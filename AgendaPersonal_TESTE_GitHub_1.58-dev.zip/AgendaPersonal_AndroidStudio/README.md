# Agenda Personal TESTE · 1.59-dev

Este é o projeto Android de teste 1.58-dev enviado, atualizado com o cadastro por link e as áreas individuais dos alunos. O pacote de teste continua `com.tiagolima.agendapersonal.teste`. O arquivo `app/google-services.json` foi preservado byte a byte e continua no projeto `agenda-personal-bdb58`. A conta de professor e o login nativo existentes foram mantidos.

## O que já está no projeto

- A área do professor usa a agenda completa atualizada, com alunos, agenda, financeiro, avaliações, catálogo, cores, técnicas e reorganização.
- Em **Mais → Mais opções → Cadastro por link**, o professor configura o endereço publicado, copia o link, abre o compartilhamento no WhatsApp e consulta os contatos.
- O aluno solicita cadastro no formulário público, criando a própria conta por e-mail e senha. O professor aprova a solicitação e pode vinculá-la ao cadastro que já existe na agenda, preservando treinos, dados financeiros, fotos e observações.
- Em **Alunos → perfil → Área do aluno**, o professor visualiza a ficha, abre uma prévia sem executar e edita o treino daquele aluno.
- Depois da aprovação e do vínculo, a edição salva na agenda é enviada para `usuarios/{uidDoAluno}/treinos/atual`. A confirmação aparece somente quando o servidor aceita o envio. Falhas mantêm a ficha local e permitem tentar novamente.
- O aluno entra pelo mesmo login nativo e recebe exclusivamente a ficha vinculada à sua conta. O professor continua usando sua própria conta ao abrir a prévia.
- Cada série tem seu número, repetições feitas, meta, carga e conclusão. O bi-set mostra os dois exercícios em sequência, com seta, mesma quantidade de rodadas e metas de repetições acompanhando o primeiro exercício; a carga de cada exercício é independente. A sequência de conclusão é A1 → B1 → descanso → A2 → B2.
- A ficha de um treino já iniciado fica preservada enquanto o professor atualiza a próxima execução.
- Reorganizar usa uma prévia: a alteração só é gravada ao finalizar a ordenação; é possível cancelar e a dupla permanece unida.
- Cores e preferências são individuais. As páginas do aluno usam uma origem local por conta, separada do banco do professor. Os registros de execução ficam neste aparelho e nesta conta; este pacote não envia esses registros para os gráficos do professor nem sincroniza o histórico entre aparelhos.

## Gerar o APK no GitHub

1. Atualize os arquivos do repositório existente com o conteúdo da pasta `AgendaPersonal_AndroidStudio`, incluindo `.github`.
2. Abra **Actions → Gerar APK TESTE (separado) → Run workflow**.
3. Depois de concluir, baixe o artefato **Agenda-Personal-TESTE**.

O projeto também abre no Android Studio. A compilação local `:app:assembleDebug` foi verificada; o ZIP entrega os fontes e as configurações, sem pastas de build ou APK compilado.

## Conectar o cadastro e os treinos no Firebase

O formulário pronto está em `web-cadastro/index.html` e precisa de um endereço público HTTPS. O formulário contém somente o cadastro do aluno. O arquivo `firebase.json` prepara uma publicação separada para evitar substituir o site que já está em uso.

Com Firebase CLI instalado e autenticado na conta responsável pelo projeto, escolha um identificador disponível para o site de cadastro e execute na raiz do projeto:

```sh
firebase hosting:sites:create SEU_SITE_CADASTRO --project agenda-personal-bdb58
firebase target:apply hosting cadastro-alunos SEU_SITE_CADASTRO --project agenda-personal-bdb58
firebase deploy --only hosting:cadastro-alunos --project agenda-personal-bdb58
```

Depois, copie o endereço exibido pelo Firebase para **Cadastro por link → Configurar endereço do formulário**. Se o site de cadastro já existir, use o identificador existente e comece pela configuração do target. Esse procedimento publica somente o formulário; não altera as regras do banco.

O login/cadastro por e-mail e senha precisa estar habilitado no Firebase Authentication. Nos cadastros criados manualmente, confirme que `usuarios/{uid}` contém `perfil: aluno`, `ativo: true` e `professorId: R2EmnDVcvMWt7TjPxOP6DjW1VOn1`. O cadastro por link já grava o vínculo com o professor e aguarda aprovação. As regras já publicadas de cadastro devem permitir ao aluno criar a própria solicitação pendente e ao professor consultar e aprovar seus contatos. As senhas ficam no Firebase Authentication, não no documento de cadastro.

Para as regras mostradas pelo usuário em 13/10/2026, use o arquivo completo **`firebase/firestore.rules`**. A captura mostrou leitura do próprio cadastro e acesso do professor a `usuarios`, com as demais operações bloqueadas. Isso impede tanto o envio do cadastro pelo aluno quanto a gravação da ficha individual. As novas regras preservam esse acesso do professor, permitem ao aluno criar apenas a própria solicitação pendente e liberam a ficha `usuarios/{uid}/treinos/atual` para gravação pelo professor e leitura pelo aluno aprovado e vinculado. O aluno não pode aprovar sua conta, mudar de professor, editar a prescrição nem acessar a ficha de outra conta.

Aplique o arquivo completo no console Firebase → Firestore → Regras → Publicar. Ele é específico para `agenda-personal-bdb58` e para o UID do professor já presente no aplicativo. A transcrição das regras anteriores está em `firebase/firestore-anterior-2026-10-13.rules`. A alteração de regras não modifica os documentos já cadastrados. Se o editor contiver regras diferentes das mostradas naquela captura, compare e preserve essas diferenças antes de publicar.

`firebase/treinos.rules.txt` continua sendo um trecho parcial para outras configurações já integradas. O botão de copiar em **Área do aluno → Orientações de conexão** copia esse trecho; ele não é substituto do arquivo completo para a configuração mostrada na captura. O arquivo `firebase.json` continua publicando apenas Hosting. `firebase-emulator.json` é exclusivo dos testes locais e não deve ser usado para publicar em produção.

As regras da captura foram analisadas e o arquivo de substituição foi validado localmente; as regras do servidor não foram publicadas ou substituídas por esta edição. O formulário não foi publicado por esta edição e nenhum cadastro real foi aprovado. A validação em seu Firebase deve ser feita com uma conta de aluno de teste: cadastrar, aprovar/vincular, salvar a ficha no professor, entrar como aluno e conferir o recebimento da alteração. A captura das regras não confirma o estado atual do Hosting nem dos perfis de todos os alunos.

## Verificação

- Compilação Android debug contra SDK 35, Gradle 8.9 e os SDKs Firebase reais.
- Testes de metas por série, bi-set, exportação individual, cadastro/vínculo sem duplicação ou perda dos dados, reorganização, agenda, financeiro, disponibilidade e navegação.
- Teste de interface em Chrome: duas tabelas do bi-set, repetições antes da carga, valores feitos, marcação em sequência, exercícios isolados, conclusão do treino, atualização durante a execução, troca de conta e prévia sem execução.

A ponte nativa e o Firebase foram simulados nos testes de interface. A compilação não substitui o teste no aparelho ou a verificação das permissões do projeto Firebase.

As regras completas foram compiladas e testadas no emulador real do Firestore, com 64 verificações aprovadas: quatro reproduzem a configuração anterior e 60 verificam a configuração corrigida. A autenticação e os documentos de teste são fictícios; nenhum serviço de produção foi acessado. Os testes cobrem cadastro por link, aprovação, consulta de contatos, publicação e atualização individual, isolamento entre contas, revogação e bloqueio de alterações indevidas. As fontes estão em `tests/firebase-rules`, e o resultado em `firebase/VALIDACAO_REGRAS.json`.

Para repetir somente os testes de regras, com Node.js e Java instalados:

```sh
cd tests/firebase-rules
npm install --no-audit --no-fund
npm test
```

Referências de configuração: [Firebase Hosting com vários sites](https://firebase.google.com/docs/hosting/multisites?hl=pt-BR), [Firestore off-line](https://firebase.google.com/docs/firestore/manage-data/enable-offline?hl=pt-BR) e [pontes nativas WebView](https://developer.android.com/privacy-and-security/risks/insecure-webview-native-bridges).
