'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8'),script=html.match(/<script id="agenda-drag-reorder-js">([\s\S]*?)<\/script>/)[1];
const elements=new Map();
class Row{
 constructor(key){this.dataset={orderKey:key};this.position={textContent:''};this.handle={closest:s=>s==='.workout-order-handle'?this.handle:s==='.workout-order-row'?this:null,setAttribute(){},focus(){}}}
 querySelector(s){return s==='.workout-order-position'?this.position:this.handle}scrollIntoView(){}
}
class List{
 constructor(markup){this.children=[...markup.matchAll(/data-order-key="([^"]+)"/g)].map(m=>new Row(m[1]));this.listeners={}}
 append(row){this.children=this.children.filter(x=>x!==row);this.children.push(row)}
 addEventListener(k,v){this.listeners[k]=v}removeEventListener(){}
}
function root(id){if(!elements.has(id))elements.set(id,{set innerHTML(value){this._html=value;if(value.includes('id="workoutOrderList"'))elements.set('workoutOrderList',new List(value))},get innerHTML(){return this._html||''}});return elements.get(id)}
const sheet={scrollTop:25,getBoundingClientRect:()=>({top:0,bottom:700,height:700})};
let plan={id:'p',name:'Ficha',organization:'sequence',days:[{id:'a',name:'A',exercises:[{id:'e1',name:'Primeiro',load:'25 kg'},{id:'e3',name:'Solto'},{id:'e2',name:'Segundo',load:'130 kg'}],bisets:[{id:'pair',exerciseIds:['e1','e2'],rounds:3,restSeconds:90}]},{id:'b',name:'B',exercises:[]},{id:'c',name:'C',exercises:[]}]},running=false,fail=false,writes=0;
const ctx={console,Date,Math,Map,Set,JSON,Object,Array,innerWidth:393,innerHeight:852,workoutDayId:'a',workoutStudentId:'s',workoutDaysOrdering:false,workoutExercisesOrdering:false,dialogStack:[],
 document:{hidden:false,getElementById:id=>id.endsWith('Dialog')?{querySelector:()=>sheet}:id==='workoutOrderStatus'?{textContent:''}:id==='workoutOrderList'?elements.get(id):root(id),querySelector:()=>null,querySelectorAll:()=>elements.get('workoutOrderList')?.children||[],addEventListener(){},removeEventListener(){}},
 addEventListener(){},removeEventListener(){},requestAnimationFrame:()=>1,cancelAnimationFrame(){},toast(){},
 renderWorkoutStudent:()=>root('workoutStudentContent').innerHTML='',renderWorkoutDay:()=>root('workoutDayContent').innerHTML='',moveWorkoutDay(){},moveWorkoutExercise(){},closeDialog(){},selectWorkoutPlan(){},openWorkoutDay(){},openWorkoutStudent(){},startWorkoutSession(){running=true},
 currentWorkoutPlan:()=>plan,currentWorkoutDay:()=>plan.days.find(x=>x.id==='a'),studentById:()=>({name:'Aluno'}),workoutDayLabel:(_,d)=>d.name,workoutPlanArchived:()=>false,workoutRunning:()=>running,workoutBisetGroups:d=>d.bisets||[],hesc:x=>String(x),replaceWorkoutPlan(next){if(fail)return false;plan=next;writes++;return true}};
ctx.window=ctx;vm.createContext(ctx);vm.runInContext(script,ctx);
const keys=()=>elements.get('workoutOrderList').children.map(r=>r.dataset.orderKey);
function keypress(index,key){const list=elements.get('workoutOrderList');list.listeners.keydown({target:list.children[index].handle,key,preventDefault(){}})}
ctx.toggleWorkoutDayOrdering();assert.deepEqual(keys(),['day:a','day:b','day:c']);keypress(0,'End');assert.equal(plan.days[0].id,'a');assert.equal(writes,0);ctx.finishWorkoutOrder();assert.deepEqual(Array.from(plan.days,d=>d.id),['b','c','a']);assert.equal(writes,1);
ctx.toggleWorkoutExerciseOrdering();assert.deepEqual(keys(),['biset:pair','exercise:e3']);keypress(0,'End');assert.deepEqual(Array.from(plan.days[2].exercises,e=>e.id),['e1','e3','e2']);ctx.cancelWorkoutOrder();assert.equal(writes,1);assert.deepEqual(Array.from(plan.days[2].exercises,e=>e.id),['e1','e3','e2']);
ctx.toggleWorkoutExerciseOrdering();keypress(0,'End');fail=true;ctx.finishWorkoutOrder();assert.equal(writes,1);assert.deepEqual(keys(),['exercise:e3','biset:pair']);fail=false;ctx.finishWorkoutOrder();assert.deepEqual(Array.from(plan.days[2].exercises,e=>e.id),['e3','e1','e2']);assert.equal(writes,2);assert.equal(plan.days[2].exercises[1].load,'25 kg');assert.equal(plan.days[2].exercises[2].load,'130 kg');
ctx.toggleWorkoutExerciseOrdering();keypress(0,'End');ctx.startWorkoutSession();assert.equal(writes,2);ctx.toggleWorkoutExerciseOrdering();assert.equal(ctx.workoutExercisesOrdering,false);
console.log('Reorganização real: prévia sem gravar, finalizar, cancelar, repetir após falha, dupla indivisível, cargas preservadas e bloqueio durante o treino. DOM simulado.');
