const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'):require;
const {chromium}=runtime('playwright');
const {fixture,init,openDay,create,start,fits,server}=require('./verify_bisets.cjs');
const qa=path.resolve(__dirname,'../../qa');fs.mkdirSync(qa,{recursive:true});
const stored=p=>p.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')));
const keys=p=>p.locator('#workoutOrderList > li').evaluateAll(rows=>rows.map(row=>row.dataset.orderKey));
const currentIds=p=>p.evaluate(()=>currentWorkoutDay().exercises.map(e=>e.id));
const item=(p,key)=>p.locator('#workoutOrderList > li[data-order-key="'+key+'"]');
async function ordering(p,kind){await p.evaluate(kind=>kind==='days'?toggleWorkoutDayOrdering():toggleWorkoutExerciseOrdering(),kind);await p.locator('#workoutOrderList').waitFor();}
async function move(p,key,to){
 const handle=await item(p,key).locator('button').boundingBox(),target=await p.locator('#workoutOrderList > li').nth(to).boundingBox();
 const x=handle.x+handle.width/2,y=handle.y+handle.height/2;
 await p.mouse.move(x,y);await p.mouse.down();await p.mouse.move(x,y+8,{steps:3});
 const from=(await keys(p)).indexOf(key),end=to>from?target.y+target.height-3:target.y+3;
 await p.mouse.move(x,end,{steps:12});await p.mouse.up();
}
async function touchMove(p,key,to,cancel=false){
 const session=await p.context().newCDPSession(p),r=await item(p,key).locator('button').boundingBox(),target=await p.locator('#workoutOrderList > li').nth(to).boundingBox();
 const x=r.x+r.width/2,y=r.y+r.height/2,from=(await keys(p)).indexOf(key),end=to>from?target.y+target.height-3:target.y+3;
 const points=(v)=>[{x,y:v,id:1,radiusX:2,radiusY:2,force:1}];
 await session.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:points(y)});
 for(let i=1;i<=12;i++)await session.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:points(y+(end-y)*i/12)});
 await session.send('Input.dispatchTouchEvent',{type:cancel?'touchCancel':'touchEnd',touchPoints:[]});await session.detach();
}
async function main(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const checks=[],layouts=[],errors=[];
 const launch=async(data=fixture,width=393,height=852,font=16)=>{
  const c=await browser.newContext({viewport:{width,height},isMobile:width<600,hasTouch:true,timezoneId:'America/Cuiaba'});await init(c,data,'deep-tl',font);
  const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));p.on('dialog',d=>d.accept());
  await p.goto('http://127.0.0.1:'+server.address().port+'/index.html');await p.waitForFunction(()=>__ready);await openDay(p);return {c,p};
 };
 try{
  const days=structuredClone(fixture);days.workoutPlans[0].organization='week';
  days.workoutPlans[0].days.push(...[1,2,3,4].map(i=>({id:'d'+i,name:['Pernas','Peito','Costas','Ombros'][i-1],weekday:i,exercises:[{id:'x'+i,name:'Exercício '+i,sets:'3',reps:'12'}]})));
  days.workoutPlans[0].days[0].weekday=0;
  let {c,p}=await launch(days);await p.evaluate(()=>closeDialog('workoutDayDialog'));
  const base=await stored(p);await ordering(p,'days');assert.equal(await p.locator('#workoutOrderList button').count(),5);assert.equal(await p.locator('#workoutStudentContent .workout-day-card').count(),0);
  assert.match(await p.locator('#workoutOrderList').innerText(),/Segunda-feira/);await move(p,'day:d',3);assert.deepEqual(await keys(p),['day:d1','day:d2','day:d3','day:d','day:d4']);assert.deepEqual(await stored(p),base);
  await p.getByRole('button',{name:'Cancelar',exact:true}).click();assert.deepEqual(await stored(p),base);assert.equal(await p.locator('#workoutOrderList').count(),0);checks.push('Treinos compactos: arraste altera apenas a prévia; cancelar mantém dados e organização normal');
  await ordering(p,'days');await move(p,'day:d',3);await p.evaluate(()=>handleAgendaSystemBack());assert.equal(await p.locator('#workoutStudentDialog.open').count(),1);assert.equal(await p.locator('#workoutOrderList').count(),0);assert.deepEqual(await stored(p),base);
  await p.evaluate(()=>handleAgendaSystemBack());assert.equal(await p.locator('#workoutStudentDialog.open').count(),0);await p.evaluate(()=>{openWorkoutStudent('s');selectWorkoutPlan('p')});checks.push('Voltar cancela primeiro a reorganização; o retorno seguinte fecha somente a ficha');
  await ordering(p,'days');await item(p,'day:d').locator('button').press('End');await item(p,'day:d3').locator('button').press('Home');
  assert.deepEqual(await keys(p),['day:d3','day:d1','day:d2','day:d4','day:d']);
  await p.evaluate(()=>{window.__writes=0;const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='agendaPersonalTL_v1')window.__writes++;return set.call(this,k,v)}});
  await p.getByRole('button',{name:'Finalizar ordenação',exact:true}).click();let saved=await stored(p);assert.deepEqual(saved.workoutPlans[0].days.map(d=>d.id),['d3','d1','d2','d4','d']);assert.equal(saved.history.length,base.history.length+1);assert.equal(await p.evaluate(()=>__writes),1);
  assert.deepEqual(saved.workoutPlans[0].days.toSorted((a,b)=>a.id.localeCompare(b.id)),base.workoutPlans[0].days.toSorted((a,b)=>a.id.localeCompare(b.id)));assert.deepEqual(saved.customData,base.customData);
  await p.reload();await p.waitForFunction(()=>__ready);await p.evaluate(()=>{showScreen('workouts');openWorkoutStudent('s');selectWorkoutPlan('p')});assert.deepEqual((await stored(p)).workoutPlans[0].days.map(d=>d.id),['d3','d1','d2','d4','d']);checks.push('Teclado, múltiplas mudanças e finalização: uma gravação; treinos intactos e ordem mantida após reabrir');
  await ordering(p,'days');await item(p,'day:d').locator('button').press('Home');await p.evaluate(()=>__failSave=true);await p.getByRole('button',{name:'Finalizar ordenação',exact:true}).click();assert.equal(await p.locator('#workoutOrderList').count(),1);assert.deepEqual(await stored(p),saved);
  assert.equal((await keys(p))[0],'day:d');await p.evaluate(()=>__failSave=false);await p.getByRole('button',{name:'Finalizar ordenação',exact:true}).click();assert.equal((await stored(p)).workoutPlans[0].days[0].id,'d');checks.push('Falha de gravação preserva dados anteriores e a prévia para tentar salvar novamente');await c.close();

  ({c,p}=await launch());await create(p);const original=await stored(p),group=original.workoutPlans[0].days[0].bisets[0],pair='biset:'+group.id;
  await ordering(p,'exercises');assert.equal(await p.locator('#workoutOrderList > li').count(),4);assert.match(await item(p,pair).innerText(),/Rosca direta \+ Rosca martelo/);assert.equal(await fits(p),'');
  await touchMove(p,pair,2);assert.deepEqual(await keys(p),['exercise:c','exercise:e',pair,'exercise:f']);assert.deepEqual(await stored(p),original);
  await touchMove(p,'exercise:c',2,true);assert.deepEqual(await keys(p),['exercise:c','exercise:e',pair,'exercise:f']);assert.equal(await p.locator('.workout-order-ghost').count(),0);
  await p.evaluate(()=>document.getElementById('toast').classList.remove('show'));await p.screenshot({path:path.join(qa,'Reordenar_exercicios.png')});
  await p.getByRole('button',{name:'Finalizar ordenação',exact:true}).click();saved=await stored(p);assert.deepEqual(await currentIds(p),['c','e','a','b','f']);
  assert.deepEqual(saved.workoutPlans[0].days[0].bisets,original.workoutPlans[0].days[0].bisets);
  assert.deepEqual(saved.workoutPlans[0].days[0].exercises.toSorted((a,b)=>a.id.localeCompare(b.id)),original.workoutPlans[0].days[0].exercises.toSorted((a,b)=>a.id.localeCompare(b.id)));
  checks.push('Toque real: bi-set move A/B juntos; cancelar um gesto mantém os arrastes anteriores; vídeos, metas e dupla intactos');
  await ordering(p,'exercises');await item(p,pair).locator('button').press('ArrowUp');await p.keyboard.press('Escape');assert.deepEqual(await currentIds(p),['c','e','a','b','f']);assert.equal(await p.locator('#workoutOrderList').count(),0);
  await ordering(p,'exercises');await item(p,pair).locator('button').press('Home');await p.evaluate(()=>{currentWorkoutDay().exercises.find(e=>e.id==='c').load='19 kg';finishWorkoutOrder()});assert.equal((await stored(p)).workoutPlans[0].days[0].exercises.find(e=>e.id==='c').load,'19 kg');
  await ordering(p,'exercises');await item(p,pair).locator('button').press('End');const beforeChanged=await stored(p);await p.evaluate(()=>{currentWorkoutDay().exercises.push({id:'new',name:'Novo exercício'});finishWorkoutOrder()});assert.deepEqual(await stored(p),beforeChanged);assert.equal(await p.locator('#workoutOrderList').count(),0);
  checks.push('Escape cancela; gravação preserva outros ajustes; mudanças na lista invalidam a prévia sem sobrescrever dados');await c.close();

  ({c,p}=await launch());await create(p);await create(p,'e','f',2,0);
  const beforePairs=await stored(p),pair1=beforePairs.workoutPlans[0].days[0].bisets[0],pair2=beforePairs.workoutPlans[0].days[0].bisets[1];
  await ordering(p,'exercises');await item(p,'biset:'+pair2.id).locator('button').press('Home');await p.getByRole('button',{name:'Finalizar ordenação',exact:true}).click();
  const afterPairs=await stored(p);assert.deepEqual(afterPairs.workoutPlans[0].days[0].bisets,[pair2,pair1]);assert.deepEqual(await currentIds(p),['e','f','a','b','c']);
  assert.deepEqual(afterPairs.workoutPlans[0].days[0].exercises.toSorted((a,b)=>a.id.localeCompare(b.id)),beforePairs.workoutPlans[0].days[0].exercises.toSorted((a,b)=>a.id.localeCompare(b.id)));
  checks.push('Múltiplos bi-sets mantêm A/B e parâmetros; a numeração acompanha a posição da dupla');await c.close();

  ({c,p}=await launch(days));await ordering(p,'exercises');await item(p,'exercise:a').locator('button').press('End');const beforeStart=await p.evaluate(()=>currentWorkoutPlan());
  await p.evaluate(()=>startWorkoutSession());
  // The regular form is rendered again before the native start function reads it.
  assert.equal(await p.locator('#workoutOrderList').count(),0);assert.deepEqual((await stored(p)).workoutPlans[0],beforeStart);
  if(!await p.evaluate(()=>workoutRunning(currentWorkoutPlan(),currentWorkoutDay())))await start(p);
  assert.equal(await p.locator('#workoutDayContent [onclick="toggleWorkoutExerciseOrdering()"]:visible').count(),0);
  await p.evaluate(()=>{toggleWorkoutExerciseOrdering();moveWorkoutExercise('a',1)});assert.deepEqual((await stored(p)).workoutPlans[0],beforeStart);assert.equal(await p.locator('#workoutOrderList').count(),0);
  await p.evaluate(()=>closeDialog('workoutDayDialog'));assert.equal(await p.locator('#workoutStudentContent [onclick="toggleWorkoutDayOrdering()"]').isDisabled(),true);
  await p.evaluate(()=>{toggleWorkoutDayOrdering();moveWorkoutDay('d',1)});assert.deepEqual((await stored(p)).workoutPlans[0],beforeStart);checks.push('Iniciar cancela uma prévia pendente; execução protege ordem dos exercícios e dos treinos da ficha');await c.close();

  const long=structuredClone(fixture);long.workoutPlans[0].days[0].exercises=Array.from({length:28},(_,i)=>({id:'long'+i,name:'Exercício '+(i+1),sets:'3',reps:'12',load:'10 kg',rest:'60 s'}));
  ({c,p}=await launch(long));await ordering(p,'exercises');
  const session=await c.newCDPSession(p),r=await item(p,'exercise:long0').locator('button').boundingBox();
  const x=r.x+r.width/2,y=r.y+r.height/2,bottom=await p.locator('#workoutDayDialog .sheet').evaluate(n=>n.getBoundingClientRect().bottom-12);
  await session.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});await session.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x,y:bottom,id:1}]});
  await p.waitForFunction(()=>document.querySelector('#workoutDayDialog .sheet').scrollTop>600);
  await session.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await session.detach();assert.ok((await keys(p)).indexOf('exercise:long0')>8);assert.equal(await p.locator('.workout-order-ghost').count(),0);
  assert.deepEqual((await stored(p)).workoutPlans[0].days[0].exercises,long.workoutPlans[0].days[0].exercises);checks.push('Lista longa rola automaticamente durante arraste pelo toque; soltar limpa a prévia flutuante sem gravação');await c.close();

  for(const [width,height,font] of [[320,740,16],[393,852,16],[393,852,20],[852,393,16]]){
   ({c,p}=await launch(days,width,height,font));await p.evaluate(()=>closeDialog('workoutDayDialog'));await ordering(p,'days');assert.equal(await fits(p),'');
   if(width===393&&font===16){await p.evaluate(()=>document.getElementById('toast').classList.remove('show'));await p.screenshot({path:path.join(qa,'Reordenar_treinos.png')});}
   await p.getByRole('button',{name:'Cancelar',exact:true}).click();await p.evaluate(()=>openWorkoutDay('d'));await ordering(p,'exercises');assert.equal(await fits(p),'');
   layouts.push({width,height,font,days:true,exercises:true});await c.close();
  }
  assert.deepEqual(errors,[]);const report={passed:true,checks,layouts,errors};fs.writeFileSync(path.join(qa,'reordering-review.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
 }finally{await browser.close();server.close();}
}
if(require.main===module)main().catch(e=>{console.error(e);process.exitCode=1;server.close()});
