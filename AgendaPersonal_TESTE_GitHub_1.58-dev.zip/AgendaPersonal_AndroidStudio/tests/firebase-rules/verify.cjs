'use strict';
// Executa somente contra o emulador local, com autenticação simulada.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {initializeTestEnvironment, assertSucceeds, assertFails} = require('@firebase/rules-unit-testing');
const {doc, collection, query, where, getDoc, getDocs, setDoc, updateDoc,
  deleteDoc, serverTimestamp, Timestamp, setLogLevel} = require('firebase/firestore');
setLogLevel('silent');

const PROJECT = 'demo-agenda-rules';
const TEACHER = 'R2EmnDVcvMWt7TjPxOP6DjW1VOn1';
const root = path.resolve(__dirname, '../..');
const tests = [];
let env;
const pending = (email = 'cadastro@example.test', overrides = {}) => ({
  nome: 'Aluno de teste', email, whatsapp: '(69) 99999-1234',
  nascimento: '1996-04-12', genero: 'Prefiro não informar',
  perfil: 'aluno', ativo: false, professorId: TEACHER,
  criadoEm: serverTimestamp(), ...overrides
});
const payload = (uid, name = 'Aluno de teste') => JSON.stringify({
  version: 2, professorId: TEACHER, studentUid: uid, studentId: 'local-' + uid,
  enabled: true, profile: {name}, plans: []
});
const workout = (uid, overrides = {}) => ({
  version: 2, professorId: TEACHER, studentUid: uid, studentId: 'local-' + uid,
  payload: payload(uid), updatedAt: serverTimestamp(), ...overrides
});
const actor = (uid, email = uid.toLowerCase() + '@example.test') =>
  env.authenticatedContext(uid, {email}).firestore();
const profileRef = (db, uid) => doc(db, 'usuarios', uid);
const workoutRef = (db, uid, id = 'atual') => doc(db, 'usuarios', uid, 'treinos', id);
async function test(name, action) {
  await action();
  tests.push(name);
  console.log('OK ' + name);
}
async function start(file) {
  if (env) await env.cleanup();
  env = await initializeTestEnvironment({projectId: PROJECT, firestore: {
    host: '127.0.0.1', port: 8185, rules: fs.readFileSync(path.join(root, 'firebase', file), 'utf8')
  }});
  await env.clearFirestore();
}
async function seed() {
  await env.withSecurityRulesDisabled(async ctx => {
    const db = ctx.firestore();
    const date = Timestamp.fromDate(new Date('2026-01-01T00:00:00Z'));
    for (const [uid, active, teacher] of [
      ['AlunoTesteA', true, TEACHER], ['AlunoTesteB', true, TEACHER],
      ['AlunoPendente', false, TEACHER], ['AlunoOutroProfessor', true, 'OutroProfessor']
    ]) {
      await setDoc(profileRef(db, uid), pending(uid.toLowerCase() + '@example.test', {
        ativo: active, professorId: teacher, criadoEm: date
      }));
    }
    await setDoc(profileRef(db, TEACHER), {nome: 'Professor de teste', perfil: 'professor', ativo: true});
    await setDoc(profileRef(db, 'AlunoLegado'), {nome: 'Cadastro legado de teste', perfil: 'aluno', ativo: true});
    await setDoc(workoutRef(db, 'AlunoPendente'), workout('AlunoPendente', {updatedAt: date}));
  });
}
async function run() {
  await start('firestore-anterior-2026-10-13.rules');
  await seed();
  let teacher = actor(TEACHER);
  let alice = actor('AlunoTesteA');
  await test('Anterior: professor continua lendo os cadastros', () => assertSucceeds(getDocs(collection(teacher, 'usuarios'))));
  await test('Anterior: aluno lê seu cadastro', () => assertSucceeds(getDoc(profileRef(alice, 'AlunoTesteA'))));
  await test('Reprodução: cadastro por link era bloqueado', () => assertFails(setDoc(profileRef(actor('CadastroTeste', 'cadastro@example.test'), 'CadastroTeste'), pending())));
  await test('Reprodução: publicação do treino era bloqueada', () => assertFails(setDoc(workoutRef(teacher, 'AlunoTesteA'), workout('AlunoTesteA'))));

  await start('firestore.rules');
  await seed();
  teacher = actor(TEACHER);
  alice = actor('AlunoTesteA');
  const bob = actor('AlunoTesteB');
  const guest = env.unauthenticatedContext().firestore();
  const applicant = actor('CadastroTeste', 'cadastro@example.test');
  await test('Professor mantém leitura de todos os cadastros', () => assertSucceeds(getDocs(collection(teacher, 'usuarios'))));
  await test('Consulta nativa de contatos funciona', () => assertSucceeds(getDocs(query(collection(teacher, 'usuarios'), where('professorId', '==', TEACHER)))));
  await test('Professor mantém edição do próprio perfil', () => assertSucceeds(updateDoc(profileRef(teacher, TEACHER), {nome: 'Professor de teste atualizado'})));
  await test('Cadastro manual pelo professor continua permitido', () => assertSucceeds(setDoc(profileRef(teacher, 'AlunoManual'), {nome: 'Aluno manual de teste', perfil: 'aluno', ativo: true, professorId: TEACHER})));
  await test('Formulário pode verificar que seu cadastro ainda não existe', async () => {
    const snap = await assertSucceeds(getDoc(profileRef(applicant, 'CadastroTeste')));
    assert.equal(snap.exists(), false);
  });
  await test('Cadastro por link grava exatamente o documento do formulário', () => assertSucceeds(setDoc(profileRef(applicant, 'CadastroTeste'), pending())));
  await test('Reenvio consulta a própria solicitação pendente', async () => {
    const snap = await assertSucceeds(getDoc(profileRef(applicant, 'CadastroTeste')));
    assert.equal(snap.data().ativo, false);
  });
  await test('Aluno não pode aprovar o próprio acesso', () => assertFails(updateDoc(profileRef(applicant, 'CadastroTeste'), {ativo: true})));
  await test('Aluno não pode substituir seu cadastro por outro perfil', () => assertFails(setDoc(profileRef(applicant, 'CadastroTeste'), pending('cadastro@example.test', {perfil: 'professor', ativo: true}))));
  await test('Aluno não pode apagar o próprio cadastro', () => assertFails(deleteDoc(profileRef(applicant, 'CadastroTeste'))));
  await test('Aluno não pode ler cadastros de outros alunos', () => assertFails(getDoc(profileRef(alice, 'AlunoTesteB'))));
  await test('Aluno não pode listar todos os cadastros', () => assertFails(getDocs(collection(alice, 'usuarios'))));
  await test('Pessoa sem login não pode ler o cadastro', () => assertFails(getDoc(profileRef(guest, 'AlunoTesteA'))));
  await test('Pessoa sem login não pode enviar cadastro', () => assertFails(setDoc(profileRef(guest, 'Visitante'), pending())));
  await test('Aluno não pode criar o cadastro de outra conta', () => assertFails(setDoc(profileRef(alice, 'OutraConta'), pending('alunotestea@example.test'))));

  const attacks = [
    ['já aprovado', {ativo: true}], ['perfil de professor', {perfil: 'professor'}],
    ['outro professor', {professorId: 'OutroProfessor'}], ['campo administrativo extra', {admin: true}],
    ['senha no documento', {senha: 'valor-proibido'}], ['e-mail alheio', {email: 'outro@example.test'}],
    ['nome inválido', {nome: 'x'}], ['telefone curto', {whatsapp: '123'}],
    ['data em formato inválido', {nascimento: '12/04/1996'}], ['gênero inválido', {genero: 'inválido'}],
    ['data de criação forjada', {criadoEm: Timestamp.fromDate(new Date('2026-01-01T00:00:00Z'))}]
  ];
  for (let i = 0; i < attacks.length; i++) {
    const [name, overrides] = attacks[i], uid = 'Ataque' + i;
    await test('Cadastro rejeita ' + name, () => assertFails(setDoc(profileRef(actor(uid, 'cadastro@example.test'), uid), pending('cadastro@example.test', overrides))));
  }
  await test('Cadastro rejeita campo obrigatório ausente', () => {
    const data = pending(); delete data.whatsapp;
    return assertFails(setDoc(profileRef(actor('CampoAusente', 'cadastro@example.test'), 'CampoAusente'), data));
  });
  await test('Cadastro aceita e-mail autenticado com maiúsculas', () => assertSucceeds(setDoc(profileRef(actor('EmailMaiusculo', 'CADASTRO@example.test'), 'EmailMaiusculo'), pending())));
  await test('Cadastro sem e-mail autenticado é rejeitado', () => assertFails(setDoc(profileRef(env.authenticatedContext('SemEmail').firestore(), 'SemEmail'), pending())));
  await test('Somente professor aprova a solicitação', () => assertSucceeds(updateDoc(profileRef(teacher, 'CadastroTeste'), {ativo: true, aprovadoEm: serverTimestamp()})));

  await test('Aluno aprovado pode consultar sua ficha ainda ausente', async () => {
    const snap = await assertSucceeds(getDoc(workoutRef(alice, 'AlunoTesteA')));
    assert.equal(snap.exists(), false);
  });
  await test('Professor publica a ficha individual no formato Android', () => assertSucceeds(setDoc(workoutRef(teacher, 'AlunoTesteA'), workout('AlunoTesteA'))));
  await test('Aluno aprovado recebe sua ficha', async () => {
    const snap = await assertSucceeds(getDoc(workoutRef(alice, 'AlunoTesteA')));
    assert.equal(snap.data().studentUid, 'AlunoTesteA');
  });
  await test('Professor atualiza a ficha individual', () => assertSucceeds(setDoc(workoutRef(teacher, 'AlunoTesteA'), workout('AlunoTesteA', {payload: payload('AlunoTesteA', 'Ficha atualizada')}))));
  await test('Aluno recebe a alteração publicada', async () => {
    const snap = await assertSucceeds(getDoc(workoutRef(alice, 'AlunoTesteA')));
    assert.equal(JSON.parse(snap.data().payload).profile.name, 'Ficha atualizada');
  });
  await test('Aluno não pode modificar a prescrição', () => assertFails(updateDoc(workoutRef(alice, 'AlunoTesteA'), {payload: 'alterado pelo aluno'})));
  await test('Aluno não pode apagar a prescrição', () => assertFails(deleteDoc(workoutRef(alice, 'AlunoTesteA'))));
  await test('Segundo aluno não pode ler a ficha do primeiro', () => assertFails(getDoc(workoutRef(bob, 'AlunoTesteA'))));
  await test('Pessoa sem login não pode ler treinos', () => assertFails(getDoc(workoutRef(guest, 'AlunoTesteA'))));
  await test('Aluno pendente não pode ler treinos já existentes', () => assertFails(getDoc(workoutRef(actor('AlunoPendente'), 'AlunoPendente'))));
  await test('Professor não publica treino antes da aprovação', () => assertFails(setDoc(workoutRef(teacher, 'AlunoPendente'), workout('AlunoPendente'))));
  await test('Professor não publica ficha para aluno de outro professor', () => assertFails(setDoc(workoutRef(teacher, 'AlunoOutroProfessor'), workout('AlunoOutroProfessor'))));
  await test('Professor não publica para cadastro legado sem vínculo', () => assertFails(setDoc(workoutRef(teacher, 'AlunoLegado'), workout('AlunoLegado'))));
  await test('Professor não publica para cadastro inexistente', () => assertFails(setDoc(workoutRef(teacher, 'SemCadastro'), workout('SemCadastro'))));
  for (const [name, values] of [
    ['UID incompatível', {studentUid: 'AlunoTesteB'}], ['professor incompatível', {professorId: 'OutroProfessor'}],
    ['versão inválida', {version: 1}], ['campo extra', {admin: true}],
    ['identificador vazio', {studentId: ''}], ['payload em outro tipo', {payload: {plans: []}}],
    ['timestamp forjado', {updatedAt: Timestamp.fromDate(new Date('2026-01-01T00:00:00Z'))}],
    ['payload maior que 650000 bytes', {payload: 'a'.repeat(650001)}],
    ['payload UTF-8 maior que 650000 bytes', {payload: 'é'.repeat(325001)}]
  ]) {
    await test('Publicação rejeita ' + name, () => assertFails(setDoc(workoutRef(teacher, 'AlunoTesteA'), workout('AlunoTesteA', values))));
  }
  await test('Documento de treino fora de atual continua bloqueado', () => assertFails(setDoc(workoutRef(teacher, 'AlunoTesteA', 'outro'), workout('AlunoTesteA'))));
  await test('Outras coleções continuam bloqueadas para o professor', () => assertFails(setDoc(doc(teacher, 'financeiro', 'teste'), {valor: 1})));
  await test('Outras coleções continuam bloqueadas para o aluno', () => assertFails(getDoc(doc(alice, 'financeiro', 'teste'))));
  await test('Revogação do acesso pelo professor funciona', () => assertSucceeds(updateDoc(profileRef(teacher, 'AlunoTesteA'), {ativo: false})));
  await test('Após revogação aluno não lê mais a ficha', () => assertFails(getDoc(workoutRef(alice, 'AlunoTesteA'))));
  await test('Após revogação aluno ainda consulta o próprio estado', () => assertSucceeds(getDoc(profileRef(alice, 'AlunoTesteA'))));
  await test('Professor pode remover a ficha do seu aluno', () => assertSucceeds(deleteDoc(workoutRef(teacher, 'AlunoTesteA'))));

  const report = {status: 'passed', tests: tests.length, project: PROJECT,
    emulator: 'Firestore local; identidades e dados fictícios', productionAccessed: false,
    oldRulesReproduced: true, cases: tests};
  if (process.env.AGENDA_RULES_REPORT) fs.writeFileSync(process.env.AGENDA_RULES_REPORT, JSON.stringify(report, null, 2) + '\n');
  console.log('RESULTADO: ' + tests.length + ' verificações aprovadas.');
}
run().catch(e => {console.error(e); process.exitCode = 1;}).finally(async () => {
  if (env) await env.cleanup();
});
