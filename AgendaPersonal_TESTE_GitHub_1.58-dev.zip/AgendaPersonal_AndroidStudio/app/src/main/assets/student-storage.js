(function(){
 'use strict';
 window.__AP_STUDENT_CONTEXT=null;
 const temporary=new Map(),memory={getItem:k=>temporary.get(String(k))??null,setItem:(k,v)=>temporary.set(String(k),String(v)),removeItem:k=>temporary.delete(String(k))};
 function backend(){try{return window.localStorage}catch(_){return memory}}
 function mapped(key){const context=window.__AP_STUDENT_CONTEXT;if(!String(key).startsWith('agenda_demo_'))return String(key);if(!context?.storageId)return null;return 'agenda_student_v2_'+context.storageId+':'+key}
 window.APstudentStorage=Object.freeze({
  getItem(key){const k=mapped(key);return k===null?null:backend().getItem(k)},
  setItem(key,value){const k=mapped(key);if(k===null)throw Error('Entre na área do aluno antes de salvar.');backend().setItem(k,String(value))},
  removeItem(key){const k=mapped(key);if(k!==null)backend().removeItem(k)},
 });
})();
