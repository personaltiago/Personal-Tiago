(function(){
 'use strict';
 const M=APStudentModel,identity=APnative.identity();
 let activated=false;
 function fail(text){window.APstudentUI?.reset();window.__AP_STUDENT_CONTEXT=null;route('landing');const e=document.getElementById('apAccountStatus');e.textContent=text+' ';const button=document.createElement('button');button.type='button';button.textContent='Entrar novamente';button.onclick=()=>APnative.request('logout');e.appendChild(button);e.hidden=false;document.body.dataset.view='connecting'}
 if(!identity||!['student','preview'].includes(identity.role)){fail('Entre com a sua conta no aplicativo.');return}
 const preview=identity.role==='preview';
 window.__AP_STUDENT_CONTEXT={storageId:preview?'preview_'+identity.studentId:identity.uid,role:preview?'preview':'student',profile:identity.profile||{},area:null};
 document.body.dataset.apAccount=preview?'preview':'student';
 window.APaccounts=Object.freeze({closePreview:()=>APnative.request('closePreview'),logout:()=>APnative.request('logout')});
 logoutDemo=function(){if(preview){APaccounts.closePreview();return}APaccounts.logout()};
 window.APnativeStudent=function(value){
  if(!window.__AP_STUDENT_CONTEXT)return;
  if(value.kind==='blocked'){fail(value.message||'Seu acesso precisa ser aprovado pelo professor.');return}
  if(value.kind==='profile'){Object.assign(window.__AP_STUDENT_CONTEXT.profile,value.profile);if(!activated){activated=true;APstudentUI.activate();document.getElementById('apAccountStatus').hidden=true}else APstudentUI.repaint();return}
  if(value.kind==='error'){APstudentUI.status(value.message||'Não foi possível atualizar o treino. Confira a conexão.');return}
  try{
   const area=value.payload?M.assertArea(JSON.parse(value.payload),preview?null:identity.uid):null;
   if(area&&area.studentId!==value.studentId)throw Error('O vínculo desta ficha é inválido.');
   window.__AP_STUDENT_CONTEXT.area=area;
   APstudentUI.repaint();APstudentUI.status(preview?'Prévia do professor · os registros de execução estão bloqueados.':value.fromCache?'Treino salvo neste aparelho. Aguardando conexão.':area?'Treino atualizado pelo professor.':'Aguardando o professor disponibilizar seu treino.');
  }catch(e){window.__AP_STUDENT_CONTEXT.area=null;APstudentUI.repaint();APstudentUI.status(e.message)}
 };
 const stored=prefs();if(!stored.color&&identity.color){APstudentStorage.setItem(PREF_KEY,JSON.stringify({...stored,color:identity.color}))}
 if(preview){document.getElementById('apStudentPreviewBar').hidden=false;document.getElementById('apStudentPreviewName').textContent=identity.profile?.name||'Aluno'}
 if(preview){activated=true;APstudentUI.activate(true)}else{route('landing');document.body.dataset.view='connecting';const status=document.getElementById('apAccountStatus');status.textContent='Carregando sua área…';status.hidden=false}
 APnative.request('subscribe').catch(e=>APstudentUI.status(e.message));
 exercisePlayVideo=function(index=exIndex){const e=exercisesFor(exActiveId)[index];if(!e?.video){toast('Vídeo não cadastrado pelo professor.');return}APnative.request('video',{url:e.video,title:e.name}).catch(e=>toast(e.message))};
 openExerciseImage=function(index=exIndex){exercisePlayVideo(index)};
 window.handleAgendaSystemBack=function(){
  for(const id of ['homeModal','bgDialog','profilePhotoDialog','profileEditor','exFinishModal']){const e=document.getElementById(id);if(e&&!e.hidden){e.hidden=true;return true}}
  const view=document.body.dataset.view;if(view==='home'){if(preview)APaccounts.closePreview();return !preview?false:true}
  if(view==='aluno'||view==='gender'){route('home');return true}agendaBack();return true;
 };
})();
