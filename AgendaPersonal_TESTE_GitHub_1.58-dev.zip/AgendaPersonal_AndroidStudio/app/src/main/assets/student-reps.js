(function(){
 'use strict';
 const ctx=()=>window.__AP_STUDENT_CONTEXT;
 function actual(session,index,e){const saved=session?.repResults?.[index];return e.rows.map((r,n)=>saved&&Object.hasOwn(saved,n)?saved[n]:(/^\d+$/.test(r.reps)?Number(r.reps):null))}
 window.APactualReps=actual;
 window.saveExerciseReps=function(index,n,value){
  if(ctx()?.role!=='student')return;const store=exStore(),s=store.active[exActiveId],e=exercisesFor(exActiveId)[index];
  if(!s||!e||n<0||n>=e.sets||exChecks(s,index,e.sets)[n])return;
  if(!s.repResults)s.repResults={};if(!s.repResults[index])s.repResults[index]=actual(s,index,e);
  const count=value===''?null:Number(value);
  if(count!==null&&(!Number.isInteger(count)||count<0||count>999)){s.repResults[index][n]=null;exSave(store);toast('Informe quantas repetições conseguiu fazer.');return}
  s.repResults[index][n]=count;exSave(store);
 };
 saveExerciseLoad=function(index,n,value){
  if(ctx()?.role!=='student')return;const store=exStore(),s=store.active[exActiveId],e=exercisesFor(exActiveId)[index];
  if(!s||!e||n<0||n>=e.sets||exChecks(s,index,e.sets)[n])return;
  const number=value===''?null:Number(String(value).replace(',','.'));
  if(!s.loads[index])s.loads[index]=exPresets(exActiveId,index,e.sets);
  if(number!==null&&(!Number.isFinite(number)||number<0||number>1000)){s.loads[index][n]=null;exSave(store);toast('Informe uma carga entre 0 e 1000 kg.');return}
  s.loads[index][n]=number;exSave(store);
 };
 exSetRowsMarkup=function(index,session,running){
  const e=exercisesFor(exActiveId)[index],done=exChecks(session,index,e.sets),loads=exLoads(session,exActiveId,index,e.sets),reps=actual(session,index,e),can=running&&ctx()?.role==='student';
  return e.rows.map((row,n)=>'<div class="ex-load-row"><div class="ex-num">'+(n+1)+'</div><label class="ex-reps"><input type="number" min="0" max="999" step="1" inputmode="numeric" aria-label="Repetições feitas de '+htmlSafe(e.name)+' na série '+(n+1)+'" value="'+(reps[n]??'')+'" placeholder="'+htmlSafe(row.reps)+'" '+(!can||done[n]?'disabled':'')+' oninput="saveExerciseReps('+index+','+n+',this.value)"><small>Meta: '+htmlSafe(row.reps)+'</small></label><label class="ex-weight"><input type="number" step="0.5" min="0" max="1000" inputmode="decimal" aria-label="Carga de '+htmlSafe(e.name)+' na série '+(n+1)+'" value="'+(loads[n]??'')+'" '+(!can||done[n]?'disabled':'')+' onchange="saveExerciseLoad('+index+','+n+',this.value)"><span>kg</span></label><button class="ex-check'+(done[n]?' checked':'')+'" type="button" onclick="toggleExerciseSet('+index+','+n+')" aria-label="'+(done[n]?'Desmarcar':'Concluir')+' série '+(n+1)+'" '+(!can?'disabled':'')+'>'+(done[n]?exSvg('check'):'')+'</button></div>').join('');
 };
 const mark=toggleExerciseSet;
 toggleExerciseSet=function(index,n){
  const s=exGetSession(),e=exercisesFor(exActiveId)[index];if(!s||!e)return;
  if(!exChecks(s,index,e.sets)[n]&&actual(s,index,e)[n]===null){toast('Informe as repetições que conseguiu fazer nesta série.');return}
  mark(index,n);
 };
 evRecordReps=function(record){const rows=record.actualReps||record.targets||Array(record.sets||0).fill(record.reps);return rows.reduce((sum,reps,n)=>record.done?.[n]&&reps!==null&&/^\d+$/.test(String(reps))?sum+Number(reps):sum,0)};
})();
