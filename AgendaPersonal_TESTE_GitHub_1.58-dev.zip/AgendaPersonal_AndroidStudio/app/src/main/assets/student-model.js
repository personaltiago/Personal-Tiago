(function(global){
 'use strict';
 const TEACHER='R2EmnDVcvMWt7TjPxOP6DjW1VOn1';
 const text=(value,max=200)=>String(value??'').trim().slice(0,max);
 const uid=value=>/^[A-Za-z0-9_-]{1,128}$/.test(String(value||''));
 const clone=value=>JSON.parse(JSON.stringify(value));
 function https(value){try{const u=new URL(String(value||''));return u.protocol==='https:'&&!u.username&&!u.password?u.href:''}catch(_){return ''}}
 function youtube(value){try{const u=new URL(https(value));let v='';if(u.hostname==='youtu.be')v=u.pathname.slice(1);else if(/^(www\.)?(youtube\.com|youtube-nocookie\.com)$/.test(u.hostname))v=u.searchParams.get('v')||u.pathname.split('/').filter(Boolean)[1]||'';return /^[A-Za-z0-9_-]{11}$/.test(v)?v:''}catch(_){return ''}}
 function load(value){const match=String(value??'').replace(',','.').match(/\d+(?:\.\d+)?/);return match&&Number(match[0])<=1000?Number(match[0]):null}
 function makeArea(state,student,helpers={}){
  if(!student||!state.students.some(s=>s.id===student.id))throw Error('Aluno não encontrado na agenda.');
  const linked=text(student.firebaseUid,128);if(linked&&!uid(linked))throw Error('O vínculo do aluno é inválido.');
  const area={version:2,professorId:TEACHER,studentId:text(student.id,160),studentUid:linked,enabled:!student.workoutInactive,profile:{name:text(student.name,120),email:text(student.email,254),phone:text(student.phone,40),birth:text(student.birthDate,10),gender:text(student.gender,60),type:text(student.studentType,20),photo:/^data:image\/(jpeg|png|webp);base64,/.test(student.photoDataUrl||'')&&student.photoDataUrl.length<200000?student.photoDataUrl:'',goal:text(student.importedTrainingProfile?.goal,300)},plans:[]};
  if(area.enabled)for(const p of state.workoutPlans||[]){
   if(p.studentId!==student.id||!(helpers.visible?helpers.visible(p):!p.archived&&p.visibility!=='hidden'))continue;
   const plan={id:text(p.id,160),name:text(p.name,160),goal:text(p.goal,300),notes:text(p.notes,4000),organization:p.organization==='week'?'week':'sequence',days:[]};
   for(const d of p.days||[]){
    const day={id:text(d.id,160),name:text(d.name,160),weekday:Number.isInteger(Number(d.weekday))?Number(d.weekday):null,notes:text(d.notes,4000),minutes:Number(p.duration||d.duration)||0,exercises:[]};
    const groups=helpers.groups?helpers.groups(d):(d.bisets||[]);
    for(const raw of d.exercises||[]){
     const g=groups.find(g=>g.exerciseIds?.includes(raw.id));
     const ex=g&&helpers.shared?helpers.shared(d,g,raw):raw;
     const count=Math.max(1,Math.min(100,Math.floor(Number(g?.rounds||ex.sets)||1))),rows=[];
     for(let n=1;n<=count;n++){
      const r=helpers.prescription?helpers.prescription(ex,n,count):null;
      const seconds=r?.restSeconds??g?.restSeconds??parseInt(ex.rest);rows.push({reps:text(r?.reps??ex.reps,500),load:load(r?.load??ex.load),rest:Math.max(0,Math.min(1800,Number.isFinite(Number(seconds))?Number(seconds):60))});
     }
     day.exercises.push({id:text(raw.id,160),name:text(ex.name,160),muscles:text(ex.muscle||ex.muscles,300),description:text(ex.guidance?.execution||ex.description||ex.notes,5000),notes:text(ex.observations,3000),video:https(ex.video),technique:text(ex.technique?.name,160),techniqueNotes:text(ex.technique?.notes||ex.technique?.observations,2000),pair:g?text(g.id,160):'',pairOwner:!!g&&g.exerciseIds[0]===raw.id,rows});
    }
    plan.days.push(day);
   }
   area.plans.push(plan);
  }
  assertArea(area,linked||null);return area;
 }
 function assertArea(area,expectedUid=null){
  if(!area||area.version!==2||area.professorId!==TEACHER||!area.studentId||typeof area.enabled!=='boolean'||!area.profile||typeof area.profile.name!=='string'||!Array.isArray(area.plans))throw Error('Área do aluno inválida.');
  if(expectedUid!==null&&(!uid(expectedUid)||area.studentUid!==expectedUid))throw Error('Este treino pertence a outro aluno.');
  let count=0;const plans=new Set();
  for(const p of area.plans){if(!p.id||plans.has(p.id)||!Array.isArray(p.days))throw Error('Ficha inválida.');plans.add(p.id);const days=new Set();
   for(const d of p.days){if(!d.id||days.has(d.id)||!Array.isArray(d.exercises))throw Error('Dia de treino inválido.');days.add(d.id);const ids=new Set();
    for(const e of d.exercises){if(!e.id||ids.has(e.id)||e.video&&!https(e.video)||!Array.isArray(e.rows)||!e.rows.length||e.rows.length>100||e.rows.some(r=>!r||typeof r.reps!=='string'||r.load!==null&&(!Number.isFinite(r.load)||r.load<0||r.load>1000)))throw Error('Prescrição inválida.');ids.add(e.id);count++;}
   }
  }
  if(count>2000||new TextEncoder().encode(JSON.stringify(area)).byteLength>650000)throw Error('A ficha ultrapassa o limite de envio. Divida o conteúdo em fichas menores.');
  return area;
 }
 function key(plan,day){return encodeURIComponent(plan).replace(/'/g,'%27')+'~'+encodeURIComponent(day).replace(/'/g,'%27')}
 function workouts(area){
  if(!area||!area.enabled)return [];
  const output=[];for(const p of area.plans)for(const d of p.days){
   const es=d.exercises.map((e,index)=>{const companion=e.pair?d.exercises.findIndex(other=>other.id!==e.id&&other.pair===e.pair):null;return {id:e.id,name:e.name,muscles:e.muscles||'Não informado',desc:[e.description,e.notes].filter(Boolean).join('\n'),sets:e.rows.length,reps:e.rows.map(r=>r.reps).every(v=>v===e.rows[0].reps)?e.rows[0].reps:e.rows.map(r=>r.reps).join(' / '),rest:e.rows[0].rest,tech:e.pair?(e.pairOwner?'Bi-set':e.technique):e.technique,techDesc:e.pair?'A → B, sem pausa entre os exercícios. Descanse depois de B.':e.techniqueNotes,paired:companion>=0?companion:null,pairOwner:e.pairOwner,pair:e.pair,video:e.video,rows:clone(e.rows),index};});
   output.push({id:key(p.id,d.id),label:d.name||String.fromCharCode(65+output.length%26),name:d.name,planName:p.name,planId:p.id,dayId:d.id,weekday:p.organization==='week'?d.weekday:null,count:es.length,tech:es.filter(e=>e.tech).length,min:d.minutes||0,photo:key(p.id,d.id),notes:[p.notes,d.notes].filter(Boolean).join('\n'),exercises:es});
  }return output;
 }
 global.APStudentModel=Object.freeze({TEACHER,text,uid,clone,https,youtube,makeArea,assertArea,workouts,key});
})(globalThis);
