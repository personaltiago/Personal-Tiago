(function(){
 'use strict';
 const M=APStudentModel,TEACHER=M.TEACHER,OUTBOX='agenda_teacher_native_areas_v2_'+TEACHER;
 const identity=APnative.identity(),statuses=new Map();let outbox={},pumping=false,queued=false;
 const teacher=()=>identity?.role==='teacher'&&identity.uid===TEACHER;
 try{outbox=JSON.parse(localStorage.getItem(OUTBOX)||'{}')||{}}catch(_){outbox={}}
 const persist=()=>localStorage.setItem(OUTBOX,JSON.stringify(outbox));
 function status(uid,value){statuses.set(uid,value);window.APupdateAreaStatus?.(uid)}
 const message=e=>e.code==='permission-denied'?'O Firebase não autorizou o envio. Confira as regras dos treinos.':e.message||'A alteração continua aguardando envio.';
 function stage(area){
  if(!teacher())return {state:'signed-out',message:'Entre com a conta do professor.'};
  M.assertArea(area,area.studentUid||null);if(!area.studentUid)return {state:'unlinked',message:'Vincule a conta do aluno em Cadastro por link → Contatos.'};
  const uid=area.studentUid,payload=JSON.stringify(area);
  if(outbox[uid]?.payload===payload){if(statuses.get(uid)?.state!=='error')Promise.resolve().then(pump);return statuses.get(uid)||{state:outbox[uid].sent?'sent':'pending',message:outbox[uid].sent?'Treino atualizado na conta do aluno.':'Treino salvo. Aguardando envio.'}}
  const prior=outbox[uid];outbox[uid]={payload,sent:false};
  try{persist()}catch(e){if(prior)outbox[uid]=prior;else delete outbox[uid];status(uid,{state:'error',message:'Não foi possível guardar a fila de envio neste aparelho.'});return statuses.get(uid)}
  status(uid,{state:'pending',message:'Treino salvo na agenda. Enviando para o aluno…'});if(pumping)queued=true;Promise.resolve().then(pump);return statuses.get(uid);
 }
 async function pump(){
  if(!teacher()||pumping)return;pumping=true;
  try{do{queued=false;for(const [uid,item] of Object.entries(outbox)){
   if(item.sent)continue;const payload=item.payload;
   try{await APnative.request('publish',{uid,payload});if(outbox[uid]?.payload!==payload){queued=true;continue}item.sent=true;persist();status(uid,{state:'sent',message:'Treino atualizado na conta do aluno.'})}
   catch(e){if(outbox[uid]?.payload!==payload){queued=true;continue}status(uid,{state:'error',message:message(e)})}
  }}while(queued&&teacher())}finally{pumping=false}
 }
 window.APaccounts=Object.freeze({isTeacher:teacher,stage,status:uid=>statuses.get(uid)||{state:outbox[uid]?.sent?'sent':'pending',message:outbox[uid]?.sent?'Treino atualizado na conta do aluno.':'Treino salvo. Aguardando envio.'},retry(uid){if(outbox[uid]){outbox[uid].sent=false;persist()}pump()},knownAreas(){return Object.values(outbox).map(v=>{try{return JSON.parse(v.payload)}catch(_){return null}}).filter(Boolean)},refreshPreview(){},preview:area=>APnative.request('preview',{payload:JSON.stringify(area)}),copyRules:()=>APnative.request('copyRules'),logout:()=>APnative.request('logout')});
 window.addEventListener('online',pump);window.addEventListener('focus',pump);
})();
