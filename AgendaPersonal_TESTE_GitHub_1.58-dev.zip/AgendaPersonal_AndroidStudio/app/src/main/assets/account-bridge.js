(function(){
 'use strict';
 const pending=new Map();let sequence=0;
 function request(action,value={}){
  return new Promise((resolve,reject)=>{
   const id='ap_'+(++sequence);pending.set(id,{resolve,reject});
   try{if(!window.AgendaAccount?.request)throw Error('Abra esta área pelo aplicativo Agenda Personal.');AgendaAccount.request(id,action,JSON.stringify(value));}
   catch(e){pending.delete(id);reject(e)}
  });
 }
 window.APnative=Object.freeze({request,identity(){try{return JSON.parse(AgendaAccount.getIdentity())}catch(_){return null}}});
 window.APnativeResult=function(id,value){const item=pending.get(id);if(!item)return;pending.delete(id);if(value.ok)item.resolve(value.data);else item.reject(Object.assign(Error(value.message||'Não foi possível concluir esta ação.'),{code:value.code||'unknown'}))};
 window.addEventListener('pagehide',()=>{for(const p of pending.values())p.reject(Error('A tela foi fechada.'));pending.clear()});
})();
