package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.MetadataChanges;
import com.google.firebase.firestore.Source;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Restricted account API used only by bundled local pages; no passwords or tokens enter JavaScript. */
public final class NativeAccountBridge {
    private final Activity activity;
    private final WebView webView;
    private final String actorUid, role, previewPayload;
    private final String studentPageUrl;
    private final FirebaseAuth auth = FirebaseAuth.getInstance();
    private final FirebaseFirestore store = FirebaseFirestore.getInstance();
    private ListenerRegistration profileListener, workoutListener;
    private volatile boolean destroyed;
    private int generation;

    NativeAccountBridge(Activity activity, WebView webView, String role, String previewPayload) {
        this.activity = activity; this.webView = webView; this.role = role;
        this.previewPayload = previewPayload;
        FirebaseUser user = auth.getCurrentUser();
        this.actorUid = user == null ? "" : user.getUid();
        String pageKey = actorUid + ("preview".equals(role) ? "_preview" : "_student");
        try {
            byte[] hash = java.security.MessageDigest.getInstance("SHA-256").digest(pageKey.getBytes(StandardCharsets.UTF_8));
            StringBuilder host = new StringBuilder();for (byte value : hash) host.append(String.format("%02x", value & 0xff));
            studentPageUrl = "https://aluno-" + host.substring(0, 32) + "." + host.substring(32) + ".agenda.invalid/aluno.html";
        } catch (java.security.NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }

    private boolean sameAccount() {
        return !destroyed && !activity.isFinishing() && auth.getCurrentUser() != null
                && actorUid.equals(auth.getCurrentUser().getUid());
    }
    private boolean teacher() { return sameAccount() && "teacher".equals(role) && AccountPolicy.teacher(actorUid); }
    private boolean localPage() {
        String url = webView.getUrl();
        return "teacher".equals(role) ? UpdateManager.isLocalPage(url == null ? null : Uri.parse(url))
                : studentPageUrl.equals(url);
    }
    String studentPageUrl() { return studentPageUrl; }

    @JavascriptInterface public String getIdentity() {
        try {
            if (!sameAccount()) return "null";
            if ("teacher".equals(role) && !AccountPolicy.teacher(actorUid)) return "null";
            if ("preview".equals(role) && !AccountPolicy.teacher(actorUid)) return "null";
            if ("student".equals(role) && AccountPolicy.teacher(actorUid)) return "null";
            JSONObject value = new JSONObject().put("uid", actorUid).put("role", role);
            int color = activity.getSharedPreferences("student_theme_" + actorUid, Context.MODE_PRIVATE)
                    .getInt("accent", 0xff8b5cf6);
            value.put("color", String.format("#%06x", color & 0xffffff));
            if ("preview".equals(role)) {
                JSONObject area = validateArea(previewPayload, null);
                value.put("profile", area.getJSONObject("profile")).put("studentId", area.getString("studentId"));
            } else {
                FirebaseUser user = auth.getCurrentUser();
                value.put("profile", new JSONObject().put("email", user == null ? "" : user.getEmail()));
            }
            return value.toString();
        } catch (Exception e) { return "null"; }
    }

    @JavascriptInterface public void request(String requestId, String action, String json) {
        if (requestId == null || !requestId.matches("ap_[0-9]{1,12}")) return;
        activity.runOnUiThread(() -> {
            final int token = generation;
            try {
                if (!sameAccount() || !localPage()) throw new SecurityException("Entre novamente no aplicativo.");
                if (json == null || json.length() > 900000) throw new IllegalArgumentException("Conteúdo acima do limite de envio.");
                JSONObject data = new JSONObject(json);
                switch (action) {
                    case "contacts": requireTeacher(); contacts(requestId, token); break;
                    case "approve": requireTeacher(); approve(requestId, token, data); break;
                    case "publish": requireTeacher(); publish(requestId, token, data); break;
                    case "preview": requireTeacher(); preview(requestId, token, data); break;
                    case "subscribe": subscribe(requestId, token); break;
                    case "closePreview":
                        if (!"preview".equals(role) || !AccountPolicy.teacher(actorUid)) throw new SecurityException("Ação indisponível.");
                        activity.finish(); break;
                    case "logout":
                        if ("preview".equals(role)) { activity.finish(); break; }
                        stopListeners(); auth.signOut();
                        if (!activity.isFinishing()) {
                            activity.startActivity(new Intent(activity, LoginActivity.class)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                            activity.finish();
                        } break;
                    case "copyRules": requireTeacher(); copyRules(); reply(requestId, token, new JSONObject().put("copied", true)); break;
                    case "video": openVideo(data); reply(requestId, token, new JSONObject()); break;
                    default: throw new IllegalArgumentException("Ação indisponível.");
                }
            } catch (Exception e) { error(requestId, token, e); }
        });
    }

    private void requireTeacher() { if (!teacher()) throw new SecurityException("Esta ação é do professor."); }
    private void contacts(String id, int token) {
        store.collection("usuarios").whereEqualTo("professorId", AccountPolicy.PROFESSOR_UID).get(Source.SERVER)
                .addOnSuccessListener(result -> {
                    try {
                        requireTeacher(); JSONArray rows = new JSONArray();
                        for (DocumentSnapshot doc : result.getDocuments()) {
                            if (!"aluno".equals(doc.getString("perfil"))) continue;
                            rows.put(new JSONObject(doc.getData()).put("uid", doc.getId()));
                        }
                        reply(id, token, rows);
                    } catch (Exception e) { error(id, token, e); }
                }).addOnFailureListener(e -> error(id, token, e));
    }
    private void approve(String id, int token, JSONObject data) throws Exception {
        String uid = data.getString("uid"); if (!AccountPolicy.uid(uid) || AccountPolicy.teacher(uid)) throw new IllegalArgumentException("Conta de aluno inválida.");
        store.collection("usuarios").document(uid).get(Source.SERVER).addOnSuccessListener(doc -> {
            try {
                requireTeacher();
                if (!doc.exists() || !"aluno".equals(doc.getString("perfil")) || !AccountPolicy.PROFESSOR_UID.equals(doc.getString("professorId")))
                    throw new SecurityException("Esta solicitação não pertence a este professor.");
                Map<String, Object> update = new HashMap<>();
                update.put("ativo", true); update.put("aprovadoEm", FieldValue.serverTimestamp());
                doc.getReference().update(update).addOnSuccessListener(v -> reply(id, token, new JSONObject()))
                        .addOnFailureListener(e -> error(id, token, e));
            } catch (Exception e) { error(id, token, e); }
        }).addOnFailureListener(e -> error(id, token, e));
    }
    private void publish(String id, int token, JSONObject data) throws Exception {
        String uid = data.getString("uid"), payload = data.getString("payload");
        if (!AccountPolicy.uid(uid) || AccountPolicy.teacher(uid)) throw new IllegalArgumentException("Conta de aluno inválida.");
        JSONObject area = validateArea(payload, uid);
        // Recheck the target on the server; the retained JS outbox retries if it is offline.
        // Firestore rules enforce the same ownership independently of this native check.
        Map<String, Object> document = new HashMap<>();
        document.put("version", 2); document.put("professorId", AccountPolicy.PROFESSOR_UID);
        document.put("studentUid", uid); document.put("studentId", area.getString("studentId"));
        document.put("payload", payload); document.put("updatedAt", FieldValue.serverTimestamp());
        store.collection("usuarios").document(uid).get(Source.SERVER).addOnSuccessListener(profile -> {
            try {
                if (!live(token)) return;
                requireTeacher();
                if (!profile.exists() || !AccountPolicy.student(profile.getString("perfil"), profile.getBoolean("ativo"), profile.getString("professorId")))
                    throw new SecurityException("A conta do aluno precisa estar aprovada e vinculada a este professor.");
                profile.getReference().collection("treinos").document("atual").set(document)
                        .addOnSuccessListener(v -> reply(id, token, new JSONObject()))
                        .addOnFailureListener(e -> error(id, token, e));
            } catch (Exception e) { error(id, token, e); }
        }).addOnFailureListener(e -> error(id, token, e));
    }
    private void preview(String id, int token, JSONObject data) throws Exception {
        String payload = data.getString("payload"); validateArea(payload, null);
        String key = UUID.randomUUID().toString(); File file = new File(activity.getCacheDir(), "student-preview-" + key + ".json");
        Files.write(file.toPath(), payload.getBytes(StandardCharsets.UTF_8));
        activity.startActivity(new Intent(activity, StudentActivity.class).putExtra("previewKey", key));
        reply(id, token, new JSONObject());
    }

    private void subscribe(String id, int token) throws Exception {
        stopListeners();
        if ("preview".equals(role) && AccountPolicy.teacher(actorUid)) {
            JSONObject area = validateArea(previewPayload, null);
            emit(token, new JSONObject().put("kind", "workout").put("payload", previewPayload)
                    .put("studentId", area.getString("studentId")).put("fromCache", false));
            reply(id, token, new JSONObject()); return;
        }
        if (!"student".equals(role) || AccountPolicy.teacher(actorUid)) throw new SecurityException("Ação indisponível.");
        profileListener = store.collection("usuarios").document(actorUid).addSnapshotListener((doc, problem) -> {
            if (!live(token)) return;
        if (problem != null) { stopWorkout(); emit(token, object("kind", "blocked", "message", "Não foi possível validar seu acesso. Confira a conexão e entre novamente.")); return; }
            if (doc == null || !doc.exists() || !AccountPolicy.student(doc.getString("perfil"), doc.getBoolean("ativo"), doc.getString("professorId"))) {
                stopWorkout();
                emit(token, object("kind", "blocked", "message", "Seu acesso precisa ser aprovado pelo professor.")); return;
            }
            JSONObject profile = object("name", doc.getString("nome"), "email", doc.getString("email"),
                    "phone", doc.getString("whatsapp"), "birth", doc.getString("nascimento"), "gender", doc.getString("genero"));
            emit(token, object("kind", "profile", "profile", profile));
            if (workoutListener == null) listenWorkout(token);
        });
        reply(id, token, new JSONObject());
    }
    private void listenWorkout(int token) {
        workoutListener = store.collection("usuarios").document(actorUid).collection("treinos").document("atual")
                .addSnapshotListener(MetadataChanges.INCLUDE, (doc, problem) -> {
                    if (!live(token)) return;
                    if (problem != null) { emitError(token, problem); return; }
                    try {
                        JSONObject result = new JSONObject().put("kind", "workout")
                                .put("fromCache", doc != null && doc.getMetadata().isFromCache());
                        if (doc != null && doc.exists()) {
                            if (!Long.valueOf(2).equals(doc.getLong("version")) || !actorUid.equals(doc.getString("studentUid"))
                                    || !AccountPolicy.PROFESSOR_UID.equals(doc.getString("professorId"))) throw new SecurityException("Esta ficha não pertence à sua conta.");
                            String payload = doc.getString("payload"); JSONObject area = validateArea(payload, actorUid);
                            if (!area.getString("studentId").equals(doc.getString("studentId"))) throw new SecurityException("O vínculo da ficha é inválido.");
                            result.put("payload", payload).put("studentId", area.getString("studentId"));
                        } else { result.put("payload", JSONObject.NULL).put("studentId", ""); }
                        emit(token, result);
                    } catch (Exception e) { emit(token, object("kind", "blocked", "message", e.getMessage())); }
                });
    }
    static JSONObject validateArea(String payload, String uid) throws Exception {
        if (payload == null || payload.getBytes(StandardCharsets.UTF_8).length > 650000) throw new IllegalArgumentException("A ficha ultrapassa o limite de envio.");
        JSONObject area = new JSONObject(payload);
        if (area.getInt("version") != 2 || !AccountPolicy.PROFESSOR_UID.equals(area.getString("professorId"))
                || area.getString("studentId").isEmpty() || !(area.get("enabled") instanceof Boolean)
                || (uid != null && !uid.equals(area.getString("studentUid")))) throw new SecurityException("Vínculo de treino inválido.");
        area.getJSONObject("profile").getString("name");
        JSONArray plans = area.getJSONArray("plans"); int exerciseCount = 0;
        for (int p = 0; p < plans.length(); p++) {
            JSONArray days = plans.getJSONObject(p).getJSONArray("days");
            for (int d = 0; d < days.length(); d++) {
                JSONArray exercises = days.getJSONObject(d).getJSONArray("exercises");
                for (int e = 0; e < exercises.length(); e++) {
                    JSONObject ex = exercises.getJSONObject(e); JSONArray rows = ex.getJSONArray("rows");
                    if (++exerciseCount > 2000 || rows.length() < 1 || rows.length() > 100) throw new IllegalArgumentException("Prescrição inválida.");
                    for (int n = 0; n < rows.length(); n++) {
                        JSONObject row = rows.getJSONObject(n); row.getString("reps");
                        if (!row.isNull("load") && (row.getDouble("load") < 0 || row.getDouble("load") > 1000)) throw new IllegalArgumentException("Carga inválida.");
                    }
                }
            }
        }
        return area;
    }
    private void openVideo(JSONObject data) throws Exception {
        String url = data.getString("url"); Uri uri = Uri.parse(url);
        if (!"https".equals(uri.getScheme()) || uri.getUserInfo() != null) throw new IllegalArgumentException("Endereço do vídeo inválido.");
        String host = uri.getHost(), video = "";
        if ("youtu.be".equals(host)) video = uri.getLastPathSegment();
        else if ("youtube.com".equals(host) || "www.youtube.com".equals(host) || "www.youtube-nocookie.com".equals(host)) {
            video = uri.getQueryParameter("v");
            if (video == null && uri.getPathSegments().size() >= 2) video = uri.getPathSegments().get(1);
        }
        if (video != null && video.matches("[A-Za-z0-9_-]{11}")) YouTubeVideoActivity.open(activity, video, 0, data.optString("title", "Vídeo do exercício"));
        else activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }
    private void copyRules() throws Exception {
        String rules;
        try (java.io.InputStream input = activity.getAssets().open("treinos.rules.txt")) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();byte[] bytes = new byte[4096];int n;
            while ((n = input.read(bytes)) != -1) out.write(bytes, 0, n);
            rules = new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
        ((ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Regras dos treinos", rules));
    }
    private boolean live(int token) { return token == generation && sameAccount() && localPage(); }
    private void reply(String id, int token, Object data) {
        if (!live(token)) return;
        webView.evaluateJavascript("window.APnativeResult&&APnativeResult(" + JSONObject.quote(id) + "," + object("ok", true, "data", data) + ");", null);
    }
    private void error(String id, int token, Exception problem) {
        if (!live(token)) return;
        webView.evaluateJavascript("window.APnativeResult&&APnativeResult(" + JSONObject.quote(id) + "," + object("ok", false, "code", code(problem), "message", problem.getMessage()) + ");", null);
    }
    private void emit(int token, JSONObject value) { if (live(token)) webView.evaluateJavascript("window.APnativeStudent&&APnativeStudent(" + value + ");", null); }
    private void emitError(int token, Exception problem) {
        String message = "permission-denied".equals(code(problem)) ? "O Firebase não autorizou o acesso a esta ficha. Avise o professor." : "Não foi possível atualizar o treino. Confira a conexão.";
        emit(token, object("kind", "permission-denied".equals(code(problem)) ? "blocked" : "error", "message", message));
    }
    private static String code(Exception e) {
        return e instanceof FirebaseFirestoreException ? ((FirebaseFirestoreException) e).getCode().name().toLowerCase(java.util.Locale.ROOT).replace('_', '-') : "unknown";
    }
    private static JSONObject object(Object... pairs) {
        JSONObject result = new JSONObject();
        try { for (int i = 0; i < pairs.length; i += 2) result.put((String) pairs[i], pairs[i + 1] == null ? JSONObject.NULL : pairs[i + 1]); } catch (Exception ignored) { }
        return result;
    }
    private void stopWorkout() { if (workoutListener != null) workoutListener.remove(); workoutListener = null; }
    private void stopListeners() { if (profileListener != null) profileListener.remove(); profileListener = null; stopWorkout(); }
    void pageStarted() { generation++; stopListeners(); }
    void destroy() { destroyed = true; generation++; stopListeners(); }
}
