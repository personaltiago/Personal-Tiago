package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;

/** Tela inicial de desenvolvimento: não mostra dados de treino até existir sincronização autorizada. */
public class StudentActivity extends Activity {
    private final int[] palette = {0xff8b5cf6,0xff2563eb,0xff0d9488,0xffe11d48,0xfff59e0b};
    private LinearLayout root;
    private TextView heading;
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if(FirebaseAuth.getInstance().getCurrentUser()==null) {startActivity(new Intent(this,LoginActivity.class));finish();return;}
        prefs=getSharedPreferences("student_theme_"+FirebaseAuth.getInstance().getUid(),MODE_PRIVATE);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32,50,32,32);root.setGravity(Gravity.CENTER_VERTICAL);
        root.setBackgroundColor(0xff11121a);
        heading=new TextView(this);heading.setText("AGENDA PERSONAL\nÁrea do aluno");
        heading.setTextSize(27);root.addView(heading);
        TextView note=new TextView(this);
        note.setText("Acesso autenticado. Os treinos e gráficos aparecerão após a integração da publicação de fichas no aplicativo do professor.\n\nEscolha sua cor:");
        note.setTextColor(Color.WHITE);note.setTextSize(16);root.addView(note);
        for(int i=0;i<palette.length;i++) {
            final int selected=palette[i];
            Button b=new Button(this);b.setText(new String[]{"Roxo","Azul","Verde","Rosa","Âmbar"}[i]);
            b.setOnClickListener(v->{prefs.edit().putInt("accent",selected).apply();heading.setTextColor(selected);});
            root.addView(b);
        }
        Button logout=new Button(this);logout.setText("Sair da conta");
        logout.setOnClickListener(v->{FirebaseAuth.getInstance().signOut();startActivity(new Intent(this,LoginActivity.class));finish();});
        root.addView(logout);setContentView(root);
        heading.setTextColor(prefs.getInt("accent",palette[0]));
    }
}
