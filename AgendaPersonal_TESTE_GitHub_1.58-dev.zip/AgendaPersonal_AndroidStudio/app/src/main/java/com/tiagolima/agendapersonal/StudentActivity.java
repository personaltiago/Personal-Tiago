package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.io.ByteArrayInputStream;

/** The authenticated student's own UI, or a read-only teacher preview of one local profile. */
public class StudentActivity extends Activity {
    private static final int FILE_REQUEST = 2102;
    private WebView webView;
    private NativeAccountBridge accounts;
    private WebBackController backController;
    private ValueCallback<Uri[]> pendingFile;
    private FirebaseAuth.AuthStateListener authListener;
    private String sessionUid;
    private boolean preview;
    private File previewFile;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) { login(); return; }
        sessionUid = user.getUid(); String key = getIntent().getStringExtra("previewKey"), payload = null;
        preview = key != null;
        try {
            if (preview) {
                if (!AccountPolicy.teacher(sessionUid) || !key.matches("[a-f0-9-]{36}")) throw new SecurityException("Prévia inválida.");
                File file = new File(getCacheDir(), "student-preview-" + key + ".json"); previewFile = file;
                if (file.length() > 650000) throw new IllegalArgumentException("A ficha ultrapassa o limite de envio.");
                payload = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
                NativeAccountBridge.validateArea(payload, null);
            } else if (AccountPolicy.teacher(sessionUid)) { finish(); return; }
        } catch (Exception e) { Toast.makeText(this, "Não foi possível abrir a prévia deste aluno.", Toast.LENGTH_LONG).show(); finish(); return; }

        webView = new WebView(this); FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0b0a0f")); root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root); AppWindowLayout.apply(this, root);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false); settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false); settings.setAllowUniversalAccessFromFileURLs(false);
        accounts = new NativeAccountBridge(this, webView, preview ? "preview" : "student", payload);
        // A local HTTPS origin per authenticated UID keeps student storage separate
        // from the professor's file-origin database and from other student accounts.
        final String pageUrl = accounts.studentPageUrl(), pageHost = Uri.parse(pageUrl).getHost();
        webView.addJavascriptInterface(accounts, "AgendaAccount");
        backController = new WebBackController(this, webView, () -> false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !pageHost.equals(uri.getHost())) return null;
                String assetPath = uri.getPath();
                String name = assetPath == null || assetPath.isEmpty() ? "" : assetPath.substring(1);
                if (!("aluno.html".equals(name) || "icon.png".equals(name) || name.matches("(account-bridge|student-(model|storage|ui|reps|native))\\.js")))
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                try {
                    return new WebResourceResponse(name.endsWith(".js") ? "application/javascript" : name.endsWith(".png") ? "image/png" : "text/html", "UTF-8", getAssets().open(name));
                } catch (Exception e) { return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0])); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (request.isForMainFrame() && pageUrl.equals(uri.toString())) return false;
                if (request.isForMainFrame() && ("https".equals(uri.getScheme()) || "mailto".equals(uri.getScheme()) || "tel".equals(uri.getScheme()))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                }
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) { accounts.pageStarted(); backController.pageStarted(); }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (preview) { callback.onReceiveValue(null); return true; }
                if (pendingFile != null) pendingFile.onReceiveValue(null); pendingFile = callback;
                try { startActivityForResult(params.createIntent(), FILE_REQUEST); return true; }
                catch (Exception e) { pendingFile.onReceiveValue(null); pendingFile = null; return false; }
            }
        });
        authListener = auth -> {
            FirebaseUser active = auth.getCurrentUser();
            if (active == null || !sessionUid.equals(active.getUid())) login();
        };
        FirebaseAuth.getInstance().addAuthStateListener(authListener);
        webView.loadUrl(pageUrl);
    }
    private void login() {
        if (isFinishing()) return;
        if (accounts != null) accounts.destroy();
        startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK)); finish();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQUEST) {
            if (pendingFile != null) pendingFile.onReceiveValue(resultCode == RESULT_OK ? WebChromeClient.FileChooserParams.parseResult(resultCode, data) : null);
            pendingFile = null; return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    @Override public void onBackPressed() { if (backController != null) backController.handleBack(); }
    @Override protected void onDestroy() {
        if (authListener != null) FirebaseAuth.getInstance().removeAuthStateListener(authListener);
        if (pendingFile != null) pendingFile.onReceiveValue(null);
        if (accounts != null) accounts.destroy(); if (backController != null) backController.destroy();
        if (isFinishing() && previewFile != null) previewFile.delete();
        if (webView != null) { webView.removeJavascriptInterface("AgendaAccount"); webView.destroy(); }
        super.onDestroy();
    }
}
