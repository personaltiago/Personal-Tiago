package com.tiagolima.agendapersonal;

/** Shared native role checks: WebView content cannot select a Firebase account. */
final class AccountPolicy {
    static final String PROFESSOR_UID = "R2EmnDVcvMWt7TjPxOP6DjW1VOn1";
    static boolean teacher(String uid) { return PROFESSOR_UID.equals(uid); }
    static boolean student(String perfil, Boolean active, String professor) {
        return "aluno".equals(perfil) && Boolean.TRUE.equals(active)
                && PROFESSOR_UID.equals(professor);
    }
    static boolean uid(String uid) { return uid != null && uid.matches("[A-Za-z0-9_-]{1,128}"); }
}
