package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.text.InputType;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends Activity {
    private static final String PROFESSOR_UID = "R2EmnDVcvMWt7TjPxOP6DjW1VOn1";
    private FirebaseAuth auth;
    private TextView status;
    private Button enter;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        auth = FirebaseAuth.getInstance();
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        layout.setPadding(42, 40, 42, 40);
        layout.setBackgroundColor(Color.rgb(14, 12, 20));
        TextView title = new TextView(this);
        title.setText("AGENDA PERSONAL\nAcesso seguro");
        title.setTextColor(Color.WHITE); title.setTextSize(26);
        layout.addView(title);
        EditText email = new EditText(this);
        email.setHint("E-mail"); email.setSingleLine(true);
        email.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        email.setTextColor(Color.WHITE); email.setHintTextColor(0xffaaaaaa);
        layout.addView(email);
        EditText password = new EditText(this);
        password.setHint("Senha"); password.setSingleLine(true);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setTextColor(Color.WHITE); password.setHintTextColor(0xffaaaaaa);
        layout.addView(password);
        enter = new Button(this); enter.setText("Entrar"); layout.addView(enter);
        status = new TextView(this); status.setTextColor(0xffe4c6ff); layout.addView(status);
        setContentView(layout);
        enter.setOnClickListener(v -> {
            String e=email.getText().toString().trim(), pw=password.getText().toString();
            if (e.isEmpty() || pw.isEmpty()) {status.setText("Informe e-mail e senha.");return;}
            enter.setEnabled(false);status.setText("Autenticando...");
            auth.signInWithEmailAndPassword(e,pw).addOnCompleteListener(task -> {
                if (!task.isSuccessful()) { enter.setEnabled(true); status.setText("Não foi possível entrar. Confira as credenciais e a conexão."); return; }
                route();
            });
        });
        if(auth.getCurrentUser()!=null) route();
    }
    private void route() {
        if(auth.getCurrentUser()==null) return;
        String uid=auth.getCurrentUser().getUid();
        if(PROFESSOR_UID.equals(uid)) { startActivity(new Intent(this,MainActivity.class)); finish(); return; }
        FirebaseFirestore.getInstance().collection("usuarios").document(uid).get()
            .addOnCompleteListener(task -> {
                if(task.isSuccessful() && task.getResult()!=null && task.getResult().exists()
                    && "aluno".equals(task.getResult().getString("perfil"))
                    && Boolean.TRUE.equals(task.getResult().getBoolean("ativo"))) {
                    startActivity(new Intent(this,StudentActivity.class)); finish();
                } else {
                    auth.signOut(); enter.setEnabled(true);
                    status.setText("Conta sem perfil de aluno ativo. Solicite acesso ao professor.");
                }
            });
    }
}
