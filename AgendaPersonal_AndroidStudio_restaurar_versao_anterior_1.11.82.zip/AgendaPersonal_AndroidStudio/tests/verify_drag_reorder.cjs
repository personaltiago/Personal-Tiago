/* CLI checks for staging/commit semantics. Real pointer/touch checks: verify_reordering.cjs. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const script=source.match(/<script id="agenda-drag-reorder-js">([\s\S]*?)<\/script>/)[1];
assert.match(source.match(/<style id="agenda-drag-reorder-css">([\s\S]*?)<\/style>/)[1],/touch-action:none/);
const copy=x=>JSON.parse(JSON.stringify(x));
let plan={id:'p',studentId:'s',name:'Ficha',organization:'sequence',days:[
 {id:'a',name:'Braços',exercises:[{id:'a1',name:'Rosca',sets:'3',reps:'12',load:'20 kg',video:'https://youtu.be/example',technique:{name:'Rest-pause'}},
  {id:'a2',name:'Tríceps'},{id:'a3',name:'Martelo'},{id:'a4',name:'Elevação'}],bisets:[{id:'pair',exerciseIds:['a1','a3'],rounds:3,restSeconds:60}]},
 {id:'b',name:'Pernas',exercises:[]},{id:'c',name:'Costas',exercises:[]}
]},writes=0,fail=false,running=false,list=null;
const sheet={scrollTop:0},status={textContent:''},listeners=new Map();
function button(row){return {setAttribute(){},focus(){},closest(selector){return selector==='.workout-order-handle'?this:selector==='.workout-order-row'?row:null;}};}
class Row{
 constructor(key){this.dataset={orderKey:key};this.position={textContent:''};this.handle=button(this);}
 querySelector(selector){return selector==='.workout-order-position'?this.position:this.handle;}
 scrollIntoView(){}
}
class List{
 constructor(markup){this.children=[...markup.matchAll(/<li class="workout-order-row" data-order-key="([^"]+)"/g)].map(m=>new Row(m[1]));this.events={};}
 addEventListener(name,fn){this.events[name]=fn;}
 append(row){const i=this.children.indexOf(row);if(i>=0)this.children.splice(i,1);this.children.push(row);}
 press(key,id){this.events.keydown({key,target:this.children.find(r=>r.dataset.orderKey===id).handle,preventDefault(){}});}
}
function root(){return {set innerHTML(value){this.html=value;list=value.includes('id="workoutOrderList"')?new List(value):null;},get innerHTML(){return this.html||'';}};}
const roots={workoutStudentContent:root(),workoutDayContent:root()};
const document={
 getElementById(id){if(id==='workoutOrderList')return list;if(id==='workoutOrderStatus')return status;if(roots[id])return roots[id];if(id.endsWith('Dialog'))return {querySelector(){return sheet;}};},
 querySelector(selector){return selector.includes('.workout-order-actions button')?button(null):null;},
 querySelectorAll(selector){return selector==='#workoutOrderList > .workout-order-row'?list?.children||[]:[];},
 addEventListener(name,fn){listeners.set(name,fn);}
};
const context={document,console,workoutStudentId:'s',workoutPlanId:'p',workoutDayId:'a',workoutDaysOrdering:false,workoutExercisesOrdering:false,
 dialogStack:[{id:'workoutStudentDialog'}],toast(){},hesc:String,
 currentWorkoutPlan(){return plan;},currentWorkoutDay(){return plan.days.find(d=>d.id===context.workoutDayId);},
 studentById(){return {name:'Aluno'};},workoutDayLabel(){return 'Treino em sequência';},workoutPlanArchived(){return false;},workoutRunning(){return running;},
 workoutBisetGroups(day){return day.bisets||[];},
 renderWorkoutStudent(){roots.workoutStudentContent.innerHTML='normal';},renderWorkoutDay(){roots.workoutDayContent.innerHTML='normal';},
 moveWorkoutDay(){},moveWorkoutExercise(){},closeDialog(){context.dialogStack=[];},selectWorkoutPlan(){},openWorkoutDay(){},openWorkoutStudent(){},
 startWorkoutSession(){running=true;},
 replaceWorkoutPlan(next){if(fail)return false;plan=next;writes++;context.renderWorkoutStudent();context.renderWorkoutDay();return true;},
};context.window=context;vm.createContext(context);vm.runInContext(script,context);
const keys=()=>list.children.map(row=>row.dataset.orderKey),ids=()=>copy(plan.days.map(d=>d.id)),exids=()=>copy(context.currentWorkoutDay().exercises.map(e=>e.id));
const initial=copy(plan);
context.toggleWorkoutDayOrdering();assert.deepEqual(keys(),['day:a','day:b','day:c']);assert.equal(writes,0);
list.press('End','day:a');list.press('Home','day:c');assert.deepEqual(keys(),['day:c','day:b','day:a']);assert.deepEqual(copy(plan),initial);assert.equal(writes,0);
context.cancelWorkoutOrder();assert.deepEqual(ids(),['a','b','c']);assert.equal(list,null);
context.toggleWorkoutDayOrdering();list.press('End','day:a');context.finishWorkoutOrder();assert.deepEqual(ids(),['b','c','a']);assert.equal(writes,1);assert.equal(list,null);
context.toggleWorkoutDayOrdering();list.press('Home','day:a');fail=true;context.finishWorkoutOrder();assert.equal(writes,1);assert.deepEqual(ids(),['b','c','a']);assert.deepEqual(keys(),['day:a','day:b','day:c']);fail=false;context.finishWorkoutOrder();assert.deepEqual(ids(),['a','b','c']);assert.equal(writes,2);
context.dialogStack=[{id:'workoutStudentDialog'},{id:'workoutDayDialog'}];context.toggleWorkoutExerciseOrdering();assert.deepEqual(keys(),['biset:pair','exercise:a2','exercise:a4']);list.press('End','biset:pair');assert.deepEqual(exids(),['a1','a2','a3','a4']);assert.equal(writes,2);context.finishWorkoutOrder();assert.deepEqual(exids(),['a2','a4','a1','a3']);assert.equal(writes,3);
assert.deepEqual(copy(plan.days[0].bisets),initial.days[0].bisets);assert.deepEqual(copy(plan.days[0].exercises).toSorted((a,b)=>a.id.localeCompare(b.id)),initial.days[0].exercises.toSorted((a,b)=>a.id.localeCompare(b.id)));
context.toggleWorkoutExerciseOrdering();list.press('Home','biset:pair');context.closeDialog('workoutStudentDialog');assert.deepEqual(exids(),['a2','a4','a1','a3']);assert.equal(context.dialogStack.length,2);assert.equal(list,null);context.closeDialog('workoutStudentDialog');assert.equal(context.dialogStack.length,0);
context.toggleWorkoutExerciseOrdering();list.press('Home','biset:pair');context.startWorkoutSession();assert.equal(list,null);assert.equal(writes,3);assert.deepEqual(exids(),['a2','a4','a1','a3']);context.toggleWorkoutExerciseOrdering();context.toggleWorkoutDayOrdering();assert.equal(list,null);assert.equal(writes,3);
console.log(JSON.stringify({passed:true,checks:['treinos e exercícios','prévia sem gravação','finalização única','cancelamento','falha e nova tentativa','bi-set indivisível','prescrição e vídeo intactos','retorno em etapas','bloqueio durante execução'],writes},null,2));
