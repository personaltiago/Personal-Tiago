package com.tiagolima.agendapersonal;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;


public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#09080C"));
        getWindow().setNavigationBarColor(Color.parseColor("#09080C"));

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        AlarmReceiver.createChannel(nm);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(this), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.evaluateJavascript("if (typeof syncNativeAlarms === 'function') syncNativeAlarms();", null);
        }
    }

    private static boolean needsExactAlarmPermission(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && !am.canScheduleExactAlarms();
    }

    public static class Bridge {
        private final Activity activity;
        private boolean exactAlarmPromptShown = false;

        Bridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface
        public boolean syncLessonAlarms(String agendaJson) {
            try {
                JSONObject agenda = new JSONObject(agendaJson);
                if (agenda.optInt("schema", 0) != 3) return false;
                AlarmScheduler.synchronize(activity, agenda);
                if (!AlarmStore.plans(activity).isEmpty()) {
                    activity.runOnUiThread(this::requestExactAlarmAccessIfNeeded);
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        private void requestExactAlarmAccessIfNeeded() {
            if (exactAlarmPromptShown || !needsExactAlarmPermission(activity)) return;
            exactAlarmPromptShown = true;
            try {
                Toast.makeText(activity, "Para avisos no minuto exato, autorize Alarmes e lembretes.", Toast.LENGTH_LONG).show();
                Intent settings = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(settings);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void openMap(String query) {
            activity.runOnUiThread(() -> {
                String location = query == null ? "" : query.trim();
                if (location.isEmpty()) {
                    Toast.makeText(activity, "Informe o endereço ou o link do Google Maps.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String directLink = MapLinks.directGoogleMapsLink(location);
                try {
                    Uri uri = Uri.parse(directLink != null
                            ? directLink : "geo:0,0?q=" + Uri.encode(location));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    activity.startActivity(intent);
                } catch (Exception e) {
                    try {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse(directLink != null ? directLink
                                        : "https://www.google.com/maps/search/?api=1&query=" + Uri.encode(location))));
                    } catch (Exception ignored) {
                        Toast.makeText(activity, "Não foi possível abrir o mapa.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void openWhatsApp(String phone, String name) {
            activity.runOnUiThread(() -> {
                try {
                    String digits = normalizeBrazilPhone(phone);
                    Uri uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode("Olá, " + name + "."));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    activity.startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(activity, "Não foi possível abrir o WhatsApp.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        private String normalizeBrazilPhone(String phone) {
            String digits = phone == null ? "" : phone.replaceAll("\\D", "");
            if ((digits.length() == 10 || digits.length() == 11) && !digits.startsWith("55")) digits = "55" + digits;
            return digits;
        }
    }
}
