package com.tiagolima.agendapersonal;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.ZoneId;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** The agenda is the single source of truth for alarms owned by this app. */
final class AlarmScheduler {
    static final int NOTIFICATION_ID = 1;
    private AlarmScheduler() {}

    static synchronized void synchronize(Context context, JSONObject agenda) throws Exception {
        JSONArray lessons = agenda.getJSONArray("lessons");
        JSONObject statuses = agenda.getJSONObject("occurrenceStatus");
        long now = System.currentTimeMillis();
        Map<String, JSONObject> desired = new LinkedHashMap<>();
        Set<String> lessonIds = new HashSet<>();
        for (int i = 0; i < lessons.length(); i++) {
            JSONObject lesson = lessons.getJSONObject(i);
            String lessonId = lesson.getString("id");
            if (lessonId.isEmpty() || !lessonIds.add(lessonId)) {
                throw new IllegalArgumentException("Identificador de aula inválido");
            }
            Set<String> blocked = blockedDates(statuses, lessonId);
            Set<String> delivered = AlarmStore.deliveredDates(context, lessonId);
            if ("weekly".equals(lesson.optString("repeat", "none"))) {
                JSONArray days = lesson.getJSONArray("repeatDays");
                if (days.length() == 0) throw new IllegalArgumentException("Dias da aula ausentes");
                for (int d = 0; d < days.length(); d++) {
                    addPlan(context, desired, lesson, days.getInt(d), blocked, delivered, now);
                }
            } else {
                addPlan(context, desired, lesson, null, blocked, delivered, now);
            }
        }
        // Persist cancellations before touching PendingIntents, including for reboot recovery.
        if (!AlarmStore.saveSnapshot(context, agenda)) {
            throw new IllegalStateException("Não foi possível salvar os avisos");
        }
        cancelLegacyAlarms(context);
        for (JSONObject old : AlarmStore.plans(context)) {
            String key = old.getString("alarmKey");
            JSONObject replacement = desired.get(key);
            if (replacement == null
                    || old.getLong("triggerAtMillis") != replacement.getLong("triggerAtMillis")
                    || !old.getString("classDate").equals(replacement.getString("classDate"))) {
                cancelPlan(context, key);
            }
        }
        NotificationManager notifications = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Iterator<String> keys = statuses.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (isBlocked(statuses.optString(key)) && notifications != null) {
                notifications.cancel(key, NOTIFICATION_ID);
            }
        }
        for (JSONObject plan : desired.values()) schedule(context, plan);
    }

    private static void addPlan(Context context, Map<String, JSONObject> desired, JSONObject lesson,
                                Integer weekday, Set<String> blocked, Set<String> delivered,
                                long now) throws Exception {
        AlarmTimes.Occurrence next = AlarmTimes.next(
                lesson.getString("date"), lesson.getString("time"), lesson.optInt("lead", 15),
                weekday, blocked, delivered, now, ZoneId.systemDefault());
        if (next == null) return;
        String key = lesson.getString("id") + "|" + (weekday == null ? "once" : "week-" + weekday);
        JSONObject plan = new JSONObject();
        plan.put("alarmKey", key);
        plan.put("lessonId", lesson.getString("id"));
        plan.put("classDate", next.date);
        plan.put("classAtMillis", next.classAtMillis);
        plan.put("triggerAtMillis", next.triggerAtMillis);
        plan.put("student", lesson.optString("student", "Aluno"));
        plan.put("location", lesson.optString("location", ""));
        plan.put("phone", lesson.optString("phone", ""));
        plan.put("lessonTime", lesson.getString("time"));
        plan.put("leadMinutes", lesson.optInt("lead", 15));
        plan.put("weekly", weekday != null);
        JSONObject old = AlarmStore.plan(context, key);
        // Do not postpone an already scheduled late warning on each agenda save.
        if (old != null && next.date.equals(old.optString("classDate"))
                && next.classAtMillis == old.optLong("classAtMillis")
                && plan.getInt("leadMinutes") == old.optInt("leadMinutes")
                && old.optLong("triggerAtMillis") > now) {
            plan.put("triggerAtMillis", old.getLong("triggerAtMillis"));
        }
        desired.put(key, plan);
    }

    private static Set<String> blockedDates(JSONObject statuses, String lessonId) {
        Set<String> result = new HashSet<>();
        String prefix = lessonId + "|";
        Iterator<String> keys = statuses.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (key.startsWith(prefix) && isBlocked(statuses.optString(key))) {
                result.add(key.substring(prefix.length()));
            }
        }
        return result;
    }

    private static boolean isBlocked(String status) {
        return "cancelada".equals(status) || "realizada".equals(status);
    }

    private static Intent alarmIntent(Context context, String key) {
        return new Intent(context, AlarmReceiver.class)
                .setAction("com.tiagolima.agendapersonal.LESSON_ALARM")
                .setData(Uri.parse("agenda-personal://alarm/" + Uri.encode(key)));
    }

    private static void schedule(Context context, JSONObject plan) throws Exception {
        String key = plan.getString("alarmKey");
        long trigger = plan.getLong("triggerAtMillis");
        Intent intent = alarmIntent(context, key)
                .putExtra("alarmKey", key)
                .putExtra("classDate", plan.getString("classDate"))
                .putExtra("triggerAtMillis", trigger);
        PendingIntent pending = PendingIntent.getBroadcast(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) throw new IllegalStateException("Serviço de alarmes indisponível");
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending);
            } else {
                Intent open = new Intent(context, MainActivity.class)
                        .setData(Uri.parse("agenda-personal://show/" + Uri.encode(key)));
                PendingIntent show = PendingIntent.getActivity(context, 0, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                manager.setAlarmClock(new AlarmManager.AlarmClockInfo(trigger, show), pending);
            }
        } catch (SecurityException e) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending);
        }
        AlarmStore.savePlan(context, plan);
    }

    private static void cancelPlan(Context context, String key) {
        PendingIntent pending = PendingIntent.getBroadcast(context, 0, alarmIntent(context, key),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pending != null) {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (manager != null) manager.cancel(pending);
            pending.cancel();
        }
        AlarmStore.removePlan(context, key);
    }

    private static void cancelLegacyAlarms(Context context) {
        for (JSONObject old : AlarmStore.legacyPlans(context)) {
            int code = old.optInt("requestCode", -1);
            if (code < 0) continue;
            PendingIntent pending = PendingIntent.getBroadcast(context, code,
                    new Intent(context, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pending != null) {
                AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                if (manager != null) manager.cancel(pending);
                pending.cancel();
            }
            AlarmStore.removeLegacy(context, code);
        }
    }

    static synchronized JSONObject consume(Context context, Intent intent) {
        try {
            String key = intent.getStringExtra("alarmKey");
            if (key == null) return null; // A stale alarm from an earlier version.
            JSONObject plan = AlarmStore.plan(context, key);
            JSONObject agenda = AlarmStore.snapshot(context);
            if (plan == null || agenda == null) return null;
            if (plan.getLong("triggerAtMillis") != intent.getLongExtra("triggerAtMillis", -1)
                    || !plan.getString("classDate").equals(intent.getStringExtra("classDate"))) return null;
            String lessonId = plan.getString("lessonId"), date = plan.getString("classDate");
            String status = agenda.getJSONObject("occurrenceStatus").optString(lessonId + "|" + date);
            if (isBlocked(status) || AlarmStore.deliveredDates(context, lessonId).contains(date)) return null;
            if (!AlarmStore.markDelivered(context, lessonId, date)) return null;
            cancelPlan(context, key);
            // A scheduling failure for a later lesson must not suppress this valid warning.
            try { synchronize(context, agenda); }
            catch (Exception ignored) {}
            return plan;
        } catch (Exception e) {
            return null;
        }
    }

    static synchronized void restore(Context context) {
        JSONObject agenda = AlarmStore.snapshot(context);
        if (agenda == null) return;
        try { synchronize(context, agenda); }
        catch (Exception ignored) {}
    }
}
