package com.tiagolima.agendapersonal;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "agenda_personal_alarmes_v2";

    @Override
    public void onReceive(Context context, Intent intent) {
        synchronized (AlarmScheduler.class) {
            JSONObject plan = AlarmScheduler.consume(context, intent);
            if (plan == null) return;
            showNotification(context, plan);
        }
    }

    private static void showNotification(Context context, JSONObject plan) {
        String student = plan.optString("student", "Aluno");
        String location = plan.optString("location", "");
        String phone = plan.optString("phone", "");
        String lessonTime = plan.optString("lessonTime", "");
        int leadMinutes = plan.optInt("leadMinutes", 15);
        String occurrenceKey = plan.optString("lessonId") + "|" + plan.optString("classDate");
        int notificationId = occurrenceKey.hashCode() & 0x7fffffff;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel(nm);

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.setData(Uri.parse("agenda-personal://lesson/" + Uri.encode(occurrenceKey)));
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                notificationId,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        PendingIntent whatsAppIntent = buildWhatsAppPendingIntent(context, notificationId, phone, student);
        PendingIntent routeIntent = buildRoutePendingIntent(context, notificationId, location);

        String title = leadMinutes > 0
                ? "Agenda Personal · aula em " + leadMinutes + " min"
                : "Agenda Personal · hora da aula";
        String message = student + (location.isEmpty() ? "" : " — " + location)
                + (lessonTime.isEmpty() ? "" : " · " + lessonTime);

        android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new android.app.Notification.Builder(context, CHANNEL_ID)
                : new android.app.Notification.Builder(context);

        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setCategory(android.app.Notification.CATEGORY_ALARM)
                .setPriority(android.app.Notification.PRIORITY_MAX)
                .setVisibility(android.app.Notification.VISIBILITY_PUBLIC)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);

        if (whatsAppIntent != null) {
            builder.addAction(android.R.drawable.ic_menu_send, "WhatsApp", whatsAppIntent);
        }
        if (routeIntent != null) {
            builder.addAction(android.R.drawable.ic_menu_mylocation, "Rota", routeIntent);
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI);
            builder.setVibrate(new long[]{0, 600, 250, 600, 250, 600});
        }

        if (nm != null) {
            try { nm.notify(occurrenceKey, AlarmScheduler.NOTIFICATION_ID, builder.build()); }
            catch (SecurityException ignored) {}
        }
    }

    private static PendingIntent buildWhatsAppPendingIntent(Context context, int notificationId, String phone, String student) {
        String digits = phone == null ? "" : phone.replaceAll("\\D", "");
        if (digits.isEmpty()) return null;
        if ((digits.length() == 10 || digits.length() == 11) && !digits.startsWith("55")) digits = "55" + digits;
        try {
            Uri uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode("Olá, " + student + "."));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            int code = (String.valueOf(notificationId) + "|wa").hashCode() & 0x7fffffff;
            return PendingIntent.getActivity(context, code, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        } catch (Exception e) {
            return null;
        }
    }

    private static PendingIntent buildRoutePendingIntent(Context context, int notificationId, String location) {
        if (location == null || location.trim().isEmpty()) return null;
        try {
            String directLink = MapLinks.directGoogleMapsLink(location);
            Uri uri = Uri.parse(directLink != null
                    ? directLink : "geo:0,0?q=" + Uri.encode(location.trim()));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            int code = (String.valueOf(notificationId) + "|route").hashCode() & 0x7fffffff;
            return PendingIntent.getActivity(context, code, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        } catch (Exception e) {
            return null;
        }
    }

    public static void createChannel(NotificationManager nm) {
        if (nm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Alarmes das aulas",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("Avisos de aulas da Agenda Personal com WhatsApp e rota");
        channel.enableVibration(true);
        channel.setVibrationPattern(new long[]{0, 600, 250, 600, 250, 600});
        channel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
        Uri sound = Settings.System.DEFAULT_ALARM_ALERT_URI;
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        channel.setSound(sound, audioAttributes);
        nm.createNotificationChannel(channel);
    }
}
