"""Create a standard ZIP smaller than GitHub's browser upload limit.

Keep all source files; the Gradle preBuild task recreates the four HTML pages.
Usage: python3 tools/package_github.py /absolute/path/AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip
"""
from pathlib import Path
import os
import shutil
import sys
import tempfile
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
PAGES = {f'app/src/main/assets/{name}.html' for name in ('index', 'professor', 'avaliacoes', 'cadastro')}
EXCLUDED_DIRS = {'.git', '.gradle', 'node_modules', '__pycache__', 'build', '.idea'}
EXCLUDED_FILES = {'.agenda-assets-build.json', '.agenda-assets-build.json.partial', 'agenda-build.json', 'agenda-build.json.partial', 'local.properties'}
NAME = 'AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip'


def main():
    target = Path(sys.argv[1]).resolve()
    if target.name != NAME or target.is_relative_to(ROOT):
        raise ValueError('Use o nome fixo do ZIP em uma pasta fora do projeto.')
    target.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix='agenda-package-', suffix='.zip', dir=target.parent)
    os.close(handle)
    try:
        with ZipFile(temporary, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
            for directory, folders, files in os.walk(ROOT):
                folders[:] = sorted(f for f in folders if f not in EXCLUDED_DIRS)
                for name in sorted(files):
                    source = Path(directory) / name
                    relative = source.relative_to(ROOT).as_posix()
                    if relative in PAGES or name in EXCLUDED_FILES:
                        continue
                    if source.is_symlink():
                        raise ValueError(f'Arquivo com vínculo não suportado: {relative}')
                    archive.write(source, 'AgendaPersonal_AndroidStudio/' + relative)
        size = Path(temporary).stat().st_size
        if size >= 25_000_000:
            raise ValueError(f'ZIP com {size} bytes; precisa ficar abaixo de 25.000.000.')
        with ZipFile(temporary) as archive:
            assert archive.testzip() is None
            names = set(archive.namelist())
            assert not any('AgendaPersonal_AndroidStudio/' + page in names for page in PAGES)
            for required in ['app/build.gradle', 'COMPILAR_NO_CODESPACES.sh', 'tools/prepare_assets.cjs', 'web/reference/AgendaPersonal_Cadastro_Professor_Integrado.html']:
                assert 'AgendaPersonal_AndroidStudio/' + required in names
            count = len(names)
        # Preserve any existing file identity metadata on the destination.
        shutil.copyfile(temporary, target)
        print(f'ZIP conferido: {size} bytes, {count} arquivos, compressão Deflate padrão.')
    finally:
        Path(temporary).unlink(missing_ok=True)


if __name__ == '__main__':
    main()
