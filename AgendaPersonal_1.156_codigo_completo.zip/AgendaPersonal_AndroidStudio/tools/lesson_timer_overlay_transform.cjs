'use strict';
// Floating windows and their reopening action have been removed. The inline timer remains.
module.exports=doc=>doc;
