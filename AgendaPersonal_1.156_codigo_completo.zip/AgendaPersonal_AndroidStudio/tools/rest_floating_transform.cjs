'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const read=n=>fs.readFileSync(path.join(__dirname,'../web',n),'utf8');
 const anchor='<button id="workoutRestStart"';assert.equal(doc.split(anchor).length,2,'rest form');
 const end='</form>';const start=doc.indexOf(anchor),formEnd=doc.indexOf(end,start);assert.ok(formEnd>start);
 doc=doc.slice(0,formEnd)+'<button id="workoutRestFloat" class="btn ap-rest-minimize" type="button" onclick="floatWorkoutRest()" hidden>Deixar flutuante</button>'+doc.slice(formEnd);
 // Pass only a validated color to the native view, without changing the rest deadline.
 const arm='Android.startWorkoutRest(JSON.stringify({...rest,triggerAtMillis:rest.endAt}))';assert.ok(doc.includes(arm));
 doc=doc.replaceAll(arm,`Android.startWorkoutRest(JSON.stringify({...rest,triggerAtMillis:rest.endAt,accent:(getComputedStyle(document.documentElement).getPropertyValue('--ac-accent').trim().match(/^#[a-fA-F0-9]{6}$/)||['#9CC72C'])[0]}))`);
 return doc.replace('</head>','<style id="ap-rest-floating-css">'+read('rest-floating.css')+'</style></head>').replace('</body>','<script id="ap-rest-floating">'+read('rest-floating.js')+'</script></body>');
};
