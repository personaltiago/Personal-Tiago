'use strict';
// Validate the actual extracted project; do not infer its version from its folder name.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),vm=require('node:vm');
const root=path.resolve(__dirname,'..'),read=n=>fs.readFileSync(path.join(root,n),'utf8'),fail=m=>{throw Error(m)};
function check(){
 const release=JSON.parse(read('release.json')),gradle=read('app/build.gradle'),update=read('app/src/main/java/com/tiagolima/agendapersonal/UpdateManager.java');
 if(release.format!==1||release.androidVersion!=='1.171'||release.versionCode!==171||release.contentVersion!=='1.12.215'||release.sequence!==321)fail('Identificação da atualização incompatível.');
 if(!gradle.includes("versionName '"+release.androidVersion+"'")||!new RegExp('versionCode[^\\n]+: '+release.versionCode+'\\s').test(gradle))fail('O projeto Android não corresponde à versão '+release.androidVersion+'.');
 if(JSON.parse(read('package.json')).version!==release.androidVersion+'.0')fail('A versão dos arquivos web diverge do projeto.');
 if(!update.includes('BASE_VERSION = "'+release.contentVersion+'"')||!update.includes('BASE_SEQUENCE = '+release.sequence+';'))fail('A versão de conteúdo diverge do projeto.');
 if(!release.sourceHashes||Object.keys(release.sourceHashes).length<10)fail('Falta a lista de conferência do pacote.');
 for(const [file,expected]of Object.entries(release.sourceHashes)){
  if(path.isAbsolute(file)||file.split('/').includes('..')||!/^([a-f0-9]{64})$/.test(expected))fail('Lista de conferência inválida.');
  const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex');if(hash!==expected)fail('Arquivo diferente do pacote revisado: '+file+'.');
 }
 const wear=read('wear/build.gradle');if(!wear.includes("versionName '1.170'")||!read('settings.gradle').includes("include ':wear'"))fail('Módulo Wear OS ausente ou com versão incorreta.');
 const manifest=read('app/src/main/AndroidManifest.xml');for(const token of ['android.permission.SYSTEM_ALERT_WINDOW','android.permission.FOREGROUND_SERVICE_SPECIAL_USE'])if(!manifest.includes(token))fail('Permissão do intervalo compacto ausente.');if(!manifest.includes('android.permission.SCHEDULE_EXACT_ALARM'))fail('Permissão dos alarmes ausente.');
 let scripts=0;
 if(process.argv.includes('--assets')){
  const allowedAssets=new Set(['index.html','professor.html','avaliacoes.html','cadastro.html','icon.png','agenda-build.json']);for(const name of fs.readdirSync(path.join(root,'app/src/main/assets')))if(!allowedAssets.has(name))fail('Arquivo inesperado nas telas do aplicativo: '+name);
  const consolidated=JSON.parse(read('web/native-release.agenda.json'));for(const [name,html] of Object.entries(consolidated.files)){if(read('app/src/main/assets/'+name)!==html)fail('Tela diferente do conteúdo consolidado: '+name);}
  for(const page of ['index','professor','avaliacoes','cadastro']){
   const html=read('app/src/main/assets/'+page+'.html');if(!html.includes('</html>'))fail('Tela incompleta: '+page);
   for(const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){
    const type=match[1].match(/\btype\s*=\s*["']([^"']+)/i)?.[1];if(type&&!['text/javascript','application/javascript'].includes(type))continue;
    new vm.Script(match[2],{filename:page+'.html#script'+(++scripts)});
   }
  }
  if(read('app/src/main/assets/index.html').includes('ap-entry-artwork-loader')&&!read('app/src/main/assets/cadastro.html').includes('id="ap-entry-artwork"'))fail('Ilustração de acesso ausente no pacote.');
  const teacher=read('app/src/main/assets/professor.html');if(teacher.includes('workoutRestNotice'))fail('Faixa de intervalo retirada ainda presente.');for(const token of ['id="financeResults"','ap-finance-results-model','APIconMaterial','ap-compact-week-agenda','id="screen-waitlist"','ap-waitlist-model','ap-waitlist','id="ap-teacher-sync-core"','id="ap-timer-compatibility"','id="ap-workout-active-shortcut"'])if(!teacher.includes(token))fail('Atualização ausente na tela gerada: '+token);
  if((teacher.match(/native=window\.APTimerCompatibility\.startLessonTimer\(/g)||[]).length!==1||(teacher.match(/rest\.native=window\.APTimerCompatibility\.startWorkoutRest\(/g)||[]).length!==2)fail('Um dos cronômetros ignora a compatibilidade do APK antigo.');
 }
 console.log('Projeto conferido: Android '+release.androidVersion+' / conteúdo '+release.contentVersion+' / sequência '+release.sequence+(scripts?' / '+scripts+' scripts analisados.':'.'));
}
try{check()}catch(error){console.error('CONFERÊNCIA INTERROMPIDA: '+error.message);process.exitCode=1}
