"""Exercise current-version download and actual four-page export with bounded memory.

Android UI APIs are test doubles; a signed APK still needs a device check.
"""
from pathlib import Path
import hashlib
import json
import runpy
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
PACKAGE = 'com/tiagolima/agendapersonal'
HARNESS = r'''package com.tiagolima.agendapersonal;
import android.net.Uri;import android.webkit.WebView;import java.nio.file.*;import java.io.*;
import java.lang.reflect.*;import java.util.concurrent.atomic.*;import org.json.*;
public final class UpdateDownloadHarness {
static final String TEACHER="R2EmnDVcvMWt7TjPxOP6DjW1VOn1";
static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
static Object field(Object o,String key)throws Exception{Field f=o.getClass().getDeclaredField(key);f.setAccessible(true);return f.get(o);}
static void set(Object o,String key,Object value)throws Exception{Field f=o.getClass().getDeclaredField(key);f.setAccessible(true);f.set(o,value);}
static void waitFor(java.util.function.BooleanSupplier condition)throws Exception{long until=System.currentTimeMillis()+30000;while(!condition.getAsBoolean()){if(System.currentTimeMillis()>until)throw new AssertionError("Download timed out");Thread.sleep(10);}}
static boolean event(WebView web,String request,String status){return web.scripts.stream().anyMatch(s->s.contains("\"requestId\":\""+request+"\"")&&s.contains("\"status\":\""+status+"\""));}
static void await(WebView web,String request,String status)throws Exception{waitFor(()->event(web,request,status));}
static void idle(UpdateDownloads d)throws Exception{AtomicBoolean busy=(AtomicBoolean)field(d,"busy");waitFor(()->!busy.get());}
public static void main(String[] args)throws Exception{
 Path root=Path.of(args[0]),work=Path.of(args[1]),assets=root.resolve("app/src/main/assets");Files.createDirectories(work);boolean base=args[2].equals("base");
 Path current=work.resolve("live");Files.createDirectories(current.resolve("updates"));
 if(!base)Files.copy(root.resolve("web/native-release.agenda.json"),current.resolve("updates/active.json"));
 MainActivity activity=new MainActivity(current.toFile(),assets);WebView web=new WebView();UpdateManager manager=new UpdateManager(activity,web);UpdateDownloads downloads=(UpdateDownloads)field(manager,"downloads");
 try{
  check(!new JSONObject(manager.updateDownloadOptions()).optBoolean("ok"),"Student options allowed");
  check(!manager.downloadUpdate("installed","f".repeat(64),"student"),"Student download accepted");
  manager.setUpdateAccount(TEACHER);check(new JSONObject(manager.updateDownloadOptions()).getJSONArray("releases").length()==0,"Unconfirmed content downloadable");set(manager,"pageAcknowledged",true);
  JSONObject opts=new JSONObject(manager.updateDownloadOptions());JSONArray list=opts.getJSONArray("releases");check(opts.optBoolean("ok")&&list.length()==1,"Only one current source required");check(opts.toString().length()<2000,"Large page strings crossed bridge");
  JSONObject installed=(JSONObject)list.opt(0);String sha=installed.getString("contentSha256");check(installed.getString("id").equals("installed")&&installed.optBoolean("current"),"Wrong current source");
  check(!manager.downloadUpdate("installed","bad","invalid"),"Invalid identity accepted");
  set(manager,"busy",true);check(!manager.downloadUpdate("installed",sha,"install-busy"),"Export raced installer");set(manager,"busy",false);
  manager.downloadUpdate("installed","0".repeat(64),"changed");await(web,"changed","error");idle(downloads);check(activity.filePickers==0,"Changed identity opened picker");
  manager.downloadUpdate("seed_"+"0".repeat(64),sha,"old");await(web,"old","error");idle(downloads);check(activity.filePickers==0,"Historical archive source survived");
  check(manager.downloadUpdate("installed",sha,"current"),"Current copy refused");check(!manager.downloadUpdate("installed",sha,"double"),"Double click duplicated copy");await(web,"current","choosing");check(activity.lastRequest==3004,"Wrong save activity request");
  manager.finishUpdateDownload(Uri.parse("content://documents/download"));await(web,"current","saved");idle(downloads);Files.move(current.resolve("exported.json"),work.resolve("current.json"));
  check(web.loads==0&&!activity.prefs.getBoolean("pending",false),"Download installed or navigated code");check(!Files.exists(current.resolve("updates/data-before-update.json")),"Download exported student data");
  if(!base)check(Files.mismatch(root.resolve("web/native-release.agenda.json"),current.resolve("updates/active.json"))==-1,"Download altered current version");
  else check(!Files.exists(current.resolve("updates/active.json")),"APK export created an active update");
  manager.downloadUpdate("installed",sha,"cancel");await(web,"cancel","choosing");manager.finishUpdateDownload(null);await(web,"cancel","cancelled");idle(downloads);check(!Files.exists(current.resolve("exported.json")),"Cancel wrote file");
  manager.downloadUpdate("installed",sha,"account");await(web,"account","choosing");manager.setUpdateAccount("");manager.setUpdateAccount(TEACHER);manager.finishUpdateDownload(Uri.parse("content://documents/download"));await(web,"account","error");idle(downloads);check(!Files.exists(current.resolve("exported.json")),"Changed account wrote file");
  manager.downloadUpdate("installed",sha,"tamper");await(web,"tamper","choosing");Path journal=current.resolve("cache/update-downloads/pending.json");JSONObject pending=new JSONObject(Files.readString(journal));Path stage=journal.getParent().resolve(pending.getString("file"));
  try(RandomAccessFile file=new RandomAccessFile(stage.toFile(),"rw")){file.seek(100);file.writeByte(1);}
  manager.finishUpdateDownload(Uri.parse("content://documents/download"));await(web,"tamper","error");idle(downloads);check(!Files.exists(current.resolve("exported.json")),"Tampered public file retained");
  manager.downloadUpdate("installed",sha,"uri");await(web,"uri","choosing");Files.writeString(current.resolve("exported.json"),"keep");manager.finishUpdateDownload(Uri.parse("file:///private/data"));await(web,"uri","error");idle(downloads);check(Files.readString(current.resolve("exported.json")).equals("keep"),"Invalid URI deleted unrelated output");Files.delete(current.resolve("exported.json"));
  check(!Files.exists(journal),"Private pending journal retained");
  System.out.println("PASS "+args[2]+": four current pages; teacher guard, exact identity, double click, cancellation, account switch, tamper, invalid URI and no historical archives; heap="+Runtime.getRuntime().maxMemory());
 }finally{manager.destroy();}
 Path resume=work.resolve("resume");Files.createDirectories(resume);MainActivity resumed=new MainActivity(resume.toFile(),assets);WebView resumedWeb=new WebView();AtomicBoolean teacher=new AtomicBoolean(true);
 UpdateDownloads.Sources source=new UpdateDownloads.Sources(){public JSONArray list(){return new JSONArray();}public UpdateDownloads.Source resolve(String id){return new UpdateDownloads.Source(new JSONObject().put("version","1.12.215").put("filename","AgendaPersonal-1.12.215.agenda.json").put("contentSha256","f".repeat(64)),(file,ok)->Files.writeString(file.toPath(),"{\"code\":true}"));}};
 UpdateDownloads one=new UpdateDownloads(resumed,resumedWeb,source,teacher::get,()->false);one.start("installed","f".repeat(64),"resume");await(resumedWeb,"resume","choosing");one.destroy();
 UpdateDownloads two=new UpdateDownloads(resumed,resumedWeb,source,teacher::get,()->false);try{two.finish(Uri.parse("content://documents/resume"));await(resumedWeb,"resume","saved");idle(two);check(Files.readString(resume.resolve("exported.json")).equals("{\"code\":true}"),"Activity recreation lost file");}finally{two.destroy();}
 MainActivity broken=new MainActivity(resume.toFile(),assets){@Override public Resolver getContentResolver(){return new Resolver(){@Override public OutputStream openOutputStream(Uri uri)throws IOException{OutputStream raw=super.openOutputStream(uri);return new FilterOutputStream(raw){@Override public void write(byte[] b,int o,int n)throws IOException{out.write(b,o,Math.min(2,n));throw new IOException("injected write failure");}};}};}};
 WebView failureWeb=new WebView();UpdateDownloads failure=new UpdateDownloads(broken,failureWeb,source,()->true,()->false);
 try{failure.start("installed","f".repeat(64),"failure");await(failureWeb,"failure","choosing");failure.finish(Uri.parse("content://documents/error"));await(failureWeb,"failure","error");idle(failure);check(!Files.exists(resume.resolve("exported.json")),"Partial file retained after I/O failure");}finally{failure.destroy();}
 System.out.println("PASS picker resume after Activity recreation; real I/O failure cleans partial output");
}
}'''


def main():
    stubs = dict(runpy.run_path(str(PROJECT / 'tests/verify_native_updates.py'))['STUBS'])
    stubs.pop(PACKAGE + '/NativeUpdateHarness.java')
    stubs[PACKAGE + '/UpdateDownloadHarness.java'] = HARNESS
    compiler = [shutil.which('javac')] if shutil.which('javac') else [shutil.which('java'), 'com.sun.tools.javac.Main']
    assert not (PROJECT / 'app/src/main/assets/update-archives').exists(), 'No old version bundle may be embedded'
    main_source = (PROJECT / 'app/src/main/java' / PACKAGE / 'MainActivity.java').read_text()
    assert 'getUpdateDownloadVersion() { return 1; }' in main_source
    assert 'getUpdateDownloadOptions()' in main_source and 'downloadUpdate(String id' in main_source
    assert 'requestCode == UpdateDownloads.SAVE_REQUEST' in main_source
    wanted = json.loads((PROJECT / 'web/native-release.agenda.json').read_bytes())
    with tempfile.TemporaryDirectory(prefix='agenda-current-download-') as temporary:
        work = Path(temporary)
        files = []
        for name, text in stubs.items():
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text)
            files.append(str(target))
        for name in ['UpdateManager', 'AndroidInstaller', 'UpdateStorage', 'UpdateExport', 'UpdateDownloads', 'UpdateIdentity', 'NativeLaunch', 'LocalPages', 'UpdateManifest']:
            files.append(str(PROJECT / 'app/src/main/java' / PACKAGE / (name + '.java')))
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + files, check=True)
        for mode, heap in [('base', '128m'), ('active', '256m')]:
            out = work / mode
            subprocess.run([shutil.which('java'), '-Xmx' + heap, '-cp', str(work / 'classes'), PACKAGE.replace('/', '.') + '.UpdateDownloadHarness', str(PROJECT), str(out), mode], check=True, timeout=90)
            actual = json.loads((out / 'current.json').read_bytes())
            assert actual == wanted, 'Saved package differs from the actual current release'
            print(f'PASS {mode}: original complete metadata and four pages preserved exactly', flush=True)
    print('PASS current-only export; no student data or embedded historical copies')


if __name__ == '__main__':
    main()
