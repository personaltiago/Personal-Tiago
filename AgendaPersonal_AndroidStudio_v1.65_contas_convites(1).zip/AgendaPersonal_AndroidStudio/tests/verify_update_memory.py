"""Exercise the real importer with four real pages under a bounded Java heap.

The Android and JSON APIs are test doubles; JSON is actual text, not object IDs.
This does not replace an APK installation and physical-device test.
"""
from pathlib import Path
import json
import runpy
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
PACKAGE = 'com/tiagolima/agendapersonal'
HARNESS = r'''package com.tiagolima.agendapersonal;
import android.net.Uri;import android.webkit.WebView;import android.app.AlertDialog;import android.widget.Toast;
import java.nio.file.*;import java.lang.reflect.*;import java.util.*;import java.util.concurrent.*;import org.json.*;
public final class UpdateMemoryHarness {
static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
static void waitFor(UpdateManager manager,boolean review)throws Exception{
 long until=System.currentTimeMillis()+30000;
 while(System.currentTimeMillis()<until){
  AlertDialog dialog=(AlertDialog)field(manager,"reviewDialog");
  if(review&&dialog!=null&&dialog.isShowing()&&dialog.getButton(1).listener!=null)return;
  if(!review&&!Boolean.TRUE.equals(field(manager,"busy")))return;
  Thread.sleep(10);
 }
 throw new AssertionError("Import did not finish: "+Toast.shown);
}
public static void main(String[] args)throws Exception {
 Path project=Path.of(args[0]),folder=Path.of(args[1]),candidate=Path.of(args[2]);String mode=args[3];
 Path updates=folder.resolve("updates");Files.createDirectories(updates);
 if(!mode.equals("first"))Files.copy(project.resolve("web/native-release.agenda.json"),updates.resolve("active.json"));
 MainActivity activity=new MainActivity(folder.toFile(),project.resolve("app/src/main/assets"));WebView view=new WebView();
 view.snapshot="{\"agendaPersonalTL_v1\":\""+"dados-ç-".repeat(131072)+"\"}";
 UpdateManager manager=new UpdateManager(activity,view);view.reader=manager::localResponse;manager.setUpdateAccount("R2EmnDVcvMWt7TjPxOP6DjW1VOn1");
 try {
  if(!mode.equals("first"))check(field(manager,"active")!=null,"Installed release did not load");
  manager.openPage(Uri.parse(LocalPages.HOME));view.awaitLoads(1);view.ready=true;manager.pageReady();
  if(mode.equals("fault")){
   JSONObject files=new JSONObject().put("index.html","<!doctype html><html><head></head><body>different agendaPersonalTL_v1 syncNativeAlarms<script data-agenda-ready></script></body></html>").put("avaliacoes.html","<html><head></head><body><script data-agenda-ready></script></body></html>");
   JSONObject fail=new JSONObject(){@Override public Iterator<String> keys(){throw new OutOfMemoryError("injected storage allocation failure");}};
   fail.put("format",1).put("appId",activity.getPackageName()).put("bridgeVersion",3).put("dataSchema",4).put("sequence",999).put("version","1.12.999").put("files",files);
   Field busy=UpdateManager.class.getDeclaredField("busy");busy.setAccessible(true);busy.set(manager,true);
   Method apply=UpdateManager.class.getDeclaredMethod("snapshotAndApply",JSONObject.class);apply.setAccessible(true);apply.invoke(manager,fail);waitFor(manager,false);
   check(!activity.prefs.getBoolean("pending",false),"Pending installation was not rolled back");
   check(!activity.prefs.getBoolean("restoreData",false),"Failed write scheduled a stale student snapshot for the next navigation");
   check(Files.mismatch(project.resolve("web/native-release.agenda.json"),updates.resolve("active.json"))==-1,"Allocation failure changed the installed release");
   check(view.loads==1,"Failed candidate was opened");check(Toast.shown.stream().anyMatch(s->s.contains("memória suficiente")),"Allocation failure had no visible message");
   check(!Files.exists(updates.resolve("active.json.new")),"Partial file survived failed write");
  } else {
   manager.importUri(Uri.parse(candidate.toUri().toString()));waitFor(manager,true);
   check(view.loads==1,"Import changed the page before confirmation");
   if(mode.equals("changed-disk"))Files.writeString(updates.resolve("active.json"),"{\"unexpected\":true}");
   AlertDialog review=(AlertDialog)field(manager,"reviewDialog");review.getButton(1).listener.click(null);
   view.awaitLoads(2);check(activity.prefs.getBoolean("pending",false),"Success was acknowledged before opening");
   check(view.html.contains("bounded-memory-import"),"New content did not open");
   view.ready=true;manager.pageReady();waitFor(manager,false);
   check(!activity.prefs.getBoolean("pending",false),"New version was not acknowledged");
   check(Files.readString(updates.resolve("data-before-update.json")).equals(view.snapshot),"Student snapshot changed");
   if(mode.equals("first"))check(!Files.exists(updates.resolve("previous.json")),"First import invented history");
   if(mode.equals("active"))check(Files.mismatch(project.resolve("web/native-release.agenda.json"),updates.resolve("previous.json"))==-1,"Exact recovery copy changed");
  }
  System.out.println("PASS "+mode+"; heap="+Runtime.getRuntime().maxMemory()+"; pages kept; data kept");
 } finally {manager.destroy();}
}
}'''

STORAGE = r'''package com.tiagolima.agendapersonal;
import java.nio.file.*;import java.util.*;import org.json.*;
public final class UpdateStorageHarness {
static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
public static void main(String[] args)throws Exception {
 Path root=Path.of(args[0]),target=root.resolve("atomic.json"),source=root.resolve("source.json");
 String text="\"\\\n\r\t\b\f\u0000"+"a".repeat(8189)+"🐺 ação /</script>";
 JSONObject value=new JSONObject().put("text",text).put("number",1.25).put("flag",true).put("nil",JSONObject.NULL).put("nested",new JSONArray().put("ç").put(4).put(new JSONObject().put("x","y")));
 String hash=UpdateStorage.writeJson(target.toFile(),value,128*1024);
 byte[] good=Files.readAllBytes(target);check(hash.equals(UpdateStorage.sha256(good)),"Saved digest differs");
 JSONObject read=new JSONObject(new String(good,java.nio.charset.StandardCharsets.UTF_8));check(read.getString("text").equals(text),"Escapes or Unicode changed");
 check(((JSONArray)read.opt("nested")).length()==3,"Array metadata changed");
 try{UpdateStorage.writeJson(target.toFile(),value,20);throw new AssertionError("Oversized update was accepted");}catch(java.io.IOException expected){}
 check(Arrays.equals(good,Files.readAllBytes(target)),"Oversized update replaced good file");
 Files.writeString(source,"another release");
 try{UpdateStorage.copy(source.toFile(),target.toFile(),128*1024,hash);throw new AssertionError("Changed source accepted");}catch(java.io.IOException expected){}
 check(Arrays.equals(good,Files.readAllBytes(target)),"Hash mismatch replaced good backup");
 JSONObject broken=new JSONObject(){@Override public Iterator<String> keys(){throw new OutOfMemoryError("injected");}};
 try{UpdateStorage.writeJson(target.toFile(),broken,128*1024);throw new AssertionError("Injected allocation failure ignored");}catch(OutOfMemoryError expected){}
 check(Arrays.equals(good,Files.readAllBytes(target)),"Allocation failure replaced good file");
 check(!Files.exists(Path.of(target+".new")),"Incomplete atomic write remained");
 UpdateStorage.copy(target.toFile(),source.toFile(),128*1024,hash);check(Files.mismatch(source,target)==-1,"Successful copy changed bytes");
 System.out.println("PASS atomic failure, size bound, verified copy, metadata, UTF-8 and escaping");

}
}'''


def main():
    java = shutil.which('java')
    compiler = [shutil.which('javac')] if shutil.which('javac') else [java, 'com.sun.tools.javac.Main']
    stubs = dict(runpy.run_path(str(PROJECT / 'tests/verify_native_updates.py'))['STUBS'])
    stubs.pop(PACKAGE + '/NativeUpdateHarness.java')
    stubs[PACKAGE + '/UpdateMemoryHarness.java'] = HARNESS
    stubs[PACKAGE + '/UpdateStorageHarness.java'] = STORAGE
    with tempfile.TemporaryDirectory(prefix='agenda-update-memory-') as temp:
        work = Path(temp)
        sources = []
        for name, text in stubs.items():
            file = work / name
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_text(text)
            sources.append(str(file))
        for name in ['UpdateManager', 'AndroidInstaller', 'UpdateStorage','UpdateExport','UpdateDownloads', 'UpdateIdentity', 'NativeLaunch', 'LocalPages', 'UpdateManifest']:
            sources.append(str(PROJECT / 'app/src/main/java' / PACKAGE / (name + '.java')))
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + sources, check=True)
        subprocess.run([java, '-Xmx64m', '-cp', str(work / 'classes'), PACKAGE.replace('/', '.') + '.UpdateStorageHarness', str(work)], check=True)
        installed = json.loads((PROJECT / 'web/native-release.agenda.json').read_bytes())
        candidate = json.loads(json.dumps(installed))
        candidate.update(version='1.12.205', sequence=311, notes='Teste de instalação com as quatro telas completas.')
        candidate['files']['index.html'] = candidate['files']['index.html'].replace('</body>', '<span hidden>bounded-memory-import</span></body>')
        file = work / 'candidate.agenda.json'
        file.write_text(json.dumps(candidate, ensure_ascii=False, separators=(',', ':')))
        for mode, heap in [('first', '192m'), ('active', '256m'), ('changed-disk', '256m'), ('fault', '192m')]:
            folder = work / mode
            folder.mkdir()
            subprocess.run([java, '-Xmx' + heap, '-cp', str(work / 'classes'), PACKAGE.replace('/', '.') + '.UpdateMemoryHarness', str(PROJECT), str(folder), str(file), mode], check=True, timeout=90)
            saved = json.loads((folder / 'updates/active.json').read_bytes())
            assert saved['files'] == (installed if mode == 'fault' else candidate)['files']
            if mode in ['active', 'changed-disk']:
                assert json.loads((folder / 'updates/previous.json').read_bytes())['files'] == installed['files']
        print('Importação completa com páginas reais e memória limitada; primeira instalação, atualização, disco alterado e falha de memória. Sem APK ou aparelho físico.')


if __name__ == '__main__':
    main()
