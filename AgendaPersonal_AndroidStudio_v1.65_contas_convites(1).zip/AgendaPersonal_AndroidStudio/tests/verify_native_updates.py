"""Compile and exercise the real UpdateManager with small Android API fakes.

This verifies loading, version acknowledgement, navigation and rollback logic.
It does not replace installation/storage checks in an Android WebView.
"""
from pathlib import Path
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
STUBS = {
    'android/view/View.java': '''package android.view;public class View {public static final int VISIBLE=0,GONE=8;public final java.util.Map<Integer,Object> nodes=new java.util.LinkedHashMap<>();@SuppressWarnings("unchecked") public <T>T findViewById(int id){return(T)nodes.get(id);}}''',
    'android/view/LayoutInflater.java': '''package android.view;import android.widget.Button;import com.tiagolima.agendapersonal.R;public class LayoutInflater{public View inflate(int id,Object parent){View root=new View();int[] ids={R.id.update_import,R.id.update_restore,R.id.update_conference,R.id.update_details,R.id.update_verify,R.id.update_publish,R.id.update_installer,R.id.update_installer_publish,R.id.update_close};String[] labels={"Importar arquivo baixado do painel","Restaurar versão anterior","Conferência de atualizações","Detalhes","Verificar","Publicar para os alunos","Instalador Android","Publicar instalador Android","Fechar"};for(int i=0;i<ids.length;i++){Button b=new Button(null);b.setText(labels[i]);root.nodes.put(ids[i],b);}return root;}}''',
    'com/tiagolima/agendapersonal/R.java': '''package com.tiagolima.agendapersonal;public class R{public static class layout{public static final int update_actions=1;}public static class id{public static final int update_import=1,update_restore=2,update_conference=3,update_details=4,update_verify=5,update_publish=6,update_close=7,update_installer=8,update_installer_publish=9;}}''',

    'android/content/Context.java': '''package android.content; public class Context {}''',
    'android/os/Build.java': 'package android.os; public class Build {public static class VERSION {public static int SDK_INT=35;}}',
    'android/provider/Settings.java': 'package android.provider; public class Settings {public static String ACTION_MANAGE_UNKNOWN_APP_SOURCES="settings";}',
    'android/content/pm/Signature.java': 'package android.content.pm; public class Signature {}',
    'android/content/pm/SigningInfo.java': 'package android.content.pm; public class SigningInfo {public Signature[] getApkContentsSigners(){return null;}}',
    'android/content/pm/PackageInfo.java': 'package android.content.pm; public class PackageInfo {public String packageName,versionName; public int versionCode; public SigningInfo signingInfo; public Signature[] signatures; public long getLongVersionCode(){return versionCode;}}',
    'android/content/pm/PackageManager.java': 'package android.content.pm; public class PackageManager {public static final int GET_SIGNING_CERTIFICATES=1,GET_SIGNATURES=2; public PackageInfo getPackageInfo(String name,int flags){return null;} public PackageInfo getPackageArchiveInfo(String path,int flags){return null;} public boolean canRequestPackageInstalls(){return false;}}',
    'androidx/core/content/FileProvider.java': 'package androidx.core.content; public class FileProvider {public static android.net.Uri getUriForFile(android.content.Context c,String a,java.io.File f){return null;}}',
    'android/content/Intent.java': '''package android.content;
public class Intent { public static final String ACTION_OPEN_DOCUMENT="open", ACTION_CREATE_DOCUMENT="create", EXTRA_TITLE="title", CATEGORY_OPENABLE="openable", EXTRA_MIME_TYPES="types";
public static final String ACTION_VIEW="view"; public static final int FLAG_GRANT_READ_URI_PERMISSION=1;
public Intent(String s,android.net.Uri uri){} public Intent addFlags(int f){return this;} public Intent setDataAndType(android.net.Uri uri,String type){return this;}
public Intent(String s){} public Intent(Context c,Class<?> t){} public Intent addCategory(String s){return this;}
public Intent setType(String s){return this;} public Intent putExtra(String k,String[] v){return this;} public Intent putExtra(String k,String v){return this;} }''',
    'android/content/SharedPreferences.java': '''package android.content;
public interface SharedPreferences { boolean getBoolean(String k,boolean d); Editor edit();
interface Editor { Editor putBoolean(String k,boolean v); boolean commit(); } }''',
    'android/net/Uri.java': '''package android.net;
public final class Uri { private final java.net.URI u; private Uri(String s){u=java.net.URI.create(s);}
public static Uri parse(String s){return new Uri(s);} public String getScheme(){return u.getScheme();}
public String getAuthority(){return u.getRawAuthority();} public String getPath(){return u.getPath();}
public String toString(){return u.toString();} public boolean equals(Object o){return o instanceof Uri&&u.equals(((Uri)o).u);}
public int hashCode(){return u.hashCode();}
public Builder buildUpon(){return new Builder(u);} public static class Builder{
private String s,a,p,q,f;Builder(java.net.URI u){s=u.getScheme();a=u.getRawAuthority();p=u.getRawPath();q=u.getRawQuery();f=u.getRawFragment();}
public Builder scheme(String v){s=v;return this;}public Builder authority(String v){a=v;return this;}public Builder path(String v){p=v;return this;}
public Uri build(){return Uri.parse(s+"://"+(a==null?"":a)+p+(q==null?"":"?"+q)+(f==null?"":"#"+f));}}
}''',
    'android/os/Looper.java': '''package android.os; public class Looper {public static Looper getMainLooper(){return new Looper();}}''',
    'android/os/Handler.java': '''package android.os;
public class Handler {public static final java.util.List<Runnable> tasks=new java.util.ArrayList<>(); public Handler(Looper l){}
public boolean postDelayed(Runnable r,long t){synchronized(tasks){tasks.add(r);}return true;}
public void removeCallbacksAndMessages(Object o){synchronized(tasks){tasks.clear();}}
public static void fire(){java.util.List<Runnable> copy; synchronized(tasks){copy=new java.util.ArrayList<>(tasks);tasks.clear();}for(Runnable r:copy)r.run();} }''',
    'android/util/Base64.java': '''package android.util; public class Base64 {public static final int NO_WRAP=2;
public static String encodeToString(byte[] a,int f){return java.util.Base64.getEncoder().encodeToString(a);} }''',
    'android/util/AtomicFile.java': '''package android.util; import java.io.*; import java.nio.file.*;
public class AtomicFile {private final File f,next; public AtomicFile(File f){this.f=f;next=new File(f.toString()+".new");}
public InputStream openRead()throws IOException{return new FileInputStream(f);}
public byte[] readFully()throws IOException{return Files.readAllBytes(f.toPath());}
public FileOutputStream startWrite()throws IOException{return new FileOutputStream(next);}
public void finishWrite(FileOutputStream s)throws IOException{s.close();Files.move(next.toPath(),f.toPath(),StandardCopyOption.REPLACE_EXISTING);}
public void failWrite(FileOutputStream s)throws IOException{s.close();Files.deleteIfExists(next.toPath());}
public void delete(){f.delete();next.delete();} }''',
    'android/webkit/CookieManager.java': '''package android.webkit; public class CookieManager {
public static CookieManager getInstance(){return new CookieManager();} public String getCookie(String s){return null;} }''',
    'android/webkit/ValueCallback.java': '''package android.webkit; public interface ValueCallback<T>{void onReceiveValue(T value);}''',
    'android/webkit/WebResourceResponse.java': '''package android.webkit;public class WebResourceResponse{
public final java.io.InputStream data;public final int status;public WebResourceResponse(String m,String e,java.io.InputStream d){data=d;status=200;}
public WebResourceResponse(String m,String e,int s,String reason,java.util.Map<String,String> headers,java.io.InputStream d){data=d;status=s;}}''',
    'android/webkit/WebView.java': '''package android.webkit;
public class WebView {public boolean postDelayed(Runnable task,long delay){return true;} public volatile String base,html,history,check; public volatile int loads; public volatile boolean ready;
public String snapshot="{\\\"agendaPersonalTL_v1\\\":\\\"foto-á-segurada\\\"}";public boolean allowUpdates=true,holdUpdateCheck=false;public ValueCallback<String> pendingUpdateCheck;
public java.util.function.Function<android.net.Uri,WebResourceResponse> reader;
public synchronized void loadUrl(String url){try{WebResourceResponse r=reader.apply(android.net.Uri.parse(url));if(r==null&&url.startsWith("file:///android_asset/"))html="<script id='ap-legacy-storage-bootstrap'>Android.captureLegacyStorage(JSON.stringify(data))</script>";else{if(r==null||r.status!=200)throw new AssertionError("Local route failed");html=new String(r.data.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);}base=url;history=url;loads++;notifyAll();}catch(java.io.IOException e){throw new RuntimeException(e);}}
public synchronized void loadDataWithBaseURL(String b,String d,String m,String e,String h){base=b;html=d;history=h;loads++;notifyAll();}
public final java.util.List<String> scripts=new java.util.concurrent.CopyOnWriteArrayList<>();public void evaluateJavascript(String s,ValueCallback<String> c){check=s;scripts.add(s);if(c==null)return;if(s.contains("APupdates.canInstall")){if(holdUpdateCheck){pendingUpdateCheck=c;return;}c.onReceiveValue(allowUpdates?"true":"false");return;}c.onReceiveValue(s.contains("localStorage.length")?org.json.JSONObject.quote(snapshot):(ready?"true":"false"));}
public synchronized void awaitLoads(int n)throws Exception{long until=System.currentTimeMillis()+5000;while(loads<n&&System.currentTimeMillis()<until)wait(50);if(loads<n)throw new AssertionError("Página não carregada");} }''',
    'android/widget/Button.java': '''package android.widget; public class Button {
public String text=""; public boolean enabled=true; public Click listener; public int visibility=0;public void setVisibility(int v){visibility=v;}
public Button(android.content.Context c){} public void setText(String s){text=s;} public void setEnabled(boolean b){enabled=b;}
public interface Click{void click(Object v);} public void setOnClickListener(Click c){listener=c;} }''',
    'android/widget/LinearLayout.java': '''package android.widget; public class LinearLayout {public static final int VERTICAL=1;public final java.util.List<Object> children=new java.util.ArrayList<>();public LinearLayout(android.content.Context c){}public void setOrientation(int v){}public void addView(Object v){children.add(v);}}''',
    'android/widget/TextView.java': '''package android.widget; public class TextView {public void setText(String s){}}''',
    'android/widget/Toast.java': '''package android.widget;
public class Toast {public static final int LENGTH_LONG=1,LENGTH_SHORT=0; public static final java.util.List<String> shown=new java.util.concurrent.CopyOnWriteArrayList<>();
private final String message;private Toast(String s){message=s;} public static Toast makeText(android.content.Context c,String s,int n){return new Toast(s);}public void show(){shown.add(message);} }''',
    'android/app/AlertDialog.java': '''package android.app;
public class AlertDialog {public static final int BUTTON_POSITIVE=1,BUTTON_NEUTRAL=2,BUTTON_NEGATIVE=3;
public static AlertDialog lastCreated;public String title,message,neutral;public Object view;public boolean showing;private Show onShow,onDismiss;
private final java.util.Map<Integer,android.widget.Button> buttons=new java.util.HashMap<>();
public void setMessage(CharSequence s){message=s.toString();}public boolean isShowing(){return showing;} public <T>T findViewById(int i){return null;}public android.widget.Button getButton(int i){return buttons.computeIfAbsent(i,k->new android.widget.Button(null));}
public interface Show{void show(Object d);} public void setOnShowListener(Show s){onShow=s;} public void setOnDismissListener(Show s){onDismiss=s;} public void show(){showing=true;if(onShow!=null)onShow.show(this);}public void dismiss(){boolean was=showing;showing=false;if(was&&onDismiss!=null)onDismiss.show(this);}
public interface Click{void onClick(Object dialog,int which);}
public static class Builder {private final AlertDialog d=new AlertDialog();public Builder(android.content.Context c,int style){} public Builder(android.content.Context c){} public Builder setCancelable(boolean b){return this;} public Builder setOnCancelListener(Show s){return this;}public Builder setTitle(String s){d.title=s;return this;}
public Builder setMessage(String s){d.message=s;return this;}public Builder setView(Object v){d.view=v;return this;}public Builder setPositiveButton(String s,Click o){d.getButton(BUTTON_POSITIVE).setText(s);if(o!=null)d.getButton(BUTTON_POSITIVE).setOnClickListener(v->{o.onClick(d,BUTTON_POSITIVE);d.dismiss();});return this;}
public Builder setNeutralButton(String s,Object o){d.neutral=s;return this;}public Builder setNegativeButton(String s,Click o){d.getButton(BUTTON_NEGATIVE).setText(s);d.getButton(BUTTON_NEGATIVE).setOnClickListener(v->{if(o!=null)o.onClick(d,BUTTON_NEGATIVE);d.dismiss();});return this;}public AlertDialog create(){lastCreated=d;return d;}public AlertDialog show(){create().show();return d;}} }''',
    'android/R.java': '''package android; public class R {public static class style{public static final int Theme_Material_Dialog_Alert=1;}public static class id{public static final int message=1;}}''',
    'org/json/JSONObject.java': (PROJECT / 'tests/native-json/org/json/JSONObject.java').read_text(),
    'org/json/JSONArray.java': (PROJECT / 'tests/native-json/org/json/JSONArray.java').read_text(),
    'org/json/JSONTokener.java': (PROJECT / 'tests/native-json/org/json/JSONTokener.java').read_text(),
    'com/tiagolima/agendapersonal/UpdatePanelActivity.java': '''package com.tiagolima.agendapersonal; public class UpdatePanelActivity {}''',
    'com/tiagolima/agendapersonal/UpdatePoller.java': '''package com.tiagolima.agendapersonal; public class UpdatePoller {static void markInstalled(MainActivity c,int n){} static org.json.JSONObject latest(MainActivity c){return null;}static org.json.JSONObject fetch(MainActivity c,int n){return new org.json.JSONObject();}}''',
    'com/tiagolima/agendapersonal/MainActivity.java': '''package com.tiagolima.agendapersonal;
import java.io.*;import java.nio.file.*;import java.util.*;
public class MainActivity extends android.content.Context {
public final File folder;public final Path assets;public final Prefs prefs=new Prefs();public MainActivity(File f,Path a){folder=f;assets=a;}
public android.content.SharedPreferences getSharedPreferences(String n,int m){return prefs;}public File getFilesDir(){return folder;}public File getCacheDir(){File cache=new File(folder,"cache");cache.mkdirs();return cache;}
public String getPackageName(){return "com.tiagolima.agendapersonal";}public boolean isFinishing(){return false;}
public String boot="";public void showBootLoading(){boot="loading";}public void showBootReady(){boot="ready";}public void showBootError(String code){boot=code;}
public android.view.LayoutInflater getLayoutInflater(){return new android.view.LayoutInflater();}public int filePickers;public int lastRequest;public void runOnUiThread(Runnable r){r.run();}public void startActivity(android.content.Intent i){}public void startActivityForResult(android.content.Intent i,int n){filePickers++;lastRequest=n;}
public Assets getAssets(){return new Assets();}public class Assets{public InputStream open(String n)throws IOException{return Files.newInputStream(assets.resolve(n));}}
public android.content.pm.PackageManager getPackageManager(){return new android.content.pm.PackageManager();}
public Resolver getContentResolver(){return new Resolver();}public class Resolver{public OutputStream openOutputStream(android.net.Uri uri)throws IOException{Path p=folder.toPath().resolve("exported.json");return Files.newOutputStream(p);}public int delete(android.net.Uri uri,String a,String[]b)throws IOException{return Files.deleteIfExists(folder.toPath().resolve("exported.json"))?1:0;}public InputStream openInputStream(android.net.Uri u)throws IOException{return Files.newInputStream(Path.of(java.net.URI.create(u.toString())));}}
public static class Prefs implements android.content.SharedPreferences {private final Map<String,Boolean> data=new java.util.concurrent.ConcurrentHashMap<>();
public boolean getBoolean(String k,boolean d){return data.getOrDefault(k,d);}public Editor edit(){return new E();}
private class E implements Editor{private final Map<String,Boolean> next=new HashMap<>();public Editor putBoolean(String k,boolean v){next.put(k,v);return this;}public boolean commit(){data.putAll(next);return true;}}}
}''',
    'com/tiagolima/agendapersonal/NativeUpdateHarness.java': r'''package com.tiagolima.agendapersonal;
import android.net.Uri;import android.webkit.WebView;import android.os.Handler;import android.widget.Toast;
import java.nio.file.*;import java.lang.reflect.*;import org.json.JSONObject;
public final class NativeUpdateHarness {
static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
static String withoutReleaseMarker(String html){String marker="<script>window.__agendaNativeReleaseToken=";int start=html.indexOf(marker);check(start>=0,"Marcador nativo ausente");int end=html.indexOf("</script>",start)+9;String extra="<script>window.addEventListener('error',function(e){if(e.error)";check(html.startsWith(extra,end),"Diagnóstico ausente");end=html.indexOf("</script>",end)+9;check(html.startsWith(NativeLaunch.HTML,end),"Alinhamento nativo não entregue");end+=NativeLaunch.HTML.length();if(html.startsWith("<script id=\"ap-native-installer-controls\">",end)){int next=html.indexOf("</script>",end);check(next>end&&html.substring(end,next).contains("publish-installer"),"Ação do APK ausente");end=next+9;}return html.substring(0,start)+html.substring(end);}
static JSONObject bundle(int n,String label){String html="<!doctype html><html><head></head><body>"+label+" agendaPersonalTL_v1 syncNativeAlarms<script data-agenda-ready></script></body></html>";
return new JSONObject().put("format",1).put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4).put("sequence",n).put("version","1.11."+(n-1)).put("files",new JSONObject().put("index.html",html).put("avaliacoes.html",html));}
static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
static void setField(Object o,String n,Object value)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,value);}
static void apply(UpdateManager m,JSONObject b)throws Exception{Method v=UpdateManager.class.getDeclaredMethod("validateBundle",JSONObject.class);v.setAccessible(true);v.invoke(m,b);Method a=UpdateManager.class.getDeclaredMethod("snapshotAndApply",JSONObject.class);a.setAccessible(true);a.invoke(m,b);}
public static void main(String[] args)throws Exception{
Path root=Path.of(args[0]),folder=Files.createTempDirectory("agenda-native-fixture-");
MainActivity activity=new MainActivity(folder.toFile(),root.resolve("app/src/main/assets"));WebView view=new WebView();
Files.createDirectories(folder.resolve("updates"));Files.writeString(folder.resolve("updates/active.json"),bundle(2,"pacote incompatível").put("bridgeVersion",2).toString());
UpdateManager manager=new UpdateManager(activity,view);
view.reader=manager::localResponse;
final int updateSequence=((Integer)field(manager,"BASE_SEQUENCE"))+1;
try {
// Busy prevents network access while exercising the actual role-specific UI.
setField(manager,"busy",true);manager.setUpdateAccount("student");manager.showScreen();
android.app.AlertDialog studentDialog=android.app.AlertDialog.lastCreated;
android.view.View studentActions=(android.view.View)studentDialog.view;check(((android.widget.Button)studentActions.nodes.get(R.id.update_import)).visibility==android.view.View.GONE&&((android.widget.Button)studentActions.nodes.get(R.id.update_restore)).visibility==android.view.View.GONE&&((android.widget.Button)studentActions.nodes.get(R.id.update_conference)).visibility==android.view.View.GONE&&((android.widget.Button)studentActions.nodes.get(R.id.update_publish)).visibility==android.view.View.GONE,"Aluno recebeu controles do professor");
check(studentDialog.title.equals("Atualizar aplicativo"),"Título técnico exibido ao aluno");
setField(manager,"manifest",new JSONObject().put("available",true).put("sequence",updateSequence));
Method display=UpdateManager.class.getDeclaredMethod("display",String.class);display.setAccessible(true);display.invoke(manager,"Atualização disponível");
check(((android.widget.Button)studentActions.nodes.get(R.id.update_verify)).text.equals("Verificar"),"Aluno perdeu o botão Verificar");
check(!((android.widget.Button)studentActions.nodes.get(R.id.update_verify)).enabled,"Download duplicado permitido durante operação");
manager.setUpdateAccount("R2EmnDVcvMWt7TjPxOP6DjW1VOn1");check(!studentDialog.isShowing(),"Janela antiga ficou aberta na troca de papel");manager.showScreen();
android.app.AlertDialog teacherDialog=android.app.AlertDialog.lastCreated;
android.view.View teacherActions=(android.view.View)teacherDialog.view;
check(teacherActions.nodes.size()==9,"Professor perdeu opções de atualização");
check(((android.widget.Button)teacherActions.nodes.get(R.id.update_publish)).visibility==android.view.View.VISIBLE,"Professor perdeu publicação");
check(((android.widget.Button)teacherActions.nodes.get(R.id.update_import)).text.equals("Importar arquivo baixado do painel"),"Importação do professor ausente");
manager.setUpdateAccount("student");check(!teacherDialog.isShowing(),"Aluno herdou janela do professor");manager.showScreen();
check(((android.widget.Button)((android.view.View)android.app.AlertDialog.lastCreated.view).nodes.get(R.id.update_publish)).visibility==android.view.View.GONE,"Janela do professor reapareceu para aluno");
((android.app.AlertDialog)field(manager,"dialog")).dismiss();setField(manager,"dialog",null);setField(manager,"manifest",null);setField(manager,"busy",false);
System.out.println("Atualizações por conta: aluno somente consulta/baixa; professor mantém importação, restauração e publicação; troca de papel fecha janela antiga; duplicidade bloqueada. Sem rede real.");
String home=LocalPages.HOME,eval=LocalPages.ORIGIN+"/assets/avaliacoes.html?agendaStudentId=aluno-2&name=Ana%20Silva";
check(UpdateManager.isLocalPage(Uri.parse(home)),"Rota local recusada");check(!UpdateManager.isLocalPage(Uri.parse("file://outro/android_asset/index.html")),"Autoridade externa aceita");
check(!UpdateManager.isLocalPage(Uri.parse("https://example.com/index.html")),"URL externa aceita");check(!UpdateManager.isLocalPage(Uri.parse("file:///android_asset/segredos.txt")),"Arquivo não previsto aceito");
check(LocalPages.allowFrame(Uri.parse("about:srcdoc"))&&LocalPages.allowFrame(Uri.parse("about:blank")),"Iframe interno bloqueado");
check(!LocalPages.allowFrame(Uri.parse("https://example.com")),"Iframe externo aceito");
check(LocalPages.canonical(Uri.parse("file:///android_asset/avaliacoes.html?name=Ana%20Silva")).toString().equals(LocalPages.ORIGIN+"/assets/avaliacoes.html?name=Ana%20Silva"),"Conversão perdeu os parâmetros");
check(manager.localResponse(Uri.parse(LocalPages.ORIGIN+"/assets/../secret")).status==404,"Caminho não previsto exposto");
check(manager.localResponse(Uri.parse("https://example.com/assets/index.html"))==null,"Rede externa interceptada");
check(new String(manager.localResponse(Uri.parse(LocalPages.ORIGIN+"/assets/professor.html")).data.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8).equals(Files.readString(root.resolve("app/src/main/assets/professor.html"))),"Professor não servido");
manager.openPage(Uri.parse(home));view.awaitLoads(1);check(home.equals(view.base)&&home.equals(view.history),"Endereço de armazenamento alterado");
String installedHtml=Files.readString(root.resolve("app/src/main/assets/index.html"));check(withoutReleaseMarker(view.html).equals(installedHtml),"Base nova substituída por pacote antigo");
manager.openPage(Uri.parse(eval));view.awaitLoads(2);check(eval.equals(view.base)&&eval.equals(view.history),"Parâmetros de avaliação perdidos");check(view.html.contains("Tiago Lima · Avaliações"),"Página errada");
check(manager.goBack(),"Voltar não funcionou");view.awaitLoads(3);check(home.equals(view.base)&&withoutReleaseMarker(view.html).equals(installedHtml),"Voltar abriu conteúdo antigo");check(!manager.goBack(),"Histórico não terminou");
Toast.shown.clear();int before=view.loads;apply(manager,bundle(updateSequence,"nova-versão-A"));view.awaitLoads(before+1);
check(view.html.contains("nova-versão-A"),"Conteúdo publicado não abriu");check(activity.prefs.getBoolean("pending",false),"Atualização confirmada antes de abrir");
check(Toast.shown.stream().noneMatch(s->s.startsWith("Atualização aplicada")),"Sucesso antecipado");
check(Files.readString(folder.resolve("updates/data-before-update.json")).equals(view.snapshot),"Snapshot alterado");
view.ready=false;manager.pageReady();check(activity.prefs.getBoolean("pending",false),"Página antiga confirmou atualização");
check(manager.publishableUpdate().isEmpty(),"Exportação permitida sem conta do professor");
manager.setUpdateAccount("student");check(manager.publishableUpdate().isEmpty(),"Aluno exportou pacote para publicação");
manager.setUpdateAccount("R2EmnDVcvMWt7TjPxOP6DjW1VOn1");JSONObject exported=new JSONObject(manager.publishableUpdate());
check(exported.getJSONObject("files").getString("index.html").contains("nova-versão-A"),"Exportação não usou o código da versão instalada");
check(!exported.getJSONObject("files").getString("index.html").contains("__agendaNativeReleaseToken"),"Exportação incluiu diagnóstico/snapshot nativo");
JSONObject candidate=new JSONObject().put("available",true).put("format",1).put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4).put("sequence",updateSequence).put("version","1.11.94").put("size",500).put("sha256","a".repeat(64)).put("bundlePath","/api/bundle/00000000-0000-0000-0000-000000000000");
UpdateManifest.validate(candidate,"com.tiagolima.agendapersonal");check(UpdateManifest.newer(candidate,updateSequence-1),"Atualização nova ignorada");check(!UpdateManifest.newer(candidate,updateSequence),"Versão instalada foi oferecida de novo");
candidate.put("bridgeVersion",2);try{UpdateManifest.validate(candidate,"com.tiagolima.agendapersonal");throw new AssertionError("Bridge antiga aceita");}catch(Exception expected){}candidate.put("bridgeVersion",3).put("bundlePath","https://foreign.example/update");try{UpdateManifest.validate(candidate,"com.tiagolima.agendapersonal");throw new AssertionError("Endereço externo aceito");}catch(Exception expected){}
check(view.check.contains("__agendaNativeReleaseToken")&&view.check.contains("__agendaNativeReleaseSequence==="+updateSequence),"Versão não verificada");
Files.writeString(Path.of(args[1]),view.html.substring(view.html.indexOf("<script>window.__agendaNativeReleaseToken="),view.html.indexOf("</script>")+9)+"\n"+view.check);
Files.writeString(Path.of(args[1]+".diagnostic.html"),view.html);
manager.pageFinished();view.ready=true;manager.pageReady();check(!activity.prefs.getBoolean("pending",true),"Abertura confirmada não registrada");
check(Toast.shown.stream().filter(s->s.startsWith("Atualização aplicada")).count()==1,"Sucesso não ligado à confirmação");
int accepted=view.loads;Handler.fire();check(view.loads==accepted,"Timer antigo desfez versão confirmada");
before=view.loads;view.ready=false;apply(manager,bundle(updateSequence+1,"nova-versão-B"));view.awaitLoads(before+1);manager.pageFinished();Handler.fire();view.awaitLoads(before+2);
check(view.html.contains("nova-versão-A")&&!view.html.contains("nova-versão-B"),"Falha não voltou à versão anterior");
check(view.html.contains("__agendaNativeReleaseSequence="+updateSequence),"Identificação da recuperação incorreta");
check(view.html.contains("localStorage.clear()"),"Restauração não incorporada");
String marker="var b=atob('",encoded=view.html.substring(view.html.indexOf(marker)+marker.length());encoded=encoded.substring(0,encoded.indexOf("'"));
check(new String(java.util.Base64.getDecoder().decode(encoded),java.nio.charset.StandardCharsets.UTF_8).equals(view.snapshot),"Snapshot UTF-8 não restaurado integralmente");
check(activity.prefs.getBoolean("restoreData",false),"Restauração confirmada prematuramente");
view.ready=true;manager.pageReady();check(!activity.prefs.getBoolean("restoreData",true),"Restauração não confirmada");
int after=view.loads;apply(manager,bundle(updateSequence-1,"nova-versão-A"));((java.util.concurrent.ExecutorService)field(manager,"executor")).submit(()->{}).get(5,java.util.concurrent.TimeUnit.SECONDS);check(view.loads==after,"Conteúdo idêntico com sequência da base foi reinstalado");apply(manager,bundle(2,"nova-versão-A"));((java.util.concurrent.ExecutorService)field(manager,"executor")).submit(()->{}).get(5,java.util.concurrent.TimeUnit.SECONDS);check(view.loads==after,"Conteúdo idêntico com sequência menor foi reinstalado");
apply(manager,bundle(updateSequence+1,"interrompida"));view.awaitLoads(after+1);check(activity.prefs.getBoolean("pending",false),"Interrupção sem marcador");
manager.destroy();UpdateManager reopened=new UpdateManager(activity,view);
view.reader=reopened::localResponse;
try{reopened.openPage(Uri.parse(home));view.awaitLoads(after+2);check(view.html.contains("nova-versão-A"),"Reabertura não recuperou a última versão confirmada");check(home.equals(view.base),"Origem alterada após recuperação");}finally{reopened.destroy();}
Path migrationFolder=Files.createTempDirectory("agenda-migration-fixture-");MainActivity legacyActivity=new MainActivity(migrationFolder.toFile(),root.resolve("app/src/main/assets"));WebView legacyView=new WebView();UpdateManager migration=new UpdateManager(legacyActivity,legacyView);legacyView.reader=migration::localResponse;
try{
 migration.start();legacyView.awaitLoads(1);check(legacyView.base.equals("file:///android_asset/index.html"),"Origem antiga não consultada");check(legacyView.html.length()<2048&&!legacyView.html.contains("localStorage.clear"),"Migração apagou dados ou carregou HTML gigante");
 String data="{\"agendaPersonalTL_v1\":\"alunos-preservados-á\",\"tiago-lima-avaliacoes-v1\":\"fotos-preservadas\"}";
 migration.captureLegacyStorage(data);legacyView.awaitLoads(2);check(Files.readString(migrationFolder.resolve("updates/legacy-storage.json")).equals(data),"Backup antigo incompleto");check(legacyView.html.contains("if(localStorage.getItem(k)===null)"),"Importação pode substituir dados novos");
 check(!legacyActivity.prefs.getBoolean("legacyImported",false),"Migração confirmada antes da abertura");
 Files.writeString(Path.of(args[1]+".migration.html"),legacyView.html);legacyView.ready=true;migration.pageReady();check(legacyActivity.prefs.getBoolean("legacyImported",false),"Migração não confirmada");
 migration.start();legacyView.awaitLoads(3);check(!legacyView.html.contains("window.__agendaLegacyImported=true"),"Dados antigos reimportados após confirmação");
}finally{migration.destroy();}
Path deliveryFolder=Files.createTempDirectory("agenda-four-pages-");MainActivity deliveryActivity=new MainActivity(deliveryFolder.toFile(),root.resolve("app/src/main/assets"));WebView deliveryView=new WebView();UpdateManager delivery=new UpdateManager(deliveryActivity,deliveryView);deliveryView.reader=delivery::localResponse;
try{
 delivery.openPage(Uri.parse(home));deliveryView.awaitLoads(1);JSONObject pages=new JSONObject();for(String name:new String[]{"index.html","professor.html","avaliacoes.html","cadastro.html"})pages.put(name,Files.readString(root.resolve("app/src/main/assets/"+name)));
 String realIndex=pages.getString("index.html");int insertion=realIndex.lastIndexOf("</body>");pages.put("index.html",realIndex.substring(0,insertion)+"<span hidden>native-identity-test</span>"+realIndex.substring(insertion));JSONObject webRelease=bundle(updateSequence,"conteúdo real").put("files",pages);apply(delivery,webRelease);deliveryView.awaitLoads(2);check(deliveryActivity.prefs.getBoolean("pending",false),"Pacote real confirmado antes da abertura");
 check(deliveryView.html.contains("id=\"apPasswordVisibility\"")&&deliveryView.html.contains("resetPassword:"),"Controles novos não entregues");check(!deliveryView.html.contains("Acesso de teste:"),"Rodapé antigo ainda entregue");
 check(new String(delivery.localResponse(Uri.parse(LocalPages.ORIGIN+"/assets/professor.html")).data.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8).equals(pages.getString("professor.html")),"Professor da atualização não servido");
 deliveryView.ready=true;delivery.pageReady();check(!deliveryActivity.prefs.getBoolean("pending",true),"Pacote real não confirmado");
}finally{delivery.destroy();}
System.out.println("Atualizações nativas: carregamento direto, URLs e parâmetros, base instalada, voltar, snapshot, rejeição de confirmação antiga, sucesso após abertura, rollback, downgrade e recuperação após interrupção verificados.");
}finally{manager.destroy();}
} }
''',
}


def main():
    java = shutil.which('java')
    javac = shutil.which('javac')
    if not java:
        raise SystemExit('Java 17 é necessário para estes testes.')
    compiler = [javac] if javac else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-native-tests-') as temporary:
        work = Path(temporary)
        sources = []
        for name, content in STUBS.items():
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding='utf-8')
            sources.append(str(target))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/AndroidInstaller.java'))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateManager.java'))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateStorage.java'))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateExport.java'))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateDownloads.java'))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateIdentity.java'))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/NativeLaunch.java'))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/LocalPages.java'))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateManifest.java'))
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + sources, check=True)
        probe = work / 'readiness.txt'
        subprocess.run([java, '-cp', str(work / 'classes'), 'com.tiagolima.agendapersonal.NativeUpdateHarness', str(PROJECT), str(probe)], check=True)
        subprocess.run(['node', '-e', r'''const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const text=fs.readFileSync(process.argv[1],'utf8'),html=text.slice(0,text.indexOf('</script>')+9),check=text.slice(text.indexOf('</script>')+9).trim();
const window={};vm.runInNewContext(html.slice(8,-9),{window});assert.equal(vm.runInNewContext(check,{window}),true);
window.__agendaNativeReleaseToken='outra-página';assert.equal(vm.runInNewContext(check,{window}),false);
vm.runInNewContext(html.slice(8,-9),{window});window.__agendaNativeReleaseSequence=2;assert.equal(vm.runInNewContext(check,{window}),false);
vm.runInNewContext(html.slice(8,-9),{window});window.__agendaBootFailed=true;assert.equal(vm.runInNewContext(check,{window}),false);
window.__agendaBootFailed=false;window.__agendaRestoreFailed=true;assert.equal(vm.runInNewContext(check,{window}),false);
console.log('Expressão real de confirmação: token, sequência, erro de abertura e erro de restauração verificados.');''', str(probe)], check=True)
        subprocess.run(['node', '-e', r'''const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const html=fs.readFileSync(process.argv[1]+'.diagnostic.html','utf8');
const code=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].find(m=>m[1].includes("window.addEventListener('error'"))[1];
let handler,errors=[],messages=[];
const window={addEventListener:(name,fn)=>handler=fn,Android:{bootFailed:code=>errors.push(code)},toast:msg=>messages.push(msg)};
vm.runInNewContext(code,{window,Android:window.Android});
handler({error:null,lineno:1});assert.equal(errors.length,0);
handler({error:Error('startup'),lineno:17});assert.deepEqual(errors,['AP-JS-17']);assert.equal(window.__agendaBootFailed,true);
window.__agendaBootFailed=false;window.__agendaNativeBootReady=true;
handler({error:Error('action'),lineno:3786});assert.equal(errors.length,1);assert.equal(window.__agendaBootFailed,false);assert.equal(messages.length,1);
console.log('Diagnóstico real: erro de abertura bloqueia o início; erro posterior não encobre o app nem invalida a versão confirmada.');''', str(probe)], check=True)
        subprocess.run(['node', '-e', r'''const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const html=fs.readFileSync(process.argv[1]+'.migration.html','utf8');const code=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].find(m=>m[1].includes('window.__agendaLegacyImported=true'))[1];
const data=new Map([['agendaPersonalTL_v1','dados-mais-novos']]),window={};
vm.runInNewContext(code,{window,atob,Uint8Array,TextDecoder,localStorage:{getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)}});
assert.equal(window.__agendaLegacyImported,true);assert.equal(data.get('agendaPersonalTL_v1'),'dados-mais-novos');assert.equal(data.get('tiago-lima-avaliacoes-v1'),'fotos-preservadas');
assert.ok(!window.__agendaRestoreFailed);console.log('Migração real em JavaScript: backup UTF-8, importação única e dados novos preservados.');''', str(probe)], check=True)


if __name__ == '__main__':
    main()
