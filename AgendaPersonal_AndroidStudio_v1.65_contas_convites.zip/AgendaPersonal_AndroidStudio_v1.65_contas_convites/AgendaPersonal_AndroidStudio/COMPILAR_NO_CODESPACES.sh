#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! grep -q "versionName '1.118'" app/build.gradle; then
  echo "Este projeto não é a versão 1.118. Confirme que substituiu o ZIP e extraiu o arquivo novo."
  exit 1
fi
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_HOME=/home/codespace/android-sdk
AGENDA_GRADLE_EXEC=/workspaces/Personal-Tiago/app/AgendaPersonal_AndroidStudio/gradle-8.9/bin/gradle
if [ ! -f "$AGENDA_GRADLE_EXEC" ]; then
  echo "O Gradle não foi encontrado no caminho usado nas compilações anteriores."
  exit 1
fi
bash "$AGENDA_GRADLE_EXEC" assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk /workspaces/Personal-Tiago/AgendaPersonal-v1.118.apk
echo "APK gerado: /workspaces/Personal-Tiago/AgendaPersonal-v1.118.apk"
