'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const {chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{if(req.url!=='/professor.html'){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,'professor.html')))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const ctx=await browser.newContext({viewport:{width:390,height:844},timezoneId:'America/Cuiaba',isMobile:true,hasTouch:true});await ctx.route(/^https:\/\//,r=>r.abort());
  await ctx.addInitScript(()=>{
   if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[{id:'s',name:'Aluno de teste',studentType:'presencial',financeEnabled:false}],lessons:[{id:'weekly',studentId:'s',date:'2026-10-12',time:'17:55',duration:60,repeat:'weekly',repeatDays:[1,3,5],lead:15},{id:'once',studentId:'s',date:'2026-10-20',time:'17:30',duration:60,repeat:'none',repeatDays:[]}],occurrenceStatus:{},history:[],workoutPlans:[],customData:{keep:9}}));
   window.Android={syncLessonAlarms(){return true}};
  });
  const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.clock.install({time:new Date('2026-10-17T00:56:58Z')});await page.goto('http://127.0.0.1:'+server.address().port+'/professor.html');
  const original=await page.evaluate(()=>JSON.stringify({lessons:state.lessons,students:state.students,workoutPlans:state.workoutPlans}));
  await page.evaluate(()=>{showScreen('availability');switchAvailabilityView('consult')});
  assert.equal(await page.locator('#availabilityMonth').count(),0,'no month selection required');assert.equal(await page.locator('[data-availability-month]').getAttribute('data-availability-month'),'2026-10');assert.equal(await page.locator('#availabilityResult .availability-row').count(),31,'whole current month on first opening, including earlier dates');
  async function query(month){await page.clock.setFixedTime(new Date(month+'-16T16:00:00Z'));await page.locator('#availabilityStart').fill('17:55');await page.locator('#availabilityEnd').fill('18:55');await page.locator('#availabilityTimeForm').getByRole('button',{name:'Consultar mês atual',exact:true}).click()}
  async function rows(){return page.locator('#availabilityResult .availability-row').evaluateAll(nodes=>nodes.map(n=>({date:n.dataset.availabilityDate,status:n.dataset.availabilityStatus,title:n.querySelector('strong').textContent})))}
  await query('2026-10');
  let result=await rows();assert.equal(result.length,31);
  for(const [date,status] of Object.entries({'2026-10-18':'free','2026-10-19':'busy','2026-10-20':'busy','2026-10-21':'busy','2026-10-22':'free','2026-10-16':'busy','2026-10-17':'free'}))assert.equal(result.find(r=>r.date===date).status,status);
  assert.match(await page.locator('#availabilityResult .availability-summary').innerText(),/21 dias livres/);assert.match(await page.locator('[data-availability-month]').innerText(),/Outubro de 2026 · 31 dias/);
  for(const [month,count] of [['2026-02',28],['2028-02',29],['2100-02',28],['2000-02',29],['2026-04',30],['2026-10',31],['2026-12',31],['2027-01',31]]){
   await query(month);result=await rows();assert.equal(result.length,count);assert.equal(new Set(result.map(r=>r.date)).size,count);
   assert.deepEqual(await page.locator('[data-availability-weekday]').evaluateAll(nodes=>nodes.map(n=>Number(n.dataset.availabilityWeekday))),[0,1,2,3,4,5,6]);
   const expected=Array.from({length:count},(_,i)=>month+'-'+String(i+1).padStart(2,'0'));assert.deepEqual(result.map(r=>r.date).sort(),expected);assert.equal(await page.locator('[data-availability-month]').getAttribute('data-availability-month'),month);
   for(let day=0;day<7;day++){const dates=await page.locator('[data-availability-weekday="'+day+'"] .availability-row').evaluateAll(nodes=>nodes.map(n=>n.dataset.availabilityDate));assert.deepEqual(dates,[...dates].sort());assert.ok(dates.every(d=>new Date(d+'T12:00:00').getDay()===day))}
  }
  assert.equal(await page.evaluate(()=>availabilityMonthRange('2026-13')),null);assert.equal(await page.evaluate(()=>availabilityMonthRange('2026-2')),null);
  await query('2026-10');
  await page.locator('[data-availability-date="2026-10-18"] .availability-action').click();assert.equal(await page.locator('#lessonDate').inputValue(),'2026-10-18');assert.equal(await page.locator('#lessonTime').inputValue(),'17:55');await page.evaluate(()=>closeDialog('lessonDialog'));
  await page.evaluate(()=>{state.occurrenceStatus['weekly|2026-10-19']='cancelada';renderAvailability()});assert.equal((await rows()).find(r=>r.date==='2026-10-19').status,'free');assert.equal((await rows()).find(r=>r.date==='2026-10-21').status,'busy');
  await page.evaluate(()=>{delete state.occurrenceStatus['weekly|2026-10-19'];switchAvailabilityView('weekly')});
  const monthDates=()=>page.locator('#automaticAvailabilityWeek>.automatic-availability-day').evaluateAll(nodes=>nodes.map(n=>n.dataset.date));
  async function checkOverview(month,count){const dates=await monthDates();assert.equal(dates.length,count);assert.deepEqual([...dates].sort(),Array.from({length:count},(_,i)=>month+'-'+String(i+1).padStart(2,'0')));const dayOrder=dates.map(d=>new Date(d+'T12:00:00').getDay());assert.deepEqual(dayOrder,[...dayOrder].sort());assert.match(await page.locator('#automaticAvailabilityWeekRange').innerText(),new RegExp('^01/'+month.slice(5)+' – '+count+'/'+month.slice(5)+'/'+month.slice(0,4)+'$'))}
  await checkOverview('2026-10',31);assert.ok(await page.locator('#automaticAvailabilityWeekReset').isHidden());
  assert.match(await page.locator('.automatic-availability-day[data-date="2026-10-19"] summary').innerText(),/1 aula/);assert.match(await page.locator('.automatic-availability-day[data-date="2026-10-20"] summary').innerText(),/1 aula/);
  const day=page.locator('.automatic-availability-day[data-date="2026-10-18"]');await day.locator('summary').click();await day.getByRole('button',{name:/Agendar 60 minutos/}).first().click();assert.equal(await page.locator('#lessonDate').inputValue(),'2026-10-18');await page.evaluate(()=>closeDialog('lessonDialog'));
  await page.getByRole('button',{name:'Próximo mês na disponibilidade',exact:true}).click();await checkOverview('2026-11',30);
  await page.getByRole('button',{name:'Mês anterior na disponibilidade',exact:true}).click();await checkOverview('2026-10',31);assert.ok(await day.getAttribute('open')!==null,'expansion retained per month');
  await page.getByRole('button',{name:'Mês anterior na disponibilidade',exact:true}).click();await checkOverview('2026-09',30);await page.locator('#automaticAvailabilityWeekReset').click();await checkOverview('2026-10',31);
  for(const [month,count]of [['2026-02',28],['2028-02',29],['2100-02',28],['2000-02',29],['2026-04',30],['2026-12',31]]){await page.clock.setFixedTime(new Date(month+'-16T16:00:00Z'));await page.evaluate(()=>changeAutomaticAvailabilityWeek(0));await checkOverview(month,count)}
  await page.getByRole('button',{name:'Próximo mês na disponibilidade',exact:true}).click();await checkOverview('2027-01',31);await page.getByRole('button',{name:'Mês anterior na disponibilidade',exact:true}).click();await checkOverview('2026-12',31);
  await page.clock.setFixedTime(new Date('2026-10-16T16:00:00Z'));await page.evaluate(()=>changeAutomaticAvailabilityWeek(0));
  await page.evaluate(()=>{switchAvailabilityView('consult');setAvailabilityQueryMode('day');automaticAvailabilityRangeEdited=true});await page.locator('#availabilityDate').fill('2026-10-20');await page.locator('#availabilityDayStart').fill('06:00');await page.locator('#availabilityDayEnd').fill('22:00');await page.locator('#availabilityDayForm').getByRole('button',{name:'Buscar horários deste dia'}).click();
  const slots=await page.locator('#availabilityResult [data-slot-start]').evaluateAll(nodes=>nodes.map(n=>n.dataset.slotStart));assert.ok(slots.length);assert.deepEqual(slots,[...slots].sort());
  await page.evaluate(()=>setAvailabilityQueryMode('time'));await query('2028-02');await page.evaluate(()=>{showScreen('today');showScreen('availability');switchAvailabilityView('consult')});assert.equal(await page.locator('[data-availability-month]').getAttribute('data-availability-month'),'2028-02');assert.equal((await rows()).length,29,'current month computed again on screen navigation');
  await page.clock.setSystemTime(new Date('2026-11-01T03:59:58Z'));await page.evaluate(()=>updateClock());assert.equal(await page.locator('[data-availability-month]').getAttribute('data-availability-month'),'2026-10','still October before local midnight');await page.clock.runFor(35000);assert.equal(await page.locator('[data-availability-month]').getAttribute('data-availability-month'),'2026-11','rolls automatically when local month changes');assert.equal((await rows()).length,30);
  await page.clock.setFixedTime(new Date('2027-01-01T16:00:00Z'));await page.evaluate(()=>document.dispatchEvent(new Event('visibilitychange')));assert.equal(await page.locator('[data-availability-month]').getAttribute('data-availability-month'),'2027-01','foreground refresh uses current month after year change');await query('2026-10');
  for(const mode of ['light','dark']){await page.evaluate(mode=>AgendaAppearance.setMode(mode),mode);for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'fits '+width+' '+mode)}}
  assert.equal(await page.evaluate(()=>JSON.stringify({lessons:state.lessons,students:state.students,workoutPlans:state.workoutPlans})),original);assert.equal(await page.evaluate(()=>state.customData.keep),9);
  await page.setViewportSize({width:390,height:844});await page.evaluate(()=>AgendaAppearance.setMode('dark'));
  await page.locator('#availabilityResult').evaluate(el=>window.scrollTo(0,el.getBoundingClientRect().top+scrollY-135));await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/availability-weekday-groups.png'});
  await page.locator('#availabilityTimeForm').scrollIntoViewIfNeeded();await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/availability-month-selector.png'});
  assert.deepEqual(errors,[]);console.log('PASS: whole current month automatically without a month selector; exactly 28/29/30/31 days, leap/century years, local midnight month rollover and foreground year change, Sunday–Saturday groups, free/busy/one-off/cancelled states, scheduling target, full-month overview navigation, exact month bounds, leap/century and year transitions, weekday order and scheduling, day navigation, light/dark 320–480px and records preserved. Browser real; Android/network simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(error=>{console.error(error);server.close();process.exitCode=1});
