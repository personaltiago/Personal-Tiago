# Balão próximo ao pet — 1.12.117

O balão acompanha a boca do animal, em vez da lateral direita do cenário. A posição considera cada espécie e fase, mantendo o texto inteiro dentro do cenário. A pontinha termina a poucos pixels da boca e permanece unida à borda arredondada.

Filhote 70%, adolescente 85% e adulto 100% preservados. O recado permanece visível sem abrir janela. Nenhuma alteração de progresso, moedas, itens ou dados.

Conteúdo 1.12.117, sequência 223, base Android 1.157. Atualização normal e ZIP no nome padrão.
