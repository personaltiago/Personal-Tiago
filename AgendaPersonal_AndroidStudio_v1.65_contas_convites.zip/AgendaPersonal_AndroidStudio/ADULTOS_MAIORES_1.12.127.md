# Adultos maiores — conteúdo 1.12.127 / sequência 233

Somente a fase adulta foi ampliada. No painel de professor e aluno, o fator externo passa de 1,18 para 1,60: aumento de 35,6% em cada dimensão sobre o adulto anterior. O desenho inteiro é preservado, inclusive o urso com quatro patas aprovado na 1.12.126.

| Superfície | Adulto anterior | Adulto atual |
| --- | --- | --- |
| Painel, tela até 360 px | 103,84 px | 140,80 px |
| Painel, celular maior | 132,16 px | 179,20 px |
| Painel, tela a partir de 700 px | 151,04 px | 204,80 px |
| Janela do mascote, limite máximo | 259,60 px | 352,00 px |
| Recado de treino, tela até 360 px | 66,08 px | 89,60 px |
| Recado de treino, celular maior | 75,52 px | 102,40 px |

Na janela do mascote, o tamanho efetivo depende da largura disponível: o adulto pode aproveitar 20 px extras da área interna do cenário, com no mínimo 4 px de margem para o fundo, e continua centralizado. Não se força um tamanho que corte a imagem ou ultrapasse a tela. O balão mantém o posicionamento acima da cabeça e o cenário reserva a altura necessária.

Filhotes e adolescentes mantêm os mesmos tamanhos internos e externos. As miniaturas das opções de cores e poses continuam cabendo nos cartões. Não foram redesenhados os animais nem alteradas as pelagens, poses, XP, moedas, metas, compras, históricos ou dados dos alunos. A aba Cuidar continua removida.

As verificações locais conferem professor e aluno, fases e poses, dimensões e limites dos cenários, balão, navegação e preservação dos registros. Navegador com autenticação e serviços externos simulados; não houve compilação de novo APK.

Importe AgendaPersonal-1.12.127.agenda.json pelo fluxo normal de atualização. O pacote já inclui as correções anteriores. O código conserva o nome padrão AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip e a base Android 1.157.
