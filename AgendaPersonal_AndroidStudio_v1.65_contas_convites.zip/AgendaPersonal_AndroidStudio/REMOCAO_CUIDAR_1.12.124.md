# Remoção de Cuidar — 1.12.124 / sequência 230

A personalização do mascote contém somente Cores, Casa, Loja e Histórico. Foram retirados a aba Cuidar, seus cartões de comida e brinquedo, o código de apresentação e os estilos específicos sem outros consumidores. A abertura padrão agora seleciona Cores; chamadas antigas para Cuidar também abrem Cores com segurança. A navegação por teclado percorre as quatro abas. O reposicionamento do balão após mudanças de tamanho é agendado para o próximo quadro para evitar ciclos do ResizeObserver.

O inventário antigo permanece armazenado para preservar compras e compatibilidade com backups. Não há conversão de itens nem débito, estorno ou ajuste de moedas. Poses, pelagens, casas, XP, metas, recompensas, históricos e dados dos alunos permanecem no mesmo formato. As funções de leitura de itens antigos no modelo foram mantidas para compatibilidade; a interface de cuidados foi removida.

Atualização normal: AgendaPersonal-1.12.124.agenda.json. Não requer desinstalação nem novo APK. O projeto de compilação conserva o nome AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip, a identidade do aplicativo e a base Android 1.157.

Verificação local: abertura e navegação nas quatro abas para professor e aluno, ausência da interface de cuidados, preservação de inventário antigo, compra e troca de poses, persistência e falhas de salvamento. Navegador Chromium com autenticação e serviços externos simulados; nenhum novo APK foi compilado nesta revisão.
