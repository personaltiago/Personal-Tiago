# Poses dos mascotes — conteúdo 1.12.123 / sequência 229

A aba Loja oferece a posição original gratuita e três novas poses próprias por espécie. Cada compra desbloqueia a pose para aquela espécie, em todas as pelagens e nas três fases. Comprar aplica a pose imediatamente; trocar uma pose já adquirida é gratuito. O saldo é debitado uma única vez.

| Animal | 80 moedas | 120 moedas | 180 moedas |
| --- | --- | --- | --- |
| Lobo | Sentado | Deitado | Barriga para cima |
| Gato | Sentado | Enroladinho | Barriga para cima |
| Panda | Sentado | De ladinho | Barriga para cima |
| Capivara | Sentada | Descansando | Espreguiçando |
| Jacaré | Esfinge | Relaxando | Brincando |
| Galo | Descansando | Asas abertas | Cantando |

As 18 novas poses possuem 288 desenhos transparentes: 32 pelagens × três fases × três poses. O jacaré brinca de barriga para cima; o galo tem poses adequadas às suas asas e ao canto. A posição escolhida é lembrada por espécie e por conta. A posição original continua disponível.

Comidas e brinquedos ficam em Cuidar, inclusive a compra de comida. Itens, roupas e casas já adquiridos permanecem no inventário. A alteração não modifica os dados de alunos, treinos em andamento, históricos, cargas, agenda, financeiro, links ou recompensas. O backup completo inclui poses e aquisições, junto dos demais dados já suportados.

Foram mantidos os tamanhos distintos das três fases e o aumento de 18% para adultos. O balão continua acima e próximo da cabeça; suas âncoras acompanham cada pose. As pelagens naturais da versão 1.12.122 permanecem disponíveis.

## Atualização e compilação

Importe AgendaPersonal-1.12.123.agenda.json pelo fluxo normal de atualização de conteúdo do aplicativo. Esta alteração não exige desinstalação nem novo APK. O ZIP de código conserva o nome padrão AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip e a base Android 1.157; ele permite compilar pelo fluxo já existente com a mesma assinatura. Não foi compilado um novo APK nesta revisão.

## Tamanho

As imagens novas usam recortes WebP transparentes de 240 × 240. Dois atlas de ícones existentes foram recompactados em WebP, preservando dimensões e alfa, e o logotipo usa WebP sem perdas. Nenhuma função foi removida para reduzir espaço. Os hashes dos originais e dos derivados estão em web/compact-artwork/manifest.json; os HTML de referência preservam as fontes originais.

## Verificação

Os testes locais usam Chromium com autenticação e rede simuladas. Conferem compras reais pelas interfaces de professor e aluno, troca gratuita, persistência após reabrir, falha de armazenamento sem perda de saldo, isolamento entre contas e preservação de treinos e históricos. Também verificam os 288 sprites contra seus hashes, as três fases, alinhamento do balão, layouts móveis e cache de pose/pelagem. Há testes de restauração do backup completo com as poses compradas.

A validação local não equivale a teste de instalação em um telefone físico. O pacote final é conferido pelas ferramentas de integridade e pelos limites do importador normal.
