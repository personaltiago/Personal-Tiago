# Conteúdo 1.12.137 / sequência 243

Um toque curto no fundo do cenário agora direciona a cabeça do mascote ao
ponto tocado. A posição é convertida pela matriz real da imagem, incluindo
espelhamento, escala da fase e posição no iframe do professor. A cabeça
inclina e se desloca suavemente em direção ao alvo, segura a posição e volta
à pose salva. Um novo toque redireciona a mesma camada a partir da posição
atual, sem trocar a imagem nem piscar.

O toque simples no corpo deixa a curiosidade mais visível: inclinação máxima
de 10 graus e pequeno movimento local da cabeça. Orelha, nariz, rabinho,
dois toques e carinho continuam separados. A região inferior e as patas
ficam fixas. As reações utilizam as texturas existentes com máscaras no
pescoço e transformações SVG locais; não são novas imagens tridimensionais
de cada orientação. Não há filtros de deformação nem fades na curiosidade.

Tocar no balão, nome, controles ou Casa não aciona o olhar do cenário.
Arrastar o fundo continua sendo rolagem; não produz carinho nem olhar.
Somente Casa abre a loja. Movimento reduzido usa uma posição estática breve.
Cancelamento, saída de conta e ocultação da página removem as reações.
Não há mudanças em dados de alunos, treinos, moedas, XP, compras ou arquivos
de arte. A correção da preparação da publicação da versão 1.12.136 permanece.
Compatível com atualização normal no APK existente; Android 1.158 mantido.

Verificação local: Chromium com páginas completas de professor e aluno;
54 combinações de espécie, fase, pose e papel, 216 quadros direcionais;
30 casos de curiosidade e 150 quadros com pés fixos; 12 contatos CDP para
toque simples, mouse de compatibilidade, dois toques, ponta do rabinho,
cancelamento, carregamento lento e atualização da interface. O teste de
protesto confere 66 configurações e 264 quadros sem deformação nas patas.
Os testes comparam pixels, geometria, restauração da pose e dados gravados.
O preparo da publicação usa o pacote real e confirmação de hash simulada.
Nenhum APK novo foi compilado e nenhuma versão externa foi publicada.
