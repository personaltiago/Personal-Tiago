# Acesso Google — Android 1.163 e conteúdo 1.12.184

Esta alteração implementa o botão de acesso Google. Não basta esconder o aviso.

## O que foi implementado

- O Android abre a escolha de conta pelo Credential Manager, fora da página WebView.
- O token Google é entregue apenas à página principal e trocado por uma sessão Firebase usando o mesmo cliente de autenticação da agenda.
- O aplicativo continua conferindo o UID exato do professor. Alunos continuam precisando de cadastro vinculado ao professor e aprovação ativa. Não há liberação por comparação de endereço de e-mail.
- Cancelamento, resposta atrasada, toque duplo, saída durante a autenticação e erro de configuração não concedem acesso.
- O provedor nativo recebe um nonce aleatório. O retorno deve corresponder ao projeto e à solicitação. A assinatura do token e a autenticação são verificadas pelo Firebase, não pela leitura local do token.
- A saída encerra a sessão Firebase e limpa o estado de escolha de conta do Credential Manager. Tokens Google não são guardados em um cache próprio, em arquivos ou em logs.
- No navegador, o botão usa o popup do Firebase; o resolvedor de popup só é usado no clique, sem criar iframe de autenticação na abertura a frio.
- O SDK local exporta também as funções de consulta e aprovação necessárias à aba Contatos da atualização 1.12.182.

## Bloqueio confirmado em 30/10/2026

O endpoint público do projeto `agenda-personal-bdb58`, consultado com o mesmo identificador público já usado pelo aplicativo, respondeu a `accounts:createAuthUri` para `google.com`:

`OPERATION_NOT_ALLOWED : The identity provider configuration is not found.`

Portanto, o provedor Google ainda não estava ativado nessa consulta. Não houve login real, criação de usuário, alteração de contas nem escrita no banco nessa verificação. Esta implementação não deve ser apresentada como login já validado no celular antes de concluir a configuração abaixo.

## Configuração necessária no Firebase

1. No projeto **agenda-personal-bdb58**, abrir **Authentication → Método de login → Google**, ativar o provedor, informar o e-mail de suporte exigido pela tela e salvar.
2. Nas configurações do projeto, registrar ou conferir o app Android com o pacote **com.tiagolima.agendapersonal** e cadastrar a impressão SHA-1 da chave que assina o APK distribuído.
3. Gerar o APK com a mesma chave já usada, pelo fluxo existente do GitHub. Instalar como atualização e importar **AgendaPersonal-1.12.184-acesso-google.agenda.json** para atualizar o conteúdo ativo.

Impressões extraídas do certificado do APK que foi enviado nesta conversa, Android **1.151**, conteúdo **1.12.98**:

- SHA-1: `2E:F9:03:47:51:FE:38:C6:62:B0:29:1D:1A:75:FA:2B:16:12:E6:BA`
- SHA-256: `11:66:C0:B2:D3:6C:BB:22:00:6F:44:10:B6:0A:B7:A7:F4:3B:C6:F0:12:A8:F4:58:2D:AF:55:8C:73:9E:6C:11`

Conferir que o APK novo conserva esse certificado. Outra chave não atualiza a instalação existente e precisa de cadastro OAuth próprio.

O código obtém o identificador público do cliente Web diretamente da configuração Google ativada no Firebase desse projeto. Não há segredo de cliente embutido e não é preciso preencher um identificador inventado no fonte.

Para acesso pelo site, o domínio público também precisa estar autorizado na autenticação Firebase. A rota Android utiliza a credencial nativa.

## Versões e instalação

- Android: **1.163**, código local **163**. O workflow existente continua fornecendo o código crescente de distribuição.
- O nome do ZIP permanece `AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip`, exigido pelo workflow atual.
- O conteúdo base do projeto continua identificado como **1.12.146 / sequência 252**, com o acesso Google acrescentado ao processo de geração. Isso preserva a regra existente que mantém o pacote mais recente já instalado; não se promove uma base antiga a uma sequência maior.
- A atualização de conteúdo **1.12.184 / sequência 290** mantém integralmente as quatro páginas da 1.12.183, alterando somente o módulo de contas, o SDK local e o botão/status Google na página de entrada. Contatos, correções de Voltar, balões, treinos e avaliações permanecem nessa atualização.
- O APK inclui também a confirmação antes da importação implementada no Android 1.162.
- Um `.agenda.json` sozinho não acrescenta a API nativa de escolha de conta aos APKs antigos.

## Verificação

- Novas classes Java compiladas com Java 17 e os artefatos reais de Android, Credential Manager 1.3.0 e Google ID 1.1.1.
- Verificações executáveis de vínculo da solicitação em `tests/java/com/tiagolima/agendapersonal/GoogleSignInProtocolChecks.java`: cliente de outro projeto, URL externa, nonce incorreto, credencial expirada e respostas malformadas recusados.
- Aplicativo completo exercitado em Chromium com o SDK Firebase local real. Escolha de conta e respostas remotas simuladas: professor, aluno aprovado, aluno pendente, conta sem cadastro, cancelamento, provedor desativado, APK antigo, resposta tardia após sair, troca de credencial recusada e fluxo do navegador.
- Login real em um celular, configuração administrativa do Firebase e assinatura/instalação do APK final ainda dependem do ambiente do responsável.

Referências oficiais usadas:

- https://firebase.google.com/docs/auth/android/google-signin
- https://firebase.google.com/docs/auth/web/google-signin
- https://developer.android.com/identity/sign-in/credential-manager-siwg-implementation
