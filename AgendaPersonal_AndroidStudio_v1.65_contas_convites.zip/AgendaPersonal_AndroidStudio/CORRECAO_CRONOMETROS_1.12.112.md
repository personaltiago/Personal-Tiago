# Correção dos cronômetros no APK antigo

Conteúdo 1.12.112, sequência 218. Atualização normal `.agenda.json`, sem reinstalação.

## Causa e mudança

No APK 1.151, `startLessonTimer` e `startWorkoutRest` abrem as faixas nativas grandes como efeito da programação do alarme. Retirar o botão ou a faixa HTML não impede esse serviço Android. A atualização 1.12.111 mantinha essas chamadas e por isso não resolvia as capturas do APK antigo.

A página agora identifica a ponte antiga pela ausência da propriedade booleana `dismissed` em `getTimerOverlayStatus`. Nela, cancela os registros nativos antigos carregados, preserva os prazos e a contagem JavaScript e impede as três chamadas nativas de início: aula, intervalo simples e intervalo do bi-set. Também bloqueia a reabertura manual da faixa antiga. O início do treino e seus registros continuam funcionando.

Limitação necessária nesse APK: a contagem e o som de fim ficam dentro do aplicativo aberto. A ponte antiga não permite separar seu alarme de fundo da faixa grande; não há promessa de cronômetro ou som fora do app. O APK com ponte compacta (1.157) mantém seu intervalo nativo compacto e alarmes nativos.

Alunos, fichas, séries feitas, cargas, notas, resultados, financeiro, datas e identificadores não são apagados pela migração. Os lembretes nativos de aulas e pagamentos continuam usando sua sincronização existente. Se não houver espaço para salvar a confirmação da migração, o estado atual continua em memória e a migração é tentada de novo ao carregar.

## Verificação

`tests/verify_timer_compatibility.cjs` executa a página gerada em Chromium com pontes Android simuladas que reproduzem o acionamento das faixas. Confere cancelamento da faixa existente, novos inícios, reabertura, recarga, preservação de dados, erro de armazenamento, prazo e som único. Executa também a função real de intervalo do bi-set e verifica que a ponte moderna continua programando alarmes. Não substitui um teste em aparelho físico.

As quatro páginas são geradas das fontes atuais e o JSON final é conferido com o validador do publicador instalado. Não há remoção da conferência de integridade do APK.

## Uso

Importe `AgendaPersonal-1.12.112.agenda.json` em **Mais → Atualizações**. A versão precisa indicar **1.12.112** depois da importação. Esse arquivo contém telas atualizadas, não uma restauração dos dados de aluno.

Para guardar as fontes ou compilar futuramente, o ZIP continua com o nome padrão `AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip`.
