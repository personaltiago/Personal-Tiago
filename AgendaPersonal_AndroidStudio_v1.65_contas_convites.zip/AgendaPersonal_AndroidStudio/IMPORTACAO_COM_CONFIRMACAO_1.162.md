# Android 1.162 — revisão antes de instalar

Ao importar um arquivo, o aplicativo lê e valida o pacote e apresenta:

- versão instalada e versão do arquivo;
- descrição das alterações incluída no próprio arquivo;
- informação sobre a preservação de conta, cadastros, fichas e históricos;
- botões **Sim, atualizar** e **Não, cancelar**.

Selecionar o arquivo não inicia a instalação. Cancelar, fechar a revisão ou
mudar de conta descarta a seleção. Somente a confirmação inicia a cópia de
proteção e a troca da versão. Treinos ou edições em andamento impedem a troca.

Arquivos sem descrição não são instalados. Nas atualizações publicadas, a
descrição também pode vir dos metadados conferidos da publicação.

## Ativar no celular

Esta mudança pertence ao instalador Android. Um arquivo `.agenda.json` sozinho
não consegue alterar o importador que já está instalado.

Substitua no repositório o arquivo de mesmo nome
`AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip` e execute o fluxo
**Gerar e publicar APK Agenda Personal**. Ele produz Android **1.162** com a
assinatura existente. Depois instale esse APK como atualização do aplicativo.

O conteúdo de base do APK continua na sequência 252. Uma atualização já
instalada com sequência superior, como 1.12.181 / 287, continua sendo usada.
O projeto não modifica os arquivos web nesta alteração nativa.

## Preparar os próximos arquivos

Inclua no pacote JSON o campo `notes`, como texto com até 4.000 caracteres,
descrevendo as mudanças reais daquela versão. Não reaproveite uma descrição
de outra atualização. O gerador agora exige esse texto:

```bash
node tools/build_web_update.cjs 1.12.182 288 atualizacao.agenda.json descricao.txt
```

Os números são um exemplo de uso. Use a versão e a sequência da entrega real.

## Verificação

`tests/verify_update_import_review.py` compila e executa o importador real com
substitutos das APIs Android, verificando os efeitos nos arquivos e nos dados.
Também há verificações de cancelamento, respostas atrasadas, troca de conta,
arquivo alterado depois da revisão, descrição ausente e confirmação duplicada.

Esses testes não substituem a compilação do APK nem o teste em aparelho físico.
