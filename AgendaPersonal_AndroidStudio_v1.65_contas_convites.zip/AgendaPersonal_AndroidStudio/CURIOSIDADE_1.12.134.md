# Curiosidade visível — conteúdo 1.12.134 / sequência 240

A reação anterior deslocava pouco o focinho e utilizava uma transição de opacidade ao restaurar a imagem. Isso podia parecer uma piscada, sem uma ação reconhecível.

O toque único agora inclina e ergue levemente a cabeça, mantém a posição por um instante e retorna suavemente. O ciclo dura 1,32 segundo. A cabeça usa a própria imagem da pelagem escolhida, com articulação no pescoço; corpo, patas e cenário permanecem fixos. Não há filtro de deslocamento nem transição de transparência nas reações locais. A restauração acontece quando o movimento já retornou à posição inicial.

Toques repetidos durante a mesma reação não a reiniciam. Toques na orelha e no nariz usam movimentos locais pelo mesmo mecanismo, sem o desvanecimento antigo. O modo de movimento reduzido exibe uma inclinação estática e restaura a pose normalmente. As respostas de carinho, rabinho e dois toques permanecem preservadas.

Nenhuma imagem, pelagem, compra, XP, moeda, ficha, treino ou dado do aluno foi alterado. Nenhum campo de armazenamento foi acrescentado. O projeto mantém Android 1.158; o pacote de conteúdo pode ser importado pela central normal de atualizações e não exige um APK novo para esta alteração.

## Verificação

- Trinta combinações de espécie, pose, idade e papel, com 150 quadros renderizados no professor e no aluno.
- Medição dos pixels: movimento visível da cabeça, preservação do contraste e da área visível do animal, parte inferior do corpo estacionária e retorno à imagem original.
- Toques repetidos, restauração automática, modo de movimento reduzido e preservação do estado salvo.
- Regressões de toques reais pelo protocolo CDP, rabinho, dois contatos distintos, eventos de mouse duplicados, carinho, ausência do realce azul e geometria do cenário.
- Inventário e integridade do pacote de conteúdo, compatibilidade com o importador existente e tamanho de distribuição.

Testes em Chromium local com autenticação/rede simuladas. Não foi realizada instalação ou inspeção em um aparelho Android físico nesta entrega.
