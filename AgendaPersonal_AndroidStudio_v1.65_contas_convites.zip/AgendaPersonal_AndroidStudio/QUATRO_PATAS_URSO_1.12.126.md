# Quatro patas visíveis na pose do urso — 1.12.126 / sequência 232

A pose Barriga para cima do panda/urso foi refinada para mostrar quatro patas completas e distinguíveis no tamanho real da interface. A pata dianteira que ficava junto ao peito agora aparece para fora, com almofada e dedos visíveis, separada da pata traseira. O desenho tem duas patas dianteiras e duas traseiras, sem cauda saliente nem quinto apêndice.

A correção vale para as seis pelagens e as três fases, em 18 imagens transparentes WebP de 240 × 240. Foram mantidos o rosto, o estilo, os identificadores, os nomes dos arquivos e a compra existente; a troca de imagem não desconta moedas. As outras 270 imagens de poses permanecem intactas. A aba Cuidar continua removida.

O atlas selecionado foi editado pela ferramenta integrada de imagens. O prompt está em web/mascot-poses/PROMPTS.md, seção 1.12.126. Os hashes e as âncoras do balão foram atualizados em web/mascot-poses/manifest.json. A prévia isolada da versão anterior com apenas três patas não integra o pacote.

Atualize pelo arquivo AgendaPersonal-1.12.126.agenda.json no fluxo normal do app; não é necessário compilar ou desinstalar. O ZIP conserva o nome padrão AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip e a base Android 1.157. Nenhum novo APK foi gerado.

Validação: revisão visual dos 18 recortes com quatro almofadas de patas, conferência no aplicativo, integridade das imagens, fases, posição do balão, seleção e troca de pose, compra única e persistência. Navegador local com autenticação e serviços externos simulados.
