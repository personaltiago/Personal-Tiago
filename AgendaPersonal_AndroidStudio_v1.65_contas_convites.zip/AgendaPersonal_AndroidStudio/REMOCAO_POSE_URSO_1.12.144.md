# Remoção da pose do urso — 1.12.144 / sequência 250

Retirada a pose “Barriga para cima” do urso/panda indicada na imagem `1000045256.jpg`. Ela deixa de aparecer na loja, nas escolhas e no pacote de imagens, nas seis pelagens e três fases. Removidos os 18 desenhos e seus perfis de movimento. As demais poses e os outros animais mantêm os desenhos existentes.

Uma seleção antiga dessa pose deixa de ser equipada e usa a pose original já disponível; o retrato em cache da posição retirada não corresponde mais à seleção válida. O registro de compra permanece guardado, sem alteração de moedas, XP, histórico ou cenário. A pose retirada não pode ser comprada, reaplicada ou restaurada por ações antigas.

Atualização de conteúdo, compatível com bridgeVersion 3 e dataSchema 4. Android permanece 1.158. O pacote `.agenda.json` precisa ser importado/publicado pelo fluxo existente do aplicativo; sua criação não afirma publicação no servidor. O ZIP conserva o nome padrão para substituição do projeto de compilação.
