# Carinho sem quadrado azul — 1.12.129 / sequência 235

O vídeo mostrou o destaque retangular de toque do Android sobre o pet. A área de carinho agora usa destaque transparente e impede a seleção involuntária da imagem e do texto ao segurar ou deslizar. O foco visível por teclado permanece disponível.

O ajuste se limita ao botão do cenário e seus elementos internos, no professor e no aluno. A casinha, os demais botões, o movimento de carinho, os corações, as poses e todos os dados permanecem com o comportamento anterior.

Atualização normal: AgendaPersonal-1.12.129.agenda.json, em Mais → Atualizações. Inclui a versão 1.12.128, sem recompilar APK ou desinstalar o aplicativo.
