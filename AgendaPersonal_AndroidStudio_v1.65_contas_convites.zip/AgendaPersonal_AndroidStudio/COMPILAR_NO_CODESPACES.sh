#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! grep -q "versionName '1.141'" app/build.gradle; then
  echo "Este projeto não é a versão 1.141. Confirme que substituiu o ZIP e extraiu o arquivo novo."
  exit 1
fi
if ! command -v node >/dev/null 2>&1; then
  echo "O Node.js é necessário para preparar as telas deste pacote. Use um Codespace com Node.js."
  exit 1
fi
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_HOME=/home/codespace/android-sdk
AGENDA_GRADLE_EXEC=/workspaces/Personal-Tiago/app/AgendaPersonal_AndroidStudio/gradle-8.9/bin/gradle
if [ ! -f "$AGENDA_GRADLE_EXEC" ]; then
  echo "O Gradle não foi encontrado no caminho usado nas compilações anteriores."
  exit 1
fi
bash "$AGENDA_GRADLE_EXEC" assembleDebug
AGENDA_APK_SOURCE=app/build/outputs/apk/debug/app-debug.apk
AGENDA_APK_TARGET=/workspaces/Personal-Tiago/AgendaPersonal-v1.141.apk
if [ ! -s "$AGENDA_APK_SOURCE" ]; then
  echo "A compilação não produziu um APK válido. Nenhum arquivo de instalação foi copiado."
  exit 1
fi
unzip -tqq "$AGENDA_APK_SOURCE"
trap 'rm -f "$AGENDA_APK_TARGET.partial"' EXIT
cp "$AGENDA_APK_SOURCE" "$AGENDA_APK_TARGET.partial"
cmp -s "$AGENDA_APK_SOURCE" "$AGENDA_APK_TARGET.partial"
mv -f "$AGENDA_APK_TARGET.partial" "$AGENDA_APK_TARGET"
ls -lh "$AGENDA_APK_TARGET"
echo "APK verificado: $AGENDA_APK_TARGET"
echo "No Explorador, clique com o botão direito nesse APK e escolha Baixar. Aguarde o tamanho completo; 0 B não é um download concluído."
