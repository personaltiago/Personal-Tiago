#!/usr/bin/env bash
# Compile without depending on the name or location of the Codespaces repository.
# A debug APK is NOT interchangeable with a release APK signed by a different key.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

if ! grep -q "versionName '1.102'" app/build.gradle; then
  echo "ERRO: versão do projeto diferente da revisão 1.102 prevista por este script." >&2
  exit 1
fi

# Respect Java/Android settings already configured by the user.
if ! command -v java >/dev/null 2>&1 && [ -d /usr/lib/jvm/java-21-openjdk-amd64 ]; then
  export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
  export PATH="$JAVA_HOME/bin:$PATH"
fi
if [ -z "${ANDROID_HOME:-}" ]; then
  for sdk in /home/codespace/android-sdk "$HOME/android-sdk" /opt/android-sdk /opt/android-sdk-linux; do
    if [ -d "$sdk" ]; then export ANDROID_HOME="$sdk"; break; fi
  done
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -n "${ANDROID_SDK_ROOT:-}" ]; then
  export ANDROID_HOME="$ANDROID_SDK_ROOT"
fi
if [ -z "${ANDROID_HOME:-}" ]; then
  echo "ERRO: Android SDK não localizado. Configure ANDROID_HOME e instale a plataforma Android 35." >&2
  exit 1
fi

if [ -f ./gradlew ]; then
  gradle_cmd=(bash ./gradlew)
elif command -v gradle >/dev/null 2>&1; then
  gradle_cmd=(gradle)
elif [ -f ./gradle-8.9/bin/gradle ]; then
  gradle_cmd=(bash ./gradle-8.9/bin/gradle)
elif [ -f /workspaces/Personal-Tiago/app/AgendaPersonal_AndroidStudio/gradle-8.9/bin/gradle ]; then
  gradle_cmd=(bash /workspaces/Personal-Tiago/app/AgendaPersonal_AndroidStudio/gradle-8.9/bin/gradle)
else
  echo "ERRO: Gradle não encontrado. Instale o Gradle 8.9 ou use o workflow 'Gerar APK Agenda Personal' no GitHub." >&2
  exit 1
fi

"${gradle_cmd[@]}" :app:assembleDebug
apk=app/build/outputs/apk/debug/app-debug.apk
[ -s "$apk" ] || { echo "ERRO: compilação terminou sem gerar o APK esperado." >&2; exit 1; }
output_dir="${AGENDA_OUTPUT_DIR:-$(dirname "$PWD")}"; mkdir -p "$output_dir"
output="$output_dir/AgendaPersonal-v1.102-debug.apk"
cp "$apk" "$output"
echo "APK de depuração: $output"
echo "AVISO: se o app instalado tiver assinatura release, não desinstale nem substitua pelo APK debug."
echo "Para atualizar com assinatura release, use o workflow GitHub e a mesma chave de assinatura anterior."
