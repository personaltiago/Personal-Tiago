#!/usr/bin/env bash
set -euo pipefail
AGENDA_PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 não foi encontrado neste Codespaces."
  exit 1
fi
exec python3 "$AGENDA_PROJECT_DIR/tools/build_android.py" "$@"
