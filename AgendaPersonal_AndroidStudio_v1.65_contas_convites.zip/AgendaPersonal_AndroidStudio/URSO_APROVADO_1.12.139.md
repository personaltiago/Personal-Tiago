# Conteúdo 1.12.139 / sequência 245

Integração da prévia aprovada R14 na Agenda Personal. O recorte desta entrega é o urso adulto preto, na pose Sentado; as demais fases, pelagens, poses e espécies conservam seus desenhos e comportamentos anteriores.

- Carinho: olhos fechados, movimento suave localizado e corações durante o gesto sobre o animal.
- Um toque: curiosidade, com inclinação pequena e olhar independente.
- Cenário: os olhos acompanham o ponto tocado, com retargeting contínuo.
- Dois toques: expressão fechada e patinha levantada em pose estática, sem o movimento que deformava a cabeça.
- Mesma animação nas telas do professor, do aluno e na visualização da casa. A casinha continua sendo o atalho para abrir a personalização.
- Renderização limitada à área do animal. O fundo, o balão, a escala do cenário e os pés não recebem a deformação da mão.
- Interrupção, troca de espécie/fase/cor/pose, fechamento da casa e troca de conta liberam o renderizador. Movimento reduzido apresenta a arte estática.

As quatro texturas transparentes derivam dos PNGs aprovados, convertidos para WebP de 512 pixels. A referência original de alta resolução continua no pacote independente de fontes do urso R14. `web/approved-bear/manifest.json` identifica os hashes das duas representações.

Para respeitar o limite do aplicativo sem retirar recursos: os dados de poses e carinho são empacotados em gzip e restaurados integralmente no carregamento; os scripts das telas secundárias são serializados sem comentários e espaços desnecessários, sem renomear identificadores nem otimizar instruções. Os limites de 2 MiB na entrada, 24 MiB no conteúdo e 25.000.000 bytes no ZIP continuam ativos.

Esta é uma atualização de conteúdo, com bridgeVersion 3 e dataSchema 4. Não modifica os esquemas, as rotinas de backup, os registros de alunos, cargas, treinos ativos, históricos, moedas, compras ou preferências salvas. Android permanece 1.158. Não contém novo APK nem afirma publicação no servidor.

Validação: `node tests/verify_approved_bear.cjs` testa os gestos nas telas reais de professor e aluno em Chromium com rede externa bloqueada e autenticação simulada, incluindo conservação dos dados e ausência de deformação da cena. Não substitui um teste em aparelho Android/iPhone físico.
