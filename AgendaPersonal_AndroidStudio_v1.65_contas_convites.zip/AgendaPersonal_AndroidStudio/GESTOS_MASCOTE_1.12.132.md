# Gestos do mascote — conteúdo 1.12.132 / sequência 238

Android 1.158, assinatura e identificador do aplicativo preservados. Esta entrega também gera um pacote de conteúdo para a central normal de atualizações; as reações não exigem alteração nativa.

## Comportamento

- Deslizar pelo menos 9 pixels sobre a parte visível do animal inicia carinho, com a pose de olhos fechados e corações já aprovada.
- Toque breve na orelha move apenas a região tocada; toque no nariz/focinho/bico produz uma reação curta de farejar.
- Toque no rabinho visível produz um protesto. Capivaras não recebem cauda nem área de toque fictícia; caudas ocultas pela pose não ganham uma área artificial.
- Dois toques com intervalo de até 280 ms, próximos entre si, exibem protesto e patinha levantada; o galo levanta uma asa. A reação simples aguarda 285 ms para distinguir esse gesto.
- Fundo, balão e pixels transparentes não provocam reações. A casa continua abrindo a personalização. Teclado continua permitindo carinho; movimento reduzido mantém resposta estática.
- Soltar, cancelar um gesto, trocar de conta e sair da tela não deixam uma reação presa. A pose escolhida retorna automaticamente.

## Preservação e arquivos

As 483 imagens anteriores dos mascotes permanecem byte a byte intactas. Acrescentadas 96 imagens WebP de reação: seis espécies, todas as pelagens naturais e três idades. Prompts e parâmetros de exportação estão em `web/mascot-reactions/PROMPTS.md`.

Nenhuma reação grava moedas, XP, compras, fichas, execução de treino ou dados dos alunos. O tamanho adulto e a diferença de tamanho entre as idades permanecem iguais à versão recuperada.

A folha de estilo limita a elasticidade nos contêineres de rolagem, preservando a rolagem normal sobre os cartões. Para respeitar os limites já existentes de 2 MiB na entrada e 24 MiB no pacote normal, o controlador dos gestos é carregado junto às imagens locais. PDF.js foi mantido com exatamente os mesmos bytes, compartilhando uma única cópia local entre avaliação e professor; importação offline foi testada nas duas formas de abertura.

## Validação

- 336 regiões opacas de anatomia em 144 combinações de espécie, pose, idade e papel.
- 82 toques reais no navegador, distinguindo orelha, nariz, cauda, corpo, dois toques e deslizar.
- Decodificação e SHA256 de todas as 96 novas imagens e das 96 imagens de carinho.
- 36 interações de carinho com verificação de zero gravações de dados; poses, compras, histórico e treino em aberto preservados.
- Movimento de cabeça/pescoço em 36 combinações, dois gestos de toque via CDP e geometria do cenário estável.
- Ausência do realce azul, acessibilidade por teclado, movimento reduzido e abertura pela casa.
- PDF.js original, importação real de PDF com núcleo e worker offline, professor avulso e dentro da tela principal, importação numerada e revisão de treino.
- Restauração manual de conteúdo: 64 verificações em Java; contratos de atualização nativa e compatibilidade do pacote de conteúdo.

Verificação em Chromium local, Java real com APIs Android simuladas e autenticação/rede simuladas. Não representa compilação de um APK novo nem teste físico no telefone.
