# Carinho articulado e cenário estável — 1.12.130 / sequência 236

## Mudança

O giro e o deslocamento do retrato inteiro foram retirados. A expressão existente de olhos fechados agora recebe um movimento localizado na cabeça, com transição gradual no pescoço. A parte inferior do corpo e as patas têm deslocamento zero; o contêiner do pet e o fundo não são animados. O movimento reutiliza os desenhos aprovados, sem novos recortes ou mudança de pelagem, fase ou tamanho.

A pose de carinho entra por transição de 180 ms e retorna à pose salva com transição de 220 ms. Durante o contato, o movimento segue um ciclo contínuo de 1,65 s, sem reiniciar a cada passada do dedo. Os corações têm frequência limitada. A preferência do sistema por movimento reduzido mantém a expressão parada.

O gesto fica capturado apenas sobre a imagem do pet. Deslizar ali faz carinho sem arrastar a página; o restante do cenário continua permitindo a navegação normal. A casinha continua abrindo a personalização. O destaque azul permanece removido.

O alinhamento do balão não recalcula a altura do cenário durante a reação. As dimensões da imagem e do cartão permanecem fixas, evitando o esticamento visto no vídeo.

## Compatibilidade e dados

Arquivo normal AgendaPersonal-1.12.130.agenda.json, em Mais → Atualizações, compatível com o contrato Android existente. Não exige compilar outro APK para esta mudança de carinho.

O projeto completo mantém a correção nativa de restauração do Android 1.158. Essa correção anterior continua dependendo da instalação do APK corrigido; importar este arquivo de telas não modifica Java nativo.

Nenhum cadastro, ficha, carga, progresso, link, histórico, moeda ou pose comprada é regravado pela interação. Os 96 desenhos de carinho e os 288 sprites de poses anteriores permanecem idênticos.

## Preparação e validação

Para preservar o limite nativo de 2 MiB da página de entrada, a serialização de dois módulos existentes também encurta apenas identificadores locais: ap-watch-model e ap-student-accounts. Não há otimização de instruções nem alteração de propriedades públicas. Os testes de persistência/login e de treino/histórico do relógio foram executados sobre as páginas geradas.

Verificações de movimento com Chromium móvel: seis espécies, três fases, professor e aluno; dimensões fixas; gestos reais de toque via CDP; movimento reduzido; liberação do gesto e retorno à pose salva. A comparação dos quadros verifica movimento na região superior e patas paradas. Autenticação e rede são simuladas; o APK e o aparelho físico não foram usados nesses testes.
