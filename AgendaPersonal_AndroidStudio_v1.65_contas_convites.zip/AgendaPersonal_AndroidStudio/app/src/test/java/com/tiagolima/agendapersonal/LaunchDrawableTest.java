package com.tiagolima.agendapersonal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;

/**
 * Draw the compiled XML with Android's real resource loader and native Canvas.
 * The previous XML had the right literal dp values but rendered almost twice
 * as large after the system's cached splash icon was scaled. This test covers
 * that system path, rather than only comparing strings in the XML.
 *
 * System rendering contract:
 * AOSP SplashscreenIconDrawableFactory: AdaptiveForegroundDrawable and
 * ImmobileIconDrawable; SplashscreenContentDrawer: no-background icon scale.
 * https://android.googlesource.com/platform/frameworks/base/+/f68c80b4e9dbdb1e5bf6620f437c3d9f865eb047/libs/WindowManager/Shell/src/com/android/wm/shell/startingsurface/SplashscreenIconDrawableFactory.java
 */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = {31, 35})
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class LaunchDrawableTest {
    private static final int[] DENSITIES = {120, 160, 213, 240, 320, 420, 480, 560, 640};

    @Test public void systemSplashMatchesNativeLoaderAfterAndroidScaling() {
        for (int dpi : DENSITIES) {
            Context context = contextAtDensity(dpi);
            Resources resources = context.getResources();
            Drawable splash = resources.getDrawable(R.drawable.launch_splash_icon, null);
            int expected = resources.getDimensionPixelSize(R.dimen.launch_logo_size);
            Rect systemBounds = opaqueBounds(drawSystemSplash(resources, splash));
            Rect nativeBounds = opaqueBounds(drawNativeLogo(context, expected));

            // Android rounds the cached foreground and each fractional inset
            // to physical pixels before scaling. Allow at most 3 logical dp.
            int tolerance = Math.max(2, Math.round(3 * dpi / 160f));
            assertEquals("native width at " + dpi, expected, nativeBounds.width());
            assertEquals("native height at " + dpi, expected, nativeBounds.height());
            assertEquals("system width at " + dpi, expected, systemBounds.width(), tolerance);
            assertEquals("system height at " + dpi, expected, systemBounds.height(), tolerance);
            assertEquals("center x at " + dpi, 0, systemBounds.centerX() - systemIconSize(resources) / 2, 1);
            assertEquals("center y at " + dpi, 0, systemBounds.centerY() - systemIconSize(resources) / 2, 1);
            System.out.println("LAUNCH sdk=" + android.os.Build.VERSION.SDK_INT + " dpi=" + dpi
                    + " native=" + nativeBounds.width() + " system=" + systemBounds.width());
        }
    }

    @Test public void regressionFixtureReproducesOversizedPreviousSplash() {
        // The 1.159 drawable used an absolute 112dp child in a 288dp
        // LayerDrawable. Android first renders that layer at 108dp, clips it,
        // then enlarges the cached result. The old source-only test missed it.
        Context context = contextAtDensity(320);
        Resources resources = context.getResources();
        int expected = resources.getDimensionPixelSize(R.dimen.launch_logo_size);
        android.graphics.drawable.LayerDrawable old = new android.graphics.drawable.LayerDrawable(
                new Drawable[]{new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT),
                        resources.getDrawable(R.drawable.launch_logo, null)});
        old.setLayerSize(0, 576, 576);
        old.setLayerSize(1, expected, expected);
        old.setLayerGravity(1, android.view.Gravity.CENTER);
        Rect bounds = opaqueBounds(drawSystemSplash(resources, old));
        assertTrue("the test must catch the previously shipped oversized drawable",
                bounds.width() > expected * 1.5);
        System.out.println("OLD_SPLASH expected=" + expected + " rendered=" + bounds.width());
    }

    private static Context contextAtDensity(int dpi) {
        Context context = RuntimeEnvironment.getApplication();
        Configuration configuration = new Configuration(context.getResources().getConfiguration());
        configuration.densityDpi = dpi;
        return context.createConfigurationContext(configuration);
    }

    private static int systemDimension(Resources resources, String name) {
        int id = resources.getIdentifier(name, "dimen", "android");
        assertTrue("missing platform dimension " + name, id != 0);
        return resources.getDimensionPixelSize(id);
    }

    private static int systemIconSize(Resources resources) {
        return (int) (systemDimension(resources, "starting_surface_icon_size") * 1.2f);
    }

    private static Bitmap drawSystemSplash(Resources resources, Drawable foreground) {
        int sourceSize = systemDimension(resources, "starting_surface_default_icon_size");
        int finalSize = systemIconSize(resources);
        Bitmap cache = Bitmap.createBitmap(sourceSize, sourceSize, Bitmap.Config.ARGB_8888);
        Canvas sourceCanvas = new Canvas(cache);
        int center = sourceSize / 2;
        // AOSP AdaptiveForegroundDrawable expands each edge by 25%, then
        // ImmobileIconDrawable scales this 108dp cache to the final 192dp icon.
        float viewportScale = 1f / (1f + 2f * .25f);
        int half = (int) (sourceSize / (viewportScale * 2));
        foreground.setBounds(center - half, center - half, center + half, center + half);
        foreground.draw(sourceCanvas);
        Bitmap result = Bitmap.createBitmap(finalSize, finalSize, Bitmap.Config.ARGB_8888);
        Canvas resultCanvas = new Canvas(result);
        resultCanvas.scale(finalSize / (float) sourceSize, finalSize / (float) sourceSize);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        resultCanvas.drawBitmap(cache, 0, 0, paint);
        return result;
    }

    private static Bitmap drawNativeLogo(Context context, int size) {
        ImageView view = new ImageView(context);
        view.setImageResource(R.drawable.launch_logo);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        view.layout(0, 0, size, size);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(bitmap));
        return bitmap;
    }

    private static Rect opaqueBounds(Bitmap bitmap) {
        int left = bitmap.getWidth(), top = bitmap.getHeight(), right = -1, bottom = -1;
        for (int y = 0; y < bitmap.getHeight(); y++) {
            for (int x = 0; x < bitmap.getWidth(); x++) {
                if ((bitmap.getPixel(x, y) >>> 24) < 128) continue;
                left = Math.min(left, x);
                top = Math.min(top, y);
                right = Math.max(right, x);
                bottom = Math.max(bottom, y);
            }
        }
        assertTrue("empty launch drawable", right >= left && bottom >= top);
        return new Rect(left, top, right + 1, bottom + 1);
    }
}
