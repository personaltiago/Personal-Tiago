package com.tiagolima.agendapersonal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

/** Exercises the actual attached view hierarchy, including unequal safe insets. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = {31, 35})
public class LaunchLayoutTest {
    @Test public void nativeAndWebCentersMatchWindowAcrossInsetsAndResize() {
        try (org.robolectric.android.controller.ActivityController<Activity> controller =
                Robolectric.buildActivity(Activity.class).setup()) {
            Activity activity = controller.get();
            activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            FrameLayout content = new FrameLayout(activity);
            View viewport = new View(activity);
            content.addView(viewport, new FrameLayout.LayoutParams(-1, -1));
            LaunchLoadingLayout loader = new LaunchLoadingLayout(activity);
            loader.setOrientation(LinearLayout.VERTICAL);
            loader.setGravity(Gravity.CENTER);
            loader.setPadding(32, 32, 32, 32);
            ImageView logo = new ImageView(activity);
            int size = activity.getResources().getDimensionPixelSize(R.dimen.launch_logo_size);
            loader.addView(logo, new LinearLayout.LayoutParams(size, size));
            TextView status = new TextView(activity);
            status.setText("Falha ao abrir. Tente novamente.");
            status.setVisibility(View.GONE);
            loader.addView(status, new LinearLayout.LayoutParams(-2, -2));
            loader.setLaunchLogo(logo, status);
            content.addView(loader, new FrameLayout.LayoutParams(-1, -1));
            activity.setContentView(content);
            View decor = activity.getWindow().getDecorView();

            int[][] cases = {
                {720, 1280, 0, 0, 0, 0},
                {720, 1280, 0, 64, 0, 24},
                {720, 1280, 0, 48, 0, 96},
                {720, 1280, 30, 102, 0, 18},
                {720, 1280, 0, 102, 30, 18},
                {1080, 2400, 0, 120, 0, 60},
                {540, 960, 18, 46, 0, 24}
            };
            for (int[] c : cases) {
                content.setPadding(c[2], c[3], c[4], c[5]);
                layout(decor, c[0], c[1]);
                int[] logoPosition = new int[2], viewportPosition = new int[2];
                logo.getLocationInWindow(logoPosition);
                viewport.getLocationInWindow(viewportPosition);
                float nativeX = logoPosition[0] + logo.getWidth() / 2f;
                float nativeY = logoPosition[1] + logo.getHeight() / 2f;
                float webX = viewportPosition[0] + viewport.getWidth()
                        * LaunchLoadingLayout.windowCenterPercent(viewport, true) / 100f;
                float webY = viewportPosition[1] + viewport.getHeight()
                        * LaunchLoadingLayout.windowCenterPercent(viewport, false) / 100f;
                assertEquals("native x", decor.getWidth() / 2f, nativeX, 1f);
                assertEquals("native y", decor.getHeight() / 2f, nativeY, 1f);
                assertEquals("web x", nativeX, webX, 1f);
                assertEquals("web y", nativeY, webY, 1f);
                assertEquals("logo width", size, logo.getWidth());
                assertEquals("logo height", size, logo.getHeight());
                System.out.println("ALIGNED sdk=" + android.os.Build.VERSION.SDK_INT
                        + " window=" + c[0] + "x" + c[1] + " insets=" + c[2] + ","
                        + c[3] + "," + c[4] + "," + c[5] + " native=" + nativeX + ","
                        + nativeY + " web=" + webX + "," + webY);
            }

            // The old inset-centered loader in the supplied video moved down.
            content.setPadding(0, 64, 0, 24);
            layout(decor, 720, 1280);
            assertTrue("fixture must reproduce the old downward jump", logo.getTranslationY() < -10f);
            float oldY = logo.getTranslationY();
            // Error messages and retry controls retain their accessible content layout.
            status.setVisibility(View.VISIBLE);
            layout(decor, 720, 1280);
            assertEquals(0f, logo.getTranslationY(), 0f);
            assertEquals(0f, logo.getTranslationX(), 0f);
            status.setVisibility(View.GONE);
            layout(decor, 720, 1280);
            assertEquals(oldY, logo.getTranslationY(), .01f);
        }
    }

    private static void layout(View view, int width, int height) {
        view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
        view.layout(0, 0, width, height);
    }
}
