package com.tiagolima.agendapersonal;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import org.json.JSONArray;
import org.json.JSONObject;

/** The signature covers every package field, independent of JSON spacing and key order. */
final class UpdatePackageSignature {
    static final String FIELD = "agendaSignature";

    static final class Invalid extends Exception {
        Invalid() { super("A atualização não tem uma assinatura válida do Agenda Personal."); }
    }

    static byte[] digest(JSONObject pack) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update("Agenda Personal update v1\n".getBytes(StandardCharsets.UTF_8));
        append(digest, pack, 0);
        return digest.digest();
    }

    static void verify(JSONObject pack, PublicKey key) throws Exception {
        String encoded = pack.optString(FIELD);
        if (encoded.isEmpty() || encoded.length() > 2048) throw new Invalid();
        try {
            Signature verifier = Signature.getInstance(algorithm(key.getAlgorithm()));
            verifier.initVerify(key);
            verifier.update(digest(pack));
            if (!verifier.verify(Base64.getDecoder().decode(encoded))) throw new Invalid();
        } catch (Exception failure) {
            throw new Invalid();
        }
    }

    static String algorithm(String keyAlgorithm) throws Invalid {
        if ("RSA".equalsIgnoreCase(keyAlgorithm)) return "SHA256withRSA";
        if ("EC".equalsIgnoreCase(keyAlgorithm)) return "SHA256withECDSA";
        throw new Invalid();
    }

    private static void append(MessageDigest digest, Object value, int depth) throws Exception {
        if (depth > 64) throw new Invalid();
        if (value instanceof JSONObject) {
            JSONObject object = (JSONObject) value;
            ArrayList<String> keys = new ArrayList<>();
            object.keys().forEachRemaining(key -> {
                if (depth != 0 || !FIELD.equals(key)) keys.add(key);
            });
            Collections.sort(keys);
            digest.update((byte) '{');
            for (String key : keys) {
                string(digest, key);
                append(digest, object.opt(key), depth + 1);
            }
            digest.update((byte) '}');
        } else if (value instanceof JSONArray) {
            JSONArray array = (JSONArray) value;
            digest.update((byte) '[');
            for (int i = 0; i < array.length(); i++) append(digest, array.opt(i), depth + 1);
            digest.update((byte) ']');
        } else if (value instanceof String) {
            string(digest, (String) value);
        } else if (value instanceof Boolean) {
            digest.update((byte) ((Boolean) value ? 't' : 'f'));
        } else if (value == null || value == JSONObject.NULL) {
            digest.update((byte) 'n');
        } else if (value instanceof Number) {
            long integer = ((Number) value).longValue();
            if (integer < -9007199254740991L || integer > 9007199254740991L
                || ((Number) value).doubleValue() != integer) throw new Invalid();
            digest.update((byte) '#');
            digest.update(Long.toString(integer).getBytes(StandardCharsets.US_ASCII));
            digest.update((byte) ';');
        } else {
            throw new Invalid();
        }
    }

    private static void string(MessageDigest digest, String value) throws Exception {
        for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            if (Character.isHighSurrogate(current)) {
                if (++i == value.length() || !Character.isLowSurrogate(value.charAt(i))) throw new Invalid();
            } else if (Character.isLowSurrogate(current)) {
                throw new Invalid();
            }
        }
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        int length = bytes.length;
        digest.update((byte) 's');
        digest.update((byte) (length >>> 24));
        digest.update((byte) (length >>> 16));
        digest.update((byte) (length >>> 8));
        digest.update((byte) length);
        digest.update(bytes);
    }
}
