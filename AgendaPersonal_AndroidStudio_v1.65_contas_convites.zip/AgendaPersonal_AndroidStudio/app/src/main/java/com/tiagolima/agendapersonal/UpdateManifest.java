package com.tiagolima.agendapersonal;
import org.json.JSONObject;

/** One contract for foreground checks, background notices and teacher publication. */
final class UpdateManifest {
    static JSONObject validate(JSONObject value, String appId) throws Exception {
        if (!value.optBoolean("available")) return value;
        if (value.optInt("format") != 1 || !appId.equals(value.optString("appId"))
                || value.optInt("bridgeVersion") != 3 || value.optInt("dataSchema") != 4
                || value.optInt("sequence") < 1 || !value.optString("version").matches("\\d+\\.\\d+\\.\\d+")
                || value.optInt("size") < 1 || value.optInt("size") > 32 * 1024 * 1024
                || !value.optString("sha256").matches("[a-f0-9]{64}")
                || !value.optString("bundlePath").matches("/api/bundle/[a-f0-9-]{36}"))
            throw new Exception("Esta atualização precisa de outra versão do APK.");
        return value;
    }
    static boolean newer(JSONObject value, int installed) {
        return value != null && value.optBoolean("available") && value.optInt("sequence") > installed;
    }
}
