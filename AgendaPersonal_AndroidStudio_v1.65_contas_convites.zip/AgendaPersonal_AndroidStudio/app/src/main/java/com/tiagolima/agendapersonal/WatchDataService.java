package com.tiagolima.agendapersonal;
import com.google.android.gms.wearable.*;
import com.tiagolima.agendapersonal.watch.WatchContract;
public final class WatchDataService extends WearableListenerService {
    @Override public void onDataChanged(DataEventBuffer events){
        for(DataEvent event:events)if(event.getType()==DataEvent.TYPE_CHANGED){
            DataItem item=event.getDataItem();String path=item.getUri().getPath();
            if(WatchContract.RECEIPT.equals(path)||path!=null&&path.startsWith(WatchContract.RESULT))try{WatchBridge.receive(this,path,DataMapItem.fromDataItem(item).getDataMap().getString("json"));}catch(Exception ignored){}
        }
    }
}
