package com.tiagolima.agendapersonal;

/** Presentation added at response time, including for already installed web updates. */
final class NativeLaunch {
    private NativeLaunch() {}

    static final String HTML = """
        <style id="ap-native-launch-style">
        html[data-ap-startup] #apStartup:not([data-error=true]) img{
          position:fixed!important;left:var(--ap-native-launch-x,50vw)!important;
          top:var(--ap-native-launch-y,50vh)!important;
          transform:translate(-50%,-50%)!important;margin:0!important;
          width:112px!important;height:112px!important;border-radius:0!important;
        }
        </style>
        <script id="ap-native-launch-layout">
        (function(){'use strict';function align(){try{
          if(!window.Android||typeof Android.getLaunchGeometry!=='function')return;
          var g=JSON.parse(Android.getLaunchGeometry()),x=Number(g.x),y=Number(g.y);
          if(!Number.isFinite(x)||!Number.isFinite(y)||x<0||x>100||y<0||y>100)return;
          document.documentElement.style.setProperty('--ap-native-launch-x',x+'vw');
          document.documentElement.style.setProperty('--ap-native-launch-y',y+'vh');
        }catch(_){}}
        align();requestAnimationFrame(align);
        document.addEventListener('DOMContentLoaded',align,{once:true});
        window.addEventListener('resize',align);
        window.addEventListener('ap-native-launch-layout',align);
        })();
        </script>
        """;
}
