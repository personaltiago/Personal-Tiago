package com.tiagolima.agendapersonal;

import org.json.JSONObject;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/** Request binding only. Firebase validates the token signature and authenticates the user. */
final class GoogleSignInProtocol {
    private GoogleSignInProtocol() {}

    static boolean validRequest(String id) {
        return id != null && id.matches("[A-Za-z0-9_-]{16,100}");
    }

    static String nonce() {
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    static String clientId(JSONObject configuration) throws Exception {
        URI uri = new URI(configuration.getString("authUri"));
        if (!"https".equals(uri.getScheme()) || !"accounts.google.com".equals(uri.getHost())
                || uri.getUserInfo() != null || uri.getPort() != -1) throw new Exception("Invalid Google authorization endpoint");
        String client = null;
        for (String pair : uri.getRawQuery().split("&")) {
            String[] parts = pair.split("=", 2);
            if ("client_id".equals(URLDecoder.decode(parts[0], "UTF-8"))) {
                if (client != null || parts.length != 2) throw new Exception("Ambiguous Google client");
                client = URLDecoder.decode(parts[1], "UTF-8");
            }
        }
        if (client == null || !client.matches("1044097605904-[A-Za-z0-9_-]+\\.apps\\.googleusercontent\\.com"))
            throw new Exception("Google client belongs to another project");
        return client;
    }

    static boolean boundToken(String token, String client, String expectedNonce, long nowSeconds) {
        try {
            if (token == null || token.length() > 65536 || expectedNonce == null) return false;
            String[] parts = token.split("\\.", -1);
            if (parts.length != 3 || parts[0].isEmpty() || parts[2].isEmpty()) return false;
            JSONObject payload = new JSONObject(new String(Base64.getUrlDecoder().decode(parts[1]), StandardCharsets.UTF_8));
            String issuer = payload.optString("iss");
            return ("https://accounts.google.com".equals(issuer) || "accounts.google.com".equals(issuer))
                && client.equals(payload.optString("aud")) && payload.optLong("exp", 0) > nowSeconds
                && MessageDigest.isEqual(expectedNonce.getBytes(StandardCharsets.UTF_8),
                    payload.optString("nonce").getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { return false; }
    }
}
