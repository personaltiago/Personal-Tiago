package com.tiagolima.agendapersonal;

import org.json.JSONObject;
import java.io.*;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.function.BooleanSupplier;

/** Streams only the current APK's source pages. No historical bundles or student storage. */
final class UpdateExport {
    private static final int LIMIT=32*1024*1024;
    static void check(BooleanSupplier allowed)throws IOException {
        if(!allowed.getAsBoolean())throw new IOException("Download cancelado: a conta mudou ou o aplicativo foi fechado.");
    }
    static byte[] read(InputStream input,int limit)throws IOException {
        try(InputStream in=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] bytes=new byte[8192];int count;
            while((count=in.read(bytes))!=-1){if(count>limit-out.size())throw new IOException("Arquivo muito grande.");out.write(bytes,0,count);}
            return out.toByteArray();
        }
    }
    static void writeBase(MainActivity activity,File target,String version,int sequence,BooleanSupplier allowed)throws Exception {
        check(allowed);
        JSONObject identity=new JSONObject(new String(read(activity.getAssets().open("agenda-build.json"),65536),StandardCharsets.UTF_8));
        JSONObject meta=identity.getJSONObject("release"),hashes=identity.getJSONObject("files");
        if(meta.optInt("format")!=1||meta.optInt("bridgeVersion")!=3||meta.optInt("dataSchema")!=4||meta.has("files")
            ||!activity.getPackageName().equals(meta.optString("appId"))||!version.equals(meta.optString("version"))||sequence!=meta.optInt("sequence"))
            throw new IOException("A cópia não corresponde à versão incluída no aplicativo.");
        try(FileOutputStream file=new FileOutputStream(target)){
            Limited output=new Limited(file,allowed);
            Writer writer=new BufferedWriter(new OutputStreamWriter(output,StandardCharsets.UTF_8),8192);
            String header=meta.toString();writer.write(header,0,header.length()-1);writer.write(",\"files\":{");
            String[] pages={"index.html","professor.html","avaliacoes.html","cadastro.html"};
            for(int i=0;i<pages.length;i++){
                check(allowed);String name=pages[i];if(i>0)writer.write(',');writer.write('"');writer.write(name);writer.write("\":");
                MessageDigest digest=MessageDigest.getInstance("SHA-256");
                try(InputStream input=new DigestInputStream(activity.getAssets().open(name),digest);
                    Reader reader=new InputStreamReader(input,StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT))){
                    quoted(writer,reader);
                }
                if(!hex(digest.digest()).equals(hashes.getString(name)))throw new IOException("A tela não corresponde ao conteúdo original.");
            }
            writer.write("}}");writer.flush();file.getFD().sync();check(allowed);
        }catch(Exception|Error error){target.delete();throw error;}
    }
    private static String hex(byte[] bytes){StringBuilder text=new StringBuilder(64);for(byte b:bytes)text.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return text.toString();}
    private static void quoted(Writer out,Reader reader)throws IOException {
        out.write('"');char[] chars=new char[8192];int count;
        while((count=reader.read(chars))!=-1){int start=0;for(int i=0;i<count;i++){
            char c=chars[i];String escaped=null;
            switch(c){case '"':escaped="\\\"";break;case '\\':escaped="\\\\";break;case '\n':escaped="\\n";break;case '\r':escaped="\\r";break;case '\t':escaped="\\t";break;case '\b':escaped="\\b";break;case '\f':escaped="\\f";break;default:if(c<32)escaped=String.format(java.util.Locale.ROOT,"\\u%04x",(int)c);}
            if(escaped!=null){out.write(chars,start,i-start);out.write(escaped);start=i+1;}
        }out.write(chars,start,count-start);}out.write('"');
    }
    private static final class Limited extends FilterOutputStream {
        private final BooleanSupplier allowed;private int size;
        Limited(OutputStream out,BooleanSupplier allowed){super(out);this.allowed=allowed;}
        @Override public void write(int value)throws IOException{check(allowed);if(size>=LIMIT)throw new IOException("Arquivo muito grande.");out.write(value);size++;}
        @Override public void write(byte[] bytes,int offset,int count)throws IOException{check(allowed);if(count>LIMIT-size)throw new IOException("Arquivo muito grande.");out.write(bytes,offset,count);size+=count;}
    }
}
