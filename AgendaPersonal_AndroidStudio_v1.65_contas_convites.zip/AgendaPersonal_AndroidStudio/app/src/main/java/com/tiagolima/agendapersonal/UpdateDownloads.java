package com.tiagolima.agendapersonal;

import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;

/** Prepares code-only copies and saves them through Android's document picker. */
final class UpdateDownloads {
    static final int SAVE_REQUEST = 3004;
    interface Write { void write(File target, BooleanSupplier allowed) throws Exception; }
    static final class Source {
        final JSONObject meta; final Write write;
        Source(JSONObject meta, Write write) { this.meta=meta; this.write=write; }
    }
    interface Sources { JSONArray list() throws Exception; Source resolve(String id) throws Exception; }
    private final MainActivity activity;
    private final WebView web;
    private final Sources sources;
    private final BooleanSupplier teacher, updating;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy=new AtomicBoolean(),saving=new AtomicBoolean();
    private final File folder,journalFile;
    private volatile boolean destroyed;
    private volatile int accountGeneration;
    private volatile int preparedGeneration=-1;
    private static final int LIMIT=24*1024*1024;

    UpdateDownloads(MainActivity activity, WebView web, Sources sources, BooleanSupplier teacher, BooleanSupplier updating) {
        this.activity=activity;this.web=web;this.sources=sources;this.teacher=teacher;this.updating=updating;
        folder=new File(activity.getCacheDir(),"update-downloads");folder.mkdirs();journalFile=new File(folder,"pending.json");
    }
    void accountChanged(){accountGeneration++;}
    String options(){
        try{if(!teacher.getAsBoolean()||destroyed)return new JSONObject().put("ok",false).put("message","Entre como professor para baixar atualizações.").toString();
            return new JSONObject().put("ok",true).put("releases",sources.list()).toString();
        }catch(Exception|OutOfMemoryError error){return "{\"ok\":false,\"message\":\"Não foi possível consultar as cópias.\"}";}
    }
    boolean start(String id,String expected,String request){
        if(destroyed||!teacher.getAsBoolean()||updating.getAsBoolean()||request==null||!request.matches("[A-Za-z0-9_-]{1,100}")||expected==null||!expected.matches("[a-f0-9]{64}")||!busy.compareAndSet(false,true))return false;
        final int generation=accountGeneration;preparedGeneration=generation;
        worker.execute(()->{
            File target=null;JSONObject journal=null;
            BooleanSupplier allowed=()->!destroyed&&generation==accountGeneration&&teacher.getAsBoolean();
            try{
                UpdateExport.check(allowed);clearOldJournal();Source source=sources.resolve(id);
                if(!expected.equals(source.meta.optString("contentSha256")))throw new IOException("A versão disponível mudou. Reabra a opção Download.");
                target=File.createTempFile("release-",".agenda.json",folder);source.write.write(target,allowed);UpdateExport.check(allowed);
                if(target.length()<1||target.length()>LIMIT)throw new IOException("A cópia está incompleta ou é muito grande.");
                journal=new JSONObject().put("requestId",request).put("version",source.meta.getString("version"))
                    .put("filename",safeName(source.meta.getString("filename"))).put("file",target.getName()).put("size",target.length()).put("sha256",hash(target));
                UpdateStorage.writeJson(journalFile,journal,65536);final JSONObject ready=journal;
                activity.runOnUiThread(()->{
                    try{
                        UpdateExport.check(allowed);
                        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json");
                        intent.putExtra(Intent.EXTRA_TITLE,ready.getString("filename"));activity.startActivityForResult(intent,SAVE_REQUEST);
                        result(request,"choosing",ready.optString("version"),"");
                    }catch(Exception error){cleanup(ready);busy.set(false);result(request,"error",ready.optString("version"),"Não foi possível abrir o local de salvamento.");}
                });
            }catch(Exception|OutOfMemoryError error){if(target!=null)target.delete();if(journal!=null)cleanup(journal);busy.set(false);result(request,"error","","Não foi possível preparar a cópia. A versão em uso foi mantida.");}
        });return true;
    }
    void finish(Uri destination){
        if(destroyed||!saving.compareAndSet(false,true))return;
        busy.set(true);final int generation=preparedGeneration<0?accountGeneration:preparedGeneration;
        worker.execute(()->{
            JSONObject journal=null;boolean success=false,writing=false;
            try{
                if(!journalFile.exists())throw new IOException("Nenhum download pendente.");
                journal=new JSONObject(new String(UpdateExport.read(new FileInputStream(journalFile),65536),java.nio.charset.StandardCharsets.UTF_8));
                if(destination==null){result(journal.optString("requestId"),"cancelled",journal.optString("version"),"");return;}
                BooleanSupplier allowed=()->!destroyed&&generation==accountGeneration&&teacher.getAsBoolean();UpdateExport.check(allowed);
                if(!"content".equals(destination.getScheme())||(activity.getPackageName()+".fileprovider").equals(destination.getAuthority()))throw new IOException("Local de salvamento inválido.");
                File file=staged(journal);if(file.length()!=((Number)journal.opt("size")).longValue()||file.length()>LIMIT)throw new IOException("A cópia foi alterada.");
                result(journal.optString("requestId"),"saving",journal.optString("version"),"");
                MessageDigest digest=MessageDigest.getInstance("SHA-256");
                try(InputStream input=new FileInputStream(file);OutputStream output=activity.getContentResolver().openOutputStream(destination)){
                    if(output==null)throw new IOException("O arquivo não pôde ser aberto.");writing=true;
                    byte[] bytes=new byte[8192];int count,total=0;
                    while((count=input.read(bytes))!=-1){UpdateExport.check(allowed);if(count>LIMIT-total)throw new IOException("Arquivo muito grande.");output.write(bytes,0,count);digest.update(bytes,0,count);total+=count;}
                    if(!hex(digest.digest()).equals(journal.getString("sha256")))throw new IOException("A cópia foi alterada.");
                    output.flush();UpdateExport.check(allowed);
                }
                success=true;result(journal.optString("requestId"),"saved",journal.optString("version"),"");
            }catch(Exception|OutOfMemoryError error){if(journal!=null)result(journal.optString("requestId"),"error",journal.optString("version"),"Não foi possível salvar a atualização. A versão em uso foi mantida.");}
            finally{
                if(writing&&!success&&destination!=null&&"content".equals(destination.getScheme())&&!(activity.getPackageName()+".fileprovider").equals(destination.getAuthority()))try{activity.getContentResolver().delete(destination,null,null);}catch(Exception ignored){}
                if(journal!=null)cleanup(journal);preparedGeneration=-1;saving.set(false);busy.set(false);
            }
        });
    }
    private void clearOldJournal(){
        try{if(journalFile.exists())cleanup(new JSONObject(new String(UpdateExport.read(new FileInputStream(journalFile),65536),java.nio.charset.StandardCharsets.UTF_8)));}catch(Exception ignored){journalFile.delete();}
    }
    private File staged(JSONObject journal)throws Exception{
        String name=journal.getString("file");if(!name.matches("release-[A-Za-z0-9._-]+\\.agenda\\.json"))throw new IOException("Cópia inválida.");
        File file=new File(folder,name);if(!file.getCanonicalFile().getParentFile().equals(folder.getCanonicalFile()))throw new IOException("Cópia inválida.");return file;
    }
    private void cleanup(JSONObject journal){try{staged(journal).delete();}catch(Exception ignored){}journalFile.delete();}
    private void result(String request,String status,String version,String message){
        if(destroyed)return;
        try{JSONObject value=new JSONObject().put("requestId",request).put("status",status).put("version",version).put("message",message);
            activity.runOnUiThread(()->{if(!destroyed&&!activity.isFinishing())web.evaluateJavascript("window.dispatchEvent(new CustomEvent('ap-update-download-result',{detail:"+value.toString()+"}));",null);});
        }catch(Exception ignored){}
    }
    private static String safeName(String name)throws IOException{
        if(name==null||name.length()>120||!name.matches("[A-Za-z0-9._-]+\\.agenda\\.json"))throw new IOException("Nome da atualização inválido.");return name;
    }
    private static String hash(File file)throws Exception{MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(file)){byte[] bytes=new byte[8192];int count;while((count=in.read(bytes))!=-1)digest.update(bytes,0,count);}return hex(digest.digest());}
    private static String hex(byte[] bytes){StringBuilder text=new StringBuilder(64);for(byte b:bytes)text.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return text.toString();}
    void destroy(){destroyed=true;worker.shutdownNow();}
}
