package com.tiagolima.agendapersonal;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Aviso "Novo cadastro" na tela (Android 1.211). Pedido do Tiago em 24/11/2026: quando o sininho do app recebe um cadastro, o
 * app mostra a notificação na tela, igual ao despertador. Quem percebe o cadastro é o conteúdo (o mesmo acompanhamento do
 * sininho, com o app aberto ou em segundo plano); aqui o app só mostra o aviso, num canal próprio, e o toque abre a lista
 * "Alunos para aprovar". Sem Firebase no Android e sem servidor. Não mexe em alarmes, descanso nem cronômetros.
 */
final class AvisosCadastro {
    static final int VERSAO = 1;
    static final String CANAL = "cadastros";
    static final String EXTRA_TIPO = "agenda_aviso_tipo";
    static final String EXTRA_ALUNO = "agenda_aviso_aluno";
    static final int NOTIFICACAO = 4101;
    static final int COR = 0xFF568900;
    private static final int LIMITE_JSON = 2000;
    private static final Pattern ALUNO = Pattern.compile("[A-Za-z0-9]{1,128}");

    private AvisosCadastro() {}

    /** Um aviso conhecido, já limpo para a tela bloqueada. */
    static final class Aviso {
        final String tipo, titulo, texto, aluno;

        Aviso(String tipo, String titulo, String texto, String aluno) {
            this.tipo = tipo;
            this.titulo = titulo;
            this.texto = texto;
            this.aluno = aluno;
        }

        /** Um aviso por aluno: o mesmo cadastro avisado duas vezes substitui o anterior. */
        String tag() { return aluno.isEmpty() ? tipo : tipo + ":" + aluno; }
    }

    static boolean tipoConhecido(String tipo) { return "cadastro".equals(tipo) || "teste".equals(tipo); }

    /** Lê os dados do aviso (tipo, titulo, texto, aluno). Devolve null se não for um aviso conhecido. */
    static Aviso ler(Map<String, String> dados) {
        if (dados == null || !tipoConhecido(dados.get("tipo"))) return null;
        String tipo = dados.get("tipo"), aluno = dados.get("aluno");
        boolean cadastro = "cadastro".equals(tipo);
        String titulo = limpo(dados.get("titulo"), 60), texto = limpo(dados.get("texto"), 240);
        if (titulo.isEmpty()) titulo = cadastro ? "Novo cadastro" : "Teste do aviso";
        if (texto.isEmpty()) texto = cadastro ? "Um aluno se cadastrou. Toque para aprovar." : "O aviso de cadastro está funcionando.";
        return new Aviso(tipo, titulo, texto, aluno != null && ALUNO.matcher(aluno).matches() ? aluno : "");
    }

    /** O mesmo, a partir do texto que o conteúdo manda pela ponte. */
    static Aviso lerJson(String json) {
        if (json == null || json.length() > LIMITE_JSON) return null;
        try {
            JSONObject objeto = new JSONObject(json);
            Map<String, String> dados = new HashMap<>();
            for (String campo : new String[]{"tipo", "titulo", "texto", "aluno"}) {
                Object valor = objeto.opt(campo);
                if (valor instanceof String) dados.put(campo, (String) valor);
            }
            return ler(dados);
        } catch (Exception invalido) {
            return null;
        }
    }

    private static String limpo(String valor, int limite) {
        if (valor == null) return "";
        String texto = valor.replaceAll("[\\u0000-\\u001f\\u007f]", " ").trim();
        int pontos = texto.codePointCount(0, texto.length());
        return pontos <= limite ? texto : texto.substring(0, texto.offsetByCodePoints(0, limite)).trim();
    }

    static void criarCanal(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel canal = new NotificationChannel(CANAL, "Cadastros de alunos", NotificationManager.IMPORTANCE_HIGH);
        canal.setDescription("Avisa quando um aluno novo se cadastra e espera a sua aprovação.");
        canal.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        canal.setShowBadge(true);
        canal.enableVibration(true);
        manager.createNotificationChannel(canal);
    }

    /** Mostra o aviso. O toque abre o app (sem recarregar se ele já estiver aberto) e leva à lista de aprovação. */
    static boolean mostrar(Context context, Aviso aviso) {
        if (aviso == null) return false;
        criarCanal(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return false;
        Intent abrir = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(EXTRA_TIPO, aviso.tipo)
                .putExtra(EXTRA_ALUNO, aviso.aluno);
        PendingIntent toque = PendingIntent.getActivity(context, aviso.tag().hashCode(), abrir,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String reservado = "cadastro".equals(aviso.tipo) ? "Um aluno se cadastrou. Toque para aprovar." : aviso.texto;
        Notification publico = new Notification.Builder(context, CANAL)
                .setSmallIcon(R.drawable.ic_stat_cadastro).setColor(COR)
                .setContentTitle(aviso.titulo).setContentText(reservado)
                .build();
        Notification notificacao = new Notification.Builder(context, CANAL)
                .setSmallIcon(R.drawable.ic_stat_cadastro).setColor(COR)
                .setContentTitle(aviso.titulo).setContentText(aviso.texto)
                .setStyle(new Notification.BigTextStyle().bigText(aviso.texto))
                .setContentIntent(toque).setAutoCancel(true)
                .setShowWhen(true).setWhen(System.currentTimeMillis())
                .setVisibility(Notification.VISIBILITY_PRIVATE).setPublicVersion(publico)
                .build();
        try {
            manager.notify(aviso.tag(), NOTIFICACAO, notificacao);
            return true;
        } catch (RuntimeException recusado) {
            return false;
        }
    }

    static boolean mostrarJson(Context context, String json) { return mostrar(context, lerJson(json)); }

    /** "cadastro" ou "teste" quando o app foi aberto pelo toque num aviso; "" nos outros casos. Tira os extras para não repetir. */
    static String abertura(Intent intent) {
        if (intent == null) return "";
        String tipo = intent.getStringExtra(EXTRA_TIPO);
        if (!tipoConhecido(tipo)) return "";
        intent.removeExtra(EXTRA_TIPO);
        intent.removeExtra(EXTRA_ALUNO);
        return tipo;
    }

    /** Estado para a tela "Sons e alertas": o que falta para o aviso aparecer na tela bloqueada. */
    static String status(Context context) {
        JSONObject status = new JSONObject();
        try {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel canal = manager == null ? null : manager.getNotificationChannel(CANAL);
            boolean permissao = manager != null && manager.areNotificationsEnabled()
                    && (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
            int importancia = canal == null ? -1 : canal.getImportance();
            status.put("versao", VERSAO);
            status.put("app", versaoDoApp(context));
            status.put("permissao", permissao);
            status.put("canal", canal == null ? "ausente" : importancia == NotificationManager.IMPORTANCE_NONE ? "desligado"
                    : importancia >= NotificationManager.IMPORTANCE_HIGH ? "alerta"
                    : importancia >= NotificationManager.IMPORTANCE_DEFAULT ? "som" : "silencioso");
            status.put("telaBloqueada", canal != null && canal.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
        } catch (Exception falha) {
            return "{\"versao\":" + VERSAO + ",\"erro\":\"status-indisponivel\"}";
        }
        return status.toString();
    }

    /** Versão do APK (ex.: "1.211"). */
    private static String versaoDoApp(Context context) {
        try {
            String nome = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            return nome == null ? "" : nome;
        } catch (Exception indisponivel) {
            return "";
        }
    }

    /** Abre as configurações do canal "Cadastros de alunos" (som, tela bloqueada); sem canal, as do app. */
    static void abrirConfiguracoes(Activity activity) {
        criarCanal(activity);
        try {
            activity.startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName())
                    .putExtra(Settings.EXTRA_CHANNEL_ID, CANAL));
            return;
        } catch (RuntimeException semTela) { /* alguns aparelhos não têm a tela do canal */ }
        try {
            activity.startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName()));
        } catch (RuntimeException ignorado) { /* sem tela de notificações: o conteúdo mostra a orientação */ }
    }
}
