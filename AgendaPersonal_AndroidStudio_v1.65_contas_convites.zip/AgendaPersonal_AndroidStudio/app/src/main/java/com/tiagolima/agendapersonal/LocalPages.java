package com.tiagolima.agendapersonal;

import android.net.Uri;

/** A closed, offline HTTPS origin shared by the app's own pages only. */
public final class LocalPages {
    public static final String ORIGIN = "https://appassets.androidplatform.net";
    public static final String HOME = ORIGIN + "/assets/index.html";
    private LocalPages() {}

    public static String assetName(Uri uri) {
        if (uri == null) return null;
        String path = uri.getPath();
        boolean secure = "https".equals(uri.getScheme())
            && "appassets.androidplatform.net".equals(uri.getAuthority());
        boolean legacy = "file".equals(uri.getScheme())
            && (uri.getAuthority() == null || uri.getAuthority().isEmpty());
        String prefix = secure ? "/assets/" : legacy ? "/android_asset/" : null;
        if (prefix == null || path == null || !path.startsWith(prefix)) return null;
        String name = path.substring(prefix.length());
        if ("index.html".equals(name) || "avaliacoes.html".equals(name)
            || "professor.html".equals(name) || "cadastro.html".equals(name)
            || "icon.png".equals(name)) return name;
        return null;
    }

    public static boolean isPage(Uri uri) {
        String name = assetName(uri);
        return name != null && name.endsWith(".html");
    }

    public static boolean isSecureOrigin(Uri uri) {
        return uri != null && "https".equals(uri.getScheme())
            && "appassets.androidplatform.net".equals(uri.getAuthority());
    }

    public static Uri canonical(Uri uri) {
        String asset = assetName(uri);
        if (asset == null) throw new IllegalArgumentException("Página local inválida");
        return uri.buildUpon().scheme("https").authority("appassets.androidplatform.net")
            .path("/assets/" + asset).build();
    }

    public static boolean allowFrame(Uri uri) {
        if (isSecureOrigin(uri) && isPage(uri)) return true;
        return uri != null && ("about:blank".equals(uri.toString())
            || "about:srcdoc".equals(uri.toString()));
    }
}
