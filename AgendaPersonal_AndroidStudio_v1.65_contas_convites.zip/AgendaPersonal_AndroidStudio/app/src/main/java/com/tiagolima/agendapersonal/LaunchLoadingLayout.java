package com.tiagolima.agendapersonal;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

/** Centers the loading artwork in the window, independently of content insets. */
final class LaunchLoadingLayout extends LinearLayout {
    private ImageView logo;
    private View errorStatus;

    LaunchLoadingLayout(Context context) { super(context); }

    void setLaunchLogo(ImageView image, View status) {
        logo = image;
        errorStatus = status;
    }

    static float windowCenterIn(View viewport, boolean horizontal) {
        int[] location = new int[2];
        viewport.getLocationInWindow(location);
        View window = viewport.getRootView();
        return (horizontal ? window.getWidth() : window.getHeight()) / 2f
                - location[horizontal ? 0 : 1];
    }

    static float windowCenterPercent(View viewport, boolean horizontal) {
        int length = horizontal ? viewport.getWidth() : viewport.getHeight();
        if (length <= 0) return 50f;
        return Math.max(0f, Math.min(100f, windowCenterIn(viewport, horizontal) * 100f / length));
    }

    @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (logo == null) return;
        boolean loading = errorStatus == null || errorStatus.getVisibility() == View.GONE;
        // Move only the artwork. The opaque panel continues to cover the whole
        // content area, while retry/error controls keep their normal layout.
        logo.setTranslationX(loading ? windowCenterIn(this, true)
                - logo.getLeft() - logo.getWidth() / 2f : 0f);
        logo.setTranslationY(loading ? windowCenterIn(this, false)
                - logo.getTop() - logo.getHeight() / 2f : 0f);
    }
}
