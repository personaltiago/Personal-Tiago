package com.tiagolima.agendapersonal;

import android.content.*;
import org.json.*;
import com.google.android.gms.wearable.*;
import com.google.android.gms.tasks.Tasks;
import com.tiagolima.agendapersonal.watch.WatchContract;
import java.util.UUID;
import java.util.concurrent.*;

/** Serializes transfers and account revocation so an older send cannot overwrite logout. */
public final class WatchBridge {
    private static long lastRefresh;
    private static long lastConnectionRefresh;
    private static volatile String connection = "{\"state\":\"checking\",\"nodes\":[]}";
    private static final ExecutorService IO=Executors.newSingleThreadExecutor();
    private static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("agenda_wear_v1",Context.MODE_PRIVATE);}
    private static String owner(Context c){return prefs(c).getString("owner","");}
    private static JSONObject object(String s){try{return new JSONObject(s);}catch(Exception e){return new JSONObject();}}
    public static synchronized void account(Context c,String uid){
        String next=uid!=null&&uid.matches("[A-Za-z0-9_-]{1,128}")?uid:"";
        if(next.equals(owner(c)))return;
        prefs(c).edit().putString("owner",next).putString("status","Escolha um treino para enviar ao relógio.").putString("current","").commit();
        IO.execute(()->{try{JSONObject revoke=new JSONObject().put("v",1).put("token",UUID.randomUUID().toString()).put("createdAt",System.currentTimeMillis()).put("revoked",true);publish(c,WatchContract.WORKOUT,revoke);}catch(Exception ignored){}});
    }
    private static void publish(Context c,String path,JSONObject p)throws Exception{
        PutDataMapRequest map=PutDataMapRequest.create(path);map.getDataMap().putString("json",p.toString());
        Tasks.await(Wearable.getDataClient(c).putDataItem(map.asPutDataRequest().setUrgent()),20,TimeUnit.SECONDS);
    }
    public static synchronized String send(Context c,String raw){
        try{
            String uid=owner(c);if(uid.isEmpty())throw new Exception("Entre na sua conta antes de enviar.");
            JSONObject p=new JSONObject(raw).put("v",1).put("owner",uid).put("token",UUID.randomUUID().toString()).put("createdAt",System.currentTimeMillis());
            p=WatchContract.parse(p.toString());final JSONObject payload=p;
            JSONObject jobs=object(prefs(c).getString("jobs","{}"));
            // The bounded journal also binds incoming receipts/results to the initiating account.
            while(jobs.length()>=40)jobs.remove(jobs.keys().next());
            jobs.put(p.getString("token"),p);
            prefs(c).edit().putString("jobs",jobs.toString()).putString("current",p.getString("token")).putString("status","Enviando ao relógio…").commit();
            IO.execute(()->{
                try {
                    if(!uid.equals(owner(c)))return;
                    publish(c,WatchContract.WORKOUT,payload);
                    if(uid.equals(owner(c))&&payload.optString("token").equals(prefs(c).getString("current",""))&&prefs(c).getString("status","").equals("Enviando ao relógio…"))prefs(c).edit().putString("status","Envio registrado. Aguardando confirmação do relógio.").apply();
                    // Node presence is advisory; a successful put is never presented as watch delivery.
                    if(Tasks.await(Wearable.getNodeClient(c).getConnectedNodes(),10,TimeUnit.SECONDS).isEmpty()&&uid.equals(owner(c)))prefs(c).edit().putString("status","Aguardando o relógio conectar e confirmar o recebimento.").apply();
                }catch(Exception e){if(uid.equals(owner(c)))prefs(c).edit().putString("status","Não foi possível enviar. Confira o pareamento, os dois aplicativos instalados e tente novamente.").apply();}
            });
            return new JSONObject().put("ok",true).put("message","Envio iniciado. Confira a confirmação em Resultados do relógio.").toString();
        }catch(Exception e){try{return new JSONObject().put("ok",false).put("message",e.getMessage()).toString();}catch(Exception ignored){return "{}";}}
    }
    public static synchronized String status(Context c){
        if(android.os.SystemClock.elapsedRealtime()-lastConnectionRefresh>3000||lastConnectionRefresh==0){
            lastConnectionRefresh=android.os.SystemClock.elapsedRealtime();
            try {
                Wearable.getNodeClient(c).getConnectedNodes().addOnSuccessListener(nodes -> {
                    try {
                        JSONArray list=new JSONArray();for(Node node:nodes)list.put(new JSONObject().put("id",node.getId()).put("name",node.getDisplayName()));
                        final String snapshot=new JSONObject().put("state","checked").put("checkedAt",System.currentTimeMillis()).put("nodes",list).toString();connection=snapshot;
                        Wearable.getCapabilityClient(c).getCapability("agendapersonal_workout_v1",CapabilityClient.FILTER_REACHABLE).addOnSuccessListener(capability -> {
                            try { if(!connection.equals(snapshot))return;JSONObject result=new JSONObject(snapshot);JSONArray apps=new JSONArray();for(Node node:capability.getNodes())apps.put(node.getId());result.put("appNodes",apps);connection=result.toString(); }catch(Exception ignored){}
                        });
                    }catch(Exception ignored){}
                }).addOnFailureListener(error -> connection="{\"state\":\"unavailable\",\"nodes\":[]}");
            } catch(Exception error) { connection="{\"state\":\"unavailable\",\"nodes\":[]}"; }
        }
        if(android.os.SystemClock.elapsedRealtime()-lastRefresh>3000){lastRefresh=android.os.SystemClock.elapsedRealtime();Wearable.getDataClient(c).getDataItems().addOnSuccessListener(items->{try{for(DataItem item:items){String path=item.getUri().getPath();if(WatchContract.RECEIPT.equals(path)||path!=null&&path.startsWith(WatchContract.RESULT))try{receive(c,path,DataMapItem.fromDataItem(item).getDataMap().getString("json"));}catch(Exception ignored){}}}finally{items.release();}});}

        JSONObject out=new JSONObject();try{
            out.put("message",prefs(c).getString("status","Escolha um treino para enviar ao relógio."));
            out.put("connection",new JSONObject(connection));
            JSONObject records=object(prefs(c).getString("results","{}"));JSONArray list=new JSONArray();String uid=owner(c);
            java.util.ArrayList<JSONObject> sorted=new java.util.ArrayList<>();records.keys().forEachRemaining(k->{JSONObject v=records.optJSONObject(k);if(v!=null&&!uid.isEmpty()&&uid.equals(v.optString("owner")))sorted.add(v);});
            sorted.sort((a,b)->Long.compare(b.optLong("finishedAt"),a.optLong("finishedAt")));for(JSONObject v:sorted)list.put(v);out.put("results",list);
        }catch(Exception ignored){}return out.toString();
    }
    public static synchronized void receive(Context c,String path,String raw){
        try{
            if(raw==null||raw.length()>20000)return;JSONObject incoming=new JSONObject(raw);String token=incoming.getString("token");
            JSONObject job=object(prefs(c).getString("jobs","{}")).optJSONObject(token);if(job==null)return;
            if(path.equals(WatchContract.RECEIPT)){
                if(token.equals(prefs(c).getString("current",""))&&job.optString("owner").equals(owner(c))){
                    String state=incoming.optString("status"),message=state.equals("ready")?"Treino recebido no relógio. Você já pode iniciar no pulso.":state.equals("busy")?"O relógio tem um treino em andamento. Encerre-o antes de reenviar.":"Treino encerrado no relógio.";
                    prefs(c).edit().putString("status",message).apply();
                }return;
            }
            if(!path.equals(WatchContract.RESULT+token))return;
            int total=job.getJSONArray("steps").length(),done=incoming.getInt("completed");long start=incoming.getLong("startedAt"),end=incoming.getLong("finishedAt"),duration=incoming.getLong("durationMs");
            if(done<0||done>total||start<=0||end<start||duration<0||duration>86400000L)return;
            JSONObject record=new JSONObject().put("token",token).put("owner",job.getString("owner")).put("role",job.getString("role")).put("person",job.getString("person")).put("label",job.getString("label")).put("startedAt",start).put("finishedAt",end).put("durationMs",duration).put("completed",done).put("total",total);
            JSONObject records=object(prefs(c).getString("results","{}"));while(records.length()>=100&&!records.has(token))records.remove(records.keys().next());records.put(token,record);
            prefs(c).edit().putString("results",records.toString()).commit();
        }catch(Exception ignored){}
    }
    private WatchBridge(){}
}
