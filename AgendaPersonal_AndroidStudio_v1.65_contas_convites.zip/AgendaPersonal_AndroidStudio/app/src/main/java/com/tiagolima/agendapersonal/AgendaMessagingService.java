package com.tiagolima.agendapersonal;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/**
 * Recebe os avisos do Firebase (Android 1.211). As mensagens vêm só com dados (tipo, titulo, texto, aluno): o app monta
 * a notificação nos dois casos, aberto ou fechado, para o toque abrir a lista de aprovação sem recarregar a agenda.
 */
public class AgendaMessagingService extends FirebaseMessagingService {
    @Override
    public void onNewToken(String token) {
        PushAvisos.salvarToken(this, token);
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        PushAvisos.mostrar(this, PushAvisos.ler(message.getData()));
    }
}
