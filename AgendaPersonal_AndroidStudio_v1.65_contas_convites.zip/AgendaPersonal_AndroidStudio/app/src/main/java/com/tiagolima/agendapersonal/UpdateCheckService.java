package com.tiagolima.agendapersonal;
import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class UpdateCheckService extends JobService {
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private Future<?> task;
    private volatile int generation;
    @Override public boolean onStartJob(JobParameters params) {
        final int token=++generation;
        task=executor.submit(()->{boolean retry=false;try{UpdatePoller.background(this);}catch(Exception error){retry=true;}if(token==generation)jobFinished(params,retry);});return true;
    }
    @Override public boolean onStopJob(JobParameters params) {generation++;if(task!=null)task.cancel(true);return true;}
    @Override public void onDestroy(){generation++;executor.shutdownNow();super.onDestroy();}
}
