package com.tiagolima.agendapersonal;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/**
 * Armazenamento principal opcional dos dados da agenda (chave agendaPersonalTL_v1) em arquivo no telefone,
 * fora do limite de ~5 MB do localStorage. Só é usado depois que o professor ativa o modo; até lá nada muda.
 * Toda gravação é atômica (temporário + troca), mantém a geração anterior (.prev) e a leitura tem cadeia de
 * recuperação: principal → anterior → cópia de segurança (NativeMirror) → reserva feita na ativação.
 */
final class NativeStore {
    private static final int MAX_CHARS = 128 * 1024 * 1024;
    private static final Object LOCK = new Object();
    private static volatile String lastSource = "";

    private NativeStore() { }

    private static File dir(File base) {
        File d = new File(base, "nstore");
        if (!d.isDirectory() && !d.mkdirs() && !d.isDirectory()) return null;
        return d;
    }

    private static boolean shape(String v) {
        return v != null && v.length() >= 2 && v.length() <= MAX_CHARS && v.charAt(0) == '{' && v.charAt(v.length() - 1) == '}';
    }

    static boolean active(File base) {
        File d = dir(base);
        return d != null && new File(d, "mode").isFile();
    }

    private static boolean writeAtomic(File target, byte[] bytes) {
        File tmp = new File(target.getParentFile(), target.getName() + ".tmp");
        try {
            try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(bytes); out.getFD().sync(); }
            if (tmp.length() != bytes.length) { tmp.delete(); return false; }
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (Exception | OutOfMemoryError e) { tmp.delete(); return false; }
    }

    /** Grava o conteúdo principal. Retorna false sem alterar nada se a gravação não puder ser confirmada. */
    static boolean write(File base, String value) {
        if (!shape(value)) return false;
        File d = dir(base);
        if (d == null) return false;
        synchronized (LOCK) {
            try {
                File main = new File(d, "main.json"), prev = new File(d, "main.prev"), meta = new File(d, "main.meta");
                byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
                File tmp = new File(d, "main.next");
                try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(bytes); out.getFD().sync(); }
                if (tmp.length() != bytes.length) { tmp.delete(); return false; }
                if (main.isFile()) Files.copy(main.toPath(), prev.toPath(), StandardCopyOption.REPLACE_EXISTING);
                Files.move(tmp.toPath(), main.toPath(), StandardCopyOption.REPLACE_EXISTING);
                String info = "{\"length\":" + value.length() + ",\"bytes\":" + bytes.length + ",\"hash\":\"" + NativeMirror.hash(value)
                    + "\",\"savedAt\":" + System.currentTimeMillis() + "}";
                return writeAtomic(meta, info.getBytes(StandardCharsets.UTF_8));
            } catch (Exception | OutOfMemoryError e) { return false; }
        }
    }

    private static String readFile(File f) {
        try { return f.isFile() ? new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8) : ""; }
        catch (Exception | OutOfMemoryError e) { return ""; }
    }

    private static String field(String json, String name) {
        int i = json.indexOf("\"" + name + "\":");
        if (i < 0) return "";
        int s = i + name.length() + 3, e = s;
        if (s < json.length() && json.charAt(s) == '"') { s++; e = json.indexOf('"', s); return e < 0 ? "" : json.substring(s, e); }
        while (e < json.length() && Character.isDigit(json.charAt(e))) e++;
        return json.substring(s, e);
    }

    /** Lê com a cadeia de recuperação. Retorna "" se nada íntegro for encontrado. */
    static String read(File base) {
        File d = dir(base);
        synchronized (LOCK) {
            lastSource = "";
            if (d != null) {
                String metaText = readFile(new File(d, "main.meta"));
                String main = readFile(new File(d, "main.json"));
                if (shape(main) && metaText.length() > 2 && NativeMirror.hash(main).equals(field(metaText, "hash"))
                    && String.valueOf(main.length()).equals(field(metaText, "length"))) { lastSource = "main"; return main; }
                String prev = readFile(new File(d, "main.prev"));
                if (shape(prev)) { lastSource = "prev"; return prev; }
            }
            String mirror = NativeMirror.read(base, NativeMirror.MAIN_KEY);
            if (shape(mirror)) { lastSource = "mirror"; return mirror; }
            if (d != null) {
                String reserve = readFile(new File(d, "reserve.json"));
                if (shape(reserve)) { lastSource = "reserve"; return reserve; }
            }
            return "";
        }
    }

    static String lastSource() { return lastSource; }

    /**
     * Ativa o modo: guarda uma reserva do conteúdo atual, grava o principal, lê de volta e compara.
     * Só marca o modo como ativo se tudo conferir.
     */
    static String activate(File base, String value) {
        if (!shape(value)) return "{\"ok\":false,\"error\":\"conteudo\"}";
        File d = dir(base);
        if (d == null) return "{\"ok\":false,\"error\":\"pasta\"}";
        synchronized (LOCK) {
            try {
                if (!writeAtomic(new File(d, "reserve.json"), value.getBytes(StandardCharsets.UTF_8))) return "{\"ok\":false,\"error\":\"reserva\"}";
                if (!write(base, value)) return "{\"ok\":false,\"error\":\"gravacao\"}";
                String back = read(base);
                if (!back.equals(value) || !"main".equals(lastSource)) return "{\"ok\":false,\"error\":\"verificacao\"}";
                if (!writeAtomic(new File(d, "mode"), "native".getBytes(StandardCharsets.UTF_8))) return "{\"ok\":false,\"error\":\"modo\"}";
                return "{\"ok\":true,\"length\":" + value.length() + ",\"hash\":\"" + NativeMirror.hash(value) + "\"}";
            } catch (Exception | OutOfMemoryError e) { return "{\"ok\":false,\"error\":\"erro\"}"; }
        }
    }

    /** Volta ao modo antigo. Os arquivos continuam no telefone como cópia. */
    static boolean deactivate(File base) {
        File d = dir(base);
        if (d == null) return false;
        synchronized (LOCK) {
            File mode = new File(d, "mode");
            return !mode.exists() || mode.delete();
        }
    }

    static String info(File base) {
        File d = dir(base);
        boolean on = active(base);
        String meta = d == null ? "" : readFile(new File(d, "main.meta"));
        boolean reserve = d != null && new File(d, "reserve.json").isFile();
        return "{\"active\":" + on + ",\"exists\":" + (meta.length() > 2) + ",\"reserve\":" + reserve + ",\"source\":\"" + lastSource + "\""
            + (meta.length() > 2 ? "," + meta.substring(1, meta.length() - 1) : "") + "}";
    }
}
