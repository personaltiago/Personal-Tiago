package com.tiagolima.agendapersonal;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import org.json.JSONObject;

/** Short, foreground-only preview. Does not schedule, cancel or deliver alarms. */
final class SoundPreview {
    private final Context context;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private volatile String kind = "", error = "";
    private boolean enabled;
    private final Runnable timeout = this::stop;

    SoundPreview(Context context) { this.context = context; }

    void resume() { enabled = true; }
    void pause() { enabled = false; stop(); }

    void play(String requested) {
        stop();
        if (!enabled || !("lesson".equals(requested) || "timer".equals(requested))) return;
        kind = requested;
        try {
            Uri sound = "timer".equals(requested) ? AudioSettings.timerSound(context) : AudioSettings.lessonSound(context);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationChannel channel = manager == null ? null : manager.getNotificationChannel("timer".equals(requested)
                        ? AudioSettings.timerChannelId(context) : AudioSettings.lessonChannelId(context));
                if (channel != null) sound = channel.getSound();
            }
            // Match the configured channel, including a deliberately silent channel.
            if (sound == null) {
                if (Build.VERSION.SDK_INT >= 26) {
                    NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                    NotificationChannel channel = manager == null ? null : manager.getNotificationChannel("timer".equals(requested)
                            ? AudioSettings.timerChannelId(context) : AudioSettings.lessonChannelId(context));
                    if (channel != null) { fail("Este aviso está sem som. Escolha um áudio ou confira as configurações do despertador."); return; }
                }
                sound = Settings.System.DEFAULT_ALARM_ALERT_URI;
            }
            final MediaPlayer next = new MediaPlayer();
            player = next;
            next.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            next.setDataSource(context, sound);
            next.setOnPreparedListener(mp -> {
                if (player != mp || !enabled) return;
                try { mp.start(); handler.removeCallbacks(timeout); handler.postDelayed(timeout, 15000); }
                catch (Exception ignored) { fail("Não foi possível reproduzir este áudio. Escolha outro arquivo."); }
            });
            next.setOnCompletionListener(mp -> { if (player == mp) stop(); });
            next.setOnErrorListener((mp, what, extra) -> {
                if (player == mp) fail("Não foi possível reproduzir este áudio. Escolha outro arquivo.");
                return true;
            });
            // Bound loading as well as playback, including corrupt/unavailable files.
            handler.postDelayed(timeout, 15000);
            next.prepareAsync();
        } catch (Exception ignored) { fail("Não foi possível abrir este áudio. Escolha o arquivo novamente."); }
    }

    void stop() {
        handler.removeCallbacks(timeout);
        MediaPlayer previous = player; player = null;
        kind = ""; error = "";
        if (previous != null) { try { previous.release(); } catch (Exception ignored) {} }
    }

    private void fail(String message) { stop(); error = message; }

    String status() {
        try { return new JSONObject().put("kind", kind).put("error", error).toString(); }
        catch (Exception ignored) { return "{}"; }
    }
}
