package com.tiagolima.agendapersonal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import org.json.JSONObject;

/** Plays the rest alert independently of the notification and the activity lifecycle. */
public final class WorkoutRestAlarmService extends Service {
    private static final String CHANNEL = "agenda_personal_rest_playback_v1";
    private static final String PREFS = "agenda_personal_rest_playback";
    private static final int NOTICE = 174405;
    private static final long PREPARE_MS = 4_000L;
    private static final long PLAY_MS = 15_000L;
    static final String STOP_ACTION = "com.tiagolima.agendapersonal.STOP_WORKOUT_REST";
    static final String EXTRA_TOKEN = "restAlertToken";
    private static final String EXTRA_MESSAGE = "restAlertMessage";

    // Only read or assigned on the main looper. The pending token survives a process restart.
    private static WorkoutRestAlarmService running;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable prepareTimeout = this::recoverSound;
    private final Runnable stopTimeout = () -> finish(true);
    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;
    private String token = "";
    private String message = "";
    private int requestId;
    private boolean foreground;
    private boolean usingBundled;

    static boolean request(Context context, JSONObject plan, String message) {
        String token = plan.optString("classDate") + "|" + plan.optLong("triggerAtMillis");
        if (!prefs(context).edit().putString(EXTRA_TOKEN, token).commit()) return false;
        try {
            context.startForegroundService(new Intent(context, WorkoutRestAlarmService.class)
                    .putExtra(EXTRA_TOKEN, token).putExtra(EXTRA_MESSAGE, message));
            return true;
        } catch (RuntimeException error) {
            prefs(context).edit().remove(EXTRA_TOKEN).apply();
            return false;
        }
    }

    static void cancel(Context context, String expected) {
        synchronized (AlarmScheduler.class) {
            String pending = pendingToken(context);
            if (expected != null && !expected.equals(pending)) return;
            prefs(context).edit().remove(EXTRA_TOKEN).apply();
            if (!pending.isEmpty()) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (running != null && pending.equals(running.token)) running.finish(false);
                });
            }
        }
    }

    static void cancelStudent(Context context, long trigger) {
        synchronized (AlarmScheduler.class) {
            String pending = pendingToken(context);
            String prefix = AlarmScheduler.STUDENT_REST_KEY + "|";
            if (trigger == 0L ? pending.startsWith(prefix) : pending.equals(prefix + trigger)) cancel(context, pending);
        }
    }

    static void cancelTeacher(Context context) {
        synchronized (AlarmScheduler.class) {
            String pending = pendingToken(context);
            if (!pending.isEmpty() && !pending.startsWith(AlarmScheduler.STUDENT_REST_KEY + "|")) cancel(context, pending);
        }
    }

    static String createChannel(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Fim do descanso", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Cartão do aviso de descanso da Agenda Personal.");
            channel.setSound(null, null);
            manager.createNotificationChannel(channel);
        }
        return CHANNEL;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private static String pendingToken(Context context) {
        return prefs(context).getString(EXTRA_TOKEN, "");
    }

    @Override public void onCreate() {
        super.onCreate();
        running = this;
        createChannel(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        synchronized (AlarmScheduler.class) {
            requestId = startId;
            String requested = intent == null ? null : intent.getStringExtra(EXTRA_TOKEN);
            if (requested == null || requested.isEmpty() || !requested.equals(pendingToken(this))) {
                if (token.isEmpty()) {
                    // An interval may have been cancelled while Android was starting this service.
                    try { promote(AlarmReceiver.workoutRestNotice(this, CHANNEL, "Descanso do treino")); }
                    catch (RuntimeException ignored) { }
                    finish(false);
                }
                return START_NOT_STICKY;
            }
            if (requested.equals(token)) return START_NOT_STICKY;
            releasePlayer();
            token = requested;
            message = intent.getStringExtra(EXTRA_MESSAGE);
            Intent stop = new Intent(this, AlarmReceiver.class).setAction(STOP_ACTION)
                    .setData(Uri.parse("agenda-personal://stop-rest/" + Uri.encode(token)))
                    .putExtra(EXTRA_TOKEN, token);
            PendingIntent stopIntent = PendingIntent.getBroadcast(this, NOTICE, stop,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder notice = AlarmReceiver.workoutRestNotice(this, CHANNEL, message)
                    .setOngoing(true).setAutoCancel(false)
                    .addAction(android.R.drawable.ic_media_pause, "Parar", stopIntent);
            try { promote(notice); }
            catch (RuntimeException error) {
                boolean posted = AlarmReceiver.publishWorkoutRestNotice(this, message, true);
                AlarmStore.recordDelivery(this, posted ? "Aviso sonoro de reserva publicado pelo Android."
                        : "Intervalo encerrado. O Android recusou o aviso de reserva.");
                finish(false);
                return START_NOT_STICKY;
            }
            String channelId = AudioSettings.restChannelId(this);
            String issue = AlarmStatus.soundIssue(this, channelId);
            if (!issue.isEmpty()) {
                AlarmStore.recordDelivery(this, "Intervalo encerrado sem som: " + issue);
                finish(true);
                return START_NOT_STICKY;
            }
            keepCpuAwake();
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel channel = manager == null ? null : manager.getNotificationChannel(channelId);
            Uri bundled = AudioSettings.bundledRestSound(this);
            Uri selected = channel == null ? null : channel.getSound();
            loadSound(selected == null ? bundled : selected, selected == null || bundled.equals(selected));
        }
        return START_NOT_STICKY;
    }

    private void promote(Notification.Builder notice) {
        if (Build.VERSION.SDK_INT >= 31) notice.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        startForeground(NOTICE, notice.build());
        foreground = true;
    }

    private void keepCpuAwake() {
        PowerManager manager = (PowerManager) getSystemService(POWER_SERVICE);
        if (manager == null) return;
        try {
            if (wakeLock == null) wakeLock = manager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AgendaPersonal:Descanso");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(30_000L);
        } catch (RuntimeException ignored) { }
    }

    private void loadSound(Uri sound, boolean bundled) {
        releasePlayer();
        usingBundled = bundled;
        try {
            MediaPlayer next = new MediaPlayer();
            player = next;
            next.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            next.setDataSource(this, sound);
            next.setOnPreparedListener(this::playPrepared);
            next.setOnCompletionListener(mp -> { if (mp == player) finish(true); });
            next.setOnErrorListener((mp, what, extra) -> {
                if (mp == player) recoverSound();
                return true;
            });
            handler.postDelayed(prepareTimeout, PREPARE_MS);
            next.prepareAsync();
        } catch (Exception error) { recoverSound(); }
    }

    private void playPrepared(MediaPlayer ready) {
        synchronized (AlarmScheduler.class) {
            if (ready != player) return;
            if (!token.equals(pendingToken(this))) { finish(false); return; }
            handler.removeCallbacks(prepareTimeout);
            try {
                ready.start();
                AlarmStore.recordDelivery(this, "Toque do descanso iniciado pela Agenda Personal.");
                handler.postDelayed(stopTimeout, PLAY_MS);
            } catch (RuntimeException error) { recoverSound(); }
        }
    }

    private void recoverSound() {
        synchronized (AlarmScheduler.class) {
            if (!token.equals(pendingToken(this))) { finish(false); return; }
            if (!usingBundled) { loadSound(AudioSettings.bundledRestSound(this), true); return; }
            AlarmStore.recordDelivery(this, "Intervalo encerrado. Falha ao reproduzir o toque de descanso.");
            finish(true);
        }
    }

    private void releasePlayer() {
        handler.removeCallbacks(prepareTimeout);
        handler.removeCallbacks(stopTimeout);
        MediaPlayer previous = player;
        player = null;
        if (previous != null) {
            try { previous.release(); } catch (RuntimeException ignored) { }
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (RuntimeException ignored) { }
        }
        wakeLock = null;
    }

    private void finish(boolean keepNotice) {
        synchronized (AlarmScheduler.class) {
            boolean current = !token.isEmpty() && token.equals(pendingToken(this));
            if (current) prefs(this).edit().remove(EXTRA_TOKEN).apply();
            releasePlayer();
            releaseWakeLock();
            if (foreground) {
                stopForeground(STOP_FOREGROUND_REMOVE);
                foreground = false;
            }
            if (keepNotice && current) AlarmReceiver.publishWorkoutRestNotice(this, message, false);
            token = "";
            stopSelfResult(requestId);
        }
    }

    @Override public void onDestroy() {
        if (running == this) running = null;
        releasePlayer();
        releaseWakeLock();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
