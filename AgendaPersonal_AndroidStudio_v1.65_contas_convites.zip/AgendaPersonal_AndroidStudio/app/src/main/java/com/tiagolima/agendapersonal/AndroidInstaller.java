package com.tiagolima.agendapersonal;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

/** Android installers have a separate channel and are never applied as web content. */
final class AndroidInstaller {
    static final int PICK_REQUEST = 3401;
    static final int PERMISSION_REQUEST = 3402;
    private static final long MAX_APK = 150L * 1024 * 1024;
    private static final String ENDPOINT = UpdateManager.SITE_URL + "/api/android-installer";
    private static final String APK_PATH = "/personaltiago/Personal-Tiago/releases/download/android-";
    private static final String APK_NAME = "AgendaPersonal-Android.apk";
    private final MainActivity activity;
    private final WebView webView;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean closed;
    private boolean busy;
    private String pendingProof;
    private String selectedHash;
    private File verifiedApk;

    AndroidInstaller(MainActivity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    void choose() {
        if (busy) { message("Aguarde a operação do instalador."); return; }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/vnd.android.package-archive");
        try { activity.startActivityForResult(intent, PICK_REQUEST); }
        catch (Exception e) { message("Não foi possível abrir o seletor de instaladores."); }
    }

    void publish(Uri uri) {
        if (uri == null || busy || !"content".equals(uri.getScheme())) return;
        busy = true;
        message("Conferindo o APK selecionado…");
        worker.execute(() -> {
            try (InputStream input = activity.getContentResolver().openInputStream(uri)) {
                if (input == null) throw new Exception();
                String hash = transfer(input, null, MAX_APK, -1, null);
                onUi(() -> {
                    pendingProof = UUID.randomUUID().toString();
                    String requestId = pendingProof;
                    selectedHash = hash;
                    String proof = JSONObject.quote(requestId);
                    String script = "(async()=>{let token='';try{if(window.APaccounts?.isTeacher())"
                        + "token=await APaccounts.getPublicationToken()}catch(_){}"
                        + "Android.submitInstallerProof(" + proof + ",token||'')})()";
                    webView.evaluateJavascript(script, null);
                    webView.postDelayed(() -> {
                        if (requestId.equals(pendingProof)) submitProof(requestId, "");
                    }, 18000);
                });
            } catch (Exception e) { onUi(() -> finish("Não foi possível ler o instalador selecionado.")); }
        });
    }

    void submitProof(String proof, String token) {
        if (closed || pendingProof == null || !pendingProof.equals(proof)) return;
        String hash = selectedHash;
        pendingProof = null;
        selectedHash = null;
        if (token == null || !token.matches("[A-Za-z0-9._-]{30,12000}")) {
            finish("Entre novamente com a conta do professor para publicar o instalador.");
            return;
        }
        new AlertDialog.Builder(activity).setTitle("Publicar instalador Android?")
            .setMessage("Os alunos poderão baixar a atualização na seção Instalador Android do Agenda.")
            .setNegativeButton("Cancelar", (d, which) -> busy = false)
            .setOnCancelListener(d -> busy = false)
            .setPositiveButton("Publicar", (d, which) -> worker.execute(() -> {
                try {
                    JSONObject release = request(hash, token).getJSONObject("manifest");
                    onUi(() -> finish("Instalador Android " + release.optString("version") + " disponível para os alunos."));
                } catch (Exception e) { onUi(() -> finish(error(e))); }
            })).show();
    }

    void show() {
        if (busy) { message("Aguarde a operação do instalador."); return; }
        if (verifiedApk != null && verifiedApk.isFile()) { showInstall(); return; }
        busy = true;
        message("Buscando instalador Android…");
        worker.execute(() -> {
            try {
                JSONObject release = request(null, null);
                if (!release.optBoolean("available")) {
                    onUi(() -> finish("Ainda não há instalador Android publicado pela Central."));
                    return;
                }
                String version = release.getString("version");
                if (versionOrder(version) <= versionOrder(installed(0).versionName)) {
                    onUi(() -> finish("O instalador Android deste aparelho está atualizado."));
                    return;
                }
                String hash = release.getString("sha256");
                long size = release.getLong("size");
                URL url = new URL(release.getString("url"));
                if (!hash.matches("[a-f0-9]{64}") || size < 1 || size > MAX_APK
                    || !httpsHost(url, "github.com") || !url.getPath().matches(APK_PATH
                        + java.util.regex.Pattern.quote(version) + "-conteudo-[0-9.]+-[0-9]+/" + APK_NAME.replace(".", "\\.")))
                    throw new Exception();
                onUi(() -> {
                    busy = false;
                    new AlertDialog.Builder(activity).setTitle("Android " + version + " disponível")
                        .setMessage("Baixe a atualização pelo Agenda. Depois, confirme no instalador do Android.")
                        .setNegativeButton("Agora não", null)
                        .setPositiveButton("Baixar atualização", (d, which) -> download(url, version, hash, size)).show();
                });
            } catch (Exception e) { onUi(() -> finish(error(e))); }
        });
    }

    private JSONObject request(String hash, String token) throws Exception {
        HttpURLConnection connection = open(new URL(ENDPOINT));
        try {
            if (hash != null) {
                byte[] body = new JSONObject().put("sha256", hash).toString().getBytes(StandardCharsets.UTF_8);
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Authorization", "Bearer " + token);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setFixedLengthStreamingMode(body.length);
                connection.setDoOutput(true);
                try (java.io.OutputStream output = connection.getOutputStream()) { output.write(body); }
            }
            int status = connection.getResponseCode();
            boolean ok = status >= 200 && status < 300;
            try (InputStream input = ok ? connection.getInputStream() : connection.getErrorStream()) {
                if (input == null) throw new Exception();
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                for (int n; (n = input.read(buffer)) != -1;) {
                    if (output.size() + n > 16384) throw new Exception();
                    output.write(buffer, 0, n);
                }
                JSONObject data = new JSONObject(new String(output.toByteArray(), StandardCharsets.UTF_8));
                if (!ok) throw new InstallerError(data.optString("error", "O servidor não concluiu a operação."));
                return data;
            }
        } finally { connection.disconnect(); }
    }

    private void download(URL url, String version, String hash, long size) {
        if (busy || closed) return;
        busy = true;
        AlertDialog progress = new AlertDialog.Builder(activity).setTitle("Baixando atualização Android")
            .setMessage("Aguarde enquanto o Agenda baixa e confere o instalador.")
            .setCancelable(false).show();
        worker.execute(() -> {
            File file = null;
            HttpURLConnection connection = null;
            try {
                File directory = new File(activity.getCacheDir(), "android-installer");
                if (!directory.mkdirs() && !directory.isDirectory()) throw new Exception();
                File[] stale = directory.listFiles((dir, name) -> name.startsWith("agenda-") && name.endsWith(".apk"));
                if (stale != null) for (File old : stale) old.delete();
                file = File.createTempFile("agenda-", ".apk", directory);
                URL downloadUrl = url;
                for (int hop = 0; hop < 4; hop++) {
                    connection = open(downloadUrl);
                    int code = connection.getResponseCode();
                    if (code == 200) break;
                    String location = connection.getHeaderField("Location");
                    connection.disconnect();
                    connection = null;
                    if (code < 300 || code >= 400 || location == null) throw new Exception();
                    downloadUrl = new URL(downloadUrl, location);
                    if (!httpsHost(downloadUrl, "github.com") && !httpsHost(downloadUrl, "release-assets.githubusercontent.com")
                        && !httpsHost(downloadUrl, "objects.githubusercontent.com")) throw new Exception();
                }
                if (connection == null) throw new Exception();
                try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(file)) {
                    if (!hash.equals(transfer(input, output, size, size, percent -> onUi(() ->
                        progress.setMessage("Baixando instalador… " + percent + "%")))))
                        throw new InstallerError("O arquivo baixado está diferente do oficial. Tente novamente.");
                }
                verifyPackage(file, version);
                File ready = file;
                file = null;
                activity.runOnUiThread(() -> {
                    if (closed || activity.isFinishing()) { ready.delete(); return; }
                    progress.dismiss();
                    busy = false;
                    verifiedApk = ready;
                    showInstall();
                });
            } catch (Exception e) {
                onUi(() -> { progress.dismiss(); finish(error(e)); });
            } finally {
                if (connection != null) connection.disconnect();
                if (file != null) file.delete();
            }
        });
    }

    private static boolean httpsHost(URL url, String host) {
        return "https".equals(url.getProtocol()) && host.equals(url.getHost()) && url.getUserInfo() == null
            && (url.getPort() == -1 || url.getPort() == 443);
    }

    private static HttpURLConnection open(URL url) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setInstanceFollowRedirects(false);
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(25000);
        return connection;
    }

    private static String transfer(InputStream input, FileOutputStream output, long limit, long expected, java.util.function.IntConsumer progress) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[65536];
        long total = 0;
        int reported = 0;
        for (int n; (n = input.read(buffer)) != -1;) {
            total += n;
            if (Thread.currentThread().isInterrupted() || total > limit) throw new Exception();
            digest.update(buffer, 0, n);
            if (output != null) output.write(buffer, 0, n);
            if (progress != null) {
                int percent = (int) (total * 100 / expected);
                if (percent >= reported + 5) { reported = percent; progress.accept(percent); }
            }
        }
        if (total == 0 || (expected >= 0 && total != expected)) throw new Exception();
        StringBuilder hex = new StringBuilder(64);
        for (byte value : digest.digest()) {
            hex.append(Character.forDigit((value & 255) >>> 4, 16));
            hex.append(Character.forDigit(value & 15, 16));
        }
        return hex.toString();
    }

    private PackageInfo installed(int flags) throws Exception {
        return activity.getPackageManager().getPackageInfo(activity.getPackageName(), flags);
    }

    @SuppressWarnings("deprecation")
    private void verifyPackage(File apk, String version) throws Exception {
        boolean modern = Build.VERSION.SDK_INT >= 28;
        int flags = modern ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
        PackageInfo current = installed(flags);
        PackageInfo update = activity.getPackageManager().getPackageArchiveInfo(apk.getPath(), flags);
        if (update == null || !current.packageName.equals(update.packageName) || !version.equals(update.versionName)
            || (modern ? update.getLongVersionCode() <= current.getLongVersionCode() : update.versionCode <= current.versionCode))
            throw new InstallerError("O instalador não é uma versão mais recente do Agenda Personal deste aparelho.");
        if (modern && (current.signingInfo == null || update.signingInfo == null)) throw new Exception();
        android.content.pm.Signature[] old = modern ? current.signingInfo.getApkContentsSigners() : current.signatures;
        android.content.pm.Signature[] next = modern ? update.signingInfo.getApkContentsSigners() : update.signatures;
        if (old == null || next == null || old.length == 0 || old.length != next.length
            || !Arrays.asList(old).containsAll(Arrays.asList(next)))
            throw new InstallerError("A assinatura do instalador é diferente da assinatura deste Agenda.");
    }

    private static long versionOrder(String version) {
        if (version == null || !version.matches("[0-9]{1,5}\\.[0-9]{1,5}")) throw new IllegalArgumentException();
        String[] parts = version.split("\\.");
        return Integer.parseInt(parts[0]) * 100000L + Integer.parseInt(parts[1]);
    }

    private void showInstall() {
        new AlertDialog.Builder(activity).setTitle("Atualização pronta")
            .setMessage("O Android vai pedir sua confirmação. O Agenda será atualizado por cima da versão instalada.")
            .setNegativeButton("Agora não", null)
            .setPositiveButton("Instalar atualização", (d, which) -> install()).show();
    }

    private void install() {
        if (verifiedApk == null || !verifiedApk.isFile()) { message("Baixe o instalador novamente."); return; }
        try {
            if (!activity.getPackageManager().canRequestPackageInstalls()) {
                activity.startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + activity.getPackageName())), PERMISSION_REQUEST);
                return;
            }
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", verifiedApk);
            activity.startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
        } catch (Exception e) { message("Não foi possível abrir o instalador do Android."); }
    }

    void afterPermission() {
        if (activity.getPackageManager().canRequestPackageInstalls()) showInstall();
        else message("O Android precisa da sua autorização para abrir o instalador.");
    }

    private void onUi(Runnable action) {
        activity.runOnUiThread(() -> { if (!closed && !activity.isFinishing()) action.run(); });
    }
    private void message(String text) { Toast.makeText(activity, text, Toast.LENGTH_LONG).show(); }
    private void finish(String text) { busy = false; message(text); }
    private static String error(Exception e) {
        return e instanceof InstallerError ? e.getMessage() : "Não foi possível concluir. Confira a conexão e tente novamente.";
    }
    void close() { closed = true; worker.shutdownNow(); }
    private static final class InstallerError extends Exception {
        InstallerError(String text) { super(text); }
    }
}
