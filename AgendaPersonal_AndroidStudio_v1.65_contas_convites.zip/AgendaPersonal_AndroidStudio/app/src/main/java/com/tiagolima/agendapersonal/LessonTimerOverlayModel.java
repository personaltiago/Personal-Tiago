package com.tiagolima.agendapersonal;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Only rest intervals float; lesson timers remain in the workout and alarm store. */
final class LessonTimerOverlayModel {
    static final class Timer {
        final String key, student, kind, exercise, accent;
        final long endAt;
        Timer(String key, String student, long endAt) {
            this(key, student, endAt, "timer", "", "#9951D5");
        }
        Timer(String key, String student, long endAt, String kind, String exercise, String accent) {
            this.key = key; this.student = student; this.endAt = endAt;
            this.kind = kind; this.exercise = exercise; this.accent = accent;
        }
    }

    static List<Timer> active(List<Timer> timers, long now) {
        List<Timer> result = new ArrayList<>();
        for (Timer timer : timers) {
            if (timer != null && "workout-rest".equals(timer.kind) && timer.key != null && !timer.key.isEmpty() && timer.endAt > now)
                result.add(timer);
        }
        result.sort(Comparator.comparingLong((Timer t) -> t.endAt).thenComparing(t -> t.key));
        return result;
    }

    static String signature(List<Timer> timers) {
        StringBuilder out = new StringBuilder();
        for (Timer timer : timers) {
            // Length prefixes avoid collisions in saved timer identifiers.
            out.append(timer.key.length()).append(':').append(timer.key)
                    .append(':').append(timer.endAt).append(';');
        }
        return out.toString();
    }

    static String clock(long remainingMillis) {
        long seconds = remainingMillis <= 0 ? 0 : 1 + (remainingMillis - 1) / 1000;
        return String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60);
    }
}
