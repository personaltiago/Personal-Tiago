package com.tiagolima.agendapersonal;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.AtomicFile;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebResourceResponse;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONTokener;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Streams local pages from a private HTTPS origin, with a non-destructive legacy-data import. */
public final class UpdateManager {
    public static final String SITE_URL = "https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site";
    public static final int IMPORT_REQUEST = 3003;
    private static final String BASE_VERSION = "1.12.215";
    static final int BASE_SEQUENCE = 321;
    private static final String HOME_URL = LocalPages.HOME;
    // The built-in agenda includes the professor, student and invitation screens.
    // It is intentionally larger than a small web page, so keep this limit above
    // the packaged asset size as well as future on-device updates.
    private static final int MAX_BYTES = 24 * 1024 * 1024;
    private final UpdateDownloads downloads;
    private final MainActivity activity;
    private final WebView webView;
    private final SharedPreferences preferences;
    private final File activeFile, previousFile, snapshotFile, legacyFile, manualRestoreFile, verifiedReleaseFile;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService checkExecutor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile JSONObject active;
    private volatile StoredRelease storedRelease;
    private volatile JSONObject manifest;
    private AlertDialog dialog;
    private AlertDialog reviewDialog;
    private JSONObject reviewBundle;
    private JSONObject reviewInstalledRelease;
    private int reviewGeneration, reviewInstalledSequence;
    private boolean reviewRequiresTeacher, reviewConfirming;
    private volatile boolean busy;
    private volatile boolean checking;
    private volatile int checkGeneration;
    private Button restoreButton, importButton, conferenceButton, detailsButton, verifyButton, publishButton, closeButton;
    private volatile boolean destroyed;
    private final ArrayList<Uri> pageHistory = new ArrayList<>();
    private volatile int pageGeneration;
    private String pageToken = "";
    private volatile PreparedPage prepared;
    private boolean pageAcknowledged;
    private volatile boolean teacherAccount;
    private volatile boolean checkingBackground;
    private long lastBackgroundCheck;

    private static final class PreparedPage {
        final String url;
        final byte[] html;
        PreparedPage(String url, String html) {
            this.url = url;
            this.html = html.getBytes(StandardCharsets.UTF_8);
        }
    }

    private static final class StoredRelease {
        final JSONObject release;
        final String sha256;
        StoredRelease(JSONObject release, String sha256) { this.release = release; this.sha256 = sha256; }
    }

    UpdateManager(MainActivity activity, WebView webView) {
        this.activity = activity; this.webView = webView;
        preferences = activity.getSharedPreferences("agenda_updates_v1", 0);
        File folder = new File(activity.getFilesDir(), "updates");
        if (!folder.exists()) folder.mkdirs();
        activeFile = new File(folder, "active.json"); previousFile = new File(folder, "previous.json");
        snapshotFile = new File(folder, "data-before-update.json");
        legacyFile = new File(folder, "legacy-storage.json");
        manualRestoreFile = new File(folder, "release-before-manual-restore.json");
        verifiedReleaseFile = new File(folder, "verified-release.json");
        if (preferences.getBoolean("manualRestorePending", false)) recoverManualRestore();
        if (preferences.getBoolean("pending", false)) rollbackFiles();
        active = readActive();
        downloads = new UpdateDownloads(activity, webView, new UpdateDownloads.Sources() {
            public JSONArray list() throws Exception {
                JSONArray result = new JSONArray();
                try { result.put(downloadSource("installed").meta); } catch (Exception ignored) { }
                return result;
            }
            public UpdateDownloads.Source resolve(String id) throws Exception { return downloadSource(id); }
        }, () -> teacherAccount, () -> busy);
    }

    public void start() {
        activity.runOnUiThread(() -> {
            if (destroyed || activity.isFinishing()) return;
            activity.showBootLoading();
            if (preferences.getBoolean("legacyImported", false)
                || (preferences.getBoolean("legacyCaptured", false) && legacyFile.exists())) {
                openHome();
                return;
            }
            final int generation = ++pageGeneration;
            prepared = null;
            // Use the actual old URL, not loadData's opaque-origin page. The first
            // script in this lightweight asset exports existing storage without deleting it.
            webView.loadUrl("file:///android_asset/index.html");
            handler.postDelayed(() -> {
                if (!destroyed && generation == pageGeneration)
                    activity.showBootError("AP-MIGRATION-TIMEOUT");
            }, 15000);
        });
    }

    public void captureLegacyStorage(String data) {
        if (destroyed || data == null || preferences.getBoolean("legacyCaptured", false)) return;
        executor.execute(() -> {
            try {
                byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
                if (bytes.length > MAX_BYTES) throw new Exception("Snapshot grande");
                new JSONObject(data);
                writeAtomic(legacyFile, bytes);
                if (!preferences.edit().putBoolean("legacyCaptured", true).commit())
                    throw new Exception("Falha ao registrar backup");
                activity.runOnUiThread(this::openHome);
            } catch (Exception e) { activity.showBootError("AP-MIGRATION-BACKUP"); }
        });
    }

    /** Only this exact reserved origin is intercepted; it never reaches the network. */
    public WebResourceResponse localResponse(Uri uri) {
        if (!LocalPages.isSecureOrigin(uri)) return null;
        String asset = LocalPages.assetName(uri);
        if (asset == null) return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
            new ByteArrayInputStream(new byte[0]));
        try {
            PreparedPage current = prepared;
            if (current != null && current.url.equals(uri.toString()))
                return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(current.html));
            JSONObject release = active;
            if (release != null && release.getJSONObject("files").has(asset))
                return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(
                    release.getJSONObject("files").getString(asset).getBytes(StandardCharsets.UTF_8)));
            return new WebResourceResponse(asset.endsWith(".png") ? "image/png" : "text/html", "UTF-8",
                activity.getAssets().open(asset));
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "UTF-8", 500, "Local Asset Error", null,
                new ByteArrayInputStream("AP-ASSET-READ".getBytes(StandardCharsets.UTF_8)));
        }
    }
    private JSONObject readActive() {
        try {
            StoredRelease stored = readStoredRelease(activeFile);
            storedRelease = stored;
            return stored.release; // Compatible local releases remain valid after restoring a lower sequence.
        }
        catch (Exception | OutOfMemoryError e) { storedRelease = null; return null; }
    }
    private StoredRelease readStoredRelease(File file) throws Exception {
        UpdateStorage.StoredText stored = UpdateStorage.readText(file, MAX_BYTES);
        return new StoredRelease(validateBundle(new JSONObject(stored.text)), stored.sha256);
    }
    private JSONObject validateBundle(JSONObject value) throws Exception {
        if (value.optInt("format") != 1 || !activity.getPackageName().equals(value.optString("appId")) || value.optInt("bridgeVersion") != 3 || value.optInt("dataSchema") != 4 || value.optInt("sequence") < 1) throw new Exception("Esta atualização precisa de outra versão do APK.");
        String version = value.optString("version");
        if (!version.matches("[0-9]+\\.[0-9]+\\.[0-9]+")) throw new Exception("A versão desta atualização é inválida.");
        String[] components = version.split("\\.");
        int major = Integer.parseInt(components[0]), minor = Integer.parseInt(components[1]);
        if (major < 1 || (major == 1 && minor < 11)) throw new Exception("Esta atualização é anterior à versão incluída neste APK.");
        JSONObject files = value.getJSONObject("files");
        if (files.length() < 2 || files.length() > 4 || !files.has("index.html") || !files.has("avaliacoes.html")) throw new Exception("A atualização está incompleta.");
        for (String asset : new String[]{"index.html", "avaliacoes.html", "professor.html", "cadastro.html"}) {
            if (!files.has(asset)) continue;
            String html = files.getString(asset);
            if ((!asset.equals("cadastro.html") && !html.contains("data-agenda-ready")) || !containsHtmlEnd(html) || html.length() > MAX_BYTES) throw new Exception("O arquivo da atualização não é compatível.");
            if (asset.equals("index.html") && !(html.contains("agendaPersonalTL_v1") && html.contains("syncNativeAlarms"))
                && !(html.contains("ap-student-accounts") && html.contains("ap-embedded-professor"))) throw new Exception("Esta atualização pertence a outra agenda.");
        }
        int known = 2 + (files.has("professor.html") ? 1 : 0) + (files.has("cadastro.html") ? 1 : 0);
        if (files.length() != known) throw new Exception("A atualização contém arquivos não previstos.");
        return value;
    }
    private static boolean containsHtmlEnd(String html) {
        for (int i = html.length() - 7; i >= 0; i--)
            if (html.charAt(i) == '<' && html.regionMatches(true, i, "</html>", 0, 7)) return true;
        return false;
    }
    public static boolean isLocalPage(Uri uri) {
        return LocalPages.isPage(uri);
    }
    private String pageHtml(Uri uri, JSONObject release, String token, int releaseSequence) throws Exception {
        String asset = LocalPages.assetName(uri);
        if (asset == null) throw new Exception("Página local inválida.");
        String html;
        if (release != null && release.getJSONObject("files").has(asset)) html = release.getJSONObject("files").getString(asset);
        else try (InputStream input = activity.getAssets().open(asset)) { html = new String(readLimited(input, MAX_BYTES), StandardCharsets.UTF_8); }
        String script = "<script>window.__agendaNativeReleaseToken=" + JSONObject.quote(token) + ";window.__agendaNativeReleaseSequence=" + releaseSequence + ";</script>";
        script += "<script>window.addEventListener('error',function(e){if(e.error){"
            + "if(!window.__agendaNativeBootReady){window.__agendaBootFailed=true;"
            + "if(window.Android&&Android.bootFailed)Android.bootFailed('AP-JS-'+(e.lineno||0))}"
            + "else if(typeof window.toast==='function')window.toast('Não foi possível concluir esta ação. Tente novamente.')}});</script>";
        if (!preferences.getBoolean("legacyImported", false) && legacyFile.exists()) {
            String snapshot = Base64.encodeToString(Files.readAllBytes(legacyFile.toPath()), Base64.NO_WRAP);
            script += "<script>(function(){try{var b=atob('" + snapshot + "');var a=Uint8Array.from(b,function(c){return c.charCodeAt(0)});"
                + "var d=JSON.parse(new TextDecoder().decode(a));Object.keys(d).forEach(function(k){"
                + "if(localStorage.getItem(k)===null)localStorage.setItem(k,d[k])});window.__agendaLegacyImported=true;"
                + "}catch(e){window.__agendaRestoreFailed=true;if(window.Android&&Android.bootFailed)Android.bootFailed('AP-MIGRATION-IMPORT')}})();</script>";
        }
        if (preferences.getBoolean("restoreData", false) && snapshotFile.exists()) {
            String snapshot = Base64.encodeToString(Files.readAllBytes(snapshotFile.toPath()), Base64.NO_WRAP);
            script += "<script>(function(){try{var b=atob('" + snapshot + "');var a=Uint8Array.from(b,function(c){return c.charCodeAt(0)});var d=JSON.parse(new TextDecoder().decode(a));localStorage.clear();Object.keys(d).forEach(function(k){localStorage.setItem(k,d[k])});}catch(e){window.__agendaRestoreFailed=true}})();</script>";
        }
        Matcher head = java.util.regex.Pattern.compile("<head\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
        if (!head.find()) throw new Exception("A página não contém o cabeçalho esperado.");
        return html.substring(0, head.end()) + script + NativeLaunch.HTML + html.substring(head.end());
    }
    public void openPage(Uri uri) { openPage(uri, false); }
    private void openHome() { openPage(Uri.parse(HOME_URL), true); }
    private void openPage(Uri uri, boolean resetHistory) {
        if (!isLocalPage(uri)) return;
        final Uri localUri = LocalPages.canonical(uri);
        activity.runOnUiThread(() -> {
            if (destroyed || activity.isFinishing()) return;
            if (resetHistory) pageHistory.clear();
            if (pageHistory.isEmpty() || !pageHistory.get(pageHistory.size() - 1).equals(localUri)) pageHistory.add(localUri);
            final int generation = ++pageGeneration;
            final String token = UUID.randomUUID().toString();
            final JSONObject release = active;
            final int releaseSequence = release == null ? BASE_SEQUENCE : release.optInt("sequence", BASE_SEQUENCE);
            executor.execute(() -> {
                try {
                    String html = pageHtml(localUri, release, token, releaseSequence);
                    activity.runOnUiThread(() -> {
                        if (destroyed || generation != pageGeneration || activity.isFinishing()) return;
                        pageToken = token;
                        pageAcknowledged = false;
                        prepared = new PreparedPage(localUri.toString(), html);
                        activity.showBootLoading();
                        // HTML stays in an InputStream, not a multi-megabyte loadData IPC message.
                        webView.loadUrl(localUri.toString());
                        handler.postDelayed(() -> {
                            if (!destroyed && generation == pageGeneration && !pageAcknowledged)
                                activity.showBootError("AP-BOOT-TIMEOUT");
                        }, 30000);
                    });
                } catch (Exception e) {
                    activity.runOnUiThread(() -> {
                        if (destroyed || generation != pageGeneration || activity.isFinishing()) return;
                        if (preferences.getBoolean("manualRestorePending", false)) {
                            recoverManualRestore(); active = readActive(); busy = false; openHome();
                            Toast.makeText(activity, "A versão anterior não abriu. A atualização atual foi mantida.", Toast.LENGTH_LONG).show();
                        } else if (preferences.getBoolean("pending", false)) {
                            rollbackFiles(); active = readActive(); busy = false; openHome();
                            Toast.makeText(activity, "Não foi possível abrir a atualização. A versão anterior foi recuperada.", Toast.LENGTH_LONG).show();
                        } else {
                            activity.showBootError("AP-PAGE-READ");
                        }
                    });
                }
            });
        });
    }
    public boolean goBack() {
        if (pageHistory.size() < 2) return false;
        pageHistory.remove(pageHistory.size() - 1);
        Uri previous = pageHistory.remove(pageHistory.size() - 1);
        openPage(previous);
        return true;
    }
    public void pageReady() {
        activity.runOnUiThread(() -> {
            if (destroyed || pageToken.isEmpty() || activity.isFinishing()) return;
            final String token = pageToken;
            final int generation = pageGeneration, releaseSequence = sequence();
            String check = "window.__agendaNativeReleaseToken===" + JSONObject.quote(token)
                + "&&window.__agendaNativeReleaseSequence===" + releaseSequence
                + "&&!window.__agendaBootFailed&&!window.__agendaRestoreFailed"
                + "&&(window.__agendaNativeBootReady=true)";
            webView.evaluateJavascript(check, result -> {
                if (destroyed || !"true".equals(result) || generation != pageGeneration || !token.equals(pageToken)) return;
                boolean applied = preferences.getBoolean("pending", false);
                boolean restored = preferences.getBoolean("manualRestorePending", false);
                if (!preferences.edit().putBoolean("pending", false).putBoolean("restoreData", false)
                    .putBoolean("legacyImported", true).putBoolean("manualRestorePending", false).commit()) return;
                pageAcknowledged = true;
                recordVerifiedRelease(active, generation, token);
                UpdatePoller.markInstalled(activity,releaseSequence);
                activity.showBootReady();
                if (restored) {
                    new AtomicFile(manualRestoreFile).delete();
                    new AtomicFile(previousFile).delete();
                    busy = false;
                    Toast.makeText(activity, "Versão anterior restaurada. Os dados foram mantidos.", Toast.LENGTH_LONG).show();
                }
                if (applied) {
                    busy = false;
                    Toast.makeText(activity, "Atualização aplicada. Seus dados foram mantidos.", Toast.LENGTH_LONG).show();
                }
            });
        });
    }
    public void pageFinished() {
        if (!preferences.getBoolean("pending", false) && !preferences.getBoolean("manualRestorePending", false)) return;
        final int generation = pageGeneration;
        handler.postDelayed(() -> {
            if (!destroyed && generation == pageGeneration && preferences.getBoolean("manualRestorePending", false) && !activity.isFinishing()) {
                recoverManualRestore(); active = readActive(); busy = false; openHome();
                Toast.makeText(activity, "A versão anterior não abriu. A atualização atual foi mantida.", Toast.LENGTH_LONG).show();
            } else if (!destroyed && generation == pageGeneration && preferences.getBoolean("pending", false) && !activity.isFinishing()) {
                rollbackFiles(); active = readActive(); busy = false; openHome();
                Toast.makeText(activity, "A nova versão não abriu corretamente. A versão anterior foi recuperada.", Toast.LENGTH_LONG).show();
            }
        }, 30000);
    }
    private void rollbackFiles() {
        try {
            if (previousFile.exists()) UpdateStorage.copy(previousFile, activeFile, MAX_BYTES, null);
            else new AtomicFile(activeFile).delete();
            preferences.edit().putBoolean("pending", false).putBoolean("restoreData", snapshotFile.exists()).commit();
        } catch (Exception ignored) { /* Keep pending for another recovery attempt. */ }
    }
    public void showScreen() {
        activity.runOnUiThread(() -> {
            if (destroyed || activity.isFinishing()) return;
            if (dialog != null && dialog.isShowing()) return;
            final boolean teacherControls = teacherAccount;
            View actions = activity.getLayoutInflater().inflate(R.layout.update_actions, null);
            importButton = actions.findViewById(R.id.update_import);
            restoreButton = actions.findViewById(R.id.update_restore);
            conferenceButton = actions.findViewById(R.id.update_conference);
            detailsButton = actions.findViewById(R.id.update_details);
            verifyButton = actions.findViewById(R.id.update_verify);
            publishButton = actions.findViewById(R.id.update_publish);
            closeButton = actions.findViewById(R.id.update_close);
            for (Button button : new Button[]{importButton, restoreButton, conferenceButton, publishButton})
                button.setVisibility(teacherControls ? View.VISIBLE : View.GONE);
            importButton.setOnClickListener(v -> performMenuAction("import"));
            restoreButton.setOnClickListener(v -> performMenuAction("restore"));
            conferenceButton.setOnClickListener(v -> performMenuAction("conference"));
            detailsButton.setOnClickListener(v -> performMenuAction("details"));
            verifyButton.setOnClickListener(v -> performMenuAction("verify"));
            publishButton.setOnClickListener(v -> performMenuAction("publish"));
            closeButton.setOnClickListener(v -> { if (dialog != null) dialog.dismiss(); });
            dialog = new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Atualizar aplicativo")
                .setMessage(description("Escolha uma opção."))
                .setView(actions).create();
            dialog.show();
            display("Escolha uma opção.");
            check();
        });
    }
    /** Only known menu actions can cross the JavaScript bridge. */
    public void performMenuAction(String action) {
        activity.runOnUiThread(() -> {
            if (destroyed || activity.isFinishing()) return;
            boolean teacherOnly = "import".equals(action) || "restore".equals(action)
                || "conference".equals(action) || "publish".equals(action);
            if (teacherOnly && !teacherAccount) return;
            if ("details".equals(action)) { showInstalledDetails(); return; }
            if (busy) { Toast.makeText(activity, "Aguarde a operação em andamento terminar.", Toast.LENGTH_LONG).show(); return; }
            switch (action == null ? "" : action) {
                case "import": requestImport(); break;
                case "restore": confirmManualRestore(); break;
                case "conference": openWebControl(false); break;
                case "publish": openWebControl(true); break;
                case "verify": if (manifest != null && manifest.optBoolean("available")) downloadAndApply(); else check(); break;
                default: break;
            }
        });
    }
    private void openWebControl(boolean publish) {
        if (!teacherAccount) return;
        final AlertDialog current = dialog;
        final String control = publish
            ? "if(!window.APupdates||typeof APupdates.openPublisher!=='function')return false;APupdates.openPublisher();return true;"
            : "return !!(window.APReleaseCenter&&typeof APReleaseCenter.openConference==='function'&&APReleaseCenter.openConference());";
        webView.evaluateJavascript("(function(){if(!window.APaccounts||!APaccounts.isTeacher())return false;" + control + "})()", result -> {
            if (destroyed || !teacherAccount || activity.isFinishing()) return;
            if ("true".equals(result)) { if (current != null && current == dialog) current.dismiss(); }
            else Toast.makeText(activity, "Este conteúdo ainda não tem essa opção. Importe a atualização 1.12.215 ou posterior.", Toast.LENGTH_LONG).show();
        });
    }
    private void showInstalledDetails() {
        String notes = active == null
            ? "Acrescenta Download da versão em uso nos três pontos da Conferência de atualizações. Salva o pacote atual pelo seletor de arquivos, sem incluir versões antigas no APK. Baixar não instala. Preserva as funções da 1.12.213, os pets e o urso atual."
            : active.optString("notes", "");
        if (notes.trim().isEmpty()) notes = "A descrição deste pacote não foi informada. Consulte a Conferência de atualizações.";
        new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Detalhes da versão instalada")
            .setMessage(description(notes)).setPositiveButton("Fechar", null).show();
    }
    /** Manual rollback changes the web release only; it must never restore an old localStorage snapshot. */
    private void confirmManualRestore() {
        if (busy) { Toast.makeText(activity, "Aguarde a operação em andamento terminar.", Toast.LENGTH_LONG).show(); return; }
        if (active == null) { Toast.makeText(activity, "Este aparelho está usando a versão incluída no APK. Não há atualização para retirar.", Toast.LENGTH_LONG).show(); return; }
        final String targetVersion = previousVersion();
        new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Restaurar versão anterior?")
            .setMessage("Versão de destino: " + targetVersion + ".\n\nA atualização atual será retirada. Os dados dos alunos, fichas e históricos serão mantidos. Alterações feitas nas fichas não serão desfeitas.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Restaurar", (d, which) -> restorePreviousRelease())
            .show();
    }
    private String previousVersion() {
        try {
            if (previousFile.exists()) {
                JSONObject previous = readStoredRelease(previousFile).release;
                if (!contentIdentity(previous).equals(contentIdentity(active))) return previous.optString("version", BASE_VERSION);
            }
        } catch (Exception | OutOfMemoryError ignored) { }
        return BASE_VERSION + " (incluída no APK)";
    }
    private void invalidateCheck() { checkGeneration++; checking = false; manifest = null; }
    private void recoverManualRestore() {
        try {
            // The journal contains code only. Current student storage is never restored or cleared.
            if (!manualRestoreFile.exists()) throw new Exception("Cópia da versão atual indisponível.");
            UpdateStorage.copy(manualRestoreFile, activeFile, MAX_BYTES, null);
            if (preferences.edit().putBoolean("manualRestorePending", false).putBoolean("restoreData", false).commit())
                new AtomicFile(manualRestoreFile).delete();
        } catch (Exception ignored) { /* Keep the journal for recovery on the next launch. */ }
    }
    private void restorePreviousRelease() {
        if (busy || active == null) return;
        final JSONObject installedRelease = active;
        invalidateCheck(); busy = true; display("Restaurando versão anterior…");
        executor.execute(() -> {
            try {
                StoredRelease prior = null;
                if (previousFile.exists()) {
                    try {
                        StoredRelease candidate = readStoredRelease(previousFile);
                        if (!contentIdentity(candidate.release).equals(contentIdentity(installedRelease))) prior = candidate;
                    } catch (Exception ignored) { /* Invalid history falls back to the verified APK pages. */ }
                }
                saveInstalledRelease(installedRelease, manualRestoreFile);
                if (!preferences.edit().putBoolean("manualRestorePending", true).putBoolean("restoreData", false).commit())
                    throw new Exception("Não foi possível preparar a restauração.");
                if (prior != null) {
                    UpdateStorage.copy(previousFile, activeFile, MAX_BYTES, prior.sha256);
                    active = prior.release; storedRelease = prior;
                }
                else { new AtomicFile(activeFile).delete(); if (activeFile.exists()) throw new Exception("Não foi possível retirar a atualização."); }
                if (prior == null) { active = null; storedRelease = null; }
                identitySource = null; identityCache = null;
                activity.runOnUiThread(() -> {
                    if (dialog != null) dialog.dismiss();
                    // Success is announced only by pageReady after the restored release opens.
                    openHome();
                });
            } catch (Exception | OutOfMemoryError e) {
                if (preferences.getBoolean("manualRestorePending", false)) recoverManualRestore();
                active = installedRelease;
                activity.runOnUiThread(() -> {
                    busy = false;
                    display("Não foi possível restaurar. A versão atual foi mantida. Tente novamente.");
                    Toast.makeText(activity, "Não foi possível restaurar a versão anterior. A versão atual foi mantida.", Toast.LENGTH_LONG).show();
                });
            }
        });
    }
    private int sequence() { return active == null ? BASE_SEQUENCE : active.optInt("sequence", BASE_SEQUENCE); }
    private String description(String message) { return "Versão instalada: " + (active == null ? BASE_VERSION : active.optString("version", BASE_VERSION)) + "\n\n" + message; }
    private void display(String message) {
        activity.runOnUiThread(() -> {
            if (dialog != null && dialog.isShowing()) {
                TextView text = dialog.findViewById(android.R.id.message); if (text != null) text.setText(description(message));
                if (verifyButton != null) verifyButton.setEnabled(!busy && !checking);
                if (restoreButton != null) restoreButton.setEnabled(teacherAccount && !busy && active != null);
                if (importButton != null) importButton.setEnabled(teacherAccount && !busy);
                if (conferenceButton != null) conferenceButton.setEnabled(teacherAccount && !busy);
                if (publishButton != null) publishButton.setEnabled(teacherAccount && !busy);
            }
        });
    }
    private void check() {
        if (busy || checking) return;
        checking = true; manifest = null;
        final int generation = ++checkGeneration, installed = sequence();
        display("Buscando atualizações…");
        // Network lookup must not hold the local restore/import worker or its busy flag.
        checkExecutor.execute(() -> {
            String message; JSONObject available = null;
            try {
                JSONObject result = UpdateManifest.validate(new JSONObject(new String(fetch("/api/manifest", 65536), StandardCharsets.UTF_8)),activity.getPackageName());
                if (!result.optBoolean("available")) message = "Ainda não há uma atualização publicada.";
                else if (result.optInt("sequence") <= installed) { available = result; message = "Versão publicada: " + result.optString("version") + "\n\nO número é igual ou anterior ao deste aparelho. Toque em Verificar para comparar os arquivos antes de decidir. Nada será instalado sem confirmação."; }
                else { available = result; message = "Nova versão: " + result.optString("version") + "\n\n" + result.optString("notes") + "\n\nToque em Verificar para conferir o conteúdo. Sua conta e seus treinos serão mantidos."; }
            } catch (Exception e) { message = readableError(e); }
            final String outcome = message; final JSONObject candidate = available;
            activity.runOnUiThread(() -> {
                if (destroyed || generation != checkGeneration || sequence() != installed) return;
                checking = false; manifest = candidate; display(outcome);
            });
        });
    }
    private String readableError(Throwable e) {
        if (e instanceof OutOfMemoryError) return "Não houve memória suficiente para abrir a atualização. A versão instalada foi mantida. Feche e abra o aplicativo antes de tentar novamente.";
        if (e instanceof NeedsLogin) return "O serviço de atualizações está indisponível. Tente novamente mais tarde.";
        return "Não foi possível consultar agora. Sua agenda continua funcionando com a versão instalada. Verifique a conexão e tente novamente.";
    }
    private byte[] fetch(String path, int limit) throws Exception {
        if (!path.matches("/api/(manifest|bundle/[a-f0-9-]{36})")) throw new Exception("Endereço de atualização inválido.");
        HttpURLConnection connection = (HttpURLConnection) new URL(SITE_URL + path).openConnection();
        connection.setConnectTimeout(15000); connection.setReadTimeout(25000); connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Accept", "application/json"); connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setRequestProperty("User-Agent", "AgendaPersonal/1.70 (Android; Updates)");
        try {
            int status = connection.getResponseCode();
            if (status == 401 || status == 403 || (status >= 300 && status < 400)) throw new NeedsLogin();
            if (status != 200) throw new Exception("Serviço indisponível.");
            if (connection.getContentType() == null || !connection.getContentType().contains("application/json")) throw new NeedsLogin();
            if (connection.getContentLengthLong() > limit) throw new Exception("Atualização muito grande.");
            try (InputStream input = connection.getInputStream()) { return readLimited(input, limit); }
        } finally { connection.disconnect(); }
    }
    private void downloadAndApply() {
        if (busy || manifest == null) return;
        webView.evaluateJavascript("!window.APupdates||APupdates.canInstall()", result -> {
            if(!"true".equals(result)){display("Conclua o treino em andamento antes de atualizar.");return;}
            downloadConfirmed();
        });
    }
    private void downloadConfirmed() {
        if(busy||manifest==null)return;
        JSONObject chosen = manifest;
        final int generation = ++reviewGeneration;
        reviewRequiresTeacher = false;
        invalidateCheck(); busy = true; display("Baixando e verificando a atualização…");
        executor.execute(() -> {
            try {
                JSONObject bundle = validateBundle(new JSONObject(fetchBundleText(chosen)));
                if (bundle.getInt("sequence") != chosen.getInt("sequence")) throw new Exception("A versão mudou durante o download.");
                activity.runOnUiThread(() -> reviewUpdate(bundle, chosen.optString("notes"), generation));
            } catch (Exception | OutOfMemoryError e) {
                activity.runOnUiThread(() -> {
                    if (destroyed || generation != reviewGeneration) return;
                    busy = false; display(readableError(e));
                    if (e instanceof OutOfMemoryError) Toast.makeText(activity, readableError(e), Toast.LENGTH_LONG).show();
                });
            }
        });
    }
    private String fetchBundleText(JSONObject chosen) throws Exception {
        byte[] bytes = fetch(chosen.getString("bundlePath"), MAX_BYTES);
        if (!UpdateStorage.sha256(bytes).equals(chosen.getString("sha256")) || bytes.length != chosen.getInt("size"))
            throw new Exception("O arquivo recebido está incompleto.");
        return new String(bytes, StandardCharsets.UTF_8);
    }
    private UpdateDownloads.Source downloadSource(String id) throws Exception {
        if ("installed".equals(id)) {
            if (!pageAcknowledged || preferences.getBoolean("pending",false) || preferences.getBoolean("manualRestorePending",false))
                throw new java.io.IOException("Aguarde a confirmação de abertura da versão em uso.");
            final JSONObject installed = active;
            String version = installed==null?BASE_VERSION:installed.getString("version");
            JSONObject meta = new JSONObject().put("id","installed").put("version",version)
                .put("sequence",installed==null?BASE_SEQUENCE:installed.getInt("sequence"))
                .put("filename","AgendaPersonal-"+version+".agenda.json").put("contentSha256",contentIdentity(installed)).put("current",true);
            return new UpdateDownloads.Source(meta,(file,allowed)->{
                UpdateExport.check(allowed);
                if(installed==null)UpdateExport.writeBase(activity,file,BASE_VERSION,BASE_SEQUENCE,allowed);
                else saveInstalledRelease(installed,file);
                UpdateExport.check(allowed);
            });
        }
        throw new java.io.IOException("Somente a versão em uso está disponível para download.");
    }
    public String updateDownloadOptions() { return downloads.options(); }
    public boolean downloadUpdate(String id,String expectedSha256,String requestId) { return downloads.start(id,expectedSha256,requestId); }
    public void finishUpdateDownload(Uri destination) { downloads.finish(destination); }
    public void setUpdateAccount(String uid) {
        boolean nextTeacher="R2EmnDVcvMWt7TjPxOP6DjW1VOn1".equals(uid);
        boolean changed=teacherAccount!=nextTeacher;teacherAccount=nextTeacher;
        if(changed)downloads.accountChanged();
        if(changed)activity.runOnUiThread(()->{
            if (!nextTeacher && reviewRequiresTeacher) cancelReview("A conta mudou. Nenhuma atualização foi instalada.");
            if(dialog!=null){dialog.dismiss();dialog=null;}
        });
    }
    public String distributionStatus() {
        try {
            JSONObject value = new JSONObject().put("installedVersion",active==null?BASE_VERSION:active.optString("version",BASE_VERSION))
                    .put("installedSequence",sequence()).put("manifest",UpdatePoller.latest(activity)).put("contentInstallerVersion",3).put("updateMenuVersion",1);
            try {
                value.put("installedContentSha256",contentIdentity(active))
                    .put("contentVerified",pageAcknowledged && !preferences.getBoolean("pending",false) && !preferences.getBoolean("manualRestorePending",false));
            } catch (Exception ignored) { value.put("contentVerified",false); }
            return value.toString();
        } catch(Exception ignored) { return "{}"; }
    }
    private JSONObject identitySource;
    private String identityCache;
    private synchronized String contentIdentity(JSONObject release) throws Exception {
        if (identityCache != null && release == identitySource) return identityCache;
        String value = UpdateIdentity.fingerprint(release, name -> {
            try (InputStream input = activity.getAssets().open(name)) { return readLimited(input, MAX_BYTES); }
            catch (java.io.FileNotFoundException | java.nio.file.NoSuchFileException missing) { return null; }
        });
        if (release == active) { identitySource = release; identityCache = value; }
        return value;
    }
    private void recordVerifiedRelease(JSONObject release, int generation, String token) {
        executor.execute(() -> {
            try {
                String identity = contentIdentity(release);
                if (destroyed || active != release || generation != pageGeneration || !token.equals(pageToken) || !pageAcknowledged) return;
                JSONObject verified = new JSONObject().put("version",release==null?BASE_VERSION:release.optString("version",BASE_VERSION))
                    .put("sequence",release==null?BASE_SEQUENCE:release.optInt("sequence",BASE_SEQUENCE))
                    .put("contentSha256",identity).put("verifiedAt",System.currentTimeMillis());
                writeAtomic(verifiedReleaseFile,verified.toString().getBytes(StandardCharsets.UTF_8));
            } catch (Exception ignored) { /* A diagnostic journal never replaces the actual-content comparison. */ }
        });
    }
    /** Export source only. Never export prepared pages, storage snapshots or auth tokens. */
    public String publishableUpdate() {
        if(!teacherAccount)return "";
        try {
            JSONObject release=active;
            if(release!=null)return release.toString();
            JSONObject files=new JSONObject();
            for(String name:new String[]{"index.html","professor.html","avaliacoes.html","cadastro.html"})
                try(InputStream input=activity.getAssets().open(name)){files.put(name,new String(readLimited(input,MAX_BYTES),StandardCharsets.UTF_8));}
            return new JSONObject().put("format",1).put("appId",activity.getPackageName()).put("bridgeVersion",3)
                    .put("dataSchema",4).put("version",BASE_VERSION).put("sequence",BASE_SEQUENCE).put("files",files).toString();
        }catch(Exception | OutOfMemoryError ignored){return "";}
    }
    public void checkInBackground() {
        if(destroyed||!pageAcknowledged||checkingBackground||System.currentTimeMillis()-lastBackgroundCheck<30*60*1000L)return;
        checkingBackground=true;lastBackgroundCheck=System.currentTimeMillis();
        checkExecutor.execute(()->{
            try{UpdatePoller.fetch(activity,sequence());activity.runOnUiThread(()->{
                if(!destroyed)webView.evaluateJavascript("if(window.APupdates)APupdates.refreshNotice()",null);
            });}catch(Exception ignored){}finally{checkingBackground=false;}
        });
    }
    public void applyPublishedUpdate(String metadata) {
        activity.runOnUiThread(()->{
            if(!teacherAccount||busy)return;
            try{manifest=UpdateManifest.validate(new JSONObject(metadata),activity.getPackageName());
                if(manifest.optBoolean("available"))downloadAndApply();
            }catch(Exception ignored){Toast.makeText(activity,"Publicação concluída. Abra Atualizações para atualizar este aparelho.",Toast.LENGTH_LONG).show();}
        });
    }
    public void importUri(Uri uri) {
        if (uri == null || busy || destroyed || !teacherAccount || activity.isFinishing()) return;
        final int generation = ++reviewGeneration;
        reviewRequiresTeacher = true;
        invalidateCheck(); busy = true;
        display("Lendo e conferindo o arquivo. A atualização ainda não será instalada…");
        executor.execute(() -> {
            try (InputStream input = activity.getContentResolver().openInputStream(uri)) {
                if (input == null) throw new Exception("Arquivo indisponível.");
                JSONObject bundle = validateBundle(new JSONObject(new String(readLimited(input, MAX_BYTES), StandardCharsets.UTF_8)));
                // Keep the exact validated bytes in memory. Confirmation must not
                // reopen a document that another app could have changed meanwhile.
                activity.runOnUiThread(() -> reviewUpdate(bundle, "", generation));
            } catch (Exception | OutOfMemoryError e) {
                activity.runOnUiThread(() -> {
                    if (destroyed || generation != reviewGeneration) return;
                    String message = e instanceof OutOfMemoryError ? readableError(e)
                        : "Não foi possível abrir esta atualização. Escolha o arquivo .agenda.json baixado do painel.";
                    cancelReview(message);
                    Toast.makeText(activity, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }
    /** Reading or downloading a file never changes the installed release. */
    private void reviewUpdate(JSONObject bundle, String publishedNotes, int generation) {
        if (destroyed || generation != reviewGeneration) return;
        if (activity.isFinishing() || (reviewRequiresTeacher && !teacherAccount)) {
            cancelReview("Nenhuma atualização foi instalada."); return;
        }
        final JSONObject installed = active;
        executor.execute(() -> {
            try {
                final String currentContent = contentIdentity(installed), candidateContent = contentIdentity(bundle);
                activity.runOnUiThread(() -> showReviewedUpdate(bundle, publishedNotes, generation, installed, currentContent, candidateContent));
            } catch (Exception | OutOfMemoryError e) {
                activity.runOnUiThread(() -> {
                    if (generation == reviewGeneration) cancelReview("Não foi possível conferir o conteúdo instalado. A versão atual foi mantida.");
                    if (e instanceof OutOfMemoryError) Toast.makeText(activity, readableError(e), Toast.LENGTH_LONG).show();
                });
            }
        });
    }
    private void showReviewedUpdate(JSONObject bundle, String publishedNotes, int generation, JSONObject installedRelease, String currentContent, String candidateContent) {
        if (destroyed || generation != reviewGeneration) return;
        if (activity.isFinishing() || (reviewRequiresTeacher && !teacherAccount) || active != installedRelease) {
            cancelReview("A versão instalada ou a conta mudou. Selecione o arquivo novamente."); return;
        }
        if (currentContent.equals(candidateContent)) {
            cancelReview("O conteúdo deste arquivo já está instalado neste aparelho. Nenhuma alteração foi feita."); return;
        }
        Object description = bundle.opt("notes");
        String notes = description instanceof String ? ((String) description).trim() : "";
        if (notes.isEmpty()) notes = publishedNotes.trim();
        if (notes.isEmpty() || notes.length() > 4000) {
            String message = "Este arquivo não traz uma descrição válida das alterações. Solicite uma atualização com a descrição antes de instalar. A versão atual foi mantida.";
            cancelReview(message);
            new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Descrição da atualização ausente")
                .setMessage(message).setNegativeButton("Fechar", null).show();
            return;
        }
        reviewBundle = bundle;
        reviewInstalledSequence = sequence();
        reviewInstalledRelease = installedRelease;
        reviewConfirming = false;
        String installed = active == null ? BASE_VERSION : active.optString("version", BASE_VERSION);
        int versionOrder = UpdateIdentity.compareVersions(bundle.optString("version"), installed);
        boolean earlier = bundle.optInt("sequence") < sequence() || versionOrder < 0;
        boolean sameNumber = bundle.optInt("sequence") == sequence() || versionOrder == 0;
        String message = "Versão instalada: " + installed
            + "\nVersão do arquivo: " + bundle.optString("version")
            + "\n\nConteúdo conferido: os arquivos são diferentes dos que estão em uso."
            + (earlier ? "\n\nEste arquivo é de uma versão anterior. A instalação substituirá a versão atual e pode retirar funções mais recentes." : sameNumber ? "\n\nA numeração é igual, mas o conteúdo é diferente. O arquivo selecionado substituirá o programa atual." : "")
            + "\n\nO que esta atualização faz:\n" + notes
            + "\n\nSua conta, cadastros, fichas e históricos serão mantidos."
            + "\n\nDeseja instalar esta atualização?";
        AlertDialog review = new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(earlier ? "Revisar restauração" : sameNumber ? "Revisar reinstalação" : "Revisar atualização")
            .setMessage(message)
            .setPositiveButton(earlier ? "Restaurar esta versão" : sameNumber ? "Reinstalar conteúdo" : "Sim, atualizar", null)
            .setNegativeButton("Não, cancelar", (d, which) -> {
                if (generation == reviewGeneration) cancelReview("Atualização cancelada. A versão instalada foi mantida.");
            }).create();
        reviewDialog = review;
        review.setOnDismissListener(ignored -> {
            if (generation == reviewGeneration && reviewBundle == bundle)
                cancelReview("Atualização cancelada. A versão instalada foi mantida.");
        });
        review.setOnShowListener(ignored -> review.getButton(AlertDialog.BUTTON_POSITIVE)
            .setOnClickListener(v -> confirmReview(bundle, generation)));
        review.show();
    }
    private void confirmReview(JSONObject bundle, int generation) {
        if (destroyed || generation != reviewGeneration || reviewBundle != bundle || reviewConfirming) return;
        if (active != reviewInstalledRelease || sequence() != reviewInstalledSequence || (reviewRequiresTeacher && !teacherAccount)) {
            cancelReview("A versão instalada ou a conta mudou. Selecione o arquivo novamente."); return;
        }
        reviewConfirming = true;
        reviewDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        webView.evaluateJavascript("!window.APupdates||APupdates.canInstall()", result -> {
            if (destroyed || generation != reviewGeneration || reviewBundle != bundle) return;
            reviewConfirming = false;
            if (!"true".equals(result)) {
                reviewDialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                Toast.makeText(activity, "Conclua o treino ou a edição em andamento antes de atualizar.", Toast.LENGTH_LONG).show();
                return;
            }
            if (active != reviewInstalledRelease || sequence() != reviewInstalledSequence || (reviewRequiresTeacher && !teacherAccount)) {
                cancelReview("A versão instalada ou a conta mudou. Selecione o arquivo novamente."); return;
            }
            AlertDialog approved = reviewDialog;
            reviewBundle = null; reviewDialog = null; reviewInstalledRelease = null;
            reviewRequiresTeacher = false; reviewGeneration++;
            approved.dismiss();
            display("Atualização confirmada. Preparando a cópia dos dados…");
            snapshotAndApply(bundle);
        });
    }
    private void cancelReview(String message) {
        reviewGeneration++;
        reviewBundle = null; reviewInstalledRelease = null; reviewRequiresTeacher = false; reviewConfirming = false;
        AlertDialog canceled = reviewDialog;
        reviewDialog = null;
        if (canceled != null) canceled.dismiss();
        busy = false;
        if (!destroyed) display(message);
    }
    private void snapshotAndApply(JSONObject bundle) {
        final JSONObject installedRelease = active;
        webView.evaluateJavascript("(function(){var d={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);d[k]=localStorage.getItem(k)}return JSON.stringify(d)})()", encoded -> {
            executor.execute(() -> {
                try {
                    if (active != installedRelease) throw new Exception("A versão instalada mudou.");
                    if (contentIdentity(bundle).equals(contentIdentity(installedRelease))) {
                        busy = false; display("O conteúdo deste arquivo já está instalado. Nenhuma alteração foi feita."); return;
                    }
                    Object decoded = new JSONTokener(encoded).nextValue();
                    if (!(decoded instanceof String)) throw new Exception("Não foi possível copiar os dados.");
                    String snapshot = (String) decoded; new JSONObject(snapshot);
                    UpdateStorage.writeText(snapshotFile, snapshot, MAX_BYTES);
                    if (installedRelease != null) backupInstalledRelease(installedRelease);
                    else new AtomicFile(previousFile).delete();
                    if (!preferences.edit().putBoolean("pending", true).commit()) throw new Exception("Não foi possível preparar a atualização.");
                    String hash = UpdateStorage.writeJson(activeFile, bundle, MAX_BYTES);
                    storedRelease = new StoredRelease(bundle, hash); active = bundle;
                    identitySource = null; identityCache = null;
                    activity.runOnUiThread(() -> {
                        if (dialog != null) dialog.dismiss();
                        openHome();
                        Toast.makeText(activity, "Arquivo recebido. Abrindo a nova versão…", Toast.LENGTH_SHORT).show();
                    });
                } catch (Exception | OutOfMemoryError e) {
                    if (preferences.getBoolean("pending", false)) {
                        rollbackFiles();
                        // The candidate page has not run: current storage is already the newest data.
                        if (!preferences.getBoolean("pending", false)) preferences.edit().putBoolean("restoreData", false).commit();
                    }
                    active = installedRelease;
                    busy = false;
                    final String message = e instanceof OutOfMemoryError
                        ? "Não houve memória suficiente para instalar. A versão anterior foi mantida. Feche e abra o aplicativo antes de tentar novamente."
                        : "Não foi possível salvar a atualização. A versão anterior foi mantida.";
                    display(message);
                    activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_LONG).show());
                }
            });
        });
    }
    public void requestImport() {
        activity.runOnUiThread(() -> {
            if (destroyed || busy || !teacherAccount || activity.isFinishing()) return;
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "application/octet-stream"});
            activity.startActivityForResult(intent, IMPORT_REQUEST);
        });
    }
    private void backupInstalledRelease(JSONObject installedRelease) throws Exception {
        saveInstalledRelease(installedRelease, previousFile);
    }
    private void saveInstalledRelease(JSONObject installedRelease, File destination) throws Exception {
        StoredRelease stored = storedRelease;
        if (stored != null && stored.release == installedRelease) {
            try {
                UpdateStorage.copy(activeFile, destination, MAX_BYTES, stored.sha256);
                return;
            } catch (Exception ignored) { /* Changed disk content is never used as the recovery copy. */ }
        }
        UpdateStorage.writeJson(destination, installedRelease, MAX_BYTES);
    }
    private static byte[] readLimited(InputStream input, int limit) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int count;
        while ((count = input.read(buffer)) != -1) { if (output.size() + count > limit) throw new Exception("Arquivo muito grande."); output.write(buffer, 0, count); }
        return output.toByteArray();
    }
    private static void writeAtomic(File file, byte[] bytes) throws Exception {
        AtomicFile target = new AtomicFile(file); FileOutputStream output = target.startWrite();
        try { output.write(bytes); target.finishWrite(output); }
        catch (Exception | Error e) { target.failWrite(output); throw e; }
    }
    public void destroy() {
        destroyed = true;
        downloads.destroy();
        activity.runOnUiThread(() -> cancelReview(""));
        handler.removeCallbacksAndMessages(null); executor.shutdownNow(); checkExecutor.shutdownNow();
    }
    private static final class NeedsLogin extends Exception {}
}
