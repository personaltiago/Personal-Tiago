package com.tiagolima.agendapersonal;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.AtomicFile;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebResourceResponse;
import android.widget.TextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Streams local pages from a private HTTPS origin, with a non-destructive legacy-data import. */
public final class UpdateManager {
    public static final String SITE_URL = "https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site";
    public static final int IMPORT_REQUEST = 3003;
    private static final String BASE_VERSION = "1.12.113";
    static final int BASE_SEQUENCE = 219;
    private static final String HOME_URL = LocalPages.HOME;
    // The built-in agenda includes the professor, student and invitation screens.
    // It is intentionally larger than a small web page, so keep this limit above
    // the packaged asset size as well as future on-device updates.
    private static final int MAX_BYTES = 24 * 1024 * 1024;
    private final MainActivity activity;
    private final WebView webView;
    private final SharedPreferences preferences;
    private final File activeFile, previousFile, snapshotFile, legacyFile;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile JSONObject active;
    private volatile JSONObject manifest;
    private AlertDialog dialog;
    private volatile boolean busy;
    private volatile boolean destroyed;
    private final ArrayList<Uri> pageHistory = new ArrayList<>();
    private volatile int pageGeneration;
    private String pageToken = "";
    private volatile PreparedPage prepared;
    private boolean pageAcknowledged;
    private volatile boolean teacherAccount;
    private volatile boolean checkingBackground;
    private long lastBackgroundCheck;

    private static final class PreparedPage {
        final String url;
        final byte[] html;
        PreparedPage(String url, String html) {
            this.url = url;
            this.html = html.getBytes(StandardCharsets.UTF_8);
        }
    }

    UpdateManager(MainActivity activity, WebView webView) {
        this.activity = activity; this.webView = webView;
        preferences = activity.getSharedPreferences("agenda_updates_v1", 0);
        File folder = new File(activity.getFilesDir(), "updates");
        if (!folder.exists()) folder.mkdirs();
        activeFile = new File(folder, "active.json"); previousFile = new File(folder, "previous.json");
        snapshotFile = new File(folder, "data-before-update.json");
        legacyFile = new File(folder, "legacy-storage.json");
        if (preferences.getBoolean("pending", false)) rollbackFiles();
        active = readActive();
    }

    public void start() {
        activity.runOnUiThread(() -> {
            if (destroyed || activity.isFinishing()) return;
            activity.showBootLoading();
            if (preferences.getBoolean("legacyImported", false)
                || (preferences.getBoolean("legacyCaptured", false) && legacyFile.exists())) {
                openHome();
                return;
            }
            final int generation = ++pageGeneration;
            prepared = null;
            // Use the actual old URL, not loadData's opaque-origin page. The first
            // script in this lightweight asset exports existing storage without deleting it.
            webView.loadUrl("file:///android_asset/index.html");
            handler.postDelayed(() -> {
                if (!destroyed && generation == pageGeneration)
                    activity.showBootError("AP-MIGRATION-TIMEOUT");
            }, 15000);
        });
    }

    public void captureLegacyStorage(String data) {
        if (destroyed || data == null || preferences.getBoolean("legacyCaptured", false)) return;
        executor.execute(() -> {
            try {
                byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
                if (bytes.length > MAX_BYTES) throw new Exception("Snapshot grande");
                new JSONObject(data);
                writeAtomic(legacyFile, bytes);
                if (!preferences.edit().putBoolean("legacyCaptured", true).commit())
                    throw new Exception("Falha ao registrar backup");
                activity.runOnUiThread(this::openHome);
            } catch (Exception e) { activity.showBootError("AP-MIGRATION-BACKUP"); }
        });
    }

    /** Only this exact reserved origin is intercepted; it never reaches the network. */
    public WebResourceResponse localResponse(Uri uri) {
        if (!LocalPages.isSecureOrigin(uri)) return null;
        String asset = LocalPages.assetName(uri);
        if (asset == null) return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
            new ByteArrayInputStream(new byte[0]));
        try {
            PreparedPage current = prepared;
            if (current != null && current.url.equals(uri.toString()))
                return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(current.html));
            JSONObject release = active;
            if (release != null && release.getJSONObject("files").has(asset))
                return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(
                    release.getJSONObject("files").getString(asset).getBytes(StandardCharsets.UTF_8)));
            return new WebResourceResponse(asset.endsWith(".png") ? "image/png" : "text/html", "UTF-8",
                activity.getAssets().open(asset));
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "UTF-8", 500, "Local Asset Error", null,
                new ByteArrayInputStream("AP-ASSET-READ".getBytes(StandardCharsets.UTF_8)));
        }
    }
    private JSONObject readActive() {
        try {
            JSONObject value = validateBundle(new JSONObject(new String(new AtomicFile(activeFile).readFully(), StandardCharsets.UTF_8)));
            return value.optInt("sequence") > BASE_SEQUENCE ? value : null;
        }
        catch (Exception e) { return null; }
    }
    private JSONObject validateBundle(JSONObject value) throws Exception {
        if (value.optInt("format") != 1 || !activity.getPackageName().equals(value.optString("appId")) || value.optInt("bridgeVersion") != 3 || value.optInt("dataSchema") != 4 || value.optInt("sequence") < 1) throw new Exception("Esta atualização precisa de outra versão do APK.");
        String version = value.optString("version");
        if (!version.matches("[0-9]+\\.[0-9]+\\.[0-9]+")) throw new Exception("A versão desta atualização é inválida.");
        String[] components = version.split("\\.");
        int major = Integer.parseInt(components[0]), minor = Integer.parseInt(components[1]);
        if (major < 1 || (major == 1 && minor < 11)) throw new Exception("Esta atualização é anterior à versão incluída neste APK.");
        JSONObject files = value.getJSONObject("files");
        if (files.length() < 2 || files.length() > 4 || !files.has("index.html") || !files.has("avaliacoes.html")) throw new Exception("A atualização está incompleta.");
        for (String asset : new String[]{"index.html", "avaliacoes.html", "professor.html", "cadastro.html"}) {
            if (!files.has(asset)) continue;
            String html = files.getString(asset);
            if ((!asset.equals("cadastro.html") && !html.contains("data-agenda-ready")) || !html.toLowerCase(java.util.Locale.ROOT).contains("</html>") || html.length() > MAX_BYTES) throw new Exception("O arquivo da atualização não é compatível.");
            if (asset.equals("index.html") && !(html.contains("agendaPersonalTL_v1") && html.contains("syncNativeAlarms"))
                && !(html.contains("ap-student-accounts") && html.contains("ap-embedded-professor"))) throw new Exception("Esta atualização pertence a outra agenda.");
        }
        int known = 2 + (files.has("professor.html") ? 1 : 0) + (files.has("cadastro.html") ? 1 : 0);
        if (files.length() != known) throw new Exception("A atualização contém arquivos não previstos.");
        return value;
    }
    public static boolean isLocalPage(Uri uri) {
        return LocalPages.isPage(uri);
    }
    private String pageHtml(Uri uri, JSONObject release, String token, int releaseSequence) throws Exception {
        String asset = LocalPages.assetName(uri);
        if (asset == null) throw new Exception("Página local inválida.");
        String html;
        if (release != null && release.getJSONObject("files").has(asset)) html = release.getJSONObject("files").getString(asset);
        else try (InputStream input = activity.getAssets().open(asset)) { html = new String(readLimited(input, MAX_BYTES), StandardCharsets.UTF_8); }
        String script = "<script>window.__agendaNativeReleaseToken=" + JSONObject.quote(token) + ";window.__agendaNativeReleaseSequence=" + releaseSequence + ";</script>";
        script += "<script>window.addEventListener('error',function(e){if(e.error){"
            + "if(!window.__agendaNativeBootReady){window.__agendaBootFailed=true;"
            + "if(window.Android&&Android.bootFailed)Android.bootFailed('AP-JS-'+(e.lineno||0))}"
            + "else if(typeof window.toast==='function')window.toast('Não foi possível concluir esta ação. Tente novamente.')}});</script>";
        if (!preferences.getBoolean("legacyImported", false) && legacyFile.exists()) {
            String snapshot = Base64.encodeToString(Files.readAllBytes(legacyFile.toPath()), Base64.NO_WRAP);
            script += "<script>(function(){try{var b=atob('" + snapshot + "');var a=Uint8Array.from(b,function(c){return c.charCodeAt(0)});"
                + "var d=JSON.parse(new TextDecoder().decode(a));Object.keys(d).forEach(function(k){"
                + "if(localStorage.getItem(k)===null)localStorage.setItem(k,d[k])});window.__agendaLegacyImported=true;"
                + "}catch(e){window.__agendaRestoreFailed=true;if(window.Android&&Android.bootFailed)Android.bootFailed('AP-MIGRATION-IMPORT')}})();</script>";
        }
        if (preferences.getBoolean("restoreData", false) && snapshotFile.exists()) {
            String snapshot = Base64.encodeToString(Files.readAllBytes(snapshotFile.toPath()), Base64.NO_WRAP);
            script += "<script>(function(){try{var b=atob('" + snapshot + "');var a=Uint8Array.from(b,function(c){return c.charCodeAt(0)});var d=JSON.parse(new TextDecoder().decode(a));localStorage.clear();Object.keys(d).forEach(function(k){localStorage.setItem(k,d[k])});}catch(e){window.__agendaRestoreFailed=true}})();</script>";
        }
        Matcher head = java.util.regex.Pattern.compile("<head\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
        if (!head.find()) throw new Exception("A página não contém o cabeçalho esperado.");
        return html.substring(0, head.end()) + script + html.substring(head.end());
    }
    public void openPage(Uri uri) { openPage(uri, false); }
    private void openHome() { openPage(Uri.parse(HOME_URL), true); }
    private void openPage(Uri uri, boolean resetHistory) {
        if (!isLocalPage(uri)) return;
        final Uri localUri = LocalPages.canonical(uri);
        activity.runOnUiThread(() -> {
            if (destroyed || activity.isFinishing()) return;
            if (resetHistory) pageHistory.clear();
            if (pageHistory.isEmpty() || !pageHistory.get(pageHistory.size() - 1).equals(localUri)) pageHistory.add(localUri);
            final int generation = ++pageGeneration;
            final String token = UUID.randomUUID().toString();
            final JSONObject release = active;
            final int releaseSequence = release == null ? BASE_SEQUENCE : release.optInt("sequence", BASE_SEQUENCE);
            executor.execute(() -> {
                try {
                    String html = pageHtml(localUri, release, token, releaseSequence);
                    activity.runOnUiThread(() -> {
                        if (destroyed || generation != pageGeneration || activity.isFinishing()) return;
                        pageToken = token;
                        pageAcknowledged = false;
                        prepared = new PreparedPage(localUri.toString(), html);
                        activity.showBootLoading();
                        // HTML stays in an InputStream, not a multi-megabyte loadData IPC message.
                        webView.loadUrl(localUri.toString());
                        handler.postDelayed(() -> {
                            if (!destroyed && generation == pageGeneration && !pageAcknowledged)
                                activity.showBootError("AP-BOOT-TIMEOUT");
                        }, 30000);
                    });
                } catch (Exception e) {
                    activity.runOnUiThread(() -> {
                        if (destroyed || generation != pageGeneration || activity.isFinishing()) return;
                        if (preferences.getBoolean("pending", false)) {
                            rollbackFiles(); active = readActive(); busy = false; openHome();
                            Toast.makeText(activity, "Não foi possível abrir a atualização. A versão anterior foi recuperada.", Toast.LENGTH_LONG).show();
                        } else {
                            activity.showBootError("AP-PAGE-READ");
                        }
                    });
                }
            });
        });
    }
    public boolean goBack() {
        if (pageHistory.size() < 2) return false;
        pageHistory.remove(pageHistory.size() - 1);
        Uri previous = pageHistory.remove(pageHistory.size() - 1);
        openPage(previous);
        return true;
    }
    public void pageReady() {
        activity.runOnUiThread(() -> {
            if (destroyed || pageToken.isEmpty() || activity.isFinishing()) return;
            final String token = pageToken;
            final int generation = pageGeneration, releaseSequence = sequence();
            String check = "window.__agendaNativeReleaseToken===" + JSONObject.quote(token)
                + "&&window.__agendaNativeReleaseSequence===" + releaseSequence
                + "&&!window.__agendaBootFailed&&!window.__agendaRestoreFailed"
                + "&&(window.__agendaNativeBootReady=true)";
            webView.evaluateJavascript(check, result -> {
                if (destroyed || !"true".equals(result) || generation != pageGeneration || !token.equals(pageToken)) return;
                boolean applied = preferences.getBoolean("pending", false);
                if (!preferences.edit().putBoolean("pending", false).putBoolean("restoreData", false)
                    .putBoolean("legacyImported", true).commit()) return;
                pageAcknowledged = true;
                UpdatePoller.markInstalled(activity,releaseSequence);
                activity.showBootReady();
                if (applied) {
                    busy = false;
                    Toast.makeText(activity, "Atualização aplicada. Seus dados foram mantidos.", Toast.LENGTH_LONG).show();
                }
            });
        });
    }
    public void pageFinished() {
        if (!preferences.getBoolean("pending", false)) return;
        final int generation = pageGeneration;
        handler.postDelayed(() -> {
            if (!destroyed && generation == pageGeneration && preferences.getBoolean("pending", false) && !activity.isFinishing()) {
                rollbackFiles(); active = readActive(); busy = false; openHome();
                Toast.makeText(activity, "A nova versão não abriu corretamente. A versão anterior foi recuperada.", Toast.LENGTH_LONG).show();
            }
        }, 30000);
    }
    private void rollbackFiles() {
        try {
            if (previousFile.exists()) writeAtomic(activeFile, Files.readAllBytes(previousFile.toPath()));
            else new AtomicFile(activeFile).delete();
            preferences.edit().putBoolean("pending", false).putBoolean("restoreData", snapshotFile.exists()).commit();
        } catch (Exception ignored) { /* Keep pending for another recovery attempt. */ }
    }
    public void showScreen() {
        activity.runOnUiThread(() -> {
            if (activity.isFinishing()) return;
            if (dialog != null && dialog.isShowing()) return;
            final boolean teacherControls = teacherAccount;
            AlertDialog.Builder builder = new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Atualizar aplicativo")
                .setMessage(description("Buscando atualizações…"))
                .setPositiveButton("Verificar", null).setNegativeButton("Fechar", null);
            if (teacherControls) {
                Button importButton = new Button(activity);
                importButton.setText("Importar arquivo baixado do painel");
                importButton.setOnClickListener(v -> { if (teacherAccount) requestImport(); });
                Button restoreButton = new Button(activity);
                restoreButton.setText("Restaurar versão anterior");
                restoreButton.setEnabled(activeFile.exists());
                restoreButton.setOnClickListener(v -> { if (teacherAccount) confirmManualRestore(); });
                LinearLayout actions = new LinearLayout(activity);
                actions.setOrientation(LinearLayout.VERTICAL);
                actions.addView(importButton);
                actions.addView(restoreButton);
                builder.setView(actions).setNeutralButton("Publicar para os alunos", null);
            }
            dialog = builder.create();
            dialog.setOnShowListener(ignored -> {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> { if (manifest != null && manifest.optInt("sequence") > sequence()) downloadAndApply(); else check(); });
                if(teacherControls)dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                    if (!teacherAccount) return;
                    dialog.dismiss();webView.evaluateJavascript("if(window.APupdates)APupdates.openPublisher()",null);
                });
            });
            dialog.show();
            check();
        });
    }
    /** Manual rollback changes the web release only; it must never restore an old localStorage snapshot. */
    private void confirmManualRestore() {
        if (busy || !activeFile.exists()) return;
        final String targetVersion = previousVersion();
        new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Restaurar versão anterior?")
            .setMessage("Versão de destino: " + targetVersion + ".\n\nA atualização atual será retirada. Os dados dos alunos, fichas e históricos serão mantidos. Alterações feitas nas fichas não serão desfeitas.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Restaurar", (d, which) -> restorePreviousRelease())
            .show();
    }
    private String previousVersion() {
        try {
            if (previousFile.exists()) {
                JSONObject previous = validateBundle(new JSONObject(new String(new AtomicFile(previousFile).readFully(), StandardCharsets.UTF_8)));
                if (previous.optInt("sequence") > BASE_SEQUENCE) return previous.optString("version", BASE_VERSION);
            }
        } catch (Exception ignored) { }
        return BASE_VERSION + " (incluída no APK)";
    }
    private void restorePreviousRelease() {
        if (busy || !activeFile.exists()) return;
        busy = true;
        executor.execute(() -> {
            try {
                byte[] prior = null;
                if (previousFile.exists()) {
                    byte[] candidate = new AtomicFile(previousFile).readFully();
                    JSONObject previous = validateBundle(new JSONObject(new String(candidate, StandardCharsets.UTF_8)));
                    if (previous.optInt("sequence") > BASE_SEQUENCE) prior = candidate;
                }
                // No snapshot restoration: never replace current localStorage with older student data.
                if (prior != null) writeAtomic(activeFile, prior);
                else new AtomicFile(activeFile).delete();
                new AtomicFile(previousFile).delete();
                if (!preferences.edit().putBoolean("pending", false).putBoolean("restoreData", false).commit())
                    throw new Exception("Não foi possível registrar a restauração.");
                active = readActive();
                activity.runOnUiThread(() -> {
                    busy = false;
                    if (dialog != null) dialog.dismiss();
                    openHome();
                    Toast.makeText(activity, "Versão anterior restaurada. Os dados foram mantidos.", Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                activity.runOnUiThread(() -> {
                    busy = false;
                    Toast.makeText(activity, "Não foi possível restaurar a versão anterior.", Toast.LENGTH_LONG).show();
                });
            }
        });
    }
    private int sequence() { return active == null ? BASE_SEQUENCE : active.optInt("sequence", BASE_SEQUENCE); }
    private String description(String message) { return "Versão instalada: " + (active == null ? BASE_VERSION : active.optString("version", BASE_VERSION)) + "\n\n" + message; }
    private void display(String message) {
        activity.runOnUiThread(() -> {
            if (dialog != null && dialog.isShowing()) {
                TextView text = dialog.findViewById(android.R.id.message); if (text != null) text.setText(description(message));
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(!busy);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText(manifest != null && manifest.optInt("sequence") > sequence() ? "Baixar atualização" : "Verificar");
            }
        });
    }
    private void check() {
        if (busy) return; busy = true; manifest = null; display("Buscando atualizações…");
        executor.execute(() -> {
            String message;
            try {
                JSONObject result = UpdateManifest.validate(new JSONObject(new String(fetch("/api/manifest", 65536), StandardCharsets.UTF_8)),activity.getPackageName());
                if (!result.optBoolean("available")) message = "Ainda não há uma atualização publicada.";
                else if (result.optInt("sequence") <= sequence()) message = "Sua agenda está atualizada.";
                else { manifest = result; message = "Nova versão: " + result.optString("version") + "\n\n" + result.optString("notes") + "\n\nSua conta e seus treinos serão mantidos."; }
            } catch (Exception e) { message = readableError(e); }
            busy = false; display(message);
        });
    }
    private String readableError(Exception e) {
        if (e instanceof NeedsLogin) return "O serviço de atualizações está indisponível. Tente novamente mais tarde.";
        return "Não foi possível consultar agora. Sua agenda continua funcionando com a versão instalada. Verifique a conexão e tente novamente.";
    }
    private byte[] fetch(String path, int limit) throws Exception {
        if (!path.matches("/api/(manifest|bundle/[a-f0-9-]{36})")) throw new Exception("Endereço de atualização inválido.");
        HttpURLConnection connection = (HttpURLConnection) new URL(SITE_URL + path).openConnection();
        connection.setConnectTimeout(15000); connection.setReadTimeout(25000); connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Accept", "application/json"); connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setRequestProperty("User-Agent", "AgendaPersonal/1.70 (Android; Updates)");
        try {
            int status = connection.getResponseCode();
            if (status == 401 || status == 403 || (status >= 300 && status < 400)) throw new NeedsLogin();
            if (status != 200) throw new Exception("Serviço indisponível.");
            if (connection.getContentType() == null || !connection.getContentType().contains("application/json")) throw new NeedsLogin();
            if (connection.getContentLengthLong() > limit) throw new Exception("Atualização muito grande.");
            try (InputStream input = connection.getInputStream()) { return readLimited(input, limit); }
        } finally { connection.disconnect(); }
    }
    private void downloadAndApply() {
        if (busy || manifest == null) return;
        webView.evaluateJavascript("!window.APupdates||APupdates.canInstall()", result -> {
            if(!"true".equals(result)){display("Conclua o treino em andamento antes de atualizar.");return;}
            downloadConfirmed();
        });
    }
    private void downloadConfirmed() {
        if(busy||manifest==null)return;
        busy = true; display("Baixando e verificando a atualização…");
        JSONObject chosen = manifest;
        executor.execute(() -> {
            try {
                byte[] bytes = fetch(chosen.getString("bundlePath"), MAX_BYTES);
                String hash = hex(MessageDigest.getInstance("SHA-256").digest(bytes));
                if (!hash.equals(chosen.getString("sha256")) || bytes.length != chosen.getInt("size")) throw new Exception("O arquivo recebido está incompleto.");
                JSONObject bundle = validateBundle(new JSONObject(new String(bytes, StandardCharsets.UTF_8)));
                if (bundle.getInt("sequence") != chosen.getInt("sequence")) throw new Exception("A versão mudou durante o download.");
                activity.runOnUiThread(() -> snapshotAndApply(bundle));
            } catch (Exception e) { busy = false; display(readableError(e)); }
        });
    }
    public void setUpdateAccount(String uid) {
        boolean nextTeacher="R2EmnDVcvMWt7TjPxOP6DjW1VOn1".equals(uid);
        boolean changed=teacherAccount!=nextTeacher;teacherAccount=nextTeacher;
        if(changed)activity.runOnUiThread(()->{if(dialog!=null){dialog.dismiss();dialog=null;}});
    }
    public String distributionStatus() {
        try{return new JSONObject().put("installedVersion",active==null?BASE_VERSION:active.optString("version",BASE_VERSION))
                .put("installedSequence",sequence()).put("manifest",UpdatePoller.latest(activity)).toString();}
        catch(Exception ignored){return "{}";}
    }
    /** Export source only. Never export prepared pages, storage snapshots or auth tokens. */
    public String publishableUpdate() {
        if(!teacherAccount)return "";
        try {
            JSONObject release=active;
            if(release!=null)return release.toString();
            JSONObject files=new JSONObject();
            for(String name:new String[]{"index.html","professor.html","avaliacoes.html","cadastro.html"})
                try(InputStream input=activity.getAssets().open(name)){files.put(name,new String(readLimited(input,MAX_BYTES),StandardCharsets.UTF_8));}
            return new JSONObject().put("format",1).put("appId",activity.getPackageName()).put("bridgeVersion",3)
                    .put("dataSchema",4).put("version",BASE_VERSION).put("sequence",BASE_SEQUENCE).put("files",files).toString();
        }catch(Exception ignored){return "";}
    }
    public void checkInBackground() {
        if(destroyed||!pageAcknowledged||checkingBackground||System.currentTimeMillis()-lastBackgroundCheck<30*60*1000L)return;
        checkingBackground=true;lastBackgroundCheck=System.currentTimeMillis();
        executor.execute(()->{
            try{UpdatePoller.fetch(activity,sequence());activity.runOnUiThread(()->{
                if(!destroyed)webView.evaluateJavascript("if(window.APupdates)APupdates.refreshNotice()",null);
            });}catch(Exception ignored){}finally{checkingBackground=false;}
        });
    }
    public void applyPublishedUpdate(String metadata) {
        activity.runOnUiThread(()->{
            if(!teacherAccount||busy)return;
            try{manifest=UpdateManifest.validate(new JSONObject(metadata),activity.getPackageName());
                if(UpdateManifest.newer(manifest,sequence()))downloadAndApply();
            }catch(Exception ignored){Toast.makeText(activity,"Publicação concluída. Abra Atualizações para atualizar este aparelho.",Toast.LENGTH_LONG).show();}
        });
    }
    public void importUri(Uri uri) {
        if (uri == null || busy) return;
        busy = true;
        executor.execute(() -> {
            try (InputStream input = activity.getContentResolver().openInputStream(uri)) {
                if (input == null) throw new Exception("Arquivo indisponível.");
                JSONObject bundle = validateBundle(new JSONObject(new String(readLimited(input, MAX_BYTES), StandardCharsets.UTF_8)));
                activity.runOnUiThread(() -> snapshotAndApply(bundle));
            } catch (Exception e) { busy = false; activity.runOnUiThread(() -> Toast.makeText(activity, "Não foi possível abrir esta atualização. Escolha o arquivo .agenda.json baixado do painel.", Toast.LENGTH_LONG).show()); }
        });
    }
    private void snapshotAndApply(JSONObject bundle) {
        if (bundle.optInt("sequence") <= sequence()) { busy = false; display("Essa versão já está instalada ou é anterior à atual."); return; }
        webView.evaluateJavascript("(function(){var d={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);d[k]=localStorage.getItem(k)}return JSON.stringify(d)})()", encoded -> {
            executor.execute(() -> {
                try {
                    Object decoded = new JSONTokener(encoded).nextValue();
                    if (!(decoded instanceof String)) throw new Exception("Não foi possível copiar os dados.");
                    String snapshot = (String) decoded; new JSONObject(snapshot);
                    writeAtomic(snapshotFile, snapshot.getBytes(StandardCharsets.UTF_8));
                    if (activeFile.exists()) writeAtomic(previousFile, new AtomicFile(activeFile).readFully());
                    else new AtomicFile(previousFile).delete();
                    if (!preferences.edit().putBoolean("pending", true).commit()) throw new Exception("Não foi possível preparar a atualização.");
                    writeAtomic(activeFile, bundle.toString().getBytes(StandardCharsets.UTF_8)); active = bundle;
                    activity.runOnUiThread(() -> {
                        if (dialog != null) dialog.dismiss();
                        openHome();
                        Toast.makeText(activity, "Arquivo recebido. Abrindo a nova versão…", Toast.LENGTH_SHORT).show();
                    });
                } catch (Exception e) { if (preferences.getBoolean("pending", false)) rollbackFiles(); busy = false; display("Não foi possível salvar a atualização. A versão anterior foi mantida."); }
            });
        });
    }
    public void requestImport() {
        activity.runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "application/octet-stream"});
            activity.startActivityForResult(intent, IMPORT_REQUEST);
        });
    }
    private static byte[] readLimited(InputStream input, int limit) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int count;
        while ((count = input.read(buffer)) != -1) { if (output.size() + count > limit) throw new Exception("Arquivo muito grande."); output.write(buffer, 0, count); }
        return output.toByteArray();
    }
    private static String hex(byte[] bytes) { StringBuilder result = new StringBuilder(); for (byte b : bytes) result.append(String.format("%02x", b & 255)); return result.toString(); }
    private static void writeAtomic(File file, byte[] bytes) throws Exception {
        AtomicFile target = new AtomicFile(file); FileOutputStream output = target.startWrite();
        try { output.write(bytes); target.finishWrite(output); }
        catch (Exception e) { target.failWrite(output); throw e; }
    }
    public void destroy() { destroyed = true; handler.removeCallbacksAndMessages(null); executor.shutdownNow(); }
    private static final class NeedsLogin extends Exception {}
}
