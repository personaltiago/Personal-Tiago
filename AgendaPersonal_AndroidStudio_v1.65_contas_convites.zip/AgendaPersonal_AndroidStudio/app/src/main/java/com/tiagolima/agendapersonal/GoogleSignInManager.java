package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.net.Uri;
import android.os.CancellationSignal;
import android.webkit.WebView;
import androidx.credentials.ClearCredentialStateRequest;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.ClearCredentialException;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.GetCredentialProviderConfigurationException;
import androidx.credentials.exceptions.NoCredentialException;
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Uses Android's account chooser; no Google authorization page is opened in the WebView. */
final class GoogleSignInManager {
    // Firebase's existing public project key; this is not a client secret.
    private static final String PROJECT_KEY = "AIzaSyBRGoqS1jLnv8qqt3yfOZzL2JWhgSQfzfM";
    private final Activity activity;
    private final WebView webView;
    private final CredentialManager credentials;
    private final Executor main;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private CancellationSignal cancellation;
    private String pending;
    private long generation;
    private boolean destroyed;

    GoogleSignInManager(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
        this.main = activity::runOnUiThread;
        this.credentials = CredentialManager.create(activity);
    }

    private boolean home() {
        try { return "index.html".equals(LocalPages.assetName(Uri.parse(webView.getUrl()))); }
        catch (RuntimeException ignored) { return false; }
    }

    void begin(String id) {
        if (destroyed || !home() || !GoogleSignInProtocol.validRequest(id)) return;
        if (pending != null) { reply(id, "auth/cancelled-popup-request", null); return; }
        pending = id;
        final long epoch = ++generation;
        final String nonce = GoogleSignInProtocol.nonce();
        worker.execute(() -> {
            try {
                String client = fetchClientId();
                main.execute(() -> choose(epoch, id, client, nonce));
            } catch (ConfigurationError error) {
                main.execute(() -> finish(epoch, id, error.code, null));
            } catch (Exception error) {
                main.execute(() -> finish(epoch, id, "auth/network-request-failed", null));
            }
        });
    }

    private boolean current(long epoch, String id) {
        return !destroyed && generation == epoch && id.equals(pending) && home();
    }

    private void choose(long epoch, String id, String client, String nonce) {
        if (!current(epoch, id)) return;
        cancellation = new CancellationSignal();
        GetSignInWithGoogleOption option = new GetSignInWithGoogleOption.Builder(client).setNonce(nonce).build();
        GetCredentialRequest request = new GetCredentialRequest.Builder().addCredentialOption(option).build();
        try {
            credentials.getCredentialAsync(activity, request, cancellation, main,
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override public void onResult(GetCredentialResponse response) {
                        if (!current(epoch, id)) return;
                        try {
                            Credential result = response.getCredential();
                            if (!(result instanceof CustomCredential)
                                || !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(result.getType()))
                                throw new IllegalArgumentException("Unexpected credential type");
                            String token = GoogleIdTokenCredential.createFrom(((CustomCredential) result).getData()).getIdToken();
                            if (!GoogleSignInProtocol.boundToken(token, client, nonce, System.currentTimeMillis() / 1000))
                                throw new IllegalArgumentException("Credential belongs to another request");
                            finish(epoch, id, null, token);
                        } catch (Exception ignored) { finish(epoch, id, "auth/invalid-credential", null); }
                    }
                    @Override public void onError(GetCredentialException error) {
                        String code = error instanceof GetCredentialCancellationException ? "auth/popup-closed-by-user"
                            : error instanceof NoCredentialException ? "native/no-google-account"
                            : error instanceof GetCredentialProviderConfigurationException ? "native/provider-unavailable"
                            : "native/google-sign-in-failed";
                        finish(epoch, id, code, null);
                    }
                });
        } catch (RuntimeException ignored) { finish(epoch, id, "native/provider-unavailable", null); }
    }

    private void finish(long epoch, String id, String code, String token) {
        if (!current(epoch, id)) return;
        pending = null;
        cancellation = null;
        reply(id, code, token);
    }

    private void reply(String id, String code, String token) {
        if (destroyed || !home()) return;
        try {
            JSONObject result = new JSONObject().put("requestId", id);
            if (token != null) result.put("idToken", token);
            else result.put("code", code);
            String json = result.toString().replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
            webView.evaluateJavascript("window.APaccounts?.receiveGoogleCredential?.(" + json + ");", null);
        } catch (Exception ignored) { /* Never log or persist identity credentials. */ }
    }

    void cancel(String id) {
        if (id != null && !id.equals(pending)) return;
        generation++;
        pending = null;
        if (cancellation != null) cancellation.cancel();
        cancellation = null;
    }

    void signOut() {
        cancel(null);
        try {
            credentials.clearCredentialStateAsync(new ClearCredentialStateRequest(), null, main,
                new CredentialManagerCallback<Void, ClearCredentialException>() {
                    @Override public void onResult(Void ignored) {}
                    @Override public void onError(ClearCredentialException ignored) {}
                });
        } catch (RuntimeException ignored) { /* Firebase sign-out still takes effect. */ }
    }

    void destroy() {
        destroyed = true;
        cancel(null);
        worker.shutdownNow();
    }

    private static final class ConfigurationError extends Exception {
        final String code;
        ConfigurationError(String code) { this.code = code; }
    }

    private static String fetchClientId() throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(
            "https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key=" + PROJECT_KEY).openConnection();
        connection.setConnectTimeout(8000);
        connection.setReadTimeout(8000);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        connection.setDoOutput(true);
        byte[] request = ("{\"providerId\":\"google.com\",\"continueUri\":\"https://agenda-personal-bdb58.firebaseapp.com/__/auth/handler\"}").getBytes(StandardCharsets.UTF_8);
        try {
            try (java.io.OutputStream output = connection.getOutputStream()) { output.write(request); }
            int status = connection.getResponseCode();
            InputStream stream = status == 200 ? connection.getInputStream() : connection.getErrorStream();
            if (stream == null) throw new ConfigurationError("auth/network-request-failed");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream input = stream) {
                byte[] buffer = new byte[4096];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (bytes.size() + count > 65536) throw new ConfigurationError("native/google-configuration");
                    bytes.write(buffer, 0, count);
                }
            }
            JSONObject body = new JSONObject(bytes.toString("UTF-8"));
            if (status != 200) {
                String message = body.optJSONObject("error") == null ? "" : body.optJSONObject("error").optString("message");
                throw new ConfigurationError(message.startsWith("OPERATION_NOT_ALLOWED") ? "auth/operation-not-allowed"
                    : "native/google-configuration");
            }
            try { return GoogleSignInProtocol.clientId(body); }
            catch (Exception error) { throw new ConfigurationError("native/google-configuration"); }
        } finally { connection.disconnect(); }
    }
}
