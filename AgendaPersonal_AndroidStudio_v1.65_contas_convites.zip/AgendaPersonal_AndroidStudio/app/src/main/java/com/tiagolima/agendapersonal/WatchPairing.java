package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Toast;

/** Opens the official setup app; pairing remains under the platform/vendor's control. */
public final class WatchPairing {
    public static void open(Activity activity, String vendor) {
        activity.runOnUiThread(() -> {
            String pkg = "samsung".equals(vendor) ? "com.samsung.android.app.watchmanager"
                    : "google".equals(vendor) ? "com.google.android.wearable.app" : null;
            if (pkg != null) {
                Intent launch = activity.getPackageManager().getLaunchIntentForPackage(pkg);
                if (launch == null) {
                    Toast.makeText(activity, "Instale o aplicativo oficial do fabricante do seu relógio pela Play Store e tente novamente.", Toast.LENGTH_LONG).show();
                    return;
                }
                try { activity.startActivity(launch); }
                catch (Exception e) { Toast.makeText(activity, "Não foi possível abrir o aplicativo de conexão.", Toast.LENGTH_LONG).show(); }
            } else if ("other".equals(vendor)) {
                try { activity.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); }
                catch (Exception e) { Toast.makeText(activity, "Abra Bluetooth nas configurações do celular.", Toast.LENGTH_LONG).show(); }
            }
        });
    }
    private WatchPairing() {}
}
