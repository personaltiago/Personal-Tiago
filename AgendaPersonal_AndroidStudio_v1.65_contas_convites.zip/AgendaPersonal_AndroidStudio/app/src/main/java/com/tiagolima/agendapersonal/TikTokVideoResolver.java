package com.tiagolima.agendapersonal;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

/** Public TikTok links and the documented oEmbed endpoint; never executes its HTML. */
final class TikTokVideoResolver {
    private static final Pattern POST = Pattern.compile("^/(?:@[^/]+/video/|player/v1/)([0-9]{15,22})/?$");
    interface Fetcher { Response get(URI uri) throws Exception; }
    static final class Response {
        final int status; final String location, body;
        Response(int status, String location, String body) { this.status=status; this.location=location; this.body=body; }
    }
    static boolean validId(String id) { return id != null && id.matches("[0-9]{15,22}"); }
    static boolean allowed(URI uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme()) || uri.getUserInfo()!=null
                || uri.getPort()!=-1 && uri.getPort()!=443 || uri.getHost()==null) return false;
        String host=uri.getHost().toLowerCase(Locale.ROOT);
        return host.equals("www.tiktok.com") || host.equals("tiktok.com") || host.equals("m.tiktok.com")
                || host.equals("vt.tiktok.com") || host.equals("vm.tiktok.com");
    }
    static String postId(URI uri) {
        if (!allowed(uri)) return "";
        Matcher match=POST.matcher(uri.getPath()); return match.matches()?match.group(1):"";
    }
    static JSONObject resolve(String raw, Fetcher fetcher) throws Exception {
        if (raw==null || raw.length()>2048) throw new IllegalArgumentException("Link inválido");
        URI uri=new URI(raw.trim()); if (!allowed(uri)) throw new IllegalArgumentException("Use um link HTTPS do TikTok");
        String videoId=postId(uri);
        for(int hops=0;videoId.isEmpty() && hops<5;hops++) {
            Response r=fetcher.get(uri);
            if (r.status<300 || r.status>399 || r.location==null || r.location.isEmpty()) break;
            URI next=uri.resolve(r.location); if (!allowed(next)) throw new IllegalArgumentException("Redirecionamento inválido");
            uri=next; videoId=postId(uri);
        }
        if (!validId(videoId)) throw new IllegalArgumentException("Não foi possível reconhecer o vídeo. Confira o link compartilhado.");
        String canonical=new URI("https",null,"www.tiktok.com",-1,uri.getPath(),null,null).toASCIIString();
        JSONObject result=new JSONObject().put("videoId",videoId).put("url",canonical).put("thumbnail","").put("title","");
        try {
            URI endpoint=new URI("https://www.tiktok.com/oembed?url="+URLEncoder.encode(canonical,"UTF-8"));
            Response r=fetcher.get(endpoint);
            if (r.status==200) {
                JSONObject metadata=new JSONObject(r.body);
                String image=metadata.optString("thumbnail_url",""); URI thumbnail=new URI(image);
                if ("https".equalsIgnoreCase(thumbnail.getScheme()) && thumbnail.getHost()!=null && thumbnail.getUserInfo()==null)
                    result.put("thumbnail",image);
                String title=metadata.optString("title",""); result.put("title",title.substring(0,Math.min(240,title.length())));
            }
        } catch (Exception ignored) { /* A missing cover must not discard a recognized video. */ }
        return result;
    }
    static Response fetch(URI uri) throws Exception {
        if (!allowed(uri)) throw new IllegalArgumentException("Endereço inválido");
        HttpURLConnection c=(HttpURLConnection)uri.toURL().openConnection();
        c.setInstanceFollowRedirects(false); c.setConnectTimeout(7000); c.setReadTimeout(9000);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Android) AgendaPersonal/1.117");
        c.setRequestProperty("Accept","application/json,text/html;q=0.8");
        try {
            int status=c.getResponseCode(); String location=c.getHeaderField("Location"),body="";
            // Redirect targets and oEmbed metadata are enough. Never download video/page bodies.
            if (status==200 && "/oembed".equals(uri.getPath())) {
                try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                    byte[] buffer=new byte[4096]; int n;
                    while((n=in.read(buffer))!=-1) { if(out.size()+n>262144)throw new IllegalArgumentException("Resposta muito grande"); out.write(buffer,0,n); }
                    body=new String(out.toByteArray(),StandardCharsets.UTF_8);
                }
            }
            return new Response(status,location,body);
        } finally { c.disconnect(); }
    }
}
