package com.tiagolima.agendapersonal;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import org.json.JSONObject;

/**
 * Aviso no relógio (Android 1.212). Pedido do Tiago em 24/11/2026: fazer o Smartwatch funcionar "para vários modelos". Mi Band,
 * Redmi Watch, Amazfit, Huawei, Garmin e Galaxy Watch não instalam o app, mas todos mostram as notificações do celular pelo app
 * da marca (Mi Fitness, Zepp, Huawei Saúde, Garmin Connect, Galaxy Wearable). Por isso o celular publica um aviso curto quando o
 * descanso acaba, e o relógio vibra.
 *
 * Começa desligado: quem liga é a pessoa, no cartão Smartwatch, para quem não tem relógio não receber notificação a mais. Quem
 * sabe quando o descanso acaba é o conteúdo (o descanso do professor e o do aluno): ele marca aqui o horário, e o aviso sai por um
 * alarme próprio, mesmo com o app fechado. Não mexe no alarme, no som, no cartão da tela bloqueada nem no cronômetro do descanso
 * que já existem: é um aviso a mais, num canal próprio e sem som (o som continua sendo o do descanso).
 */
final class AvisosRelogio {
    static final int VERSAO = 1;
    static final String CANAL = "relogio";
    static final String ACAO = "com.tiagolima.agendapersonal.AVISO_RELOGIO";
    static final String EXTRA_CHAVE = "agenda_relogio_chave";
    static final String EXTRA_QUANDO = "agenda_relogio_quando";
    static final int NOTIFICACAO = 4201;
    static final int COR = 0xFF568900;
    /** O teste sai depois de 10 s: dá tempo de bloquear a tela (alguns apps de relógio só repassam com a tela apagada). */
    static final long TESTE_MS = 10_000L;
    /** O descanso do app vai até 3600 s; nenhum aviso é marcado para mais de 2 h. */
    static final long MAXIMO_MS = 2L * 60 * 60 * 1000;
    /** Sai da barra do celular depois de 2 min; o próximo descanso traz um aviso novo. */
    static final long SUMIR_MS = 2L * 60 * 1000;
    static final long[] VIBRACAO = {0, 400, 200, 400};
    static final String TITULO_PADRAO = "Fim do descanso";
    static final String TEXTO_PADRAO = "Volte para o treino.";
    private static final String PREFS = "agenda_avisos_relogio_v1";
    private static final String ATIVO = "ativo";
    private static final int LIMITE_JSON = 1000;

    private AvisosRelogio() {}

    /** "professor" e "aluno": um aviso marcado para cada descanso. "teste": o botão Testar no relógio. */
    static boolean chaveConhecida(String chave) { return chaveDoDescanso(chave) || "teste".equals(chave); }

    private static boolean chaveDoDescanso(String chave) { return "professor".equals(chave) || "aluno".equals(chave); }

    private static int codigo(String chave) { return "professor".equals(chave) ? 4211 : "aluno".equals(chave) ? 4212 : 4213; }

    private static SharedPreferences prefs(Context context) { return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static boolean ativo(Context context) { return prefs(context).getBoolean(ATIVO, false); }

    /** Liga ou desliga neste celular. Desligar desmarca os avisos que estavam marcados. */
    static boolean ligar(Context context, boolean ativo) {
        boolean salvo = prefs(context).edit().putBoolean(ATIVO, ativo).commit();
        if (ativo) criarCanal(context);
        else {
            cancelar(context, "professor");
            cancelar(context, "aluno");
        }
        return salvo;
    }

    /** Título e texto pedidos pelo conteúdo, limpos e curtos para a tela pequena do relógio. Null se o pedido for inválido. */
    static String[] lerTextos(String json) {
        if (json == null || json.length() > LIMITE_JSON) return null;
        try {
            JSONObject objeto = new JSONObject(json);
            Object titulo = objeto.opt("titulo"), texto = objeto.opt("texto");
            String t = limpo(titulo instanceof String ? (String) titulo : "", 40);
            String x = limpo(texto instanceof String ? (String) texto : "", 120);
            return new String[]{t.isEmpty() ? TITULO_PADRAO : t, x.isEmpty() ? TEXTO_PADRAO : x};
        } catch (Exception invalido) {
            return null;
        }
    }

    static String limpo(String valor, int limite) {
        if (valor == null) return "";
        String texto = valor.replaceAll("[\\u0000-\\u001f\\u007f]", " ").trim();
        int pontos = texto.codePointCount(0, texto.length());
        return pontos <= limite ? texto : texto.substring(0, texto.offsetByCodePoints(0, limite)).trim();
    }

    /**
     * Marca o aviso do fim do descanso para o horário "quando" (milissegundos do relógio do celular). Marcar de novo a mesma
     * chave substitui o aviso anterior. Só marca com o aviso ligado e para um horário entre agora e 2 h.
     */
    static boolean agendar(Context context, String chave, long quando, String json) {
        if (!chaveDoDescanso(chave) || !ativo(context)) return false;
        long agora = System.currentTimeMillis();
        if (quando <= agora || quando > agora + MAXIMO_MS) return false;
        String[] textos = lerTextos(json);
        return textos != null && programar(context, chave, quando, textos[0], textos[1]);
    }

    /** Aviso de teste daqui a 10 s, pelo mesmo caminho do aviso de verdade. Funciona desligado, para conferir o relógio antes. */
    static boolean testar(Context context) {
        criarCanal(context);
        return programar(context, "teste", System.currentTimeMillis() + TESTE_MS, "Teste do relógio",
                "Se o relógio vibrou, o aviso do descanso vai chegar nele.");
    }

    private static Intent disparo(Context context, String chave) {
        return new Intent(context, AvisoRelogioReceiver.class).setAction(ACAO)
                .setData(Uri.parse("agenda-personal://relogio/" + chave));
    }

    private static boolean exato(AlarmManager alarmes) {
        return Build.VERSION.SDK_INT < 31 || alarmes.canScheduleExactAlarms();
    }

    private static synchronized boolean programar(Context context, String chave, long quando, String titulo, String texto) {
        AlarmManager alarmes = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmes == null) return false;
        if (!prefs(context).edit().putLong(chave + ".quando", quando).putString(chave + ".titulo", titulo)
                .putString(chave + ".texto", texto).commit()) return false;
        PendingIntent pendente = PendingIntent.getBroadcast(context, codigo(chave),
                disparo(context, chave).putExtra(EXTRA_CHAVE, chave).putExtra(EXTRA_QUANDO, quando),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (exato(alarmes)) alarmes.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, quando, pendente);
            else alarmes.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, quando, pendente);
            return true;
        } catch (RuntimeException semAlarmeExato) {
            // Sem "Alarmes e lembretes" o Android pode recusar o horário exato; o aviso sai com pequena tolerância.
            try {
                alarmes.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, quando, pendente);
                return true;
            } catch (RuntimeException recusado) {
                limpar(context, chave);
                return false;
            }
        }
    }

    /** Desmarca (o descanso foi parado antes do fim). Um aviso que já apareceu fica até sumir sozinho. */
    static synchronized void cancelar(Context context, String chave) {
        if (!chaveDoDescanso(chave)) return;
        PendingIntent pendente = PendingIntent.getBroadcast(context, codigo(chave), disparo(context, chave),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pendente != null) {
            AlarmManager alarmes = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmes != null) alarmes.cancel(pendente);
            pendente.cancel();
        }
        limpar(context, chave);
    }

    private static void limpar(Context context, String chave) {
        prefs(context).edit().remove(chave + ".quando").remove(chave + ".titulo").remove(chave + ".texto").commit();
    }

    /** Chamado pelo alarme. Só mostra se o aviso ainda é o marcado (nem desmarcado nem substituído) e se continua ligado. */
    static boolean disparar(Context context, String chave, long quando) {
        String titulo, texto;
        synchronized (AvisosRelogio.class) {
            if (!chaveConhecida(chave) || quando <= 0) return false;
            SharedPreferences p = prefs(context);
            if (p.getLong(chave + ".quando", -1L) != quando) return false;
            titulo = p.getString(chave + ".titulo", TITULO_PADRAO);
            texto = p.getString(chave + ".texto", TEXTO_PADRAO);
            limpar(context, chave);
            if (chaveDoDescanso(chave) && !ativo(context)) return false;
        }
        return mostrar(context, chave, titulo, texto);
    }

    /** Canal próprio, sem som (o som do fim do descanso já toca) e com vibração, para o app do relógio repassar e vibrar. */
    static void criarCanal(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel canal = new NotificationChannel(CANAL, "Avisos no relógio", NotificationManager.IMPORTANCE_HIGH);
        canal.setDescription("Aviso curto no fim do descanso, para o relógio vibrar. O app do relógio (Mi Fitness, Zepp, Galaxy Wearable…) repassa os avisos do celular.");
        canal.setSound(null, null);
        canal.enableVibration(true);
        canal.setVibrationPattern(VIBRACAO);
        canal.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        canal.setShowBadge(false);
        manager.createNotificationChannel(canal);
    }

    /** Publica o aviso. O toque no celular abre o app (sem recarregar se ele já estiver aberto). */
    static boolean mostrar(Context context, String chave, String titulo, String texto) {
        criarCanal(context);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return false;
        Intent abrir = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent toque = PendingIntent.getActivity(context, codigo(chave), abrir,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        // Na tela bloqueada do celular aparece só o título; nome de aluno e exercício ficam para o relógio e o celular aberto.
        Notification publico = new Notification.Builder(context, CANAL)
                .setSmallIcon(R.drawable.ic_stat_relogio).setColor(COR)
                .setContentTitle(titulo).setContentText("Toque para abrir o treino.")
                .build();
        Notification aviso = new Notification.Builder(context, CANAL)
                .setSmallIcon(R.drawable.ic_stat_relogio).setColor(COR)
                .setContentTitle(titulo).setContentText(texto)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(toque).setAutoCancel(true)
                .setShowWhen(true).setWhen(System.currentTimeMillis())
                .setTimeoutAfter(SUMIR_MS)
                .setVisibility(Notification.VISIBILITY_PRIVATE).setPublicVersion(publico)
                .build();
        try {
            // Tira o anterior antes: o app do relógio trata como aviso novo e vibra de novo.
            manager.cancel(chave, NOTIFICACAO);
            manager.notify(chave, NOTIFICACAO, aviso);
            return true;
        } catch (RuntimeException recusado) {
            return false;
        }
    }

    /** Estado para o cartão Smartwatch: ligado, permissão de notificação, canal e alarme exato. */
    static String status(Context context) {
        JSONObject status = new JSONObject();
        try {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel canal = manager == null ? null : manager.getNotificationChannel(CANAL);
            boolean permissao = manager != null && manager.areNotificationsEnabled()
                    && (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
            AlarmManager alarmes = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            int importancia = canal == null ? -1 : canal.getImportance();
            status.put("versao", VERSAO);
            status.put("app", versaoDoApp(context));
            status.put("ativo", ativo(context));
            status.put("permissao", permissao);
            status.put("canal", canal == null ? "ausente" : importancia == NotificationManager.IMPORTANCE_NONE ? "desligado"
                    : importancia >= NotificationManager.IMPORTANCE_DEFAULT ? "alerta" : "silencioso");
            status.put("exato", alarmes != null && exato(alarmes));
        } catch (Exception falha) {
            return "{\"versao\":" + VERSAO + ",\"erro\":\"status-indisponivel\"}";
        }
        return status.toString();
    }

    /** Versão do APK (ex.: "1.212"). */
    private static String versaoDoApp(Context context) {
        try {
            String nome = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            return nome == null ? "" : nome;
        } catch (Exception indisponivel) {
            return "";
        }
    }

    /** Abre as configurações do canal "Avisos no relógio" (vibração, tela bloqueada); sem a tela do canal, as do app. */
    static void abrirConfiguracoes(Activity activity) {
        criarCanal(activity);
        try {
            activity.startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName())
                    .putExtra(Settings.EXTRA_CHANNEL_ID, CANAL));
            return;
        } catch (RuntimeException semTela) { /* alguns aparelhos não têm a tela do canal */ }
        try {
            activity.startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName()));
        } catch (RuntimeException ignorado) { /* sem tela de notificações: o conteúdo mostra a orientação */ }
    }
}
