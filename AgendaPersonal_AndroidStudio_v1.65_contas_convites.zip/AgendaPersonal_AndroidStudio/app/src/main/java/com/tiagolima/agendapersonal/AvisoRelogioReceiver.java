package com.tiagolima.agendapersonal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarme do aviso no relógio (Android 1.212): mostra o aviso que o conteúdo marcou para o fim do descanso. Ver AvisosRelogio. */
public final class AvisoRelogioReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !AvisosRelogio.ACAO.equals(intent.getAction())) return;
        AvisosRelogio.disparar(context, intent.getStringExtra(AvisosRelogio.EXTRA_CHAVE),
                intent.getLongExtra(AvisosRelogio.EXTRA_QUANDO, 0L));
    }
}
