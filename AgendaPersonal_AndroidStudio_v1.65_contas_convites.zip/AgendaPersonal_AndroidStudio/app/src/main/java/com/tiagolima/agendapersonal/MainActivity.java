package com.tiagolima.agendapersonal;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceResponse;
import android.widget.Toast;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import android.view.Gravity;
import android.view.View;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 2002;

    private WebView webView;
    private UpdateManager updateManager;
    private InlineYouTubePlayer inlineVideo;
    private ReceiptTextReader receiptTextReader;
    private final java.util.concurrent.ExecutorService tikTokWorker = new java.util.concurrent.ThreadPoolExecutor(2,2,0L,java.util.concurrent.TimeUnit.MILLISECONDS,new java.util.concurrent.ArrayBlockingQueue<Runnable>(32));
    private SoundPreview soundPreview;
    private AlarmRingtonePicker ringtonePicker;
    private WebBackController backController;
    private ValueCallback<Uri[]> pendingFileChooser;
    private Uri pendingCameraUri;
    private LinearLayout bootPanel;
    private TextView bootStatus;
    private Button bootRetry;
    private boolean openUpdatesAfterBoot;
    private boolean floatingTimerPermissionDialog;
    private boolean floatingTimerPermissionPending;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        soundPreview = new SoundPreview(this);
        receiptTextReader = new ReceiptTextReader(this);
        ringtonePicker = new AlarmRingtonePicker(this, () -> {
            if (webView != null) webView.evaluateJavascript("if(typeof syncNativeAlarms==='function')syncNativeAlarms();", null);
        });
        openUpdatesAfterBoot=getIntent().getBooleanExtra("agenda_open_updates",false);
        UpdatePoller.schedule(this);

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        AlarmReceiver.createChannel(this);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#09080C"));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#09080C"));
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        bootPanel = new LinearLayout(this);
        bootPanel.setOrientation(LinearLayout.VERTICAL);
        bootPanel.setGravity(Gravity.CENTER);
        bootPanel.setPadding(32, 32, 32, 32);
        bootPanel.setBackgroundColor(Color.parseColor("#09080C"));
        ImageView bootLogo = new ImageView(this);
        bootLogo.setImageResource(R.mipmap.ic_launcher);
        bootLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        bootLogo.setContentDescription(getString(R.string.app_name));
        int logoSize = Math.round(128 * getResources().getDisplayMetrics().density);
        bootPanel.addView(bootLogo, new LinearLayout.LayoutParams(logoSize, logoSize));
        bootStatus = new TextView(this);
        bootStatus.setTextColor(Color.WHITE);
        bootStatus.setTextSize(18);
        bootStatus.setGravity(Gravity.CENTER);
        bootStatus.setVisibility(View.GONE);
        LinearLayout.LayoutParams statusLayout = new LinearLayout.LayoutParams(-1, -2);
        statusLayout.topMargin = Math.round(24 * getResources().getDisplayMetrics().density);
        bootRetry = new Button(this);
        bootRetry.setText("Tentar abrir novamente");
        bootRetry.setVisibility(View.GONE);
        bootRetry.setOnClickListener(v -> updateManager.start());
        bootPanel.addView(bootStatus, statusLayout);
        bootPanel.addView(bootRetry);
        root.addView(bootPanel, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        AppWindowLayout.apply(this, root);
        inlineVideo = new InlineYouTubePlayer(this, root, webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        updateManager = new UpdateManager(this, webView);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!request.isForMainFrame()) return !LocalPages.allowFrame(uri);
                if (UpdateManager.isLocalPage(uri)) {
                    if (request.isForMainFrame()) inlineVideo.close();
                    if (request.isForMainFrame()) updateManager.openPage(uri);
                    return true;
                }
                String scheme = uri.getScheme();
                if ("https".equals(scheme) || "http".equals(scheme) || "mailto".equals(scheme) || "tel".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return updateManager.localResponse(request.getUrl());
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showBootError("AP-LOAD-" + error.getErrorCode());
            }
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (backController != null) backController.pageStarted();
                if (inlineVideo != null) inlineVideo.close();
            }
            @Override public void onPageFinished(WebView view, String url) { updateManager.pageFinished(); }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = filePathCallback;
                pendingCameraUri = null;

                try {
                    Intent contentIntent = fileChooserParams.createIntent();
                    Intent cameraIntent = acceptsImage(fileChooserParams) ? createCameraIntent() : null;

                    if (fileChooserParams.isCaptureEnabled() && cameraIntent != null) {
                        startActivityForResult(cameraIntent, FILE_CHOOSER_REQUEST);
                        return true;
                    }

                    Intent chooser = Intent.createChooser(contentIntent, "Escolher arquivo");
                    if (cameraIntent != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                    pendingFileChooser = null;
                    pendingCameraUri = null;
                    Toast.makeText(MainActivity.this, "Não foi possível abrir os arquivos do celular.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new Bridge(this), "Android");
        backController = new WebBackController(this, webView, this::closeInlineVideoOnBack);
        updateManager.start();
    }

    public void showBootLoading() {
        runOnUiThread(() -> {
            bootStatus.setText("");
            bootStatus.setVisibility(View.GONE);
            bootRetry.setVisibility(View.GONE);
            bootPanel.setVisibility(View.VISIBLE);
        });
    }

    public void showBootReady() {
        runOnUiThread(() -> {
            bootPanel.setVisibility(View.GONE);
            updateManager.checkInBackground();
            if(openUpdatesAfterBoot){openUpdatesAfterBoot=false;getIntent().removeExtra("agenda_open_updates");updateManager.showScreen();}
        });
    }

    public void showBootError(String code) {
        final String safe = code == null ? "AP-BOOT" : code.replaceAll("[^A-Za-z0-9:_-]", "");
        runOnUiThread(() -> {
            bootStatus.setText("A agenda não concluiu a abertura.\nSeus dados não foram apagados.\n\nCódigo: " + safe);
            bootStatus.setVisibility(View.VISIBLE);
            bootRetry.setVisibility(View.VISIBLE);
            bootPanel.setVisibility(View.VISIBLE);
        });
    }

    private boolean acceptsImage(WebChromeClient.FileChooserParams params) {
        String[] types = params.getAcceptTypes();
        if (types == null || types.length == 0) return false;
        for (String type : types) {
            if (type != null && (type.startsWith("image/") || type.equals("image/*"))) return true;
        }
        return false;
    }

    private Intent createCameraIntent() throws Exception {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) return null;
        File folder = new File(getCacheDir(), "camera");
        if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Falha ao preparar câmera");
        File image = File.createTempFile("avaliacao_", ".jpg", folder);
        pendingCameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", image);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (ringtonePicker != null && ringtonePicker.result(requestCode, resultCode, data)) return;
        if (requestCode == UpdateManager.IMPORT_REQUEST) {
            if (resultCode == RESULT_OK && data != null) updateManager.importUri(data.getData());
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                if (data == null || data.getData() == null) {
                    if (pendingCameraUri != null) result = new Uri[]{pendingCameraUri};
                } else {
                    result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
            }
            if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(result);
            pendingFileChooser = null;
            pendingCameraUri = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (backController != null) backController.handleBack();
    }

    private boolean closeInlineVideoOnBack() {
        if (inlineVideo != null && inlineVideo.leaveFullScreen()) return true;
        if (inlineVideo != null && inlineVideo.isActive()) {
            inlineVideo.close();
            webView.evaluateJavascript("if(typeof clearWorkoutInlineVideo==='function')clearWorkoutInlineVideo();", null);
            return true;
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (floatingTimerPermissionPending) {
            floatingTimerPermissionPending = false;
            if (!LessonTimerOverlayService.allowed(this)) Toast.makeText(this,
                    "A faixa não foi autorizada. O cronômetro e o alarme continuam ativos.", Toast.LENGTH_LONG).show();
        }
        LessonTimerOverlayService.refresh(this, false);
        if (inlineVideo != null) inlineVideo.onResume();
        if (soundPreview != null) soundPreview.resume();
        if(updateManager!=null)updateManager.checkInBackground();
        if (webView != null) {
            webView.evaluateJavascript("if (typeof syncNativeAlarms === 'function') syncNativeAlarms();", null);
        }
    }

    private void offerFloatingTimer(boolean explicit) {
        if (isFinishing() || isDestroyed()) return;
        if (LessonTimerOverlayService.active(this).isEmpty()) {
            if (explicit) Toast.makeText(this, "Inicie o cronômetro e confirme o despertador primeiro.", Toast.LENGTH_LONG).show();
            return;
        }
        if (LessonTimerOverlayService.allowed(this)) {
            if (!LessonTimerOverlayService.refresh(this, explicit) && explicit)
                Toast.makeText(this, "Não foi possível abrir a faixa. O cronômetro continua ativo.", Toast.LENGTH_LONG).show();
            return;
        }
        android.content.SharedPreferences prefs = getSharedPreferences("agenda_lesson_timer_overlay", MODE_PRIVATE);
        if (floatingTimerPermissionDialog || !explicit && prefs.getBoolean("permission_asked", false)) return;
        floatingTimerPermissionDialog = true;
        try { new android.app.AlertDialog.Builder(this)
                .setTitle("Cronômetro flutuante")
                .setMessage("Para acompanhar o tempo enquanto usa outros aplicativos, autorize o Agenda Personal a exibir sobre outros apps. Arraste a janela para posicioná-la. O botão de fechar oculta a contagem sem encerrar o intervalo ou a aula.")
                .setNegativeButton("Agora não", (dialog, which) -> { })
                .setPositiveButton("Autorizar faixa", (dialog, which) -> {
                    try {
                        floatingTimerPermissionPending = true;
                        prefs.edit().remove("dismissed").apply();
                        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (RuntimeException error) {
                        floatingTimerPermissionPending = false;
                        Toast.makeText(this, "Não foi possível abrir a permissão. O cronômetro continua ativo.", Toast.LENGTH_LONG).show();
                    }
                })
                .setOnDismissListener(dialog -> floatingTimerPermissionDialog = false)
                .show();
        } catch (RuntimeException error) { floatingTimerPermissionDialog = false; return; }
        prefs.edit().putBoolean("permission_asked", true).apply();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);setIntent(intent);
        if(intent.getBooleanExtra("agenda_open_updates",false)) {
            if(updateManager!=null&&bootPanel.getVisibility()==View.GONE){intent.removeExtra("agenda_open_updates");updateManager.showScreen();}
            else openUpdatesAfterBoot=true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1001 && webView != null) {
            webView.evaluateJavascript("if (typeof syncNativeAlarms === 'function') syncNativeAlarms();", null);
        }
    }

    @Override protected void onPause() {
        if (inlineVideo != null) inlineVideo.onPause();
        if (soundPreview != null) soundPreview.pause();
        super.onPause();
    }

    private static boolean needsExactAlarmPermission(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && !am.canScheduleExactAlarms();
    }

    @Override protected void onDestroy() {
        if (receiptTextReader != null) receiptTextReader.close();
        if (soundPreview != null) soundPreview.pause();
        if (backController != null) backController.destroy();
        if (inlineVideo != null) inlineVideo.close();
        if (updateManager != null) updateManager.destroy();
        tikTokWorker.shutdownNow();
        super.onDestroy();
    }

    public static class Bridge {
        private final Activity activity;
        private boolean exactAlarmPromptShown = false;

        Bridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface public void openUpdates() { ((MainActivity) activity).updateManager.showScreen(); }
        @JavascriptInterface public void setUpdateAccount(String uid) { ((MainActivity) activity).updateManager.setUpdateAccount(uid); }
        @JavascriptInterface public void setWatchAccount(String uid) { WatchBridge.account(activity.getApplicationContext(), uid); }
        @JavascriptInterface public String sendWatchWorkout(String raw) { return WatchBridge.send(activity.getApplicationContext(), raw); }
        @JavascriptInterface public String getWatchStatus() { return WatchBridge.status(activity.getApplicationContext()); }
        @JavascriptInterface public void openWatchPairing(String vendor) { WatchPairing.open(activity, vendor); }
        @JavascriptInterface public String getUpdateStatus() { return ((MainActivity) activity).updateManager.distributionStatus(); }
        @JavascriptInterface public String getPublishableUpdate() { return ((MainActivity) activity).updateManager.publishableUpdate(); }
        @JavascriptInterface public void applyPublishedUpdate(String metadata) { ((MainActivity) activity).updateManager.applyPublishedUpdate(metadata); }
        @JavascriptInterface public void updatePageReady() { ((MainActivity) activity).updateManager.pageReady(); }
        @JavascriptInterface public void captureLegacyStorage(String data) { ((MainActivity) activity).updateManager.captureLegacyStorage(data); }
        @JavascriptInterface public void bootFailed(String code) { ((MainActivity) activity).showBootError(code); }
        @JavascriptInterface public boolean chooseAlarmRingtone(String kind) {
            if (!("lesson".equals(kind) || "timer".equals(kind) || "rest".equals(kind))) return false;
            activity.runOnUiThread(() -> { ((MainActivity) activity).soundPreview.stop(); ((MainActivity) activity).ringtonePicker.choose(kind); });
            return true;
        }
        @JavascriptInterface public boolean playCustomSound(String kind) {
            if (!"lesson".equals(kind) && !"timer".equals(kind) && !"rest".equals(kind)) return false;
            activity.runOnUiThread(() -> ((MainActivity) activity).soundPreview.play(kind));
            return true;
        }
        @JavascriptInterface public void stopCustomSoundPreview() {
            activity.runOnUiThread(() -> ((MainActivity) activity).soundPreview.stop());
        }
        @JavascriptInterface public String getSoundPreviewStatus() {
            return ((MainActivity) activity).soundPreview.status();
        }
        @JavascriptInterface public String getAlarmStatus() { return AlarmStatus.inspect(activity).toString(); }
        @JavascriptInterface public String getCustomSoundStatus() { return AudioSettings.status(activity).toString(); }
        @JavascriptInterface public void showAlarmSettings() { activity.runOnUiThread(() -> AlarmStatus.show(activity)); }

        @JavascriptInterface
        public boolean openYouTubeVideo(String videoJson) {
            try {
                if (videoJson == null || videoJson.length() > 2000) return false;
                JSONObject video = new JSONObject(videoJson);
                YouTubeVideoActivity.open(activity, video.optString("videoId"), video.optInt("startSeconds", 0),
                        video.optString("title", "Vídeo do exercício"));
                return true;
            } catch (Exception error) {
                return false;
            }
        }

        @JavascriptInterface public boolean readPixReceipt(String key, String mime, String base64) {
            MainActivity main=(MainActivity)activity;
            return main.receiptTextReader != null && main.receiptTextReader.read(key,mime,base64,(requestKey,result) -> {
                String script="if(typeof financeReceiptRead==='function')financeReceiptRead("+JSONObject.quote(requestKey)+","+result.toString()+");";
                activity.runOnUiThread(() -> { if (!activity.isFinishing() && !activity.isDestroyed() && main.webView!=null) main.webView.evaluateJavascript(script,null); });
            });
        }
        @JavascriptInterface public boolean requestTikTokVideo(String requestJson) {
            try {
                if (requestJson==null || requestJson.length()>3000) return false;
                JSONObject request=new JSONObject(requestJson); String key=request.optString("key"),url=request.optString("url");
                if (!key.matches("[A-Za-z0-9_-]{1,100}") || !TikTokVideoResolver.allowed(new java.net.URI(url))) return false;
                MainActivity main=(MainActivity)activity;
                main.tikTokWorker.execute(() -> {
                    JSONObject result;
                    try { result=TikTokVideoResolver.resolve(url,TikTokVideoResolver::fetch); }
                    catch (Exception error) { result=new JSONObject(); try { result.put("error","Não foi possível carregar o vídeo. Confira a conexão e o link."); } catch(Exception ignored){} }
                    final String script="if(typeof workoutTikTokMetadata==='function')workoutTikTokMetadata("+JSONObject.quote(key)+","+result.toString()+");";
                    activity.runOnUiThread(() -> { if (!activity.isFinishing() && !activity.isDestroyed()) main.webView.evaluateJavascript(script,null); });
                }); return true;
            } catch(Exception error) { return false; }
        }
        @JavascriptInterface public boolean openInlineTikTokVideo(String videoJson) {
            try {
                if(videoJson==null || videoJson.length()>4000)return false;
                JSONObject request=new JSONObject(videoJson);request.put("provider","tiktok");InlineYouTubePlayer.validate(request);
                MainActivity main=(MainActivity)activity;if(main.inlineVideo==null)return false;main.inlineVideo.open(request);return true;
            } catch(Exception error){return false;}
        }

        @JavascriptInterface public boolean openInlineYouTubeVideo(String videoJson) {
            try {
                if (videoJson == null || videoJson.length() > 4000) return false;
                JSONObject video = new JSONObject(videoJson);
                InlineYouTubePlayer.validate(video);
                MainActivity main = (MainActivity) activity;
                if (main.inlineVideo == null) return false;
                main.inlineVideo.open(video); return true;
            } catch (Exception error) { return false; }
        }

        @JavascriptInterface public void positionInlineYouTubeVideo(String requestKey, String boundsJson) {
            try {
                if (boundsJson == null || boundsJson.length() > 1600) return;
                MainActivity main = (MainActivity) activity;
                if (main.inlineVideo != null) main.inlineVideo.position(requestKey, new JSONObject(boundsJson));
            } catch (Exception ignored) {}
        }

        @JavascriptInterface public void closeInlineYouTubeVideo(String requestKey) {
            MainActivity main = (MainActivity) activity;
            if (main.inlineVideo != null) main.inlineVideo.close(requestKey);
        }

        @JavascriptInterface public boolean startWorkoutRest(String restJson) {
            try {
                if (restJson == null || restJson.length() > 4000) return false;
                AlarmScheduler.startWorkoutRest(activity, new JSONObject(restJson));
                activity.runOnUiThread(() -> { if (LessonTimerOverlayService.allowed(activity)) LessonTimerOverlayService.refresh(activity, true); });
                return true;
            } catch (Exception error) { return false; }
        }

        @JavascriptInterface public boolean cancelWorkoutRest() {
            try { AlarmScheduler.cancelWorkoutRest(activity); return true; }
            catch (Exception error) { return false; }
        }

        @JavascriptInterface
        public String saveCustomSound(String kind, String fileName, String mimeType, String base64) {
            try {
                return AudioSettings.saveBase64(activity, kind, fileName, mimeType, base64).toString();
            } catch (Exception e) {
                try {
                    String message = e.getMessage();
                    return new JSONObject().put("error", message == null
                            ? "Não foi possível salvar o áudio." : message).toString();
                } catch (Exception ignored) {
                    return "{\"error\":\"Não foi possível salvar o áudio.\"}";
                }
            }
        }

        @JavascriptInterface
        public boolean startLessonTimer(String timerJson) {
            try {
                AlarmScheduler.startLessonTimer(activity, new JSONObject(timerJson));
                try { activity.runOnUiThread(() -> ((MainActivity) activity).offerFloatingTimer(false)); }
                catch (RuntimeException ignored) { /* The alarm was already scheduled successfully. */ }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void cancelLessonTimer(String lessonId, String classDate) {
            AlarmScheduler.cancelLessonTimer(activity, lessonId, classDate);
        }

        @JavascriptInterface public void showWorkoutRestOverlay() {
            activity.runOnUiThread(() -> ((MainActivity) activity).offerFloatingTimer(true));
        }
        @JavascriptInterface public String getTimerOverlayStatus() {
            try { return new JSONObject().put("showing", LessonTimerOverlayService.isShowing())
                    .put("kind", LessonTimerOverlayService.showingKind()).put("allowed", LessonTimerOverlayService.allowed(activity)).toString(); }
            catch (Exception ignored) { return "{}"; }
        }

        @JavascriptInterface public void showLessonTimerOverlay() {
            activity.runOnUiThread(() -> ((MainActivity) activity).offerFloatingTimer(true));
        }

        @JavascriptInterface
        public boolean syncLessonAlarms(String agendaJson) {
            try {
                JSONObject agenda = new JSONObject(agendaJson);
                if (agenda.optInt("schema", 0) != 4) return false;
                AlarmScheduler.synchronize(activity, agenda);
                if (!AlarmStore.plans(activity).isEmpty()) {
                    activity.runOnUiThread(this::requestExactAlarmAccessIfNeeded);
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        private void requestExactAlarmAccessIfNeeded() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || exactAlarmPromptShown || !needsExactAlarmPermission(activity)) return;
            exactAlarmPromptShown = true;
            try {
                Toast.makeText(activity, "Para avisos no minuto exato, autorize Alarmes e lembretes.", Toast.LENGTH_LONG).show();
                Intent settings = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(settings);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void openMap(String query) {
            activity.runOnUiThread(() -> {
                String location = query == null ? "" : query.trim();
                if (location.isEmpty()) {
                    Toast.makeText(activity, "Informe o endereço ou o link do Google Maps.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String directLink = MapLinks.directGoogleMapsLink(location);
                try {
                    Uri uri = Uri.parse(directLink != null
                            ? directLink : "geo:0,0?q=" + Uri.encode(location));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    activity.startActivity(intent);
                } catch (Exception e) {
                    try {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse(directLink != null ? directLink
                                        : "https://www.google.com/maps/search/?api=1&query=" + Uri.encode(location))));
                    } catch (Exception ignored) {
                        Toast.makeText(activity, "Não foi possível abrir o mapa.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void openWhatsApp(String phone, String name) {
            openWhatsAppMessage(phone, "Olá, " + (name == null ? "" : name) + ".");
        }

        @JavascriptInterface
        public void openWhatsAppMessage(String phone, String message) {
            activity.runOnUiThread(() -> {
                try {
                    String digits = normalizeBrazilPhone(phone);
                    if (digits.isEmpty()) {
                        Toast.makeText(activity, "WhatsApp não cadastrado.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Uri uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(message == null ? "" : message));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    activity.startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(activity, "Não foi possível abrir o WhatsApp.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openExternal(String url) {
            activity.runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(url == null ? "" : url.trim());
                    String scheme = uri.getScheme();
                    if (scheme == null || !(scheme.equals("https") || scheme.equals("http") || scheme.equals("mailto") || scheme.equals("tel"))) {
                        throw new IllegalArgumentException("URL inválida");
                    }
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception e) {
                    Toast.makeText(activity, "Não foi possível abrir este link.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void shareText(String title, String text) {
            activity.runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Agenda Personal" : title);
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    activity.startActivity(Intent.createChooser(send, "Compartilhar"));
                } catch (Exception e) {
                    Toast.makeText(activity, "Não foi possível compartilhar.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void saveBase64File(String filename, String mimeType, String base64) {
            new Thread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    String safeName = sanitizeFilename(filename);
                    String mime = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType;
                    saveToDownloads(safeName, mime, bytes);
                    activity.runOnUiThread(() -> Toast.makeText(activity,
                            "Arquivo salvo em Downloads/Agenda Personal.", Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    activity.runOnUiThread(() -> Toast.makeText(activity,
                            "Não foi possível salvar o arquivo.", Toast.LENGTH_LONG).show());
                }
            }).start();
        }

        @JavascriptInterface
        public boolean openBase64File(String filename, String mimeType, String base64) {
            try {
                if (base64 == null || base64.length() > 18_000_000) return false;
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (bytes.length == 0 || bytes.length > 12 * 1024 * 1024) return false;
                String safeName = sanitizeFilename(filename);
                File folder = new File(activity.getCacheDir(), "shared");
                if (!folder.exists() && !folder.mkdirs()) return false;
                File file = new File(folder, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", file);
                String mime = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType;
                activity.runOnUiThread(() -> {
                    try {
                        Intent view = new Intent(Intent.ACTION_VIEW);
                        view.setDataAndType(uri, mime);
                        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        activity.startActivity(Intent.createChooser(view, "Abrir arquivo"));
                    } catch (Exception e) {
                        Toast.makeText(activity, "Não foi possível abrir este arquivo.", Toast.LENGTH_SHORT).show();
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void shareBase64File(String filename, String mimeType, String base64, String text) {
            new Thread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    String safeName = sanitizeFilename(filename);
                    File folder = new File(activity.getCacheDir(), "shared");
                    if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Falha ao preparar compartilhamento");
                    File file = new File(folder, safeName);
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", file);
                    activity.runOnUiThread(() -> {
                        try {
                            Intent send = new Intent(Intent.ACTION_SEND);
                            send.setType((mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType);
                            send.putExtra(Intent.EXTRA_STREAM, uri);
                            if (text != null && !text.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, text);
                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            activity.startActivity(Intent.createChooser(send, "Compartilhar"));
                        } catch (Exception e) {
                            Toast.makeText(activity, "Não foi possível compartilhar o arquivo.", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    activity.runOnUiThread(() -> Toast.makeText(activity,
                            "Não foi possível preparar o arquivo para compartilhar.", Toast.LENGTH_SHORT).show());
                }
            }).start();
        }

        private void saveToDownloads(String filename, String mime, byte[] bytes) throws Exception {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Agenda Personal");
                Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Falha ao criar arquivo");
                try (OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Falha ao abrir arquivo");
                    out.write(bytes);
                }
            } else {
                File folder = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (folder == null) throw new IllegalStateException("Downloads indisponível");
                File target = new File(folder, filename);
                try (FileOutputStream out = new FileOutputStream(target)) { out.write(bytes); }
            }
        }

        private String sanitizeFilename(String name) {
            String value = name == null ? "arquivo" : name.trim();
            value = value.replaceAll("[\\\\/:*?\"<>|\\x00-\\x1F]", "_");
            if (value.isEmpty()) value = "arquivo";
            return value.length() > 120 ? value.substring(0, 120) : value;
        }

        private String normalizeBrazilPhone(String phone) {
            String digits = phone == null ? "" : phone.replaceAll("\\D", "");
            if ((digits.length() == 10 || digits.length() == 11) && !digits.startsWith("55")) digits = "55" + digits;
            return digits;
        }
    }
}
