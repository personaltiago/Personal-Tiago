package com.tiagolima.agendapersonal;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

/** Applies a user-selected correction to the current release in memory before native review. */
final class UpdateAreaPatch {
    private static final String FORMAT = "agenda-patch/1";
    private static final String FORMAT_MODULE = "agenda-patch/2";
    private static final String GENERAL = "geral";
    private static final String[] PAGES = {"index.html", "professor.html", "avaliacoes.html", "cadastro.html"};
    private static final String[][] AREAS = {
        {"pets", "Pets"},
        {"alunos", "Alunos"},
        {"professor", "Professor"},
        {"relogio", "Relógio"},
        {"sons", "Sons e temporizadores"},
        {"evolucao", "Evolução"},
        {"avaliacoes", "Avaliações"},
        {"agenda", "Agenda"},
        {"cadastro", "Cadastro"},
        {"pagamentos", "Pagamentos"},
    };
    // Same page and component scope as agenda-patch/1 in the web updater.
    private static final String[][] RULES = {
        {
            "pets ap-student-mascot-css ap-student-pet-choice-css ap-student-mascot-model ap-mascot-homes "
                + "ap-mascot-asset-codec ap-student-mascot-art ap-mascot-daily-message ap-nonbear-reactions ap-mascot-petting "
                + "ap-teacher-mascot ap-mascot-closeup ap-student-pet-storage ap-student-mascot",
            "alunos ap-student-model ap-student-areas-css ap-student-ui ap-student-finish-control "
                + "ap-student-identity-css ap-student-identity-controls ap-student-notifications ap-student-notifications-css "
                + "ap-student-inline-video ap-student-inline-video-css ap-student-session-recovery ap-cardio-student "
                + "ap-student-workout-audio ap-student-access",
            "relogio ap-watch-model ap-watch-ui ap-watch-history",
            "sons ap-cardio-sound ap-workout-audio ap-workout-audio-options-css ap-workout-audio-options-ui",
            "evolucao ap-evolution-css ap-progress-sync-source ap-feedback-model ap-feedback-sync ap-feedback-student "
                + "ap-feedback-css",
            "avaliacoes ap-home-assessments ap-home-assessments-css",
            "agenda agenda-week-schedule-styles",
            "cadastro ap-registration-router",
            "pagamentos ap-billing-model payments-ui-css ap-student-billing ap-student-billing-css",
        },
        {
            "pets ap-teacher-mascot-card-css ap-pet-card-css ap-teacher-mascot-day",
            "professor ap-teacher-appearance ap-teacher-appearance-css ap-teacher-features ap-more-organization "
                + "ap-more-organization-css ap-student-archive ap-student-archive-css ap-student-tools-css "
                + "ap-workout-corrections ap-workout-corrections-css ap-workout-instructions ap-workout-instructions-css "
                + "ap-workout-previous-series ap-workout-previous-series-css ap-workout-timed-series "
                + "ap-workout-timed-series-css ap-cardio-teacher ap-workout-export ap-workout-export-model "
                + "ap-workout-export-css",
            "relogio ap-watch-model ap-watch-ui ap-watch-history ap-watch-teacher",
            "sons ap-timer-compatibility ap-cardio-sound ap-workout-audio ap-workout-audio-options-css "
                + "ap-workout-audio-options-ui ap-cardio-sound-settings ap-sound-preview-js ap-sound-preview-css "
                + "ap-rest-floating ap-rest-floating-css",
            "evolucao workout-student-progress ap-student-progress-css ap-student-progress-model "
                + "ap-teacher-student-progress ap-feedback-model ap-feedback-card ap-feedback-teacher ap-feedback-css",
            "avaliacoes ap-profile-assessments-css",
            "agenda ap-waitlist-model ap-waitlist ap-waitlist-css ap-compact-week-agenda ap-availability-compact-css "
                + "ap-availability-order-css ap-availability-conflict-css ap-student-lesson-priority "
                + "ap-student-lesson-priority-css",
            "cadastro ap-registration-link-editor-css ap-registration-contact-photo-css",
            "pagamentos ap-billing-model ap-finance-wallet-model ap-finance-wallet ap-finance-wallet-css "
                + "ap-finance-results ap-finance-results-model ap-finance-results-css ap-pix-receipt-model ap-pix-receipt "
                + "ap-pix-receipt-css",
        },
        {
            "avaliacoes pdf-page-layout-source agenda-integration-style report-preview-style "
                + "evaluation-previous-page-navigation evaluation-agenda-student-registration",
        },
        {
            "pets ap-bear-young-face-assets ap-chick-face-assets ap-kitten-face-assets ap-capybara-face-reaction-assets "
                + "ap-approved-bear-assets ap-bear-face-reaction-assets ap-mascot-gesture-runtime ap-mascot-reaction-assets "
                + "ap-mascot-affection-assets ap-mascot-image-assets ap-mascot-coat-assets ap-mascot-pose-assets "
                + "ap-mascot-home-assets",
            "evolucao ap-progress-sync-source",
            "cadastro ap-registration-photo-js ap-registration-photo-css",
        },
    };
    // Area, module, display name, parent module, and component IDs with that exclusive scope.
    private static final String[][] MODULES = {
        {"pets", "gato", "Gato", "", "ap-kitten-face-assets"},
        {"pets", "lobo", "Lobo", "", ""},
        {"pets", "urso", "Urso", "", "ap-bear-young-face-assets ap-approved-bear-assets ap-bear-face-reaction-assets"},
        {"pets", "capivara", "Capivara", "", "ap-capybara-face-reaction-assets"},
        {"pets", "galo", "Galo", "", "ap-chick-face-assets"},
        {"pets", "peixe", "Peixe", "", ""},
        {"pets", "raposa", "Raposa", "", ""},
        {"alunos", "treinos", "Treinos", "", "ap-student-finish-control ap-student-inline-video ap-student-inline-video-css ap-student-session-recovery"},
        {"alunos", "cronometro", "Cronômetro", "", "ap-cardio-student"},
        {"alunos", "descanso", "Descanso", "cronometro", ""},
        {"alunos", "audios", "Áudios", "", "ap-student-workout-audio"},
        {"alunos", "perfil", "Perfil", "", "ap-student-identity-css ap-student-identity-controls"},
        {"alunos", "notificacoes", "Notificações", "", "ap-student-notifications ap-student-notifications-css"},
        {"alunos", "acesso", "Acesso", "", "ap-student-access"},
        {"professor", "painel", "Painel", "", "ap-teacher-features ap-more-organization ap-more-organization-css"},
        {"professor", "alunos", "Alunos", "", "ap-student-archive ap-student-archive-css ap-student-tools-css"},
        {"professor", "exercicios", "Exercícios", "", "ap-workout-corrections ap-workout-corrections-css ap-workout-instructions ap-workout-instructions-css ap-workout-previous-series ap-workout-previous-series-css ap-workout-timed-series ap-workout-timed-series-css ap-cardio-teacher ap-workout-export ap-workout-export-model ap-workout-export-css"},
        {"professor", "aparencia", "Aparência", "", "ap-teacher-appearance ap-teacher-appearance-css"},
        {"relogio", "relogio", "Treino no relógio", "", "ap-watch-ui"},
        {"relogio", "sincronizacao", "Sincronização", "", "ap-watch-teacher"},
        {"relogio", "historico", "Histórico", "", "ap-watch-history"},
        {"sons", "audios", "Áudios de treino", "", "ap-workout-audio ap-workout-audio-options-css ap-workout-audio-options-ui ap-cardio-sound-settings"},
        {"sons", "cronometro", "Cronômetro", "", "ap-timer-compatibility"},
        {"sons", "descanso", "Descanso", "cronometro", "ap-rest-floating ap-rest-floating-css"},
        {"sons", "cardio", "Cardio", "cronometro", "ap-cardio-sound"},
        {"sons", "previa", "Prévia de sons", "", "ap-sound-preview-js ap-sound-preview-css"},
        {"evolucao", "progresso", "Progresso e cargas", "", "ap-evolution-css workout-student-progress ap-student-progress-css ap-student-progress-model ap-teacher-student-progress"},
        {"evolucao", "sincronizacao", "Sincronização", "", "ap-progress-sync-source"},
        {"evolucao", "feedback", "Feedback", "", "ap-feedback-model ap-feedback-sync ap-feedback-student ap-feedback-css ap-feedback-card ap-feedback-teacher"},
        {"avaliacoes", "ficha", "Ficha e perfil", "", "ap-home-assessments ap-home-assessments-css ap-profile-assessments-css evaluation-previous-page-navigation"},
        {"avaliacoes", "pdf", "PDF e relatórios", "", "pdf-page-layout-source report-preview-style"},
        {"avaliacoes", "integracao", "Integração com a agenda", "", "agenda-integration-style evaluation-agenda-student-registration"},
        {"agenda", "horarios", "Horários e disponibilidade", "", "agenda-week-schedule-styles ap-compact-week-agenda ap-availability-compact-css ap-availability-order-css ap-availability-conflict-css"},
        {"agenda", "espera", "Lista de espera", "", "ap-waitlist-model ap-waitlist ap-waitlist-css"},
        {"agenda", "prioridade", "Prioridade de aulas", "", "ap-student-lesson-priority ap-student-lesson-priority-css"},
        {"cadastro", "convites", "Links e convites", "", "ap-registration-router ap-registration-link-editor-css"},
        {"cadastro", "fotos", "Fotos de cadastro", "", "ap-registration-contact-photo-css ap-registration-photo-js ap-registration-photo-css"},
        {"pagamentos", "pagamentos", "Mensalidades e cobrança", "", "ap-billing-model payments-ui-css ap-student-billing ap-student-billing-css"},
        {"pagamentos", "carteira", "Carteira", "", "ap-finance-wallet-model ap-finance-wallet ap-finance-wallet-css"},
        {"pagamentos", "recibos", "Pix e comprovantes", "", "ap-pix-receipt-model ap-pix-receipt ap-pix-receipt-css"},
        {"pagamentos", "resultados", "Resultados financeiros", "", "ap-finance-results ap-finance-results-model ap-finance-results-css"},
    };
    private static final List<String> SHARED = Arrays.asList("ap-workout-audio", "ap-workout-audio-options-css",
        "ap-workout-audio-options-ui", "ap-feedback-model", "ap-feedback-css");
    private static final Pattern LABEL = Pattern.compile("[a-z0-9][a-z0-9-]{0,59}");
    private static final Pattern HASH = Pattern.compile("[a-f0-9]{64}");
    private static final Pattern RAW_TAG = Pattern.compile("<!--|<(script|style|textarea|title|xmp|iframe|noembed|noframes)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTRIBUTE = Pattern.compile("\\s([^\\s=/>]+)(?:\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+)))?");
    private static final Pattern END_BLOCK = Pattern.compile("</\\s*(?:script|style)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern VERSION = Pattern.compile("(\\d+)\\.(\\d+)\\.(\\d+)");

    private UpdateAreaPatch() {}

    static final class Invalid extends Exception {
        Invalid(String message) { super(message); }
    }

    static boolean recognizes(JSONObject value) {
        Object format = value.opt("format");
        return FORMAT.equals(format) || FORMAT_MODULE.equals(format);
    }

    static String areaName(String id) {
        for (String[] area : AREAS) if (area[0].equals(id)) return area[1];
        return "";
    }

    private static final class Change {
        final String page, id, before, after, content;
        Change(JSONObject entry) {
            page = string(entry, "page");
            id = string(entry, "id");
            before = string(entry, "before");
            after = string(entry, "after");
            content = entry.opt("content") instanceof String ? (String) entry.opt("content") : null;
        }
        String key() { return page + "|" + id; }
    }

    private static final class Block {
        final int start, end;
        Block(int start, int end) { this.start = start; this.end = end; }
    }

    static String sectionCatalog() {
        try {
            JSONObject catalog = new JSONObject();
            for (String[] area : AREAS) {
                JSONArray modules = new JSONArray();
                for (String[] row : MODULES) {
                    if (area[0].equals(row[0])) modules.put(new JSONArray().put(row[1]).put(row[2]).put(row[3]));
                }
                modules.put(new JSONArray().put(GENERAL).put("Geral").put(""));
                catalog.put(area[0], modules);
            }
            return catalog.toString();
        } catch (Exception invalidCatalog) { return "{}"; }
    }

    private static String[] moduleEntry(String area, String module) {
        for (String[] row : MODULES) if (area.equals(row[0]) && module.equals(row[1])) return row;
        return null;
    }

    private static String declaredModule(JSONObject patch, String area) throws Invalid {
        if (!FORMAT_MODULE.equals(patch.opt("format"))) return "";
        String module = string(patch, "module");
        if (!GENERAL.equals(module) && moduleEntry(area, module) == null)
            throw new Invalid("O manifesto modular precisa indicar um módulo válido de " + areaName(area) + ".");
        return module;
    }

    private static String componentModule(String area, Change change) {
        // The area allowlist has already checked the page and component.
        for (String[] row : MODULES) {
            if (area.equals(row[0]) && (" " + row[4] + " ").contains(" " + change.id + " ")) return row[1];
        }
        return GENERAL;
    }

    private static String resolvedModule(String area, String declared, List<Change> ordered) throws Invalid {
        if (GENERAL.equals(declared)) return GENERAL;
        String first = componentModule(area, ordered.get(0));
        boolean mixed = false;
        for (Change change : ordered) {
            String owner = componentModule(area, change);
            String[] entry = moduleEntry(area, owner);
            if (!declared.isEmpty() && entry != null && !declared.equals(owner) && !declared.equals(entry[3]))
                throw new Invalid("O componente " + change.id + " pertence a outro módulo de " + areaName(area) + ".");
            mixed |= !first.equals(owner);
        }
        return mixed ? GENERAL : first;
    }

    private static String modulePath(String area, String module) {
        String[] entry = moduleEntry(area, module);
        if (entry == null) return "Geral";
        String[] parent = moduleEntry(area, entry[3]);
        return parent == null ? entry[2] : parent[2] + " · " + entry[2];
    }

    static JSONObject apply(JSONObject installed, JSONObject patch, String appId, int sizeLimit) throws Exception {
        String id = string(patch, "id"), area = string(patch, "area"), areaLabel = areaName(area);
        String title = string(patch, "title"), version = string(patch, "version"), notes = string(patch, "notes");
        Object changes = patch.opt("changes");
        if (!recognizes(patch) || !appId.equals(patch.opt("appId")) ||
            !numberIs(patch, "bridgeVersion", 3) || !numberIs(patch, "dataSchema", 4) ||
            !LABEL.matcher(id).matches() || areaLabel.isEmpty() || !line(title, 90) ||
            !line(version, 40) || !line(notes, 700) || !(changes instanceof JSONArray) ||
            ((JSONArray) changes).length() == 0 || ((JSONArray) changes).length() > 24) {
            throw new Invalid("Escolha uma atualização por área compatível com esta Agenda Personal.");
        }
        List<Change> ordered = changes((JSONArray) changes, area, areaLabel);
        String declared = declaredModule(patch, area);
        String module = resolvedModule(area, declared, ordered);
        JSONArray fingerprints = new JSONArray();
        for (Change change : ordered) fingerprints.put(new JSONArray().put(change.page).put(change.id).put(change.before).put(change.after));
        // V1 signatures are also the keys of archives already on users' devices.
        JSONArray identity = new JSONArray().put(area);
        if (!declared.isEmpty()) identity.put(declared);
        String signature = digest(identity.put(fingerprints).toString());
        JSONArray history = history(installed, id, area, module, title, version, signature);

        JSONObject files = new JSONObject();
        JSONObject current = installed.getJSONObject("files");
        boolean changed = false;
        for (String page : PAGES) {
            String html = current.getString(page);
            Map<String, Change> selected = new HashMap<>();
            for (Change entry : ordered) if (page.equals(entry.page)) selected.put(entry.id, entry);
            String next = selected.isEmpty() ? html : replaceBlocks(html, selected, sizeLimit);
            files.put(page, next);
            changed |= next != html;
        }
        if (!changed) throw new Invalid("Esta correção já está presente.");
        int sequence = installed.optInt("sequence");
        Matcher build = VERSION.matcher(installed.optString("version"));
        if (sequence < 1 || sequence >= Integer.MAX_VALUE - 1 || !build.matches()) {
            throw new Invalid("O conteúdo em uso não pode receber esta correção.");
        }
        long nextBuild;
        try { nextBuild = Math.addExact(Long.parseLong(build.group(3)), 1L); }
        catch (ArithmeticException | NumberFormatException badNumber) {
            throw new Invalid("O número interno da compilação atingiu o limite.");
        }
        JSONObject release = new JSONObject();
        for (Iterator<String> keys = installed.keys(); keys.hasNext();) {
            String key = keys.next();
            release.put(key, installed.opt(key));
        }
        JSONObject update = new JSONObject().put("category", area).put("title", title)
            .put("summary", notes.substring(0, Math.min(notes.length(), 260)));
        update.put("module", module);
        return release.put("version", build.group(1) + "." + build.group(2) + "." + nextBuild)
            .put("sequence", sequence + 1).put("files", files)
            .put("notes", "[" + areaLabel + "] " + title + " — " + notes + "\nSeção: " + areaLabel + " · " + modulePath(area, module))
            .put("update", update)
            .put("modularUpdates", history);
    }

    private static List<Change> changes(JSONArray input, String area, String areaLabel) throws Exception {
        Map<String, Change> unique = new HashMap<>();
        for (int i = 0; i < input.length(); i++) {
            Object row = input.opt(i);
            if (!(row instanceof JSONObject)) throw new Invalid("Componente inválido na correção.");
            Change c = new Change((JSONObject) row);
            if (!allowed(c, area) || !HASH.matcher(c.before).matches() || !HASH.matcher(c.after).matches()
                || c.before.equals(c.after) || c.content == null || unique.put(c.key(), c) != null) {
                throw new Invalid("A correção contém um componente inválido ou fora da área " + areaLabel + ".");
            }
            if (END_BLOCK.matcher(c.content).find() || !c.after.equals(digest(c.content))) {
                throw new Invalid("Falha na verificação de integridade de " + c.id + ".");
            }
        }
        for (String id : SHARED) {
            Change student = unique.get("index.html|" + id), teacher = unique.get("professor.html|" + id);
            if ((student != null || teacher != null) &&
                (student == null || teacher == null || !student.after.equals(teacher.after))) {
                throw new Invalid("O componente " + id + " precisa da mesma correção no aluno e no professor.");
            }
        }
        List<Change> ordered = new ArrayList<>(unique.values());
        ordered.sort(Comparator.comparing(Change::key));
        return ordered;
    }

    private static boolean allowed(Change c, String area) {
        int page = Arrays.asList(PAGES).indexOf(c.page);
        if (page < 0 || !LABEL.matcher(c.id).matches()) return false;
        String prefix = area + " ";
        for (String row : RULES[page]) {
            if (row.startsWith(prefix)) return (" " + row.substring(prefix.length()) + " ").contains(" " + c.id + " ");
        }
        return false;
    }

    static JSONObject inverse(JSONObject installed, JSONObject patch) throws Exception {
        String area = patch.getString("area");
        List<Change> forward = changes(patch.getJSONArray("changes"), area, areaName(area));
        JSONArray reverse = new JSONArray();
        for (Change entry : forward) {
            String html = installed.getJSONObject("files").getString(entry.page);
            Block block = findBlocks(html, java.util.Collections.singletonMap(entry.id, entry)).get(entry.id);
            if (block == null) throw new Invalid("Componente ausente: " + entry.id);
            String text = html.substring(block.start, block.end);
            if (entry.before.equals(digest(text))) reverse.put(new JSONObject()
                .put("page", entry.page).put("id", entry.id).put("before", entry.after)
                .put("after", entry.before).put("content", text));
        }
        if (reverse.length() != forward.size()) return null;
        JSONObject inverse = new JSONObject().put("format", patch.getString("format")).put("appId", patch.getString("appId"))
            .put("bridgeVersion", 3).put("dataSchema", 4).put("id", patch.getString("id"))
            .put("area", area).put("version", patch.getString("version")).put("title", patch.getString("title"))
            .put("notes", "Reverte apenas os componentes alterados por esta correção.").put("changes", reverse);
        if (FORMAT_MODULE.equals(patch.opt("format"))) inverse.put("module", patch.getString("module"));
        return inverse;
    }

    static JSONObject remove(JSONObject installed, JSONObject record, JSONObject reverse, String appId, int limit) throws Exception {
        String id = record.getString("id");
        if (!id.equals(reverse.optString("id")) || !record.getString("area").equals(reverse.optString("area")))
            throw new Invalid("A cópia de reversão não corresponde a esta atualização.");
        for (Change entry : changes(reverse.getJSONArray("changes"), record.getString("area"), areaName(record.getString("area")))) {
            String html = installed.getJSONObject("files").getString(entry.page);
            Block block = findBlocks(html, java.util.Collections.singletonMap(entry.id, entry)).get(entry.id);
            if (block == null || !entry.before.equals(digest(html.substring(block.start, block.end))))
                throw new Invalid("Outra atualização já modificou um componente desta correção. A versão atual foi mantida.");
        }
        JSONObject base = new JSONObject();
        for (Iterator<String> keys = installed.keys(); keys.hasNext();) {
            String key = keys.next();
            if (!"modularUpdates".equals(key)) base.put(key, installed.opt(key));
        }
        JSONObject next = apply(base, reverse, appId, limit);
        String module = record.optString("module");
        if (!module.isEmpty() && !module.equals(next.getJSONObject("update").optString("module")))
            throw new Invalid("A cópia de reversão não corresponde ao módulo desta atualização.");
        JSONArray history = new JSONArray();
        JSONArray current = installed.getJSONArray("modularUpdates");
        for (int i = 0; i < current.length(); i++) {
            JSONObject item = current.optJSONObject(i);
            if (item == record) {
                JSONObject removed = new JSONObject(item.toString()).put("removed", true);
                history.put(removed);
            } else if (item != null) history.put(item);
        }
        next.getJSONObject("update").put("title", "Desinstalação de " + record.getString("title"));
        return next.put("modularUpdates", history)
            .put("notes", "Desinstalar: " + record.getString("title") + ". Apenas os trechos desta correção serão revertidos.");
    }

    private static JSONArray history(JSONObject installed, String id, String area, String module, String title, String version, String signature) throws Exception {
        JSONObject record = new JSONObject().put("id", id).put("area", area)
            .put("title", title).put("version", version).put("signature", signature);
        if (!module.isEmpty()) record.put("module", module);
        JSONArray result = new JSONArray().put(record);
        Object previous = installed.opt("modularUpdates");
        if (previous instanceof JSONArray) {
            JSONArray array = (JSONArray) previous;
            for (int i = 0; i < array.length(); i++) {
                Object raw = array.opt(i);
                if (!(raw instanceof JSONObject)) continue;
                JSONObject item = (JSONObject) raw;
                String priorId = string(item, "id"), priorSignature = string(item, "signature");
                if (id.equals(priorId)) {
                    if (!signature.equals(priorSignature)) throw new Invalid("Já existe outra correção com o identificador " + id + ".");
                } else if (result.length() < 20 && LABEL.matcher(priorId).matches()
                    && !areaName(string(item, "area")).isEmpty() && line(string(item, "title"), 90)
                    && line(string(item, "version"), 40) && HASH.matcher(priorSignature).matches()) {
                    result.put(item);
                }
            }
        }
        return result;
    }

    private static String replaceBlocks(String html, Map<String, Change> selected, int sizeLimit) throws Exception {
        Map<String, Block> blocks = findBlocks(html, selected);
        List<Change> pending = new ArrayList<>();
        long length = html.length();
        for (Change change : selected.values()) {
            Block block = blocks.get(change.id);
            if (block == null) throw new Invalid("O componente " + change.id + " não existe no conteúdo em uso.");
            String current = digest(html.substring(block.start, block.end));
            if (current.equals(change.after)) continue;
            if (!current.equals(change.before)) {
                throw new Invalid("Conflito em " + change.id + ". Esta correção precisa ser adaptada ao conteúdo em uso.");
            }
            length += change.content.length() - (block.end - block.start);
            pending.add(change);
        }
        if (pending.isEmpty()) return html;
        if (length > sizeLimit) throw new Invalid("A atualização montada ultrapassa o limite de 24 MiB.");
        pending.sort(Comparator.comparingInt(change -> blocks.get(change.id).start));
        StringBuilder next = new StringBuilder((int) length);
        int from = 0;
        for (Change change : pending) {
            Block block = blocks.get(change.id);
            next.append(html, from, block.start).append(change.content);
            from = block.end;
        }
        return next.append(html, from, html.length()).toString();
    }

    private static Map<String, Block> findBlocks(String html, Map<String, Change> selected) throws Invalid {
        Map<String, Block> blocks = new HashMap<>();
        Matcher raw = RAW_TAG.matcher(html);
        int from = 0;
        while (raw.find(from)) {
            String tag = raw.group(1);
            if (tag == null) {
                int end = html.indexOf("-->", raw.end());
                if (end < 0) break;
                from = end + 3;
                continue;
            }
            int openingEnd = tagEnd(html, raw.end());
            if (openingEnd < 0) break;
            Matcher close = Pattern.compile("</" + tag + "\\s*>", Pattern.CASE_INSENSITIVE).matcher(html);
            if (!close.find(openingEnd + 1)) break;
            from = close.end();
            if (!"script".equalsIgnoreCase(tag) && !"style".equalsIgnoreCase(tag)) continue;
            Matcher attrs = ATTRIBUTE.matcher(html).region(raw.end(), openingEnd);
            String found = null;
            int ids = 0;
            boolean src = false;
            while (attrs.find()) {
                String name = attrs.group(1);
                if ("src".equalsIgnoreCase(name)) src = true;
                if (!"id".equalsIgnoreCase(name)) continue;
                ids++;
                String id = attrs.group(2) != null ? attrs.group(2) : attrs.group(3) != null ? attrs.group(3) : attrs.group(4);
                if (selected.containsKey(id)) found = id;
            }
            if (found != null && (ids != 1 || src || blocks.put(found, new Block(openingEnd + 1, close.start())) != null)) {
                throw new Invalid("O componente " + found + " aparece em uma estrutura incompatível.");
            }
        }
        return blocks;
    }

    private static int tagEnd(String html, int start) {
        char quote = 0;
        for (int i = start; i < html.length(); i++) {
            char c = html.charAt(i);
            if (quote != 0) {
                if (quote == c) quote = 0;
            } else if (c == '\'' || c == '"') quote = c;
            else if (c == '>') return i;
        }
        return -1;
    }

    private static boolean numberIs(JSONObject value, String key, int expected) {
        Object number = value.opt(key);
        return number instanceof Number && ((Number) number).doubleValue() == expected;
    }

    private static boolean line(String value, int max) { return value.length() <= max && !value.trim().isEmpty(); }

    private static String string(JSONObject object, String key) {
        Object value = object.opt(key);
        return value instanceof String ? (String) value : "";
    }

    private static String digest(String value) throws Exception {
        return UpdateStorage.sha256(value.getBytes(StandardCharsets.UTF_8));
    }
}
