package com.tiagolima.agendapersonal;

import java.io.File;
import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONObject;

/** Private copies of modular corrections, addressed by the signature recorded in the release. */
final class UpdateArchive {
    private final File folder;
    private final int limit;

    UpdateArchive(File folder, int limit) { this.folder = folder; this.limit = limit; }

    private File file(JSONObject record, String kind) throws IOException {
        String id = record.optString("id"), signature = record.optString("signature");
        if (!id.matches("[a-z0-9][a-z0-9-]{0,59}") || !signature.matches("[a-f0-9]{64}"))
            throw new IOException("Atualização inválida.");
        return new File(folder, id + "-" + signature + kind);
    }

    JSONObject readReverse(JSONObject record) throws Exception {
        return new JSONObject(UpdateStorage.readText(file(record, ".undo"), limit).text);
    }

    void save(JSONObject record, JSONObject patch, JSONObject inverse) throws Exception {
        if (!folder.isDirectory() && !folder.mkdirs()) throw new IOException("Não foi possível guardar a correção.");
        File original = file(record, ".json"), undo = file(record, ".undo");
        UpdateStorage.writeJson(original, patch, limit);
        if (inverse != null) UpdateStorage.writeJson(undo, inverse, limit);
    }

    JSONObject describe(JSONObject record) throws Exception {
        String id = record.getString("id"), signature = record.getString("signature");
        return new JSONObject(record.toString()).put("downloadId", "patch-" + id + "-" + signature)
            .put("downloadable", file(record, ".json").isFile())
            .put("reversible", !record.optBoolean("removed") && record.optBoolean("ownsChanges", false) && file(record, ".undo").isFile());
    }

    UpdateDownloads.Source download(JSONObject record) throws Exception {
        JSONObject meta = describe(record);
        File original = file(record, ".json");
        if (!meta.optBoolean("downloadable")) throw new IOException("A cópia individual não está disponível.");
        meta.put("id", meta.getString("downloadId")).put("contentSha256", record.getString("signature"))
            .put("filename", "AgendaPersonal-" + record.getString("id") + ".agenda.json");
        return new UpdateDownloads.Source(meta, (target, allowed) -> {
            UpdateExport.check(allowed);
            UpdateStorage.copy(original, target, limit, null);
            UpdateExport.check(allowed);
        });
    }

    static JSONObject find(JSONObject release, String id, String signature) {
        JSONArray records = release == null ? null : release.optJSONArray("modularUpdates");
        if (records == null) return null;
        for (int i = 0; i < records.length(); i++) {
            JSONObject record = records.optJSONObject(i);
            if (record != null && id.equals(record.optString("id")) && signature.equals(record.optString("signature")))
                return record;
        }
        return null;
    }
}
