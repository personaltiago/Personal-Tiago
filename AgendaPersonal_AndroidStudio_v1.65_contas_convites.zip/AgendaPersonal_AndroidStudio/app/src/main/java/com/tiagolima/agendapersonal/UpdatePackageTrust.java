package com.tiagolima.agendapersonal;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.ByteArrayInputStream;
import java.security.cert.CertificateFactory;
import org.json.JSONObject;

/** Verify against the certificate that signed the APK currently installed on the device. */
final class UpdatePackageTrust {
    @SuppressWarnings("deprecation")
    static void verify(Context context, JSONObject pack) throws Exception {
        android.content.pm.Signature[] signers;
        PackageManager manager = context.getPackageManager();
        if (Build.VERSION.SDK_INT >= 28) {
            PackageInfo info = manager.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
            signers = info.signingInfo == null ? null : info.signingInfo.getApkContentsSigners();
        } else {
            signers = manager.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES).signatures;
        }
        if (signers == null || signers.length != 1) throw new UpdatePackageSignature.Invalid();
        CertificateFactory certificates = CertificateFactory.getInstance("X.509");
        UpdatePackageSignature.verify(pack, certificates.generateCertificate(
            new ByteArrayInputStream(signers[0].toByteArray())).getPublicKey());
    }
}
