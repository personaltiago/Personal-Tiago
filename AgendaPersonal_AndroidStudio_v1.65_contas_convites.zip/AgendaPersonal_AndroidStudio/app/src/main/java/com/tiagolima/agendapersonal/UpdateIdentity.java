package com.tiagolima.agendapersonal;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import org.json.JSONObject;

/** Identifies the pages actually served, independent of JSON formatting and release labels. */
final class UpdateIdentity {
    interface Assets { byte[] read(String name) throws Exception; }
    private static final String[] PAGES = {"index.html", "professor.html", "avaliacoes.html", "cadastro.html"};

    static String fingerprint(JSONObject release, Assets assets) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        sized(digest, "AgendaPersonal/pages/v1".getBytes(StandardCharsets.UTF_8));
        JSONObject files = release == null ? null : release.getJSONObject("files");
        for (String name : PAGES) {
            sized(digest, name.getBytes(StandardCharsets.UTF_8));
            byte[] page = files != null && files.has(name)
                ? files.getString(name).getBytes(StandardCharsets.UTF_8) : assets.read(name);
            sized(digest, page);
        }
        StringBuilder value = new StringBuilder(64);
        for (byte b : digest.digest()) value.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
        return value.toString();
    }

    private static void sized(MessageDigest digest, byte[] value) {
        digest.update(ByteBuffer.allocate(4).putInt(value == null ? -1 : value.length).array());
        if (value != null) digest.update(value);
    }

    static int compareVersions(String first, String second) {
        String[] a = first.split("\\."), b = second.split("\\.");
        for (int i = 0; i < 3; i++) {
            String x = a[i].replaceFirst("^0+(?!$)", ""), y = b[i].replaceFirst("^0+(?!$)", "");
            if (x.length() != y.length()) return Integer.compare(x.length(), y.length());
            int compared = x.compareTo(y); if (compared != 0) return compared;
        }
        return 0;
    }
}
