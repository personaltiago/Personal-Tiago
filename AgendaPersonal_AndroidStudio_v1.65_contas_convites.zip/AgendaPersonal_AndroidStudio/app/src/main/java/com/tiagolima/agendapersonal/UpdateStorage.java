package com.tiagolima.agendapersonal;

import android.util.AtomicFile;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

/** Writes and backs up full releases without allocating another full JSON string or byte array. */
final class UpdateStorage {
    private static final int CHUNK = 8192;
    private static final char[] HEX = "0123456789abcdef".toCharArray();
    private interface Content { void write(OutputStream output) throws Exception; }

    static final class StoredText {
        final String text, sha256;
        StoredText(String text, String sha256) { this.text = text; this.sha256 = sha256; }
    }

    /** The raw byte buffer leaves scope before the caller starts parsing large page strings. */
    static StoredText readText(File file, int limit) throws Exception {
        byte[] bytes = new AtomicFile(file).readFully();
        if (bytes.length > limit) throw new IOException("Arquivo muito grande.");
        return new StoredText(new String(bytes, StandardCharsets.UTF_8), sha256(bytes));
    }

    static String writeJson(File target, JSONObject value, int limit) throws Exception {
        return atomic(target, limit, null, output -> {
            Writer writer = new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8), CHUNK);
            json(writer, value, 0);
            writer.flush(); // AtomicFile owns the stream and syncs it before committing.
        });
    }

    static void writeText(File target, String value, int limit) throws Exception {
        atomic(target, limit, null, output -> {
            Writer writer = new BufferedWriter(new OutputStreamWriter(output, StandardCharsets.UTF_8), CHUNK);
            text(writer, value, 0, value.length());
            writer.flush();
        });
    }

    /** A mismatched source never replaces the last good backup. */
    static String copy(File source, File target, int limit, String expectedSha256) throws Exception {
        return atomic(target, limit, expectedSha256, output -> {
            try (InputStream input = new AtomicFile(source).openRead()) {
                byte[] buffer = new byte[CHUNK];
                int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            }
        });
    }

    static String sha256(byte[] bytes) throws Exception {
        return hex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }

    private static String atomic(File file, int limit, String expectedSha256, Content content) throws Exception {
        AtomicFile target = new AtomicFile(file);
        FileOutputStream output = target.startWrite();
        try {
            LimitedDigest stream = new LimitedDigest(output, limit);
            content.write(stream);
            stream.flush();
            String hash = hex(stream.digest.digest());
            if (expectedSha256 != null && !expectedSha256.equals(hash))
                throw new IOException("A cópia da versão instalada mudou.");
            target.finishWrite(output);
            return hash;
        } catch (Exception | Error failure) {
            try { target.failWrite(output); } catch (Exception | Error ignored) { }
            throw failure;
        }
    }

    private static final class LimitedDigest extends FilterOutputStream {
        final MessageDigest digest;
        final int limit;
        int size;
        LimitedDigest(OutputStream output, int limit) throws Exception {
            super(output); this.limit = limit; digest = MessageDigest.getInstance("SHA-256");
        }
        @Override public void write(int value) throws IOException {
            if (size >= limit) throw new IOException("Arquivo muito grande.");
            out.write(value); digest.update((byte) value); size++;
        }
        @Override public void write(byte[] bytes, int offset, int count) throws IOException {
            if (count < 0 || count > limit - size) throw new IOException("Arquivo muito grande.");
            out.write(bytes, offset, count); digest.update(bytes, offset, count); size += count;
        }
    }

    private static void json(Writer output, Object value, int depth) throws Exception {
        if (depth > 64) throw new IOException("Metadados da atualização muito complexos.");
        if (value == null || value == JSONObject.NULL) { output.write("null"); return; }
        if (value instanceof JSONObject) {
            JSONObject object = (JSONObject) value;
            output.write('{'); boolean first = true;
            Iterator<String> keys = object.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (!first) output.write(','); first = false;
                quoted(output, key); output.write(':'); json(output, object.opt(key), depth + 1);
            }
            output.write('}');
        } else if (value instanceof JSONArray) {
            JSONArray array = (JSONArray) value;
            output.write('[');
            for (int i = 0; i < array.length(); i++) {
                if (i > 0) output.write(','); json(output, array.opt(i), depth + 1);
            }
            output.write(']');
        } else if (value instanceof String) quoted(output, (String) value);
        else if (value instanceof Boolean) output.write(value.toString());
        else if (value instanceof Number) {
            double number = ((Number) value).doubleValue();
            if (Double.isNaN(number) || Double.isInfinite(number)) throw new IOException("Número inválido na atualização.");
            output.write(value.toString());
        } else throw new IOException("Metadado inválido na atualização.");
    }

    private static void quoted(Writer output, String value) throws IOException {
        output.write('"');
        int start = 0;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            String escape;
            switch (c) {
                case '"': escape = "\\\""; break;
                case '\\': escape = "\\\\"; break;
                case '\n': escape = "\\n"; break;
                case '\r': escape = "\\r"; break;
                case '\t': escape = "\\t"; break;
                case '\b': escape = "\\b"; break;
                case '\f': escape = "\\f"; break;
                default:
                    if (c >= 32) continue;
                    text(output, value, start, i);
                    output.write("\\u00"); output.write(HEX[c >> 4]); output.write(HEX[c & 15]);
                    start = i + 1; continue;
            }
            text(output, value, start, i); output.write(escape); start = i + 1;
        }
        text(output, value, start, value.length()); output.write('"');
    }

    private static void text(Writer output, String value, int start, int end) throws IOException {
        for (int offset = start; offset < end; offset += CHUNK)
            output.write(value, offset, Math.min(CHUNK, end - offset));
    }

    private static String hex(byte[] bytes) {
        char[] result = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            result[i * 2] = HEX[(bytes[i] & 255) >> 4]; result[i * 2 + 1] = HEX[bytes[i] & 15];
        }
        return new String(result);
    }
}
