package com.tiagolima.agendapersonal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** A small, non-focusable window; never owns, cancels, or reschedules alarms. */
public final class LessonTimerOverlayService extends Service {
    private static final String PREFS = "agenda_lesson_timer_overlay";
    private static final String CHANNEL = "agenda_lesson_timer_overlay_v1";
    private static final String HIDE = "com.tiagolima.agendapersonal.HIDE_TIMER_OVERLAY";
    private static final int NOTICE = 174404;
    private static volatile boolean showing;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager manager;
    private LinearLayout row;
    private TextView student, clock;
    private String notificationKey = "";
    private boolean foreground;

    static boolean allowed(Context context) {
        return Settings.canDrawOverlays(context);
    }

    static List<LessonTimerOverlayModel.Timer> active(Context context) {
        List<LessonTimerOverlayModel.Timer> timers = new ArrayList<>();
        for (JSONObject plan : AlarmStore.plans(context)) {
            if ("timer".equals(plan.optString("kind"))) {
                timers.add(new LessonTimerOverlayModel.Timer(plan.optString("alarmKey"),
                        plan.optString("student", "Aluno"), plan.optLong("triggerAtMillis")));
            }
        }
        return LessonTimerOverlayModel.active(timers, System.currentTimeMillis());
    }

    /** Call from a visible Activity, including when returning from permission settings. */
    static boolean refresh(Context context, boolean explicit) {
        if (explicit) context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("dismissed").apply();
        List<LessonTimerOverlayModel.Timer> timers = active(context);
        if (timers.isEmpty() || !allowed(context) || dismissed(context, timers)) return false;
        try {
            context.startForegroundService(new Intent(context, LessonTimerOverlayService.class));
            return true;
        } catch (RuntimeException error) {
            // An unavailable overlay must never roll back a successfully scheduled alarm.
            return false;
        }
    }

    static boolean isShowing() { return showing; }

    private static boolean dismissed(Context context, List<LessonTimerOverlayModel.Timer> timers) {
        return LessonTimerOverlayModel.signature(timers).equals(
                context.getSharedPreferences(PREFS, MODE_PRIVATE).getString("dismissed", ""));
    }

    @Override public void onCreate() {
        super.onCreate();
        manager = (WindowManager) getSystemService(WINDOW_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Cronômetro flutuante", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Contagem da aula em andamento, sem som adicional.");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // Fulfill the foreground-service contract even if the timer expired en route.
        try {
            startForeground(NOTICE, notification(null));
            foreground = true;
        } catch (RuntimeException error) { shutdown(); return START_NOT_STICKY; }
        if (intent != null && HIDE.equals(intent.getAction())) { hide(); return START_NOT_STICKY; }
        notificationKey = "";
        handler.removeCallbacks(tick);
        tick.run();
        return START_NOT_STICKY;
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            List<LessonTimerOverlayModel.Timer> timers = active(LessonTimerOverlayService.this);
            if (!allowed(LessonTimerOverlayService.this) || timers.isEmpty()
                    || dismissed(LessonTimerOverlayService.this, timers)) { shutdown(); return; }
            LessonTimerOverlayModel.Timer timer = timers.get(0);
            try {
                if (row == null) attach();
                String caption = timer.student + (timers.size() > 1 ? " · +" + (timers.size() - 1) + " aula(s)" : "");
                student.setText(caption);
                String time = LessonTimerOverlayModel.clock(timer.endAt - System.currentTimeMillis());
                clock.setText(time);
                clock.setContentDescription("Tempo restante da aula: " + time);
                String key = timer.key + "|" + timer.endAt + "|" + caption;
                if (!key.equals(notificationKey)) {
                    ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTICE, notification(timer));
                    notificationKey = key;
                }
                handler.postDelayed(this, 1000);
            } catch (RuntimeException error) { shutdown(); }
        }
    };

    private Notification notification(LessonTimerOverlayModel.Timer timer) {
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent enter = PendingIntent.getActivity(this, NOTICE, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent hide = PendingIntent.getService(this, NOTICE,
                new Intent(this, LessonTimerOverlayService.class).setAction(HIDE),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Cronômetro da aula")
                .setContentText(timer == null ? "Abrindo contagem flutuante…" : timer.student)
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(enter)
                .setCategory(Notification.CATEGORY_STOPWATCH).setVisibility(Notification.VISIBILITY_PRIVATE)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Ocultar faixa", hide);
        if (timer != null) builder.setWhen(timer.endAt).setShowWhen(true)
                .setUsesChronometer(true).setChronometerCountDown(true);
        return builder.build();
    }

    private void attach() {
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(5), dp(2), dp(5));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(24, 18, 32));
        background.setCornerRadius(dp(18));
        background.setStroke(dp(1), Color.rgb(153, 81, 213));
        row.setBackground(background);
        row.setElevation(dp(8));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("AULA EM ANDAMENTO");
        title.setTextColor(Color.rgb(204, 168, 238));
        title.setTextSize(9);
        title.setLetterSpacing(.06f);
        labels.addView(title);
        student = new TextView(this);
        student.setTextColor(Color.WHITE);
        student.setTextSize(12);
        student.setSingleLine(true);
        student.setEllipsize(TextUtils.TruncateAt.END);
        labels.addView(student);
        labels.setContentDescription("Abrir Agenda Personal");
        labels.setOnClickListener(v -> openAgenda());
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));

        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(23);
        clock.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        clock.setPadding(dp(10), 0, dp(6), 0);
        clock.setOnClickListener(v -> openAgenda());
        row.addView(clock, new LinearLayout.LayoutParams(-2, -2));

        Button close = new Button(this);
        close.setText("×");
        close.setTextSize(23);
        close.setTextColor(Color.rgb(218, 205, 230));
        close.setBackgroundColor(Color.TRANSPARENT);
        close.setMinWidth(0); close.setMinimumWidth(0);
        close.setPadding(0, 0, 0, 0);
        close.setContentDescription("Ocultar faixa sem parar o cronômetro");
        close.setOnClickListener(v -> hide());
        row.addView(close, new LinearLayout.LayoutParams(dp(48), dp(48)));
        manager.addView(row, layout());
        showing = true;
    }

    private WindowManager.LayoutParams layout() {
        int width = Math.max(1, Math.min(dp(340), getResources().getDisplayMetrics().widthPixels - dp(24)));
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(width, -2,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = dp(8);
        return params;
    }

    private void openAgenda() {
        try {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        } catch (RuntimeException ignored) { }
    }

    private void hide() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("dismissed", LessonTimerOverlayModel.signature(active(this))).apply();
        shutdown();
    }

    private void shutdown() {
        handler.removeCallbacks(tick);
        detach();
        if (foreground) { stopForeground(STOP_FOREGROUND_REMOVE); foreground = false; }
        stopSelf();
    }

    private void detach() {
        showing = false;
        if (row != null) {
            try { manager.removeView(row); } catch (RuntimeException ignored) { }
            row = null;
        }
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (row != null) {
            try { manager.updateViewLayout(row, layout()); } catch (RuntimeException error) { shutdown(); }
        }
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(tick);
        detach();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
