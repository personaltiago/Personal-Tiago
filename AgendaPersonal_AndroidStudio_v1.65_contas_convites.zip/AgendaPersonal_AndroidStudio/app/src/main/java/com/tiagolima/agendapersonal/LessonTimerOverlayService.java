package com.tiagolima.agendapersonal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RemoteViews;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Native countdown and optional floating window for the same scheduled rest. */
public final class LessonTimerOverlayService extends Service {
    private static final String PREFS = "agenda_lesson_timer_overlay";
    private static final String CHANNEL = "agenda_personal_rest_countdown_v1";
    private static final String HIDE = "com.tiagolima.agendapersonal.HIDE_TIMER_OVERLAY";
    private static final int NOTICE = 174404;
    private static volatile boolean showing;
    private static volatile String showingKind = "";
    private static LessonTimerOverlayService running;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager manager;
    private LinearLayout row;
    private TextView student, clock, title;
    private WindowManager.LayoutParams window;
    private float downX, downY;
    private int initialX, initialY;
    private boolean moved;
    private LessonTimerOverlayModel.Timer postedTimer;
    private boolean postedOverlay;
    private boolean foreground;

    static boolean allowed(Context context) {
        return Settings.canDrawOverlays(context);
    }

    static List<LessonTimerOverlayModel.Timer> active(Context context) {
        List<LessonTimerOverlayModel.Timer> timers = new ArrayList<>();
        for (JSONObject plan : AlarmStore.plans(context)) {
            if ("workout-rest".equals(plan.optString("kind"))
                    && !AlarmScheduler.STUDENT_REST_KEY.equals(plan.optString("alarmKey"))) {
                timers.add(new LessonTimerOverlayModel.Timer(plan.optString("alarmKey"),
                        plan.optString("student", "Aluno"), plan.optLong("triggerAtMillis"),
                        plan.optString("kind"), plan.optString("exercise"),
                        plan.optString("accent", "workout-rest".equals(plan.optString("kind")) ? "#9CC72C" : "#9951D5")));
            }
        }
        return LessonTimerOverlayModel.active(timers, System.currentTimeMillis());
    }

    /** Call from a visible Activity, including when returning from permission settings. */
    static boolean refresh(Context context, boolean explicit) {
        if (explicit) context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("dismissed").apply();
        List<LessonTimerOverlayModel.Timer> timers = active(context);
        if (timers.isEmpty()) return false;
        try {
            context.startForegroundService(new Intent(context, LessonTimerOverlayService.class));
            return true;
        } catch (RuntimeException error) {
            boolean posted = postPlain(context);
            report(context, (posted ? "publicada sem serviço" : "não abriu") + " (" + error.getClass().getSimpleName()
                    + (error.getMessage() == null ? "" : ": " + error.getMessage()) + ")" + lockscreenProblems(context));
            return posted;
        }
    }

    static boolean isShowing() { return showing; }
    static boolean isDismissed(Context context) { return dismissed(context, active(context)); }
    static String showingKind() { return showingKind; }

    static void refreshRunning() {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (running != null) running.refreshDisplay();
        });
    }

    private static boolean dismissed(Context context, List<LessonTimerOverlayModel.Timer> timers) {
        return LessonTimerOverlayModel.signature(timers).equals(
                context.getSharedPreferences(PREFS, MODE_PRIVATE).getString("dismissed", ""));
    }

    @Override public void onCreate() {
        super.onCreate();
        manager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel((NotificationManager) getSystemService(NOTIFICATION_SERVICE));
        running = this;
    }

    private static void createChannel(NotificationManager notifications) {
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Contagem do descanso", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("Tempo restante do descanso na tela bloqueada.");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setShowBadge(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        notifications.createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        List<LessonTimerOverlayModel.Timer> timers = active(this);
        if (intent != null && HIDE.equals(intent.getAction())) hideOverlay(timers);
        LessonTimerOverlayModel.Timer first = timers.isEmpty() ? null : timers.get(0);
        try {
            if (!foreground) {
                startForeground(NOTICE, notification(first));
                foreground = true;
                rememberNotification(first);
                report(this, "aberta" + lockscreenProblems(this));
            }
        } catch (RuntimeException error) {
            // The foreground service was refused: still post the countdown as a plain notification,
            // whose chronometer keeps counting on the lock screen by itself.
            boolean posted = postPlain(this);
            report(this, (posted ? "publicada sem serviço" : "não abriu") + " (" + error.getClass().getSimpleName()
                    + (error.getMessage() == null ? "" : ": " + error.getMessage()) + ")" + lockscreenProblems(this));
            shutdown();
            return START_NOT_STICKY;
        }
        refreshDisplay();
        return START_NOT_STICKY;
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            List<LessonTimerOverlayModel.Timer> timers = active(LessonTimerOverlayService.this);
            if (timers.isEmpty()) { shutdown(); return; }
            LessonTimerOverlayModel.Timer timer = timers.get(0);
            if (allowed(LessonTimerOverlayService.this) && !dismissed(LessonTimerOverlayService.this, timers)) {
                try { updateOverlay(timer); }
                catch (RuntimeException error) { detach(); }
            } else if (row != null) {
                detach();
            }
            try {
                // SystemUI advances the chronometer. Repost only when the notification's data changes.
                if (!LessonTimerOverlayModel.sameNotification(postedTimer, timer) || postedOverlay != (row != null)) {
                    ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTICE, notification(timer));
                    rememberNotification(timer);
                }
                long remaining = Math.max(1L, timer.endAt - System.currentTimeMillis());
                handler.postDelayed(this, Math.min(1_000L, remaining));
            } catch (RuntimeException error) { shutdown(); }
        }
    };

    private void refreshDisplay() {
        handler.removeCallbacks(tick);
        tick.run();
    }

    private void updateOverlay(LessonTimerOverlayModel.Timer timer) {
        if (row == null) attach();
        showingKind = timer.kind;
        int accent = Color.parseColor(timer.accent.matches("#[a-fA-F0-9]{6}") ? timer.accent : "#9CC72C");
        title.setTextColor(accent);
        clock.setTextColor(accent);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(25, 27, 30));
        background.setCornerRadius(dp(18));
        background.setStroke(dp(1), accent);
        row.setBackground(background);
        student.setText(timer.exercise);
        String time = LessonTimerOverlayModel.clock(timer.endAt - System.currentTimeMillis());
        clock.setText(time);
        clock.setContentDescription("Tempo restante do intervalo: " + time);
    }

    private void rememberNotification(LessonTimerOverlayModel.Timer timer) {
        postedTimer = timer;
        postedOverlay = row != null;
    }

    private Notification notification(LessonTimerOverlayModel.Timer timer) {
        Notification.Builder builder = countdown(this, timer);
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        if (row != null) {
            PendingIntent hide = PendingIntent.getService(this, NOTICE,
                    new Intent(this, LessonTimerOverlayService.class).setAction(HIDE),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Ocultar faixa", hide);
        }
        return builder.build();
    }

    private static Notification.Builder countdown(Context context, LessonTimerOverlayModel.Timer timer) {
        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent enter = PendingIntent.getActivity(context, NOTICE, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Descanso do treino")
                .setContentText(timer == null ? "Contagem do intervalo" : timer.exercise)
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(enter)
                .setCategory(Notification.CATEGORY_STOPWATCH).setVisibility(Notification.VISIBILITY_PUBLIC);
        if (timer != null) {
            // Supply both the system countdown and a native Chronometer in the compact layout.
            builder.setWhen(timer.endAt).setShowWhen(true)
                    .setUsesChronometer(true).setChronometerCountDown(true);
            RemoteViews compact = new RemoteViews(context.getPackageName(), R.layout.notification_rest_countdown);
            long base = SystemClock.elapsedRealtime() + Math.max(0L, timer.endAt - System.currentTimeMillis());
            compact.setChronometer(R.id.rest_countdown_clock, base, context.getString(R.string.rest_countdown_format), true);
            compact.setChronometerCountDown(R.id.rest_countdown_clock, true);
            compact.setTextViewText(R.id.rest_countdown_exercise, timer.exercise);
            builder.setStyle(new Notification.DecoratedCustomViewStyle()).setCustomContentView(compact);
        }
        return builder;
    }

    private void attach() {
        row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(24, 18, 32));
        background.setCornerRadius(dp(18));
        background.setStroke(dp(1), Color.rgb(153, 81, 213));
        row.setBackground(background);
        row.setElevation(dp(8));

        TextView grip = new TextView(this);
        grip.setText("⠿");
        grip.setTextColor(Color.WHITE);
        grip.setTextSize(24);
        grip.setGravity(Gravity.CENTER);
        grip.setContentDescription("Arrastar cronômetro do intervalo");
        grip.setOnTouchListener(this::drag);
        row.addView(grip, new LinearLayout.LayoutParams(dp(28), dp(48)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        title = new TextView(this);
        title.setText("INTERVALO");
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setTextColor(Color.rgb(204, 168, 238));
        title.setTextSize(9);
        title.setLetterSpacing(.06f);
        labels.addView(title);
        student = new TextView(this);
        student.setTextColor(Color.WHITE);
        student.setTextSize(12);
        student.setSingleLine(true);
        student.setEllipsize(TextUtils.TruncateAt.END);
        labels.addView(student);
        labels.setContentDescription("Arrastar cronômetro; toque para abrir Agenda Personal");
        labels.setOnClickListener(v -> openAgenda());
        labels.setOnTouchListener(this::drag);
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));

        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(24);
        clock.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        clock.setPadding(dp(8), 0, 0, 0);
        clock.setOnClickListener(v -> openAgenda());
        clock.setOnTouchListener(this::drag);
        row.addView(clock, new LinearLayout.LayoutParams(-2, -2));

        Button close = new Button(this);
        close.setText("×");
        close.setTextSize(23);
        close.setTextColor(Color.rgb(218, 205, 230));
        close.setBackgroundColor(Color.TRANSPARENT);
        close.setMinWidth(0); close.setMinimumWidth(0);
        close.setPadding(0, 0, 0, 0);
        close.setContentDescription("Ocultar faixa sem parar o cronômetro");
        close.setOnClickListener(v -> hide());
        row.addView(close, new LinearLayout.LayoutParams(dp(48), dp(48)));
        window = layout();
        manager.addView(row, window);
        showing = true;
    }

    private WindowManager.LayoutParams layout() {
        int width = Math.max(1, Math.min(dp(286), getResources().getDisplayMetrics().widthPixels - dp(24)));
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(width, -2,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = (int) getSharedPreferences(PREFS, MODE_PRIVATE).getLong("compact_x", dp(12));
        params.y = (int) getSharedPreferences(PREFS, MODE_PRIVATE).getLong("compact_y", Math.max(dp(8), getResources().getDisplayMetrics().heightPixels - dp(192)));
        clamp(params);
        return params;
    }

    private void clamp(WindowManager.LayoutParams params) {
        params.x = Math.max(0, Math.min(params.x, Math.max(0, getResources().getDisplayMetrics().widthPixels - params.width)));
        int height = row != null && row.getHeight() > 0 ? row.getHeight() : dp(64);
        params.y = Math.max(dp(8), Math.min(params.y, Math.max(dp(8), getResources().getDisplayMetrics().heightPixels - height - dp(24))));
    }

    private boolean drag(View view, MotionEvent event) {
        if (window == null) return false;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getRawX(); downY = event.getRawY();
                initialX = window.x; initialY = window.y; moved = false; return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - downX, dy = event.getRawY() - downY;
                if (!moved && Math.hypot(dx, dy) < ViewConfiguration.get(this).getScaledTouchSlop()) return true;
                moved = true; window.x = initialX + Math.round(dx); window.y = initialY + Math.round(dy); clamp(window);
                try { manager.updateViewLayout(row, window); } catch (RuntimeException error) { hide(); }
                return true;
            case MotionEvent.ACTION_UP:
                if (moved) getSharedPreferences(PREFS, MODE_PRIVATE).edit().putLong("compact_x", window.x).putLong("compact_y", window.y).apply();
                else view.performClick();
                return true;
            case MotionEvent.ACTION_CANCEL: return true;
            default: return false;
        }
    }

    private void openAgenda() {
        try {
            startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        } catch (RuntimeException ignored) { }
    }

    private void hide() {
        hideOverlay(active(this));
        refreshDisplay();
    }

    private void hideOverlay(List<LessonTimerOverlayModel.Timer> timers) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("dismissed", LessonTimerOverlayModel.signature(timers)).apply();
        detach();
    }

    private static boolean postPlain(Context context) {
        synchronized (AlarmScheduler.class) {
            try {
                List<LessonTimerOverlayModel.Timer> timers = active(context);
                if (timers.isEmpty()) return false;
                LessonTimerOverlayModel.Timer timer = timers.get(0);
                NotificationManager notifications = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
                createChannel(notifications);
                if (!AlarmStatus.notificationsAllowed(context, CHANNEL)) return false;
                long remaining = timer.endAt - System.currentTimeMillis();
                if (remaining <= 0) return false;
                notifications.notify(NOTICE, countdown(context, timer).setTimeoutAfter(remaining).build());
                return true;
            } catch (RuntimeException ignored) { return false; }
        }
    }

    /** Cancels the countdown notification when the rest is stopped (also covers the plain fallback). */
    static void cancelNotice(Context context) {
        try {
            NotificationManager notifications = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
            if (notifications != null) notifications.cancel(NOTICE);
        } catch (RuntimeException ignored) { }
    }

    /** Readable reasons why Android would hide the countdown on the lock screen ("" when none found). */
    static String lockscreenProblems(Context context) {
        StringBuilder out = new StringBuilder();
        try {
            NotificationManager notifications = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
            if (notifications == null) return "";
            if (!notifications.areNotificationsEnabled()) out.append("; notificações do app desligadas no Android");
            NotificationChannel channel = notifications.getNotificationChannel(CHANNEL);
            if (channel != null) {
                if (channel.getImportance() == NotificationManager.IMPORTANCE_NONE) out.append("; canal \"Contagem do descanso\" desligado");
                if (channel.getLockscreenVisibility() == Notification.VISIBILITY_SECRET) out.append("; canal oculto na tela bloqueada");
            }
        } catch (RuntimeException ignored) { }
        return out.toString();
    }

    static void report(Context context, String state) {
        String previous = AlarmStore.lastDelivery(context);
        String message = "Contagem na tela bloqueada: " + state;
        if (previous.startsWith("Descanso iniciado com aviso")) message += " | " + previous;
        AlarmStore.recordDelivery(context, message);
    }

    private void shutdown() {
        handler.removeCallbacks(tick);
        detach();
        if (foreground) { stopForeground(STOP_FOREGROUND_REMOVE); foreground = false; }
        stopSelf();
    }

    private void detach() {
        showing = false;
        showingKind = "";
        if (row != null) {
            try { manager.removeView(row); } catch (RuntimeException ignored) { }
            row = null;
        }
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        if (row != null) {
            try { window = layout(); manager.updateViewLayout(row, window); } catch (RuntimeException error) { hide(); }
        }
    }

    @Override public void onDestroy() {
        if (running == this) running = null;
        handler.removeCallbacks(tick);
        detach();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
