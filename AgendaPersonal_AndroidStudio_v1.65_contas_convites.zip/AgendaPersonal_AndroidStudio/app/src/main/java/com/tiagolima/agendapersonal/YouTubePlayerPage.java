package com.tiagolima.agendapersonal;

/** An isolated YouTube page whose HTTPS origin identifies this installed app. */
final class YouTubePlayerPage {
    private YouTubePlayerPage() {}

    static boolean validVideoId(String videoId) {
        return videoId != null && videoId.matches("[A-Za-z0-9_-]{11}");
    }

    static String origin(String packageName) {
        if (packageName == null || !packageName.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")) {
            throw new IllegalArgumentException("Identificação do app inválida");
        }
        return "https://" + packageName;
    }

    static String html(String videoId, int startSeconds, String packageName) {
        if (!validVideoId(videoId) || startSeconds < 0) throw new IllegalArgumentException("Vídeo inválido");
        String appOrigin = origin(packageName);
        return "<!doctype html><html lang=\"pt-BR\"><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<meta name=\"referrer\" content=\"strict-origin-when-cross-origin\">"
                + "<title>Vídeo do exercício</title><style>"
                + "*{box-sizing:border-box}html,body{margin:0;background:#0b0a0f;color:#f7f4fa;font-family:Arial,sans-serif}"
                + "main{padding:14px 12px}.video{width:100%;aspect-ratio:16/9;min-height:200px;background:#000}"
                + "#player{display:block;width:100%;height:100%;min-height:200px;border:0}"
                + "#status{color:#c9b8d5;font-size:14px;line-height:1.5;margin:16px 0 0}"
                + "#status:empty{display:none}"
                + "#videoControls{display:flex;gap:6px;flex:0 0 48px;padding:2px 6px;background:#15121c}"
                + "#videoControls button{flex:1;min-width:0;min-height:44px;padding:3px;border:1px solid #66526f;border-radius:8px;background:#231a2d;color:#f7f4fa;font:600 12px/1.2 Arial,sans-serif;cursor:pointer}"
                + "#videoControls button:disabled{opacity:.45}#videoControls button:focus-visible{outline:2px solid #dbb6ff;outline-offset:-3px}"
                + "main.video-error #videoControls{display:none}main:fullscreen,main:-webkit-full-screen{height:100vh;padding:0;display:flex;flex-direction:column}main:fullscreen .video,main:-webkit-full-screen .video{flex:1;height:auto;max-height:none;aspect-ratio:auto}"
                + "main.video-error.video-fullscreen #videoControls{display:flex}main.video-error #videoControls button:not(#videoFull){display:none}"
                + "@media(orientation:landscape){main{max-width:960px;margin:auto}.video{max-height:calc(100vh - 105px);aspect-ratio:auto;height:calc(100vh - 105px)}}"
                + "</style></head><body><main><div class=\"video\"><div id=\"player\"></div></div>"
                + "<div id=\"videoControls\" role=\"group\" aria-label=\"Controles do vídeo\"><button id=\"videoPlay\" type=\"button\" disabled onclick=\"toggleWorkoutVideo()\">Reproduzir</button>"
                + "<button id=\"videoRepeat\" type=\"button\" disabled onclick=\"repeatWorkoutVideo()\">Repetir</button><button id=\"videoSound\" type=\"button\" disabled aria-pressed=\"false\" aria-label=\"Ativar som do vídeo\" onclick=\"toggleWorkoutVideoSound()\">Ativar som</button><button id=\"videoFull\" type=\"button\" disabled aria-pressed=\"false\" onclick=\"fullscreenWorkoutVideo()\">Tela cheia</button></div>"
                + "<p id=\"status\" role=\"status\">Carregando vídeo…</p></main><script>"
                + "var player=null,autoStart=true,videoAllowed=true,videoPlaying=false,videoReady=false,videoMuted=true,videoNativeFullscreen=false;function videoStatus(text){document.getElementById('status').textContent=text;}"
                + "function videoPlayingState(playing){videoPlaying=playing;var b=document.getElementById('videoPlay');b.textContent=playing?'Pausar':'Reproduzir';b.setAttribute('aria-label',playing?'Pausar vídeo':'Reproduzir vídeo');}"
                + "function videoSoundState(){var b=document.getElementById('videoSound');b.textContent=videoMuted?'Ativar som':'Silenciar';b.setAttribute('aria-label',videoMuted?'Ativar som do vídeo':'Silenciar vídeo');b.setAttribute('aria-pressed',String(!videoMuted));}"
                + "var playerTimeout=setTimeout(function(){videoStatus('O vídeo não carregou. Confira a conexão ou use Abrir no YouTube.');},15000);"
                + "function onYouTubeIframeAPIReady(){try{player=new YT.Player('player',{width:'100%',height:'100%',videoId:'" + videoId + "',"
                + "playerVars:{autoplay:0,controls:0,playsinline:1,rel:0,hl:'pt-BR',start:" + startSeconds + ",origin:'" + appOrigin + "'},"
                + "events:{onReady:function(event){clearTimeout(playerTimeout);event.target.mute();videoMuted=true;videoSoundState();videoReady=true;videoStatus('');document.querySelectorAll('#videoControls button').forEach(function(b){b.disabled=false;});"
                + "if(autoStart&&videoAllowed&&!document.hidden)event.target.playVideo();},"
                + "onStateChange:function(event){if(event.data===1){if(!videoAllowed||document.hidden){pauseWorkoutVideo();return;}videoPlayingState(true);videoStatus('');}else if(event.data===0||event.data===2)videoPlayingState(false);},"
                + "onError:function(event){clearTimeout(playerTimeout);document.querySelector('main').classList.add('video-error');videoReady=false;videoPlayingState(false);var text=event.data===100?'Este vídeo está indisponível.':"
                + "event.data===101||event.data===150?'Este vídeo não permite reprodução dentro de aplicativos.':"
                + "event.data===153?'Não foi possível iniciar o player do YouTube.':'Não foi possível reproduzir este vídeo.';"
                + "videoStatus(text+' Use Abrir no YouTube.');},"
                + "onAutoplayBlocked:function(){videoPlayingState(false);videoStatus('');document.getElementById('videoPlay').focus();}}});}"
                + "catch(error){clearTimeout(playerTimeout);videoStatus('Não foi possível iniciar o vídeo. Use Abrir no YouTube.');}}"
                + "function pauseWorkoutVideo(){videoAllowed=false;if(player&&typeof player.pauseVideo==='function')player.pauseVideo();videoPlayingState(false);}"
                + "function toggleWorkoutVideo(){if(!videoReady)return;if(videoPlaying){pauseWorkoutVideo();return;}videoAllowed=true;player.playVideo();}"
                + "function repeatWorkoutVideo(){if(!videoReady)return;videoAllowed=true;player.seekTo(" + startSeconds + ",true);player.playVideo();}"
                + "function toggleWorkoutVideoSound(){if(!videoReady)return;try{if(videoMuted){player.unMute();if(player.getVolume()===0)player.setVolume(100);}else player.mute();videoMuted=!videoMuted;videoSoundState();}catch(error){videoStatus('Não foi possível alterar o som. Tente novamente.');}}"
                + "function workoutVideoIsFullscreen(){return !!(document.fullscreenElement||document.webkitFullscreenElement||videoNativeFullscreen);}"
                + "function updateWorkoutVideoFullscreen(){var full=workoutVideoIsFullscreen(),b=document.getElementById('videoFull');document.querySelector('main').classList.toggle('video-fullscreen',full);b.textContent=full?'Sair da tela cheia':'Tela cheia';b.setAttribute('aria-label',full?'Sair da tela cheia e voltar ao vídeo menor':'Ampliar vídeo em tela cheia');b.setAttribute('aria-pressed',String(full));}"
                + "function videoFullscreenState(active){videoNativeFullscreen=!!active;updateWorkoutVideoFullscreen();}"
                + "function fullscreenWorkoutVideo(){var full=workoutVideoIsFullscreen(),main=document.querySelector('main'),action=full?(document.exitFullscreen||document.webkitExitFullscreen):(main.requestFullscreen||main.webkitRequestFullscreen);if(!action){videoStatus(full?'Use Voltar do aparelho para sair da tela cheia.':'Tela cheia indisponível neste aparelho.');return;}try{var result=action.call(full?document:main);if(result&&result.then)result.then(updateWorkoutVideoFullscreen,function(){videoStatus(full?'Não foi possível reduzir o vídeo. Use Voltar do aparelho.':'Não foi possível abrir em tela cheia.');});else updateWorkoutVideoFullscreen();}catch(error){videoStatus(full?'Não foi possível reduzir o vídeo. Use Voltar do aparelho.':'Não foi possível abrir em tela cheia.');}}"
                + "document.addEventListener('fullscreenchange',updateWorkoutVideoFullscreen);document.addEventListener('webkitfullscreenchange',updateWorkoutVideoFullscreen);updateWorkoutVideoFullscreen();"
                + "document.addEventListener('visibilitychange',function(){if(document.hidden)pauseWorkoutVideo();});"
                + "</script><script async src=\"https://www.youtube.com/iframe_api\" "
                + "onerror=\"videoStatus('Confira a conexão e tente novamente, ou use Abrir no YouTube.');\"></script></body></html>";
    }

    static String inlineHtml(String videoId, int startSeconds, String packageName) {
        return html(videoId, startSeconds, packageName).replace("</head>",
                "<style>html,body{height:100%;background:#000}main{padding:0!important;height:100vh;display:flex;flex-direction:column}"
                + ".video{flex:1;width:100%;height:auto!important;max-height:none!important;aspect-ratio:auto;min-height:200px}"
                + "#status{flex:0 0 auto;margin:0;padding:6px 8px;font-size:12px;line-height:1.4;max-height:40px;overflow:auto}"
                + "#status:empty{display:none}#status.error{display:flex;align-items:center;gap:8px;padding:0 8px;max-height:48px;min-height:44px}"
                + "#status.error span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}"
                + "#status a{flex:0 0 auto;display:flex;align-items:center;min-height:44px;color:#e0b7ff;font-weight:bold;text-decoration:none}"
                + "</style></head>").replace(
                "function videoStatus(text){document.getElementById('status').textContent=text;}",
                "function videoStatus(text){var status=document.getElementById('status');status.textContent='';status.className='';"
                + "if(!text)return;if(text.indexOf('Abrir no YouTube')<0){status.textContent=text;return;}"
                + "status.className='error';var message=document.createElement('span');message.textContent=text;message.title=text;status.appendChild(message);"
                + "var link=document.createElement('a');link.href='https://www.youtube.com/watch?v=" + videoId
                + (startSeconds > 0 ? "&t=" + startSeconds : "") + "';link.textContent='Abrir no YouTube';status.appendChild(link);}");
    }
}
