package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Toast;

/** System alarm-tone list. Request codes preserve the target across activity recreation. */
final class AlarmRingtonePicker {
    private static final int LESSON_REQUEST = 2401, TIMER_REQUEST = 2402;
    private final Activity activity;
    private final Runnable changed;
    private boolean open;

    AlarmRingtonePicker(Activity activity, Runnable changed) { this.activity = activity; this.changed = changed; }

    void choose(String kind) {
        if (open || !("lesson".equals(kind) || "timer".equals(kind))) return;
        Uri current = "timer".equals(kind) ? AudioSettings.timerSound(activity) : AudioSettings.lessonSound(activity);
        Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, Settings.System.DEFAULT_ALARM_ALERT_URI);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, current == null ? Settings.System.DEFAULT_ALARM_ALERT_URI : current);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "timer".equals(kind) ? "Toque do fim da aula" : "Toque antes da aula");
        try { open = true; activity.startActivityForResult(intent, "timer".equals(kind) ? TIMER_REQUEST : LESSON_REQUEST); }
        catch (Exception ignored) { open = false; say("O celular não abriu a lista de toques. Você pode escolher um arquivo de áudio."); }
    }

    boolean result(int request, int code, Intent data) {
        if (request != LESSON_REQUEST && request != TIMER_REQUEST) return false;
        open = false;
        if (code != Activity.RESULT_OK || data == null) return true;
        try {
            Uri uri = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if (uri == null) return true;
            if ((data.getFlags() & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) != 0) {
                try { activity.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                catch (Exception ignored) {} // System alarm URIs normally need no persisted grant.
            }
            Ringtone ringtone = RingtoneManager.getRingtone(activity, uri);
            String title = ringtone == null ? "Toque do celular" : ringtone.getTitle(activity);
            AudioSettings.saveRingtone(activity, request == TIMER_REQUEST ? "timer" : "lesson", uri, title);
            AlarmReceiver.createChannel(activity);
            changed.run();
            say(request == TIMER_REQUEST ? "Toque do fim da aula salvo." : "Toque antes da aula salvo.");
        } catch (Exception error) { say(error.getMessage() == null ? "Não foi possível salvar o toque. Tente novamente." : error.getMessage()); }
        return true;
    }

    private void say(String text) { Toast.makeText(activity, text, Toast.LENGTH_LONG).show(); }
}
