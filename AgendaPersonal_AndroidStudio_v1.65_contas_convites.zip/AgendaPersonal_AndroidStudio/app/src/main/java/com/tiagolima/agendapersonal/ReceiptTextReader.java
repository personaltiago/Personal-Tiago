package com.tiagolima.agendapersonal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import androidx.exifinterface.media.ExifInterface;
import android.os.ParcelFileDescriptor;
import android.util.Base64;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

/** Reads only caller-supplied bytes, with the bundled on-device Latin model. */
final class ReceiptTextReader {
    interface Callback { void done(String key, JSONObject result); }
    static final int MAX_BYTES = 8 * 1024 * 1024;
    private final Context context;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy = new AtomicBoolean();
    private volatile boolean closed;
    ReceiptTextReader(Context context) { this.context = context.getApplicationContext(); }
    static boolean validRequest(String key, String mime, String encoded) {
        return key != null && key.matches("[A-Za-z0-9_-]{1,100}") && encoded != null
            && encoded.length() > 0 && encoded.length() <= 11_184_812
            && ("application/pdf".equals(mime) || "image/jpeg".equals(mime)
                || "image/png".equals(mime) || "image/webp".equals(mime));
    }
    boolean read(String key, String mime, String encoded, Callback callback) {
        if (closed || !validRequest(key,mime,encoded) || !busy.compareAndSet(false,true)) return false;
        try {
            worker.execute(() -> {
                File file = null;
                JSONObject result = new JSONObject();
                try {
                    byte[] bytes = Base64.decode(encoded,Base64.DEFAULT);
                    if (bytes.length == 0 || bytes.length > MAX_BYTES) throw new Exception("Use um comprovante de até 8 MB.");
                    file = File.createTempFile("receipt-ocr-", ".tmp", context.getCacheDir());
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    String text;
                    try (TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)) {
                        text = "application/pdf".equals(mime) ? pdf(file,recognizer) : image(file,recognizer);
                    }
                    result.put("text",text.substring(0,Math.min(text.length(),40000))).put("method","native-ocr");
                } catch (Exception error) {
                    try { result.put("error","Não foi possível ler automaticamente. Confira o arquivo e preencha os dados manualmente."); }
                    catch(Exception ignored) {}
                } finally {
                    if (file != null) file.delete();
                    busy.set(false);
                }
                if (!closed) callback.done(key,result);
            });
            return true;
        } catch(Exception error) { busy.set(false); return false; }
    }
    private String recognize(Bitmap bitmap, TextRecognizer recognizer) throws Exception {
        if (closed) throw new Exception("Leitura encerrada");
        // Never interrupt/recycle a bitmap while ML Kit is still processing it.
        try { return Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap,0))).getText(); }
        finally { bitmap.recycle(); }
    }
    private String image(File file, TextRecognizer recognizer) throws Exception {
        BitmapFactory.Options options = new BitmapFactory.Options(); options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(),options);
        if (options.outWidth < 1 || options.outHeight < 1 || (long)options.outWidth*options.outHeight > 40_000_000L)
            throw new Exception("Dimensões da imagem inválidas");
        options.inSampleSize = 1;
        while (Math.max(options.outWidth,options.outHeight)/options.inSampleSize > 2800) options.inSampleSize *= 2;
        options.inJustDecodeBounds = false; options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(),options);
        if (bitmap == null) throw new Exception("Imagem inválida");
        Matrix matrix = new Matrix();
        try {
            int orientation = new ExifInterface(file.getAbsolutePath()).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
            if (orientation==ExifInterface.ORIENTATION_ROTATE_90) matrix.postRotate(90);
            else if (orientation==ExifInterface.ORIENTATION_ROTATE_180) matrix.postRotate(180);
            else if (orientation==ExifInterface.ORIENTATION_ROTATE_270) matrix.postRotate(270);
            else if (orientation==ExifInterface.ORIENTATION_FLIP_HORIZONTAL) matrix.postScale(-1,1);
            else if (orientation==ExifInterface.ORIENTATION_FLIP_VERTICAL) matrix.postScale(1,-1);
            else if (orientation==ExifInterface.ORIENTATION_TRANSPOSE) { matrix.postRotate(90); matrix.postScale(-1,1); }
            else if (orientation==ExifInterface.ORIENTATION_TRANSVERSE) { matrix.postRotate(270); matrix.postScale(-1,1); }
        } catch(Exception ignored) {}
        if (!matrix.isIdentity()) {
            Bitmap rotated = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
            if (rotated != bitmap) bitmap.recycle(); bitmap = rotated;
        }
        return recognize(bitmap,recognizer);
    }
    private String pdf(File file, TextRecognizer recognizer) throws Exception {
        StringBuilder text = new StringBuilder();
        try (ParcelFileDescriptor fd=ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer=new PdfRenderer(fd)) {
            if (renderer.getPageCount()<1 || renderer.getPageCount()>3) throw new Exception("Use até três páginas para leitura automática");
            for(int n=0;n<renderer.getPageCount();n++) {
                if (closed) throw new Exception("Leitura encerrada");
                try (PdfRenderer.Page page=renderer.openPage(n)) {
                    float scale=Math.min(3f,Math.min(2000f/page.getWidth(),2600f/page.getHeight()));
                    int width=Math.max(1,Math.round(page.getWidth()*scale)),height=Math.max(1,Math.round(page.getHeight()*scale));
                    Bitmap bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE);
                    try { page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); }
                    catch(Exception error) { bitmap.recycle(); throw error; }
                    text.append(recognize(bitmap,recognizer)).append('\n');
                }
            }
        }
        return text.toString();
    }
    void close() { closed=true; worker.shutdown(); }
}
