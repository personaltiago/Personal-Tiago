package com.tiagolima.agendapersonal;
/** TikTok's official iframe in an unprivileged native WebView. */
final class TikTokPlayerPage {
 private TikTokPlayerPage() {}
 static String html(String videoId) {
  if (!TikTokVideoResolver.validId(videoId)) throw new IllegalArgumentException("Vídeo inválido");
  return ("<!doctype html><html lang=\"pt-BR\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta name=\"referrer\" content=\"strict-origin-when-cross-origin\"><title>Vídeo do exercício</title><style>\n"
   + "*{box-sizing:border-box}html,body{height:100%;margin:0;background:#000;color:#f7f4fa;font:14px/1.4 Arial,sans-serif}main{height:100vh;display:flex;flex-direction:column}iframe{flex:1;display:block;width:100%;min-height:200px;border:0}#controls{display:flex;gap:6px;flex:0 0 48px;padding:2px 6px;background:#15121c}button{flex:1;min-width:0;min-height:44px;padding:3px;border:1px solid #66526f;border-radius:8px;background:#231a2d;color:#f7f4fa;font:600 12px/1.2 Arial,sans-serif;cursor:pointer}button:disabled{opacity:.45}button:focus-visible{outline:2px solid #dbb6ff}#status{margin:0;padding:6px 8px;font-size:12px;max-height:80px;overflow:auto}#status:empty{display:none}#status a{color:#e0b7ff}main:fullscreen,main:-webkit-full-screen{height:100vh}#retry{display:none}main.error #retry{display:block}main.error #play,main.error #repeat,main.error #sound{display:none}\n"
   + "</style></head><body><main><iframe id=\"player\" title=\"Vídeo do TikTok\" allow=\"autoplay; fullscreen; encrypted-media\" allowfullscreen referrerpolicy=\"strict-origin-when-cross-origin\" src=\"https://www.tiktok.com/player/v1/__VIDEO_ID__?autoplay=0&controls=0&description=0&music_info=0&rel=0&muted=0\"></iframe><div id=\"controls\" role=\"group\" aria-label=\"Controles do vídeo\"><button id=\"play\" disabled>Reproduzir</button><button id=\"repeat\" disabled>Repetir</button><button id=\"sound\" disabled aria-pressed=\"false\">Ativar som</button><button id=\"retry\">Tentar novamente</button><button id=\"full\" aria-pressed=\"false\">Tela cheia</button></div><p id=\"status\" role=\"status\">Carregando vídeo…</p></main><script>\n"
   + "const frame=document.getElementById('player'),origin='https://www.tiktok.com';let ready=false,playing=false,muted=true,desiredMuted=true,muteAck=false,allowed=true,autoStart=true,pendingPlay=autoStart,nativeFull=false;\n"
   + "function send(type,value){frame.contentWindow.postMessage({type,value,'x-tiktok-player':true},origin)}\n"
   + "function status(text){document.getElementById('status').textContent=text}\n"
   + "function state(){document.getElementById('play').textContent=playing?'Pausar':'Reproduzir';const b=document.getElementById('sound');b.textContent=muted?'Ativar som':'Silenciar';b.setAttribute('aria-pressed',String(!muted))}\n"
   + "function fail(text){clearTimeout(timeout);ready=false;playing=false;document.querySelector('main').classList.add('error');status(text);state()}\n"
   + "let timeout=setTimeout(()=>fail('O vídeo não carregou. Confira a conexão e tente novamente.'),20000);\n"
   + "function pauseWorkoutVideo(){allowed=false;pendingPlay=false;if(ready)send('pause');playing=false;state()}\n"
   + "function play(){allowed=true;pendingPlay=true;if(!ready)return;if(muteAck){pendingPlay=false;send('play')}else send('mute')}\n"
   + "document.getElementById('play').onclick=()=>playing?pauseWorkoutVideo():play();\n"
   + "document.getElementById('repeat').onclick=()=>{if(ready){send('seekTo',0);play()}};\n"
   + "document.getElementById('sound').onclick=()=>{if(ready){desiredMuted=!desiredMuted;send(desiredMuted?'mute':'unMute');muted=desiredMuted;if(!desiredMuted)muteAck=true;state()}};\n"
   + "document.getElementById('retry').onclick=()=>{ready=false;playing=false;muted=true;desiredMuted=true;muteAck=false;allowed=true;pendingPlay=autoStart;document.querySelector('main').classList.remove('error');status('Carregando vídeo…');state();frame.src=frame.src;timeout=setTimeout(()=>fail('O vídeo não carregou. Confira a conexão.'),20000)};\n"
   + "window.addEventListener('message',event=>{\n"
   + " if(event.origin!==origin||event.source!==frame.contentWindow||!event.data||event.data['x-tiktok-player']!==true)return;\n"
   + " const m=event.data;\n"
   + " if(m.type==='onPlayerReady'){clearTimeout(timeout);ready=true;status('');document.querySelectorAll('#controls button').forEach(b=>b.disabled=false);send('mute')}\n"
   + " else if(m.type==='onMute'&&ready){muted=m.value===true;if(!muteAck&&desiredMuted&&!muted){send('mute');return}if(muted)muteAck=true;state();if(pendingPlay&&muteAck&&allowed&&!document.hidden){pendingPlay=false;send('play')}}\n"
   + " else if(m.type==='onStateChange'){if(m.value===1){if(!allowed||document.hidden){pauseWorkoutVideo();return}playing=true}else if(m.value===0||m.value===2)playing=false;state()}\n"
   + " else if(m.type==='onPlayerError'){const code=m.value?.errorCode;if(code===3002){pendingPlay=false;playing=false;status('Toque em Reproduzir para iniciar.');state()}else fail(code===1001?'Este vídeo está indisponível no TikTok.':'Não foi possível reproduzir este vídeo. Confira a conexão e tente novamente.')}\n"
   + "});\n"
   + "function videoFullscreenState(value){nativeFull=!!value;fullState()}\n"
   + "function fullState(){const full=!!(document.fullscreenElement||document.webkitFullscreenElement||nativeFull),b=document.getElementById('full');b.textContent=full?'Sair da tela cheia':'Tela cheia';b.setAttribute('aria-pressed',String(full))}\n"
   + "document.getElementById('full').onclick=()=>{const full=document.fullscreenElement||document.webkitFullscreenElement||nativeFull,owner=full?document:document.querySelector('main'),fn=full?(document.exitFullscreen||document.webkitExitFullscreen):(owner.requestFullscreen||owner.webkitRequestFullscreen);try{const p=fn?.call(owner);p?.catch(()=>status('Use Voltar do aparelho para sair da tela cheia.'))}catch(_){status('Use Voltar do aparelho para sair da tela cheia.')}};\n"
   + "document.addEventListener('fullscreenchange',fullState);document.addEventListener('webkitfullscreenchange',fullState);document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseWorkoutVideo()});state();fullState();\n"
   + "</script></body></html>\n").replace("__VIDEO_ID__",videoId);
 }
}
