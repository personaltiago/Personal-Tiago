package com.tiagolima.agendapersonal;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Periodic update notices; never downloads or installs without the user's tap. */
final class UpdatePoller {
    private static final String PREFS="agenda_distribution_v1", CHANNEL="agenda_updates_v1";
    private static final int JOB_ID=7417, NOTICE_ID=7418;
    private static SharedPreferences preferences(Context context) { return context.getSharedPreferences(PREFS,0); }
    static void schedule(Context context) {
        JobScheduler jobs=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if(jobs==null)return;
        if(jobs.getPendingJob(JOB_ID)!=null)return;
        try { jobs.schedule(new JobInfo.Builder(JOB_ID,new ComponentName(context,UpdateCheckService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true)
                .setPeriodic(6*60*60*1000L,60*60*1000L).build()); } catch(RuntimeException ignored) {}
    }
    static void markInstalled(Context context,int sequence) {
        preferences(context).edit().putInt("installed",sequence).apply();
        JSONObject latest=latest(context);
        if(!UpdateManifest.newer(latest,sequence)) {
            NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(manager!=null)manager.cancel(NOTICE_ID);
        }
    }
    static JSONObject latest(Context context) {
        try{return UpdateManifest.validate(new JSONObject(preferences(context).getString("latest","{}")),context.getPackageName());}
        catch(Exception ignored){return null;}
    }
    static JSONObject fetch(Context context,int installed) throws Exception {
        HttpURLConnection connection=(HttpURLConnection)new URL(UpdateManager.SITE_URL+"/api/manifest").openConnection();
        connection.setConnectTimeout(12000);connection.setReadTimeout(20000);connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Accept","application/json");connection.setRequestProperty("Cache-Control","no-cache");
        connection.setRequestProperty("User-Agent","AgendaPersonal/1.70 (Android; Updates)");
        try {
            if(connection.getResponseCode()!=200||connection.getContentType()==null||!connection.getContentType().contains("application/json"))throw new Exception("Consulta indisponível");
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] buffer=new byte[4096];
            try(InputStream input=connection.getInputStream()){int count;while((count=input.read(buffer))!=-1){if(bytes.size()+count>65536)throw new Exception("Resposta inválida");bytes.write(buffer,0,count);}}
            JSONObject value=UpdateManifest.validate(new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8)),context.getPackageName());
            preferences(context).edit().putString("latest",value.toString()).apply();
            int current=Math.max(installed,preferences(context).getInt("installed",UpdateManager.BASE_SEQUENCE));
            if(UpdateManifest.newer(value,current))notify(context,value);
            return value;
        } finally {connection.disconnect();}
    }
    static void background(Context context) throws Exception {
        fetch(context,Math.max(UpdateManager.BASE_SEQUENCE,preferences(context).getInt("installed",UpdateManager.BASE_SEQUENCE)));
    }
    private static synchronized void notify(Context context,JSONObject release) {
        SharedPreferences prefs=preferences(context);
        if(prefs.getInt("notified",0)>=release.optInt("sequence"))return;
        NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(manager==null||!manager.areNotificationsEnabled())return;
        manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Atualizações do aplicativo",NotificationManager.IMPORTANCE_DEFAULT));
        NotificationChannel channel=manager.getNotificationChannel(CHANNEL);
        if(channel==null||channel.getImportance()==NotificationManager.IMPORTANCE_NONE)return;
        Intent intent=new Intent(context,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("agenda_open_updates",true);
        PendingIntent open=PendingIntent.getActivity(context,NOTICE_ID,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        try {
            manager.notify(NOTICE_ID,new Notification.Builder(context,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("Agenda Personal · nova atualização")
                    .setContentText("Versão "+release.optString("version")+". Toque para atualizar.")
                    .setContentIntent(open).setAutoCancel(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_RECOMMENDATION).build());
            prefs.edit().putInt("notified",release.optInt("sequence")).apply();
        } catch(SecurityException ignored) {}
    }
}
