package com.tiagolima.agendapersonal;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/**
 * Cópia de segurança, no armazenamento interno do telefone, de chaves específicas do localStorage.
 * O localStorage continua sendo a fonte principal: esta cópia nunca altera nem substitui os dados do app.
 * Cada gravação é atômica (arquivo temporário + troca) e mantém a geração anterior em ".prev".
 */
final class NativeMirror {
    static final String MAIN_KEY = "agendaPersonalTL_v1";
    private static final int MAX_CHARS = 64 * 1024 * 1024;
    private static final Object LOCK = new Object();

    private NativeMirror() { }

    static boolean allowed(String key) { return MAIN_KEY.equals(key); }

    /** Hash FNV-1a sobre as unidades UTF-16, idêntico ao calculado no JavaScript. */
    static String hash(String value) {
        int h = 0x811c9dc5;
        for (int i = 0; i < value.length(); i++) { h ^= value.charAt(i); h *= 0x01000193; }
        return Long.toString(h & 0xffffffffL, 16);
    }

    private static File folder(File base) {
        File dir = new File(base, "mirror");
        if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory()) return null;
        return dir;
    }

    static boolean save(File base, String key, String value) { return save(base, key, value, false); }

    /**
     * Sem force, recusa substituir uma cópia grande por um conteúdo menos da metade do tamanho: isso costuma indicar
     * que os dados do app foram apagados e a cópia é justamente o que permite recuperá-los.
     */
    static boolean save(File base, String key, String value, boolean force) {
        if (!allowed(key) || value == null || value.length() < 2 || value.length() > MAX_CHARS) return false;
        if (value.charAt(0) != '{' || value.charAt(value.length() - 1) != '}') return false;
        File dir = folder(base);
        if (dir == null) return false;
        if (!force) {
            int existing = intField(info(base, key), "length");
            if (existing > 20000 && value.length() < existing / 2) return false;
        }
        synchronized (LOCK) {
            File data = new File(dir, key + ".json"), prev = new File(dir, key + ".prev"), tmp = new File(dir, key + ".tmp");
            File meta = new File(dir, key + ".meta"), metaTmp = new File(dir, key + ".meta.tmp");
            try {
                byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
                try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(bytes); out.getFD().sync(); }
                if (tmp.length() != bytes.length) throw new IOException("Gravação incompleta");
                if (data.exists()) Files.copy(data.toPath(), prev.toPath(), StandardCopyOption.REPLACE_EXISTING);
                Files.move(tmp.toPath(), data.toPath(), StandardCopyOption.REPLACE_EXISTING);
                String info = "{\"length\":" + value.length() + ",\"bytes\":" + bytes.length + ",\"hash\":\"" + hash(value)
                    + "\",\"savedAt\":" + System.currentTimeMillis() + "}";
                try (FileOutputStream out = new FileOutputStream(metaTmp)) { out.write(info.getBytes(StandardCharsets.UTF_8)); out.getFD().sync(); }
                Files.move(metaTmp.toPath(), meta.toPath(), StandardCopyOption.REPLACE_EXISTING);
                return true;
            } catch (Exception | OutOfMemoryError e) {
                tmp.delete(); metaTmp.delete();
                return false;
            }
        }
    }

    /** JSON com length, bytes, hash e savedAt da última cópia íntegra, ou {"exists":false}. */
    static String info(File base, String key) {
        if (!allowed(key)) return "{\"exists\":false}";
        File dir = folder(base);
        if (dir == null) return "{\"exists\":false}";
        synchronized (LOCK) {
            try {
                File data = new File(dir, key + ".json"), meta = new File(dir, key + ".meta");
                if (!data.isFile() || !meta.isFile()) return "{\"exists\":false}";
                String text = new String(Files.readAllBytes(meta.toPath()), StandardCharsets.UTF_8);
                int bytes = intField(text, "bytes");
                if (bytes < 0 || data.length() != bytes) return "{\"exists\":false,\"damaged\":true}";
                return "{\"exists\":true," + text.substring(1);
            } catch (Exception e) { return "{\"exists\":false}"; }
        }
    }

    static String read(File base, String key) {
        if (!allowed(key)) return "";
        File dir = folder(base);
        if (dir == null) return "";
        synchronized (LOCK) {
            try {
                if (!info(base, key).startsWith("{\"exists\":true")) return "";
                return new String(Files.readAllBytes(new File(dir, key + ".json").toPath()), StandardCharsets.UTF_8);
            } catch (Exception | OutOfMemoryError e) { return ""; }
        }
    }

    private static int intField(String json, String name) {
        int i = json.indexOf("\"" + name + "\":");
        if (i < 0) return -1;
        int s = i + name.length() + 3, e = s;
        while (e < json.length() && Character.isDigit(json.charAt(e))) e++;
        try { return Integer.parseInt(json.substring(s, e)); } catch (Exception ex) { return -1; }
    }
}
