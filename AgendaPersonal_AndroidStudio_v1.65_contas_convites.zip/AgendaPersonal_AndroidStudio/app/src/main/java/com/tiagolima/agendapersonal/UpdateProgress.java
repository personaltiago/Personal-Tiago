package com.tiagolima.agendapersonal;

import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.OpenableColumns;
import android.util.TypedValue;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Barra de progresso da importação de atualização (pedido do Tiago, 21/11/2026): mostra em que etapa a importação está e quando
 * terminou. Só exibe; não decide nada da instalação. Regras: a barra só chega a 100% quando a nova versão abriu e confirmou
 * (pageReady); em erro ou cancelamento ela para onde estava, muda de cor e diz que nada foi instalado. "Ocultar" fecha só a janela,
 * nunca a operação.
 */
final class UpdateProgress {
    private static final int ACCENT = 0xFFDD5595, ERROR = 0xFFE46A6A, DONE = 0xFF4FB286;
    private static final long READ_INTERVAL_MS = 100;
    private final MainActivity activity;
    private AlertDialog dialog;
    private TextView stepView, detailView;
    private ProgressBar bar;
    private boolean active, finished, hiddenByUser;
    private int percent;
    private String title = "Importando atualização", step = "", detail = "";
    private long lastRead;

    UpdateProgress(MainActivity activity) { this.activity = activity; }

    /** Tamanho do arquivo escolhido, ou -1 se o provedor não informar. */
    long sizeOf(Uri uri) {
        try (Cursor cursor = activity.getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst() && !cursor.isNull(0)) return cursor.getLong(0);
        } catch (RuntimeException ignored) { /* Sem tamanho: barra indeterminada na leitura. */ }
        return -1;
    }

    void start() {
        active = true; finished = false; hiddenByUser = false; percent = 0; lastRead = 0;
        title = "Importando atualização";
        show(-1, "Etapa 1 de 4 · Lendo o arquivo", "Abrindo o arquivo escolhido…", ACCENT);
    }

    /** Leitura: 0–40% da barra, pelos bytes lidos. */
    void reading(long read, long total) {
        if (!active || finished) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastRead < READ_INTERVAL_MS && read < total) return;
        lastRead = now;
        if (total > 0) show((int) Math.min(40, read * 40 / total), "Etapa 1 de 4 · Lendo o arquivo", mb(Math.min(read, total)) + " de " + mb(total) + " MB lidos", ACCENT);
        else show(-1, "Etapa 1 de 4 · Lendo o arquivo", mb(read) + " MB lidos", ACCENT);
    }

    void step(int value, String name, String text) {
        if (finished) return;
        active = true;
        show(value, name, text, ACCENT);
    }

    /** A janela "Revisar atualização" assume a tela; a barra volta depois da confirmação. */
    void waitReview() {
        if (!active || finished) return;
        percent = 60; step = "Etapa 2 de 4 · Aguardando sua confirmação"; detail = "Revise a atualização e toque em Instalar.";
        activity.runOnUiThread(() -> { if (dialog != null) dialog.dismiss(); dialog = null; });
    }

    void done(String message) {
        if (!active || finished) return;
        finished = true; title = "Atualização concluída";
        hiddenByUser = false;
        show(100, "Etapa 4 de 4 · Concluído", message, DONE);
        activity.runOnUiThread(() -> {
            final AlertDialog shown = dialog;
            if (shown != null) shown.getWindow().getDecorView().postDelayed(() -> { if (shown == dialog && shown.isShowing()) close(); }, 4000);
        });
        active = false;
    }

    /** Erro ou cancelamento: a barra fica onde parou, em outra cor, e a mensagem diz o que aconteceu. Nunca 100%. */
    void fail(String message) {
        if (!active || finished) return;
        finished = true; title = "Nada foi instalado";
        hiddenByUser = false;
        show(Math.min(percent, 99), step.isEmpty() ? "Parou" : "Parou em: " + step.replaceFirst("^Etapa \\d de 4 · ", ""), message, ERROR);
        active = false;
    }

    void close() {
        active = false;
        activity.runOnUiThread(() -> { if (dialog != null) dialog.dismiss(); dialog = null; });
    }

    private void show(int value, String name, String text, int color) {
        if (value >= 0) percent = value;
        step = name; detail = text;
        final int shown = value, tint = color;
        final String heading = title, line = name, info = text;
        activity.runOnUiThread(() -> {
            if (activity.isFinishing()) return;
            if (dialog == null) build();
            dialog.setTitle(heading);
            stepView.setText(line + (shown >= 0 ? " · " + shown + "%" : ""));
            detailView.setText(info);
            bar.setIndeterminate(shown < 0);
            if (shown >= 0) bar.setProgress(shown);
            bar.setProgressTintList(ColorStateList.valueOf(tint));
            bar.setIndeterminateTintList(ColorStateList.valueOf(tint));
            if (!dialog.isShowing() && !hiddenByUser) dialog.show();
        });
    }

    private void build() {
        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(22);
        box.setPadding(pad, dp(8), pad, dp(4));
        stepView = new TextView(activity);
        stepView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        bar = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setMinimumHeight(dp(12));
        detailView = new TextView(activity);
        detailView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        detailView.setAlpha(0.8f);
        box.addView(stepView);
        box.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(24)));
        box.addView(detailView);
        dialog = new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title).setView(box).setCancelable(true)
            .setNegativeButton("Ocultar", (d, which) -> hiddenByUser = true).create();
        dialog.setOnCancelListener(d -> hiddenByUser = true);
        dialog.setOnDismissListener(d -> { if (dialog == d) dialog = null; });
    }

    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }

    private static String mb(long bytes) { return String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.1f", bytes / 1048576.0); }
}
