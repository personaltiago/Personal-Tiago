package com.tiagolima.agendapersonal;

import android.app.AlertDialog;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.OpenableColumns;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Barra de progresso da importação de atualização (pedido do Tiago, 20 e 21/11/2026): mesmo formato da barra do "Publicar para os
 * alunos" (etapa à esquerda, porcentagem à direita, barra arredondada, MB e tempo restante), no verde dos ícones desta janela. Só exibe;
 * não decide nada da instalação. A barra só chega a 100% quando a nova versão abriu e confirmou (pageReady); em erro ou cancelamento
 * ela para onde estava, fica vermelha e diz que nada foi instalado. "Ocultar" fecha só a janela, nunca a operação.
 */
final class UpdateProgress {
    // GREEN: barra (o verde dos ícones desta janela); TEXT_GREEN: textos em verde, mais claro para ler bem no fundo escuro.
    static final int GREEN = 0xFF568900, TEXT_GREEN = 0xFF8DBF3A, ERROR = 0xFFE46A6A, TRACK = 0xFF3A3640;
    // Cores explícitas dos textos (1.209): no 1.208 eles herdavam a cor escura do tema do app e ficavam quase invisíveis no fundo cinza
    // da janela (print do Tiago, 21/11 12:13). Branco para a etapa, cinza-claro para os detalhes.
    static final int TEXT = 0xFFFFFFFF, TEXT_SOFT = 0xFFE4E4E4, TEXT_MUTED = 0xFFC2C2C2;
    private static final long READ_INTERVAL_MS = 100;
    private final MainActivity activity;
    private AlertDialog dialog;
    private TextView nameView, percentView, sizeView, detailView;
    private ProgressBar bar;
    private GradientDrawable fill;
    private boolean active, finished, hiddenByUser;
    private int percent;
    private String title = "Importando atualização", step = "", detail = "";
    private long lastRead, readStarted, lastSampleTime, lastSampleBytes;
    private double speed;

    UpdateProgress(MainActivity activity) { this.activity = activity; }

    /** Tamanho do arquivo escolhido, ou -1 se o provedor não informar. */
    long sizeOf(Uri uri) {
        try (Cursor cursor = activity.getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst() && !cursor.isNull(0)) return cursor.getLong(0);
        } catch (RuntimeException ignored) { /* Sem tamanho: barra indeterminada na leitura. */ }
        return -1;
    }

    void start() {
        active = true; finished = false; hiddenByUser = false; percent = 0; lastRead = 0; speed = 0;
        readStarted = lastSampleTime = SystemClock.uptimeMillis(); lastSampleBytes = 0;
        title = "Importando atualização";
        show(-1, "Etapa 1 de 4 · Lendo o arquivo", "Abrindo o arquivo escolhido…", "", GREEN);
    }

    /** Leitura: 0–40% da barra, pelos bytes lidos, com tempo restante depois de 1 s. */
    void reading(long read, long total) {
        if (!active || finished) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastRead < READ_INTERVAL_MS && read < total) return;
        lastRead = now;
        double seconds = (now - lastSampleTime) / 1000.0;
        if (seconds >= 0.25) {
            double sample = Math.max(0, read - lastSampleBytes) / seconds;
            speed = speed > 0 ? speed * 0.65 + sample * 0.35 : sample;
            lastSampleTime = now; lastSampleBytes = read;
        }
        String eta = "Etapa 1 de 4";
        if (total > 0 && read < total && now - readStarted >= 1000 && speed > 0) {
            long left = Math.max(1, (long) Math.ceil((total - read) / speed));
            eta = "Estimativa: cerca de " + (left < 60 ? left + " s" : (long) Math.ceil(left / 60.0) + " min") + " restantes.";
        }
        if (total > 0) show((int) Math.min(40, read * 40 / total), "Etapa 1 de 4 · Lendo o arquivo", eta, mb(Math.min(read, total)) + " de " + mb(total) + " MB", GREEN);
        else show(-1, "Etapa 1 de 4 · Lendo o arquivo", eta, mb(read) + " MB lidos", GREEN);
    }

    void step(int value, String name, String text) {
        if (finished) return;
        active = true;
        show(value, name, text, "", GREEN);
    }

    /** A janela "Revisar atualização" assume a tela; a barra volta depois da confirmação. */
    void waitReview() {
        if (!active || finished) return;
        percent = 60; step = "Etapa 2 de 4 · Aguardando sua confirmação"; detail = "Revise a atualização e toque em Instalar.";
        activity.runOnUiThread(() -> { if (dialog != null) dialog.dismiss(); dialog = null; });
    }

    void done(String message) {
        if (!active || finished) return;
        finished = true; hiddenByUser = false; title = "Atualização concluída";
        show(100, "Etapa 4 de 4 · Concluído", message, "", GREEN);
        activity.runOnUiThread(() -> {
            final AlertDialog shown = dialog;
            if (shown != null) shown.getWindow().getDecorView().postDelayed(() -> { if (shown == dialog && shown.isShowing()) close(); }, 4000);
        });
        active = false;
    }

    /** Erro ou cancelamento: a barra fica onde parou, em vermelho, e a mensagem diz o que aconteceu. Nunca 100%. */
    void fail(String message) {
        if (!active || finished) return;
        finished = true; hiddenByUser = false; title = "Nada foi instalado";
        // 1.210: mantém a linha "Etapa N de 4" da etapa em que parou (no 1.209 ela ficava vazia).
        show(Math.min(percent, 99), step.isEmpty() ? "Parou" : "Parou em: " + nameOf(step), message, stageOf(step), ERROR);
        active = false;
    }

    void close() {
        active = false;
        activity.runOnUiThread(() -> { if (dialog != null) dialog.dismiss(); dialog = null; });
    }

    private void show(int value, String name, String text, String size, int color) {
        if (value >= 0) percent = value;
        step = name; detail = text;
        final int shown = value, tint = color;
        final String heading = title, label = nameOf(name), stage = stageOf(name), info = text, amount = size;
        activity.runOnUiThread(() -> {
            if (activity.isFinishing()) return;
            if (dialog == null) build();
            dialog.setTitle(heading);
            nameView.setText(label);
            percentView.setText(shown >= 0 ? shown + "%" : "—");
            percentView.setTextColor(tint == ERROR ? ERROR : TEXT_GREEN);
            sizeView.setText(amount.isEmpty() ? stage : amount);
            detailView.setText(info.equals(stage) ? "" : info);
            bar.setIndeterminate(shown < 0);
            if (shown >= 0) bar.setProgress(shown);
            fill.setColor(tint);
            bar.setIndeterminateTintList(ColorStateList.valueOf(tint));
            if (!dialog.isShowing() && !hiddenByUser) dialog.show();
            // 1.210 (pedido do Tiago, 21/11 13:10): "Ocultar" enquanto a atualização continua; "Fechar" quando terminou ou deu erro.
            android.widget.Button button = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            if (button != null) { button.setText(finished ? "Fechar" : "Ocultar"); button.setTextColor(TEXT_GREEN); }
        });
    }

    private void build() {
        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(10), dp(24), dp(6));
        LinearLayout top = new LinearLayout(activity);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        nameView = text(17, true, TEXT);
        percentView = text(16, false, TEXT_GREEN);
        percentView.setGravity(Gravity.END);
        top.addView(nameView, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(percentView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        // Barra arredondada e grossa, como a do Publicar: trilho escuro e preenchimento na cor da etapa.
        GradientDrawable track = new GradientDrawable();
        track.setCornerRadius(dp(6)); track.setColor(TRACK);
        fill = new GradientDrawable();
        fill.setCornerRadius(dp(6)); fill.setColor(GREEN);
        LayerDrawable layers = new LayerDrawable(new Drawable[]{track, new ClipDrawable(fill, Gravity.START, ClipDrawable.HORIZONTAL)});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        bar = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgressDrawable(layers);
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(12));
        barParams.setMargins(0, dp(14), 0, dp(12));
        sizeView = text(15, false, TEXT_SOFT);
        detailView = text(14, false, TEXT_MUTED);
        detailView.setPadding(0, dp(4), 0, dp(4));
        box.addView(top);
        box.addView(bar, barParams);
        box.addView(sizeView);
        box.addView(detailView);
        dialog = new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title).setView(box).setCancelable(true)
            .setNegativeButton("Ocultar", (d, which) -> hiddenByUser = true).create();
        dialog.setOnCancelListener(d -> hiddenByUser = true);
        dialog.setOnDismissListener(d -> { if (dialog == d) dialog = null; });
    }

    private TextView text(int sp, boolean bold, int color) {
        TextView view = new TextView(activity);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setTextColor(color);
        return view;
    }

    private static String nameOf(String name) { return name.replaceFirst("^Etapa \\d de 4 · ", ""); }

    private static String stageOf(String name) { return name.startsWith("Etapa ") && name.contains(" · ") ? name.substring(0, name.indexOf(" · ")) : ""; }

    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }

    private static String mb(long bytes) { return String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.1f", bytes / 1048576.0); }
}
