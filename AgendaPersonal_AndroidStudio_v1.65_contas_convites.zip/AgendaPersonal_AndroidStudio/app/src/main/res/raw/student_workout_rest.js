(function (app) {
  'use strict';
  if (app.__agendaStudentRestInstalled || typeof toggleExerciseSet !== 'function' ||
      typeof exSave !== 'function' || typeof app.Android?.startStudentRest !== 'function') return;
  app.__agendaStudentRestInstalled = true;

  const save = exSave;
  const toggle = toggleExerciseSet;
  let selection = null;
  let fallback = null;
  let fallbackTimeout;
  let audioContext;
  let activeOwner = student();

  function student() {
    const account = app.__AP_STUDENT_CONTEXT;
    return account?.role === 'student' ? account.storageId : null;
  }

  function clearFallback() {
    clearTimeout(fallbackTimeout);
    fallback = null;
  }

  function primeSound() {
    try {
      if (app.APWorkoutAudio) { app.APWorkoutAudio.prime(); return; }
      const Audio = app.AudioContext || app.webkitAudioContext;
      if (!audioContext && Audio) audioContext = new Audio();
      audioContext?.resume()?.catch(() => {});
    } catch (_) { }
  }

  function playFallback() {
    if (!fallback || student() !== fallback.owner) { clearFallback(); return; }
    if (Date.now() < fallback.deadline) return;
    const late = Date.now() - fallback.deadline;
    clearFallback();
    if (late > 60_000) return;
    if (app.APWorkoutAudio) { app.APWorkoutAudio.play('rest').catch(() => {}); return; }
    if (!audioContext) return;
    try {
      const now = audioContext.currentTime;
      const volume = audioContext.createGain();
      const tone = audioContext.createOscillator();
      tone.frequency.value = 880;
      tone.connect(volume);
      volume.connect(audioContext.destination);
      volume.gain.setValueAtTime(0.16, now);
      volume.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      tone.start(now);
      tone.stop(now + 0.45);
    } catch (_) { }
  }

  function armNative(deadline, exercise) {
    try { return app.Android.startStudentRest(deadline, exercise) === true; }
    catch (_) { return false; }
  }

  function cancel(deadline) {
    if (!deadline || fallback?.deadline === deadline) clearFallback();
    try { app.Android.cancelStudentRest(deadline); } catch (_) { }
  }

  toggleExerciseSet = function (exercise, series) {
    if (!student()) return toggle.apply(this, arguments);
    selection = {plan: exActiveId, exercise, series};
    try { return toggle.apply(this, arguments); }
    finally { selection = null; }
  };

  exSave = function (data) {
    const owner = student();
    if (!owner) return save.apply(this, arguments);
    const before = exStore().active || {};
    const active = data?.active || {};
    const selected = selection;
    let started = null;
    if (selected) {
      const {plan, exercise, series} = selected;
      const previous = before[plan];
      const current = active[plan];
      const exerciseData = exercisesFor(plan)[exercise];
      if (previous && current && exerciseData && !exChecks(previous, exercise, exerciseData.sets)[series]
          && exChecks(current, exercise, exerciseData.sets)[series]) {
        const paired = typeof biSetCompanionIndex === 'function' && biSetCompanionIndex(exercise) != null;
        const seconds = Number(exerciseData.rows?.[series]?.rest ?? exerciseData.rest);
        // A bi-set keeps its existing A → B → rest sequence.
        if ((!paired || biSetSourceIndex(exercise) !== exercise) && Number.isFinite(seconds)
            && seconds > 0 && seconds <= 3_600) {
          const deadline = Date.now() + Math.round(seconds * 1_000);
          const name = String(exerciseData.name || 'Descanso do treino').slice(0, 200);
          started = {owner, deadline, name, paired};
          current.restUntil = deadline;
          current.apAutoRestSeries = {deadline, exercise, series};
          // The older WebView cue must not play a second end alert.
          current.workoutAudioCue = {version: 1, until: deadline, start: true, end: true};
          primeSound();
        }
      }
      const mark = previous?.apAutoRestSeries;
      if (mark && current?.restUntil === mark.deadline && mark.exercise === exercise && mark.series === series
          && exerciseData && !exChecks(current, exercise, exerciseData.sets)[series]) {
        current.restUntil = 0;
        delete current.apAutoRestSeries;
      }
    }
    const result = save.apply(this, arguments);
    if (result !== true || student() !== owner) return result;
    for (const [plan, previous] of Object.entries(before)) {
      const mark = previous?.apAutoRestSeries;
      if (mark && mark.deadline !== active[plan]?.restUntil) cancel(mark.deadline);
    }
    if (started) {
      activeOwner = owner;
      if (started.paired) app.APWorkoutAudio?.play('pause').catch(() => {});
      clearFallback();
      if (!armNative(started.deadline, started.name)) {
        fallback = started;
        fallbackTimeout = setTimeout(playFallback, Math.max(0, started.deadline - Date.now()));
      }
    }
    return result;
  };

  app.addEventListener('ap-student-ready', () => { activeOwner = student(); });
  app.addEventListener('ap-account-changed', () => {
    const owner = student();
    if (activeOwner && activeOwner !== owner) cancel(0);
    activeOwner = owner;
  });
  app.document.addEventListener('visibilitychange', () => {
    if (app.document.hidden || !fallback) return;
    if (fallback.deadline > Date.now() && student() === fallback.owner
        && armNative(fallback.deadline, fallback.name)) clearFallback();
    else playFallback();
  });
})(window);
