(() => {
  'use strict';
  const pets = [
    ['gato', 'Gato', /\b(?:gat[oa]s?|kittens?|cats?)\b/],
    ['lobo', 'Lobo', /\b(?:lob[oa]s?|wolfs?|wolves)\b/],
    ['urso', 'Urso', /\b(?:urs[oa]s?|ursos?inhos?|bears?)\b/],
    ['capivara', 'Capivara', /\b(?:capivaras?|capybaras?)\b/],
    ['galo', 'Galo', /\b(?:galos?|galinhas?|pintinhos?|chicks?|roosters?)\b/],
    ['peixe', 'Peixe', /\b(?:bettas?|peixes?|aquarios?|fish)\b/],
    ['raposa', 'Raposa', /\b(?:raposas?|raposinhas?|fox|foxes)\b/],
    ['geral', 'Geral', null]
  ];
  const shared = new Set(['student-pet-persistence', 'pet-ios-gestures', 'pet-ios-camera', 'non-bear-reactions',
    'pet-approach', 'pet-paid-colours', 'individual-pet-poses', 'presencial-pet-rewards']);
  const sectionNames = {pets:'Pets', alunos:'Aluno', professor:'Professor', relogio:'Relógio', sons:'Sons e temporizadores',
    evolucao:'Evolução e avaliações', avaliacoes:'Avaliações', agenda:'Agenda', cadastro:'Cadastros e contatos', pagamentos:'Financeiro'};
  const sectionAliases = {alunos:'aluno', cadastro:'cadastros', pagamentos:'financeiro'};
  const get = id => document.getElementById(id);
  const teacher = () => window.APaccounts?.isTeacher?.() === true && !window.__AP_STUDENT_CONTEXT;
  const normalize = text => String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, ' ');
  function petOf(id, title) {
    if (shared.has(id)) return 'geral';
    // The title identifies the pet. Descriptions may cite a different animal as a reference.
    for (const text of [title, id]) {
      const names = pets.filter(([, , pattern]) => pattern?.test(normalize(text)));
      if (names.length) return names.length === 1 ? names[0][0] : 'geral';
    }
    return 'geral';
  }
  function make(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text) node.textContent = text;
    return node;
  }
  const opened = new Set();
  let downloadRequest, downloadStatus, lastList, lastFilter, lastSnapshot;
  function fold(key, title, count, cls) {
    const folder = make('details', cls);
    folder.open = opened.has(key);
    const summary = make('summary');
    summary.append(make('span', 'ap-catalog-title', title), make('small', 'ap-catalog-count', count + (count === 1 ? ' atualização' : ' atualizações')));
    folder.append(summary);
    folder.addEventListener('toggle', () => folder.open ? opened.add(key) : opened.delete(key));
    return folder;
  }
  function readManaged() {
    try {
      const json = window.Android?.getManagedUpdates?.() || '[]';
      const records = JSON.parse(json);
      return {json, records:Array.isArray(records) ? records.filter(item =>
        item && typeof item.title === 'string' && typeof item.version === 'string' &&
        /^[a-z0-9][a-z0-9-]{0,59}$/.test(item.id) && /^[a-f0-9]{64}$/.test(item.signature) &&
        Object.hasOwn(sectionNames, item.area)) : []};
    } catch (_) { return {json:'[]', records:[]}; }
  }
  function button(label, action) {
    const control = make('button', 'ap-catalog-button', label);
    control.type = 'button';
    control.onclick = action;
    return control;
  }
  function managedRow(item) {
    const row = make('article', 'ap-catalog-managed');
    row.dataset.catalogManaged = item.id;
    const title = make('h3', '', item.title);
    const meta = make('p', '', 'Versão ' + item.version + ' · ' + (item.removed ? 'Desinstalada' : 'Instalada'));
    row.append(title);
    if (item.summary) row.append(make('p', '', item.summary));
    row.append(meta);
    const actions = make('div', 'ap-catalog-actions');
    const status = make('p', 'ap-catalog-status');
    status.setAttribute('role', 'status');
    if (item.downloadable) actions.append(button('Baixar arquivo', () => {
      if (!teacher()) return;
      const request = 'patch-download-' + Date.now();
      if (window.Android.downloadUpdate(item.downloadId, item.signature, request) === true) {
        downloadRequest = request;
        downloadStatus = status;
        status.textContent = 'Preparando o arquivo…';
      } else status.textContent = 'Aguarde a operação em andamento e tente novamente.';
    }));
    if (item.reversible) actions.append(button('Desinstalar', () => {
      if (teacher()) window.Android.removeManagedUpdate(item.id, item.signature);
    }));
    if (!item.downloadable) status.textContent = 'Arquivo individual indisponível neste aparelho.';
    else if (!item.reversible && !item.removed) status.textContent = 'Reversão individual indisponível.';
    row.append(actions, status);
    return row;
  }
  function prepareMenu() {
    const menu = get('apUpdateModular');
    const label = menu?.querySelector('.ap-update-menu-label') || menu?.lastElementChild;
    if (label?.textContent.trim() === 'Atualizações por área') label.textContent = 'Importar atualização';
    if (menu) menu.onclick = () => {
      if (!teacher()) return;
      if (window.APupdates?.canInstall?.() !== true) {
        get('apUpdateMenuStatus').textContent = 'Finalize o treino ou a edição em andamento antes de instalar.';
        return;
      }
      window.APReleaseCenter?.close();
      window.Android?.openUpdateAction?.('import');
    };
    if (menu && get('apUpdateImport')) get('apUpdateImport').hidden = true;
  }
  function organize() {
    const central = get('apReleaseCenter'), list = get('apReleaseCatalog');
    if (!list || central?.hidden || !teacher()) return;
    const intro = central.querySelector('.ap-release-intro');
    const help = 'Abra uma seção para ver suas atualizações. Em Pets, abra o animal. As ações individuais aparecem quando o arquivo ou a reversão está disponível.';
    if (intro && intro.textContent !== help) intro.textContent = help;
    const oldDownload = get('apReleasePopupDownload');
    if (oldDownload) { oldDownload.disabled = true; if (!oldDownload.hidden) oldDownload.hidden = true; }

    const filter = central.querySelector('[data-release-filter][aria-pressed="true"]')?.dataset.releaseFilter || 'all';
    const {json, records} = readManaged();
    const rendered = list.querySelectorAll('[data-feature-id]');
    const rawRows = Array.from(rendered).some(row => !row.closest('[data-pet-folder]') &&
      (row.closest('[data-release-area="pets"]') || isLegacyPet(row)));
    const replaced = !list.querySelector('[data-catalog-rendered]');
    if (lastList === list && !replaced && !rawRows && filter === lastFilter && json === lastSnapshot) return;
    lastList = list; lastFilter = filter; lastSnapshot = json;
    list.querySelectorAll('[data-catalog-managed],[data-catalog-generated]').forEach(node => node.remove());
    let petArea = list.querySelector('[data-release-area="pets"]');
    const group = new Map(pets.map(([id]) => [id, []]));
    for (const row of rendered) {
      const title = row.querySelector('h3')?.textContent;
      if (row.dataset.featureId.startsWith('installed-') && records.some(item => normalize(item.title) === normalize(title))) {
        row.remove();
        continue;
      }
      if (row.closest('[data-release-area="pets"]') || isLegacyPet(row)) {
        group.get(petOf(row.dataset.featureId, title)).push(row);
      }
    }
    const visible = records.filter(item => filter === 'all' || (filter === 'removed' && item.removed) ||
      (filter === 'active' && item.reversible) || (filter === 'integrated' && !item.removed && !item.reversible));
    for (const item of visible) {
      if (item.area === 'pets') group.get(petOf(item.id, item.title)).unshift(managedRow(item));
      else {
        const key = sectionAliases[item.area] || item.area;
        let area = list.querySelector('[data-release-area="' + key + '"]');
        if (!area) {
          area = fold('area-' + key, sectionNames[item.area], visible.filter(row => row.area === item.area).length, 'ap-release-area ap-catalog-folder');
          area.dataset.releaseArea = key;
          area.dataset.catalogGenerated = '';
          list.append(area);
        }
        (area.querySelector('.ap-release-area-rows') || area).append(managedRow(item));
      }
    }
    const petCount = [...group.values()].reduce((sum, rows) => sum + rows.length, 0);
    if (!petArea?.isConnected && (petCount || filter === 'all')) {
      petArea = fold('area-pets', 'Pets', petCount, 'ap-release-area ap-catalog-folder');
      petArea.dataset.releaseArea = 'pets';
      list.prepend(petArea);
    }
    if (petArea) {
      const body = petArea.querySelector('.ap-release-area-rows') || petArea;
      for (const [id, title] of pets) {
        const rows = group.get(id);
        let folder = body.querySelector('[data-pet-folder="' + id + '"]');
        if (!rows.length && filter !== 'all') { folder?.remove(); continue; }
        if (!folder) {
          folder = fold('pet-' + id, title, rows.length, 'ap-catalog-folder');
          folder.dataset.petFolder = id;
          body.append(folder);
        }
        folder.querySelector('.ap-catalog-count').textContent = rows.length + (rows.length === 1 ? ' atualização' : ' atualizações');
        folder.querySelector('.ap-catalog-empty')?.remove();
        if (rows.length) folder.append(...rows);
        else folder.append(make('p', 'ap-catalog-empty', 'Nenhuma atualização individual registrada.'));
      }
      const count = petArea.querySelector(':scope > summary .ap-release-area-count');
      if (count) { count.textContent = petCount; count.setAttribute('aria-label', petCount + ' atualizações'); }
    }
    const total = get('apReleaseCount');
    if (total && records.length) total.textContent = list.querySelectorAll('[data-feature-id],[data-catalog-managed]').length + ' atualizações neste filtro';
    if (visible.length) list.querySelector('.ap-release-empty')?.remove();
    if (!list.querySelector('[data-catalog-rendered]')) {
      const marker = make('span');
      marker.hidden = true;
      marker.dataset.catalogRendered = '';
      list.append(marker);
    }
  }
  function isLegacyPet(row) {
    if (row.closest('[data-release-area]:not([data-release-area="pets"])')) return false;
    return shared.has(row.dataset.featureId) || petOf(row.dataset.featureId, row.querySelector('h3')?.textContent) !== 'geral';
  }
  window.addEventListener('ap-update-download-result', ({detail}) => {
    if (!teacher() || detail?.requestId !== downloadRequest || !downloadStatus?.isConnected) return;
    const messages = {choosing:'Escolha onde salvar o arquivo.', saving:'Salvando a atualização…',
      saved:'Arquivo salvo.', cancelled:'Download cancelado.', error:detail.message || 'Não foi possível salvar.'};
    downloadStatus.textContent = messages[detail.status] || '';
  });
  document.addEventListener('DOMContentLoaded', () => {
    const style = make('style');
    style.textContent = '#apReleasePopupDownload[hidden],#apUpdateImport[hidden]{display:none!important}'+
      '#apReleaseCatalog .ap-catalog-folder{margin:8px 0;border:1px solid #7776;border-radius:10px}'+
      '#apReleaseCatalog .ap-catalog-folder>summary{display:flex;align-items:center;gap:8px;padding:12px;cursor:pointer;list-style:none}'+
      '#apReleaseCatalog .ap-catalog-folder>summary::-webkit-details-marker{display:none}'+
      '#apReleaseCatalog .ap-catalog-title{font-weight:650;flex:1}'+
      '#apReleaseCatalog .ap-catalog-count{color:inherit;opacity:.8;font-size:.75rem;white-space:nowrap}'+
      '#apReleaseCatalog .ap-catalog-folder>summary::after{content:"›";font-size:1.25rem}'+
      '#apReleaseCatalog .ap-catalog-folder[open]>summary::after{transform:rotate(90deg)}'+
      '#apReleaseCatalog .ap-catalog-managed,#apReleaseCatalog .ap-catalog-empty{padding:12px;margin:0;border-top:1px solid #7775}'+
      '#apReleaseCatalog .ap-catalog-managed h3,#apReleaseCatalog .ap-catalog-managed p{margin:0 0 6px;color:inherit}'+
      '#apReleaseCatalog .ap-catalog-managed h3{font-size:1rem}'+
      '#apReleaseCatalog .ap-catalog-managed p,#apReleaseCatalog .ap-catalog-empty{font-size:.8rem;opacity:.8}'+
      '#apReleaseCatalog .ap-catalog-status:empty,#apReleaseCatalog .ap-catalog-actions:empty{display:none}'+
      '#apReleaseCatalog .ap-catalog-actions{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}'+
      '#apReleaseCatalog .ap-catalog-button{min-height:42px;border:1px solid #7778;border-radius:8px;padding:6px 10px;background:transparent;color:inherit;font:inherit;font-size:.8rem}';
    document.head.append(style);
    let center;
    const watchCenter = new MutationObserver(organize);
    function connect() {
      prepareMenu();
      const current = get('apReleaseCenter');
      if (current === center) return;
      watchCenter.disconnect();
      center = current;
      if (!center) return;
      watchCenter.observe(center, {childList:true, subtree:true, attributes:true, attributeFilter:['hidden','aria-pressed']});
      organize();
    }
    new MutationObserver(connect).observe(document.body, {childList:true});
    connect();
  });
})();
