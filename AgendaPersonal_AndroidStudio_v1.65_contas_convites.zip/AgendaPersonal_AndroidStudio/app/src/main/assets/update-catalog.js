(() => {
  'use strict';
  const pets = [
    ['gato', 'Gato', /\b(?:gat[oa]s?|kittens?|cats?)\b/],
    ['lobo', 'Lobo', /\b(?:lob[oa]s?|wolfs?|wolves)\b/],
    ['capivara', 'Capivara', /\b(?:capivaras?|capybaras?)\b/],
    ['geral', 'Geral', null]
  ];
  const shared = new Set(['student-pet-persistence', 'pet-ios-gestures', 'pet-ios-camera', 'non-bear-reactions',
    'pet-approach', 'pet-paid-colours', 'individual-pet-poses', 'presencial-pet-rewards']);
  const sectionNames = {pets:'Pets', alunos:'Aluno', professor:'Professor', relogio:'Relógio', sons:'Sons e temporizadores',
    evolucao:'Evolução e avaliações', avaliacoes:'Avaliações', agenda:'Agenda', cadastro:'Cadastros e contatos', pagamentos:'Financeiro'};
  const sectionAliases = {alunos:'aluno', cadastro:'cadastros', pagamentos:'financeiro'};
  const legacySections = {
    'student-theme-restored':['alunos','perfil'], 'partial-workout':['alunos','treinos'],
    'shared-workout-audio':['sons','audios'], 'cardio-finish-audio':['sons','cardio'],
    'student-evolution':['evolucao','progresso'], 'student-evolution-sync':['evolucao','sincronizacao'],
    'student-feedback-restored':['evolucao','feedback'], 'feedback-symbol':['evolucao','feedback'],
    'duplicate-video-warning':['professor','exercicios'], 'compact-completed':['professor','exercicios'],
    'auto-rest':['sons','descanso'], 'cardio-timer':['sons','cronometro']
  };
  function readSections() {
    try { return JSON.parse(window.Android?.getUpdateSections?.() || '{}'); }
    catch (_) { return {}; }
  }
  const nativeSections = readSections();
  const sections = Object.fromEntries(Object.keys(sectionNames).map(area => [area,
    Array.isArray(nativeSections[area]) ? nativeSections[area] :
      area === 'pets' ? pets.map(([id, label]) => [id, label, '']) : [['geral','Geral','']]
  ]));
  const areaByKey = new Map(Object.keys(sections).map(area => [sectionAliases[area] || area, area]));
  const get = id => document.getElementById(id);
  const teacher = () => window.APaccounts?.isTeacher?.() === true && !window.__AP_STUDENT_CONTEXT;
  const normalize = text => String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, ' ');
  function petOf(id, title) {
    if (shared.has(id)) return 'geral';
    // The title identifies the pet. Descriptions may cite a different animal as a reference.
    for (const text of [title, id]) {
      const names = pets.filter(([, , pattern]) => pattern?.test(normalize(text)));
      if (names.length) return names.length === 1 ? names[0][0] : 'geral';
    }
    return 'geral';
  }
  function rowLocation(row) {
    const id = row.dataset.featureId;
    if (Object.hasOwn(legacySections, id)) return legacySections[id];
    const key = row.closest('[data-release-area]')?.dataset.releaseArea;
    const area = key ? areaByKey.get(key) : isLegacyPet(row) ? 'pets' : '';
    if (!area) return null;
    return [area, area === 'pets' ? petOf(id, row.querySelector('h3')?.textContent) : 'geral'];
  }
  function make(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text) node.textContent = text;
    return node;
  }
  const opened = new Set();
  let downloadRequest, downloadStatus, downloadSerial = 0, lastList, lastFilter, lastSnapshot;
  function fold(key, title, count, cls) {
    const folder = make('details', cls);
    folder.open = opened.has(key);
    const summary = make('summary');
    summary.append(make('span', 'ap-catalog-title', title), make('small', 'ap-catalog-count', count + (count === 1 ? ' atualização' : ' atualizações')));
    folder.append(summary);
    folder.addEventListener('toggle', () => folder.open ? opened.add(key) : opened.delete(key));
    return folder;
  }
  function readManaged() {
    try {
      const json = window.Android?.getManagedUpdates?.() || '[]';
      const records = JSON.parse(json);
      return {json, records:Array.isArray(records) ? records.filter(item =>
        item && typeof item.title === 'string' && typeof item.version === 'string' &&
        /^[a-z0-9][a-z0-9-]{0,59}$/.test(item.id) && /^[a-f0-9]{64}$/.test(item.signature) &&
        Object.hasOwn(sectionNames, item.area)) : []};
    } catch (_) { return {json:'[]', records:[]}; }
  }
  function button(label, action) {
    const control = make('button', 'ap-catalog-button', label);
    control.type = 'button';
    control.onclick = action;
    return control;
  }
  function managedRow(item, section) {
    const row = make('article', 'ap-catalog-managed');
    row.dataset.catalogManaged = item.id;
    const title = make('h3', '', item.title);
    const state = item.removed ? 'Desinstalada' : 'Instalada';
    const meta = make('p', '', 'Versão ' + item.version + ' · ' + state);
    const options = make('details', 'ap-catalog-options');
    const trigger = make('summary', 'ap-release-more', '⋮');
    trigger.setAttribute('aria-label', 'Opções de ' + item.title);
    const actions = make('div', 'ap-catalog-actions');
    const info = make('div', 'ap-catalog-info');
    info.hidden = true;
    const infoButton = button('Detalhes', () => {
      info.hidden = !info.hidden;
      infoButton.setAttribute('aria-expanded', String(!info.hidden));
    });
    infoButton.setAttribute('aria-expanded', 'false');
    info.append(make('p', '', section), make('p', '', item.summary || 'Este arquivo não trouxe uma descrição.'));
    if (!item.downloadable) info.append(make('p', '', 'A cópia individual do arquivo não está neste aparelho.'));
    if (!item.reversible && !item.removed) info.append(make('p', '', 'A reversão individual não está disponível para esta correção.'));
    const status = make('p', 'ap-catalog-status');
    status.setAttribute('role', 'status');
    const download = button('Baixar arquivo', () => {
      if (!teacher()) return;
      const request = 'patch-download-' + Date.now() + '-' + (++downloadSerial);
      if (window.Android.downloadUpdate(item.downloadId, item.signature, request) === true) {
        downloadRequest = request;
        downloadStatus = status;
        status.textContent = 'Preparando o arquivo…';
      } else status.textContent = 'Aguarde a operação em andamento e tente novamente.';
    });
    download.disabled = !item.downloadable;
    const remove = button('Desinstalar', () => {
      if (teacher()) window.Android.removeManagedUpdate(item.id, item.signature);
    });
    remove.disabled = !item.reversible;
    actions.append(infoButton, download, remove);
    options.append(trigger, actions, info, status);
    row.append(title, meta, options);
    return row;
  }
  function prepareMenu() {
    const menu = get('apUpdateModular');
    const label = menu?.querySelector('.ap-update-menu-label') || menu?.lastElementChild;
    if (label?.textContent.trim() === 'Atualizações por área') label.textContent = 'Importar atualização';
    if (menu) menu.onclick = () => {
      if (!teacher()) return;
      if (window.APupdates?.canInstall?.() !== true) {
        get('apUpdateMenuStatus').textContent = 'Finalize o treino ou a edição em andamento antes de instalar.';
        return;
      }
      window.APReleaseCenter?.close();
      window.Android?.openUpdateAction?.('import');
    };
    if (menu && get('apUpdateImport')) get('apUpdateImport').hidden = true;
  }
  function sectionNodes(area, entries, filter, parent = '') {
    const folders = [];
    for (const [module, label, moduleParent] of sections[area]) {
      if (moduleParent !== parent) continue;
      const rows = entries.get(module);
      const children = sectionNodes(area, entries, filter, module);
      const count = rows.length + children.reduce((sum, entry) => sum + entry.count, 0);
      if (!count && filter !== 'all') continue;
      const folder = fold(area + '-' + module, label, count, 'ap-catalog-folder');
      folder.dataset.catalogModule = module;
      if (area === 'pets') folder.dataset.petFolder = module;
      folder.append(...rows, ...children.map(entry => entry.folder));
      if (!count && !children.length) folder.append(make('p', 'ap-catalog-empty', 'Nenhuma atualização registrada nesta seção.'));
      folders.push({folder, count});
    }
    return folders;
  }
  function organize() {
    const central = get('apReleaseCenter'), list = get('apReleaseCatalog');
    if (!list || central?.hidden || !teacher()) return;
    const intro = central.querySelector('.ap-release-intro');
    const help = 'Abra uma área e escolha a função ou o pet. Use os três pontos de cada item para ver os detalhes e as ações disponíveis.';
    if (intro && intro.textContent !== help) intro.textContent = help;
    const oldDownload = get('apReleasePopupDownload');
    const oldDownloadLabel = oldDownload?.querySelector('span');
    if (oldDownloadLabel && oldDownloadLabel.textContent !== 'Baixar versão em uso') {
      oldDownloadLabel.textContent = 'Baixar versão em uso';
    }

    const filter = central.querySelector('[data-release-filter][aria-pressed="true"]')?.dataset.releaseFilter || 'all';
    const {json, records} = readManaged();
    const rendered = Array.from(list.querySelectorAll('[data-feature-id]'));
    const rawRows = rendered.some(row => !row.closest('[data-catalog-module]') && rowLocation(row));
    if (lastList === list && list.querySelector('[data-catalog-rendered]') && !rawRows && filter === lastFilter && json === lastSnapshot) return;
    lastList = list; lastFilter = filter; lastSnapshot = json;

    const groups = new Map(Object.entries(sections).map(([area, modules]) =>
      [area, new Map(modules.map(([id]) => [id, []]))]));
    for (const row of rendered) {
      const title = normalize(row.querySelector('h3')?.textContent);
      if (row.dataset.featureId.startsWith('installed-') && records.some(item => normalize(item.title) === title ||
        (item.removed && normalize('Desinstalação de ' + item.title) === title))) {
        row.remove();
        continue;
      }
      const location = rowLocation(row);
      if (location) {
        const entries = groups.get(location[0]);
        (entries.get(location[1]) || entries.get('geral')).push(row);
      }
    }
    const visible = records.filter(item => filter === 'all' || (filter === 'removed' && item.removed) ||
      (filter === 'active' && !item.removed && item.reversible) || (filter === 'integrated' && !item.removed && !item.reversible));
    for (const item of visible) {
      const entries = groups.get(item.area);
      const fallback = item.area === 'pets' ? petOf(item.id, item.title) : 'geral';
      const module = entries.has(item.module) ? item.module : fallback;
      const modules = sections[item.area];
      const labels = [sectionNames[item.area]];
      for (let entry = modules.find(([id]) => id === module); entry; entry = modules.find(([id]) => id === entry[2])) {
        labels.push(entry[1]);
      }
      (entries.get(module) || entries.get('geral')).unshift(managedRow(item, [labels[0], ...labels.slice(1).reverse()].join(' → ')));
    }
    list.querySelectorAll('[data-catalog-module],[data-catalog-generated]').forEach(node => node.remove());
    for (const [area, entries] of groups) {
      const children = sectionNodes(area, entries, filter);
      const count = children.reduce((sum, entry) => sum + entry.count, 0);
      const key = sectionAliases[area] || area;
      let container = list.querySelector('[data-release-area="' + key + '"]');
      if (!container && children.length) {
        container = fold('area-' + key, sectionNames[area], count, 'ap-release-area ap-catalog-folder');
        container.dataset.releaseArea = key;
        container.dataset.catalogGenerated = '';
        if (area === 'pets') list.prepend(container); else list.append(container);
      }
      if (!container) continue;
      const body = container.querySelector('.ap-release-area-rows') || container;
      body.append(...children.map(entry => entry.folder));
      const badge = container.querySelector(':scope > summary .ap-release-area-count');
      if (badge) {
        badge.textContent = count;
        badge.setAttribute('aria-label', count + ' atualizações');
      }
      const oldStats = container.querySelector(':scope > summary .ap-release-area-copy small');
      if (oldStats) oldStats.textContent = count === 1 ? '1 atualização' : count + ' atualizações';
    }
    for (const container of list.querySelectorAll('[data-release-area]')) {
      if (!areaByKey.has(container.dataset.releaseArea)) container.hidden = !container.querySelector('[data-feature-id]');
    }
    const total = get('apReleaseCount');
    if (total && records.length) total.textContent = list.querySelectorAll('[data-feature-id],[data-catalog-managed]').length + ' atualizações neste filtro';
    if (list.querySelector('[data-release-area]:not([hidden])')) list.querySelector('.ap-release-empty')?.remove();
    if (!list.querySelector('[data-catalog-rendered]')) {
      const marker = make('span');
      marker.hidden = true;
      marker.dataset.catalogRendered = '';
      list.append(marker);
    }
  }
  function isLegacyPet(row) {
    if (row.closest('[data-release-area]:not([data-release-area="pets"])')) return false;
    return shared.has(row.dataset.featureId) || petOf(row.dataset.featureId, row.querySelector('h3')?.textContent) !== 'geral';
  }
  window.addEventListener('ap-update-download-result', ({detail}) => {
    if (!teacher() || detail?.requestId !== downloadRequest || !downloadStatus?.isConnected) return;
    const messages = {choosing:'Escolha onde salvar o arquivo.', saving:'Salvando a atualização…',
      saved:'Arquivo salvo.', cancelled:'Download cancelado.', error:detail.message || 'Não foi possível salvar.'};
    downloadStatus.textContent = messages[detail.status] || '';
  });
  document.addEventListener('DOMContentLoaded', () => {
    const style = make('style');
    style.textContent = '#apUpdateImport[hidden],#apReleaseCatalog [data-release-area][hidden]{display:none!important}'+
      '#apReleaseCatalog .ap-catalog-folder{margin:8px 0;border:1px solid #7776;border-radius:10px}'+
      '#apReleaseCatalog .ap-catalog-folder>summary{display:flex;align-items:center;gap:8px;padding:12px;cursor:pointer;list-style:none}'+
      '#apReleaseCatalog .ap-catalog-folder>summary::-webkit-details-marker{display:none}'+
      '#apReleaseCatalog .ap-catalog-title{font-weight:650;flex:1}'+
      '#apReleaseCatalog .ap-catalog-count{color:inherit;opacity:.8;font-size:.75rem;white-space:nowrap}'+
      '#apReleaseCatalog .ap-catalog-folder>summary::after{content:"›";font-size:1.25rem}'+
      '#apReleaseCatalog .ap-catalog-folder[open]>summary::after{transform:rotate(90deg)}'+
      '#apReleaseCatalog .ap-catalog-managed,#apReleaseCatalog .ap-catalog-empty{padding:12px;margin:0;border-top:1px solid #7775}'+
      '#apReleaseCatalog .ap-catalog-managed h3,#apReleaseCatalog .ap-catalog-managed p{margin:0 0 6px;color:inherit}'+
      '#apReleaseCatalog .ap-catalog-managed{position:relative;padding-right:60px}'+
      '#apReleaseCatalog .ap-catalog-managed h3{font-size:1rem}'+
      '#apReleaseCatalog .ap-catalog-options>summary{position:absolute;right:10px;top:9px;display:grid;place-items:center;cursor:pointer;list-style:none}'+
      '#apReleaseCatalog .ap-catalog-options>summary::-webkit-details-marker{display:none}'+
      '#apReleaseCatalog .ap-catalog-options[open]>summary{background:rgba(128,128,128,.18)}'+
      '#apReleaseCatalog .ap-catalog-info[hidden]{display:none!important}'+
      '#apReleaseCatalog .ap-catalog-info{border-left:2px solid #7776;padding-left:10px}'+
      '#apReleaseCatalog .ap-catalog-managed p,#apReleaseCatalog .ap-catalog-empty{font-size:.8rem;opacity:.8}'+
      '#apReleaseCatalog .ap-catalog-status:empty,#apReleaseCatalog .ap-catalog-actions:empty{display:none}'+
      '#apReleaseCatalog .ap-catalog-actions{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}'+
      '#apReleaseCatalog .ap-catalog-button{min-height:42px;border:1px solid #7778;border-radius:8px;padding:6px 10px;background:transparent;color:inherit;font:inherit;font-size:.8rem}'+
      '#apReleaseCatalog .ap-catalog-button:disabled{opacity:.52}';
    document.head.append(style);
    let center;
    const watchCenter = new MutationObserver(organize);
    function connect() {
      prepareMenu();
      const current = get('apReleaseCenter');
      if (current === center) return;
      watchCenter.disconnect();
      center = current;
      if (!center) return;
      watchCenter.observe(center, {childList:true, subtree:true, attributes:true, attributeFilter:['hidden','aria-pressed']});
      organize();
    }
    new MutationObserver(connect).observe(document.body, {childList:true});
    connect();
  });
})();
