# Reações das poses dos vídeos — 1.12.145 / sequência 251

Correção direcionada aos vídeos `1000045252.mp4` e `1000045254.mp4`: urso adulto preto na pose original de quatro patas e na pose “De ladinho”.

Olhar com contornos de olhos calibrados para cada retrato, deslocamento independente das íris e uma inclinação pequena da cabeça que começa depois do olhar. Um toque provoca curiosidade. Orelha e nariz têm respostas locais distintas. O toque duplo produz incômodo por descida das pálpebras usando a própria textura do retrato; a boca não é apagada, preenchida ou redesenhada. A pata que sustenta o rosto na pose de lado continua apoiada. As reações terminam na arte original.

O caminho do carinho foi mantido integralmente: o novo controlador encaminha `affection` para a função anterior sem alterar seus argumentos. Os arquivos `bear-pose-motion.js`, `mascot-petting.js`, `approved-bear-motion.js` e `approved-bear-attention.js` são idênticos aos da 1.12.144. Corações, expressões de carinho e gesto de arrastar não foram refeitos. As outras fases, pelagens e poses usam os controladores existentes. A pose de barriga para cima continua removida.

Conferência no Chromium local com telas reais de professor e aluno, autenticação simulada e rede externa bloqueada: olhar, curiosidade, orelha, nariz e incômodo, suporte imóvel, retorno neutro, preservação dos dados e carinho por toque real. Há caminhos WebGL e Canvas; a execução sem WebGL é conferida separadamente. Não foi realizado teste físico em Android ou iPhone nesta entrega.

Atualização de conteúdo com bridgeVersion 3, dataSchema 4, Android 1.158. O `.agenda.json` é o arquivo para subir no próprio aplicativo. A geração deste pacote não publica uma versão no servidor.
