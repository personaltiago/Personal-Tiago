# Tamanho dos pets por fase — 1.12.116

Filhote: 70% do tamanho atual. Adolescente: 85%. Adulto: 100%, preservando o tamanho anterior.

A escala é proporcional e ancorada na base do retrato para manter o pet no chão. Vale para todos os seis animais, no início do professor, no início do aluno e no painel do pet. A pontinha da fala acompanha a nova posição da boca. O lobo adulto continua invertido conforme o modelo aprovado.

Imagens, regras de XP (600 e 1800), moedas, itens, registros e demais dados permanecem intactos. Balão arredondado com texto sempre visível preservado.

Conteúdo 1.12.116, sequência 222, base Android 1.157. Atualização normal, sem necessidade de reinstalar para essa mudança.
