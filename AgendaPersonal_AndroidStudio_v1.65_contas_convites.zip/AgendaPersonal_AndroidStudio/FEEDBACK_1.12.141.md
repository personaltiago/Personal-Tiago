# Feedback sem bloquear o mascote — 1.12.141 / sequência 247

O pedido de feedback fica em um botão abaixo do cenário, sem interceptar o toque no pet. A resposta salva na fila deixa de ser tratada como falta de resposta; continua guardada até o servidor confirmar. O histórico, a confirmação e a proteção contra consultas antigas permanecem. Outra solicitação ainda não respondida continua visível.

A capivara de prévia também reage ao toque, sem selecionar o mascote no lugar da aluna. As artes e o carinho do urso da versão 1.12.140 foram preservados.

Verificação: recibo, fila offline, quota, isolamento por conta e consulta antiga em testes automatizados; cliente e Worker reais com identidades simuladas; prévia do navegador com dados fictícios. Sem teste físico neste iPhone e sem acesso aos feedbacks da aluna.
