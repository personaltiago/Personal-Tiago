# Pets voltados para o balão — 1.12.118

Corrige o sentido dos retratos que estavam voltados para a esquerda ou com a cabeça no lado oposto ao balão: gato adolescente/adulto; lobo adulto; capivara filhote/adolescente; panda adolescente/adulto; galo adolescente/adulto; jacaré adolescente/adulto. As demais imagens mantêm a orientação.

A ponta da fala acompanha a boca após a inversão. Somente o retrato é espelhado, preservando textos, cenário, nome e botão Casa. A mesma orientação vale no primeiro carregamento, no retrato em cache e nas telas do professor/aluno.

Três tamanhos mantidos: filhote 70%, adolescente 85%, adulto 100% do tamanho anterior, apoiados na mesma base. Progresso, XP, moedas, itens e registros preservados.

Conteúdo 1.12.118, sequência 224, base Android 1.157. Compatível com atualização normal. ZIP no nome padrão.
