# Balão de fala arredondado — 1.12.115

O texto do recado permanece sempre visível dentro do balão no cenário do professor e do aluno. O balão tem cantos de 50 px, texto centralizado e largura limitada a 184 px no celular. A altura acompanha o conteúdo sem truncar palavras. O nome do pet continua visível.

Remove integralmente o botão de abrir recado, a janela de leitura e a alteração de navegação introduzidos em 1.12.114. Casa, mensagens, itens, progresso e registros continuam preservados.

Conteúdo 1.12.115, sequência 221, base Android 1.157. Pode ser aplicado pela atualização normal.
