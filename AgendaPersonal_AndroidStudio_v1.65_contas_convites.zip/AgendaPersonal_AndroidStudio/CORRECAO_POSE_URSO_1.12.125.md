# Correção da pose do urso — conteúdo 1.12.125 / sequência 231

A pose Barriga para cima do panda/urso foi corrigida nas seis pelagens e nas três fases: 18 sprites. Foi removida a saliência lateral atrás da pata traseira que parecia uma cauda comprida ou um quinto membro. A pose mantém quatro patas definidas, barriga para cima e a mesma identidade visual. A cauda curta fica encoberta pelo corpo nessa posição.

O identificador panda/play e os nomes de arquivo são os mesmos. A seleção e a compra existentes continuam válidas; não há nova cobrança. A escolha de cor, a fase, as moedas, o XP, os dados dos alunos, os treinos e os backups não mudaram de formato. As outras poses e os outros animais não foram redesenhados. A remoção da aba Cuidar da versão 1.12.124 foi mantida.

Os 18 sprites finais estão em web/mascot-poses/panda-play-*.webp, com transparência e 240 × 240 pixels. O manifest.json conserva a verificação SHA-256 e as âncoras do balão para cada desenho. A edição do atlas foi feita com a ferramenta integrada de imagens. O prompt e a referência do atlas estão em web/mascot-poses/PROMPTS.md. Uma prévia isolada da orelha canela que alterou a contagem de patas foi descartada e não integra o pacote.

Importe AgendaPersonal-1.12.125.agenda.json no fluxo normal de atualização do app. Não é necessário compilar um APK nem desinstalar. O código completo mantém o nome padrão AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip e a base Android 1.157.

Validação: conferência visual dos recortes e da anatomia; integridade das imagens, carregamento e seleção da pose nas interfaces de professor e aluno, fases de crescimento, posição do balão, compra única e persistência. Navegador local com serviços externos simulados; não foi gerado um novo APK.
