# Atalho da aba Ativas — conteúdo 1.12.113

Sequência 219. Atualização normal `.agenda.json`, mantendo a correção dos cronômetros da versão 1.12.112.

O botão **Ativas** passa a abrir o treino em andamento do aluno exibido. Se houver vários em andamento, prioriza aquele que estava aberto; sem essa referência, usa o iniciado mais recentemente. A busca considera todas as fichas ativas desse aluno.

Sem treino em andamento, retorna ao último treino aberto daquele aluno durante a sessão do aplicativo. Sem referência anterior, abre diretamente um treino único ou posiciona a tela na lista de treinos para a escolha, quando houver vários. Fichas arquivadas, inclusive automaticamente, e treinos excluídos não são destinos válidos. A preferência de navegação é separada por aluno e guardada somente na sessão; não altera o banco de alunos, cargas ou resultados.

O número ao lado de Ativas continua contando **fichas ativas**, como antes. A aba Arquivadas e os controles de edição mantêm seu funcionamento. O atalho abre a execução existente sem iniciar, reiniciar ou concluir o treino.

Verificado na página final em Chromium com API Android simulada: treino em outra ficha ativa, retorno da aba Arquivadas, último treino, alunos diferentes com IDs de dias iguais, recarga, ficha arquivada, dia excluído, ausência de ficha ativa, treino único, múltiplas sessões e erro de gravação da preferência. Conferidos registros anteriores, ausência de chamadas de início de cronômetro e ausência de alterações no banco durante a navegação de um treino parado.

Importar `AgendaPersonal-1.12.113.agenda.json` em **Mais → Atualizações**. Não requer outro APK.
