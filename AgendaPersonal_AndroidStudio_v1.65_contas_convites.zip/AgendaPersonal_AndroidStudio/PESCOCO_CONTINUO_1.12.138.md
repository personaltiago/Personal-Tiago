# Conteúdo 1.12.138 / sequência 244

O vídeo 1000044205.mp4 mostra o panda com um recorte no lado do pescoço
durante o olhar: as máscaras da cabeça e do corpo abriam uma fenda quando
as duas cópias da imagem se afastavam. A inclinação também era excessiva.

A curiosidade, o nariz, a orelha e o olhar agora usam uma única textura sobre
uma malha contínua. A cabeça e o pescoço permanecem conectados. A rotação
se reduz gradualmente até zero antes do tronco inferior; todos os vértices
abaixo de 80% da imagem ficam fixos. O movimento varia com o espaço de
pescoço disponível; o jacaré de barriga para cima tem deslocamento menor
para preservar a patinha que fica perto da cabeça. Nenhuma arte foi trocada.

O renderizador principal usa WebGL e dispõe de alternativa Canvas 2D sem
dependências adicionais. Os recursos e a animação são liberados ao terminar,
cancelar, trocar de conta ou ocultar a página. Uma textura que acaba de
carregar depois do cancelamento não reinsere uma reação antiga. O movimento
reduzido exibe uma resposta estática. A transição entre alvos começa na mesma
posição renderizada e a pose escolhida volta ao final.

Carinho, protesto, patas levantadas, cenário, botão Casa e dados do aplicativo
permanecem com as funções existentes. Sem migração de dados ou novo APK.

Verificações: malhas das 72 combinações de espécie, fase e pose, com áreas
de triângulos de 0,521 a 1,475 do original, sem inversões ou colapsos; pixels
das patas e geometria do cenário; professor e aluno; retorno da pose e dados
salvos; transição entre alvos; movimento reduzido; cancelamento de textura;
alternativa Canvas 2D; contatos reais simulados por CDP; pacote normal e
compatibilidade com o publicador. Os testes visuais são locais em Chromium.
Nenhuma versão externa foi publicada e nenhum APK novo foi compilado.
