# Adultos maiores · conteúdo 1.12.121 / sequência 227

Os adultos dos seis animais ficam 18% maiores no habitat do painel (professor e aluno), na visualização principal do pet e no recado após concluir o treino. A imagem mantém sua proporção e seu arquivo original completo. O espaço do retrato aumenta; a imagem não recebe um zoom que corte o animal.

No painel, o espaço passa de 88 para 103,84 px em telas até 360 px; de 112 para 132,16 px no tamanho móvel padrão; de 128 para 151,04 px no tamanho amplo. No painel principal do pet, a largura máxima passa de 220 para 259,6 px e respeita o espaço disponível em telas menores. Filhotes e adolescentes mantêm os tamanhos anteriores. As miniaturas de escolha continuam ajustadas aos seus cartões.

O balão aprovado continua acima da cabeça. O cálculo existente reserva espaço para o retrato maior, preservando a ponta curta e o texto completo. As seis opções de cor, orientação de cada animal, nome, casa, XP, moedas, histórico e itens anteriores continuam iguais. Não há mudança no registro do mascote nem migração de dados.

Aplicar AgendaPersonal-1.12.121.agenda.json pela atualização normal. Fonte completa no nome padrão AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip. Base Android 1.157; sem nova função nativa.

Validação local em Chromium: seis espécies, três fases, professor e aluno em 320/390/480 px, tamanho dos adultos +18%, retratos dentro do cenário, balão e texto completos, cores e estado preservados. Autenticação e rede simuladas; não houve teste em aparelho físico ou publicação externa.
