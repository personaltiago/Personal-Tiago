# Carinho no pet e acesso pela casinha — 1.12.128 / sequência 234

No painel de professor e aluno, tocar no animal faz carinho. O pet mostra uma expressão de olhos fechados, cabeça ligeiramente erguida e satisfação, com um coração pequeno. A reação dura cerca de 1,6 segundo e depois restaura a pose escolhida. Toques repetidos renovam a reação; corações visíveis são limitados a três. O gesto não compra itens, não concede recompensas e não modifica moedas, XP, metas, treinos, progresso, cores, poses ou outros registros.

Tocar no fundo do cenário, no nome ou no balão não abre a personalização. O botão Casa continua abrindo a janela do pet na aba Casa, com acesso às abas Cores, Loja e Histórico. O comando explícito Pet do menu permanece disponível para que seja possível reativar um pet oculto. Avisos de treino e ações explícitas de feedback mantêm sua função.

As 96 expressões de carinho cobrem seis espécies, 32 pelagens e três fases. São novos recortes 3D transparentes de 240 × 240; a reação não usa um filtro que troque a cor do animal. A posição de carinho é temporária e mantém a pelagem e a fase; a pose comprada continua selecionada. A representação normal, inclusive o urso aprovado com quatro patas e os adultos maiores da 1.12.127, foi mantida.

A interação aceita toque/clique e teclado. Os eventos de ponteiro são passivos e não capturam o gesto, preservando a rolagem vertical. O elemento de imagem tocado é mantido durante a reação para não interromper os movimentos do ponteiro. A preferência de redução de movimento desativa o balanço e o deslocamento do coração. Trocar de conta, ocultar o aplicativo ou abrir a personalização cancela a reação.

## Imagens e tamanho do pacote

Os 288 sprites de poses existentes não foram alterados. Para acomodar as expressões sem exigir um APK novo, foi compactado apenas o canal de transparência de 99 retratos/pelagens existentes. Os blocos VP8 de cor e os perfis de cor permanecem byte a byte idênticos; todos os pixels opacos decodificados foram comparados e permanecem iguais. A transparência inferior a 24 foi descartada e os demais valores suaves foram arredondados em passos de oito. Foram economizados 1.075.340 bytes. Os hashes e os resultados estão em web/mascot-alpha-optimization.json.

Não houve recompressão da cor dessas imagens, alteração de dimensões ou substituição dos ícones e do logotipo. As fontes dos dois controladores isolados do relógio continuam legíveis; no HTML de entrada foram encurtados somente seus identificadores locais, sem otimizar instruções nem alterar propriedades públicas, para manter o limite de 2 MiB do aplicativo instalado.

As novas expressões foram editadas pela ferramenta integrada de imagens; os prompts e as referências estão em web/mascot-affection/PROMPTS.md. Os testes locais verificam os 96 arquivos contra seus hashes, gestos reais para professor/aluno, restauração de pose, limitação de corações, teclado, redução de movimento, cancelamento ao trocar conta e ausência de gravação de dados durante o carinho. Serviços externos e autenticação são simulados.

Importe AgendaPersonal-1.12.128.agenda.json pelo fluxo normal do app. O arquivo já inclui as correções anteriores. Não requer compilar outro APK nem desinstalar. O código completo conserva o nome padrão AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip e a base Android 1.157.
