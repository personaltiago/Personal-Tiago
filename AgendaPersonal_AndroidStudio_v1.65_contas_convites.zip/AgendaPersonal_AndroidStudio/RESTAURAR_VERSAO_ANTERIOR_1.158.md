# Restauração de versão — Android 1.158

## Correção

A consulta da central usava a mesma trava e a mesma fila da restauração local. Enquanto a consulta demorava ou aguardava a rede, tocar em Restaurar versão anterior era ignorado sem aviso. As consultas agora têm uma fila própria; a restauração funciona sem depender da conexão. Durante outra instalação ou restauração, os botões ficam desabilitados.

Um histórico ausente, corrompido ou igual à versão atual volta às páginas verificadas incluídas no APK. A troca guarda um diário contendo somente o código da versão atual. O aplicativo anuncia a restauração apenas quando a página de destino confirma a abertura; se falhar ou for interrompido, recupera o código atual.

A restauração manual não carrega backups antigos dos alunos e não apaga localStorage. Os cadastros, fichas, cargas, progressos, links, moedas e históricos atuais são preservados. A restauração automática de uma instalação que falhou continua separada.

## Aplicação

Esta correção é Java nativo. Arquivos .agenda.json substituem apenas as páginas; não conseguem corrigir o gerenciador de atualizações de um APK instalado.

Substitua o ZIP da raiz de personaltiago/Personal-Tiago pelo arquivo de mesmo nome, AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip. Execute Actions → Gerar e publicar APK Agenda Personal → Run workflow. O workflow já existente compila com a assinatura guardada e usa ANDROID_VERSION_CODE=1000+GITHUB_RUN_NUMBER, maior nas próximas execuções. A versão Android será 1.158.

Instale o APK resultante por cima do atual, com a mesma assinatura. Não desinstale nem limpe os dados do aplicativo.

O projeto atual inclui o conteúdo 1.12.138 / sequência 244, com carinho suave, cenário estável e sem o quadrado azul. O retorno retira uma atualização de conteúdo instalada sobre a base do APK; não desinstala o próprio APK nem troca sua assinatura. Se o conteúdo já estiver incluído no APK, o botão fica desabilitado até existir uma atualização de conteúdo para retirar.

## Validação

Verificação de código Java executável com APIs Android simuladas: toque real nos controles de restauração, consulta pendente/offline, histórico válido/ausente/corrompido/duplicado, confirmação após a abertura, recuperação após falha e interrupção e falha ao gravar preferências. Também executadas as regressões de carregamento, importação, confirmação e recuperação. A compilação completa e a assinatura do APK devem ser feitas pelo workflow; não foram simuladas como concluídas.
