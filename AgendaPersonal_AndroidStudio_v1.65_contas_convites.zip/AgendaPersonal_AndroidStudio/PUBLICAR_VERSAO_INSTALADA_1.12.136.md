# Conteúdo 1.12.136 / sequência 242

O Android serializa cada barra como `\/` ao exportar o pacote instalado.
O pacote 1.12.135 tem 25.158.621 bytes no arquivo normal, mas 25.537.328
bytes nessa representação. A central media esse texto antes de ler o JSON
e recusava uma atualização válida pelo limite de 24 MiB (25.165.824 bytes).

Agora a opção “Usar a versão deste aparelho” lê o JSON e o serializa sem
escapes dispensáveis antes de medir e selecionar o pacote. As quatro páginas
ficam idênticas, o limite permanece e os dados de alunos, contas e mascotes
não participam da exportação. A seleção de arquivo mantém seus controles.
Falhas de leitura, formato, compatibilidade e tamanho têm mensagens próprias.
Não publica automaticamente: o professor revisa e toca no botão de publicar.

Instalar este arquivo pela tela nativa Mais → Atualizações → importar arquivo.
Na central de publicação antiga, escolher diretamente o arquivo .agenda.json
também permite selecionar a correção. Depois da instalação, a opção de usar
a versão do aparelho já inclui a leitura corrigida. APK 1.158 mantido.

Verificação: reprodução da recusa antiga e teste Chromium com o pacote real,
exportação Android simulada com barras escapadas, envio exato das quatro
páginas, confirmação de tamanho/hash/versão, rejeição de pacote realmente
grande e incompatível, erro vazio/malformado e fechamento durante preparo.
Servidor e autenticação simulados; nenhuma publicação externa realizada.
