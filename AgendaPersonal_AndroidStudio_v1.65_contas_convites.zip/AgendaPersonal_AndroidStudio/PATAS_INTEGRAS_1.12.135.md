# Patas íntegras na reação — conteúdo 1.12.135 / sequência 241

O vídeo enviado mostrou uma faixa na base das patas e a mistura entre os pés da pose em pé e os da pose de protesto. A resposta anterior processava a imagem inteira por um filtro e sobrepunha as duas poses na entrada e na saída.

## Alteração

- Retirado o filtro de deslocamento da resposta de protesto e a sobreposição por opacidade entre as poses.
- O protesto mantém a arte completa com a patinha ou asa levantada por 1,05 segundo e retorna à pose escolhida. A pose de protesto fica estável; não há recorte nem deformação da pata levantada.
- As patas apoiadas permanecem intactas durante essa pose. A reação usa uma única imagem completa por vez.
- Corrigidas as 18 artes de reação do gato: seis pelagens naturais nas três fases. As demais 561 imagens anteriores permanecem byte a byte intactas.
- A curiosidade e os movimentos de cabeça da versão 1.12.134 foram preservados. O carinho, o rabinho, os dois toques e os gestos de acessibilidade mantêm seus acionamentos.

Nenhuma compra, moeda, XP, ficha, progresso, treino, link ou dado do aluno é migrado ou apagado. As poses escolhidas e as pelagens mantêm os mesmos identificadores. Esta entrega é um pacote de conteúdo normal; mantém o projeto Android 1.158 e não exige um APK novo para a correção.

## Arte e reprodução

Edição realizada com a ferramenta de imagens integrada, usando como referência o atlas das reações existentes. Os arquivos finais são `web/mascot-reactions/kitten-*-*.webp`; o prompt integral e os parâmetros estão em `web/mascot-reactions/PROMPTS.md`. A geração mantém o mesmo personagem, a pata levantada, as pelagens e as três idades, com correção dos apoios inferiores.

## Verificação

- 66 combinações de espécie, idade, pelagem e papel, com 264 quadros renderizados no professor e no aluno.
- Comparação dos pixels das patas e da imagem completa com a mesma arte sem filtro: sem corte ou deslocamento durante a reação.
- Ausência de duas poses sobrepostas, filtros de deslocamento e animações de opacidade no protesto; retorno à pose original e dados preservados.
- Toques reais por CDP, um e dois contatos, eventos duplicados, rabinho, pressão longa, cancelamento e atualização do cartão.
- Contatos independentes em caudas, asas e corpo; regressões das áreas de toque e integridade das imagens.
- Inventário, contrato do importador e limites de tamanho do pacote de atualização.

Os quadros foram conferidos em Chromium local, com autenticação e rede simuladas. O vídeo original foi analisado localmente; não foi alterado nem incorporado ao aplicativo.
