# Agenda Personal no relógio — primeira versão

Android 1.151 / conteúdo 1.12.86 / sequência 192. Projeto cumulativo: preserva os recursos anteriores do aplicativo.

Destino: relógios com **Wear OS 3 ou superior**, Google Play Services e um celular Android pareado. Relógios vendidos apenas como “compatíveis com Android” podem usar outro sistema. Não há confirmação de suporte do P71J/Pubu Wear. Não há aplicativo publicado na Play Store nesta entrega.

## Conexão pela aba Mais

Abra Mais → Smartwatch. Escolha o aplicativo de conexão indicado pelo fabricante e toque em Abrir conexão do relógio. Samsung abre Galaxy Wearable; Wear OS by Google abre o aplicativo homônimo, quando instalado. Outro fabricante abre ajustes Bluetooth: conclua a configuração no aplicativo oficial indicado pelo modelo. Nenhuma dessas ações confirma pareamento automaticamente. Ao voltar, Verificar conexão consulta os nós Wear OS e a capacidade anunciada pelo Agenda Personal no relógio (APK 1.151 ou superior). A presença de um nó sozinho não confirma a instalação do aplicativo. Modelos apenas compatíveis com celulares Android, como os anúncios W11 Pro enviados sem indicação de Wear OS, não estão confirmados para este APK.

## O que está implementado

No aluno, abra a ficha e a lista de exercícios. No professor, abra o dia de treino de um aluno. Ambos têm um **ícone compacto de smartwatch junto ao título**, no início do treino. Um toque inicia o envio, sem janela adicional de confirmação. No professor, conexão e resultados ficam em **Mais → Smartwatch**. O cronômetro flutuante do intervalo é independente desse envio. Uma execução já iniciada naquele treino no celular deve ser encerrada antes do envio.

O envio só é confirmado quando o aplicativo do relógio responde. Com o treino recebido, abra Agenda Personal no relógio e toque em **Iniciar treino**. O relógio mostra o exercício, a série, repetições/carga prescritas e o descanso. Pode concluir séries, pular descanso, pausar/retomar e encerrar com registro parcial ou completo. Bi-sets seguem A → B → descanso, rodada por rodada. Até 80 exercícios, 30 séries por exercício e 1800 s de intervalo.

O treino recebido e suas marcações ficam salvos no relógio. Não depende de uma WebView no celular aberta durante a execução. O cronômetro usa tempo monotônico, sem depender do ajuste do relógio do sistema. Após reiniciar o dispositivo, recupera a sessão pausada no último ponto salvo. Há uma notificação de treino em andamento para voltar à sessão. A vibração de término do descanso depende do comportamento do aparelho em segundo plano e ainda precisa de teste no modelo real.

O resumo volta ao celular pelo Data Layer quando os aparelhos se reconectam. É deduplicado por sessão, pertence à conta que enviou e aparece em Resultados do relógio. Em **Resultados do relógio → Incluir no histórico**, o professor confirma o aluno, por seleção explícita do cadastro. O resultado aparece em **Histórico de sessões**, com origem Smartwatch, tempo e contagem de séries; o token evita duplicação. A inclusão não gera cargas medidas nem preenche os gráficos com a prescrição. No aplicativo do aluno, os resumos incluídos ficam neste aparelho e não são enviados automaticamente ao professor pelo serviço remoto nesta entrega. As séries marcadas indicam confirmação manual; o relógio não mede carga/repetições nem registra sensores, frequência cardíaca ou calorias. Para repetir o treino, envie uma nova sessão.

Trocar/sair da conta no celular envia uma revogação, aplicada ao reconectar o relógio. Enquanto desconectado, a cópia já recebida permanece local. Um novo treino não substitui uma sessão em andamento: encerre-a e reenvie. Os limites locais são 20 resumos recentes no relógio e 100 no celular.

## Compilar preservando a assinatura atual

Use **o mesmo Codespaces/keystore que gera o APK atualmente instalado**. O app do celular e o do relógio precisam do mesmo pacote e certificado. Não desinstale o app do celular para trocar a assinatura, pois isso pode apagar dados locais. Nenhuma chave de assinatura é incluída no ZIP.

O ZIP mantém o nome usado no repositório:
`AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip`

Na raiz do Codespaces, com esse ZIP atualizado:

```bash
unzip -oq AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip -d projeto-1.151
bash projeto-1.151/AgendaPersonal_AndroidStudio/COMPILAR_COM_RELOGIO.sh
```

O script compila, verifica pacote/versão/assinaturas e disponibiliza:

- `AgendaPersonal-v1.151.apk` — celular.
- `AgendaPersonal-WearOS-v1.151.apk` — relógio.

O APK do relógio é instalado **no relógio**, via ADB/Android Studio. Não é instalado tocando no arquivo no celular. A instalação na Play Store requer um processo de publicação separado. Uma atualização `.agenda.json` não instala este módulo nativo; por isso esta entrega é o projeto completo para compilar os dois aplicativos.

## Conferência técnica

Testes de contrato e cronômetro: `gradle :wear:testDebugUnitTest`.
Modelo de envio: `node tools/test_watch_model.cjs`.
Navegador: `AGENDA_CHROMIUM=/caminho/chromium node tests/verify_watch_workout.cjs`.
Compilação e validação de APKs: `bash COMPILAR_COM_RELOGIO.sh`.

Ainda não testado em smartwatch físico. Pareamento real, consumo de bateria, vibração com tela apagada, uso de coroa/botões e comportamento do sistema do modelo comprado fazem parte da validação no aparelho. Esta versão não promete controlar o app nativo de treino de outro fabricante.
