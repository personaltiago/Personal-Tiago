# Correção da conferência de publicação — Android 1.157

O GitHub Actions concluiu `:app:assembleRelease` com `BUILD SUCCESSFUL`, mas a etapa seguinte rejeitou o APK. O verificador ainda exigia o texto `showLessonTimerOverlay` na tela do professor. Essa chamada foi retirada junto com a faixa de aula, conforme a alteração aprovada. A tela atual contém zero ocorrências dela.

`tools/verify_apk.py` passa a exigir os marcadores do intervalo compacto, incluindo controles de arrastar, abrir e fechar. Também rejeita a chamada antiga, a faixa anterior de intervalo e a antiga faixa de aula. A conferência de financeiro, agenda semanal, quatro telas, bytes, hashes, identidade de fontes, versão Android, permissão, serviço nativo e assinatura permanece ativa. As mensagens identificam o marcador que faltou ou reapareceu.

`tests/verify_apk_checks.py` usa as quatro telas geradas reais em um ZIP de teste e simula somente as ferramentas de inspeção do SDK. O teste confirma a aceitação do conteúdo atual e do versionCode usado pelo CI, além da rejeição de telas alteradas/ausentes, recursos ausentes, faixas retiradas reintroduzidas, identidade/versão incorreta e serviço/permissão ausentes. O ZIP de teste não é um APK instalável e não é distribuído.

A falha anterior foi reproduzida com o verificador original e as telas atuais antes da correção. A versão Android permanece 1.157, o conteúdo 1.12.111 e a sequência 217: a correção é do processo de verificação; não altera as telas nem os dados do usuário.

Para publicar, substituir o ZIP padrão no repositório, confirmar a alteração e iniciar uma **nova execução** por `Run workflow` na branch `main`. Reexecutar o job antigo usa o commit antigo e repete a falha. O arquivo `.agenda.json` anterior permanece idêntico; ele não atualiza o verificador nem o serviço Android.

Limite: a nova compilação assinada e a publicação final devem ser confirmadas no GitHub Actions; os testes locais não substituem a instalação em aparelho.
