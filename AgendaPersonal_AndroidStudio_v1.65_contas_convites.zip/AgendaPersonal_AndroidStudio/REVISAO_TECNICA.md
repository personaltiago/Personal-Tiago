# Revisão do Agenda Personal — 1.123

Conteúdo 1.12.43, sequência 149. Revisão concluída em 18/10/2026.

## Correções

- **Cronômetro da aula:** a configuração clonava uma contagem já existente e comparava a identidade do objeto clonado com a original. A comparação sempre falhava e marcava essa contagem como criada pelo treino. A decisão de reutilizar agora é calculada antes da cópia. O teste com navegador reproduziu o erro antes e confirmou que Parar treino mantém a contagem independente depois da correção.
- **YouTube:** uma substituição usada para incluir TikTok também trocava a mensagem de compatibilidade do YouTube. A mensagem agora considera o provedor correto. Há teste com a ponte antiga e com os dois provedores.
- **Compilação:** origem e destino Java 17 explícitos; mantém o Kotlin BOM e as dependências existentes. O comando do Codespaces verifica a integridade do APK e conclui a cópia por arquivo temporário, sem apresentar uma cópia parcial como arquivo final.
- **Verificações:** testes antigos foram adaptados à entrada integrada, à ficha atual, às séries individuais e à ordenação com confirmação. A importação tem um PDF numerado de teste incluído. O migrador de testes só modifica verificações do professor, preservando a entrada de contas/alunos.

- **Compatibilidade Android:** a classe interna do gesto Voltar já era chamada apenas no Android 13+, mas não declarava esse contrato. A anotação específica de API agora expressa a condição existente, sem desligar a análise. A permissão de alarme tem guarda explícita de versão; as consultas à câmera agora são declaradas no manifesto para Android 11+; o validador de HTML usa `Locale.ROOT`.
- **Fotos do comprovante:** substituído o leitor EXIF antigo da plataforma por `androidx.exifinterface:exifinterface:1.4.2`, mantendo a correção de orientação e as limitações de tamanho. Referência: [Android Developers — Exifinterface](https://developer.android.com/jetpack/androidx/releases/exifinterface).

- **Reconstrução das telas:** incluída a base original imutável em `web/reference/`. `npm run build:assets` regenera as quatro telas com os módulos entregues, sem depender de um arquivo externo de outra conversa. O resultado foi comparado byte a byte com a versão compilada.

## Evidência automatizada

**75 verificações aprovadas, nenhuma falha**, incluindo:

| Área | Cobertura |
| --- | --- |
| Agenda | Recorrências, cancelamentos, conflito real de horário, virada de dia, resumo de domingo a sábado, datas do mês e abertura da aula correta |
| Sons e treino | Três escolhas de áudio e prévias, ponte de alarmes, descanso, contagem reutilizada, séries, bi-set, ordem, retomada e histórico |
| Financeiro | Carteira mensal, centavos, alunos arquivados, recebimentos, revisão manual de Pix, duplicidade, data/valor, falha de armazenamento e vínculo do aluno |
| PDFs | Leitura real de MFit e modelo numerado, instruções do documento, revisão, aluno de destino, rollback e arquivo anexado |
| Vídeos | Links, galerias, janela interna YouTube/TikTok, retorno, foco, prévia e mensagem para APK anterior |
| Contas e apresentação | Separação de alunos, aprovação, cadastro por link, fotos, temas, janelas e layouts de celular |
| Android | Compilação das 27 classes de produção contra APIs reais; testes Java de alarmes, atualização, retorno, som e players |

Os resultados individuais estão em `VERIFICACAO_AUTOMATICA.json`. Nenhum teste usou os dados ativos do seu aparelho.

## Compilação Android completa

`assembleDebug lintDebug` terminou com **BUILD SUCCESSFUL**, usando Gradle 8.9, JDK 17 e plataforma Android 35. O APK de QA tem 60,937,074 bytes, CRC válido, manifesto e DEX presentes. O arquivo foi construído com os mesmos arquivos de produção entregues.

A análise terminou com **0 erros e 33 avisos**. Não foi desligado `abortOnError`, criado baseline para esconder erros nem adicionado um bloqueio geral de diagnósticos. Permanecem sugestões para JavaScript necessário às páginas, orientação retrato escolhida, tradução dos textos, recursos/ícones e guardas antigas de SDK. A gravação síncrona da recuperação de atualização é intencional para garantir que o estado seja gravado antes de continuar.

O APK local é apenas de QA e tem outra assinatura de teste. Compile no seu Codespaces existente para manter a chave de atualização da sua instalação. Não é necessário desinstalar ou limpar os dados.

## Reproduzir as verificações

Use Node.js 22 ou superior, Python 3 e Java 17 ou superior. Em um ambiente de desenvolvimento:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r tests/requirements.txt
npm install
npx playwright install chromium
npm test
```

`AGENDA_CHROMIUM` permite usar um Chromium já instalado. O executador gera um pacote temporário com as quatro telas atuais, roda todos os testes e termina com erro se algum falhar. Registra logs e relatório em uma pasta temporária indicada ao final.

Para repetir a compilação direta das APIs Java, forneça os JARs em `tests/run_all.py --android-jar ... --androidx-jar ... --dependency-dir ...`. Sem esses caminhos, essa verificação específica é marcada como não executada; a compilação Android completa é feita pelo Gradle.

No Codespaces já configurado, compile com `bash COMPILAR_NO_CODESPACES.sh`. A análise Android adicional é `gradle assembleDebug lintDebug`, usando o Gradle 8.9 existente. O arquivo `LEIA_COMPILACAO.txt` contém o comando completo e o nome exato para substituir o ZIP anterior.

## Limites

- Os testes de navegador usam navegador real, com Firebase, ponte Android e mídia remota simulados. Os testes de OCR da tela simulam o retorno nativo; o leitor Java compilou contra as APIs reais, mas o reconhecimento de uma foto em aparelho não foi executado aqui.
- Permissões, alarme com tela apagada, bateria e reprodução real de mídia precisam de verificação no celular.
- A verificação do publicador compara e valida o pacote real. O servidor externo de distribuição não faz parte deste projeto: sua integração não foi executada. O teste informa isso explicitamente e aceita `AGENDA_DISTRIBUTION_WORKER` para quem tiver o código do servidor.
- Testes aprovados cobrem os cenários descritos; não são garantia de ausência de qualquer erro em qualquer dispositivo.
