# Agenda Personal — recados contextuais do mascote, versão 1.131

Conteúdo 1.12.51, sequência 157. Atualização de 19/10/2026.

## Resultado

O cartão existente de aluno e professor mantém o retrato selecionado e a ação que abre cuidados/loja. O texto estático de convite dá lugar a um balão de fala creme, com texto escuro, borda discreta e quebra de linhas. A cor acompanha o fundo dos retratos aprovados. Não há redesenho ou recompressão das imagens. O cartão se adapta a 320, 390 e 480 px e aos temas claro/escuro, sem cortar o recado.

mascot-daily-message.js compõe mensagens locais por papel e estado. Aluno: espera de ficha, treino agendado, sequência sem calendário, descanso em uma ficha semanal, execução ativa e treino completo salvo no dia local. A verificação de conclusão exige incomplete=false, finishedAt numérico no dia local e todas as séries dos exercícios marcadas; não concede recompensa nem regrava a sessão. As mensagens variam de forma determinística por dia e conta.

Professor: teacher-mascot-day.js reutiliza occurrences/statusOf da agenda para obter somente total não cancelado, quantidade realizada e próximo/atual horário. O resumo não transfere nomes ou fichas dos alunos ao componente. Uma aula dentro do intervalo é descrita como prevista, sem inferir presença. Depois do último horário, pendências não são anunciadas como concluídas. Um dia livre sugere uma pausa sem classificar automaticamente o dia inteiro como descanso.

O cartão é atualizado na renderização habitual, ao alterar a agenda, no retorno à página e a cada minuto com o aplicativo visível. A composição é local, sem rede, APIs externas, conversa livre ou custos de geração. Os registros e preferências do mascote continuam separados por conta.

## Validação

verify_mascot_daily_message.cjs usa navegador real e relógio controlado em America/Cuiaba. Abrange agenda com três aulas não canceladas e uma cancelada, recorrência semanal, aula atual, próxima aula, fim dos horários sem confirmação, conclusão real na agenda, dia livre, textos do aluno por estado, execução incompleta, séries não concluídas, dia anterior em UTC/data local, transição automática para o dia seguinte pelo temporizador e troca de conta. Verifica 12 combinações de largura/tema, retratos selecionados, a abertura da tela de cuidados e ausência de alterações nos registros. As capturas de revisão permanecem apenas no ambiente de teste.

A suíte completa e seus limites ficam em VERIFICACAO_AUTOMATICA.json. Autenticação, rede e serviços nativos são simulados; não houve acesso a contas reais nem publicação externa. Não foi gerado APK ou lint completo. A compilação Java opcional depende das bibliotecas Android externas e foi identificada separadamente no relatório.

A entrega mantém quatro páginas, bridgeVersion 3/dataSchema 4 e o limite de 2 MiB da entrada. O JSON deve ser aplicado em cada aparelho, diretamente ou pelo publicador já existente; a sincronização de fichas não instala código novo no aparelho do aluno. A mesma atualização inclui a recuperação de orientações de exercícios e os vídeos compartilhados das versões anteriores.

---

Histórico anterior:

# Agenda Personal — orientações em treinos já importados, versão 1.130

Conteúdo 1.12.50, sequência 156. Atualização de 18/10/2026.

## Problema e comportamento

A captura mostra Leg Press Horizontal recolhido. As orientações são exibidas ao expandir o exercício. Além desse estado da interface, o código continha uma interrupção em withWorkoutGuidance para sourceDocumentId/guidanceVersion, que impedia preencher campos vazios de fichas legadas. A montagem de pacotes individuais também usava diretamente os campos originais, sem a resolução de orientações usada na tela do professor.

O novo web/workout-guidance-resolver.js preserva cada campo não vazio e usa, para campos ausentes, o texto original extraído salvo, a execução estruturada/descrição quando disponível, e a orientação correspondente do catálogo. O catálogo é resolvido por vínculo com nome compatível ou por correspondência única do nome completo/aliases normalizados. Itens do aplicativo têm preferência na busca por nome; entradas privadas são usadas quando não existe entrada do app. Ambiguidades e variantes sem correspondência exata ficam sem preenchimento automático. Não há busca por substring, alteração de IDs nem migração das prescrições.

O transformador de prioridade do PDF instala o resolvedor tanto no caminho de visualização/edição quanto na construção do pacote de cada aluno. A publicação inicial já existente repassa os textos ao abrir o painel do professor; não é preciso reimportar o PDF. O estudante atualiza apenas descrição e vídeo de uma sessão ativa cujo exercício conserva ID e nome; o snapshot persistido com ordem, séries, cargas e contador permanece intacto.

## Validação e limites

verify_existing_workout_guidance.cjs reproduz o exercício da captura, com três alunos fictícios: importação antiga sem vínculo e com guidanceVersion, ficha com texto parcial e ID antigo, e ficha com orientação individual completa. Verifica resolução independente dos campos, sourceNotes/sourceObservations, descrição estruturada, homônimos, vínculo explícito, variante inexistente, catálogo privado, abertura real do cartão e editor do professor, pacotes publicados na inicialização e descrição real da área do aluno durante treino iniciado. Compara a sessão e todas as prescrições antes/depois, incluindo carga 37,5 e série concluída.

A suíte completa e os detalhes de execução ficam em VERIFICACAO_AUTOMATICA.json. A compilação Java opcional não foi executada por ausência das bibliotecas Android; não houve alteração das APIs nativas, geração de APK ou lint completo. O transporte Firebase é simulado; não houve acesso a contas reais ou publicação externa. A recuperação do texto original só é possível quando esse texto está nos dados salvos; esta correção não faz nova extração de um PDF ausente. A orientação do catálogo é usada apenas quando existe uma correspondência segura.

A versão mantém as quatro páginas, bridgeVersion 3/dataSchema 4, seis retratos aprovados e resolução compartilhada de vídeos. A atualização JSON pode ser aplicada no APK atual. Fonte, JSON e ZIP são verificados byte a byte e por CRC antes da entrega.

---

Histórico anterior:

# Agenda Personal — vídeo compartilhado em fichas antigas, versão 1.129

Conteúdo 1.12.49, sequência 155. Atualização de 18/10/2026.

## Problema reproduzido

O catálogo contém uma entrada única app-ex-029, “Elevação de Quadril na Maquina”, com alias “Elevação de quadril na máquina”. O resolvedor anterior considerava somente o vídeo próprio do exercício ou uma consulta direta por catalogId. Uma ficha já existente sem esse identificador, com um identificador antigo ou vinculada a uma cópia privada vazia podia continuar mostrando “Sem vídeo”, mesmo com demonstração salva no catálogo. O mesmo resolvedor abastece os pacotes individuais dos alunos, portanto a ausência era transmitida para eles.

## Correção

shared-workout-video-resolver.js substitui somente a busca da demonstração. O vídeo direto continua prioritário. Um vínculo válido conserva sua preferência. Quando necessário, a busca usa o nome completo ou aliases declarados com a normalização existente de acentos, caixa e espaços. Uma correspondência única no catálogo do app prevalece sobre cópias privadas antigas vazias. Se o item do app não tem vídeo e nunca recebeu uma escolha explícita, uma correspondência privada única pode fornecer o vídeo. O mesmo vale quando não há item correspondente no app. Múltiplas correspondências e variantes sem correspondência exata não são escolhidas por aproximação. Um vínculo com outro nome deixa de fornecer o vídeo do exercício errado. A limpeza explícita do vídeo de um item do app é respeitada, mesmo havendo uma cópia privada antiga com link.

A mudança é de leitura: não regrava catalogId nem vídeo nas fichas. As prescrições, orientações, IDs e registros de execução são mantidos. O mecanismo existente de publicação inicial e após salvar continua montando o pacote de cada aluno com helpers.video, e agora inclui o link resolvido também para exercícios legados. Não há mudança de schema ou dependência de um APK novo.

## Evidência

A regressão verify_shared_student_videos.cjs usa o exercício da captura e três alunos. Exercita ausência de vínculo, ID inexistente/incorreto, cópia privada antiga, nomes com/sem acento, alias, homônimos, variantes, vídeo individual e remoção explícita. O salvamento real no editor do catálogo atualiza os pacotes de todos os alunos que herdam o vídeo. Duas páginas reais da área do aluno exibem e acionam o player com o ID de vídeo correto. Atualizar a demonstração durante um treino preserva contagem iniciada, cargas, séries marcadas e prescrição congelada. O JSON das fichas do professor é comparado antes/depois e permanece idêntico.

O transporte Firebase e a reprodução física no Android são simulados nos testes. Nenhuma conta real ou publicação externa foi acessada. Para receber a correção, o professor deve aplicar o JSON e abrir o painel conectado; os alunos devem abrir seus aplicativos conectados. Falhas de vinculação/aprovação ou de conectividade continuam sendo exibidas pelo fluxo já existente.

Os resultados da revisão ficam em VERIFICACAO_AUTOMATICA.json. Não foi gerado APK nem repetido o lint completo nesta mudança de interface e resolução de dados. Não foram alteradas APIs nativas; somente os metadados de versão foram incrementados. A verificação opcional de compilação Java ficou marcada como SKIP por ausência das bibliotecas Android neste ambiente; os testes de comportamento e de compatibilidade de atualização foram executados. O visual 3D e as demais funcionalidades anteriores permanecem incluídos.

---

Histórico anterior:

# Agenda Personal — retratos 3D aprovados, versão 1.128

Conteúdo 1.12.48, sequência 154. Atualização de 18/10/2026.

## Alteração visual

Os desenhos vetoriais dos seis animais foram substituídos pelas seis imagens fornecidas pela usuária. Os arquivos recebidos possuem extensão PNG, mas o conteúdo real é JPEG de 1536 × 1536 pixels. Eles foram copiados sem reencodificação ou alteração de pixels para web/mascot-images/*.jpg. manifest.json registra o SHA-256 de cada arquivo. O empacotador e a verificação automatizada comprovam a identidade byte a byte dos retratos incorporados.

Os dados são incluídos como JSON inerte em cadastro.html, uma página já permitida pelo contrato de atualização existente. A entrada reutiliza o carregador local de páginas do aplicativo, interpreta apenas esse JSON e decodifica as seis imagens antes de renderizar. O aplicativo continua usando quatro páginas, bridgeVersion 3 e dataSchema 4; não há novo requisito nativo. A página de entrada permanece dentro de 2 MiB. Não se usa CDN ou conexão externa para os retratos. O cadastro público independente permanece sem as imagens.

O seletor usa duas colunas e retratos maiores, sem distorção ou recorte. O retrato principal preserva a composição integral e o fundo claro original. O componente mantém navegação, acessibilidade, modo claro/escuro e retorno por Voltar/Escape. Uma falha no carregamento local oferece nova tentativa e não altera o saldo.

## Compatibilidade e limites visuais

Nome, saldo, XP, meta, inventário, alimentos, equipamentos, recompensas e histórico não são migrados nem zerados. Os controles de teste continuam restritos ao professor. Cada espécie utiliza um retrato fixo aprovado; a progressão continua em dados e indicadores, sem versões físicas distintas por fase. Itens equipados são exibidos como etiquetas abaixo do retrato, sem roupas vetoriais sobre as imagens. Não se trata de modelos tridimensionais manipuláveis ou animações articuladas; as reações existentes são movimentos leves do quadro, respeitando a preferência por movimento reduzido.

## Verificação

Testes em Chromium com dados fictícios: igualdade SHA-256 das seis imagens, decodificação real em 1536px, enquadramento integral, ausência dos desenhos antigos, falha de carregamento e nova tentativa, escolha e troca sem perda de progresso, reinício, isolamento por conta e permissões. As verificações do seletor cobrem 108 combinações de espécie, fase lógica, modo e largura. O relatório consolidado fica em VERIFICACAO_AUTOMATICA.json. Autenticação, rede e serviços nativos são simulados nos testes de interface. Não foi gerado novo APK nem repetido o lint completo nesta alteração visual.

---

Histórico anterior:

# Agenda Personal — seis mascotes, versão 1.127

Conteúdo 1.12.47, sequência 153. Atualização de 18/10/2026.

A capivara retorna ao catálogo selecionável e preserva exatamente o desenho original. Gatinho cinza e Lobo foram adicionados como vetores no mesmo sistema visual dos demais mascotes, com roupas e fases de crescimento. As escolhas ficam disponíveis no componente compartilhado por aluno e professor. A versão anterior preservava a capivara legada, mas não permitia escolhê-la novamente; essa omissão foi corrigida.

O modelo reconhece seis espécies sem migrar ou zerar saldos. A troca de espécie não altera nome, XP, moedas, inventário, alimentos, sessões ou histórico. Os controles de simulação continuam exclusivos do professor. Em telas de até 370 pixels, as escolhas usam duas colunas para manter os nomes legíveis.

As verificações do seletor abrangem 108 combinações de espécie, fase, tema e largura; roupas são conferidas em todos os seis personagens. Foram mantidos os testes de falha de persistência, reinício, troca de conta, capivara legada, prévia sem permissão de escrita e progresso independente do professor. Verificação geral detalhada em VERIFICACAO_AUTOMATICA.json. Interface em Chromium com dados fictícios, autenticação/rede simuladas. Não foi gerado novo APK nem repetido o lint completo para esta mudança de interface. O progresso permanece local ao aparelho.

---

Histórico anterior:

# Agenda Personal — mascote do professor, versão 1.126

Conteúdo 1.12.46, sequência 152. Atualização de 18/10/2026.

O início do professor inclui Seu mascote, que abre o mesmo componente visual do aluno. Escolha, nome, saldo, inventário, roupas e experiência do professor são persistidos em uma chave exclusiva por UID da conta. A abertura exige uma conta de professor ativa e uma mensagem do iframe correto. As simulações de treino e fase só funcionam nesse contexto. Elas não escrevem no armazenamento de alunos nem registram treinos concluídos.

A janela se sobrepõe ao painel, herda suas cores e modo claro/escuro, fecha por Voltar/Escape e restaura o foco no cartão. Falhas de persistência não exibem saldo ou inventário não salvo. A troca de conta fecha o mascote e invalida a sessão de teste. A mesma janela continua em modo de leitura na prévia de um aluno.

Testes em Chromium com dados fictícios: abertura pelo cartão real, compra e equipamento, controles de teste, três fases em três larguras e dois modos, reinício, troca de conta, falha de armazenamento, mensagem de origem indevida e isolamento dos dados dos alunos. As verificações anteriores do mascote do aluno também foram repetidas. Os detalhes da rodada estão em VERIFICACAO_AUTOMATICA.json.

Autenticação e rede foram simuladas nos testes de interface. Não foi gerado APK nem repetido o lint completo nesta alteração de interface. As 27 classes Java foram compiladas contra APIs Android reais. O progresso permanece local ao aparelho.

---

Histórico anterior:

# Agenda Personal — escolha de mascotes, versão 1.125

Conteúdo 1.12.45, sequência 151. Atualização de 18/10/2026.

## Resultado

O aluno pode escolher entre Jacaré roxo, Panda e Galo. O seletor fica dentro da tela do mascote e permite trocar gratuitamente. A escolha é salva na mesma área de execução do aluno e retorna ao reabrir o aplicativo. Selecionar outra espécie preserva nome, meta, moedas, experiência, inventário, roupas equipadas, alimentos, recompensas já recebidas, sessão de treino ativa e histórico. Trocar não reinicia a evolução nem libera outra recompensa pelo mesmo treino.

Os desenhos são adaptações vetoriais das três referências enviadas, integradas ao estilo do aplicativo. O jacaré mantém a cor roxa, focinho claro, olhos dourados, cauda e roupa esportiva com acabamento rosa; o panda mantém o branco/cinza, topete, piscadela e pata levantada; o galo mantém o corpo dourado, crista vermelha, expressão relaxada e cauda verde. Não são recortes das imagens anexadas nem reproduções do acabamento 3D do galo. As referências originais foram preservadas na pasta branding/mascots.

Cada personagem tem proporções de filhote, adolescente e adulto. Camiseta, moletom e faixa são camadas desenhadas em relação ao corpo/cabeça da própria espécie, preservando as cores do personagem; o aluno mantém a cor escolhida no app para as roupas compradas. O jacaré já tem sua camiseta de referência como aparência básica. As regras anteriores de pontos, loja, consumo e descanso continuam.

## Migração

Uma conta nova vê Escolha seu mascote. Uma conta que já tinha a capivara e não possuía o campo de espécie continua mostrando a capivara e seu progresso, até o aluno escolher um dos três novos mascotes. A capivara não aparece como uma quarta opção no seletor. A prévia do professor permanece somente leitura.

## Validação

78 verificações aprovadas, nenhuma falha pendente. A nova regressão usa navegador real para conferir as três escolhas, gravação e recarga, falha de armazenamento, migração da capivara, separação de contas, prévia bloqueada, foco de teclado e preservação de execução/saldo/inventário. Foram conferidos 54 painéis do seletor: 3 personagens × 3 fases × 2 modos × 3 larguras (320, 390 e 480 px), incluindo limites geométricos para evitar cortes. Camiseta, moletom e faixa foram verificados em cada espécie. A regressão anterior do mascote também passou, incluindo a conclusão real do treino e 144 painéis das abas.

Agenda, importação PDF, Pix, finanças, sons, vídeos e contas tiveram suas regressões executadas. Um teste de tela cheia do TikTok encontrou uma corrida na leitura do rótulo pelo teste; o teste agora aguarda o evento/rótulo efetivo e passou. Não houve alteração no player de produção.

As 27 classes Java foram compiladas contra APIs reais. Não foi gerado novo APK nem executado um novo assembleDebug/lintDebug nesta entrega. As mudanças nativas são somente os identificadores de versão/conteúdo. Os resultados atuais estão em VERIFICACAO_AUTOMATICA.json. Relatórios anteriores permanecem em tests/reports.

## Construção e aplicação

Importe AgendaPersonal_atualizacao_1.12.45.agenda.json em Mais > Atualizações no app existente. Esta novidade não exige um componente nativo novo. Para compilar o código completo, substitua o ZIP anterior com o mesmo nome e use LEIA_COMPILACAO.txt. O APK resultante é AgendaPersonal-v1.125.apk.

Para regenerar as telas a partir do código: npm ci e npm run build:assets. Terser 5.44.0 está fixado no package-lock para compactar o código dos mascotes e três módulos isolados da tela inicial, mantendo as APIs públicas e o limite de entrada de 2 MiB dos APKs existentes. A minificação não é ofuscação de dados e não muda as chaves de armazenamento. As quatro telas prontas já estão no ZIP, então a compilação Android normal não precisa executar o gerador JavaScript.

## Limitações

O progresso e a escolha ficam no armazenamento local de execução do aluno neste aparelho. Não foi acrescentada sincronização entre aparelhos nem recuperação após limpeza/desinstalação. A escolha não identifica visualmente o aluno e não altera a prescrição de treino. Não houve teste em um celular físico nem publicação em serviço externo; rede, mídia e ponte nativa foram simuladas nos testes de navegador. A integração com o servidor externo de distribuição não pôde ser executada porque seu código não integra este projeto.

---

# Histórico da versão anterior

# Agenda Personal — mascote do aluno, versão 1.124

Conteúdo 1.12.44, sequência 150. Atualização de 18/10/2026.

## O que foi entregue

Mascote vetorial próprio, uma capivara em três fases: filhote, adolescente e adulto. A tela inicial do aluno inclui o cartão “Seu mascote”. Ao abrir, há saldo de moedas, experiência, crescimento, acompanhamento da meta semanal, nome editável, cuidados, guarda-roupa, loja e histórico de ações. Roupas e acessórios acompanham as fases e as cores do aluno. Respeita modo claro/escuro e preferência de reduzir animações do sistema.

Cada primeiro treino completo do dia pode render 100 moedas, até a meta daquela semana. A conclusão exige todas as séries e a confirmação já existente do treino. O mesmo registro ou outro treino no mesmo dia não rende uma segunda recompensa. A meta completa rende 300 XP para qualquer frequência de 1 a 7 dias; no caso de 7 dias, o arredondamento distribui os pontos para fechar exatamente 300. A semana vai de domingo a sábado. Metas já iniciadas ficam fixas até o fim da semana; mudar a preferência vale para a próxima. A sugestão usa os dias explícitos da ficha, ou 3 treinos quando a ficha é apenas sequencial. O aluno deve ajustar conforme combinado com seu professor.

Filhote até 599 XP; adolescente de 600 a 1799 XP; adulto a partir de 1800 XP. Comprar ou usar itens não gasta experiência. A loja inicial inclui dois alimentos consumíveis, bola permanente, faixa, camiseta e moletom. Alimentar e brincar são interações, não fontes de experiência. Descansar não causa perda de pontos, fome, doença ou regressão.

## Integração e preservação

A recompensa e o registro final do treino ficam na mesma gravação do documento de execução. Se o armazenamento falhar, nem o treino nem os pontos são confirmados; a sessão permanece para tentar novamente. Compras verificam saldo e posse antes de salvar, e falhas mantêm saldo e inventário anteriores. A prévia do professor é somente leitura. Contas diferentes usam o isolamento existente do aluno. Treinos antigos são preservados e não concedem recompensas retroativas.

Para manter o arquivo de entrada abaixo do limite de 2 MiB aceito pelos APKs anteriores, foi reduzida apenas a precisão decimal dos caminhos vetoriais de identificação muscular. Imagens, licença e geometrias são preservadas: desvio máximo por coordenada do caminho de 0,05 pixel na escala original, e 0,005 pixel nas posições/limites. Os testes da identificação de treinos continuam aprovados.

## Validação desta versão

77 verificações automatizadas aprovadas, nenhuma falha pendente. Inclui o fluxo real de conclusão do aluno com recompensa, falha de armazenamento e tentativa posterior, repetição de conclusão, duas sessões no mesmo dia, compras, uso de alimento, nome, meta congelada da semana, roupas equipadas, recarga, contas diferentes e prévia bloqueada. Foram inspecionados 144 painéis: três fases, três larguras móveis, dois modos e quatro abas. Testes da agenda, alarmes, Pix, importação, vídeos e identidade também foram executados. O relatório detalhado está em VERIFICACAO_AUTOMATICA.json.

As 27 classes Java foram compiladas contra APIs reais do Android, incluindo AndroidX EXIF 1.4.2. Não foi gerado novo APK nesta mudança. A última compilação Gradle completa pertence à versão 1.123 e está documentada no histórico abaixo; não deve ser confundida com uma compilação 1.124. Nesta entrega, o código nativo muda somente os identificadores de versão/conteúdo. O script de compilação passa a gerar AgendaPersonal-v1.124.apk.

## Como aplicar

No app existente, importe AgendaPersonal_atualizacao_1.12.44.agenda.json em Mais > Atualizações. O mascote não exige novo componente nativo. Para compilar o aplicativo completo, substitua o ZIP anterior com o mesmo nome e use o comando em LEIA_COMPILACAO.txt. O código do mascote está em web/student-mascot*, integrado por tools/student_mascot_transform.cjs; npm run build:assets regenera as telas.

## Limites reais

O progresso do mascote acompanha o armazenamento local de execução do aluno neste aparelho. Esta versão não cria sincronização do progresso com servidor, recuperação após limpeza/desinstalação, auditoria de treino por sensor, nem uma carteira de dinheiro. As moedas são virtuais. As proteções impedem repetição no fluxo normal deste armazenamento; não são uma garantia antifraude entre aparelhos ou contra alteração manual do banco. Não houve teste em um celular físico nem publicação em serviço externo. Rede e serviços nativos foram simulados nos testes de navegador.

---

# Histórico da revisão anterior

# Revisão do Agenda Personal — 1.123

Conteúdo 1.12.43, sequência 149. Revisão concluída em 18/10/2026.

## Correções

- **Cronômetro da aula:** a configuração clonava uma contagem já existente e comparava a identidade do objeto clonado com a original. A comparação sempre falhava e marcava essa contagem como criada pelo treino. A decisão de reutilizar agora é calculada antes da cópia. O teste com navegador reproduziu o erro antes e confirmou que Parar treino mantém a contagem independente depois da correção.
- **YouTube:** uma substituição usada para incluir TikTok também trocava a mensagem de compatibilidade do YouTube. A mensagem agora considera o provedor correto. Há teste com a ponte antiga e com os dois provedores.
- **Compilação:** origem e destino Java 17 explícitos; mantém o Kotlin BOM e as dependências existentes. O comando do Codespaces verifica a integridade do APK e conclui a cópia por arquivo temporário, sem apresentar uma cópia parcial como arquivo final.
- **Verificações:** testes antigos foram adaptados à entrada integrada, à ficha atual, às séries individuais e à ordenação com confirmação. A importação tem um PDF numerado de teste incluído. O migrador de testes só modifica verificações do professor, preservando a entrada de contas/alunos.

- **Compatibilidade Android:** a classe interna do gesto Voltar já era chamada apenas no Android 13+, mas não declarava esse contrato. A anotação específica de API agora expressa a condição existente, sem desligar a análise. A permissão de alarme tem guarda explícita de versão; as consultas à câmera agora são declaradas no manifesto para Android 11+; o validador de HTML usa `Locale.ROOT`.
- **Fotos do comprovante:** substituído o leitor EXIF antigo da plataforma por `androidx.exifinterface:exifinterface:1.4.2`, mantendo a correção de orientação e as limitações de tamanho. Referência: [Android Developers — Exifinterface](https://developer.android.com/jetpack/androidx/releases/exifinterface).

- **Reconstrução das telas:** incluída a base original imutável em `web/reference/`. `npm run build:assets` regenera as quatro telas com os módulos entregues, sem depender de um arquivo externo de outra conversa. O resultado foi comparado byte a byte com a versão compilada.

## Evidência automatizada

**75 verificações aprovadas, nenhuma falha**, incluindo:

| Área | Cobertura |
| --- | --- |
| Agenda | Recorrências, cancelamentos, conflito real de horário, virada de dia, resumo de domingo a sábado, datas do mês e abertura da aula correta |
| Sons e treino | Três escolhas de áudio e prévias, ponte de alarmes, descanso, contagem reutilizada, séries, bi-set, ordem, retomada e histórico |
| Financeiro | Carteira mensal, centavos, alunos arquivados, recebimentos, revisão manual de Pix, duplicidade, data/valor, falha de armazenamento e vínculo do aluno |
| PDFs | Leitura real de MFit e modelo numerado, instruções do documento, revisão, aluno de destino, rollback e arquivo anexado |
| Vídeos | Links, galerias, janela interna YouTube/TikTok, retorno, foco, prévia e mensagem para APK anterior |
| Contas e apresentação | Separação de alunos, aprovação, cadastro por link, fotos, temas, janelas e layouts de celular |
| Android | Compilação das 27 classes de produção contra APIs reais; testes Java de alarmes, atualização, retorno, som e players |

Os resultados individuais estão em `VERIFICACAO_AUTOMATICA.json`. Nenhum teste usou os dados ativos do seu aparelho.

## Compilação Android completa

`assembleDebug lintDebug` terminou com **BUILD SUCCESSFUL**, usando Gradle 8.9, JDK 17 e plataforma Android 35. O APK de QA tem 60,937,074 bytes, CRC válido, manifesto e DEX presentes. O arquivo foi construído com os mesmos arquivos de produção entregues.

A análise terminou com **0 erros e 33 avisos**. Não foi desligado `abortOnError`, criado baseline para esconder erros nem adicionado um bloqueio geral de diagnósticos. Permanecem sugestões para JavaScript necessário às páginas, orientação retrato escolhida, tradução dos textos, recursos/ícones e guardas antigas de SDK. A gravação síncrona da recuperação de atualização é intencional para garantir que o estado seja gravado antes de continuar.

O APK local é apenas de QA e tem outra assinatura de teste. Compile no seu Codespaces existente para manter a chave de atualização da sua instalação. Não é necessário desinstalar ou limpar os dados.

## Reproduzir as verificações

Use Node.js 22 ou superior, Python 3 e Java 17 ou superior. Em um ambiente de desenvolvimento:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r tests/requirements.txt
npm install
npx playwright install chromium
npm test
```

`AGENDA_CHROMIUM` permite usar um Chromium já instalado. O executador gera um pacote temporário com as quatro telas atuais, roda todos os testes e termina com erro se algum falhar. Registra logs e relatório em uma pasta temporária indicada ao final.

Para repetir a compilação direta das APIs Java, forneça os JARs em `tests/run_all.py --android-jar ... --androidx-jar ... --dependency-dir ...`. Sem esses caminhos, essa verificação específica é marcada como não executada; a compilação Android completa é feita pelo Gradle.

No Codespaces já configurado, compile com `bash COMPILAR_NO_CODESPACES.sh`. A análise Android adicional é `gradle assembleDebug lintDebug`, usando o Gradle 8.9 existente. O arquivo `LEIA_COMPILACAO.txt` contém o comando completo e o nome exato para substituir o ZIP anterior.

## Limites

- Os testes de navegador usam navegador real, com Firebase, ponte Android e mídia remota simulados. Os testes de OCR da tela simulam o retorno nativo; o leitor Java compilou contra as APIs reais, mas o reconhecimento de uma foto em aparelho não foi executado aqui.
- Permissões, alarme com tela apagada, bateria e reprodução real de mídia precisam de verificação no celular.
- A verificação do publicador compara e valida o pacote real. O servidor externo de distribuição não faz parte deste projeto: sua integração não foi executada. O teste informa isso explicitamente e aceita `AGENDA_DISTRIBUTION_WORKER` para quem tiver o código do servidor.
- Testes aprovados cobrem os cenários descritos; não são garantia de ausência de qualquer erro em qualquer dispositivo.
