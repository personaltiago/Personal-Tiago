# Revisão de limpeza — Android 1.157 / conteúdo 1.12.111

Revisão do pacote de código, da montagem das telas e das dependências das partes alteradas. O arquivo de entrega conserva o nome `AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip`.

## Resíduos removidos

- Três cópias temporárias de HTML deixadas por gravações interrompidas na pasta de telas: 4.194.304 bytes. Elas acompanhavam o ZIP anterior sem constar no inventário parcial da versão.
- Dezoito JPEGs dos mascotes com fundo, já substituídos pelos 18 WebP transparentes. Os recortes finais e seus hashes foram preservados; os hashes das imagens originais permanecem como procedência no manifesto de imagens.
- Três ferramentas sem consumidores atuais: a transformação de sobreposição de aula que apenas devolvia a entrada, a prévia muscular substituída pela organização atual e uma migração de testes já concluída.
- Vinte e oito relatórios antigos gerados por testes. Os testes continuam no projeto; seus resultados são saídas, não fontes da versão.

Total: 52 arquivos, 9.077.045 bytes antes da compressão. Esse número descreve arquivos retirados do pacote de código; não mede redução do APK instalado nem ganho de desempenho.

## Código substituído que ainda participava da montagem

A faixa antiga de intervalo estava escondida, mas ainda existia na tela gerada e recebia atualizações. A montagem agora retira seu HTML, estilos e atualizações, inclusive o posicionamento usado pelo bi-set. O cronômetro compacto, seus alarmes, o prazo de término e o som foram mantidos. O modelo Android continua necessário ao serviço compacto e não foi apagado.

A cópia pública de `teacher-sync.js` estava atrasada em relação à fonte usada pelo aplicativo. As quatro cópias públicas de sincronização agora são geradas das mesmas fontes. O carregador web preserva o código atual embutido na atualização; os identificadores novos também sobrevivem ao filtro de versões anteriores do carregador. As cópias públicas continuam como compatibilidade para conteúdos anteriores.

O endereço antigo `web/cadastro.html` agora recebe o mesmo formulário gerado de cadastro com foto que `web/cadastro-aluno-publico.html`, evitando manter duas implementações diferentes. O endereço antigo foi preservado.

## Conferência do pacote

- O manifesto passa a relacionar todos os arquivos enviados no ZIP, com SHA-256, em vez de uma seleção parcial. O próprio `release.json` fica fora de seu mapa de hashes para evitar referência circular.
- Um inventário comum controla o manifesto e o empacotamento. Dependências instaladas, resultados de compilação, relatórios gerados e sobras de editor ficam fora da entrega.
- O empacotador confere a lista exata de entradas e cada hash do ZIP antes de aceitar o arquivo.
- A preparação limpa cópias temporárias conhecidas mesmo ao reaproveitar telas já montadas. A conferência das telas Android aceita somente as quatro páginas, o ícone e a identificação da montagem.
- O comando local de APK de teste agora informa explicitamente que produz debug; a distribuição com a assinatura existente continua pelo workflow de publicação do GitHub.

Para uma alteração futura intencional nas fontes, revise o diff, execute `python3 tools/refresh_release.py`, depois `node tools/prepare_assets.cjs` e `node tools/check_release.cjs --assets`. Para conferir sem alterar o manifesto: `python3 tools/refresh_release.py --check`.

## Partes preservadas por terem uso

O HTML em `web/reference/` ainda é a entrada de montagem das quatro telas. Arquivos de compatibilidade, migrações de dados e métodos da ponte Android usados por conteúdo anterior foram preservados. As classes compartilhadas também foram verificadas em relação ao módulo Wear OS; uma classe não usada diretamente pelo telefone pode ser usada pelo relógio. Imagens de referência e fontes de arte editáveis continuam disponíveis onde participam da produção ou documentam sua origem.

Não foi feita exclusão automática apenas por não encontrar uma chamada textual: a aplicação também usa eventos, código gerado, ponte JavaScript/Android e arquivos de compatibilidade.

## Validação e limites

As verificações automatizadas cobrem a limpeza em montagem reaproveitada, igualdade das fontes públicas, cadastro unificado, remoção da faixa antiga, contagem e finalização do intervalo, relógio de bi-set, cronômetro compacto, login persistente, feedback confirmado, exportação de treino, mascotes transparentes, modelos do aluno, sincronização e modelo do relógio. O serviço Android compacto foi exercitado com APIs Android simuladas. O envio e a resposta de feedback foram exercitados com o handler real do servidor e autenticação/armazenamento simulados; nenhuma mensagem foi enviada a contas reais.

O teste isolado de alarmes tinha uma simulação desatualizada do serviço, sem o método `isDismissed` já existente na produção; a simulação foi alinhada à interface atual.

A entrega inclui conferência do inventário/hash do ZIP e reconstrução das quatro telas após extração em outra pasta. Isso não substitui compilação Gradle/SDK, instalação em aparelho, autenticação Firebase real ou teste físico no Safari/iPhone. Não havia navegador de teste instalado para executar a suíte Playwright, nem SDK/assinatura Android para gerar um APK assinado neste ambiente. Nenhuma publicação externa foi realizada por esta revisão.
