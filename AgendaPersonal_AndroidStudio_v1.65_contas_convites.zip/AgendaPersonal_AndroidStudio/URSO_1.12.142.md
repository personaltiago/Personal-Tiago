# Urso: gestos por pose — 1.12.142 / sequência 248

Quatro poses, três fases e seis cores. O motor aprovado R14 do urso preto adulto sentado permanece intacto. As outras 71 combinações usam movimentos localizados no rosto e orelhas e mantêm a pose escolhida, sem substituir a imagem pelo urso sentado.

Carinho, olhar direcionado, curiosidade, orelha, farejo e protesto. Os olhos iniciam a atenção antes da inclinação da cabeça. O protesto fecha a expressão e mantém as patas fixas. Corpo apoiado e cenário não são transformados. Movimento reduzido conserva resposta visual sem deslocamento.

Geometria: 72 combinações verificadas, sete contatos; áreas da malha entre 0,739 e 1,260; corpo abaixo do limite de apoio imóvel; retorno neutro; prioridade R14. Conferência adicional no navegador com as artes reais. Não houve teste físico em Android ou iPhone nesta execução. Os demais animais conservam seus comportamentos anteriores.
