package com.tiagolima.agendapersonal.watch;
import com.google.android.gms.wearable.*;
public final class WatchDataService extends WearableListenerService {
    @Override public void onDataChanged(DataEventBuffer events){for(DataEvent e:events)if(e.getType()==DataEvent.TYPE_CHANGED)WatchTransfer.receive(this,e.getDataItem());}
}
