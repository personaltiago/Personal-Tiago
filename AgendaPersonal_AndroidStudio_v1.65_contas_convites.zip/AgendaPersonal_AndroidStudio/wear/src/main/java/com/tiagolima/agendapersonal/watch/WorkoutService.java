package com.tiagolima.agendapersonal.watch;

import android.app.*;
import android.content.*;
import android.os.*;
import androidx.core.app.NotificationCompat;
import androidx.wear.ongoing.OngoingActivity;

/** Visible, user-started workout. Timestamps remain correct even if a background tick is delayed. */
public final class WorkoutService extends Service {
    private final Handler handler=new Handler(Looper.getMainLooper());private long previousRest=-1;private int ticks;
    private final Runnable tick=new Runnable(){public void run(){
        WorkoutClock k=WatchStore.clock(WorkoutService.this);
        if(!k.started||WatchStore.prefs(WorkoutService.this).getBoolean("finished",false)||WatchStore.packet(WorkoutService.this).optBoolean("revoked")){stopSelf();return;}
        long rest=k.rest(WatchStore.now());if(previousRest>0&&rest==0&&!k.paused){Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);if(v!=null)v.vibrate(VibrationEffect.createOneShot(400,VibrationEffect.DEFAULT_AMPLITUDE));}previousRest=rest;
        if(++ticks%10==0)WatchStore.save(WorkoutService.this,k);handler.postDelayed(this,1000);
    }};
    @Override public int onStartCommand(Intent intent,int flags,int id){
        NotificationManager manager=getSystemService(NotificationManager.class);manager.createNotificationChannel(new NotificationChannel("workout","Treino em andamento",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,WatchActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder=new NotificationCompat.Builder(this,"workout").setSmallIcon(R.drawable.ic_workout).setContentTitle("Agenda Personal").setContentText("Treino em andamento · toque para voltar").setContentIntent(open).setOngoing(true).setCategory(NotificationCompat.CATEGORY_WORKOUT).setVisibility(NotificationCompat.VISIBILITY_PRIVATE);
        OngoingActivity ongoing=new OngoingActivity.Builder(this,1,builder).setStaticIcon(R.drawable.ic_workout).setTouchIntent(open).build();ongoing.apply(this);
        startForeground(1,builder.build());handler.removeCallbacks(tick);handler.post(tick);return START_NOT_STICKY;
    }
    @Override public void onDestroy(){handler.removeCallbacks(tick);stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
