package com.tiagolima.agendapersonal.watch;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;

/** Small, round-screen friendly workout checklist; no network or phone required after transfer. */
public final class WatchActivity extends Activity {
    private LinearLayout content;private ScrollView scroll;private TextView clock,rest;private String signature="";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable tick=new Runnable(){public void run(){render();handler.postDelayed(this,500);}};
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    @Override public void onCreate(Bundle state){super.onCreate(state);scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(8,10,12));content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setGravity(Gravity.CENTER_HORIZONTAL);content.setPadding(dp(22),dp(35),dp(22),dp(40));scroll.addView(content);setContentView(scroll);}
    @Override public void onResume(){super.onResume();WatchTransfer.refresh(this);if(WatchStore.clock(this).started&&!WatchStore.prefs(this).getBoolean("finished",false))foreground();handler.post(tick);}
    @Override public void onPause(){handler.removeCallbacks(tick);super.onPause();}
    private TextView text(String value,int size,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(6),0,dp(6));content.addView(t,new LinearLayout.LayoutParams(-1,-2));return t;}
    private void button(String label,boolean primary,Runnable action){Button b=new Button(this);b.setText(label);b.setTextSize(15);b.setAllCaps(false);b.setTextColor(primary?Color.BLACK:Color.WHITE);GradientDrawable bg=new GradientDrawable();bg.setColor(primary?Color.rgb(180,255,36):Color.rgb(35,39,43));bg.setCornerRadius(dp(28));b.setBackground(bg);b.setMinHeight(dp(52));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);content.addView(b,lp);b.setOnClickListener(v->{action.run();signature="";render();});}
    private static String time(long ms){long seconds=Math.max(0,ms+999)/1000;return String.format(java.util.Locale.ROOT,"%02d:%02d",seconds/60,seconds%60);}
    private void foreground(){try{startForegroundService(new Intent(this,WorkoutService.class));}catch(Exception e){new AlertDialog.Builder(this).setMessage("Mantenha o treino aberto para acompanhar o descanso.").setPositiveButton("OK",null).show();}}
    private void finish(boolean partial){new AlertDialog.Builder(this).setMessage(partial?"Encerrar com as séries realizadas?":"Salvar este treino no relógio?").setPositiveButton("Salvar",(d,w)->{try{JSONObject result=WatchStore.finish(this);WatchTransfer.put(this,WatchContract.RESULT+result.getString("token"),result);WatchTransfer.receipt(this,result.getString("token"),"finished");stopService(new Intent(this,WorkoutService.class));signature="";render();}catch(Exception ignored){}}).setNegativeButton("Voltar",null).show();}
    private void render(){
        JSONObject p=WatchStore.packet(this);WorkoutClock k=WatchStore.clock(this);boolean finished=WatchStore.prefs(this).getBoolean("finished",false),ready=p.has("exercises")&&!p.optBoolean("revoked");
        JSONArray steps=p.optJSONArray("steps");int total=steps==null?0:steps.length();long left=k.rest(WatchStore.now());
        String next=p.optString("token")+"|"+k.started+"|"+k.paused+"|"+k.completed+"|"+(left>0)+"|"+finished;
        if(next.equals(signature)){if(clock!=null)clock.setText(time(k.elapsed(WatchStore.now())));if(rest!=null)rest.setText(time(left));return;}signature=next;content.removeAllViews();clock=null;rest=null;
        text("AGENDA PERSONAL",11,0xffb4ff24).setTypeface(null,Typeface.BOLD);
        if(!ready){text("Seu treino no pulso",21,Color.WHITE).setTypeface(null,Typeface.BOLD);text("No celular, abra o treino e toque em Enviar ao relógio. Aluno e professor podem enviar.",14,0xffbdc3c7);button("Buscar treino",true,()->WatchTransfer.refresh(this));return;}
        text(p.optString("label"),20,Color.WHITE).setTypeface(null,Typeface.BOLD);text(p.optString("person")+" · "+(p.optString("role").equals("teacher")?"Professor":"Aluno"),12,0xffbdc3c7);
        if(finished){text("Treino salvo",23,0xffb4ff24);text(k.completed+" de "+total+" séries · "+time(k.elapsed(WatchStore.now())),15,Color.WHITE);text("O resumo será enviado ao celular quando conectar. Para treinar de novo, envie uma nova sessão pelo celular.",14,0xffbdc3c7);button("Sincronizar resumo",true,()->WatchTransfer.refresh(this));return;}
        if(!k.started){text(p.optJSONArray("exercises").length()+" exercícios · "+total+" séries",14,Color.WHITE);text("O treino ficará disponível aqui mesmo sem conexão após o envio.",13,0xffbdc3c7);button("Iniciar treino",true,()->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1);WatchStore.start(this);foreground();});return;}
        clock=text(time(k.elapsed(WatchStore.now())),22,Color.WHITE);text(k.completed+" / "+total+" séries concluídas",12,0xffbdc3c7);
        if(k.completed>=total){button("Finalizar treino",true,()->finish(false));return;}
        JSONObject step=steps.optJSONObject(k.completed),ex=p.optJSONArray("exercises").optJSONObject(step.optInt("e")),row=ex.optJSONArray("rows").optJSONObject(step.optInt("set"));
        if(left>0){text(k.paused?"Descanso pausado":"Descanso",18,Color.WHITE);rest=text(time(left),32,0xffb4ff24);button("Pular descanso",false,()->{WorkoutClock c=WatchStore.clock(this);c.skipRest();WatchStore.save(this,c);});}
        text(ex.optString("name"),20,Color.WHITE).setTypeface(null,Typeface.BOLD);text("Série "+(step.optInt("set")+1)+" de "+ex.optJSONArray("rows").length(),13,0xffbdc3c7);text(row.optString("reps")+" rep. · "+(row.optString("load").trim().isEmpty()?"Carga não informada":row.optString("load")+" kg"),15,Color.WHITE);text("Prescrição do treino",10,0xffbdc3c7);
        if(!k.paused&&left==0)button("Concluir série",true,()->{WorkoutClock c=WatchStore.clock(this);if(c.complete(WatchStore.now(),step.optInt("rest"),total))WatchStore.save(this,c);});
        button(k.paused?"Retomar":"Pausar",false,()->{WorkoutClock c=WatchStore.clock(this);if(c.paused){c.resume(WatchStore.now());foreground();}else c.pause(WatchStore.now());WatchStore.save(this,c);});
        button("Encerrar treino",false,()->finish(true));
    }
}
