package com.tiagolima.agendapersonal.watch;

import android.content.*;
import android.os.SystemClock;
import android.provider.Settings;
import org.json.*;

final class WatchStore {
    static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("watch_workout_v1",Context.MODE_PRIVATE);}
    static JSONObject json(String s){try{return new JSONObject(s);}catch(Exception e){return new JSONObject();}}
    static JSONObject packet(Context c){return json(prefs(c).getString("packet","{}"));}
    static long now(){return SystemClock.elapsedRealtime();}
    static int boot(Context c){return Settings.Global.getInt(c.getContentResolver(),Settings.Global.BOOT_COUNT,0);}
    static synchronized WorkoutClock clock(Context c){
        JSONObject s=json(prefs(c).getString("session","{}"));WorkoutClock k=new WorkoutClock();
        k.started=s.optBoolean("started");k.paused=s.optBoolean("paused");k.completed=s.optInt("completed");k.accumulated=s.optLong("accumulated");k.anchor=s.optLong("anchor");k.restUntil=s.optLong("restUntil");k.pausedRest=s.optLong("pausedRest");
        if(k.started&&s.optInt("boot",boot(c))!=boot(c)){
            k.accumulated=s.optLong("checkpointElapsed");k.pausedRest=s.optLong("checkpointRest");k.anchor=now();k.restUntil=0;k.paused=true;save(c,k);
        }return k;
    }
    static synchronized void save(Context c,WorkoutClock k){
        try{JSONObject s=new JSONObject().put("started",k.started).put("paused",k.paused).put("completed",k.completed).put("accumulated",k.accumulated).put("anchor",k.anchor).put("restUntil",k.restUntil).put("pausedRest",k.pausedRest).put("boot",boot(c)).put("checkpointElapsed",k.elapsed(now())).put("checkpointRest",k.rest(now()));prefs(c).edit().putString("session",s.toString()).commit();}catch(Exception ignored){}
    }
    static synchronized String receive(Context c,String raw,String node){
        try{
            JSONObject p=WatchContract.parse(raw),old=packet(c);
            String source=prefs(c).getString("source","");
            if(p.optLong("createdAt")<old.optLong("createdAt"))return "stale";
            if(p.optBoolean("revoked")){
                if(!source.isEmpty()&&!source.equals(node))return "stale";
                prefs(c).edit().putString("packet",p.toString()).remove("session").remove("finished").putString("source",node).commit();return "revoked";
            }
            if(p.optString("token").equals(old.optString("token")))return "ready";
            if(clock(c).started&&!prefs(c).getBoolean("finished",false))return "busy";
            prefs(c).edit().putString("packet",p.toString()).putString("source",node).remove("session").remove("finished").remove("startedAt").commit();return "ready";
        }catch(Exception e){return "invalid";}
    }
    static synchronized void start(Context c){WorkoutClock k=clock(c);if(!k.started){k.start(now());prefs(c).edit().putLong("startedAt",System.currentTimeMillis()).commit();save(c,k);}}
    static synchronized JSONObject finish(Context c)throws JSONException{
        WorkoutClock k=clock(c);if(!k.started||prefs(c).getBoolean("finished",false))throw new JSONException("Treino indisponível.");
        k.pause(now());save(c,k);JSONObject p=packet(c);
        JSONObject result=new JSONObject().put("token",p.getString("token")).put("startedAt",prefs(c).getLong("startedAt",0)).put("finishedAt",Math.max(System.currentTimeMillis(),prefs(c).getLong("startedAt",0))).put("durationMs",k.elapsed(now())).put("completed",k.completed);
        JSONObject results=json(prefs(c).getString("results","{}"));while(results.length()>=20)results.remove(results.keys().next());results.put(p.getString("token"),result);
        prefs(c).edit().putBoolean("finished",true).putString("results",results.toString()).commit();return result;
    }
    private WatchStore(){}
}
