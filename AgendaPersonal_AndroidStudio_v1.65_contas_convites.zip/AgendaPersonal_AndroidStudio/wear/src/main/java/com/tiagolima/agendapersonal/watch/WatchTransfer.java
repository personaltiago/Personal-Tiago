package com.tiagolima.agendapersonal.watch;
import android.content.Context;
import com.google.android.gms.wearable.*;
import org.json.*;
final class WatchTransfer {
    static void put(Context c,String path,JSONObject p){
        try{PutDataMapRequest map=PutDataMapRequest.create(path);map.getDataMap().putString("json",p.toString());Wearable.getDataClient(c).putDataItem(map.asPutDataRequest().setUrgent());}catch(Exception ignored){}
    }
    static void receipt(Context c,String token,String status){try{put(c,WatchContract.RECEIPT,new JSONObject().put("token",token).put("status",status).put("at",System.currentTimeMillis()));}catch(Exception ignored){}}
    static void receive(Context c,DataItem item){
        if(!WatchContract.WORKOUT.equals(item.getUri().getPath()))return;
        try{String raw=DataMapItem.fromDataItem(item).getDataMap().getString("json");String status=WatchStore.receive(c,raw,item.getUri().getHost());if(status.equals("ready")||status.equals("busy"))receipt(c,new JSONObject(raw).getString("token"),status);}catch(Exception ignored){}
    }
    static void refresh(Context c){
        Wearable.getDataClient(c).getDataItems().addOnSuccessListener(items->{try{for(DataItem item:items)receive(c,item);}finally{items.release();}});
        JSONObject results=WatchStore.json(WatchStore.prefs(c).getString("results","{}"));results.keys().forEachRemaining(k->put(c,WatchContract.RESULT+k,results.optJSONObject(k)));
    }
}
