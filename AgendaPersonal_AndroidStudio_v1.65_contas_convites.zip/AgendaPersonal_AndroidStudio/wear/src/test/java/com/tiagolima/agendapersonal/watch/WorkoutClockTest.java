package com.tiagolima.agendapersonal.watch;
import org.junit.Test;
import static org.junit.Assert.*;
public class WorkoutClockTest {
 @Test public void pausesRestAndElapsedWithoutCountingPausedTime(){WorkoutClock k=new WorkoutClock();k.start(1000);assertTrue(k.complete(11000,60,4));k.pause(21000);assertEquals(20000,k.elapsed(121000));assertEquals(50000,k.rest(121000));assertFalse(k.complete(121000,60,4));k.resume(121000);assertEquals(50000,k.rest(121000));assertEquals(30000,k.elapsed(131000));assertFalse(k.complete(170999,60,4));assertTrue(k.complete(171000,60,4));assertEquals(2,k.completed);}
 @Test public void finishHasNoUnnecessaryFinalRestAndCannotOvercount(){WorkoutClock k=new WorkoutClock();assertFalse(k.complete(0,60,1));k.start(0);assertTrue(k.complete(100,60,1));assertEquals(0,k.rest(100));assertFalse(k.complete(101,60,1));assertEquals(1,k.completed);}
 @Test public void handlesLargeBackgroundDelayAndExplicitSkip(){WorkoutClock k=new WorkoutClock();k.start(100);k.complete(200,60,3);assertEquals(0,k.rest(100000));k.complete(100000,1800,3);k.skipRest();assertEquals(0,k.rest(100001));assertTrue(k.complete(100001,1800,3));}
 @Test public void repeatedStartAndPauseAreIdempotent(){WorkoutClock k=new WorkoutClock();k.start(1000);k.start(2000);k.pause(3000);k.pause(8000);assertEquals(2000,k.elapsed(9000));k.resume(10000);k.resume(12000);assertEquals(3000,k.elapsed(11000));}
}
