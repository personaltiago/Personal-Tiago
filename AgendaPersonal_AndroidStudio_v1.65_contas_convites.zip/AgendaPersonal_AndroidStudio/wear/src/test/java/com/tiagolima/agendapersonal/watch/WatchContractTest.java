package com.tiagolima.agendapersonal.watch;
import org.json.*;
import org.junit.Test;
import static org.junit.Assert.*;
public class WatchContractTest {
 private JSONObject valid()throws Exception{return new JSONObject("{\"v\":1,\"token\":\"session-1\",\"role\":\"student\",\"owner\":\"uid\",\"label\":\"A\",\"person\":\"Aluno\",\"workoutId\":\"plan-day\",\"exercises\":[{\"id\":\"e1\",\"name\":\"Agachamento\",\"rows\":[{\"reps\":\"12\",\"load\":\"20\"},{\"reps\":\"10\",\"load\":\"22\"}]}],\"steps\":[{\"e\":0,\"set\":0,\"rest\":60},{\"e\":0,\"set\":1,\"rest\":60}]}");}
 @Test public void acceptsBothRoles()throws Exception{for(String role:new String[]{"student","teacher"})assertEquals(role,WatchContract.parse(valid().put("role",role).toString()).getString("role"));}
 @Test public void rejectsDuplicateOrMissingSeries()throws Exception{JSONObject p=valid();p.getJSONArray("steps").getJSONObject(1).put("set",0);try{WatchContract.parse(p.toString());fail();}catch(JSONException expected){}p=valid();p.getJSONArray("steps").remove(1);try{WatchContract.parse(p.toString());fail();}catch(JSONException expected){}}
 @Test public void rejectsUnboundedRestOrUnknownRole()throws Exception{JSONObject p=valid();p.getJSONArray("steps").getJSONObject(0).put("rest",-1);try{WatchContract.parse(p.toString());fail();}catch(JSONException expected){}p=valid().put("role","preview");try{WatchContract.parse(p.toString());fail();}catch(JSONException expected){}}
}
