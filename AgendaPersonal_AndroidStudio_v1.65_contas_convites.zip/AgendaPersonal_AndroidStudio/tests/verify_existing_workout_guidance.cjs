'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const {chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const name='Leg Press Horizontal',students=['a','b','c'].map(id=>({id,name:'Aluno '+id,firebaseUid:'guidance_'+id,studentType:'presencial'}));
const exercise=(id,extra={})=>({id,name,sets:'3',reps:'10-12',load:'50 kg',rest:'60',notes:'',observations:'',...extra});
const fixture={students,lessons:[],customData:{keep:42},workoutExecutions:[],workoutPlans:students.map(s=>({id:'p'+s.id,studentId:s.id,name:'Ficha '+s.id,days:[{id:'d',name:'Treino A',exercises:[exercise('e'+s.id,{sourceDocumentId:'pdf',guidanceVersion:1,...(s.id==='b'?{catalogId:'old-id',notes:'Execução individual do PDF'}:s.id==='c'?{notes:'Execução individual',observations:'Cuidados individuais'}:{})})]}]}))};
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'professor.html';if(!['index.html','professor.html','cadastro.html','avaliacoes.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  await context.addInitScript(seed=>{if(location.pathname.endsWith('/professor.html')){localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(seed));window.__staged=[];window.APaccounts={isTeacher:()=>true,stage:area=>__staged.push(JSON.parse(JSON.stringify(area))),refreshPreview(){},knownAreas:()=>[],status:()=>({state:'sent',message:'Enviado'})}}},fixture);
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await page.waitForFunction(()=>__staged.length>=3);
  const catalog=await page.evaluate(name=>workoutCatalogItems().filter(e=>e.source==='app'&&workoutCatalogSameName({name},e)),name);assert.equal(catalog.length,1);assert.ok(catalog[0].notes);assert.ok(catalog[0].observations);
  const before=await page.evaluate(()=>JSON.stringify(state.workoutPlans));
  const areas=await page.evaluate(()=>['a','b','c'].map(id=>__staged.filter(a=>a.studentUid==='guidance_'+id).at(-1)));
  const first=areas[0].plans[0].days[0].exercises[0],mixed=areas[1].plans[0].days[0].exercises[0],individual=areas[2].plans[0].days[0].exercises[0];
  assert.equal(first.description,catalog[0].notes);assert.equal(first.notes,catalog[0].observations);assert.equal(mixed.description,'Execução individual do PDF');assert.equal(mixed.notes,catalog[0].observations);assert.equal(individual.description,'Execução individual');assert.equal(individual.notes,'Cuidados individuais');
  const edge=await page.evaluate(({name,id})=>{
   const source=withWorkoutGuidance({name,catalogId:id,sourceDocumentId:'pdf',guidanceVersion:1,sourceNotes:'Texto original extraído',sourceObservations:'Cuidados originais'});
   const alternate=withWorkoutGuidance({name,guidance:{execution:'Orientação estruturada'}});
   state.exerciseCatalog.push({id:'dupe1',name:'Teste homônimo',source:'mine',notes:'Não escolher 1'},{id:'dupe2',name:'Teste homônimo',source:'mine',notes:'Não escolher 2'},{id:'unique',name:'Exercício próprio',source:'mine',notes:'Execução própria',observations:'Cuidados próprios'});
   return {source,alternate,ambiguous:withWorkoutGuidance({name:'Teste homônimo'}),linked:withWorkoutGuidance({name:'Teste homônimo',catalogId:'dupe2'}),variant:withWorkoutGuidance({name:name+' variante inexistente xyz',catalogId:id}),private:withWorkoutGuidance({name:'Exercício próprio'}),accent:withWorkoutGuidance({name:'  LEG PRESS HORIZONTAL  ',catalogId:'stale'})};
  },{name,id:catalog[0].id});
  assert.equal(edge.source.notes,'Texto original extraído');assert.equal(edge.source.observations,'Cuidados originais');assert.equal(edge.alternate.notes,'Orientação estruturada');assert.equal(edge.ambiguous.notes,'');assert.equal(edge.linked.notes,'Não escolher 2');assert.equal(edge.variant.notes,'');assert.equal(edge.private.notes,'Execução própria');assert.equal(edge.accent.notes,catalog[0].notes);
  await page.evaluate(()=>{workoutStudentId='a';workoutPlanId='pa';openWorkoutDay('d')});const card=page.locator('.workout-exercise[data-exercise-id="ea"]');await card.locator('summary').click();assert.ok(await card.locator('details').evaluate(n=>n.open));assert.ok((await card.innerText()).includes(catalog[0].notes));assert.ok((await card.innerText()).includes(catalog[0].observations));
  await page.evaluate(()=>openWorkoutExerciseEditor('ea'));assert.equal(await page.locator('#workoutExerciseNotes').inputValue(),catalog[0].notes);assert.equal(await page.locator('#workoutExerciseObservations').inputValue(),catalog[0].observations);
  const student=await context.newPage();student.on('pageerror',e=>errors.push(e.message));await student.goto('http://127.0.0.1:'+server.address().port+'/index.html');await student.waitForFunction(()=>!!window.APstudentUI);
  const stale=JSON.parse(JSON.stringify(areas[0]));stale.plans[0].days[0].exercises[0].description='';stale.plans[0].days[0].exercises[0].notes='';
  await student.evaluate(area=>{window.__AP_STUDENT_CONTEXT={storageId:'guidance_a',role:'student',area,profile:area.profile};APstudentUI.activate();openExerciseHub('pa~d');beginExerciseWorkout();saveExerciseLoad(0,0,'37.5');toggleExerciseSet(0,0);openExerciseDetail(0);setExerciseTab('description')},stale);
  const active=await student.evaluate(()=>JSON.stringify(exGetSession()));
  await student.evaluate(area=>{window.__AP_STUDENT_CONTEXT.area=area;renderExerciseApp();setExerciseTab('description')},areas[0]);
  const shown=await student.locator('#exTabContent').innerText();assert.ok(shown.includes(catalog[0].notes));assert.ok(shown.includes(catalog[0].observations));assert.equal(await student.evaluate(()=>JSON.stringify(exGetSession())),active,'instruction refresh does not modify the active session');
  assert.equal(await page.evaluate(()=>JSON.stringify(state.workoutPlans)),before);assert.equal(await page.evaluate(()=>state.customData.keep),42);assert.deepEqual(errors,[]);
  console.log('PASS: screenshot Leg Press Horizontal; existing PDF imports, missing/stale catalog IDs and guidanceVersion; independent source-first instructions/observations; exact matching, ambiguity and variants; three automatically staged student packets; teacher card expansion/editor; student description refresh during active workout with sets, loads, timer and original prescriptions preserved. Firebase simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
