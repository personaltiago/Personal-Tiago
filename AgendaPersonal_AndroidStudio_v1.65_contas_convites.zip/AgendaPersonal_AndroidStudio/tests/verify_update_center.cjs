'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),next=JSON.parse(fs.readFileSync(path.join(root,'web/native-release.agenda.json'))),base=next;
const catalog=JSON.parse(script(next,'ap-release-center').match(/const catalog=Object\.freeze\((\[.*\])\.sort/)[1]);
const clone=x=>JSON.parse(JSON.stringify(x));
function script(release,id,page='index.html',tag='script'){const m=release.files[page].match(new RegExp('<'+tag+'\\b[^>]*\\bid="'+id+'"[^>]*>([\\s\\S]*?)<\\/'+tag+'>'));assert.ok(m,id);return m[1]}
class Node{
 constructor(tag,doc){this.tagName=tag.toUpperCase();this.doc=doc;this.children=[];this.attrs={};this.dataset={};this.events={};this.hidden=false;this.open=false;this.disabled=false;this.style={setProperty(){}};this.textContent='';this.value='';this.isConnected=true;this.offsetHeight=130;this.classList={add(){},remove(){},toggle(){},contains:name=>(this.attrs.class||'').split(/\s+/).includes(name)}}
 set id(value){this._id=value;this.doc.ids.set(value,this)}get id(){return this._id}
 set innerHTML(html){this._html=String(html);this.children=[];const stack=[this];for(const m of this._html.matchAll(/<(\/?)([a-z][a-z0-9-]*)\b([^>]*)>/gi)){
  if(m[1]){while(stack.length>1){const n=stack.pop();if(n.tagName===m[2].toUpperCase())break}continue}
  const n=new Node(m[2],this.doc);for(const a of m[3].matchAll(/([\w-]+)="([^"]*)"/g))n.setAttribute(a[1],a[2]);n.hidden=/(?:^|\s)hidden(?:\s|$)/.test(m[3]);n.disabled=/(?:^|\s)disabled(?:\s|$)/.test(m[3]);stack.at(-1).appendChild(n);
  if(!['input','br','hr','img','meta','link','source','wbr'].includes(m[2].toLowerCase())&&!m[3].endsWith('/'))stack.push(n);
 }}get innerHTML(){return this._html||''}
 setAttribute(name,value){this.attrs[name]=String(value);if(name==='id')this.id=value;if(name.startsWith('data-'))this.dataset[name.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=String(value)}
 hasAttribute(name){return Object.hasOwn(this.attrs,name)}getAttribute(name){return this.attrs[name]??null}
 appendChild(child){child.parentElement=this;this.children.push(child);return child}append(...children){for(const child of children)this.appendChild(child)}
 remove(){if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(n=>n!==this);this.isConnected=false}
 click(){this.doc.clicked=this;if(this.onclick)this.onclick()}
 matches(selector){return selector.split(',').some(s=>{s=s.trim();if(s==='[hidden]')return this.hidden;if(s==='dialog:not([open])')return this.tagName==='DIALOG'&&!this.open;if(s.startsWith('#'))return this.id===s.slice(1);if(s.startsWith('.'))return this.classList.contains(s.slice(1));if(s.startsWith('['))return this.hasAttribute(s.slice(1,-1));return this.tagName===s.toUpperCase()})}
 querySelectorAll(selector){const all=[];const walk=n=>{for(const child of n.children){all.push(child);walk(child)}};walk(this);return all.filter(n=>n.matches(selector))}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null}
 contains(n){while(n){if(n===this)return true;n=n.parentElement}return false}
 closest(selector){let n=this;while(n){if(n.matches(selector))return n;n=n.parentElement}return null}
 getBoundingClientRect(){return this.rect||{left:290,right:332,top:150,bottom:194,width:42,height:44}}
 addEventListener(type,fn){(this.events[type]??=[]).push(fn)}emit(type,event={}){for(const fn of this.events[type]||[])fn(event)}
 focus(){this.doc.activeElement=this}showModal(){this.open=true}close(){this.open=false;this.emit('close')}
 replaceChildren(...nodes){this.children=[];this.append(...nodes)}
}
class Document{
 constructor(){this.ids=new Map();this.events={};this.body=new Node('body',this);this.head=new Node('head',this);this.activeElement=new Node('button',this);this.hidden=false;this.readyState='complete'}
 getElementById(id){return this.ids.get(id)||null}createElement(tag){return new Node(tag,this)}querySelectorAll(selector){return this.body.querySelectorAll(selector)}addEventListener(type,fn){(this.events[type]??=[]).push(fn)}
}
const initial={students:[{id:'s1',name:'Ana'}],workoutPlans:[{id:'p',name:'Treino A'}],workoutExecutions:[{id:'done',loads:[10,12]}],payments:[{id:'payment',amount:110000}],documents:[{id:'pdf',body:'BASE64-preservado'}],customData:{retain:true},teacherFeatures:{version:1,autoRest:true,compactCompleted:true,feedbackSymbol:true,duplicateVideoWarning:true,futureOption:'keep'}};
function fixture({frame=true,storage:newStorage}={}){
 const storage=newStorage||new Map([['agendaPersonalTL_v1',JSON.stringify(initial)]]),doc=new Document(),events={};let uid='teacher-one',writeFailure=false,readFailure=false,status={installedVersion:'1.12.215',installedSequence:321,installedContentSha256:'a'.repeat(64),contentVerified:true};let installs=0,publishes=0,canInstall=true,decorates=0,syncs=0,finds=0;
 const localStorage={getItem:key=>{if(readFailure)throw Error('read failed');return storage.get(key)??null},setItem:(key,value)=>{if(writeFailure)throw Error('quota');storage.set(key,String(value))}};
 const c={document:doc,localStorage,console,Date,setTimeout:()=>1,clearTimeout(){},addEventListener:(type,fn)=>(events[type]??=[]).push(fn),APaccounts:{isTeacher:()=>!!uid,teacherUid:()=>uid},Android:{getUpdateStatus:()=>JSON.stringify(status),openUpdates(){installs++}},APupdates:{canInstall:()=>canInstall,openPublisher(){publishes++}},__agendaNativeBootReady:true,__agendaNativeReleaseSequence:321};c.window=c;
 vm.createContext(c);vm.runInContext(script(next,'ap-nonbear-reactions'),c);vm.runInContext(script(next,'ap-mascot-closeup'),c);
 const td=new Document(),get=id=>td.getElementById(id)||(()=>{const n=td.createElement('div');n.id=id;return n})();
 for(const id of ['workoutVideoDuplicateWarning','workoutVideoDuplicateList','workoutVideoDuplicateTitle'])get(id);
 get('workoutExerciseVideo').value='https://youtu.be/abcdefghijk';get('workoutExerciseName').value='Exercício atual';for(const id of ['workoutExerciseCatalogId','workoutExercisePlanId','workoutExerciseDayId','workoutExerciseEditId'])get(id).value='';
 const t={document:td,localStorage,console,Date,state:JSON.parse(storage.get('agendaPersonalTL_v1')||'{}'),DB_KEY:'agendaPersonalTL_v1',parent:c,APWorkoutCorrections:{decorate(){decorates++}},APTeacherSync:{changed(){syncs++}},APVideoDuplicates:{find(){finds++;return[{name:'Outro exercício'}]}},normalizedWorkoutVideoUrl:x=>x,workoutExerciseMode:'day',workoutCatalogItems:()=>[],getComputedStyle(){}};t.window=t;
 vm.createContext(t);vm.runInContext(script(next,'ap-teacher-features','professor.html'),t);vm.runInContext(script(next,'ap-video-duplicates-ui','professor.html'),t);
 const iframe=doc.createElement('iframe');iframe.id='apPreviewTeacher';if(frame)iframe.setAttribute('srcdoc','teacher');iframe.contentWindow=t;
 vm.runInContext(script(next,'ap-release-center'),c);
 const f={c,t,doc,td,storage,get,events,open:()=>c.APReleaseCenter.openConference(),items:()=>clone(c.APReleaseCenter.items()),node:id=>doc.getElementById(id),emit:(type,detail)=>{for(const fn of events[type]||[])fn({detail})},action(id,action='review'){
  const b=doc.createElement('button');b.setAttribute('data-release-action','menu');b.setAttribute('data-feature',id);doc.activeElement=b;f.node('apReleaseCenter').emit('click',{target:b});if(catalog.some(item=>item.id===id))f.node(action==='details'?'apReleasePopupDetails':'apReleaseDelete').onclick();
 },confirm(){f.node('apReleaseConfirm').onclick()},cancel(){f.node('apReleaseDetailCancel').onclick()},filter(value){const b=doc.createElement('button');b.setAttribute('data-release-filter',value);f.node('apReleaseCenter').emit('click',{target:b})},set uid(value){uid=value},set fail(value){writeFailure=value},set readFail(value){readFailure=value},set status(value){status=value},set canInstall(value){canInstall=value},get installs(){return installs},get publishes(){return publishes},get decorates(){return decorates},get syncs(){return syncs},get finds(){return finds}};
 return f;
}
let groups=0;async function test(name,fn){await fn();groups++;console.log('PASS '+name)}
function nativeDownloads(f,releases){
 const calls=[];f.c.Android.getUpdateDownloadVersion=()=>1;f.c.Android.getUpdateDownloadOptions=()=>JSON.stringify({ok:true,releases});f.c.Android.downloadUpdate=(...args)=>{calls.push(args);return true};return calls;
}
function downloadCard(f,id){
 f.open();const anchor=f.node('apReleaseCatalog').querySelectorAll('[data-release-action]').find(n=>n.dataset.feature===id);assert.ok(anchor,id);
 f.node('apReleaseCenter').emit('click',{target:anchor});assert.ok(f.node('apReleasePopupDownload'));f.node('apReleasePopupDownload').onclick();return anchor;
}
const archived={id:'installed',current:true,version:'1.12.215',sequence:321,filename:'AgendaPersonal-1.12.215.agenda.json',contentSha256:'2'.repeat(64)};
async function main(){
 await test('Reviewed bundled pages match the 1.12.268 release',()=>{
  const hash=value=>require('node:crypto').createHash('sha256').update(value).digest('hex');
  for(const [name,expected]of Object.entries({"professor.html": "a4ba18e7a7eb9f47251bc772fd8782efd5b5b79763546e79405707aa1a33c73c", "avaliacoes.html": "bfed1eff86754389b3ccb15ccf947df1cd7856a6a67ea1e3f260c804b845d521", "cadastro.html": "3bbcc3a9a8dfed00b8cb0fa976ee9fda5cb58d0a909822bd19e0efdf4be75ffe"}))assert.equal(hash(next.files[name]),expected);
  let html=next.files['index.html'];for(const id of ['ap-release-center','ap-release-center-css']){const tag=id.endsWith('css')?'style':'script';html=html.replace(script(next,id,'index.html',tag),id)}
  assert.equal(hash(html),"36b68d79cb440e39871e0e747a37e031da058c54be393c456291bb41d2df2069");assert.equal(next.version,'1.12.268');assert.equal(next.sequence,374);
 });
 await test('37 ordered named cards; six removable and 31 integrated; history records one real install',()=>{
  const f=fixture();assert.equal(f.open(),true);const items=f.items();assert.equal(items.length,37);assert.equal(items[0].version,'1.12.234');assert.equal(items.at(-1).version,'1.12.187');assert.equal(items.filter(x=>x.kind==='active').length,6);assert.equal(items.filter(x=>x.kind==='integrated').length,31);
  const html=f.node('apReleaseCatalog').innerHTML;assert.equal((html.match(/data-feature-id=/g)||[]).length,37);assert.equal((html.match(/data-release-action="menu"/g)||[]).length,37);assert.doesNotMatch(html,/>Apagar<|>Detalhes</);assert.match(html,/Aproximação do pet/);assert.match(html,/1\.12\.210/);
  const history=JSON.parse(f.storage.get('agenda_release_history_v1_teacher-one'));assert.equal(history.length,1);assert.equal(history[0].version,'1.12.215');assert.match(f.node('apReleaseTitle').innerHTML||f.node('apReleaseCenter').innerHTML,/Conferência de atualizações/);
 });
 await test('Each of four teacher features can remove/restore alone, cancel safely and survive JSON reload',()=>{
  for(const item of catalog.filter(x=>x.adapter==='teacher')){
   const f=fixture();f.open();const before=clone(f.t.state);f.action(item.id);assert.ok(f.node('apReleaseDetail').open);assert.equal(f.node('apReleaseConfirm').textContent,'Desativar');assert.match(f.node('apReleaseDetailBody').innerHTML,/preservad|continuam|mantidos/i);f.cancel();assert.deepEqual(clone(f.t.state),before);
   f.action(item.id);f.confirm();assert.equal(f.t.state.teacherFeatures[item.key],false);assert.equal(f.items().find(x=>x.id===item.id).kind,'removed');
   const expected=clone(before);expected.teacherFeatures[item.key]=false;assert.deepEqual(clone(f.t.state),expected);assert.deepEqual(JSON.parse(f.storage.get('agendaPersonalTL_v1')),expected);
   const reloaded=fixture({storage:f.storage});reloaded.open();assert.equal(reloaded.items().find(x=>x.id===item.id).kind,'removed');reloaded.action(item.id);assert.equal(reloaded.node('apReleaseConfirm').textContent,'Reativar');reloaded.confirm();assert.deepEqual(clone(reloaded.t.state),before);
  }
 });
 await test('Pet removal uses actual 210 preference without writing rewards, colours or student/teacher records',()=>{
  const f=fixture();f.open();const data=f.storage.get('agendaPersonalTL_v1');f.action('pet-approach');f.confirm();assert.equal(f.c.APMascotCloseup.isEnabled(),false);assert.equal(f.items().find(x=>x.id==='pet-approach').kind,'removed');assert.equal(f.storage.get('agendaPersonalTL_v1'),data);
  assert.equal(f.storage.get('agenda_pet_closeup_v1_teacher%3Ateacher-one'),'false');f.action('pet-approach');f.confirm();assert.equal(f.c.APMascotCloseup.isEnabled(),true);assert.equal(f.storage.get('agendaPersonalTL_v1'),data);
 });
 await test('Non-bear recovery can be removed/restored without changing bear/approach preferences, rewards or saved records',()=>{
  const f=fixture();f.open();const before=f.storage.get('agendaPersonalTL_v1');let cancellations=0;
  f.c.APMascotPetting={cancelAll(){cancellations++}};
  assert.equal(f.c.APNonBearReactions.isEnabled(),true);f.action('non-bear-reactions');f.cancel();assert.equal(f.c.APNonBearReactions.isEnabled(),true);
  f.action('non-bear-reactions');f.confirm();assert.equal(f.c.APNonBearReactions.isEnabled(),false);assert.equal(f.items().find(x=>x.id==='non-bear-reactions').kind,'removed');
  assert.equal(f.c.APMascotCloseup.isEnabled(),true);assert.equal(cancellations,0);assert.equal(f.storage.get('agendaPersonalTL_v1'),before);
  const reload=fixture({storage:f.storage});reload.open();assert.equal(reload.c.APNonBearReactions.isEnabled(),false);reload.action('non-bear-reactions');reload.confirm();assert.equal(reload.c.APNonBearReactions.isEnabled(),true);
  const failing=fixture();failing.open();failing.action('non-bear-reactions');failing.fail=true;failing.confirm();assert.equal(failing.c.APNonBearReactions.isEnabled(),true);assert.ok(failing.node('apReleaseDetail').open);
 });
 await test('Quota failure keeps old state and confirmation open; retry applies once; callback errors do not misreport a saved setting',()=>{
  const f=fixture();f.open();f.action('auto-rest');const before=clone(f.t.state);f.fail=true;f.confirm();assert.deepEqual(clone(f.t.state),before);assert.ok(f.node('apReleaseDetail').open);assert.match(f.node('apReleaseDetailStatus').textContent,/Não foi possível salvar/);f.fail=false;f.t.APWorkoutCorrections.decorate=()=>{throw Error('paint failed')};f.confirm();f.confirm();assert.equal(f.t.state.teacherFeatures.autoRest,false);assert.equal(f.node('apReleaseDetail').open,false);assert.equal(f.syncs,1);
 });
 await test('Account change and student/preview context cannot use a pending confirmation',()=>{
  const f=fixture();f.open();f.action('auto-rest');const before=f.storage.get('agendaPersonalTL_v1');f.uid='teacher-two';f.emit('ap-account-changed');assert.equal(f.node('apReleaseCenter').hidden,true);assert.equal(f.node('apReleaseDetail').open,false);f.confirm();assert.equal(f.storage.get('agendaPersonalTL_v1'),before);
  const student=fixture();student.c.__AP_STUDENT_CONTEXT={role:'student',storageId:'s1'};assert.equal(student.open(),false);assert.equal(student.c.APReleaseCenter.items().length,0);
 });
 await test('Fallback without open iframe preserves full agenda; malformed agenda never offers a fake successful deletion',()=>{
  const f=fixture({frame:false});f.open();const before=JSON.parse(f.storage.get('agendaPersonalTL_v1'));f.action('compact-completed');f.confirm();const expected=clone(before);expected.teacherFeatures.compactCompleted=false;assert.deepEqual(JSON.parse(f.storage.get('agendaPersonalTL_v1')),expected);
  const malformed=fixture({frame:false});malformed.storage.set('agendaPersonalTL_v1','broken');malformed.open();assert.equal(malformed.items().filter(x=>x.kind==='unavailable').length,4);malformed.action('auto-rest');malformed.confirm();assert.equal(malformed.storage.get('agendaPersonalTL_v1'),'broken');assert.ok(malformed.node('apReleaseConfirm').hidden);
 });
 await test('Integrated/unknown features cannot be deleted; Details explains limit; Back closes detail before central',()=>{
  const f=fixture();f.open();const before=f.storage.get('agendaPersonalTL_v1');f.action('student-evolution','details');assert.match(f.node('apReleaseDetailBody').innerHTML,/reversão individual/);assert.ok(f.node('apReleaseConfirm').hidden);assert.equal(f.c.APReleaseCenter.close(),true);assert.equal(f.node('apReleaseCenter').hidden,false);assert.equal(f.c.APReleaseCenter.close(),true);assert.equal(f.node('apReleaseCenter').hidden,true);
  f.open();f.action('student-evolution');f.confirm();assert.equal(f.storage.get('agendaPersonalTL_v1'),before);f.cancel();f.action('__proto__');f.confirm();assert.equal(f.storage.get('agendaPersonalTL_v1'),before);
 });
 await test('Filters show real active/removed states and changes in another view are rechecked before confirmation',()=>{
  const f=fixture();f.open();f.filter('active');assert.equal((f.node('apReleaseCatalog').innerHTML.match(/data-feature-id=/g)||[]).length,6);f.action('auto-rest');f.confirm();assert.equal((f.node('apReleaseCatalog').innerHTML.match(/data-feature-id=/g)||[]).length,5);f.filter('removed');assert.match(f.node('apReleaseCatalog').innerHTML,/Desativada/);f.filter('integrated');assert.equal((f.node('apReleaseCatalog').innerHTML.match(/data-feature-id=/g)||[]).length,31);
  f.action('compact-completed');f.t.APTeacherFeatures.set('compactCompleted',false);f.confirm();assert.match(f.node('apReleaseStatus').textContent,/já mudou/);assert.equal(f.t.state.teacherFeatures.compactCompleted,false);
 });
 await test('Only boot-confirmed history is recorded; equal/lower labels with different content remain distinct and notes are escaped',()=>{
  const f=fixture();f.c.__agendaNativeBootReady=false;f.c.APReleaseCenter.observe();assert.equal(f.storage.get('agenda_release_history_v1_teacher-one'),undefined);f.c.__agendaNativeBootReady=true;f.status={installedVersion:'1.12.215',installedSequence:321,contentVerified:false};f.c.APReleaseCenter.observe();assert.equal(f.storage.get('agenda_release_history_v1_teacher-one'),undefined);
  f.status={installedVersion:'1.12.215',installedSequence:321,installedContentSha256:'a'.repeat(64),contentVerified:true};f.c.APReleaseCenter.observe();f.c.APReleaseCenter.observe();assert.equal(JSON.parse(f.storage.get('agenda_release_history_v1_teacher-one')).length,1);
  f.status={installedVersion:'1.12.215',installedSequence:321,installedContentSha256:'b'.repeat(64),contentVerified:true};f.c.APReleaseCenter.observe();assert.equal(JSON.parse(f.storage.get('agenda_release_history_v1_teacher-one')).length,2);
  f.c.__agendaNativeReleaseSequence=305;f.status={installedVersion:'1.12.199',installedSequence:305,installedContentSha256:'c'.repeat(64),contentVerified:true,manifest:{version:'1.12.199',sequence:305,notes:'<img src=x onerror=bad> detalhe'}};f.c.APReleaseCenter.observe();f.open();assert.equal(JSON.parse(f.storage.get('agenda_release_history_v1_teacher-one')).length,3);assert.match(f.node('apReleaseHistory').innerHTML,/&lt;img/);assert.doesNotMatch(f.node('apReleaseHistory').innerHTML,/<img/);
 });
 await test('Menu routing preserves native installer safety and publishing; old iframe flags stay unavailable',()=>{
  const f=fixture();f.c.APReleaseCenter.open();f.canInstall=false;f.node('apUpdateImport').onclick();assert.equal(f.installs,0);assert.equal(f.node('apUpdateMenu').hidden,false);f.canInstall=true;f.node('apUpdateImport').onclick();assert.equal(f.installs,1);assert.equal(f.node('apUpdateMenu').hidden,true);f.c.APReleaseCenter.open();f.node('apUpdatePublish').onclick();assert.equal(f.publishes,1);
  const old=fixture();old.t.APTeacherFeatures={read:()=>({autoRest:true,compactCompleted:true}),set(){throw Error('Unsupported')}};old.open();assert.equal(old.items().filter(x=>x.kind==='unavailable').length,2);
 });
 await test('Video warning disappears and restores through actual UI adapter, leaving entered link/name untouched',()=>{
  const f=fixture();f.open();f.t.APVideoDuplicateUI.refresh();assert.equal(f.get('workoutVideoDuplicateWarning').hidden,false);const name=f.get('workoutExerciseName').value,link=f.get('workoutExerciseVideo').value,count=f.finds;f.action('duplicate-video-warning');f.confirm();assert.equal(f.get('workoutVideoDuplicateWarning').hidden,true);assert.equal(f.finds,count);f.action('duplicate-video-warning');f.confirm();assert.equal(f.get('workoutVideoDuplicateWarning').hidden,false);assert.ok(f.finds>count);assert.equal(f.get('workoutExerciseName').value,name);assert.equal(f.get('workoutExerciseVideo').value,link);
 });
 await test('Actual feedback PNG keeps original symbol by default; removal restores teacher name only; restoration returns logo',async()=>{
  class Context{
   constructor(){this.ops=[];this.saved=[];this.fillStyle='#000';this.font='10px Arial';this.textAlign='left';this.textBaseline='top'}
   save(){this.saved.push({fillStyle:this.fillStyle,font:this.font,textAlign:this.textAlign,textBaseline:this.textBaseline})}restore(){Object.assign(this,this.saved.pop())}
   translate(){}scale(){}beginPath(){}roundRect(){}arc(){}clip(){}stroke(){}
   fill(path){if(path?.value)this.ops.push({kind:'symbol',value:path.value,color:this.fillStyle})}
   fillRect(...args){this.ops.push({kind:'rect',args,color:this.fillStyle})}
   fillText(text,x,y){this.ops.push({kind:'text',text,x,y,color:this.fillStyle,font:this.font,align:this.textAlign})}
   measureText(text){return{width:String(text).length*Number(this.font.match(/(\d+)px/)?.[1]||24)*.52}}
  }
  class Canvas{constructor(){this.ctx=new Context()}getContext(){return this.ctx}}
  const f=fixture();f.open();
  const load=(release,target)=>{target.document.createElement=tag=>{assert.equal(tag,'canvas');return new Canvas()};target.Path2D=class{constructor(value){this.value=value}};vm.runInContext(script(release,'ap-feedback-model','professor.html'),target);vm.runInContext(script(release,'ap-feedback-card','professor.html'),target)};
  load(next,f.t);const previous={document:{},console,Date};previous.window=previous;vm.createContext(previous);load(base,previous);
  const data={id:'feedback-one',studentName:'Ana Silva',source:'presencial',startedAt:Date.parse('2026-11-02T16:00:00Z'),finishedAt:Date.parse('2026-11-02T16:45:00Z'),durationSeconds:2700,teacherEvaluation:{effort:7,note:'Boa execução.'},response:{intensity:'Moderada',comment:'Ótimo treino.'}};
  for(const accent of ['#b6ff26','#b574ee']){
   const options={professional:'Tiago Lima',accent},original=await previous.APFeedbackCard.create(data,options),active=await f.t.APFeedbackCard.create(data,options);
   assert.deepEqual(clone(active.ctx.ops),clone(original.ctx.ops));assert.ok(active.ctx.ops.some(x=>x.kind==='symbol'&&x.color===accent));
   f.action('feedback-symbol');f.confirm();const removed=await f.t.APFeedbackCard.create(data,options);assert.ok(!removed.ctx.ops.some(x=>x.kind==='symbol'));assert.ok(removed.ctx.ops.some(x=>x.text==='Tiago Lima'));
   assert.deepEqual(clone(removed.ctx.ops.filter(x=>!(x.kind==='text'&&x.y>=146&&x.y<220))),clone(active.ctx.ops.filter(x=>x.kind!=='symbol')));
   f.action('feedback-symbol');f.confirm();const restored=await f.t.APFeedbackCard.create(data,options);assert.deepEqual(clone(restored.ctx.ops),clone(original.ctx.ops));
  }
 });
 await test('Main menu has the eight actions in the supplied order, all stacked, with no deletion button; Details and close work separately',()=>{
  const f=fixture();assert.equal(f.c.APReleaseCenter.open(),true);const menu=f.node('apUpdateMenu');
  assert.deepEqual(menu.querySelectorAll('.ap-update-menu-action').map(n=>n.id),['apUpdateModular','apUpdateImport','apUpdateRestore','apUpdateConference','apUpdateDetails','apUpdateVerify','apUpdatePublish','apUpdateClose']);
  assert.doesNotMatch(menu.innerHTML,/Apagar/);assert.match(menu.innerHTML,/Conferência de atualizações/);
  f.node('apUpdateDetails').onclick();assert.equal(f.node('apPackageDetail').open,true);assert.equal(f.node('apPackageDetailVersion').textContent,'Versão 1.12.215');
  assert.equal(f.c.APReleaseCenter.close(),true);assert.equal(f.node('apPackageDetail').open,false);assert.equal(menu.hidden,false);
  f.node('apUpdateConference').onclick();assert.equal(menu.hidden,true);assert.equal(f.node('apReleaseCenter').hidden,false);
  f.node('apReleaseBack').onclick();assert.equal(f.node('apReleaseCenter').hidden,true);assert.equal(menu.hidden,false);
  f.node('apUpdateClose').onclick();assert.equal(menu.hidden,true);
  const css=script(next,'ap-release-center-css','index.html','style');assert.match(css,/\.ap-update-menu-actions\{display:grid;grid-template-columns:minmax\(0,1fr\)/);
 });
 await test('Three-dot menu uses separate Desativar and Detalhes actions, restores focus and fits both normal and zoomed narrow viewports',()=>{
  const f=fixture();f.open();const anchor=f.node('apReleaseCatalog').querySelectorAll('[data-release-action]').find(n=>n.dataset.feature==='non-bear-reactions');
  f.c.innerWidth=320;f.c.innerHeight=600;anchor.rect={left:270,right:312,top:540,bottom:584,width:42,height:44};
  f.node('apReleaseCenter').emit('click',{target:anchor});const popup=f.node('apReleasePopup');
  assert.equal(popup.hidden,false);assert.equal(f.node('apReleaseDeleteLabel').textContent,'Desativar');assert.equal(f.node('apReleaseDelete').disabled,false);assert.equal(anchor.getAttribute('aria-expanded'),'true');
  assert.ok(parseFloat(popup.style.left)>=12);assert.ok(parseFloat(popup.style.left)+parseFloat(popup.style.width)<=308);assert.ok(parseFloat(popup.style.top)<anchor.rect.top);
  f.node('apReleasePopupDetails').onclick();assert.equal(popup.hidden,true);assert.equal(f.node('apReleaseDetail').open,true);assert.match(f.node('apReleaseDetailBody').innerHTML,/seis pelagens/);f.cancel();assert.equal(f.doc.activeElement,anchor);
  f.c.visualViewport={width:190,height:220,offsetLeft:30,offsetTop:15};f.node('apReleaseCenter').emit('click',{target:anchor});
  assert.ok(parseFloat(popup.style.left)>=42);assert.ok(parseFloat(popup.style.left)+parseFloat(popup.style.width)<=208);assert.ok(parseFloat(popup.style.top)>=27);assert.ok(parseFloat(popup.style.maxHeight)<=196);
  f.node('apReleaseDelete').onclick();assert.equal(f.node('apReleaseConfirm').textContent,'Desativar');f.cancel();assert.equal(f.c.APNonBearReactions.isEnabled(),true);
 });
 await test('Integrated changes expose Details and an honestly disabled Apagar; popup keyboard navigation and Escape do not close the wrong layer',()=>{
  const f=fixture();f.open();const root=f.node('apReleaseCenter'),anchors=f.node('apReleaseCatalog').querySelectorAll('[data-release-action]');
  const integrated=anchors.find(n=>n.dataset.feature==='update-center');root.emit('click',{target:integrated});assert.equal(f.node('apReleaseDelete').disabled,true);assert.equal(f.node('apReleasePopupHint').hidden,false);f.node('apReleasePopupDetails').onclick();assert.match(f.node('apReleaseDetailBody').innerHTML,/não possui remoção individual/);f.cancel();
  const anchor=anchors.find(n=>n.dataset.feature==='auto-rest');root.emit('click',{target:anchor});let prevented=false;
  root.emit('keydown',{key:'ArrowDown',preventDefault(){prevented=true}});assert.ok(prevented);assert.equal(f.doc.activeElement,f.node('apReleasePopupDetails'));
  root.emit('keydown',{key:'ArrowUp',preventDefault(){}});assert.equal(f.doc.activeElement,f.node('apReleaseDelete'));
  root.emit('keydown',{key:'Tab',preventDefault(){}});assert.equal(f.node('apReleasePopup').hidden,true);assert.equal(f.doc.activeElement,anchor);
  root.emit('click',{target:anchor});root.emit('keydown',{key:'Escape',preventDefault(){}});assert.equal(f.node('apReleasePopup').hidden,true);assert.equal(root.hidden,false);
 });
 await test('The updated menu opens the modular panel and dispatches native actions',()=>{
  const f=fixture();let opened=0;f.c.APModularUpdates={open(){opened++}};
  assert.equal(f.c.APReleaseCenter.open(),true);assert.equal(f.installs,0);
  f.node('apUpdateModular').onclick();assert.equal(opened,1);assert.equal(f.node('apUpdateMenu').hidden,true);
  f.uid='';assert.equal(f.c.APReleaseCenter.open(),false);
  const direct=fixture(),actions=[];direct.c.Android.openUpdateAction=action=>actions.push(action);
  for(const [id,action]of[['apUpdateImport','import'],['apUpdateRestore','restore']]){direct.c.APReleaseCenter.open();direct.node(id).onclick();assert.equal(actions.at(-1),action);assert.equal(direct.node('apUpdateMenu').hidden,true)}
  direct.c.APReleaseCenter.open();direct.node('apUpdateVerify').onclick();assert.equal(direct.installs,1);assert.equal(direct.node('apUpdateMenu').hidden,true);
  direct.c.APReleaseCenter.open();direct.c.Android.openUpdateAction=()=>{throw Error('bridge unavailable')};direct.node('apUpdateImport').onclick();assert.equal(direct.node('apUpdateMenu').hidden,false);assert.match(direct.node('apUpdateMenuStatus').textContent,/Não foi possível/);
 });
 await test('Account change closes the menu even with its Details dialog open; students cannot open conference, menus or pending deletion',()=>{
  const f=fixture();f.c.APReleaseCenter.open();f.node('apUpdateDetails').onclick();assert.equal(f.node('apPackageDetail').open,true);
  f.uid='teacher-two';f.emit('ap-account-changed');assert.equal(f.node('apUpdateMenu').hidden,true);assert.equal(f.node('apPackageDetail').open,false);
  f.c.__AP_STUDENT_CONTEXT={role:'student',storageId:'student-one'};assert.equal(f.c.APReleaseCenter.open(),false);assert.equal(f.c.APReleaseCenter.openConference(),false);
  assert.equal(f.storage.get('agendaPersonalTL_v1'),JSON.stringify(initial));
 });
 await test('Integrated pet poses have Download beside disabled Apagar; the current file is explicit and no installation or student write occurs',()=>{
  const f=fixture(),calls=nativeDownloads(f,[archived]),before=f.storage.get('agendaPersonalTL_v1');const anchor=downloadCard(f,'individual-pet-poses');
  assert.equal(f.node('apReleaseDelete').disabled,true);assert.equal(f.node('apReleaseDownload').open,true);assert.equal(f.node('apReleaseDownloadFile').textContent,archived.filename);
  assert.match(f.node('apReleaseDownloadDescription').textContent,/pacote completo/);assert.equal(f.node('apReleaseDownloadConfirm').hidden,false);
  assert.equal(calls.length,0);f.node('apReleaseDownloadConfirm').onclick();assert.equal(calls.length,1);assert.deepEqual(calls[0].slice(0,2),[archived.id,archived.contentSha256]);
  f.node('apReleaseDownloadConfirm').onclick();assert.equal(calls.length,1);assert.equal(f.node('apReleaseDownloadCancel').disabled,true);
  f.c.APReleaseCenter.close();assert.equal(f.node('apReleaseDownload').open,true);
  f.emit('ap-update-download-result',{requestId:calls[0][2],status:'choosing'});assert.match(f.node('apReleaseDownloadStatus').textContent,/onde salvar/);
  f.emit('ap-update-download-result',{requestId:calls[0][2],status:'saving'});assert.match(f.node('apReleaseDownloadStatus').textContent,/Salvando/);
  f.emit('ap-update-download-result',{requestId:calls[0][2],status:'saved',version:archived.version});assert.match(f.node('apReleaseDownloadStatus').textContent,/1\.12\.215 salva/);
  assert.equal(f.node('apReleaseDownloadCancel').disabled,false);f.node('apReleaseDownloadCancel').onclick();assert.equal(f.node('apReleaseDownload').open,false);assert.equal(f.doc.activeElement,anchor);
  assert.equal(f.installs,0);assert.equal(f.publishes,0);assert.equal(f.storage.get('agendaPersonalTL_v1'),before);
 });
 await test('Download cancellation, failure, refusal and unrelated callbacks leave the existing package and allow a retry',()=>{
  for(const outcome of ['cancelled','error','refused']){
   const f=fixture(),calls=nativeDownloads(f,[archived]);downloadCard(f,'individual-pet-poses');
   if(outcome==='refused')f.c.Android.downloadUpdate=()=>false;
   f.node('apReleaseDownloadConfirm').onclick();
   if(outcome!=='refused'){
    f.emit('ap-update-download-result',{requestId:'different',status:'saved',version:'1.12.999'});assert.equal(f.node('apReleaseDownloadConfirm').disabled,true);
    f.emit('ap-update-download-result',{requestId:calls[0][2],status:outcome,message:'Não foi possível salvar.',version:archived.version});
   }
   assert.equal(f.node('apReleaseDownloadConfirm').disabled,false);assert.equal(f.node('apReleaseDownloadCancel').disabled,false);assert.equal(f.installs,0);assert.equal(f.storage.get('agendaPersonalTL_v1'),JSON.stringify(initial));
  }
 });
 await test('Only verified current code is downloadable; historical labels never become fake old files; old Android requests native support',()=>{
  const f=fixture();nativeDownloads(f,[{...archived,id:'seed_'+'1'.repeat(64),current:false}]);downloadCard(f,'individual-pet-poses');assert.equal(f.node('apReleaseDownloadConfirm').hidden,true);assert.match(f.node('apReleaseDownloadStatus').textContent,/confirmação/);
  const current=fixture(),calls=nativeDownloads(current,[archived]);downloadCard(current,'individual-pet-poses');assert.equal(current.node('apReleaseDownloadVersion').textContent,'Versão em uso: 1.12.215');assert.equal(current.node('apReleaseDownloadFile').textContent,'AgendaPersonal-1.12.215.agenda.json');assert.match(current.node('apReleaseDownloadDescription').textContent,/versão em uso/);current.node('apReleaseDownloadConfirm').onclick();assert.equal(calls[0][0],'installed');
  const old=fixture();downloadCard(old,'individual-pet-poses');assert.equal(old.node('apReleaseDownloadConfirm').hidden,true);assert.match(old.node('apReleaseDownloadStatus').textContent,/Android 1\.168/);assert.equal(old.installs,0);
 });
 await test('Account switch closes download and stale callbacks cannot save, install or change any account data',()=>{
  const f=fixture(),calls=nativeDownloads(f,[archived]);downloadCard(f,'individual-pet-poses');f.node('apReleaseDownloadConfirm').onclick();f.uid='';f.emit('ap-account-changed');assert.equal(f.node('apReleaseDownload').open,false);
  f.emit('ap-update-download-result',{requestId:calls[0][2],status:'saved',version:archived.version});assert.equal(f.c.APReleaseCenter.openConference(),false);assert.equal(f.installs,0);assert.equal(f.storage.get('agendaPersonalTL_v1'),JSON.stringify(initial));
 });
 await test('Third popup item participates in keyboard navigation, and Escape closes only the download dialog',()=>{
  const f=fixture();nativeDownloads(f,[archived]);f.open();const root=f.node('apReleaseCenter'),anchor=f.node('apReleaseCatalog').querySelectorAll('[data-release-action]').find(n=>n.dataset.feature==='individual-pet-poses');root.emit('click',{target:anchor});root.emit('keydown',{key:'End',preventDefault(){}});assert.equal(f.doc.activeElement,f.node('apReleasePopupDownload'));
  f.node('apReleasePopupDownload').onclick();f.node('apReleaseDownload').emit('cancel',{preventDefault(){}});assert.equal(f.node('apReleaseDownload').open,false);assert.equal(root.hidden,false);assert.equal(f.doc.activeElement,anchor);
 });
 await test('Web downloads only the matching original current bundle; integrated resources save current code and incompatible code is unavailable',()=>{
  const f=fixture(),urls=[],revoked=[];delete f.c.Android;f.c.Blob=Blob;f.c.URL={createObjectURL:blob=>{urls.push(blob);return 'blob:current'},revokeObjectURL:url=>revoked.push(url)};
  const small={format:1,appId:'com.tiagolima.agendapersonal',bridgeVersion:3,dataSchema:4,version:'1.12.215',sequence:321,files:Object.fromEntries(['index.html','professor.html','avaliacoes.html','cadastro.html'].map(k=>[k,'<html>code only</html>']))},raw=JSON.stringify(small);
  f.c.APWebPlatform={getPublishableUpdate:()=>raw,getUpdateStatus:()=>JSON.stringify({installedVersion:'1.12.215',installedSequence:321})};downloadCard(f,'update-center');assert.equal(f.node('apReleaseDownloadConfirm').hidden,false);f.node('apReleaseDownloadConfirm').onclick();assert.equal(urls.length,1);assert.equal(f.doc.clicked.download,'AgendaPersonal-1.12.215.agenda.json');assert.equal(urls[0].size,Buffer.byteLength(raw));
  f.node('apReleaseDownloadCancel').onclick();downloadCard(f,'individual-pet-poses');assert.equal(f.node('apReleaseDownloadConfirm').hidden,false);assert.equal(f.node('apReleaseDownloadFile').textContent,'AgendaPersonal-1.12.215.agenda.json');assert.equal(urls.length,1);
  f.node('apReleaseDownloadCancel').onclick();f.c.APWebPlatform.getPublishableUpdate=()=>JSON.stringify({...small,bridgeVersion:2});downloadCard(f,'update-center');assert.equal(f.node('apReleaseDownloadConfirm').hidden,true);
 });
 console.log(JSON.stringify({groups,limit:'DOM, storage and native adapters simulated; no physical Android/iPhone layout test.'}));
}
main().catch(error=>{console.error(error);process.exitCode=1});
