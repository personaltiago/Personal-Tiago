/* Exercise production prescription/row/journal functions without a browser. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/professor.html'),'utf8');
function script(marker){const a=html.indexOf('<script '+marker);assert.ok(a>=0);const start=html.indexOf('>',a)+1,end=html.indexOf('</script>',start);return html.slice(start,end);}
function between(source,a,b){const start=source.indexOf(a),end=source.indexOf(b,start);assert.ok(start>=0&&end>start,a);return source.slice(start,end);}
const t=script('data-agenda-techniques'),s=script('data-agenda-workout-series'),b=script('data-agenda-bisets');
const elements=new Map(),messages=[];
const element=id=>{if(!elements.has(id))elements.set(id,{value:'',scrollTop:0});return elements.get(id);};
const ctx={state:{workoutDrafts:{},workoutRest:null},hesc:v=>String(v??'').replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;'),
  workoutDraftKey:(p,d)=>p+'|'+d,workoutPlanArchived:()=>false,workoutRunning:()=>true,
  toast:m=>messages.push(m),document:{getElementById:element,querySelector:()=>element('sheet')},
  renderWorkoutDay(){},renderGuide(){},focusGuideStep(){},closeDialog(){},cancelNativeWorkoutRest(){},
  restRemaining:()=>0,studentById:()=>({name:'Teste'}),id:(()=>{let n=0;return()=>String(++n);})(),
  armRest:r=>{ctx.state.workoutRest=r;},workoutExerciseDraft:(p,d,ex)=>ctx.state.workoutDrafts['p|d'].values?.[ex.id]||{},
  commitWorkoutChange:changes=>{if(ctx.failSave)return false;Object.assign(ctx.state,changes);return true;}};
ctx.window=ctx;vm.createContext(ctx);
vm.runInContext('(function(){'+between(t,'  const copy=','  const original=')+between(t,'  function normalize(','  function exerciseControls(')+'window.__tech={expanded,fields,seriesReps};})();',ctx);
vm.runInContext('(function(){'+between(s,'  const integer=','  function context(')+'window.__series={prescribed,entries};})();',ctx);
vm.runInContext('(function(){let audienceDay="";'+between(b,'  const integer=','  function groups(')+between(b,'  function groups(','  function groupById(')+between(b,'  function journal(','  function locked(')+between(b,'  function pendingValue(','  function renderGuide(')+between(b,'  function seriesRows(','  function stackedVideos(')+between(b,'  window.completeWorkoutBisetPart=','  function updateGuideClock(')+'window.__biset={seriesRows,pendingValue,phase,groups};})();',ctx);
ctx.workoutBisetGroups=ctx.__biset.groups;
const plain=x=>JSON.parse(JSON.stringify(x)),checks=[];
const ex={id:'a',name:'Glúteo coice na polia',sets:'3',reps:'12 / 10 / 8',load:'25 kg',rest:'90 s'};
const targets=(e,total)=>[1,2,3].map(n=>ctx.workoutTechniqueRoundPrescription(e,n,total)?.reps);
assert.deepEqual(targets(ex),['12','10','8']);assert.equal(ctx.workoutTechniqueRoundPrescription(ex,0),null);assert.equal(ctx.workoutTechniqueRoundPrescription(ex,4),null);
assert.deepEqual(targets({...ex,reps:'12/10/8'}),['12','10','8']);
assert.deepEqual(plain(ctx.__series.prescribed(ex)).map(r=>r.targetReps),['12','10','8']);checks.push('Prescrição 12 / 10 / 8 distribuída nas séries 1, 2 e 3');
for(const reps of ['8-10','8–10','12','10 + 4 + 3','10 + redução','10 + 10 s','Até a falha']){
 assert.equal(ctx.workoutTechniqueRoundPrescription({...ex,reps},1),null);
 assert.deepEqual(plain(ctx.__series.prescribed({...ex,reps})).map(r=>r.targetReps),[reps,reps,reps]);
}
assert.equal(ctx.workoutTechniqueRoundPrescription({...ex,sets:'4'},1),null);
assert.equal(ctx.workoutTechniqueRoundPrescription({...ex,reps:'12 / carga / 8'},1),null);
assert.equal(ctx.workoutTechniqueRoundPrescription({...ex,reps:'12 / 10-8 / 8'},1),null);
assert.deepEqual(targets({...ex,reps:'12 / 8-10 / 6–8'}),['12','8-10','6–8']);checks.push('Faixas e etapas dentro da série preservadas; listas ambíguas não viram metas inventadas');
const presets=plain(ctx.workoutTechniquePresets());
const pyramid=presets.find(p=>p.id==='pyramid-up');const technique={...pyramid,presetId:pyramid.id};
const structured={...ex,reps:'99 / 98 / 97',technique};
assert.deepEqual(targets(structured),['12','10','8']);
assert.deepEqual([1,2,3].map(n=>ctx.workoutTechniqueRoundPrescription(structured,n).restSeconds),[90,90,90]);
const reverse=presets.find(p=>p.id==='pyramid-down');assert.deepEqual(targets({...ex,technique:{...reverse,presetId:reverse.id}}),['8','10','12']);
const grouped={...technique,rows:[{sets:3,reps:'12 / 10 / 8',load:'25 kg',restSeconds:90}]};
assert.deepEqual(targets({...ex,technique:grouped}),['12','10','8']);
assert.deepEqual(plain(ctx.__tech.fields(grouped)),{sets:'3',reps:'12 / 10 / 8',rest:'90 s',load:'25 kg'});
for(const id of ['rest-pause','drop-set','isometry']){
 const p=presets.find(p=>p.id===id);assert.deepEqual(targets({...ex,technique:{...p,presetId:p.id}}),[p.rows[0].reps,p.rows[0].reps,p.rows[0].reps]);
}
checks.push('Pirâmides e técnicas estruturadas prioritárias; pausas, cargas e etapas preservadas');
const plan={id:'p',studentId:'student'},day={id:'d',exercises:[ex,{...ex,id:'b',name:'Parceiro',sets:'4',reps:'15 / 12 / 10',load:'10 kg'}]},g={id:'g',exerciseIds:['a','b'],rounds:3,restSeconds:90};day.bisets=[g];
ctx.guideContext=()=>({p:plan,day,g});ctx.state.workoutDrafts['p|d']={sessionId:'session',values:{},bisets:{}};
let phase=ctx.__biset.phase(plan,day,g);
for(const [letter,raw,expected] of [['A',ex,['12','10','8']],['B',day.exercises[1],['12','10','8']]]){
 const e=ctx.workoutBisetExercisePrescription(day,g,raw),rows=ctx.__biset.seriesRows(g,e,letter,phase);
 assert.deepEqual(plain(rows).map(r=>r.targetReps),expected);assert.deepEqual(plain(rows).map(r=>r.reps),expected);
 const markup=ctx.workoutSetTable(e,rows,{interactive:true,part:letter,groupId:g.id,step:phase.step});
 assert.deepEqual([...markup.matchAll(/class="ws-set-target">Meta: ([^<]+)/g)].map(m=>m[1]),expected);
 assert.deepEqual([...markup.matchAll(/data-series-field="reps" value="([^"]*)"/g)].map(m=>m[1]),expected);
 assert.ok(markup.indexOf('data-series-field="reps"')<markup.indexOf('data-series-field="load"'));
}
checks.push('Ao montar a dupla, B acompanha automaticamente as metas de A e a quantidade de rodadas');
const completed={round:2,reps:9,load:'27 kg',done:true,prescribedReps:'12 / 10 / 8'};
ctx.state.workoutDrafts['p|d'].values.a={series:{2:completed}};const before=JSON.stringify(ctx.state);
const singleRows=plain(ctx.__series.entries(plan,day,ex));assert.deepEqual(singleRows.map(r=>r.targetReps),['12','10','8']);assert.equal(singleRows[1].reps,'9');assert.equal(singleRows[1].load,'27 kg');assert.equal(singleRows[1].done,true);assert.equal(JSON.stringify(ctx.state),before);
ctx.state.workoutDrafts['p|d'].values={};phase=ctx.__biset.phase(plan,day,g);
phase.j.entries={1:{A:{reps:'9',load:'28 kg'}}};let rows=plain(ctx.__biset.seriesRows(g,ex,'A',phase));assert.equal(rows[1].targetReps,'10');assert.equal(rows[1].reps,'9');assert.equal(rows[1].load,'28 kg');
phase.j.rounds=[{A:{reps:11,load:'25 kg'},B:{reps:14,load:'10 kg'}}];rows=plain(ctx.__biset.seriesRows(g,ex,'A',phase));assert.equal(rows[0].reps,'11');assert.equal(rows[0].targetReps,'12');assert.equal(rows[0].done,true);
checks.push('Metas corrigidas sem reescrever repetições realizadas, cargas, séries concluídas ou rascunhos');
ctx.state.workoutDrafts['p|d']={sessionId:'execution',values:{},bisets:{}};
const actualA=[11,9,7],actualB=[14,11,9],expectedA=['12','10','8'],expectedB=['12','10','8'];
for(let round=0;round<3;round++){
 for(const [part,reps,load] of [['A',actualA[round],'25'],['B',actualB[round],'10']]){
  const status=ctx.__biset.phase(plan,day,g);assert.equal(status.part,part);assert.equal(status.index,round);
  element('workoutBisetReps').value=String(reps);element('workoutBisetLoad').value=load;
  if(round===0&&part==='A'){
   const before=JSON.stringify(ctx.state);ctx.failSave=true;ctx.completeWorkoutBisetPart(null,status.step);assert.equal(JSON.stringify(ctx.state),before);ctx.failSave=false;
  }
  ctx.completeWorkoutBisetPart(null,status.step);
  const after=JSON.stringify(ctx.state);ctx.completeWorkoutBisetPart(null,status.step);assert.equal(JSON.stringify(ctx.state),after);
 }
 const resting=ctx.__biset.phase(plan,day,g);assert.equal(resting.part,'rest');assert.equal(ctx.state.workoutRest.seconds,90);ctx.nextWorkoutBisetRound(resting.step);
}
const journal=ctx.state.workoutDrafts['p|d'].bisets.g;
assert.deepEqual(plain(journal.rounds).map(r=>r.A.prescribedReps),expectedA);assert.deepEqual(plain(journal.rounds).map(r=>r.B.prescribedReps),expectedB);
assert.deepEqual(plain(journal.rounds).map(r=>r.A.reps),actualA);assert.deepEqual(plain(journal.rounds).map(r=>r.B.reps),actualB);
assert.equal(ctx.__biset.phase(plan,day,g).part,'done');checks.push('Execução real A1/B1 até A3/B3: metas iguais, valores realizados independentes, descanso e guardas mantidos');
// The screenshot: A has a sequence and B has a range; only the group view changes.
const photoDay={id:'photo',exercises:[{...ex,load:'25 kg'},{id:'b',name:'Elevação de Quadril na Máquina',sets:'3',reps:'6-10',load:'130 kg',notes:'Orientação de B',video:'video-b'}],bisets:[g]};
const photoBefore=JSON.stringify(photoDay),photoB=ctx.workoutBisetExercisePrescription(photoDay,g,photoDay.exercises[1]);
assert.equal(photoB.reps,'12 / 10 / 8');assert.equal(photoB.sets,'3');assert.equal(photoB.load,'130 kg');assert.equal(photoB.notes,'Orientação de B');assert.equal(photoB.video,'video-b');
assert.deepEqual(targets(photoB),['12','10','8']);assert.deepEqual([1,2,3].map(n=>ctx.workoutTechniqueRoundPrescription(photoB,n).load),['130 kg','130 kg','130 kg']);assert.equal(JSON.stringify(photoDay),photoBefore);
assert.equal(ctx.workoutTechniqueRoundPrescription(photoDay.exercises[1],1),null);assert.equal(photoDay.exercises[1].reps,'6-10');
checks.push('Dupla existente da imagem: 12/10/8 em ambos, 25 kg e 130 kg separados, sem reescrever os exercícios');
const weightedDay=plain(photoDay);weightedDay.exercises[0].technique={...technique,rows:technique.rows.map((r,i)=>({...r,load:(25+i*5)+' kg'}))};
weightedDay.exercises[1].technique={...technique,rows:technique.rows.map((r,i)=>({...r,reps:String(15-i*2),load:(110+i*10)+' kg'}))};
const weightedBefore=JSON.stringify(weightedDay),weightedB=ctx.workoutBisetExercisePrescription(weightedDay,g,weightedDay.exercises[1]);
assert.deepEqual(targets(weightedB),['12','10','8']);assert.deepEqual([1,2,3].map(n=>ctx.workoutTechniqueRoundPrescription(weightedB,n).load),['110 kg','120 kg','130 kg']);assert.equal(JSON.stringify(weightedDay),weightedBefore);
assert.ok(ctx.workoutTechniquePrescription(weightedB).sharedBiSet);checks.push('Cargas próprias por etapa de B preservadas ao compartilhar as metas da pirâmide de A');
const rangeDay=plain(photoDay);rangeDay.exercises[0].reps='8–10';assert.equal(ctx.workoutBisetExercisePrescription(rangeDay,g,rangeDay.exercises[1]).reps,'8–10');
const restDay=plain(photoDay),restPreset=presets.find(p=>p.id==='rest-pause');restDay.exercises[0].technique={...restPreset,presetId:restPreset.id};
assert.deepEqual(targets(ctx.workoutBisetExercisePrescription(restDay,g,restDay.exercises[1])),['10 + 4 + 3','10 + 4 + 3','10 + 4 + 3']);checks.push('Sem 12/10/8 fixo no código: faixa e técnica de A são acompanhadas por B');
const largeDay=plain(photoDay),largeGroup={...g,rounds:100};
largeDay.exercises[0].sets='100';largeDay.exercises[0].technique={...technique,rows:Array.from({length:20},(_,i)=>({sets:5,reps:i%2?'10':'12',load:'',restSeconds:90}))};
largeDay.exercises[1].sets='100';largeDay.exercises[1].technique={...technique,rows:Array.from({length:20},(_,i)=>({sets:i===0?1:i===19?9:5,reps:'6-10',load:(100+i)+' kg',restSeconds:90}))};
const largeBefore=JSON.stringify(largeDay),largeB=ctx.workoutBisetExercisePrescription(largeDay,largeGroup,largeDay.exercises[1]);
assert.equal(largeB.reps,'Conforme técnica');assert.ok(ctx.workoutTechniquePrescription(largeB).rows.length>20);
for(let n=1;n<=100;n++){assert.equal(ctx.workoutTechniqueRoundPrescription(largeB,n,100).reps,ctx.workoutTechniqueRoundPrescription(largeDay.exercises[0],n,100).reps);assert.equal(ctx.workoutTechniqueRoundPrescription(largeB,n,100).load,ctx.workoutTechniqueRoundPrescription(largeDay.exercises[1],n,100).load);}
assert.equal(JSON.stringify(largeDay),largeBefore);checks.push('Até 100 séries: metas e cargas próprias por rodada mantidas, com representação compacta e sem texto excedente');
// Applying from B must update the reference exercise, while B's saved load stays its own.
let currentPlan={...plan,days:[plain(photoDay)]};currentPlan.days[0].id='d';ctx.currentWorkoutDay=()=>currentPlan.days[0];ctx.currentWorkoutPlan=()=>currentPlan;ctx.workoutPlanById=()=>currentPlan;
ctx.state.workoutDrafts['p|d']={sessionId:'assembly',values:{},bisets:{}};
ctx.workoutRunning=()=>false;
ctx.target={mode:'card',planId:'p',dayId:'d',exerciseId:'b'};ctx.detailId='pyramid-up';ctx.replaceWorkoutPlan=next=>{if(ctx.failSave)return false;currentPlan=plain(next);return true;};
vm.runInContext('(function(){'+between(t,'  const copy=','  const original=')+between(t,'  function normalize(','  function exerciseControls(')+between(t,'  window.applyWorkoutTechnique=','  function pairContext(')+'})();',ctx);
const beforeApply=JSON.stringify(currentPlan);ctx.failSave=true;ctx.applyWorkoutTechnique();assert.equal(JSON.stringify(currentPlan),beforeApply);ctx.failSave=false;ctx.applyWorkoutTechnique();
assert.equal(currentPlan.days[0].exercises[0].technique.presetId,'pyramid-up');assert.equal(currentPlan.days[0].exercises[1].load,'130 kg');assert.equal(currentPlan.days[0].exercises[1].reps,'6-10');
assert.deepEqual(targets(ctx.workoutBisetExercisePrescription(currentPlan.days[0],g,currentPlan.days[0].exercises[1])),['12','10','8']);checks.push('Escolher técnica pelo cartão de B aplica a prescrição comum via A; falha de gravação não altera a dupla');
// Exercise the actual group-saving path, including B with a different set count.
currentPlan.days[0].bisets=[];currentPlan.days[0].name='Inferiores';currentPlan.days[0].exercises[1].technique={...technique,rows:[{sets:4,reps:'6-10',load:'130 kg',restSeconds:90}]};
ctx.__baseSave=null;
vm.runInContext('(function(){'+between(b,'  const integer=','  function groups(')+between(b,'  function groups(','  function video(')+between(b,'  function editorContext(','  window.removeWorkoutBiset=')+'window.__baseSave=window.saveWorkoutBiset;})();',ctx);
vm.runInContext('(function(){const original={biset:window.__baseSave};'+between(t,'  const copy=','  const original=')+between(t,'  function normalize(','  function exerciseControls(')+between(t,'  window.saveWorkoutBiset=','  openWorkoutExerciseEditor=')+'})();',ctx);
element('workoutBisetPlanId').value='p';element('workoutBisetDayId').value='d';element('workoutBisetEditId').value='';element('workoutBisetExerciseA').value='a';element('workoutBisetExerciseB').value='b';element('workoutBisetRounds').value='3';element('workoutBisetRest').value='90';
const originalExercises=JSON.stringify(currentPlan.days[0].exercises),beforePair=JSON.stringify(currentPlan);ctx.failSave=true;ctx.saveWorkoutBiset({preventDefault(){}});assert.equal(JSON.stringify(currentPlan),beforePair);
ctx.failSave=false;ctx.saveWorkoutBiset({preventDefault(){}});assert.equal(currentPlan.days[0].bisets.length,1);assert.equal(JSON.stringify(currentPlan.days[0].exercises),originalExercises);
const created=currentPlan.days[0].bisets[0];assert.equal(created.rounds,3);assert.deepEqual(targets(ctx.workoutBisetExercisePrescription(currentPlan.days[0],created,currentPlan.days[0].exercises[1])),['12','10','8']);
element('workoutBisetEditId').value=created.id;element('workoutBisetRounds').value='4';const beforeMismatch=JSON.stringify(currentPlan);ctx.saveWorkoutBiset({preventDefault(){}});assert.equal(JSON.stringify(currentPlan),beforeMismatch);
checks.push('Criação real do bi-set: B com quatro séries não exige ajuste manual; dupla recebe três metas de A; falha e contagem incompatível não salvam');
// The normal exercise editor presents B's shared reps and keeps its own load.
const fillStub=view=>{ctx.__filled=plain(view);for(const [suffix,key] of [['EditId','id'],['Sets','sets'],['Reps','reps'],['Load','load']])element('workoutExercise'+suffix).value=String(view[key]||'');};
ctx.__fillStub=fillStub;ctx.workoutExerciseMode='day';
vm.runInContext('(function(){let formTechnique=null;const original={fill:window.__fillStub};'+between(t,'  const copy=','  const original=')+between(t,'  function normalize(','  function exerciseControls(')+between(t,'  function renderForm(','  window.editWorkoutExerciseTechnique=')+'})();',ctx);
ctx.fillWorkoutExerciseFields(currentPlan.days[0].exercises[1]);assert.equal(element('workoutExerciseReps').value,'12 / 10 / 8');assert.equal(element('workoutExerciseSets').value,'3');assert.equal(element('workoutExerciseLoad').value,'130 kg');assert.equal(element('workoutExerciseReps').readOnly,true);assert.equal(element('workoutExerciseSets').readOnly,true);
assert.match(element('workoutExerciseTechniqueSummary').innerHTML,/acompanham o primeiro exercício/);
checks.push('Editor de B já mostra a sequência compartilhada, explica a origem e conserva a carga do próprio exercício');
console.log(JSON.stringify({passed:true,checks},null,2));
