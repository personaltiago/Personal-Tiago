'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';if(!['index.html','professor.html','avaliacoes.html','cadastro.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;
 try{
  browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,timezoneId:'America/Cuiaba'});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.failMotivationSave&&k.includes('agenda_demo_exercise_sessions_v1_'))throw Error('quota');return set.call(this,k,v)}});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));const url='http://127.0.0.1:'+server.address().port;
  await page.goto(url);await page.waitForFunction(()=>!!window.APmascot);
  async function activate(uid='motivation_alice',role='student'){
   await page.evaluate(({uid,role})=>{window.dispatchEvent(new Event('ap-account-changed'));const student={id:'s',firebaseUid:uid,name:'Aluna de teste'},area=APStudentModel.makeArea({students:[student],workoutPlans:[{id:'p',studentId:'s',name:'Plano',days:[{id:'d',name:'Treino A',exercises:[{id:'e1',name:'Agachamento',sets:1,reps:'12',rest:'0',load:'10'},{id:'e2',name:'Remada',sets:1,reps:'12',rest:'0',load:'10'}]}]}]},student);window.__AP_STUDENT_CONTEXT={storageId:uid,role,area,profile:area.profile};APstudentUI.activate(role==='preview');route('home')},{uid,role});
  }
  const popup=page.locator('#apWorkoutMotivation');
  async function finish(loads,fail=false){
   await page.evaluate(loads=>{openExerciseHub('p~d');beginExerciseWorkout();loads.forEach((load,i)=>{saveExerciseLoad(i,0,String(load));toggleExerciseSet(i,0)});finishExerciseWorkout()},loads);
   await page.locator('#exFinishIntensity').selectOption('Moderada');await page.evaluate(fail=>window.failMotivationSave=fail,fail);await page.locator('.ex-finish-confirm').click();
  }
  await activate();await page.locator('#apMascotHome .ap-habitat-house').click();await page.locator('[data-mascot-item="kitten"]').click();await page.locator('.ap-mascot-settings summary').click();await page.locator('#apMascotName').fill('Luna');await page.locator('#apMascotSettings button').click();await page.keyboard.press('Escape');
  for(const [loads,trend] of [[[10,10],'first'],[[15,10],'increased'],[[15,10],'maintained'],[[10,10],'decreased'],[[15,5],'mixed']]){
   await finish(loads);await popup.waitFor({state:'visible'});assert.equal(await popup.getAttribute('data-load-trend'),trend);assert.equal(await page.locator('#apWorkoutMotivationName').innerText(),'Luna');
   const text=await page.locator('#apWorkoutMotivationText').innerText();assert.equal(await page.evaluate(()=>APWorkoutMotivation.messageFor(exStore().history[0]).text),text);
   assert.equal(await page.locator('#apWorkoutMotivationReward').isVisible(),trend==='first','messages also appear after the daily reward cap');
   const stored=await page.evaluate(()=>APstudentStorage.getItem(exStorageKey()));await page.evaluate(()=>confirmExerciseWorkoutFinish());assert.equal(await page.evaluate(()=>APstudentStorage.getItem(exStorageKey())),stored,'duplicate finish cannot advance message rotation');
   await page.locator('#apWorkoutMotivationClose').click();assert.equal(await popup.isVisible(),false);await page.evaluate(()=>route('home'));assert.equal(await page.locator('#apMascotHome .ap-mascot-speech').innerText(),text);
  }
  const beforeFailure=await page.evaluate(()=>({history:exStore().history.length,rotation:JSON.stringify(APmascot.state().messageRotation)}));
  await finish([20,10],true);assert.equal(await popup.isVisible(),false);assert.equal(await page.evaluate(()=>exStore().history.length),beforeFailure.history);assert.equal(await page.evaluate(()=>JSON.stringify(APmascot.state().messageRotation)),beforeFailure.rotation);
  await page.evaluate(()=>window.failMotivationSave=false);await page.locator('.ex-finish-confirm').click();await popup.waitFor({state:'visible'});assert.equal(await popup.getAttribute('data-load-trend'),'increased');
  await page.evaluate(()=>route('home'));await page.reload();await page.waitForFunction(()=>!!window.APmascot);await activate();assert.equal(await page.evaluate(()=>exStore().history.length),6);assert.equal(await page.evaluate(()=>APmascot.state().name),'Luna');assert.equal(await page.locator('#apMascotHome').getAttribute('data-load-trend'),'increased');
  await page.locator('#apMascotHome .ap-habitat-house').click();await page.locator('#apPetHide').click();await page.keyboard.press('Escape');await finish([25,10]);await page.waitForTimeout(200);assert.equal(await popup.isVisible(),false,'hidden pet suppresses the message');assert.equal(await page.evaluate(()=>exStore().history.length),7);
  await page.evaluate(()=>{APmascot.open()});await page.locator('#apPetShow').click();await page.keyboard.press('Escape');await finish([20,10]);await popup.waitFor({state:'visible'});assert.equal(await popup.getAttribute('data-load-trend'),'decreased');
  for(const width of [320,390,480])for(const mode of ['claro','escuro']){
   await page.setViewportSize({width,height:844});await page.evaluate(mode=>{const p=prefs();p.mode=mode;APstudentStorage.setItem(PREF_KEY,JSON.stringify(p));const n=document.getElementById('apWorkoutMotivation');n.classList.toggle('ap-mascot-light',mode==='claro')},mode);
   assert.ok(await popup.evaluate(n=>{const r=n.getBoundingClientRect();return n.scrollWidth<=n.clientWidth+1&&r.left>=0&&r.right<=innerWidth+1&&r.top>=0&&r.bottom<=innerHeight}),'fits '+[width,mode]);
   const all=await page.evaluate(()=>Object.values(APWorkoutMotivation.phrases).flat());for(const text of all){await page.locator('#apWorkoutMotivationText').evaluate((n,text)=>n.textContent=text,text);assert.ok(await popup.evaluate(n=>n.scrollWidth<=n.clientWidth+1),'no phrase overflows')}
  }
  await page.setViewportSize({width:390,height:844});await page.evaluate(()=>{document.getElementById('apWorkoutMotivation').classList.remove('ap-mascot-light');document.getElementById('apWorkoutMotivationText').textContent=APWorkoutMotivation.messageFor(exStore().history[0]).text});
  if(process.env.AGENDA_REVIEW_DIR){fs.mkdirSync(process.env.AGENDA_REVIEW_DIR,{recursive:true});await page.screenshot({path:path.join(process.env.AGENDA_REVIEW_DIR,'pet-motivacao.png')})}
  await page.keyboard.press('Escape');assert.equal(await popup.isVisible(),false);
  await finish([25,10]);await popup.waitFor({state:'visible'});await activate('motivation_bob');assert.equal(await popup.isVisible(),false);assert.equal(await page.evaluate(()=>exStore().history.length),0);assert.deepEqual(await page.evaluate(()=>APmascot.state().messageRotation),{});
  await activate('motivation_alice','preview');const preview=await page.evaluate(()=>APstudentStorage.getItem(exStorageKey()));assert.equal(await page.evaluate(()=>APmascot.prepareReward(exStore(),{id:'blocked'})),null);assert.equal(await page.evaluate(()=>APstudentStorage.getItem(exStorageKey())),preview);
  assert.deepEqual(errors,[]);console.log('PASS: real completion for first/increased/maintained/decreased/mixed loads; 75 messages in 6 mobile/theme layouts; atomic retry; saved rotation and home message; daily-cap independence; hide/re-enable; duplicate finish; account and preview isolation; dismissal and reload. Authentication/network simulated.');
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r))}
}
run().catch(e=>{console.error(e);process.exitCode=1});
