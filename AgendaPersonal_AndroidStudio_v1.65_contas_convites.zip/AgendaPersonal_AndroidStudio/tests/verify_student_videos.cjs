'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),vm=require('node:vm'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/') : require):require;
const {chromium}=runtime('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,'professor.html')))});
const video='https://www.youtube.com/watch?v=M7lc1UVf-VE';
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{
   window.__staged=[];
   window.APaccounts={isTeacher:()=>true,stage:p=>window.__staged.push(JSON.parse(JSON.stringify(p))),refreshPreview(){},knownAreas:()=>[],status:()=>({state:'sent',message:'Enviado'})};
   localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[{id:'s',name:'Aluna',firebaseUid:'student_video',studentType:'presencial'}],lessons:[],customData:{preserve:7}}));
  });
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>typeof openCatalogExerciseEditor==='function');
  const cid=await page.evaluate(()=>{
   const catalog=workoutCatalogItems().find(e=>e.source==='app'&&!workoutCatalogBlocked(e));
   state.exerciseCatalogOverrides[catalog.id]={...state.exerciseCatalogOverrides[catalog.id],video:''};
   const make=(id,video='')=>({id,catalogId:catalog.id,name:catalog.name,sets:'3',reps:'8-12',rest:'60',load:'20',video});
   state.workoutPlans=[{id:'p',studentId:'s',name:'Ficha',days:[{id:'d',name:'Treino',exercises:[make('a'),make('b','https://youtu.be/aqz-KE-bpKQ')]}]}];
   save();return catalog.id;
  });
  await page.waitForFunction(()=>window.__staged.some(p=>p.plans.length));
  assert.equal(await page.evaluate(()=>window.__staged.at(-1).plans[0].days[0].exercises[0].video),'');
  // Real catalog editor save after the prescription already exists.
  await page.evaluate(cid=>openCatalogExerciseEditor(cid,'video'),cid);
  await page.locator('#workoutExerciseVideo').fill(video);
  await page.locator('#workoutExerciseForm button[type="submit"]').click();
  await page.waitForTimeout(500);
  const area=await page.evaluate(()=>window.__staged.at(-1));
  assert.equal(await page.evaluate(()=>workoutExerciseVideoUrl(state.workoutPlans[0].days[0].exercises[0])),video,'teacher resolves catalog link');
  assert.equal(area.plans[0].days[0].exercises[0].video,video,'same resolved catalog video must reach student packet');
  assert.equal(area.plans[0].days[0].exercises[1].video,'https://youtu.be/aqz-KE-bpKQ','individual exercise video takes precedence');
  assert.equal(await page.evaluate(()=>state.workoutPlans[0].days[0].exercises[0].video),'','prescription is not rewritten');
  assert.equal(await page.evaluate(()=>state.customData.preserve),7);
  await page.evaluate(()=>{state.workoutPlans[0].days[0].bisets=[{id:'pair',exerciseIds:['a','b'],rounds:3,restSeconds:60}];save()});
  await page.waitForTimeout(500);
  assert.equal(await page.evaluate(()=>window.__staged.at(-1).plans[0].days[0].exercises[0].video),video,'bi-set retains catalog fallback');
  assert.deepEqual(errors,[]);
  // Actual student entry scripts and persisted in-progress execution.
  const {ctx,storage,element}=require('./verify_shell_boot.cjs'),evaluate=s=>vm.runInContext(s,ctx);
  ctx.__AP_STUDENT_CONTEXT={storageId:'student_video',role:'student',area,profile:area.profile};storage.clear();ctx.document.body.dataset.view='exercise';
  element('exSingleLoadTable').querySelector=()=>element('heading');
  evaluate("exActiveId='p~d';exIndex=0;exView='detail';exTab='video';renderExerciseApp();exNewSession(exActiveId);saveExerciseLoad(0,0,'31');toggleExerciseSet(0,0)");
  const saved=JSON.stringify(evaluate('exGetSession()'));
  ctx.__AP_STUDENT_CONTEXT.area.plans[0].days[0].exercises[0].video='https://m.youtube.com/shorts/aqz-KE-bpKQ';
  ctx.__AP_STUDENT_CONTEXT.area.plans[0].days[0].exercises[0].rows=[{reps:'99',load:99,rest:999}];
  assert.equal(evaluate("exercisesFor(exActiveId)[0].video"),'https://m.youtube.com/shorts/aqz-KE-bpKQ','new video visible during active workout');
  assert.equal(evaluate('exercisesFor(exActiveId)[0].sets'),3,'active prescription stays frozen');
  assert.equal(evaluate('exercisesFor(exActiveId)[0].rows[0].reps'),'8-12');
  assert.equal(JSON.stringify(evaluate('exGetSession()')),saved,'media refresh does not mutate session, time, loads or checks');
  assert.equal(ctx.APStudentModel.youtube('https://m.youtube.com/shorts/aqz-KE-bpKQ'),'aqz-KE-bpKQ');
  assert.equal(ctx.APStudentModel.youtube('https://www.youtu.be/M7lc1UVf-VE'),'M7lc1UVf-VE');
  assert.equal(ctx.APStudentModel.youtube('https://evil.test/?v=M7lc1UVf-VE'),'');
  ctx.__AP_STUDENT_CONTEXT.area.plans[0].days[0].exercises[0].id='replacement';
  assert.equal(evaluate('exercisesFor(exActiveId)[0].video'),video,'replacement exercise cannot change old session by position');
  ctx.__AP_STUDENT_CONTEXT.area.plans[0].days[0].exercises[0].id='a';ctx.__AP_STUDENT_CONTEXT.area.plans[0].days[0].exercises[0].video='';
  assert.equal(evaluate('exercisesFor(exActiveId)[0].video'),'','explicit current media removal is honored');
  console.log('PASS: real browser catalog save -> automatic student packet, explicit link precedence, bi-set fallback, preserved prescription/data; active-session media refresh preserves checks/loads/time and stable IDs; supported YouTube hosts and hostile-host rejection. Firebase and Android playback not exercised.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
