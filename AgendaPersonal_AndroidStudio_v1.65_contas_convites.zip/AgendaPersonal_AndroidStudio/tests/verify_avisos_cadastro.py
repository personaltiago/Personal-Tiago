"""Aviso "Novo cadastro" na tela (Android 1.211, pedido do Tiago em 24/11/2026: "é só ele jogar na tela a notificação").

Parte A confere as ligações no projeto: sem Firebase no Android (o aviso é local), a ponte com o conteúdo e o ícone
monocromático. Parte B compila a classe REAL AvisosCadastro com Android de mentira e confere a leitura do pedido do conteúdo,
a notificação (canal, tela bloqueada, versão pública sem o nome, toque que não recarrega o app), a abertura pelo toque, o estado
para a tela "Sons e alertas" e as configurações do canal.
Não é teste em aparelho: a notificação real no Xiaomi só se confirma no celular, pelo botão "Testar".
"""
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal'


def static_checks():
    gradle = (PROJECT / 'app/build.gradle').read_text()
    manifest = (PROJECT / 'app/src/main/AndroidManifest.xml').read_text()
    for texto, nome in [(gradle, 'build.gradle'), (manifest, 'manifesto')]:
        assert 'firebase' not in texto.lower(), nome + ': o aviso é local, sem Firebase no Android.'
    versao = re.search(r"versionName '1\.(\d+)'", gradle)
    assert versao and int(versao.group(1)) >= 211, 'O aviso de cadastro precisa do Android 1.211 ou mais novo.'
    assert 'android.permission.POST_NOTIFICATIONS' in manifest

    main = (SOURCE / 'MainActivity.java').read_text()
    for token in ['if (savedInstanceState == null) noticeOpen.set(AvisosCadastro.abertura(getIntent()));', 'AvisosCadastro.criarCanal(this);',
                  'String notice=AvisosCadastro.abertura(intent);', "new Event('ap-notice-open')",
                  '@JavascriptInterface public int getNoticeVersion() { return AvisosCadastro.VERSAO; }',
                  '@JavascriptInterface public String getNoticeStatus() { return AvisosCadastro.status(activity); }',
                  '@JavascriptInterface public boolean showRegistrationNotice(String json) { return AvisosCadastro.mostrarJson(activity, json); }',
                  '@JavascriptInterface public void openNoticeSettings()',
                  '@JavascriptInterface public String takeNoticeOpen() { return ((MainActivity) activity).noticeOpen.getAndSet(""); }']:
        assert token in main, 'MainActivity sem: ' + token
    assert 'Push' not in main, 'Sobrou ponte do push no MainActivity.'
    assert not (SOURCE / 'PushAvisos.java').exists() and not (SOURCE / 'AgendaMessagingService.java').exists()

    icon = (PROJECT / 'app/src/main/res/drawable/ic_stat_cadastro.xml').read_text()
    colors = set(re.findall(r'android:(?:fill|stroke)Color="([^"]+)"', icon))
    assert colors == {'@android:color/transparent', '#FFFFFFFF'}, 'Ícone da barra de status precisa ser branco sobre transparente.'
    assert 'android:viewportWidth="24"' in icon and 'android:width="24dp"' in icon


STUBS = {
    'android/Manifest.java': 'package android;public final class Manifest{public static final class permission{public static final String POST_NOTIFICATIONS="android.permission.POST_NOTIFICATIONS";}}',
    'android/os/Build.java': 'package android.os;public class Build{public static class VERSION{public static int SDK_INT=35;}}',
    'android/content/pm/PackageManager.java': '''package android.content.pm;public class PackageManager{public static final int PERMISSION_GRANTED=0,PERMISSION_DENIED=-1;public String versionName="1.211";
public PackageInfo getPackageInfo(String name,int flags)throws NameNotFoundException{if(versionName==null)throw new NameNotFoundException();PackageInfo i=new PackageInfo();i.versionName=versionName;return i;}
public static class NameNotFoundException extends Exception{}}''',
    'android/content/pm/PackageInfo.java': 'package android.content.pm;public class PackageInfo{public String versionName;}',
    'android/provider/Settings.java': '''package android.provider;public final class Settings{public static final String ACTION_CHANNEL_NOTIFICATION_SETTINGS="android.settings.CHANNEL_NOTIFICATION_SETTINGS",
ACTION_APP_NOTIFICATION_SETTINGS="android.settings.APP_NOTIFICATION_SETTINGS",EXTRA_APP_PACKAGE="android.provider.extra.APP_PACKAGE",EXTRA_CHANNEL_ID="android.provider.extra.CHANNEL_ID";}''',
    'android/content/Context.java': '''package android.content;
public class Context{public static final String NOTIFICATION_SERVICE="notification";
public android.app.NotificationManager manager=new android.app.NotificationManager();public int permission=0;
public Object getSystemService(String name){return NOTIFICATION_SERVICE.equals(name)?manager:null;}
public int checkSelfPermission(String p){return permission;}public String getPackageName(){return "com.tiagolima.agendapersonal";}
public android.content.pm.PackageManager packages=new android.content.pm.PackageManager();public android.content.pm.PackageManager getPackageManager(){return packages;}}''',
    'android/content/Intent.java': '''package android.content;import java.util.*;
public class Intent{public static final int FLAG_ACTIVITY_NEW_TASK=0x10000000,FLAG_ACTIVITY_CLEAR_TOP=0x04000000,FLAG_ACTIVITY_SINGLE_TOP=0x20000000;
public final String action;public final Class<?> target;public int flags;public final Map<String,String> extras=new LinkedHashMap<>();
public Intent(String action){this.action=action;target=null;}public Intent(Context c,Class<?> t){action=null;target=t;}
public Intent addFlags(int f){flags|=f;return this;}public Intent putExtra(String k,String v){extras.put(k,v);return this;}
public String getStringExtra(String k){return extras.get(k);}public void removeExtra(String k){extras.remove(k);}}''',
    'android/app/Activity.java': '''package android.app;import android.content.Intent;import java.util.*;
public class Activity extends android.content.Context{public final List<Intent> started=new ArrayList<>();public Set<String> missing=new HashSet<>();
public void startActivity(Intent i){if(missing.contains(i.action))throw new RuntimeException("ActivityNotFoundException");started.add(i);}}''',
    'android/app/PendingIntent.java': '''package android.app;
public class PendingIntent{public static final int FLAG_UPDATE_CURRENT=0x08000000,FLAG_IMMUTABLE=0x04000000;public final int requestCode,flags;public final android.content.Intent intent;
private PendingIntent(int r,android.content.Intent i,int f){requestCode=r;intent=i;flags=f;}
public static PendingIntent getActivity(android.content.Context c,int r,android.content.Intent i,int f){return new PendingIntent(r,i,f);}}''',
    'android/app/Notification.java': '''package android.app;
public class Notification{public static final int VISIBILITY_PUBLIC=1,VISIBILITY_PRIVATE=0,VISIBILITY_SECRET=-1;
public String channel,title,text,bigText;public int icon,color,visibility=VISIBILITY_PRIVATE;public long when;public boolean autoCancel,showWhen;public PendingIntent contentIntent;public Notification publicVersion;
public static class Style{}public static class BigTextStyle extends Style{public String text;public BigTextStyle bigText(CharSequence t){text=String.valueOf(t);return this;}}
public static class Builder{private final Notification n=new Notification();public Builder(android.content.Context c,String channel){n.channel=channel;}
public Builder setSmallIcon(int i){n.icon=i;return this;}public Builder setColor(int c){n.color=c;return this;}public Builder setContentTitle(CharSequence t){n.title=String.valueOf(t);return this;}
public Builder setContentText(CharSequence t){n.text=String.valueOf(t);return this;}public Builder setStyle(Style s){n.bigText=((BigTextStyle)s).text;return this;}
public Builder setContentIntent(PendingIntent p){n.contentIntent=p;return this;}public Builder setAutoCancel(boolean b){n.autoCancel=b;return this;}
public Builder setShowWhen(boolean b){n.showWhen=b;return this;}public Builder setWhen(long w){n.when=w;return this;}
public Builder setVisibility(int v){n.visibility=v;return this;}public Builder setPublicVersion(Notification p){n.publicVersion=p;return this;}public Notification build(){return n;}}}''',
    'android/app/NotificationChannel.java': '''package android.app;
public class NotificationChannel{public final String id;public String name,description;public int importance,lockscreen=-1000;public boolean badge,vibration;
public NotificationChannel(String id,CharSequence name,int importance){this.id=id;this.name=String.valueOf(name);this.importance=importance;}
public void setDescription(String d){description=d;}public void setLockscreenVisibility(int v){lockscreen=v;}public void setShowBadge(boolean b){badge=b;}public void enableVibration(boolean b){vibration=b;}
public int getImportance(){return importance;}public int getLockscreenVisibility(){return lockscreen;}}''',
    'android/app/NotificationManager.java': '''package android.app;import java.util.*;
public class NotificationManager{public static final int IMPORTANCE_NONE=0,IMPORTANCE_MIN=1,IMPORTANCE_LOW=2,IMPORTANCE_DEFAULT=3,IMPORTANCE_HIGH=4;
public final Map<String,NotificationChannel> channels=new HashMap<>();public final Map<String,Notification> posted=new LinkedHashMap<>();public boolean enabled=true,refuse;
public void createNotificationChannel(NotificationChannel c){NotificationChannel old=channels.get(c.id);if(old==null)channels.put(c.id,c);else{old.name=c.name;old.description=c.description;}}
public NotificationChannel getNotificationChannel(String id){return channels.get(id);}public boolean areNotificationsEnabled(){return enabled;}
public void notify(String tag,int id,Notification n){if(refuse)throw new SecurityException("refused");posted.put(tag+"#"+id,n);}}''',
    'com/tiagolima/agendapersonal/R.java': 'package com.tiagolima.agendapersonal;public final class R{public static final class drawable{public static final int ic_stat_cadastro=0x7f080001;}}',
    'com/tiagolima/agendapersonal/MainActivity.java': 'package com.tiagolima.agendapersonal;public class MainActivity extends android.app.Activity{}',
}

HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.*;import android.content.*;import org.json.JSONObject;import java.util.*;
public final class AvisosCadastroHarness{
static int checks;static void check(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m);}
static Map<String,String> data(String... kv){Map<String,String> m=new LinkedHashMap<>();for(int i=0;i<kv.length;i+=2)m.put(kv[i],kv[i+1]);return m;}
static JSONObject status(Context c){return new JSONObject(AvisosCadastro.status(c));}
public static void main(String[] a){
 // 1. O pedido do conteúdo.
 AvisosCadastro.Aviso ana=AvisosCadastro.ler(data("tipo","cadastro","titulo","Novo cadastro","texto","Ana se cadastrou. Toque para aprovar.","aluno","abcDEF123"));
 check(ana!=null&&ana.titulo.equals("Novo cadastro")&&ana.texto.equals("Ana se cadastrou. Toque para aprovar.")&&ana.tag().equals("cadastro:abcDEF123"),"cadastro lido");
 check(AvisosCadastro.ler(null)==null&&AvisosCadastro.ler(data("tipo","promo","titulo","x"))==null&&AvisosCadastro.ler(data("titulo","sem tipo"))==null,"só tipos conhecidos");
 AvisosCadastro.Aviso vazio=AvisosCadastro.ler(data("tipo","cadastro"));
 check(vazio.titulo.equals("Novo cadastro")&&vazio.texto.equals("Um aluno se cadastrou. Toque para aprovar.")&&vazio.tag().equals("cadastro"),"textos padrão");
 check(AvisosCadastro.ler(data("tipo","cadastro","aluno","../x")).aluno.isEmpty()&&AvisosCadastro.ler(data("tipo","cadastro","aluno","a b")).aluno.isEmpty(),"aluno inválido descartado");
 AvisosCadastro.Aviso sujo=AvisosCadastro.ler(data("tipo","cadastro","titulo","\nNovo\u0007 cadastro\t","texto","Bia\u0000 se cadastrou."));
 check(!sujo.titulo.matches("(?s).*[\\u0000-\\u001f].*")&&!sujo.texto.matches("(?s).*[\\u0000-\\u001f].*"),"sem caracteres de controle");
 StringBuilder longo=new StringBuilder();for(int i=0;i<300;i++)longo.append("😀");
 String cortado=AvisosCadastro.ler(data("tipo","teste","texto",longo.toString())).texto;
 check(cortado.codePointCount(0,cortado.length())==240&&!Character.isHighSurrogate(cortado.charAt(cortado.length()-1)),"texto longo cortado sem quebrar emoji");
 AvisosCadastro.Aviso json=AvisosCadastro.lerJson("{\"tipo\":\"cadastro\",\"titulo\":\"Novo cadastro\",\"texto\":\"Caio se cadastrou. Toque para aprovar.\",\"aluno\":\"uidCaio9\"}");
 check(json!=null&&json.tag().equals("cadastro:uidCaio9")&&json.texto.startsWith("Caio"),"pedido em JSON da ponte");
 check(AvisosCadastro.lerJson(null)==null&&AvisosCadastro.lerJson("não é json")==null&&AvisosCadastro.lerJson("{\"tipo\":\"x\"}")==null,"JSON inválido ou desconhecido");
 StringBuilder enorme=new StringBuilder("{\"tipo\":\"cadastro\",\"texto\":\"");for(int i=0;i<2100;i++)enorme.append('a');enorme.append("\"}");
 check(AvisosCadastro.lerJson(enorme.toString())==null,"pedido grande demais recusado");
 check(AvisosCadastro.lerJson("{\"tipo\":\"cadastro\",\"aluno\":123}").aluno.isEmpty(),"campo que não é texto é ignorado");

 // 2. Notificação.
 Context c=new Context();
 check(AvisosCadastro.mostrar(c,ana),"aviso mostrado");
 NotificationChannel canal=c.manager.getNotificationChannel("cadastros");
 check(canal!=null&&canal.name.equals("Cadastros de alunos")&&canal.importance==NotificationManager.IMPORTANCE_HIGH&&canal.lockscreen==Notification.VISIBILITY_PRIVATE&&canal.badge&&canal.vibration&&!canal.description.isEmpty(),"canal com alerta e tela bloqueada");
 Notification n=c.manager.posted.get("cadastro:abcDEF123#4101");
 check(n!=null&&n.channel.equals("cadastros")&&n.icon==R.drawable.ic_stat_cadastro&&n.color==0xFF568900,"canal, ícone e cor");
 check(n.title.equals("Novo cadastro")&&n.text.equals(ana.texto)&&n.bigText.equals(ana.texto)&&n.autoCancel&&n.showWhen&&n.when>0,"textos e toque único");
 check(n.visibility==Notification.VISIBILITY_PRIVATE&&n.publicVersion!=null&&!n.publicVersion.text.contains("Ana")&&n.publicVersion.title.equals("Novo cadastro")&&n.publicVersion.icon==R.drawable.ic_stat_cadastro,"tela bloqueada sem conteúdo sensível mostra versão sem o nome");
 PendingIntent toque=n.contentIntent;
 check(toque.flags==(PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE)&&toque.requestCode=="cadastro:abcDEF123".hashCode(),"toque imutável, um por aluno");
 check(toque.intent.target==MainActivity.class&&toque.intent.flags==(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP),"toque abre o app sem recriar a tela");
 check("cadastro".equals(toque.intent.extras.get("agenda_aviso_tipo"))&&"abcDEF123".equals(toque.intent.extras.get("agenda_aviso_aluno"))&&toque.intent.extras.size()==2,"extras do toque");
 check(AvisosCadastro.mostrarJson(c,"{\"tipo\":\"cadastro\",\"texto\":\"Caio se cadastrou. Toque para aprovar.\",\"aluno\":\"zzz999\"}"),"pedido da ponte mostrado");
 check(c.manager.posted.size()==2&&c.manager.posted.get("cadastro:zzz999#4101").contentIntent.requestCode!=toque.requestCode,"dois alunos, dois avisos");
 AvisosCadastro.mostrar(c,ana);check(c.manager.posted.size()==2,"o mesmo aluno substitui o aviso anterior");
 AvisosCadastro.Aviso teste=AvisosCadastro.ler(data("tipo","teste","titulo","Teste do aviso","texto","Assim chega o aviso de um cadastro novo."));
 check(AvisosCadastro.mostrar(c,teste)&&c.manager.posted.get("teste#4101").publicVersion.text.equals(teste.texto),"aviso de teste");
 check(!AvisosCadastro.mostrar(c,null)&&!AvisosCadastro.mostrarJson(c,"{}")&&c.manager.posted.size()==3,"pedido desconhecido não mostra nada");
 Context recusa=new Context();recusa.manager.refuse=true;check(!AvisosCadastro.mostrar(recusa,ana),"Android recusou: sem travar");

 // 3. Abertura pelo toque.
 Intent aberto=new Intent(c,MainActivity.class).putExtra("agenda_aviso_tipo","cadastro").putExtra("agenda_aviso_aluno","abcDEF123").putExtra("outro","fica");
 check(AvisosCadastro.abertura(aberto).equals("cadastro")&&aberto.extras.keySet().equals(Set.of("outro")),"abertura lida uma vez");
 check(AvisosCadastro.abertura(aberto).isEmpty()&&AvisosCadastro.abertura(null).isEmpty(),"não repete");
 check(AvisosCadastro.abertura(new Intent(c,MainActivity.class).putExtra("tipo","cadastro")).isEmpty(),"só os extras do próprio aviso");
 check(AvisosCadastro.abertura(new Intent(c,MainActivity.class).putExtra("agenda_aviso_tipo","pagamento")).isEmpty(),"tipo desconhecido ignorado");

 // 4. Estado para "Sons e alertas".
 Context s=new Context();JSONObject e=status(s);
 check(e.optInt("versao")==1&&e.optString("app").equals("1.211")&&e.optString("canal").equals("ausente")&&!e.optBoolean("telaBloqueada")&&e.optBoolean("permissao"),"antes do canal");
 check(!e.has("token")&&!e.has("configurado"),"sem nada do push");
 s.packages.versionName=null;check(status(s).optString("app").isEmpty()&&status(s).optInt("versao")==1,"sem a versão do APK: estado continua");s.packages.versionName="1.211";
 AvisosCadastro.criarCanal(s);check(status(s).optString("canal").equals("alerta")&&status(s).optBoolean("telaBloqueada"),"canal com alerta");
 NotificationChannel sc=s.manager.getNotificationChannel("cadastros");
 sc.importance=NotificationManager.IMPORTANCE_DEFAULT;check(status(s).optString("canal").equals("som"),"sem pop-up");
 sc.importance=NotificationManager.IMPORTANCE_LOW;check(status(s).optString("canal").equals("silencioso"),"silencioso");
 sc.importance=NotificationManager.IMPORTANCE_NONE;check(status(s).optString("canal").equals("desligado"),"desligado");
 AvisosCadastro.criarCanal(s);check(sc.importance==NotificationManager.IMPORTANCE_NONE,"o app não desfaz a escolha do Tiago no canal");
 sc.lockscreen=Notification.VISIBILITY_SECRET;check(!status(s).optBoolean("telaBloqueada"),"tela bloqueada desligada no canal");
 s.permission=-1;check(!status(s).optBoolean("permissao"),"Android 13+: sem permissão de notificação");
 android.os.Build.VERSION.SDK_INT=32;check(status(s).optBoolean("permissao"),"Android 12: permissão não existe");android.os.Build.VERSION.SDK_INT=35;
 s.permission=0;s.manager.enabled=false;check(!status(s).optBoolean("permissao"),"notificações do app desligadas");

 // 5. Configurações do canal.
 Activity t=new Activity();AvisosCadastro.abrirConfiguracoes(t);
 check(t.started.size()==1&&t.started.get(0).action.equals("android.settings.CHANNEL_NOTIFICATION_SETTINGS")&&"cadastros".equals(t.started.get(0).extras.get("android.provider.extra.CHANNEL_ID"))&&"com.tiagolima.agendapersonal".equals(t.started.get(0).extras.get("android.provider.extra.APP_PACKAGE")),"abre o canal");
 Activity u=new Activity();u.missing.add("android.settings.CHANNEL_NOTIFICATION_SETTINGS");AvisosCadastro.abrirConfiguracoes(u);
 check(u.started.size()==1&&u.started.get(0).action.equals("android.settings.APP_NOTIFICATION_SETTINGS"),"sem tela do canal: notificações do app");
 Activity v=new Activity();v.missing.add("android.settings.CHANNEL_NOTIFICATION_SETTINGS");v.missing.add("android.settings.APP_NOTIFICATION_SETTINGS");AvisosCadastro.abrirConfiguracoes(v);
 check(v.started.isEmpty(),"sem nenhuma tela: sem travar");
 System.out.println("PASS: aviso de novo cadastro, "+checks+" verificações.");
}}
'''


def main():
    static_checks()
    java = shutil.which('java')
    javac = shutil.which('javac')
    if not java:
        raise SystemExit('Java 17 é necessário para estes testes.')
    compiler = [javac] if javac else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-avisos-tests-') as temporary:
        work = Path(temporary)
        stubs = dict(STUBS)
        for name in ['JSONObject', 'JSONArray', 'JSONTokener']:
            stubs['org/json/' + name + '.java'] = (PROJECT / 'tests/native-json/org/json' / (name + '.java')).read_text()
        stubs['com/tiagolima/agendapersonal/AvisosCadastroHarness.java'] = HARNESS
        sources = []
        for name, content in stubs.items():
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding='utf-8')
            sources.append(str(target))
        sources.append(str(SOURCE / 'AvisosCadastro.java'))
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + sources, check=True)
        subprocess.run([java, '-ea', '-cp', str(work / 'classes'), 'com.tiagolima.agendapersonal.AvisosCadastroHarness'], check=True)
    print('PASS: ligações do aviso de novo cadastro no projeto (sem Firebase, ponte, ícone) conferidas.')


if __name__ == '__main__':
    main()
