'use strict';
// Startup/account integration with a minimal DOM and Firebase doubles, not a real WebView.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const assets=path.resolve(__dirname,'../app/src/main/assets'),html=fs.readFileSync(path.join(assets,'index.html'),'utf8');
const nodes=new Map(),events=new Map(),storage=new Map();
function element(id){
 if(nodes.has(id))return nodes.get(id);
 const attrs=new Map(),classes=new Set(),callbacks=new Map();
 const n={id,value:'',hidden:false,textContent:'',innerHTML:'',firstChild:{textContent:''},dataset:{},options:[],style:{setProperty(){},removeProperty(){}},
 classList:{add(...a){a.forEach(x=>classes.add(x))},remove(...a){a.forEach(x=>classes.delete(x))},contains:x=>classes.has(x),toggle(x,v){if(v===false)classes.delete(x);else classes.add(x)}},
 setAttribute(k,v){attrs.set(k,v)},getAttribute:k=>attrs.get(k)||null,hasAttribute:k=>attrs.has(k),removeAttribute(k){attrs.delete(k);if(k==='srcdoc')delete n.srcdoc;if(k.startsWith('data-'))delete n.dataset[k.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]},
 addEventListener(k,fn){if(!callbacks.has(k))callbacks.set(k,[]);callbacks.get(k).push(fn)},fire(k){for(const fn of callbacks.get(k)||[])fn({})},removeEventListener(){},querySelector(){return null},querySelectorAll(){return []},append(){},appendChild(){},insertBefore(){},prepend(){},focus(){},remove(){},getBoundingClientRect(){return {width:400,height:800,left:0,top:0}},scrollTo(){}};
 Object.defineProperty(n,'srcdoc',{configurable:true,get(){return attrs.get('srcdoc')},set(v){attrs.set('srcdoc',v)}});
 nodes.set(id,n);return n;
}
for(const m of html.matchAll(/<([a-z][a-z0-9-]*)\b([^>]*\bid="([^"]+)"[^>]*)>/gi)){const n=element(m[3]);n.hidden=/\bhidden\b/.test(m[2]);const a=m[2].match(/data-asset="([^"]+)"/);if(a)n.dataset.asset=a[1];}
for(const m of html.matchAll(/<script\b[^>]*\bid="([^"]+)"[^>]*>([\s\S]*?)<\/script>/gi))element(m[1]).textContent=m[2];
const ctx={console,URL,URLSearchParams,TextDecoder,TextEncoder,Uint8Array,Blob,Date,Math,Map,Set,Promise,structuredClone,atob,btoa,
 setTimeout(){return 1},clearTimeout(){},setInterval(){return 1},clearInterval(){},requestAnimationFrame(){},cancelAnimationFrame(){},
 CustomEvent:class{constructor(type,o){this.type=type;this.detail=o?.detail}},Event:class{constructor(type){this.type=type}},
 innerWidth:400,innerHeight:800,localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k)},sessionStorage:{getItem(){return null},setItem(){},removeItem(){}},
 navigator:{onLine:false,userAgent:'Android',clipboard:{}},location:{href:'https://appassets.androidplatform.net/assets/index.html',search:''},history:{pushState(){},replaceState(){},back(){ctx.backCalls=(ctx.backCalls||0)+1}},
 document:{baseURI:'https://appassets.androidplatform.net/assets/index.html',getElementById:id=>nodes.get(id)||null,querySelector(){return null},querySelectorAll(){return []},createElement:tag=>element('new-'+Math.random()),body:element('body'),documentElement:element('html'),addEventListener(){}},
 matchMedia(){return {matches:false,addEventListener(){}}},Image:class{},alert(){},confirm(){return false},
 addEventListener(type,fn){if(!events.has(type))events.set(type,[]);events.get(type).push(fn)},dispatchEvent(e){for(const fn of events.get(e.type)||[])fn(e)},scrollTo(){},
 fetch:async url=>{const name=new URL(url).pathname.split('/').pop();return {ok:true,text:async()=>fs.readFileSync(path.join(assets,name),'utf8')}}};
ctx.window=ctx;ctx.globalThis=ctx;ctx.parent=ctx;vm.createContext(ctx);
let scripts=0;
for(const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)){
 if(/type="(?:application\/octet-stream|text\/plain)"/.test(m[1]))continue;
 let code=m[2];if(m[1].includes('ap-student-accounts'))code=code.replace(/\n\}\)\(\);\s*$/, '\nwindow.__accountTest={setSdk:value=>sdk=value,activate};\n})();');
 vm.runInContext(code,ctx,{filename:'entry-'+scripts++,importModuleDynamically(){return Promise.reject(Error('Offline test'))}});
}
async function run(){
 assert.ok(Buffer.byteLength(html)<2*1024*1024);assert.equal(ctx.document.body.dataset.view,'landing');assert.ok(ctx.APaccounts&&ctx.APstudentUI);assert.equal(ctx.handleAgendaSystemBack(),false);
 for(const file of ['index.html','professor.html','avaliacoes.html','cadastro.html']){const source=fs.readFileSync(path.join(assets,file),'utf8');for(const m of source.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){if(/type="(?:application\/octet-stream|text\/plain)"/.test(m[1]))continue;new vm.Script(m[2],{filename:file})}}
 assert.equal(html.includes('agendaPersonalTL_TESTE_brand_159'),false);
 const teacher=ctx.APStudentModel.TEACHER;
 const sdk={auth:{currentUser:{uid:teacher}},signOut:async auth=>auth.currentUser=null};
 ctx.__accountTest.setSdk(sdk);storage.set('agendaPersonalTL_v1',JSON.stringify({students:[{id:'old',name:'Preservado'}],lessons:[]}));
 storage.set('ap_professor_marca_159_professor_teste',JSON.stringify({completed:true,name:'Professor',description:'Personal Trainer',main:'#A12CFF',support:'#08070C',bg:'#08070C',design:'atual'}));
 await ctx.__accountTest.activate({uid:teacher,email:'professor@example.test'},'Professor');await new Promise(resolve=>setImmediate(resolve));
 assert.equal(ctx.APaccounts.isTeacher(),true);const frame=element('apPreviewTeacher');assert.ok(frame.srcdoc.includes("const DB_KEY='agendaPersonalTL_v1';"));assert.ok(frame.srcdoc.includes('workoutInlineBounds=function'));assert.equal(JSON.parse(storage.get('agendaPersonalTL_v1')).students[0].name,'Preservado');
 for(const m of frame.srcdoc.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){if(/type="(?:application\/octet-stream|text\/plain)"/.test(m[1]))continue;new vm.Script(m[2],{filename:'prepared-professor.html'})}
 const legacyCode=html.match(/<script id="ap-legacy-storage-bootstrap">([\s\S]*?)<\/script>/)[1];let legacyCaptured=null;const oldStorage=new Map([['agendaPersonalTL_v1','antigos-preservados'],['irrelevant','omitido']]);
 vm.runInNewContext(legacyCode,{window:{Android:true},location:{protocol:'file:'},Android:{captureLegacyStorage:s=>legacyCaptured=JSON.parse(s)},localStorage:{length:oldStorage.size,key:i=>[...oldStorage.keys()][i],getItem:k=>oldStorage.get(k)}});
 assert.equal(legacyCaptured.agendaPersonalTL_v1,'antigos-preservados');assert.equal(legacyCaptured.irrelevant,undefined);assert.equal(oldStorage.size,2);
 let registrations=0,tabs=[];frame.contentWindow={openRegistrationLink(){registrations++},setRegistrationTab(t){tabs.push(t)},handleAgendaSystemBack(){return false}};
 ctx.APaccounts.openRegistrations();assert.equal(registrations,1);assert.deepEqual(tabs,['contacts']);assert.equal(ctx.handleAgendaSystemBack(),true);
 assert.equal(element('apPreviewOverlay').classList.contains('is-open'),false);
 await ctx.APaccounts.logout();assert.equal(ctx.APaccounts.isTeacher(),false);assert.equal(ctx.__AP_STUDENT_CONTEXT,null);assert.equal(frame.hasAttribute('srcdoc'),false);assert.equal(ctx.document.body.dataset.view,'landing');assert.equal(JSON.parse(storage.get('agendaPersonalTL_v1')).students[0].name,'Preservado');
 const student={uid:'student_alice',email:'alice@example.test'};sdk.auth.currentUser=student;sdk.doc=(db,...p)=>p.join('/');sdk.getDoc=async()=>({exists:()=>true,data:()=>({perfil:'aluno',professorId:teacher,ativo:false,nome:'Alice'})});
 await assert.rejects(()=>ctx.__accountTest.activate(student,'Aluno'),/aprovação/);assert.equal(ctx.__AP_STUDENT_CONTEXT,null);
 sdk.getDoc=async()=>({exists:()=>true,data:()=>({perfil:'aluno',professorId:teacher,ativo:true,nome:'Alice',genero:'Feminino'})});sdk.onSnapshot=()=>()=>{};
 await ctx.__accountTest.activate(student,'Aluno');assert.equal(ctx.__AP_STUDENT_CONTEXT.storageId,student.uid);assert.equal(ctx.APaccounts.isTeacher(),false);
 ctx.APstudentStorage.setItem('agenda_demo_fixture','only-Alice');assert.equal(storage.get('agenda_student_v2_student_alice:agenda_demo_fixture'),'only-Alice');
 await ctx.APaccounts.logout();assert.equal(ctx.APstudentStorage.getItem('agenda_demo_fixture'),null);assert.equal(storage.get('agenda_student_v2_student_alice:agenda_demo_fixture'),'only-Alice');assert.equal(storage.has('agenda_demo_fixture'),false);
 console.log('PASS: entry boot, script syntax in 4 pages, teacher frame, production database, invites entry, Android Back delegation, logout, approval gate and student storage isolation. DOM/Firebase simulated.');
}
run().catch(e=>{console.error(e);process.exitCode=1});
