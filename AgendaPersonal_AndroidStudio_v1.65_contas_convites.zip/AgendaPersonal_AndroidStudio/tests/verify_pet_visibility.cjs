'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const {chromium}=require('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';if(!['index.html','professor.html','avaliacoes.html','cadastro.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.failPetPreference&&k.startsWith('agenda_pet_visible_v1_'))throw Error('quota');return set.call(this,k,v)}});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  const url='http://127.0.0.1:'+server.address().port;
  async function boot(){await page.goto(url);await page.waitForFunction(()=>!!window.APmascot)}
  async function student(uid='alice',role='student'){
   await page.evaluate(({uid,role})=>{
    window.dispatchEvent(new Event('ap-account-changed'));
    const student={id:'local_'+uid,firebaseUid:uid,name:'Aluna de teste',gender:'Feminino'};
    const area=APStudentModel.makeArea({students:[student],workoutPlans:[]},student);
    window.__AP_STUDENT_CONTEXT={storageId:uid,role,area,profile:area.profile};APstudentUI.activate(role==='preview');route('home');
   },{uid,role});
  }
  await boot();await student();
  await page.locator('#apMascotHome').click();await page.locator('#apMascotChoices [data-mascot-item="kitten"]').click();
  const saved=await page.evaluate(()=>{const s=exStore();s.mascot={...APmascot.state(),name:'Luna',coins:225,xp:600};exSave(s);return APstudentStorage.getItem(exStorageKey())});
  await page.locator('#apPetHide').click();assert.equal(await page.locator('#apMascotHome').isVisible(),false);assert.equal(await page.locator('#apMascotBody').isVisible(),false);assert.equal(await page.locator('#apPetHide').getAttribute('aria-pressed'),'true');
  assert.equal(await page.evaluate(()=>APstudentStorage.getItem(exStorageKey())),saved,'hiding preserves the complete workout and pet store');
  await page.keyboard.press('Escape');await page.evaluate(()=>{route('profile');profileRender()});await page.locator('#apProfilePet').click();await page.locator('#apPetHiddenNote').waitFor();
  await page.evaluate(()=>window.failPetPreference=true);await page.locator('#apPetShow').click();assert.match(await page.locator('#apMascotStatus').textContent(),/Não foi possível salvar/);assert.equal(await page.locator('#apMascotBody').isVisible(),false);await page.evaluate(()=>window.failPetPreference=false);
  await page.reload();await page.waitForFunction(()=>!!window.APmascot);await student();assert.equal(await page.locator('#apMascotHome').isVisible(),false,'choice persists after reload');
  await student('bob');assert.equal(await page.locator('#apMascotHome').isVisible(),true,'another student retains their own preference');
  await student('alice','preview');await page.evaluate(()=>APmascot.open());assert.equal(await page.locator('#apPetShow').isEnabled(),false,'preview cannot change student choice');
  await student();await page.evaluate(()=>APmascot.open());await page.locator('#apPetShow').click();assert.equal(await page.evaluate(()=>APstudentStorage.getItem(exStorageKey())),saved);assert.equal(await page.evaluate(()=>APmascot.state().name),'Luna');assert.equal(await page.locator('#apMascotBody').isVisible(),true);
  await page.keyboard.press('Escape');
  await page.evaluate(async()=>{window.__AP_STUDENT_CONTEXT=null;window.APaccounts={isTeacher:()=>true,teacherUid:()=> 'teacher_alice'};window.dispatchEvent(new Event('ap-account-changed'));document.getElementById('apPreviewOverlay').classList.add('is-open');document.getElementById('apPreviewTeacher').srcdoc=await(await fetch('professor.html')).text()});
  const frame=page.frameLocator('#apPreviewTeacher');await frame.locator('#morePet').waitFor({state:'attached'});await frame.locator('body').evaluate(()=>{chooseAppDesign('deep-tl');showScreen('more')});
  await frame.locator('#morePet').click();assert.equal(await frame.locator('#morePet').getAttribute('aria-pressed'),'true');await frame.locator('#morePet').click();await page.locator('#apPetHide').click();assert.equal(await frame.locator('#apTeacherMascotOpen').isVisible(),false);await page.keyboard.press('Escape');
  assert.equal(await frame.locator('#morePet').isVisible(),true,'entry remains accessible while hidden');assert.equal(await frame.locator('#morePet').evaluate(n=>n===document.activeElement),true,'focus returns to Pet');
  const cards=frame.locator('[aria-labelledby="moreOptionsTitle"] .more-function');assert.equal(await cards.count(),10);
  for(const width of [320,390,480]){
   await page.setViewportSize({width,height:844});await frame.locator('#morePet').scrollIntoViewIfNeeded();
   await frame.locator('#morePet [data-deep-solid="pet"]').waitFor();
   const geometry=await frame.locator('#morePet').evaluate(p=>{const a=p.getBoundingClientRect(),b=document.getElementById('moreAccountLogout').getBoundingClientRect();return {fits:p.scrollWidth<=p.clientWidth+1,sameRow:Math.abs(a.top-b.top)<1,right:a.left>b.left,icon:!!p.querySelector('[data-deep-solid="pet"]')}});
   assert.ok(geometry.fits&&geometry.sameRow&&geometry.right&&geometry.icon,'Pet fits next to Sair da conta at '+width);
   await frame.locator('#morePet').click();assert.equal(await page.locator('#apMascotBody').isVisible(),false);assert.ok(await page.locator('.ap-mascot-sheet').evaluate(n=>n.scrollWidth<=n.clientWidth+1));await page.keyboard.press('Escape');
  }
  await frame.locator('#morePet').click();await page.locator('#apPetShow').click();assert.equal(await frame.locator('#apTeacherMascotOpen').getAttribute('hidden'),null);await page.keyboard.press('Escape');
  assert.equal(await page.evaluate(()=>APmascot.isEnabled('alice')),true,'teacher choice does not affect pupil');
  assert.deepEqual(errors,[]);
  if(process.env.AGENDA_REVIEW_DIR){fs.mkdirSync(process.env.AGENDA_REVIEW_DIR,{recursive:true});await page.setViewportSize({width:390,height:844});await frame.locator('#morePet').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(process.env.AGENDA_REVIEW_DIR,'pet-menu.png')});await frame.locator('#morePet').click();await page.locator('#apPetHide').click();await page.screenshot({path:path.join(process.env.AGENDA_REVIEW_DIR,'pet-hidden.png')})}
  console.log('PASS: Pet card beside logout; persistent hide/reactivate; teacher/student/preview isolation; quota rollback; preserved name/coins/XP; profile recovery entry; keyboard focus; responsive 320/390/480 px; no JS errors. Local browser; authentication simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
