'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'..'),manifest=JSON.parse(fs.readFileSync(path.join(root,'web/mascot-images/manifest.json'))),images={};
for(const [species,phases] of Object.entries(manifest)){images[species]={};for(const [phase,item] of Object.entries(phases))images[species][phase]='data:'+item.mime+';base64,'+fs.readFileSync(path.join(root,'web/mascot-images',item.file)).toString('base64')}
let data=images,failDecode=false,events=[];
const ctx={APMascotModel:{choices:Object.keys(images).map(id=>({id,name:id})),phase:xp=>xp>=1800?{id:'adult',name:'Adulto'}:xp>=600?{id:'teen',name:'Adolescente'}:{id:'baby',name:'Filhote'}},Event:function(type){this.type=type},dispatchEvent:e=>events.push(e.type),document:{baseURI:'https://local.test/'},URL,fetch:async()=>({text:async()=>'<html></html>'}),DOMParser:class{parseFromString(){return {getElementById:id=>['ap-mascot-affection-assets','ap-mascot-gesture-runtime','ap-mascot-reaction-assets'].includes(id)?null:({textContent:JSON.stringify(id==='ap-mascot-pose-assets'?{}:id==='ap-mascot-coat-assets'?Object.fromEntries(Object.keys(images).map(s=>[s,{0:images[s]}])):data)})}}},Image:class{set src(uri){this.naturalWidth=1600;this.naturalHeight=960;queueMicrotask(()=>failDecode?this.onerror():this.onload())}}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'web/student-mascot-art.js'),'utf8'),ctx);
(async()=>{
const A=ctx.APMascotArt,s={species:'wolf',name:'Léo',xp:1800};
assert.ok(!A.render(s).includes('<rect'),'no white loading tile');
assert.ok(!A.render(s,true,'data:image/jpeg;base64,YQ==').includes('<image'),'old opaque portrait cache cannot flash');
assert.ok(A.render(s,true,images.wolf.adult).includes('<image'),'transparent cache can paint before the library is ready');
data={...images,wolf:{...images.wolf,adult:'data:image/jpeg;base64,YQ=='}};assert.equal(await A.load(),false,'opaque asset is rejected');assert.equal(A.error(),true);
assert.match(A.render(s,true,images.wolf.adult),/transform="translate\(320 0\) scale\(-1 1\)"/,'early cached wolf faces the speech');
data=images;failDecode=true;assert.equal(await A.load(),false,'decode failure is retryable');failDecode=false;assert.equal(await A.load(),true);assert.equal(A.ready(),true);assert.equal(A.error(),false);
for(const species of Object.keys(images))for(const [phase,xp] of [['baby',0],['teen',600],['adult',1800]]){const state={species,name:species,xp};assert.equal(A.portrait(state),images[species][phase]);const svg=A.render(state);assert.ok(svg.includes(images[species][phase]));assert.ok(!svg.includes('<rect'));assert.equal(svg.includes('transform="translate(320 0) scale(-1 1)"'),({kitten:['teen','adult'],wolf:['adult'],capybara:['baby','teen'],panda:['teen','adult'],rooster:['teen','adult'],alligator:['teen','adult']}[species]||[]).includes(phase),'portrait faces the speech bubble without mirroring text');}
assert.equal(events.at(-1),'ap-mascot-art-ready');console.log('PASS: 18 exact transparent assets, growth phase selection, old JPEG cache rejection, neutral loading, invalid/decode retry and successful hydration.');
})().catch(e=>{console.error(e);process.exitCode=1});
