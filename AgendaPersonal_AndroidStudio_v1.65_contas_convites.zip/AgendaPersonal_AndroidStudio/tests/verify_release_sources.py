"""Check the shared ZIP inventory, including editor junk and unexpected archive files."""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from release_files import source_files

with tempfile.TemporaryDirectory() as folder:
    base = Path(folder)
    for name in ['release.json', '.github/workflows/build.yml', 'web/active.js', 'app/src/main/assets/icon.png', 'app/src/main/assets/index.html', 'app/src/main/assets/.professor.html.interrupted', 'web/active.js.bak', 'node_modules/unused.js', 'local.properties', 'VERIFICACAO_ANTIGA.json', 'tests/reports/old.json']:
        file = base / name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text('fixture')
    assert {name for name, _ in source_files(base)} == {'release.json', '.github/workflows/build.yml', 'web/active.js', 'app/src/main/assets/icon.png'}

release = json.loads((ROOT / 'release.json').read_text())
actual = {name: hashlib.sha256(file.read_bytes()).hexdigest() for name, file in source_files(ROOT) if name != 'release.json'}
assert actual == release['sourceHashes'], 'Whole-project manifest drift'
if len(sys.argv) > 1:
    prefix = 'AgendaPersonal_AndroidStudio/'
    with ZipFile(sys.argv[1]) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {prefix + 'release.json'} | {prefix + name for name in actual}
        for name, expected in actual.items():
            assert hashlib.sha256(archive.read(prefix + name)).hexdigest() == expected, name
print(f'PASS: complete inventory of {len(actual)} source files; generated pages, editor leftovers and dependency folders excluded; exact archive contents/hashes checked when supplied.')
