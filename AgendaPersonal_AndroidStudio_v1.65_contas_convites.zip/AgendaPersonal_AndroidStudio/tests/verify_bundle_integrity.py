"""Verify the exact bundled assets, native update contract and executable inline JavaScript.

Runs without an Android device, Firebase, network, Node dependencies or Chromium.
"""
from html.parser import HTMLParser
from pathlib import Path
import json
import re
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
ASSETS = PROJECT / 'app/src/main/assets'
UPDATE = (PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateManager.java').read_text(encoding='utf8')
GRADLE = (PROJECT / 'app/build.gradle').read_text(encoding='utf8')


class ScriptParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.type = None
        self.chunks = []
        self.scripts = []

    def handle_starttag(self, name, attrs):
        if name == 'script':
            self.type = dict(attrs).get('type', 'text/javascript').lower()
            self.chunks = []

    def handle_data(self, data):
        if self.type is not None:
            self.chunks.append(data)

    def handle_endtag(self, name):
        if name == 'script' and self.type is not None:
            if self.type in {'text/javascript', 'application/javascript', 'module', ''}:
                code = ''.join(self.chunks)
                if code.strip():
                    self.scripts.append((self.type, code))
            self.chunks = []
            self.type = None


def main():
    files = ('index.html', 'professor.html', 'avaliacoes.html', 'cadastro.html')
    bundled = {name: (ASSETS / name).read_text(encoding='utf8') for name in files}
    version = re.search(r'BASE_VERSION\s*=\s*"(\d+\.\d+\.\d+)"', UPDATE)
    sequence = re.search(r'BASE_SEQUENCE\s*=\s*(\d+)', UPDATE)
    android_version = re.search(r"versionName\s+'([^']+)'", GRADLE)
    assert version and sequence and android_version, 'Identificação de versão ausente'
    assert int(sequence[1]) > 0
    assert android_version[1] == '1.102', 'Contrato nativo precisa de revisão antes da publicação'
    assert re.search(r'bridgeVersion",\s*3', UPDATE), 'Ponte nativa divergente'
    assert re.search(r'dataSchema",\s*4', UPDATE), 'Esquema de dados divergente'
    assert len(json.dumps({'format': 1, 'appId': 'com.tiagolima.agendapersonal',
                           'bridgeVersion': 3, 'dataSchema': 4, 'version': version[1],
                           'sequence': int(sequence[1]), 'files': bundled},
                          ensure_ascii=False).encode('utf-8')) < 24 * 1024 * 1024, 'Pacote excede 24 MiB'
    count = 0
    with tempfile.TemporaryDirectory(prefix='agenda-script-validation-') as directory:
        for name, html in bundled.items():
            assert re.search(r'<head\b[^>]*>', html, re.I) and '</html>' in html.lower(), f'HTML incompleto: {name}'
            if name != 'cadastro.html':
                assert 'data-agenda-ready' in html, f'Ponto de confirmação nativa ausente: {name}'
            parser = ScriptParser()
            parser.feed(html)
            for num, (script_type, code) in enumerate(parser.scripts):
                path = Path(directory) / f"{name}-{num}.{'mjs' if script_type == 'module' else 'js'}"
                path.write_text(code, encoding='utf-8')
                proc = subprocess.run(['node', '--check', str(path)], capture_output=True, text=True)
                if proc.returncode:
                    raise AssertionError(f'Erro de sintaxe em {name}, script {num}: {proc.stderr[-1000:]}')
                count += 1
    assert count >= 35, 'Menos scripts executáveis do que o esperado'
    print(f'Pacote íntegro: {len(files)} páginas, versão web {version[1]}, sequência {sequence[1]}, '
          f'Android {android_version[1]}, {count} scripts executáveis com sintaxe válida; limites respeitados.')


if __name__ == '__main__':
    main()
