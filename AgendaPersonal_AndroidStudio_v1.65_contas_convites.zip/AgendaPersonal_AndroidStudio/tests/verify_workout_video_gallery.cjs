'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const {chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets'),v1='https://youtu.be/M7lc1UVf-VE?t=10',v2='https://youtu.be/dQw4w9WgXcQ?t=20';
const fixture={students:[{id:'a',name:'Aluna teste',studentType:'presencial',financeEnabled:true,monthlyValue:'300,00',dueDate:'2026-11-14'}],lessons:[],history:[],payments:[{id:'pay',studentId:'a',amount:300,dueDate:'2026-10-14',paidAt:'2026-10-14T12:00:00Z'}],workoutExecutions:[{id:'old',exercises:[{load:'35 kg'}]}],workoutDrafts:{keep:{load:42}},customData:{preserve:true},
 exerciseCatalog:[{id:'old-copy',source:'mine',name:'Agachamento Hack',muscle:'Quadríceps',video:v1,notes:'Texto próprio antigo',customFlag:9}],exerciseCatalogOverrides:{'app-ex-022':{customFlag:'keep'}},exerciseFavorites:['old-copy'],
 workoutPlans:[{id:'p',studentId:'a',name:'Ficha',organization:'sequence',days:[{id:'d',name:'Treino A',exercises:[
 {id:'e',catalogId:'old-copy',name:'Agachamento Hack',muscle:'Quadríceps',category:'Musculação',sets:'3',reps:'12',rest:'60',load:'50 kg',video:v1,notes:'Orientação individual',observations:'Somente nesta ficha'},
 {id:'new-old',name:'Movimento exclusivo da professora',muscle:'Ombros',category:'Musculação',sets:'2',reps:'15',video:v1},
 {id:'conflict1',name:'Isometria exclusiva de teste',video:v1},{id:'conflict2',name:'Isometria exclusiva de teste',video:v2}
 ]}]}]};
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,'professor.html')))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const ctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await ctx.route('https://**',r=>r.abort());
  await ctx.addInitScript(seed=>{localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(seed));const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='agendaPersonalTL_v1'&&window.__failSave)throw Error('Quota');return set.call(this,k,v)}},fixture);
  const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.stack));await page.goto('http://127.0.0.1:'+server.address().port);
  const preserved=await page.evaluate(({v1,v2})=>{
   const [cleared,chosen]=WORKOUT_STARTER_EXERCISES.filter(e=>e.id!=='app-ex-022').slice(0,2);
   state.exerciseCatalogOverrides[cleared.id]={video:''};state.exerciseCatalogOverrides[chosen.id]={video:v2};
   for(const item of [cleared,chosen])state.workoutPlans[0].days[0].exercises.push({...item,id:'recovery-'+item.id,catalogId:item.id,video:v1});
   return {cleared:cleared.id,chosen:chosen.id};
  },{v1,v2});
  const before=await page.evaluate(()=>structuredClone(state));
  await page.evaluate(()=>openWorkoutCatalog());
  assert.equal(await page.evaluate(()=>workoutCatalogItem('app-ex-022').video),v1,'old private copy recovers its exact app match');
  assert.equal(await page.evaluate(()=>state.exerciseCatalog.filter(e=>e.name==='Movimento exclusivo da professora').length),1);
  assert.equal(await page.evaluate(()=>state.exerciseCatalog.some(e=>e.name==='Isometria exclusiva de teste')),false,'conflicting old links are not guessed');
  assert.equal(await page.evaluate(()=>state.exerciseCatalogOverrides['app-ex-022'].customFlag),'keep');
  assert.equal(await page.evaluate(id=>workoutCatalogItem(id).video,preserved.cleared),'','explicitly cleared gallery link stays cleared during first recovery');
  assert.equal(await page.evaluate(id=>workoutCatalogItem(id).video,preserved.chosen),v2,'existing gallery choice wins over old student copy');
  const recovered=await page.evaluate(()=>({plans:state.workoutPlans,executions:state.workoutExecutions,drafts:state.workoutDrafts,payments:state.payments,custom:state.customData}));
  assert.deepEqual(recovered,{plans:before.workoutPlans,executions:before.workoutExecutions,drafts:before.workoutDrafts,payments:before.payments,custom:before.customData});
  await page.locator('#workoutCatalogSearch').fill('Agachamento Hack');await page.locator('#workoutCatalogVideo').selectOption('ready');
  assert.equal(await page.locator('[data-catalog-id="app-ex-022"]').count(),1);
  await page.evaluate(()=>closeDialog('workoutCatalogDialog'));
  async function edit(id='e'){await page.evaluate(id=>{workoutStudentId='a';workoutPlanId='p';workoutDayId='d';openWorkoutExerciseEditor(id)},id)}
  async function save(){await page.locator('#workoutExerciseForm button[type="submit"]').click()}
  await edit();await page.locator('#workoutExerciseVideo').fill(v2);await page.evaluate(()=>document.getElementById('workoutExerciseReusable').checked=false);const count=await page.evaluate(()=>state.exerciseCatalog.length);await save();
  assert.equal(await page.locator('#workoutExerciseDialog').isVisible(),false);assert.equal(await page.evaluate(()=>workoutCatalogItem('app-ex-022').video),v2);assert.equal(await page.evaluate(()=>state.exerciseCatalog.length),count,'editing only video does not add a duplicate');
  assert.equal(await page.evaluate(()=>state.workoutPlans[0].days[0].exercises[0].catalogId),'app-ex-022');
  assert.equal(await page.evaluate(()=>state.exerciseCatalogOverrides['app-ex-022'].notes),undefined,'personal notes do not become shared app instructions');
  for(const key of ['sets','reps','load','rest','notes','observations'])assert.equal(await page.evaluate(k=>state.workoutPlans[0].days[0].exercises[0][k],key),before.workoutPlans[0].days[0].exercises[0][key]);
  await edit();await save();assert.equal(await page.evaluate(()=>state.exerciseCatalog.length),count,'repeated save retains same catalog item');
  await page.evaluate(()=>{openWorkoutExerciseEditor();pickWorkoutCatalogExercise('app-ex-022')});assert.equal(await page.locator('#workoutExerciseVideo').inputValue(),v2,'future workout selection reuses saved link');await page.evaluate(()=>closeDialog('workoutExerciseDialog'));
  await edit();await page.locator('#workoutExerciseName').fill('Agachamento Hack com pausa exclusivo');await save();
  assert.equal(await page.evaluate(()=>state.exerciseCatalog.length),count+1);assert.equal(await page.evaluate(()=>workoutCatalogItem('app-ex-022').video),v2,'renamed variant does not overwrite the original');
  const ownId=await page.evaluate(()=>state.workoutPlans[0].days[0].exercises[0].catalogId);assert.notEqual(ownId,'app-ex-022');
  await edit();await page.locator('#workoutExerciseVideo').fill(v1);await save();assert.equal(await page.evaluate(id=>workoutCatalogItem(id).video,ownId),v1);assert.equal(await page.evaluate(()=>state.exerciseCatalog.length),count+1);
  const stored=await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1'));await edit();await page.locator('#workoutExerciseVideo').fill(v2);await page.evaluate(()=>__failSave=true);await save();assert.equal(await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1')),stored);assert.equal(await page.evaluate(id=>workoutCatalogItem(id).video,ownId),v1,'failed persistence changes neither library nor workout');await page.evaluate(()=>{__failSave=false;closeDialog('workoutExerciseDialog')});
  await edit();await page.locator('#workoutExerciseVideo').fill('javascript:alert(1)');await save();assert.equal(await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1')),stored);await page.evaluate(()=>closeDialog('workoutExerciseDialog'));
  await page.evaluate(()=>openCatalogExerciseEditor('app-ex-022'));await page.locator('#workoutExerciseVideo').fill('');await save();await page.evaluate(()=>openWorkoutCatalog());assert.equal(await page.evaluate(()=>workoutCatalogItem('app-ex-022').video),'','recovery runs once; clearing a gallery link stays cleared');
  assert.deepEqual(await page.evaluate(()=>({executions:state.workoutExecutions,drafts:state.workoutDrafts,payments:state.payments,custom:state.customData})),{executions:before.workoutExecutions,drafts:before.workoutDrafts,payments:before.payments,custom:before.customData});
  const failed=await ctx.newPage();failed.on('pageerror',e=>errors.push(e.stack));await failed.goto('http://127.0.0.1:'+server.address().port);
  const seed=await failed.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1'));await failed.evaluate(()=>{__failSave=true;openWorkoutCatalog()});assert.equal(await failed.evaluate(()=>state.exerciseVideoGalleryMigration),undefined);assert.equal(await failed.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1')),seed);
  await failed.evaluate(()=>{closeDialog('workoutCatalogDialog');__failSave=false;openWorkoutCatalog()});assert.equal(await failed.evaluate(()=>state.exerciseVideoGalleryMigration),1,'failed recovery can be retried');
  assert.deepEqual(errors,[]);console.log('PASS: real teacher forms, recovery of old links/copies, app With video filter, deduplication, private variants, reusable video for new workout, no shared personal prescription, one-time recovery, invalid URL and atomic quota failure. Real media/network not exercised.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
