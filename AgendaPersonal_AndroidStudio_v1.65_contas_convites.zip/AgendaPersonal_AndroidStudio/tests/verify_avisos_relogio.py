"""Aviso no relógio (Android 1.212, pedido do Tiago em 24/11/2026: o Smartwatch "para vários modelos").

Parte A confere as ligações no projeto: a ponte com o conteúdo, o receptor do alarme (não exportado), as permissões, o ícone e que
o descanso, os alarmes e o cronômetro que já existem não mudaram (o aviso é independente deles). Parte B compila as classes REAIS
AvisosRelogio e AvisoRelogioReceiver com Android de mentira e confere: começa desligado; marcar, substituir e desmarcar o aviso de
cada descanso; o alarme exato (e a tolerância sem "Alarmes e lembretes"); o disparo só do aviso que continua marcado; a notificação
(canal com som de notificação e vibração, ticker e texto expandido, tela bloqueada sem nomes, some depois de 2 min; o canal sem som do 1.212 é apagado); o teste em 10 s; o estado e as configurações.
Não é teste em aparelho nem em relógio: a chegada no relógio só se confirma com um relógio de verdade, pelo botão "Testar no relógio".
"""
from pathlib import Path
import hashlib
import re
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal'

# Descanso, alarmes, cronômetro, relógio Wear OS e aviso de cadastro: iguais ao Android 1.211. Mudar qualquer um deles exige pedido
# específico do Tiago (área protegida); se isso acontecer, atualize esta lista no mesmo pedido.
PROTEGIDOS = {
    'AlarmReceiver.java': '26453f7abf75c016b85ac3db1fe48b41e1cb045b8a45cf6064cb45e885838e9c',
    'AlarmScheduler.java': 'b79fef31f46c3ec5854d25dae35a7b1568d26defc78345da1521991878bf7cae',
    'AlarmStore.java': 'fe466b466abc27e0ead4f9c8a22f2420b2062b11690a2d1ffcea294a5ab7ed44',
    'AlarmStatus.java': 'deaa0e96101663756e892ed7f21d4290f573c3c05de263eb0d235e9f6d9f2adc',
    'AudioSettings.java': '49d53fd687e5ee1977734acbe1de6a6c277e5ae8defce1965e88314cc5a2a1e4',
    'BootReceiver.java': '5b5354613b933bfba9370cb51b3bb3b0145f6f6f5763fc1255547cd47467740a',
    'WorkoutRestAlarmService.java': '3fbbc9eac57a920b2e28b7880247660fe16ed6274ce42060ab705161977d5cb8',
    'LessonTimerOverlayService.java': '90b8c549f0aa737fc4296f1ca38566a1ef453abb083471c4444f1bcfd04c7aa8',
    'LessonTimerOverlayModel.java': '4b972ebbb9510ad0844fed21eddfc0fad60d7c2021e8c2250483a69f1f46740d',
    'WatchBridge.java': '2dfd56fc98f270695ae4c25ee960a3c766640a826d686c976ffb789176a633b8',
    'AvisosCadastro.java': '29d0a71f8e6a27b298398e180fb494253e14e14cb6a72bc87efdcecc435b5368',
}


def static_checks():
    gradle = (PROJECT / 'app/build.gradle').read_text()
    versao = re.search(r"versionName '1\.(\d+)'", gradle)
    assert versao and int(versao.group(1)) >= 212, 'O aviso no relógio precisa do Android 1.212 ou mais novo.'

    manifest = (PROJECT / 'app/src/main/AndroidManifest.xml').read_text()
    receptor = re.search(r'<receiver\s+android:name="\.AvisoRelogioReceiver"\s+android:exported="(\w+)"\s*/>', manifest)
    assert receptor and receptor.group(1) == 'false', 'O receptor do aviso no relógio precisa existir e não ser exportado.'
    for permissao in ['POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'VIBRATE']:
        assert 'android.permission.' + permissao in manifest, 'Manifesto sem ' + permissao

    main = (SOURCE / 'MainActivity.java').read_text()
    for token in ['@JavascriptInterface public int getWatchNoticeVersion() { return AvisosRelogio.VERSAO; }',
                  '@JavascriptInterface public String getWatchNoticeStatus() { return AvisosRelogio.status(activity); }',
                  '@JavascriptInterface public boolean setWatchNoticeEnabled(boolean enabled) { return AvisosRelogio.ligar(activity, enabled); }',
                  '@JavascriptInterface public boolean scheduleWatchNotice(String key, long at, String json) { return AvisosRelogio.agendar(activity, key, at, json); }',
                  '@JavascriptInterface public void cancelWatchNotice(String key) { AvisosRelogio.cancelar(activity, key); }',
                  '@JavascriptInterface public boolean testWatchNotice() { return AvisosRelogio.testar(activity); }',
                  '@JavascriptInterface public void openWatchNoticeSettings() { activity.runOnUiThread(() -> AvisosRelogio.abrirConfiguracoes(activity)); }']:
        assert token in main, 'MainActivity sem: ' + token

    novos = (SOURCE / 'AvisosRelogio.java').read_text() + (SOURCE / 'AvisoRelogioReceiver.java').read_text()
    for classe in ['AlarmScheduler', 'AlarmReceiver', 'AlarmStore', 'WorkoutRestAlarmService', 'LessonTimerOverlay', 'AudioSettings', 'WatchBridge']:
        assert classe not in novos, 'O aviso no relógio não pode depender de ' + classe + ' (descanso e alarmes ficam como estão).'
    for nome, esperado in PROTEGIDOS.items():
        atual = hashlib.sha256((SOURCE / nome).read_bytes()).hexdigest()
        assert atual == esperado, nome + ' mudou: descanso, alarmes e cronômetro são área protegida.'

    icon = (PROJECT / 'app/src/main/res/drawable/ic_stat_relogio.xml').read_text()
    colors = set(re.findall(r'android:(?:fill|stroke)Color="([^"]+)"', icon))
    assert colors == {'@android:color/transparent', '#FFFFFFFF'}, 'Ícone da barra de status precisa ser branco sobre transparente.'
    assert 'android:viewportWidth="24"' in icon and 'android:width="24dp"' in icon


STUBS = {
    'android/Manifest.java': 'package android;public final class Manifest{public static final class permission{public static final String POST_NOTIFICATIONS="android.permission.POST_NOTIFICATIONS";}}',
    'android/os/Build.java': 'package android.os;public class Build{public static class VERSION{public static int SDK_INT=35;}}',
    'android/net/Uri.java': '''package android.net;public final class Uri{private final String s;private Uri(String s){this.s=s;}public static Uri parse(String s){return new Uri(s);}
public String toString(){return s;}public boolean equals(Object o){return o instanceof Uri&&((Uri)o).s.equals(s);}public int hashCode(){return s.hashCode();}}''',
    'android/media/AudioAttributes.java': '''package android.media;public class AudioAttributes{public static final int USAGE_NOTIFICATION=5,CONTENT_TYPE_SONIFICATION=4;public int usage,content;
public static class Builder{private final AudioAttributes a=new AudioAttributes();public Builder setUsage(int u){a.usage=u;return this;}public Builder setContentType(int c){a.content=c;return this;}public AudioAttributes build(){return a;}}}''',
    'android/content/pm/PackageManager.java': '''package android.content.pm;public class PackageManager{public static final int PERMISSION_GRANTED=0,PERMISSION_DENIED=-1;public String versionName="1.212";
public PackageInfo getPackageInfo(String name,int flags)throws NameNotFoundException{if(versionName==null)throw new NameNotFoundException();PackageInfo i=new PackageInfo();i.versionName=versionName;return i;}
public static class NameNotFoundException extends Exception{}}''',
    'android/content/pm/PackageInfo.java': 'package android.content.pm;public class PackageInfo{public String versionName;}',
    'android/provider/Settings.java': '''package android.provider;public final class Settings{public static final String ACTION_CHANNEL_NOTIFICATION_SETTINGS="android.settings.CHANNEL_NOTIFICATION_SETTINGS",
ACTION_APP_NOTIFICATION_SETTINGS="android.settings.APP_NOTIFICATION_SETTINGS",EXTRA_APP_PACKAGE="android.provider.extra.APP_PACKAGE",EXTRA_CHANNEL_ID="android.provider.extra.CHANNEL_ID";
public static final class System{public static final android.net.Uri DEFAULT_NOTIFICATION_URI=android.net.Uri.parse("content://settings/system/notification_sound");}}''',
    'android/content/SharedPreferences.java': '''package android.content;
public interface SharedPreferences{boolean getBoolean(String k,boolean d);long getLong(String k,long d);String getString(String k,String d);boolean contains(String k);Editor edit();
interface Editor{Editor putBoolean(String k,boolean v);Editor putLong(String k,long v);Editor putString(String k,String v);Editor remove(String k);boolean commit();void apply();}}''',
    'android/content/MemoryPrefs.java': '''package android.content;import java.util.*;
public final class MemoryPrefs implements SharedPreferences{public final Map<String,Object> data=new LinkedHashMap<>();public boolean refuse;
public boolean getBoolean(String k,boolean d){Object v=data.get(k);return v instanceof Boolean?(Boolean)v:d;}public long getLong(String k,long d){Object v=data.get(k);return v instanceof Long?(Long)v:d;}
public String getString(String k,String d){Object v=data.get(k);return v instanceof String?(String)v:d;}public boolean contains(String k){return data.containsKey(k);}
public Editor edit(){final Map<String,Object> put=new LinkedHashMap<>();final Set<String> del=new HashSet<>();return new Editor(){
public Editor putBoolean(String k,boolean v){put.put(k,v);return this;}public Editor putLong(String k,long v){put.put(k,v);return this;}public Editor putString(String k,String v){put.put(k,v);return this;}
public Editor remove(String k){del.add(k);return this;}public boolean commit(){if(refuse)return false;for(String k:del)data.remove(k);data.putAll(put);return true;}public void apply(){commit();}};}}''',
    'android/content/Context.java': '''package android.content;import java.util.*;
public class Context{public static final String NOTIFICATION_SERVICE="notification",ALARM_SERVICE="alarm";public static final int MODE_PRIVATE=0;
public android.app.NotificationManager manager=new android.app.NotificationManager();public android.app.AlarmManager alarms=new android.app.AlarmManager();public int permission=0;
public final Map<String,MemoryPrefs> prefs=new HashMap<>();
public Object getSystemService(String name){return NOTIFICATION_SERVICE.equals(name)?manager:ALARM_SERVICE.equals(name)?alarms:null;}
public SharedPreferences getSharedPreferences(String name,int mode){return prefs.computeIfAbsent(name,n->new MemoryPrefs());}
public int checkSelfPermission(String p){return permission;}public String getPackageName(){return "com.tiagolima.agendapersonal";}
public android.content.pm.PackageManager packages=new android.content.pm.PackageManager();public android.content.pm.PackageManager getPackageManager(){return packages;}}''',
    'android/content/Intent.java': '''package android.content;import java.util.*;
public class Intent{public static final int FLAG_ACTIVITY_NEW_TASK=0x10000000,FLAG_ACTIVITY_CLEAR_TOP=0x04000000,FLAG_ACTIVITY_SINGLE_TOP=0x20000000;
public String action;public final Class<?> target;public android.net.Uri data;public int flags;public final Map<String,Object> extras=new LinkedHashMap<>();
public Intent(String action){this.action=action;target=null;}public Intent(Context c,Class<?> t){action=null;target=t;}
public Intent setAction(String a){action=a;return this;}public String getAction(){return action;}public Intent setData(android.net.Uri d){data=d;return this;}
public Intent addFlags(int f){flags|=f;return this;}public Intent putExtra(String k,String v){extras.put(k,v);return this;}public Intent putExtra(String k,long v){extras.put(k,v);return this;}
public String getStringExtra(String k){Object v=extras.get(k);return v instanceof String?(String)v:null;}public long getLongExtra(String k,long d){Object v=extras.get(k);return v instanceof Long?(Long)v:d;}
public String identity(){return action+"|"+data+"|"+(target==null?"":target.getName());}}''',
    'android/content/BroadcastReceiver.java': 'package android.content;public abstract class BroadcastReceiver{public abstract void onReceive(Context context,Intent intent);}',
    'android/app/Activity.java': '''package android.app;import android.content.Intent;import java.util.*;
public class Activity extends android.content.Context{public final List<Intent> started=new ArrayList<>();public Set<String> missing=new HashSet<>();
public void startActivity(Intent i){if(missing.contains(i.action))throw new RuntimeException("ActivityNotFoundException");started.add(i);}}''',
    'android/app/PendingIntent.java': '''package android.app;import java.util.*;
public class PendingIntent{public static final int FLAG_UPDATE_CURRENT=0x08000000,FLAG_IMMUTABLE=0x04000000,FLAG_NO_CREATE=0x20000000;
public static final Map<String,PendingIntent> registry=new HashMap<>();public final String kind,key;public final int requestCode;public int flags;public android.content.Intent intent;public boolean cancelled;
private PendingIntent(String kind,String key,int r,android.content.Intent i,int f){this.kind=kind;this.key=key;requestCode=r;intent=i;flags=f;}
private static PendingIntent get(String kind,int r,android.content.Intent i,int f){String key=kind+"|"+r+"|"+i.identity();PendingIntent old=registry.get(key);
 if((f&FLAG_NO_CREATE)!=0)return old;if(old!=null){if((f&FLAG_UPDATE_CURRENT)!=0)old.intent=i;old.flags=f;return old;}PendingIntent p=new PendingIntent(kind,key,r,i,f);registry.put(key,p);return p;}
public static PendingIntent getBroadcast(android.content.Context c,int r,android.content.Intent i,int f){return get("broadcast",r,i,f);}
public static PendingIntent getActivity(android.content.Context c,int r,android.content.Intent i,int f){return get("activity",r,i,f);}
public void cancel(){cancelled=true;registry.remove(key);}}''',
    'android/app/AlarmManager.java': '''package android.app;import java.util.*;
public class AlarmManager{public static final int RTC_WAKEUP=0;public boolean exact=true,refuseExact,refuseAll;public final Map<PendingIntent,long[]> alarms=new LinkedHashMap<>();
public boolean canScheduleExactAlarms(){return exact;}
public void setExactAndAllowWhileIdle(int type,long at,PendingIntent p){if(refuseExact||refuseAll)throw new SecurityException("exact");alarms.put(p,new long[]{type,at,1});}
public void setAndAllowWhileIdle(int type,long at,PendingIntent p){if(refuseAll)throw new SecurityException("all");alarms.put(p,new long[]{type,at,0});}
public void cancel(PendingIntent p){alarms.remove(p);}}''',
    'android/app/Notification.java': '''package android.app;
public class Notification{public static final int VISIBILITY_PUBLIC=1,VISIBILITY_PRIVATE=0,VISIBILITY_SECRET=-1;public static final String CATEGORY_REMINDER="reminder",CATEGORY_MESSAGE="msg";
public String channel,title,text,category,ticker,bigText;public int icon,color,visibility=VISIBILITY_PRIVATE;public long when,timeout;public boolean autoCancel,showWhen;public PendingIntent contentIntent;public Notification publicVersion;
public static class Builder{private final Notification n=new Notification();public Builder(android.content.Context c,String channel){n.channel=channel;}
public Builder setSmallIcon(int i){n.icon=i;return this;}public Builder setColor(int c){n.color=c;return this;}public Builder setContentTitle(CharSequence t){n.title=String.valueOf(t);return this;}
public Builder setContentText(CharSequence t){n.text=String.valueOf(t);return this;}public Builder setCategory(String c){n.category=c;return this;}
public Builder setContentIntent(PendingIntent p){n.contentIntent=p;return this;}public Builder setAutoCancel(boolean b){n.autoCancel=b;return this;}
public Builder setShowWhen(boolean b){n.showWhen=b;return this;}public Builder setWhen(long w){n.when=w;return this;}public Builder setTimeoutAfter(long t){n.timeout=t;return this;}
public Builder setVisibility(int v){n.visibility=v;return this;}public Builder setPublicVersion(Notification p){n.publicVersion=p;return this;}
public Builder setTicker(CharSequence t){n.ticker=String.valueOf(t);return this;}public Builder setStyle(Style st){if(st instanceof BigTextStyle)n.bigText=((BigTextStyle)st).text;return this;}public Notification build(){return n;}}
public abstract static class Style{}public static class BigTextStyle extends Style{String text;public BigTextStyle bigText(CharSequence t){text=String.valueOf(t);return this;}}}''',
    'android/app/NotificationChannel.java': '''package android.app;
public class NotificationChannel{public final String id;public String name,description;public int importance,lockscreen=-1000;public boolean badge=true,vibration,soundSet;public android.net.Uri sound;public android.media.AudioAttributes audio;public long[] pattern;
public NotificationChannel(String id,CharSequence name,int importance){this.id=id;this.name=String.valueOf(name);this.importance=importance;}
public void setDescription(String d){description=d;}public void setLockscreenVisibility(int v){lockscreen=v;}public void setShowBadge(boolean b){badge=b;}public void enableVibration(boolean b){vibration=b;}
public void setVibrationPattern(long[] p){pattern=p;}public void setSound(android.net.Uri u,android.media.AudioAttributes a){sound=u;audio=a;soundSet=true;}
public int getImportance(){return importance;}public int getLockscreenVisibility(){return lockscreen;}}''',
    'android/app/NotificationManager.java': '''package android.app;import java.util.*;
public class NotificationManager{public static final int IMPORTANCE_NONE=0,IMPORTANCE_MIN=1,IMPORTANCE_LOW=2,IMPORTANCE_DEFAULT=3,IMPORTANCE_HIGH=4;
public final Map<String,NotificationChannel> channels=new HashMap<>();public final Map<String,Notification> posted=new LinkedHashMap<>();public final List<String> log=new ArrayList<>();public boolean enabled=true,refuse;
public void createNotificationChannel(NotificationChannel c){NotificationChannel old=channels.get(c.id);if(old==null)channels.put(c.id,c);else{old.name=c.name;old.description=c.description;}}
public NotificationChannel getNotificationChannel(String id){return channels.get(id);}public boolean areNotificationsEnabled(){return enabled;}
public void deleteNotificationChannel(String id){log.add("delete:"+id);channels.remove(id);}
public void cancel(String tag,int id){log.add("cancel:"+tag+"#"+id);posted.remove(tag+"#"+id);}
public void notify(String tag,int id,Notification n){if(refuse)throw new SecurityException("refused");log.add("notify:"+tag+"#"+id);posted.put(tag+"#"+id,n);}}''',
    'com/tiagolima/agendapersonal/R.java': 'package com.tiagolima.agendapersonal;public final class R{public static final class drawable{public static final int ic_stat_relogio=0x7f080002;}}',
    'com/tiagolima/agendapersonal/MainActivity.java': 'package com.tiagolima.agendapersonal;public class MainActivity extends android.app.Activity{}',
}

HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.*;import android.content.*;import org.json.JSONObject;import java.util.*;
public final class AvisosRelogioHarness{
static int checks;static void check(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m);}
static JSONObject status(Context c){return new JSONObject(AvisosRelogio.status(c));}
static MemoryPrefs prefs(Context c){return c.prefs.get("agenda_avisos_relogio_v1");}
static long[] alarm(Context c,String chave){for(Map.Entry<PendingIntent,long[]> e:c.alarms.alarms.entrySet())if(("agenda-personal://relogio/"+chave).equals(String.valueOf(e.getKey().intent.data)))return e.getValue();return null;}
static PendingIntent pending(Context c,String chave){for(PendingIntent p:c.alarms.alarms.keySet())if(("agenda-personal://relogio/"+chave).equals(String.valueOf(p.intent.data)))return p;return null;}
public static void main(String[] a){
 // 1. Textos pedidos pelo conteúdo.
 String[] t=AvisosRelogio.lerTextos("{\"titulo\":\"Fim do descanso\",\"texto\":\"Ana · Supino reto\"}");
 check(t!=null&&t[0].equals("Fim do descanso")&&t[1].equals("Ana · Supino reto"),"textos lidos");
 String[] padrao=AvisosRelogio.lerTextos("{}");check(padrao[0].equals("Fim do descanso")&&padrao[1].equals("Volte para o treino."),"textos padrão");
 check(AvisosRelogio.lerTextos(null)==null&&AvisosRelogio.lerTextos("não é json")==null,"pedido inválido");
 StringBuilder enorme=new StringBuilder("{\"texto\":\"");for(int i=0;i<1100;i++)enorme.append('a');enorme.append("\"}");check(AvisosRelogio.lerTextos(enorme.toString())==null,"pedido grande demais");
 check(AvisosRelogio.lerTextos("{\"titulo\":7,\"texto\":true}")[0].equals("Fim do descanso"),"campo que não é texto é ignorado");
 String[] sujo=AvisosRelogio.lerTextos("{\"titulo\":\"\\nFim\\u0007\",\"texto\":\"Bia\\u0000 · Remada\"}");
 check(!sujo[0].matches("(?s).*[\\u0000-\\u001f].*")&&!sujo[1].matches("(?s).*[\\u0000-\\u001f].*"),"sem caracteres de controle");
 StringBuilder longo=new StringBuilder("{\"texto\":\"");for(int i=0;i<150;i++)longo.append("😀");longo.append("\"}");
 String cortado=AvisosRelogio.lerTextos(longo.toString())[1];check(cortado.codePointCount(0,cortado.length())==120&&!Character.isHighSurrogate(cortado.charAt(cortado.length()-1)),"texto longo cortado sem quebrar emoji");

 // 2. Começa desligado: nada é marcado.
 Context c=new Context();long agora=System.currentTimeMillis();
 JSONObject e=status(c);check(e.optInt("versao")==1&&!e.optBoolean("ativo")&&e.optString("canal").equals("ausente")&&e.optString("app").equals("1.212"),"começa desligado, sem canal");
 check(!AvisosRelogio.agendar(c,"professor",agora+60000,"{}")&&c.alarms.alarms.isEmpty(),"desligado: não marca");
 check(c.manager.channels.isEmpty(),"desligado: o canal nem é criado");
 // Quem vem do 1.212 tem o canal antigo, sem som: ligar apaga e cria o novo.
 c.manager.channels.put("relogio",new NotificationChannel("relogio","Avisos no relógio",NotificationManager.IMPORTANCE_HIGH));

 // 3. Ligar cria o canal: sem som, com vibração, tela bloqueada sem conteúdo.
 check(AvisosRelogio.ligar(c,true)&&status(c).optBoolean("ativo"),"ligado");
 NotificationChannel canal=c.manager.getNotificationChannel("relogio_som");
 check(c.manager.getNotificationChannel("relogio")==null&&c.manager.log.contains("delete:relogio"),"canal antigo sem som apagado");
 check(canal!=null&&canal.name.equals("Avisos no relógio")&&canal.importance==NotificationManager.IMPORTANCE_HIGH&&!canal.description.isEmpty(),"canal com alerta");
 check(canal.soundSet&&"content://settings/system/notification_sound".equals(String.valueOf(canal.sound))&&canal.audio!=null&&canal.audio.usage==android.media.AudioAttributes.USAGE_NOTIFICATION&&canal.audio.content==android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION,"canal com som de notificação (apps de relógio não repassam aviso silencioso)");
 check(canal.vibration&&Arrays.equals(canal.pattern,new long[]{0,400,200,400}),"canal vibra");
 check(canal.lockscreen==Notification.VISIBILITY_PRIVATE&&!canal.badge,"tela bloqueada privada, sem bolinha no ícone");

 // 4. Marcar, substituir e separar professor e aluno.
 long fim=agora+60000;
 check(AvisosRelogio.agendar(c,"professor",fim,"{\"titulo\":\"Fim do descanso\",\"texto\":\"Ana · Supino reto\"}"),"marcado");
 long[] al=alarm(c,"professor");check(al!=null&&al[0]==AlarmManager.RTC_WAKEUP&&al[1]==fim&&al[2]==1,"alarme exato no horário do fim");
 PendingIntent p=pending(c,"professor");
 check(p.kind.equals("broadcast")&&p.flags==(PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE)&&p.requestCode==4211,"pendente imutável e próprio");
 check(p.intent.target==AvisoRelogioReceiver.class&&"com.tiagolima.agendapersonal.AVISO_RELOGIO".equals(p.intent.action),"vai para o receptor do aviso");
 check("professor".equals(p.intent.getStringExtra("agenda_relogio_chave"))&&p.intent.getLongExtra("agenda_relogio_quando",0)==fim,"leva a chave e o horário");
 check(prefs(c).getLong("professor.quando",0)==fim&&prefs(c).getString("professor.texto","").equals("Ana · Supino reto"),"guardado para o disparo");
 long novo=agora+90000;check(AvisosRelogio.agendar(c,"professor",novo,"{\"texto\":\"Ana · Remada\"}"),"remarcado");
 check(c.alarms.alarms.size()==1&&alarm(c,"professor")[1]==novo&&prefs(c).getLong("professor.quando",0)==novo,"o novo substitui o anterior");
 check(AvisosRelogio.agendar(c,"aluno",agora+45000,"{\"texto\":\"Leg press\"}")&&c.alarms.alarms.size()==2&&pending(c,"aluno").requestCode==4212,"aluno tem o próprio aviso");
 check(!AvisosRelogio.agendar(c,"teste",agora+60000,"{}")&&!AvisosRelogio.agendar(c,"outro",agora+60000,"{}")&&!AvisosRelogio.agendar(c,null,agora+60000,"{}"),"só professor e aluno");
 check(!AvisosRelogio.agendar(c,"aluno",agora-1000,"{}")&&!AvisosRelogio.agendar(c,"aluno",agora+3*60*60*1000L,"{}")&&!AvisosRelogio.agendar(c,"aluno",agora+5000,"x"),"horário ou pedido inválido");
 check(alarm(c,"aluno")[1]==agora+45000,"pedido recusado não mexe no aviso marcado");

 // 5. Disparo: só o aviso que continua marcado.
 check(!AvisosRelogio.disparar(c,"professor",fim)&&c.manager.posted.isEmpty(),"o horário antigo (substituído) não mostra nada");
 check(!AvisosRelogio.disparar(c,"professor",0)&&!AvisosRelogio.disparar(c,"intruso",novo),"disparo inválido");
 check(AvisosRelogio.disparar(c,"professor",novo),"aviso mostrado no fim do descanso");
 Notification n=c.manager.posted.get("professor#4201");
 check(n!=null&&n.channel.equals("relogio_som")&&n.icon==R.drawable.ic_stat_relogio&&n.color==0xFF568900,"canal, ícone e cor");
 check(n.title.equals("Fim do descanso")&&n.text.equals("Ana · Remada")&&"msg".equals(n.category),"textos e categoria de mensagem");
 check("Fim do descanso: Ana · Remada".equals(n.ticker)&&"Ana · Remada".equals(n.bigText),"ticker e texto expandido para o app do relógio");
 check(n.publicVersion.ticker==null&&n.publicVersion.bigText==null,"versão da tela bloqueada sem ticker");
 check(n.autoCancel&&n.showWhen&&n.when>0&&n.timeout==120000,"some sozinho depois de 2 min");
 check(n.visibility==Notification.VISIBILITY_PRIVATE&&n.publicVersion!=null&&n.publicVersion.title.equals("Fim do descanso")&&!n.publicVersion.text.contains("Ana"),"tela bloqueada sem o nome do aluno");
 check(n.contentIntent.kind.equals("activity")&&n.contentIntent.intent.target==MainActivity.class&&n.contentIntent.intent.flags==(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP),"toque abre o app sem recriar");
 check(c.manager.log.indexOf("cancel:professor#4201")<c.manager.log.indexOf("notify:professor#4201"),"tira o anterior antes: o relógio vibra de novo");
 check(!prefs(c).contains("professor.quando")&&!AvisosRelogio.disparar(c,"professor",novo),"mostra uma vez só");

 // 6. O receptor do alarme.
 PendingIntent doAluno=pending(c,"aluno");new AvisoRelogioReceiver().onReceive(c,doAluno.intent);
 check(c.manager.posted.get("aluno#4201")!=null&&c.manager.posted.get("aluno#4201").text.equals("Leg press"),"receptor mostra o aviso do aluno");
 new AvisoRelogioReceiver().onReceive(c,new Intent("outra.acao"));new AvisoRelogioReceiver().onReceive(c,null);check(c.manager.posted.size()==2,"receptor ignora o que não é dele");

 // 7. Desmarcar (descanso parado antes do fim) e desligar.
 long f2=agora+70000;AvisosRelogio.agendar(c,"aluno",f2,"{}");PendingIntent pa=pending(c,"aluno");
 AvisosRelogio.cancelar(c,"aluno");check(alarm(c,"aluno")==null&&pa.cancelled&&!prefs(c).contains("aluno.quando"),"desmarcado");
 check(!AvisosRelogio.disparar(c,"aluno",f2),"desmarcado não mostra, mesmo se o alarme já estava a caminho");
 AvisosRelogio.cancelar(c,"aluno");AvisosRelogio.cancelar(c,"teste");AvisosRelogio.cancelar(c,null);check(true,"desmarcar de novo ou sem chave: sem travar");
 long f3=agora+80000;AvisosRelogio.agendar(c,"professor",f3,"{}");
 check(AvisosRelogio.ligar(c,false)&&!status(c).optBoolean("ativo")&&c.alarms.alarms.isEmpty(),"desligar desmarca tudo");
 check(!AvisosRelogio.disparar(c,"professor",f3),"desligado não mostra");

 // 8. Testar no relógio: daqui a 10 s, pelo mesmo caminho, mesmo desligado.
 long antes=System.currentTimeMillis();check(AvisosRelogio.testar(c),"teste marcado");
 long[] at=alarm(c,"teste");check(at!=null&&at[1]>=antes+10000&&at[1]<=System.currentTimeMillis()+10000&&pending(c,"teste").requestCode==4213,"teste em 10 s");
 check(c.manager.getNotificationChannel("relogio_som")!=null,"teste garante o canal");
 check(AvisosRelogio.disparar(c,"teste",at[1])&&c.manager.posted.get("teste#4201").title.equals("Teste do relógio"),"aviso de teste mostrado");

 // 9. Sem "Alarmes e lembretes": aviso com tolerância; Android 11: exato sem pedir.
 Context s=new Context();AvisosRelogio.ligar(s,true);s.alarms.exact=false;
 check(AvisosRelogio.agendar(s,"aluno",agora+30000,"{}")&&alarm(s,"aluno")[2]==0&&!status(s).optBoolean("exato"),"sem permissão de exato: aviso com tolerância");
 android.os.Build.VERSION.SDK_INT=30;check(AvisosRelogio.agendar(s,"aluno",agora+31000,"{}")&&alarm(s,"aluno")[2]==1&&status(s).optBoolean("exato"),"Android 11: exato");android.os.Build.VERSION.SDK_INT=35;
 s.alarms.exact=true;s.alarms.refuseExact=true;check(AvisosRelogio.agendar(s,"aluno",agora+32000,"{}")&&alarm(s,"aluno")[2]==0,"exato recusado: tolerância");
 s.alarms.refuseAll=true;check(!AvisosRelogio.agendar(s,"professor",agora+33000,"{}")&&!prefs(s).contains("professor.quando"),"Android recusou tudo: não fica marcado pela metade");
 Context sem=new Context();AvisosRelogio.ligar(sem,true);prefs(sem).refuse=true;check(!AvisosRelogio.agendar(sem,"aluno",agora+30000,"{}")&&sem.alarms.alarms.isEmpty(),"sem gravar: sem alarme");

 // 10. Estado para o cartão.
 Context st=new Context();check(status(st).optString("canal").equals("ausente")&&status(st).optBoolean("permissao")&&status(st).optBoolean("exato"),"estado inicial");
 AvisosRelogio.ligar(st,true);NotificationChannel sc=st.manager.getNotificationChannel("relogio_som");check(status(st).optString("canal").equals("alerta"),"canal com alerta");
 sc.importance=NotificationManager.IMPORTANCE_DEFAULT;check(status(st).optString("canal").equals("alerta"),"sem pop-up ainda avisa");
 sc.importance=NotificationManager.IMPORTANCE_LOW;check(status(st).optString("canal").equals("silencioso"),"silencioso");
 sc.importance=NotificationManager.IMPORTANCE_NONE;check(status(st).optString("canal").equals("desligado"),"desligado no Android");
 AvisosRelogio.ligar(st,true);check(sc.importance==NotificationManager.IMPORTANCE_NONE,"o app não desfaz a escolha da pessoa no canal");
 st.permission=-1;check(!status(st).optBoolean("permissao"),"Android 13+: sem permissão de notificação");
 Context up=new Context();up.prefs.computeIfAbsent("agenda_avisos_relogio_v1",k->new MemoryPrefs()).data.put("ativo",true);up.manager.channels.put("relogio",new NotificationChannel("relogio","Avisos no relógio",NotificationManager.IMPORTANCE_HIGH));
 check(status(up).optString("canal").equals("alerta")&&up.manager.getNotificationChannel("relogio_som")!=null&&up.manager.getNotificationChannel("relogio")==null,"ligado no 1.212: o 1.213 troca o canal sem religar");
 android.os.Build.VERSION.SDK_INT=32;check(status(st).optBoolean("permissao"),"Android 12: permissão não existe");android.os.Build.VERSION.SDK_INT=35;
 st.permission=0;st.manager.enabled=false;check(!status(st).optBoolean("permissao"),"notificações do app desligadas");
 st.packages.versionName=null;check(status(st).optString("app").isEmpty()&&status(st).optInt("versao")==1,"sem a versão do APK: estado continua");

 // 11. Android recusou a notificação: sem travar.
 Context r=new Context();AvisosRelogio.ligar(r,true);AvisosRelogio.agendar(r,"aluno",agora+20000,"{}");r.manager.refuse=true;
 check(!AvisosRelogio.disparar(r,"aluno",agora+20000),"recusado: sem travar");

 // 12. Configurações do canal.
 Activity t1=new Activity();AvisosRelogio.abrirConfiguracoes(t1);
 check(t1.started.size()==1&&t1.started.get(0).action.equals("android.settings.CHANNEL_NOTIFICATION_SETTINGS")&&"relogio_som".equals(t1.started.get(0).extras.get("android.provider.extra.CHANNEL_ID")),"abre o canal do relógio");
 Activity t2=new Activity();t2.missing.add("android.settings.CHANNEL_NOTIFICATION_SETTINGS");AvisosRelogio.abrirConfiguracoes(t2);
 check(t2.started.size()==1&&t2.started.get(0).action.equals("android.settings.APP_NOTIFICATION_SETTINGS"),"sem tela do canal: notificações do app");
 Activity t3=new Activity();t3.missing.add("android.settings.CHANNEL_NOTIFICATION_SETTINGS");t3.missing.add("android.settings.APP_NOTIFICATION_SETTINGS");AvisosRelogio.abrirConfiguracoes(t3);
 check(t3.started.isEmpty(),"sem nenhuma tela: sem travar");
 System.out.println("PASS: aviso no relógio, "+checks+" verificações.");
}}
'''


def main():
    static_checks()
    java = shutil.which('java')
    javac = shutil.which('javac')
    if not java:
        raise SystemExit('Java 17 é necessário para estes testes.')
    compiler = [javac] if javac else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-relogio-tests-') as temporary:
        work = Path(temporary)
        stubs = dict(STUBS)
        for name in ['JSONObject', 'JSONArray', 'JSONTokener']:
            stubs['org/json/' + name + '.java'] = (PROJECT / 'tests/native-json/org/json' / (name + '.java')).read_text()
        stubs['com/tiagolima/agendapersonal/AvisosRelogioHarness.java'] = HARNESS
        sources = []
        for name, content in stubs.items():
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding='utf-8')
            sources.append(str(target))
        sources += [str(SOURCE / 'AvisosRelogio.java'), str(SOURCE / 'AvisoRelogioReceiver.java')]
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + sources, check=True)
        subprocess.run([java, '-ea', '-cp', str(work / 'classes'), 'com.tiagolima.agendapersonal.AvisosRelogioHarness'], check=True)
    print('PASS: ligações do aviso no relógio no projeto (ponte, receptor, permissões, ícone, descanso intocado) conferidas.')


if __name__ == '__main__':
    main()
