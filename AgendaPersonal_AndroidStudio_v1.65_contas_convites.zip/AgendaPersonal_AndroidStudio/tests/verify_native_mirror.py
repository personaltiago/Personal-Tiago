"""Compila e executa NativeMirror.java (Java puro) para conferir gravação atômica, geração anterior, recusa de encolher,
detecção de arquivo danificado e o mesmo hash FNV-1a do JavaScript. Não roda em aparelho."""
import subprocess,sys,tempfile,shutil,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/com/tiagolima/agendapersonal/NativeMirror.java'
TEST='''package com.tiagolima.agendapersonal;
import java.io.File;import java.nio.file.*;
public class NativeMirrorHarness{static int n=0;static void c(boolean b,String m){n++;if(!b)throw new AssertionError(m);}
public static void main(String[] a)throws Exception{File d=Files.createTempDirectory("nm").toFile();String k="agendaPersonalTL_v1";
c(!NativeMirror.save(d,"outra","{}"),"chave fora da lista");
c(NativeMirror.info(d,k).equals("{\\"exists\\":false}"),"sem cópia no início");
String v="{\\"a\\":\\"ç ã 😀\\",\\"n\\":[1,2,3]}";c(NativeMirror.save(d,k,v),"salvar");
String i=NativeMirror.info(d,k);c(i.contains("\\"exists\\":true")&&i.contains("\\"length\\":"+v.length()),"info");
c(i.contains("\\"hash\\":\\""+NativeMirror.hash(v)+"\\""),"hash");
c(NativeMirror.read(d,k).equals(v),"leitura igual");
String v2="{\\"b\\":1}";c(NativeMirror.save(d,k,v2),"segunda gravação");
c(new String(Files.readAllBytes(new File(d,"mirror/"+k+".prev").toPath()),"UTF-8").equals(v),"geração anterior");
c(!NativeMirror.save(d,k,"não json"),"rejeita inválido");c(NativeMirror.read(d,k).equals(v2),"inválido não altera");
StringBuilder big=new StringBuilder("{\\"x\\":\\"");for(int q=0;q<30000;q++)big.append('a');big.append("\\"}");
c(NativeMirror.save(d,k,big.toString()),"salvar grande");
c(!NativeMirror.save(d,k,"{\\"x\\":1}"),"recusa encolher");c(NativeMirror.read(d,k).length()==big.length(),"cópia grande preservada");
c(NativeMirror.save(d,k,"{\\"x\\":1}",true),"force aceita");c(NativeMirror.read(d,k).equals("{\\"x\\":1}"),"force gravou");
Files.write(new File(d,"mirror/"+k+".json").toPath(),"{}".getBytes());c(NativeMirror.info(d,k).contains("damaged"),"detecta dano");c(NativeMirror.read(d,k).isEmpty(),"não lê arquivo danificado");
c(NativeMirror.hash("abc").equals("1a47e90b"),"hash FNV-1a de abc");c(NativeMirror.hash("ação 😀").equals("d7fb74fc"),"hash igual ao JavaScript com acento e emoji");
System.out.println("PASS NativeMirror: "+n+" verificações.");}}
'''
def main():
    work=Path(tempfile.mkdtemp(prefix='native-mirror-'))
    try:
        pkg=work/'src/com/tiagolima/agendapersonal';pkg.mkdir(parents=True)
        (pkg/'NativeMirrorHarness.java').write_text(TEST,encoding='utf-8')
        subprocess.run(['javac','-encoding','UTF-8','-d',str(work/'classes'),str(SRC),str(pkg/'NativeMirrorHarness.java')],check=True)
        subprocess.run(['java','-Dfile.encoding=UTF-8','-cp',str(work/'classes'),'com.tiagolima.agendapersonal.NativeMirrorHarness'],check=True)
        # mesmo hash que o JavaScript para texto com acento
        js=subprocess.run(['node','-e','let h=0x811c9dc5;for(const c of "ação 😀"){for(let i=0;i<c.length;i++){h^=c.charCodeAt(i);h=Math.imul(h,0x01000193)>>>0}}console.log(h.toString(16))'],capture_output=True,text=True,check=True).stdout.strip()
        print('hash JS de "ação 😀":',js)
    finally:
        shutil.rmtree(work,ignore_errors=True)
if __name__=='__main__':main()
