const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const runtime = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/') : require;
const { chromium } = runtime('playwright');
const assets = path.resolve(__dirname, '../app/src/main/assets');
const pdfFile = path.resolve(__dirname, 'fixtures/revisao_importacao_treino.pdf');
const fixture = {
  students: [{ id: 'j', name: 'Jéssica', phone: '69911111111', studentType: 'presencial' }, { id: 'other', name: 'Joana', phone: '69922222222' }],
  lessons: [], history: [], payments: [], occurrenceStatus: {}, lessonTimers: {},
  workoutPlans: [{ id: 'original', studentId: 'j', name: 'Ficha anterior', organization: 'sequence', days: [{ id: 'day-old', name: 'Treino anterior', exercises: [{ id: 'old', name: 'Agachamento', sets: '4', reps: '8', load: '40 kg', rest: '90 s' }] }] }],
  workoutExecutions: [], workoutDrafts: {}, customData: { preserved: true },
};
const server = http.createServer((req, res) => {
  const file = path.resolve(assets, '.' + new URL(req.url, 'http://localhost').pathname);
  if (!file.startsWith(assets + path.sep) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', file.endsWith('.html') ? 'text/html;charset=utf-8' : 'application/octet-stream');
  res.end(fs.readFileSync(file));
});
const errors = [];
async function makePage(browser, width = 414, height = 900) {
  const context = await browser.newContext({ viewport: { width, height }, isMobile: width < 768, hasTouch: true, timezoneId: 'America/Cuiaba' });
  await context.addInitScript(data => {
    if (!localStorage.getItem('agendaPersonalTL_v1')) localStorage.setItem('agendaPersonalTL_v1', JSON.stringify(data));
    const save = Storage.prototype.setItem;
    Storage.prototype.setItem = function(key, value) { if (window.__failSave && key === 'agendaPersonalTL_v1') throw new Error('quota'); return save.call(this, key, value); };
    window.Android = { syncLessonAlarms() { return true; }, getAlarmStatus() { return '{"ready":true}'; } };
  }, fixture);
  const page = await context.newPage(); page.setDefaultTimeout(7000);
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('http://127.0.0.1:' + server.address().port + '/professor.html');
  return page;
}
async function readPdf(page) {
  await page.evaluate(()=>showScreen('workouts'));
  await page.locator('.workout-student-choice[data-student-id="j"]').click();
  await page.evaluate(()=>workoutPdfImportContextStudentId='j');
  await page.locator('#workoutPdfImportFile').setInputFiles(pdfFile);
  await page.locator('#workoutPdfImportActions').waitFor({ timeout: 60000 });
}
async function fits(page){
 assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
 for(const selector of ['#workoutImportStudentType','#workoutPdfImportActions .btn.primary','#workoutPdfImportActions .btn.ghost']){
  const control=page.locator(selector);await control.scrollIntoViewIfNeeded();
  assert.ok(await control.evaluate(el=>{const r=el.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return r.width>0&&r.height>=40&&r.x>=0&&r.right<=innerWidth+1&&!!hit&&(hit===el||el.contains(hit))}),selector+' is reachable');
 }
}
async function documentCount(page){return page.evaluate(async()=>{const db=await workoutDocumentDb();try{return await new Promise((resolve,reject)=>{const r=db.transaction('documents').objectStore('documents').count();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}finally{db.close()}})}
async function main(){
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const page=await makePage(browser);await readPdf(page);
  const originalPlan=await page.evaluate(()=>JSON.parse(JSON.stringify(state.workoutPlans.find(p=>p.id==='original'))));
  const original=await page.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')));
  const parsed=await page.evaluate(()=>({profile:workoutPdfImport.profile,days:workoutPdfImport.days}));
  assert.equal(parsed.profile.name,'Jéssica Gella de Oliveira');assert.equal(parsed.days.flatMap(d=>d.exercises).length,16);
  assert.equal(await page.evaluate(()=>workoutPdfImport.lockedStudentId),'j');
  assert.equal(await page.locator('#workoutImportStudentType').inputValue(),'presencial');
  assert.ok(await page.locator('#workoutPdfImportActions .btn.primary').isDisabled());
  await page.locator('#workoutImportReviewed').check();assert.ok(await page.locator('#workoutPdfImportActions .btn.primary').isEnabled());
  await page.locator('#workoutImportReviewed').uncheck();assert.ok(await page.locator('#workoutPdfImportActions .btn.primary').isDisabled());
  assert.equal(await documentCount(page),0);
  for(const [width,height,fontSize] of [[320,568,16],[360,780,16],[414,900,16],[768,1024,16],[1080,800,16],[320,640,20],[360,460,16]]){
   await page.setViewportSize({width,height});await page.evaluate(font=>document.documentElement.style.fontSize=font+'px',fontSize);await fits(page);
  }
  await page.setViewportSize({width:414,height:900});await page.evaluate(()=>document.documentElement.style.fontSize='16px');
  // A fresh import outside a profile must require the user to choose the type.
  await page.evaluate(()=>{workoutPdfImport.lockedStudentId='';workoutPdfImport.targetStudentId='';workoutPdfImport.studentType='';workoutPdfImport.reviewConfirmed=false;renderWorkoutPdfImport()});
  assert.ok(await page.locator('#workoutPdfImportActions .btn.primary').isDisabled());
  await page.locator('#workoutImportStudentType').selectOption('online');assert.equal(await page.evaluate(()=>workoutPdfImport.studentType),'online');
  await page.evaluate(()=>{workoutPdfImport.lockedStudentId='j';workoutPdfImport.targetStudentId='j';workoutPdfImport.studentType='presencial';workoutPdfImport.reviewConfirmed=true;renderWorkoutPdfImport()});
  await page.evaluate(()=>window.__failSave=true);await page.locator('#workoutPdfImportActions .btn.primary').click();
  await page.waitForFunction(()=>!workoutPdfImport?.saving);
  assert.deepEqual(await page.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1'))),original);assert.equal(await documentCount(page),0);
  await page.evaluate(()=>window.__failSave=false);await page.locator('#workoutPdfImportActions .btn.primary').click();
  await page.waitForFunction(()=>state.workoutPlans.length===2);
  const stored=await page.evaluate(()=>JSON.parse(JSON.stringify(state)));assert.deepEqual(stored.workoutPlans.find(p=>p.id==='original'),originalPlan);
  const imported=stored.workoutPlans.find(p=>p.id!=='original');assert.equal(imported.studentId,'j');assert.equal(imported.days.flatMap(d=>d.exercises).length,16);assert.equal(stored.students.find(s=>s.id==='j').name,'Jéssica');assert.deepEqual(stored.customData,fixture.customData);assert.equal(await documentCount(page),1);
  await page.reload();assert.equal(await page.evaluate(()=>state.workoutPlans.length),2);assert.equal(await documentCount(page),1);assert.deepEqual(errors,[]);
  console.log('PASS: real MFit PDF with 16 exercises, locked destination, source name retained, required type/review, controls reachable at seven viewport/font combinations, quota rollback removes orphan PDF, successful retry, original plan/prescriptions/student preserved, one attached PDF and reload. Network/native simulated.');
 }finally{await browser.close();server.close()}
}
main().catch(error=>{console.error(error);server.close();process.exitCode=1});
