'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'):require,{chromium}=runtime('playwright');
let origin='',releaseResponse=null,received=0,receiveResolve;const receivedAll=new Promise(resolve=>receiveResolve=resolve);
const source=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/index.html'),'utf8');
const candidate={format:1,appId:'com.tiagolima.agendapersonal',bridgeVersion:3,dataSchema:4,sequence:105,version:'1.11.99',files:Object.fromEntries(['index.html','professor.html','avaliacoes.html','cadastro.html'].map(n=>[n,'<html><script data-agenda-ready></script>'+('á'.repeat(n==='index.html'?250000:1))+'</html>']))};
const text=JSON.stringify(candidate),total=Buffer.byteLength(text);
const server=http.createServer((req,res)=>{if(req.url==='/api/publish'&&req.method==='POST'){assert.equal(req.headers.authorization,'Bearer local-test-token');req.on('data',chunk=>received+=chunk.length);req.on('end',()=>{releaseResponse=()=>{res.setHeader('Content-Type','application/json');res.writeHead(201);res.end(JSON.stringify({published:true,manifest:{available:true,sequence:105,version:'1.11.99'}}))};receiveResolve()});return}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(source.replace("const SERVICE='https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site'","const SERVICE='"+origin+"'"))});
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(origin);await page.waitForFunction(()=>!!window.APupdates);
  await page.evaluate(()=>{window.Android={getPublishableUpdate:()=>'',applyPublishedUpdate:meta=>window.appliedMeta=JSON.parse(meta)};window.APaccounts={isTeacher:()=>true,getPublicationToken:async()=> 'local-test-token'};APupdates.openPublisher()});
  await page.locator('#apPublishFile').setInputFiles({name:'test.agenda.json',mimeType:'application/json',buffer:Buffer.from(text)});
  const cdp=await context.newCDPSession(page);await cdp.send('Network.enable');await cdp.send('Network.emulateNetworkConditions',{offline:false,latency:10,downloadThroughput:1024*1024,uploadThroughput:64*1024,connectionType:'cellular3g'});
  await page.locator('#apPublishSend').click();await page.waitForFunction(()=>{const n=document.getElementById('apPublishProgressBar');return n.value>0&&n.value<100});
  const percent=await page.locator('#apPublishProgressBar').evaluate(n=>n.value);assert.ok(percent>0&&percent<100);assert.equal(await page.locator('#apPublishProgress').getAttribute('data-state'),'uploading');
  await page.waitForFunction(()=>document.getElementById('apPublishProgressEta').textContent.includes('Estimativa'));
  await page.locator('#apPublishProgress').screenshot({path:path.resolve(__dirname,'../../../../publish_progress_review.png')});
  await page.waitForFunction(()=>document.getElementById('apPublishProgress').dataset.state==='confirming');assert.equal(await page.evaluate(()=>window.appliedMeta),undefined);assert.equal(await page.locator('#apPublishSend').isDisabled(),true);await receivedAll;assert.equal(received,total,'actual UTF-8 upload bytes arrive');
  assert.ok(releaseResponse);releaseResponse();await page.waitForFunction(()=>document.getElementById('apPublishProgress').dataset.state==='done');assert.equal(await page.locator('#apPublishStatus').getAttribute('data-kind'),'success');assert.equal(await page.evaluate(()=>appliedMeta.sequence),105);
  for(const width of [320,390,480]){await page.setViewportSize({width,height:844});const fits=await page.locator('#apPublishProgress').evaluate(n=>{const b=n.getBoundingClientRect();return b.left>=0&&b.right<=innerWidth+1&&n.scrollWidth<=n.clientWidth+1});assert.ok(fits,'progress fits '+width)}
  assert.deepEqual(errors,[]);console.log('PASS: real Chromium XHR with throttled HTTP upload, measured percentage and ETA, UTF-8 byte count, 100% waiting for actual server response, confirmed publication and responsive 320/390/480 layout. Local server/auth fixture; no live release published.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
