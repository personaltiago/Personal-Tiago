'use strict';
// Optional UI verification: install Playwright and its Chromium headless shell.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {chromium} = require('playwright');
const root = path.resolve(__dirname, '..');
const java = fs.readFileSync(path.join(root,
  'app/src/main/java/com/tiagolima/agendapersonal/NativeLaunch.java'), 'utf8');
const bootstrap = java.split('"""')[1];
assert(bootstrap?.includes('ap-native-launch-layout'));
const css = fs.readFileSync(path.join(root, 'web/startup.css'), 'utf8');
const logo = fs.readFileSync(path.join(root, 'app/src/main/res/drawable-nodpi/launch_logo.png')).toString('base64');

(async () => {
  const browser = await chromium.launch({headless: true, args: ['--no-sandbox'],
    ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ?
      {executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH} : {})});
  try {
    // Window dimensions and insets are physical px; the web viewport is the
    // inset content region. Verify its real rendered logo in window coordinates.
    const cases = [
      {w:720,h:1280,l:0,t:0,r:0,b:0,dpr:2},
      {w:720,h:1280,l:0,t:64,r:0,b:24,dpr:2},
      {w:720,h:1280,l:0,t:48,r:0,b:96,dpr:2},
      {w:720,h:1280,l:30,t:102,r:0,b:18,dpr:2},
      {w:720,h:1280,l:0,t:102,r:30,b:18,dpr:2},
      {w:1080,h:2400,l:0,t:120,r:0,b:60,dpr:3},
      {w:540,h:960,l:18,t:46,r:0,b:24,dpr:1.5}
    ];
    for (const c of cases) {
      const vw = (c.w-c.l-c.r)/c.dpr, vh = (c.h-c.t-c.b)/c.dpr;
      const context = await browser.newContext({viewport:{width:Math.round(vw),height:Math.round(vh)},deviceScaleFactor:c.dpr});
      const page = await context.newPage();
      await page.route('**/*', route => route.abort());
      const geometry = {x:100*(c.w/2-c.l)/(c.w-c.l-c.r),y:100*(c.h/2-c.t)/(c.h-c.t-c.b)};
      const makeHtml = useBootstrap => `<!doctype html><html data-ap-startup="pending"><head>
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <style>*{box-sizing:border-box}${css}</style>
        <script>window.Android={getLaunchGeometry:()=>JSON.stringify(window.launchGeometry)};
        window.launchGeometry=${JSON.stringify(geometry)};</script>
        ${useBootstrap ? bootstrap : ''}</head><body>
        <section id="apStartup" data-error="false"><img width="112" height="112"
          src="data:image/png;base64,${logo}" alt="Agenda Personal"><p>Abrindo…</p>
          <button hidden>Tentar novamente</button></section></body></html>`;
      await page.setContent(makeHtml(true));
      const bounds = () => page.locator('#apStartup img').evaluate(img => {
        const r=img.getBoundingClientRect(),s=getComputedStyle(img);
        return {x:r.x+r.width/2,y:r.y+r.height/2,w:r.width,h:r.height,radius:s.borderRadius,position:s.position};
      });
      let box=await bounds();
      assert(Math.abs(c.l+box.x*c.dpr-c.w/2)<=1,`x center ${JSON.stringify(c)}: ${JSON.stringify(box)}`);
      assert(Math.abs(c.t+box.y*c.dpr-c.h/2)<=1,`y center ${JSON.stringify(c)}: ${JSON.stringify(box)}`);
      assert.equal(box.w,112);assert.equal(box.h,112);assert.equal(box.radius,'0px');
      // A changed native viewport refreshes the existing page without reloading.
      await page.evaluate(() => {
        window.launchGeometry={x:45,y:47};window.dispatchEvent(new Event('ap-native-launch-layout'));
      });
      box=await bounds();
      assert(Math.abs(box.x-Math.round(vw)*.45)<.1);
      assert(Math.abs(box.y-Math.round(vh)*.47)<.1);
      // Error/retry UI must retain its normal flow and remain in the safe viewport.
      await page.locator('#apStartup').evaluate(n=>{n.dataset.error='true';n.querySelector('button').hidden=false});
      assert.equal((await bounds()).position,'static');
      assert(await page.locator('#apStartup button').isVisible());
      const button=await page.locator('#apStartup button').boundingBox();
      assert(button.y>=0&&button.y+button.height<=Math.round(vh));
      if(c.t===64){
        await page.setContent(makeHtml(false));box=await bounds();
        assert(Math.abs(c.t+box.y*c.dpr-c.h/2)>10,'old startup fixture must reproduce the downward jump');
      }
      console.log(`PASS web window ${c.w}x${c.h}, insets ${c.l}/${c.t}/${c.r}/${c.b}, dpr ${c.dpr}`);
      await context.close();
    }
    console.log('PASS: real Chromium startup layout, physical window center, unchanged 112px artwork, resize event and retry flow.');
  } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
