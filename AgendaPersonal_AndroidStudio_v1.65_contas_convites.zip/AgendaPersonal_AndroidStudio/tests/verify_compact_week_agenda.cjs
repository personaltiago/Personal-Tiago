'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const html=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/professor.html'),'utf8');
const start=html.indexOf("let agendaWeekAnchor='';"),finish=html.indexOf("UI_ICONS.close=",start);
assert.ok(start>=0&&finish>start);
const RealDate=Date,now=new RealDate('2026-10-20T14:00:00-04:00').getTime();
class Clock extends RealDate{constructor(...a){super(...(a.length?a:[now]))}static now(){return now}}
const days=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
const longDays=['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
const iso=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const students=[{id:'s',name:'Nome <especial>',studentType:'presencial',financeEnabled:true,dueDate:'2026-10-30',photoDataUrl:'data:image/png;base64,AAAA'}];
const state={students,lessonTimers:{},occurrenceStatus:{},customData:{keep:17},lessons:[
 {id:'mon',studentId:'s',time:'09:00',duration:60,date:'2026-10-19'},
 {id:'tue',studentId:'s',time:'10:00',duration:60,date:'2026-10-20'},
 {id:'sun',studentId:'s',time:'11:00',duration:60,date:'2026-10-25'},
 {id:'next',studentId:'s',time:'12:00',duration:60,date:'2026-10-27'}]};
let cards=[],scrolls=0,pillScrolls=0;
function card(date,open,hidden){return {dataset:{date},open,hidden,isConnected:true,querySelectorAll(){return[]},scrollIntoView(){scrolls++}}}
const wrap={dataset:{},querySelectorAll(q){return q.includes('day-card[open]')?cards.filter(c=>c.open):[]},get innerHTML(){return this.html||''},set innerHTML(value){this.html=value;cards=[...value.matchAll(/<details class="day-card[^"]*" data-date="([^"]+)"([^>]*)>/g)].map(m=>card(m[1],/\bopen\b/.test(m[2]),/\bhidden\b/.test(m[2])))}};
const elements={weekList:wrap,weekDayStrip:{innerHTML:''},agendaWeekRange:{textContent:''},agendaWeekReset:{hidden:true}};
const document={getElementById:id=>elements[id]||(elements[id]={textContent:''}),querySelectorAll(q){if(q==='#weekList>.day-card')return cards;return[]},querySelector(q){return q.includes('week-day-pill.is-selected')?{scrollIntoView(){pillScrolls++}}:null}};
const context={Date:Clock,document,console,days,longDays,state,iso,dateOnlyNow:()=>new Clock(),parseDate:s=>new Clock(s+'T00:00:00'),validWorkoutDate:s=>/^\d{4}-\d\d-\d\d$/.test(s),
 occurrences(d){return state.lessons.filter(l=>l.date===iso(d)).map(lesson=>({lesson,date:lesson.date,status:state.occurrenceStatus[lesson.id+'|'+lesson.date]||'agendada'}))},
 lessonParticipant:l=>students.find(s=>s.id===l.studentId),dashboardLessonMode:()=> 'presencial',studentTypeLabel:()=> 'Presencial',directGoogleMapsLink:()=>false,
 hesc:s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
 timerKey:(id,date)=>id+'|'+date,dashboardStatus:item=>({cls:'',label:item.status==='realizada'?'Realizada':'Agendada'}),statusClass:()=>'',
 financeStatus:()=>({kind:'ok'}),studentInitials:()=> 'NE',uiIcon:()=>'',isExperimentalLesson:()=>false,fmtDate:s=>s,formatTimerMs:()=> '01:00',lessonCountdownHtml:()=>'<span>ACTIVE_TIMER</span>',WHATSAPP_ICON:'',
 timeToMinutes:s=>Number(s.slice(0,2))*60+Number(s.slice(3)),slotEnd:(s,n)=>Number(s.slice(0,2))*60+Number(s.slice(3))+n,cleanExpiredTimers(){},renderFinanceAlert(){}};
vm.createContext(context);vm.runInContext(html.slice(start,finish),context);
const before=JSON.stringify(state);
context.renderWeek();
assert.equal(cards.length,7,'all seven dates, including Sunday, remain available');
assert.deepEqual(cards.filter(c=>!c.hidden).map(c=>c.dataset.date),['2026-10-20']);
assert.equal(cards.filter(c=>c.open).length,1);
assert.match(elements.weekDayStrip.innerHTML,/Dom/);assert.match(elements.weekDayStrip.innerHTML,/25\/10/);
assert.equal((wrap.html.match(/class="lesson agenda-lesson"[^>]* open>/g)||[]).length,0,'week rows start compact');
assert.match(wrap.html,/class="agenda-week-avatar"/);assert.match(wrap.html,/Financeiro: Em dia/);
assert.match(wrap.html,/Nome &lt;especial&gt;/,'names stay escaped');
assert.match(wrap.html,/Agendada/,'attendance is separate from financial status');
context.openWeekDay('2026-10-19');assert.deepEqual(cards.filter(c=>!c.hidden).map(c=>c.dataset.date),['2026-10-19']);assert.equal(scrolls,0,'day tap does not jump vertically');
context.openWeekDay('2026-10-21');assert.deepEqual(cards.filter(c=>!c.hidden).map(c=>c.dataset.date),['2026-10-21']);assert.match(wrap.html,/Sem aulas agendadas/);
context.openWeekDay('2026-10-25');context.renderWeek();assert.deepEqual(cards.filter(c=>!c.hidden).map(c=>c.dataset.date),['2026-10-25'],'selection survives repaint');
context.changeAgendaWeek(1);assert.match(elements.agendaWeekRange.textContent,/26\/10/);assert.deepEqual(cards.filter(c=>!c.hidden).map(c=>c.dataset.date),['2026-10-26']);
context.openWeekDay('2026-10-27');assert.deepEqual(cards.filter(c=>!c.hidden).map(c=>c.dataset.date),['2026-10-27']);
context.changeAgendaWeek(0);assert.deepEqual(cards.filter(c=>!c.hidden).map(c=>c.dataset.date),['2026-10-20']);
assert.equal(JSON.stringify(state),before,'navigation does not edit any saved lesson, payment or metadata');
const item={lesson:state.lessons[1],date:'2026-10-20',status:'realizada'};
const today=context.renderLessonCard(item,'todayList',false);assert.doesNotMatch(today,/agenda-week-avatar|Financeiro:/,'Today keeps its existing layout');
const week=context.renderLessonCard(item,'weekList',false);assert.match(week,/Realizada/);assert.match(week,/Financeiro: Em dia/);assert.match(week,/openWorkoutForLesson/);assert.match(week,/startLessonTimer/);assert.match(week,/cancelAndMakeup/);assert.match(week,/openEditLesson/);assert.match(week,/openWhatsFor/);
state.lessonTimers['tue|2026-10-20']={endAt:now+60000};assert.match(context.renderLessonCard(item,'weekList',false),/ACTIVE_TIMER/);assert.match(context.renderLessonCard(item,'weekList',false),/agenda-timer-pill/);
assert.ok(pillScrolls>0,'selected date is scrolled into horizontal view');
console.log('PASS: production weekly renderer/day navigation with DOM fakes: seven dates, one visible day, empty days, week changes, preserved selection/data, compact rows, escaped names, financial/attendance distinction, existing actions and running timer. Browser/device layout still requires inspection.');
