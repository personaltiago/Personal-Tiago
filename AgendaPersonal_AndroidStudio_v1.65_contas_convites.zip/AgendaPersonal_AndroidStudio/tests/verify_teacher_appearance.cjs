'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const {chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const fixture={students:[{id:'s',name:'Aluna de teste',studentType:'presencial',phone:'69999999999',financeEnabled:true,dueDate:'2026-11-11',startDate:'2026-10-11',monthlyValue:'300'}],lessons:[],payments:[],workoutPlans:[{id:'p',studentId:'s',name:'Ficha',days:[{id:'d',name:'Glúteo',exercises:[{id:'e',name:'Abdução de quadril',sets:'3',reps:'12',load:'30',rest:'60'}]}]}],customData:{preserve:52}};
const server=http.createServer((req,res)=>{const file=req.url.includes('avaliacoes.html')?'avaliacoes.html':'professor.html';res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,file)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  await context.addInitScript(fixture=>{if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(fixture));const original=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.__failKey===k)throw Error('quota');return original.call(this,k,v)}},fixture);
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>window.AgendaAppearance);const data=await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1'));
  await page.evaluate(()=>{showScreen('more');openColorPanel()});assert.equal(await page.locator('[data-teacher-mode="dark"]').getAttribute('aria-pressed'),'true');
  const audit=[];
  for(const design of ['current','neon-tl','metal-tl','pro-tl','deep-tl']){
   await page.evaluate(id=>{AgendaColors.selectDesign(id);AgendaColors.save({version:1,id:'custom',primary:'#9b32dc',secondary:'#457ca0',background:'#101d2c'});openColorPanel()},design);
   for(const mode of ['light','dark']){
    await page.locator('[data-teacher-mode="'+mode+'"]').click();assert.equal(await page.evaluate(()=>AgendaAppearance.getMode()),mode);assert.equal(await page.evaluate(()=>document.documentElement.style.colorScheme),mode);
    assert.equal(await page.locator('[data-teacher-mode="'+mode+'"]').getAttribute('aria-pressed'),'true');
    const config=await page.evaluate(()=>AgendaColors.get());assert.equal(config.primary,'#9b32dc');assert.equal(config.secondary,'#457ca0');if(mode==='dark')assert.equal(config.background,'#101d2c','custom dark background restored');
    const palettes=await page.evaluate(()=>{const p=AgendaColors.palette(AgendaColors.get()),c=p.colors;return ['bg','surface','raised','field','tint','tint-strong'].flatMap(bg=>['text','muted','accent','good','warn','danger'].map(fg=>({bg,fg,ratio:AgendaColors.contrast(c[fg],c[bg])}))).concat([{bg:'primary-fill',fg:'on-primary',ratio:AgendaColors.contrast(c['primary-fill'],c['on-primary'])}])});
    for(const item of palettes)assert.ok(item.ratio>=4.49,design+' '+mode+' '+JSON.stringify(item));
    await page.evaluate(()=>closeDialog('colorPanelDialog'));
    for(const screen of ['dashboard','students-presencial','finance','more','workouts']){
     await page.evaluate(screen=>showScreen(screen),screen);
     const findings=await page.evaluate(()=>{
      const rgb=c=>c.match(/[\d.]+/g)?.map(Number)||[0,0,0,0],l=c=>c.slice(0,3).map(n=>n/255).reduce((s,n,i)=>s+[.2126,.7152,.0722][i]*(n<=.04045?n/12.92:((n+.055)/1.055)**2.4),0),ratio=(a,b)=>(Math.max(l(a),l(b))+.05)/(Math.min(l(a),l(b))+.05);
      function back(el){for(let n=el;n;n=n.parentElement){const s=getComputedStyle(n),image=s.backgroundImage;if(image.startsWith('linear-gradient')||image.startsWith('radial-gradient')){const colors=[...image.matchAll(/rgba?\([^)]*\)/g)].map(m=>rgb(m[0])).filter(c=>c.length===3||c[3]===1);if(colors.length)return colors}const c=rgb(s.backgroundColor);if(c.length===3||c[3]===1)return [c]}return [[255,255,255]]}
      return [...document.querySelectorAll('.screen.active *,.bottom-navigation button,.panel-return-bar button')].filter(n=>n.childElementCount===0&&n.textContent.trim()&&!n.closest('svg')&&n.checkVisibility({checkOpacity:true,checkVisibilityCSS:true})).map(n=>{const s=getComputedStyle(n),foreground=rgb(s.color),min=Math.min(...back(n).map(c=>ratio(foreground,c))),size=parseFloat(s.fontSize),threshold=size>=24||size>=18.66&&Number(s.fontWeight)>=700?3:4.5;return {selector:n.tagName.toLowerCase()+(n.id?'#'+n.id:'.'+[...n.classList].join('.')),text:n.textContent.trim().slice(0,70),ratio:min,threshold,color:s.color,background:back(n)}}).filter(x=>x.ratio+.01<x.threshold);
     });
     audit.push({design,mode,screen,findings});
    }
    await page.evaluate(()=>openColorPanel());
   }
  }
  fs.writeFileSync('/workspace/scratch/9330e8f92c6b/tmp/teacher_appearance_audit.json',JSON.stringify(audit,null,2));
  const low=audit.filter(a=>a.mode==='light').flatMap(a=>a.findings.map(f=>({design:a.design,screen:a.screen,...f})));assert.deepEqual(low,[],'visible light-mode text contrast');assert.deepEqual(audit.filter(a=>a.mode==='dark').flatMap(a=>a.findings),[],'visible dark-mode text contrast');
  await page.evaluate(()=>{AgendaColors.selectDesign('deep-tl');chooseTeacherAppearance('light');closeDialog('colorPanelDialog');showScreen('students-presencial')});await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/teacher_light_review.png'});
  await page.evaluate(()=>{openColorPanel();document.getElementById('colorPanelScroll').scrollTop=0});await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/teacher_appearance_controls_review.png'});
  for(const width of [320,360,390,480]){await page.setViewportSize({width,height:844});const fits=await page.locator('.teacher-appearance-options').evaluate(n=>n.getBoundingClientRect().right<=innerWidth&&[...n.querySelectorAll('button')].every(b=>b.scrollWidth<=b.clientWidth+1));assert.ok(fits,'mode choices fit '+width)}
  await page.setViewportSize({width:390,height:844});const theme=await page.evaluate(()=>AgendaColors.get());await page.reload();await page.waitForFunction(()=>window.AgendaAppearance);assert.equal(await page.evaluate(()=>AgendaAppearance.getMode()),'light');assert.deepEqual(await page.evaluate(()=>AgendaColors.get()),theme);
  // Neither failed storage write may change the visible mode or the saved colors.
  for(const key of ['agendaPersonalTL_appearance_backgrounds_v1','agendaPersonalTL_design_v1']){
   await page.evaluate(key=>{openColorPanel();window.__failKey=key},key);await page.locator('[data-teacher-mode="dark"]').click();assert.equal(await page.evaluate(()=>AgendaAppearance.getMode()),'light');assert.deepEqual(await page.evaluate(()=>AgendaColors.get()),theme);await page.evaluate(()=>__failKey='');
  }
  await page.evaluate(()=>{setColorPanelTab('custom');editColorPanel('primary','#22aa77');cancelColorPanelPreview();closeDialog('colorPanelDialog')});assert.deepEqual(await page.evaluate(()=>AgendaColors.get()),theme);
  const assessment=await context.newPage();assessment.on('pageerror',e=>errors.push(e.message));await assessment.goto('http://127.0.0.1:'+server.address().port+'/avaliacoes.html');await assessment.waitForFunction(()=>window.AgendaColors);assert.equal(await assessment.evaluate(()=>document.documentElement.dataset.agendaColorMode),'light','assessment inherits saved light theme');await page.evaluate(()=>chooseTeacherAppearance('dark'));await assessment.waitForFunction(()=>document.documentElement.dataset.agendaColorMode==='dark');await assessment.close();
  const presetFailures=await page.evaluate(()=>{
   const failures=[];openColorPanel();
   for(const design of AgendaColors.designs){AgendaColors.selectDesign(design.id);for(const mode of ['light','dark']){
    const background=mode==='light'?'#f2edf6':'#121f2e';AgendaColors.save({version:1,id:'custom',primary:'#9b32dc',secondary:'#457ca0',background});
    for(const preset of AgendaColors.presets){chooseColorPreset(preset.id);const actual=AgendaColors.get();if(actual.background!==background||AgendaAppearance.getMode()!==mode||actual.primary!==preset.primary||actual.secondary!==preset.secondary)failures.push({design:design.id,mode,preset:preset.id,actual})}
   }}return failures;
  });assert.deepEqual(presetFailures,[],'every color preset preserves mode and exact background in all 5 designs');
  assert.equal(await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1')),data,'business data unchanged');assert.deepEqual(errors,[]);
  console.log('PASS: 5 designs × 2 modes, 5 main screens; palette contrast >=4.5, custom accent preservation, exact dark background restoration, pressed state, 4 mobile widths, restart, storage rollback and custom-preview cancellation. No student settings or business data changed.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
