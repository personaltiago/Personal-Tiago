// Verifica o modo "agenda no telefone" (Etapa 2) no Chromium, com ponte Android simulada e duas telas (pai + iframe).
const fs=require('fs'),path=require('path'),assert=require('assert');
const {chromium}=require('playwright');
const release=JSON.parse(fs.readFileSync(path.join(__dirname,'..','web','native-release.agenda.json'),'utf8'));
const html=release.files['professor.html'];
const a=html.indexOf('<script id="ap-native-store">'),b=html.indexOf('</script>',a);
assert(a>0&&b>a,'script ausente');
for(const k of ['index.html','professor.html','avaliacoes.html'])assert(release.files[k].includes('id="ap-native-store"'),k);
const code=html.slice(a+'<script id="ap-native-store">'.length,b);
const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const backup=scripts.find(s=>s.includes('global.APFullBackupCore='));
const mirror=scripts.find(s=>s.includes('window.APNativeMirror='));
const backupPanel=scripts.find(s=>s.includes('window.APFullBackup='));
const saveAgenda=html.match(/^function save\(\).*syncNativeAlarms\(\)\}$/m)?.[0];
assert(backup&&mirror&&backupPanel&&saveAgenda);
const BRIDGE=`(function(){const mem=JSON.parse(sessionStorage.getItem('fakeNative')||'{"on":false,"v":null,"writes":0,"fail":false,"unreadable":false}');
 const save=()=>{try{sessionStorage.setItem('fakeNative',JSON.stringify(mem.v&&mem.v.length>2e6?Object.assign({},mem,{v:'{}'}):mem))}catch(_){}};
 window.__mem=mem;
 window.Android={getMirrorVersion:()=>2,nsActive:()=>mem.on,nsRead:()=>mem.unreadable?'':(mem.v||''),
  nsWrite:v=>{if(mem.failNext){mem.failNext=false;return false}if(mem.fail||typeof v!=='string'||v[0]!=='{')return false;mem.v=v;mem.writes++;save();return true},
  nsActivate:v=>{mem.v=v;mem.on=true;save();return JSON.stringify({ok:true,length:v.length,hash:window.APNativeStore.hash(v)})},
  nsDeactivate:()=>{mem.on=false;save();return true},nsInfo:()=>JSON.stringify({active:mem.on,exists:!!mem.v,reserve:true,source:'main',length:(mem.v||'').length,savedAt:1}),
  mirrorInfo:()=>JSON.stringify(mem.mirror?{exists:true,length:mem.mirror.length,hash:window.APNativeStore.hash(mem.mirror)}:{exists:false}),
  mirrorSave:(key,value)=>{mem.mirror=value;save();return true},
  mirrorSaveForce:(key,value)=>{mem.mirror=value;save();return true}};
})();`;
const PAGE=(inner)=>`<!doctype html><html><head><script>${BRIDGE}</script><script>${code}</script><script>${backup}</script><script>${mirror}</script></head><body>${inner}</body></html>`;
const RECOVERY_PAGE=PAGE(`<button id="edit">Editar agenda</button><script>
const DB_KEY='agendaPersonalTL_v1',state=JSON.parse(localStorage.getItem(DB_KEY)||'{}');
const normalizeState=x=>x,renderAll=()=>{},toast=()=>{},syncNativeAlarms=()=>true;
${saveAgenda}
window.tryAgendaEdit=name=>{state.students[0].name=name;return save()};
document.getElementById('edit').onclick=()=>window.tryAgendaEdit('edição pela interface');
const originalOpen=indexedDB.open.bind(indexedDB);
const recoverySimulation=sessionStorage.getItem('recoverySimulation');
if(recoverySimulation)indexedDB.open=function(name,...args){
 if(name==='agenda-full-backup-control-v1')return originalOpen(name,...args);
 indexedDB.open=originalOpen;
 const pending={};
 if(recoverySimulation==='fail'){
  queueMicrotask(()=>{pending.error=new Error('disco indisponível');pending.onerror()});
 }else{
  window.resumeRecovery=()=>{
   const request=originalOpen(name,...args);
   request.onsuccess=()=>{pending.result=request.result;pending.onsuccess()};
   request.onerror=()=>{pending.error=request.error;pending.onerror()};
  };
 }
 return pending;
};
</script><script>${backupPanel}</script>`);
const FRAME=`<!doctype html><html><head><script>${code}</script></head><body></body></html>`;
(async()=>{
 const br=await chromium.launch();const ctx=await br.newContext();const page=await ctx.newPage();
 const errs=[];page.on('pageerror',e=>errs.push(String(e)));
 await page.route('http://t.local/**',r=>{const u=r.request().url();r.fulfill({contentType:'text/html; charset=utf-8',body:u.endsWith('/frame.html')?FRAME:u.endsWith('/recovery.html')?RECOVERY_PAGE:PAGE('<iframe id="f" src="/frame.html"></iframe>')})});
 await page.goto('http://t.local/p.html');await page.waitForFunction(()=>{try{return !!document.getElementById('f').contentWindow.APNativeStore}catch(_){return false}});
 const ev=(fn,arg)=>page.evaluate(fn,arg);
 // 1. modo antigo: tudo vai ao localStorage
 await ev(()=>{localStorage.setItem('agendaPersonalTL_v1','{"a":1}')});
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),'{"a":1}');
 assert.strictEqual(await ev(()=>window.__mem.writes),0);
 assert.strictEqual((await ev(()=>APNativeStore.status())).active,false);
 // 2. A confirmação da cópia ativa o modo e a agenda reabre idêntica.
 const initial=JSON.stringify({students:[{id:'teste',name:'Agenda fictícia'}],workoutPlans:[]});
 await ev(v=>localStorage.setItem('agendaPersonalTL_v1',v),initial);
 const act=await ev(()=>APNativeStore.activate());assert.equal(act.ok,true);
 assert.strictEqual(await ev(()=>window.__mem.on),true);
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),initial);
 assert(!await ev(()=>Object.keys(localStorage).includes('agendaPersonalTL_v1')));
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 assert.strictEqual(await ev(()=>document.getElementById('f').contentWindow.localStorage.getItem('agendaPersonalTL_v1')),initial);
 // 3. valor grande (>5 MB) acima da cota
 const big=await ev(()=>{const v=JSON.stringify({x:'a'.repeat(9e6)});localStorage.setItem('agendaPersonalTL_v1',v);return v.length});
 assert(big>9e6);
 assert.strictEqual(await ev(()=>document.getElementById('f').contentWindow.localStorage.getItem('agendaPersonalTL_v1').length),big,'iframe vê valor grande');
 await ev(()=>APNativeStore.flush());assert.strictEqual(await ev(()=>window.__mem.v.length),big,'gravou arquivo');
 // 4. escrita no iframe chega ao pai + evento de storage
 await ev(()=>{window.__ev=0;addEventListener('storage',e=>{if(e.key==='agendaPersonalTL_v1')window.__ev++})});
 await ev(()=>{document.getElementById('f').contentWindow.localStorage.setItem('agendaPersonalTL_v1','{"z":2}')});
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),'{"z":2}');
 assert.strictEqual(await ev(()=>window.__ev),1,'evento emulado');
 // 5. debounce: várias escritas, uma gravação
 const w0=await ev(()=>window.__mem.writes);
 await ev(()=>{for(let i=0;i<5;i++)localStorage.setItem('agendaPersonalTL_v1','{"i":'+i+'}')});
 await page.waitForTimeout(900);
 assert.strictEqual(await ev(()=>window.__mem.writes)-w0,1);assert.strictEqual(await ev(()=>window.__mem.v),'{"i":4}');
 // 6. outras chaves seguem no localStorage
 await ev(()=>{localStorage.setItem('outra','x')});assert.strictEqual(await ev(()=>localStorage.getItem('outra')),'x');
 // 7. falha de gravação: próxima escrita lança QuotaExceededError
 await ev(()=>{window.__mem.fail=true;localStorage.setItem('agendaPersonalTL_v1','{"f":1}')});
 await ev(()=>APNativeStore.flush());
 const thrown=await ev(()=>{try{localStorage.setItem('agendaPersonalTL_v1','{"f":2}');return 'no'}catch(e){return e.name}});
 assert.strictEqual(thrown,'QuotaExceededError');
 await ev(()=>{window.__mem.fail=false});await page.waitForTimeout(3300);
 assert.strictEqual(await ev(()=>window.__mem.v),'{"f":1}','retry gravou');
 // 8. reinício: modo ativo lê do arquivo
 await ev(()=>APNativeStore.flush());
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),'{"f":1}','leu do arquivo após reiniciar');
 // 9. arquivo ilegível: não grava (evita sobrescrever o principal com dados vazios)
 await ev(()=>sessionStorage.setItem('fakeNative',JSON.stringify({on:true,v:null,writes:0,fail:false,unreadable:true})));
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),null);
 assert.strictEqual(await ev(()=>{try{localStorage.setItem('agendaPersonalTL_v1','{"novo":1}');return 'no'}catch(e){return e.name}}),'QuotaExceededError');
 assert.strictEqual(await ev(()=>APNativeStore.status().broken),true);
 assert.strictEqual(await ev(()=>window.__mem.writes),0);
 assert.strictEqual((await ev(()=>APNativeStore.deactivate())).ok,false);
 await ev(()=>sessionStorage.setItem('fakeNative',JSON.stringify({on:true,v:'{"f":1}',writes:0,fail:false,unreadable:false})));
 // 10. desativar: volta ao localStorage
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 await ev(()=>{window.__mem.unreadable=false});
 const de=await ev(()=>APNativeStore.deactivate());
 if(!de.ok)assert.fail('deactivate '+JSON.stringify(de));
 assert.strictEqual(await ev(()=>window.__mem.on),false);
 assert(await ev(()=>Object.keys(localStorage).includes('agendaPersonalTL_v1')));
 // 11. desativar com dados grandes recusa e continua ativo
 await ev(()=>{localStorage.removeItem('agendaPersonalTL_v1');sessionStorage.setItem('fakeNative',JSON.stringify({on:true,v:'{}',writes:0,fail:false,unreadable:false}))});
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 await ev(()=>{localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({x:'b'.repeat(9e6)}))});
 const bad=await ev(()=>APNativeStore.deactivate());assert.strictEqual(bad.ok,false);assert.strictEqual(bad.error,'quota');
 assert.strictEqual((await ev(()=>APNativeStore.status())).active,true);
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1').length)>9e6,true);
 // 12. Restore transactions in both modes, with native disk and IndexedDB verified after reload.
 for(const phone of [false,true]){
  const backupValue=JSON.stringify({students:[{id:'simulado',name:'Aluna fictícia'}],workoutPlans:[]});
  await ev(({phone,initial})=>{
   localStorage.removeItem('agendaPersonalTL_v1');
   sessionStorage.setItem('fakeNative',JSON.stringify({on:phone,v:phone?initial:null,writes:0}));
  },{phone,initial});
  await page.reload();
  await ev(({phone,initial})=>{if(!phone)localStorage.setItem('agendaPersonalTL_v1',initial)},{phone,initial});
  const result=await ev(async ({backupValue,phone,initial})=>{
   const agenda='agendaPersonalTL_v1', owner='professor-ficticio', preference='tiago-lima-avaliacoes-v1';
   const core=APFullBackupCore;
   localStorage.setItem(preference,'antes');
   const previous=await core.capture(owner);
   const data={...previous,local:{[agenda]:backupValue,[preference]:'depois'}};
   data.databases[0].rows=[{key:'ficticio',value:{name:'Anexo fictício'}}];
   const remaining=()=>new Promise((resolve,reject)=>{
    const open=indexedDB.open('agenda-full-backup-control-v1');
    open.onerror=()=>reject(open.error);
    open.onsuccess=()=>{
     const db=open.result,tx=db.transaction('restore'),get=tx.objectStore('restore').get('pending');
     tx.oncomplete=()=>{db.close();resolve(get.result===undefined)};
     tx.onerror=()=>reject(tx.error);
    };
   });
   let failed=false, guardCalls=0;
   if(phone)window.__mem.failNext=true;
   try{await core.restore({data},owner,()=>phone||++guardCalls<3)}catch(_){failed=true}
   const reverted=await core.capture(owner);
   const rollback=failed&&reverted.local[agenda]===initial&&reverted.local[preference]==='antes'&&
      reverted.databases[0].rows.length===0&&await remaining()&&(!phone||window.__mem.v===initial);
   const legacySize=()=>Array.from({length:localStorage.length},(_,i)=>localStorage.key(i))
     .reduce((sum,key)=>sum+key.length+localStorage.getItem(key).length,0);
   const sizeBefore=legacySize();
   await core.restore({data},owner);
   const captured=await core.capture(owner);
   return {rollback,recovered:captured.local[agenda]===backupValue&&captured.local[preference]==='depois',
    journalEmpty:await remaining(),noExtraStorage:legacySize()===sizeBefore+1+(phone?0:backupValue.length-initial.length),
    mirrored:APNativeMirror.status().inSync,file:!phone||window.__mem.v===backupValue,
    attachment:captured.databases[0].rows[0]?.value.name==='Anexo fictício'};
  },{backupValue,phone,initial});
  assert.deepStrictEqual(result,{rollback:true,recovered:true,journalEmpty:true,noExtraStorage:true,mirrored:true,file:true,attachment:true},'restauração em modo '+(phone?'telefone':'antigo'));
  await page.reload();
  assert.equal(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),backupValue);
  assert(await ev(()=>APNativeMirror.status().inSync));
  // Clear only the fictitious attachment before exercising the other mode.
  await ev(async()=>{
   const owner='professor-ficticio',data=await APFullBackupCore.capture(owner);
   data.databases[0].rows=[];
   await APFullBackupCore.restore({data},owner);
  });
 }
 // 13. Startup recovery blocks both the panel and its normal save path until the old agenda is reloaded.
 const candidate=JSON.stringify({students:[{id:'novo',name:'Agenda do backup'}],workoutPlans:[]});
 const stageRecovery=async ({phone,initial,candidate,simulation})=>{
  const key='agendaPersonalTL_v1';
  if(!APNativeStore.flush())throw Error('falha ao preparar agenda fictícia');
  if(!phone&&APNativeStore.status().active&&!APNativeStore.deactivate().ok)throw Error('falha ao preparar modo antigo');
  const before=await APFullBackupCore.capture('professor-ficticio');
  before.local[key]=initial;
  await new Promise((resolve,reject)=>{
   const request=indexedDB.open('agenda-full-backup-control-v1');
   request.onerror=()=>reject(request.error);
   request.onsuccess=()=>{
    const db=request.result,tx=db.transaction('restore','readwrite');
    tx.objectStore('restore').put({before},'pending');
    tx.oncomplete=()=>{db.close();resolve()};
    tx.onerror=()=>{db.close();reject(tx.error)};
   };
  });
  if(phone&&!APNativeStore.status().active&&!APNativeStore.activate().ok)throw Error('falha ao preparar modo telefone');
  localStorage.setItem(key,candidate);
  if(!APNativeStore.flush())throw Error('falha ao gravar agenda do backup fictício');
  sessionStorage.setItem('recoverySimulation',simulation);
 };
 const recovery=page.getByRole('dialog',{name:'Recuperação da agenda'});
 for(const phone of [false,true]){
  await ev(stageRecovery,{phone,initial,candidate,simulation:'hold'});
  await page.goto('http://t.local/recovery.html');
  await page.waitForFunction(()=>typeof resumeRecovery==='function');
  assert(await recovery.isVisible());
  await page.keyboard.press('Escape');
  assert(await recovery.isVisible(),'Escape não libera o painel durante recuperação');
  const writes=await ev(()=>window.__mem.writes);
  assert.strictEqual(await ev(()=>tryAgendaEdit('edição simulada')),false);
  assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),candidate);
  if(phone)assert.equal(await ev(()=>window.__mem.writes),writes);
  await ev(()=>resumeRecovery());
  assert(await ev(()=>APFullBackup.ready));
  await recovery.waitFor({state:'hidden'});
  assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),initial);
  assert.strictEqual(await ev(()=>state.students[0].name),'Agenda fictícia');
  await page.getByRole('button',{name:'Editar agenda'}).click();
  assert.strictEqual(await ev(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')).students[0].name),'edição pela interface');
 }
 // A failed recovery keeps the panel locked and exposes a way to retry with the same journal.
 await ev(stageRecovery,{phone:true,initial,candidate,simulation:'fail'});
 await page.reload();
 assert.strictEqual(await ev(()=>APFullBackup.ready),false);
 assert(await recovery.getByText(/Não foi possível recuperar a agenda/).isVisible());
 assert.strictEqual(await ev(()=>tryAgendaEdit('edição durante erro')),false);
 await ev(()=>sessionStorage.removeItem('recoverySimulation'));
 await recovery.getByRole('button',{name:'Reabrir painel'}).click();
 await recovery.waitFor({state:'hidden'});
 assert(await ev(()=>APFullBackup.ready));
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),initial);
 assert.deepStrictEqual(errs,[]);
 await br.close();console.log('verify_native_store: OK');
})().catch(e=>{console.error(e);process.exit(1)});
