// Verifica o modo "agenda no telefone" (Etapa 2) no Chromium, com ponte Android simulada e duas telas (pai + iframe).
const fs=require('fs'),path=require('path'),assert=require('assert');
const {chromium}=require('playwright');
const release=JSON.parse(fs.readFileSync(path.join(__dirname,'..','web','native-release.agenda.json'),'utf8'));
const html=release.files['professor.html'];
const a=html.indexOf('<script id="ap-native-store">'),b=html.indexOf('</script>',a);
assert(a>0&&b>a,'script ausente');
for(const k of ['index.html','professor.html','avaliacoes.html'])assert(release.files[k].includes('id="ap-native-store"'),k);
const code=html.slice(a+'<script id="ap-native-store">'.length,b);
const BRIDGE=`(function(){const mem=JSON.parse(sessionStorage.getItem('fakeNative')||'{"on":false,"v":null,"writes":0,"fail":false,"unreadable":false}');
 const save=()=>{try{sessionStorage.setItem('fakeNative',JSON.stringify(mem.v&&mem.v.length>2e6?Object.assign({},mem,{v:'{}'}):mem))}catch(_){}};
 window.__mem=mem;
 window.Android={getMirrorVersion:()=>2,nsActive:()=>mem.on,nsRead:()=>mem.unreadable?'':(mem.v||''),
  nsWrite:v=>{if(mem.fail||typeof v!=='string'||v[0]!=='{')return false;mem.v=v;mem.writes++;save();return true},
  nsActivate:v=>{mem.v=v;mem.on=true;save();return JSON.stringify({ok:true,length:v.length,hash:window.APNativeStore.hash(v)})},
  nsDeactivate:()=>{mem.on=false;save();return true},nsInfo:()=>JSON.stringify({active:mem.on,exists:!!mem.v,reserve:true,source:'main',length:(mem.v||'').length,savedAt:1})};
})();`;
const PAGE=(inner)=>`<!doctype html><html><head><script>${BRIDGE}</script><script>${code}</script></head><body>${inner}</body></html>`;
const FRAME=`<!doctype html><html><head><script>${code}</script></head><body></body></html>`;
(async()=>{
 const br=await chromium.launch();const ctx=await br.newContext();const page=await ctx.newPage();
 const errs=[];page.on('pageerror',e=>errs.push(String(e)));
 await page.route('http://t.local/**',r=>{const u=r.request().url();r.fulfill({contentType:'text/html',body:u.endsWith('/frame.html')?FRAME:PAGE('<iframe id="f" src="/frame.html"></iframe>')})});
 await page.goto('http://t.local/p.html');await page.waitForFunction(()=>{try{return !!document.getElementById('f').contentWindow.APNativeStore}catch(_){return false}});
 const ev=(fn,arg)=>page.evaluate(fn,arg);
 // 1. modo antigo: tudo vai ao localStorage
 await ev(()=>{localStorage.setItem('agendaPersonalTL_v1','{"a":1}')});
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),'{"a":1}');
 assert.strictEqual(await ev(()=>window.__mem.writes),0);
 assert.strictEqual((await ev(()=>APNativeStore.status())).active,false);
 // 2. Novas ativações estão pausadas. Um aparelho que já usa o modo continua lendo a agenda.
 const act=await ev(()=>APNativeStore.activate());assert.equal(act.ok,false);
 assert.strictEqual(await ev(()=>window.__mem.on),false);
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),'{"a":1}');
 await ev(()=>{localStorage.removeItem('agendaPersonalTL_v1');sessionStorage.setItem('fakeNative',JSON.stringify({on:true,v:'{"a":1}',writes:0,fail:false,unreadable:false}))});
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 assert.strictEqual(await ev(()=>document.getElementById('f').contentWindow.localStorage.getItem('agendaPersonalTL_v1')),'{"a":1}');
 // 3. valor grande (>5 MB) acima da cota
 const big=await ev(()=>{const v=JSON.stringify({x:'a'.repeat(9e6)});localStorage.setItem('agendaPersonalTL_v1',v);return v.length});
 assert(big>9e6);
 assert.strictEqual(await ev(()=>document.getElementById('f').contentWindow.localStorage.getItem('agendaPersonalTL_v1').length),big,'iframe vê valor grande');
 await ev(()=>APNativeStore.flush());assert.strictEqual(await ev(()=>window.__mem.v.length),big,'gravou arquivo');
 // 4. escrita no iframe chega ao pai + evento de storage
 await ev(()=>{window.__ev=0;addEventListener('storage',e=>{if(e.key==='agendaPersonalTL_v1')window.__ev++})});
 await ev(()=>{document.getElementById('f').contentWindow.localStorage.setItem('agendaPersonalTL_v1','{"z":2}')});
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),'{"z":2}');
 assert.strictEqual(await ev(()=>window.__ev),1,'evento emulado');
 // 5. debounce: várias escritas, uma gravação
 const w0=await ev(()=>window.__mem.writes);
 await ev(()=>{for(let i=0;i<5;i++)localStorage.setItem('agendaPersonalTL_v1','{"i":'+i+'}')});
 await page.waitForTimeout(900);
 assert.strictEqual(await ev(()=>window.__mem.writes)-w0,1);assert.strictEqual(await ev(()=>window.__mem.v),'{"i":4}');
 // 6. outras chaves seguem no localStorage
 await ev(()=>{localStorage.setItem('outra','x')});assert.strictEqual(await ev(()=>localStorage.getItem('outra')),'x');
 // 7. falha de gravação: próxima escrita lança QuotaExceededError
 await ev(()=>{window.__mem.fail=true;localStorage.setItem('agendaPersonalTL_v1','{"f":1}')});
 await ev(()=>APNativeStore.flush());
 const thrown=await ev(()=>{try{localStorage.setItem('agendaPersonalTL_v1','{"f":2}');return 'no'}catch(e){return e.name}});
 assert.strictEqual(thrown,'QuotaExceededError');
 await ev(()=>{window.__mem.fail=false});await page.waitForTimeout(3300);
 assert.strictEqual(await ev(()=>window.__mem.v),'{"f":1}','retry gravou');
 // 8. reinício: modo ativo lê do arquivo
 await ev(()=>APNativeStore.flush());
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),'{"f":1}','leu do arquivo após reiniciar');
 // 9. arquivo ilegível: não grava (evita sobrescrever o principal com dados vazios)
 await ev(()=>sessionStorage.setItem('fakeNative',JSON.stringify({on:true,v:null,writes:0,fail:false,unreadable:true})));
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1')),null);
 assert.strictEqual(await ev(()=>{try{localStorage.setItem('agendaPersonalTL_v1','{"novo":1}');return 'no'}catch(e){return e.name}}),'QuotaExceededError');
 assert.strictEqual(await ev(()=>APNativeStore.status().broken),true);
 assert.strictEqual(await ev(()=>window.__mem.writes),0);
 assert.strictEqual((await ev(()=>APNativeStore.deactivate())).ok,false);
 await ev(()=>sessionStorage.setItem('fakeNative',JSON.stringify({on:true,v:'{"f":1}',writes:0,fail:false,unreadable:false})));
 // 10. desativar: volta ao localStorage
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 await ev(()=>{window.__mem.unreadable=false});
 const de=await ev(()=>APNativeStore.deactivate());
 if(!de.ok)assert.fail('deactivate '+JSON.stringify(de));
 assert.strictEqual(await ev(()=>window.__mem.on),false);
 assert(await ev(()=>Object.keys(localStorage).includes('agendaPersonalTL_v1')));
 // 11. desativar com dados grandes recusa e continua ativo
 await ev(()=>{localStorage.removeItem('agendaPersonalTL_v1');sessionStorage.setItem('fakeNative',JSON.stringify({on:true,v:'{}',writes:0,fail:false,unreadable:false}))});
 await page.reload();await page.waitForFunction(()=>!!window.APNativeStore);
 await ev(()=>{localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({x:'b'.repeat(9e6)}))});
 const bad=await ev(()=>APNativeStore.deactivate());assert.strictEqual(bad.ok,false);assert.strictEqual(bad.error,'quota');
 assert.strictEqual((await ev(()=>APNativeStore.status())).active,true);
 assert.strictEqual(await ev(()=>localStorage.getItem('agendaPersonalTL_v1').length)>9e6,true);
 assert.deepStrictEqual(errs,[]);
 await br.close();console.log('verify_native_store: OK');
})().catch(e=>{console.error(e);process.exit(1)});
