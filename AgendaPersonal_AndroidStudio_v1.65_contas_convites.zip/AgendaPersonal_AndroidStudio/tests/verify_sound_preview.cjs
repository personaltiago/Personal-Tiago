'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const {chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://local').pathname.slice(1)||'professor.html';if(!['professor.html','index.html','avaliacoes.html','cadastro.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});try{
 const ctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,timezoneId:'America/Cuiaba'});await ctx.route(/^https:\/\//,r=>r.abort());
 await ctx.addInitScript(()=>{
  if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[{id:'s',name:'Aluno de teste',studentType:'presencial',financeEnabled:false}],lessons:[{id:'l',studentId:'s',date:'2026-10-16',time:'16:45',duration:60,lead:30,repeat:'none',repeatDays:[]}],workoutPlans:[],lessonTimers:{},customData:{keep:9}}));
  window.__timerCalls=[];window.__settings=0;window.__blocked=false;window.__timerIssue='';window.__lessonIssue='Ative as notificações das aulas.';window.__restSupported=true;
  window.Android={syncLessonAlarms(json){window.__agendaPayload=JSON.parse(json);return true},getAlarmStatus(){return JSON.stringify({ready:!__lessonIssue,issue:__lessonIssue,timerReady:!__timerIssue,timerIssue:__timerIssue,lessonSoundName:localStorage.getItem('test_lesson_sound')||'',timerSoundName:localStorage.getItem('test_timer_sound')||'',restSoundName:localStorage.getItem('test_rest_sound')||''})},getCustomSoundStatus(){return JSON.stringify({lessonName:localStorage.getItem('test_lesson_sound')||'',timerName:localStorage.getItem('test_timer_sound')||'',restName:localStorage.getItem('test_rest_sound')||'',restSupported:__restSupported})},saveCustomSound(kind,name,type,bytes){if(window.__failSound)return '{"error":"Falha ao guardar áudio"}';localStorage.setItem('test_'+kind+'_sound',name);return this.getCustomSoundStatus()},showAlarmSettings(){__settings++},startLessonTimer(json){if(__blocked)return false;__timerCalls.push(JSON.parse(json));return true},cancelLessonTimer(){window.__cancelled=(window.__cancelled||0)+1}};
 });
 const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.clock.install({time:new Date('2026-10-16T20:30:00Z')});await page.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await page.evaluate(()=>showScreen('today'));
 assert.match(await page.locator('#screen-today [data-agenda-alarm-status]').innerText(),/Ative as notificações/);assert.equal(await page.evaluate(()=>__agendaPayload.lessons[0].lead),30);
 await page.locator('#screen-today').getByRole('button',{name:'Verificar / testar',exact:true}).click();assert.equal(await page.evaluate(()=>__settings),1);
 await page.locator('#screen-today .agenda-start-lesson').click();const first=await page.evaluate(()=>__timerCalls[0]);assert.equal(first.durationMinutes,60);assert.ok(Math.abs(first.triggerAtMillis-await page.evaluate(()=>Date.now()+3600000))<1000);assert.equal(await page.locator('#screen-today .agenda-start-lesson').count(),0);assert.ok(await page.locator('#screen-today .lesson-timer[data-timer-key]').isVisible());
 await page.evaluate(()=>startLessonTimer('l','2026-10-16'));assert.equal(await page.evaluate(()=>__timerCalls.length),1,'no double timer');
 await page.reload();await page.evaluate(()=>showScreen('today'));assert.ok(await page.locator('#screen-today .lesson-timer[data-timer-key]').isVisible(),'running timer survives reload');await page.locator('#screen-today .lesson-timer-stop').click();assert.ok(await page.locator('#screen-today .agenda-start-lesson').isVisible());
 await page.evaluate(()=>{__blocked=true;__timerIssue='Escolha um som em Fim da aula.';renderAlarmStatus()});await page.locator('#screen-today .agenda-start-lesson').click();assert.equal(await page.evaluate(()=>state.lessonTimers['l|2026-10-16'].native),false);assert.match(await page.locator('#screen-today [data-agenda-alarm-status]').innerText(),/Escolha um som em Fim da aula/);assert.ok(await page.locator('#screen-today [data-timer-retry]').isVisible());
 await page.evaluate(()=>{__blocked=false;__timerIssue=''});await page.locator('#screen-today [data-timer-retry]').click();assert.equal(await page.evaluate(()=>state.lessonTimers['l|2026-10-16'].native),true);
 await page.locator('#screen-today').getByRole('button',{name:'Sons e alertas',exact:true}).click();assert.ok(await page.locator('#screen-settings').isVisible());
 await page.evaluate(()=>{
  window.__preview={kind:'',error:''};window.__plays=[];window.__stops=0;
  Android.playCustomSound=kind=>{__plays.push(kind);__preview={kind,error:''};return true};
  Android.stopCustomSoundPreview=()=>{__stops++;__preview={kind:'',error:''}};
  Android.getSoundPreviewStatus=()=>JSON.stringify(__preview);
 });
 const lesson=page.locator('[data-sound-preview="lesson"]'),timer=page.locator('[data-sound-preview="timer"]');
 const lessonPicker=page.locator('[data-phone-ringtone="lesson"]'),timerPicker=page.locator('[data-phone-ringtone="timer"]');
 const rest=page.locator('[data-sound-preview="rest"]'),restPicker=page.locator('[data-phone-ringtone="rest"]'),restFile=page.locator('[data-audio-file="rest"]');
 assert.equal(await page.locator('.sound-choice-group').first().locator('.sound-button strong').innerText(),'Som do descanso do treino');
 await page.evaluate(()=>__restSupported=false);
 for(const button of [rest,restPicker,restFile]){await button.click();assert.match(await page.locator('#toast').innerText(),/APK 1.111/)}
 assert.equal(await page.evaluate(()=>localStorage.getItem('test_rest_sound')),null,'old APK cannot silently save rest into another sound');
 await page.evaluate(()=>__restSupported=true);
 const restChoice=page.waitForEvent('filechooser');await restFile.click();await(await restChoice).setFiles({name:'descanso.wav',mimeType:'audio/wav',buffer:Buffer.from('rest-audio')});
 await page.waitForFunction(()=>document.getElementById('restSoundLabel').textContent==='descanso.wav');
 assert.equal(await page.locator('#lessonSoundLabel').innerText(),'Padrão do celular');assert.equal(await page.locator('#timerSoundLabel').innerText(),'Padrão do celular');
 await page.evaluate(()=>__failSound=true);await page.locator('#restSoundInput').setInputFiles({name:'falha.wav',mimeType:'audio/wav',buffer:Buffer.from('invalid-save')});await page.waitForFunction(()=>document.getElementById('toast').textContent.includes('Falha ao guardar'));assert.equal(await page.locator('#restSoundLabel').innerText(),'descanso.wav');await page.evaluate(()=>__failSound=false);
 await timerPicker.click();assert.match(await page.locator('#toast').innerText(),/APK 1.106/,'old APK explains missing native picker');
 await page.evaluate(()=>{window.__toneChoices=[];Android.chooseAlarmRingtone=kind=>{__toneChoices.push(kind);return true}});
 await lesson.click();await timerPicker.click();assert.equal(await page.evaluate(()=>soundPreviewKind),'','opening tone picker stops preview');assert.deepEqual(await page.evaluate(()=>__toneChoices),['timer']);
 await lessonPicker.click();assert.deepEqual(await page.evaluate(()=>__toneChoices),['timer','lesson']);
 await restPicker.click();assert.deepEqual(await page.evaluate(()=>__toneChoices),['timer','lesson','rest']);
 await page.evaluate(()=>{localStorage.setItem('test_rest_sound','Descanso do celular');syncNativeAlarms()});assert.equal(await page.locator('#restSoundLabel').innerText(),'Descanso do celular');assert.equal(await page.locator('#lessonSoundLabel').innerText(),'Padrão do celular');
 await page.evaluate(()=>{localStorage.setItem('test_timer_sound','Brisa do celular');syncNativeAlarms()});assert.match(await page.getByRole('button',{name:/Som do fim da aula/}).innerText(),/Brisa do celular/,'native picker callback refreshes saved name');
 await page.evaluate(()=>{Android.chooseAlarmRingtone=()=>false});await timerPicker.click();assert.match(await page.locator('#toast').innerText(),/Não foi possível abrir/);
 await page.evaluate(()=>{Android.chooseAlarmRingtone=()=>{throw Error('unavailable')}});await lessonPicker.click();assert.match(await page.locator('#toast').innerText(),/Não foi possível abrir/);
 await page.evaluate(()=>{__plays=[]});
 await lesson.click();assert.equal(await lesson.innerText(),'■ Parar');assert.equal(await lesson.getAttribute('aria-pressed'),'true');assert.deepEqual(await page.evaluate(()=>__plays),['lesson']);
 await timer.click();assert.equal(await lesson.innerText(),'▶ Ouvir');assert.equal(await timer.innerText(),'■ Parar');assert.deepEqual(await page.evaluate(()=>__plays),['lesson','timer']);
 await timer.click();assert.equal(await timer.innerText(),'▶ Ouvir');
 await lesson.click();await page.evaluate(()=>__preview={kind:'',error:''});await page.clock.runFor(300);assert.equal(await lesson.innerText(),'▶ Ouvir','completed native playback resets button');
 await timer.click();await page.evaluate(()=>__preview={kind:'',error:'Não foi possível abrir este áudio.'});await page.clock.runFor(300);assert.equal(await timer.innerText(),'▶ Ouvir');assert.match(await page.locator('#toast').innerText(),/Não foi possível abrir/);
 await lesson.click();await page.evaluate(()=>showScreen('today'));assert.equal(await page.evaluate(()=>soundPreviewKind),'');assert.equal(await page.evaluate(()=>__preview.kind),'');await page.evaluate(()=>showScreen('settings'));
 await timer.click();const choice=page.waitForEvent('filechooser');await page.getByRole('button',{name:/Som antes da aula/}).click();await(await choice).setFiles([]);assert.equal(await page.evaluate(()=>soundPreviewKind),'','changing audio stops preview');
 await rest.click();assert.equal(await rest.innerText(),'■ Parar');assert.equal(await page.evaluate(()=>__preview.kind),'rest');await lesson.click();assert.equal(await rest.innerText(),'▶ Ouvir');assert.equal(await page.evaluate(()=>__preview.kind),'lesson');await rest.click();const restAgain=page.waitForEvent('filechooser');await restFile.click();await(await restAgain).setFiles([]);assert.equal(await page.evaluate(()=>__preview.kind),'','rest chooser stops rest preview');
 await page.evaluate(()=>showScreen('more'));await page.locator('#moreLessonSounds').click();assert.equal(await page.evaluate(()=>document.activeElement?.dataset.phoneRingtone),'rest','clock card targets rest sound');
 await page.evaluate(()=>{delete Android.playCustomSound});await lesson.click();assert.match(await page.locator('#toast').innerText(),/APK 1.102/);assert.equal(await lesson.innerText(),'▶ Ouvir');
 for(const mode of ['light','dark']){await page.evaluate(mode=>AgendaAppearance.setMode(mode),mode);for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));for(const button of [rest,lesson,timer,restPicker,lessonPicker,timerPicker]){assert.ok(await button.isVisible());assert.ok((await button.boundingBox()).height>=44)}}}
 await page.reload();await page.evaluate(()=>showScreen('settings'));assert.equal(await page.locator('#restSoundLabel').innerText(),'Descanso do celular','rest choice name survives reload');assert.equal(await page.locator('#timerSoundLabel').innerText(),'Brisa do celular');
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/sound-preview-settings.png'});
 assert.deepEqual(errors,[]);console.log('PASS: three independent sound choices; real rest file chooser/FileReader, failed save rollback, native picker target/callback and name persistence, old APK rest capability guard; three previews without overlap, stop/error/completion, clock card focuses rest, light/dark at 320–480px. Browser real; Android playback/picker simulated.');
 }finally{await browser.close();server.close()}}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
