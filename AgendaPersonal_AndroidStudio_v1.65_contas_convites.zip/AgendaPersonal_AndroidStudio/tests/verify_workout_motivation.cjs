'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const sandbox={};vm.createContext(sandbox);
for(const file of ['workout-motivation.js','student-mascot-model.js'])vm.runInContext(fs.readFileSync(path.resolve(__dirname,'../web/'+file),'utf8'),sandbox);
const M=sandbox.APWorkoutMotivation,P=sandbox.APMascotModel;
const exercise=(id,loads,reps='12',name=id)=>({exerciseId:id,name,reps,targets:loads.map(()=>reps),loads,done:loads.map(()=>true)});
const record=(loads,at=2000,id='p~d')=>({id,startedAt:at,finishedAt:at+100,incomplete:false,exerciseRecords:[exercise('e1',loads)]});
const previous=record([10,12],1000),current=record([12,12]);
assert.equal(Object.values(M.phrases).length,3);
for(const pool of Object.values(M.phrases)){assert.equal(pool.length,25);assert.equal(new Set(pool).size,25);assert.ok(pool.every(s=>s.length>30&&s.length<180))}
assert.equal(new Set(Object.values(M.phrases).flat()).size,75);
const kind=(r,h=[previous])=>M.compare(r,h).kind;
assert.equal(kind(current),'increased');assert.equal(kind(record([10,12])),'maintained');assert.equal(kind(record([8,12])),'decreased');assert.equal(kind(record([12,8])),'mixed');
assert.equal(kind(current,[]),'first');assert.equal(kind(current,[record([0,0],1000,'other')]),'first');
assert.equal(kind(current,[{...previous,incomplete:true}]),'first');assert.equal(kind(current,[{...previous,finishedAt:3000}]),'first');
assert.equal(kind(current,[previous,record([15,15],1500)]),'decreased','most recent complete execution, independent of history order');
assert.equal(kind(record([null,''])),'uncomparable','missing loads never become zero');
assert.equal(kind(record([false,'   '])),'uncomparable');
assert.equal(kind(record([-2,1001])),'uncomparable');
assert.equal(kind(record(['10,0','12.0'])),'maintained');
assert.equal(kind({...current,exerciseRecords:[exercise('e1',[12,12],'8')]}),'uncomparable','rep prescription change is not a comparable task');
assert.equal(kind(record([12])),'uncomparable','changed set count');
assert.equal(kind({...current,exerciseRecords:[exercise('e1',[12,12],'12','Novo exercício')]}),'uncomparable','reused ID after exercise replacement');
assert.equal(kind({...current,exerciseRecords:[exercise('e1',[12,12],'12','Graviton assistido')]},[{...previous,exerciseRecords:[exercise('e1',[10,10],'12','Graviton assistido')]}]),'uncomparable','assistance is not external load');
const old={...previous,exerciseRecords:[exercise('squat',[30]),exercise('curl',[5])]};
const reordered={...current,exerciseRecords:[exercise('curl',[6]),exercise('squat',[30])]};
assert.equal(kind(reordered,[old]),'increased','reordering matches IDs, not exercise positions or sums');
const ambiguous={...previous,exerciseRecords:[exercise(null,[10],'12','Supino'),exercise(null,[20],'12','Supino')]};
assert.equal(kind({...current,exerciseRecords:[exercise(null,[15],'12','Supino')]},[ambiguous]),'uncomparable');
assert.equal(M.prepare({...current,incomplete:true},[previous],{}),null);
assert.equal(M.prepare({...current,exerciseRecords:[{...current.exerciseRecords[0],done:[true,false]}]},[previous],{}),null);
for(const [trend,loads] of [['increased',[15,15]],['maintained',[10,12]],['decreased',[5,5]]]){
 let rotation={},last=-1;const cycles=[new Set(),new Set()];
 for(let i=0;i<50;i++){
  const prepared=M.prepare(record(loads),[previous],rotation,()=>0);assert.equal(prepared.message.kind,trend);
  assert.notEqual(prepared.message.index,last,'no repeat at the cycle boundary');last=prepared.message.index;cycles[Math.floor(i/25)].add(last);
  const pet=P.read({...P.fresh(),messageRotation:prepared.rotation});rotation=JSON.parse(JSON.stringify(pet.messageRotation));
  assert.equal(M.messageFor({mascotMessage:prepared.message}).text,M.phrases[trend][last]);
 }
 assert.equal(cycles[0].size,25);assert.equal(cycles[1].size,25);
}
const frozen=JSON.stringify(previous);M.prepare(current,[previous],{});assert.equal(JSON.stringify(previous),frozen,'history is read-only');
assert.ok(M.messageFor({mascotMessage:{kind:'first'}}).text);assert.equal(M.messageFor({mascotMessage:{kind:'increased',index:100}}),null);
console.log('PASS: 75 unique phrases; all load trends; comparable IDs/sets/reps; reordered and ambiguous exercises; missing/invalid loads; assistance; latest valid history; 25-message cycles without repeats across serialization and pet edits; incomplete records rejected.');
