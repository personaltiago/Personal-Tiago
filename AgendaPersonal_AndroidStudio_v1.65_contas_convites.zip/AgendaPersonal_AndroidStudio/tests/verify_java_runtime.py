"""JDK selection regression checks; no Android compilation is performed."""
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tools'))
import build_android as build


class JavaRuntime(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='agenda-java-')
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.installed = []
        self.default = None
        self.original_glob = Path.glob
        self.addCleanup(patch.stopall)
        patch.object(build.shutil, 'which', side_effect=lambda *a, **kw: self.default).start()
        patch.object(Path, 'home', return_value=self.base/'home').start()
        patch.object(Path, 'glob', new=lambda path, pattern: iter(self.installed) if str(path) == '/usr/lib/jvm' else iter(())).start()

    def jdk(self, version, name=None):
        root = self.base/(name or 'jdk-'+str(version))
        executable = root/'bin/java'
        executable.parent.mkdir(parents=True)
        executable.write_text('#!/bin/sh\nprintf \'openjdk version "'+str(version)+'.0.1"\\n\'\n')
        executable.chmod(0o755)
        self.installed.append(root)
        return root

    def test_01_codespaces_path_and_java_home_25_choose_installed_17(self):
        newer, stable = self.jdk(25), self.jdk(17)
        self.default = str(newer/'bin/java')
        self.assertEqual(build.java_home({'JAVA_HOME':str(newer)}), str(stable))

    def test_02_java_17_preferred_to_explicit_java_21(self):
        stable, alternate = self.jdk(17), self.jdk(21)
        self.assertEqual(build.java_home({'JAVA_HOME':str(alternate)}), str(stable))

    def test_03_java_21_supported_fallback(self):
        newer, compatible = self.jdk(26), self.jdk(21)
        self.assertEqual(build.java_home({'JAVA_HOME':str(newer)}), str(compatible))

    def test_04_java_23_25_26_only_fail_before_gradle(self):
        for major in (23,25,26):
            self.jdk(major)
        with self.assertRaisesRegex(RuntimeError, 'Gradle 8.9.*openjdk-17-jdk'):
            build.java_home({})

    def test_05_sdkman_discovery_and_spaces(self):
        compatible = self.jdk(17, 'jdk 17 with spaces')
        self.installed.clear()
        def glob(path, pattern):
            return iter([compatible]) if path == self.base/'home/.sdkman/candidates/java' else iter(())
        with patch.object(Path, 'glob', new=glob):
            self.assertEqual(build.java_home({}), str(compatible))

    def test_06_broken_java_executable_does_not_hide_working_jdk(self):
        broken, stable = self.jdk(25), self.jdk(17)
        (broken/'bin/java').write_bytes(b'not an executable format')
        self.assertEqual(build.java_home({'JAVA_HOME':str(broken)}), str(stable))

    def test_07_system_actual_java_17(self):
        with patch.object(Path, 'glob', new=self.original_glob), patch.object(build.shutil, 'which', return_value='/usr/bin/java'):
            self.assertTrue((Path(build.java_home({}))/'bin/java').is_file())


if __name__ == '__main__':
    unittest.main()
