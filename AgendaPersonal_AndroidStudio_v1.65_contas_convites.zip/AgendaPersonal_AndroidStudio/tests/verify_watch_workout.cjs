'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const {chromium}=require('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const file=path.join(assets,new URL(req.url,'http://localhost').pathname);if(!file.startsWith(assets+'/')||!fs.existsSync(file)){res.writeHead(404);return res.end();}res.setHeader('Content-Type',file.endsWith('.html')?'text/html;charset=utf-8':'application/octet-stream');res.end(fs.readFileSync(file));});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});try{
 const ctx=await browser.newContext({viewport:{width:360,height:780}});
 await ctx.addInitScript(()=>{
  window.__sent=[];window.Android={sendWatchWorkout(raw){window.__sent.push(JSON.parse(raw));return JSON.stringify({ok:true,message:'Teste enviado'});},getWatchStatus(){return JSON.stringify({message:'Recebido',results:[{role:'student',person:'Aluno',label:'A',completed:4,total:4,durationMs:60000,finishedAt:Date.now()}]});}};
  window.APaccounts={isTeacher:()=>true,context:()=>window.__AP_STUDENT_CONTEXT};
  localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[{id:'s1',name:'Aluno teste',studentType:'presencial'}],workoutPlans:[{id:'p1',studentId:'s1',name:'Ficha',startDate:'2026-01-01',visibility:'always',days:[{id:'d1',name:'Treino A',exercises:[{id:'e1',name:'Agachamento',sets:'2',reps:'12',load:'20',rest:'60'},{id:'e2',name:'Remada',sets:'2',reps:'10',load:'18',rest:'45'}]}]}]}));
 });
 const page=await ctx.newPage();let confirmations=0;page.on('dialog',d=>{confirmations++;return d.accept()});await page.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await page.waitForFunction(()=>typeof APsendTeacherWatchWorkout==='function');
 await page.evaluate(()=>{workoutStudentId='s1';workoutPlanId='p1';workoutDayId='d1';showScreen('workouts');openWorkoutStudent('s1');selectWorkoutPlan('p1');openWorkoutDay('d1');window.__watchMessages=[];toast=message=>__watchMessages.push(message);});
 await page.locator('#workoutDayContent .ap-watch-send-icon').click();
 assert.equal(await page.evaluate(()=>__sent.length),1,JSON.stringify(await page.evaluate(()=>window.__watchMessages)));assert.equal(await page.evaluate(()=>__sent[0].role),'teacher');assert.equal(await page.evaluate(()=>__sent[0].steps.length),4);
 assert.equal(await page.locator('#workoutDayContent .ap-watch-send-icon').count(),1);assert.equal(await page.locator('#workoutDayContent .ap-watch-actions').count(),0);assert.equal(confirmations,0,'one tap sends without a confirmation dialog');
 await page.screenshot({path:'/tmp/agenda-watch-teacher-icon.png'});
 await page.evaluate(()=>{window.APaccounts.isTeacher=()=>false});await page.locator('#workoutDayContent .ap-watch-send-icon').click();assert.equal(await page.evaluate(()=>__sent.length),1,'unauthenticated teacher is blocked');await page.evaluate(()=>{window.APaccounts.isTeacher=()=>true});
 const old=await page.evaluate(()=>JSON.stringify(state.workoutExecutions));await page.evaluate(()=>APWatchUI.results('teacher'));assert.equal(await page.locator('.ap-watch-dialog').count(),1);await page.evaluate(()=>APWatchUI.close());assert.equal(await page.evaluate(()=>JSON.stringify(state.workoutExecutions)),old);
 // A read-only teacher preview cannot send a student session.
 await page.goto('http://127.0.0.1:'+server.address().port+'/index.html');await page.waitForFunction(()=>window.APstudentUI&&window.APWatchUI);
 await page.evaluate(()=>{const area={version:2,enabled:true,professorId:APStudentModel.TEACHER,studentId:'s1',studentUid:'student1',profile:{name:'Aluno',gender:'Masculino'},plans:[{id:'p1',name:'Ficha',organization:'sequence',days:[{id:'d1',name:'A',exercises:[{id:'e1',name:'Agachamento',rows:[{reps:'12',load:20,rest:60},{reps:'10',load:22,rest:45}]}]}]}]};window.__AP_STUDENT_CONTEXT={role:'student',storageId:'student1',profile:{name:'Aluno',gender:'Masculino'},area};APstudentUI.activate();openExerciseHub(APStudentModel.workouts(area)[0].id);});
 await page.locator('#exerciseScreen .ap-watch-send-icon').click();assert.equal(await page.evaluate(()=>__sent.length),1);assert.equal(await page.evaluate(()=>__sent[0].role),'student');assert.equal(await page.evaluate(()=>__sent[0].exercises[0].rows[1].load),'22');
 assert.equal(confirmations,0);assert.equal(await page.locator('#exListView .ap-watch-actions').count(),0);
 await page.evaluate(()=>{renderExerciseApp();renderExerciseApp()});assert.equal(await page.locator('#exerciseScreen .ap-watch-send-icon').count(),1,'rerenders keep one icon');
 for(const width of [280,360,430]){await page.setViewportSize({width,height:780});const box=await page.locator('#exerciseScreen .ap-watch-send-icon').boundingBox();assert.ok(box&&box.width===44&&box.height===44&&box.x>=0&&box.x+box.width<=width,'compact accessible icon fits '+width);}
 await page.setViewportSize({width:360,height:780});await page.screenshot({path:'/tmp/agenda-watch-student-icon.png'});
 await page.evaluate(()=>APWatchUI.results('student'));await page.waitForSelector('.ap-watch-dialog article');assert.match(await page.locator('.ap-watch-dialog article').innerText(),/4\/4 séries/);await page.evaluate(()=>APWatchUI.close());
 await page.evaluate(()=>{__AP_STUDENT_CONTEXT.role='preview';renderExerciseApp();});assert.equal(await page.locator('#exerciseScreen .ap-watch-send-icon').count(),0);
 await page.screenshot({path:process.env.AGENDA_WATCH_SCREENSHOT||'/tmp/agenda-watch-student.png'});
 console.log('Watch browser: compact icons, one-tap teacher/student transfers, responsive sizing, authentication/preview guards, per-set prescription and separate summaries passed.');await ctx.close();
}finally{await browser.close();server.close();}})().catch(e=>{console.error(e);server.close();process.exitCode=1});
