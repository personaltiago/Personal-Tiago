'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const {chromium}=require('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets'),sources=path.resolve(__dirname,'../web/mascot-images');
const manifest=JSON.parse(fs.readFileSync(path.join(sources,'manifest.json'))),html=fs.readFileSync(path.join(assets,'cadastro.html'),'utf8'),map=JSON.parse(html.match(/<script type="application\/json" id="ap-mascot-image-assets">([\s\S]*?)<\/script>/)[1]);
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
for(const [species,phases]of Object.entries(manifest))for(const [phase,item]of Object.entries(phases)){const bytes=Buffer.from(map[species][phase].split(',')[1],'base64');assert.equal(hash(bytes),item.sha256,'approved bytes: '+species+'/'+phase);assert.deepEqual(bytes,fs.readFileSync(path.join(sources,item.file)))}
assert.equal(manifest.wolf.baby.originalSha256,'d041f52ff554e3311880a419830eed07ce8e2d2d6a2d910529693f101d35534c');
assert.equal(manifest.capybara.baby.originalSha256,'cda8260ee1b39ba7fe846449d5689de717d93af179c6efbc1b6ef9855109d161');
let failImages=true;
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';if(!['index.html','professor.html','cadastro.html','avaliacoes.html'].includes(name)){res.writeHead(404);return res.end()}if(name==='cadastro.html'&&failImages){res.writeHead(503);return res.end('offline fixture')}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>!!window.APmascot);
  await page.evaluate(()=>{const student={id:'a',firebaseUid:'a',name:'Pessoa de teste',gender:'Feminino'},area=APStudentModel.makeArea({students:[student],workoutPlans:[]},student);window.__AP_STUDENT_CONTEXT={storageId:'raster-test',role:'student',area,profile:area.profile};APstudentUI.activate();route('home');APmascot.open()});
  await page.waitForFunction(()=>APMascotArt.error());assert.equal(await page.locator('#apMascotImageError').isVisible(),true);assert.equal(await page.evaluate(()=>APmascot.state().coins),0);
  failImages=false;await page.locator('#apMascot [data-mascot-retry]').click();await page.waitForFunction(()=>APMascotArt.ready());assert.equal(await page.locator('#apMascotImageError').isVisible(),false);assert.equal(await page.locator('#apMascotChoices image[data-mascot-photo]').count(),6);
  for(const [species,phases]of Object.entries(manifest))for(const [xp,phase]of [[0,'baby'],[599,'baby'],[600,'teen'],[1799,'teen'],[1800,'adult']]){
   const before=await page.evaluate(({species,xp})=>{const store=exStore();store.mascot={...APmascot.state(),species,xp,name:'Companheiro',coins:321,inventory:['shirt'],equipped:{body:'shirt'}};exSave(store);const before=APmascot.state();APmascot.open();APmascot.refreshHome();return before},{species,xp});
   const uri=await page.locator('#apMascotArt image').getAttribute('href');const natural=JSON.parse(fs.readFileSync(path.join(__dirname,'../web/mascot-coats/manifest.json'),'utf8')),expectedAsset=species==='alligator'?natural.alligator.variants['0'][phase]:phases[phase];assert.equal(hash(Buffer.from(uri.split(',')[1],'base64')),expectedAsset.sha256,species+'/'+phase);
   assert.deepEqual(await page.evaluate(async uri=>{const i=new Image();i.src=uri;await i.decode();return [i.naturalWidth,i.naturalHeight]},uri),[expectedAsset.width,expectedAsset.height]);
   assert.equal(await page.locator('#apMascotArt svg').getAttribute('data-mascot-style'),'3d-reference');assert.equal(await page.locator('#apMascotArt svg').getAttribute('data-mascot-phase'),phase);assert.equal(await page.locator('#apMascotArt image').getAttribute('data-mascot-photo-phase'),phase);assert.equal(await page.locator('#apMascotArt image').getAttribute('preserveAspectRatio'),'xMidYMid meet');
   for(const selector of ['#apMascotArt','#apMascotHome .ap-mascot-mini']){
    const geometry=await page.locator(selector).evaluate(n=>{const svg=n.querySelector('svg').getBoundingClientRect(),image=n.querySelector('image').getBoundingClientRect();return {width:image.width/svg.width,height:image.height/svg.height,bottom:image.bottom-svg.bottom}}),expected={baby:.7,teen:.85,adult:1}[phase];
    assert.ok(Math.abs(geometry.width-expected)<.001&&Math.abs(geometry.height-expected)<.001,species+'/'+phase+' has the correct visible size in '+selector);
    assert.ok(Math.abs(geometry.bottom)<.1,'growth keeps feet at the same ground baseline');
   }
   assert.deepEqual(await page.evaluate(()=>APmascot.state()),before,'rendering preserves XP/name/balance/inventory');
   if(process.env.AGENDA_REVIEW_DIR&&[0,600,1800].includes(xp)){fs.mkdirSync(process.env.AGENDA_REVIEW_DIR,{recursive:true});await page.locator('.ap-mascot-sheet').evaluate(n=>n.scrollTop=0);await page.screenshot({path:path.join(process.env.AGENDA_REVIEW_DIR,'portrait-'+species+'-'+phase+'.png')})}
  }
  assert.equal(await page.locator('#apMascotArt path').count(),0,'no vector animal or pasted flat clothes replace the approved portrait');assert.deepEqual(errors,[]);console.log('PASS: exact classic portrait bytes plus new natural green alligator at 384px, real 70/85/100% geometry in student home and pet view; thresholds 599/600/1799/1800; preserved baby wolf/capybara; XP/name/coins/inventory unchanged; no external requests; real image decode; uncut contain fit; failed local-asset load + retry; unchanged balance; no previous vector drawings or flat clothing overlays. Browser native/auth services simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
