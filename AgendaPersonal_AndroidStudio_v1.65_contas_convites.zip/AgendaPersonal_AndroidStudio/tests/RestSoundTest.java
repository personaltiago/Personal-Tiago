package com.tiagolima.agendapersonal;

import android.app.Notification;
import android.content.Intent;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;

/** Production settings/scheduler/receiver integration; Android services are fakes. */
public final class RestSoundTest {
    private static int checks;
    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) throws Exception {
        MainActivity c = NativeAlarmHarness.context();
        MainActivity.Bridge bridge = new MainActivity.Bridge(c);
        JSONObject snapshot = NativeAlarmHarness.agenda().put("workoutStudents",
                new JSONArray().put(new JSONObject().put("id", "r").put("name", "Aluno")));
        AlarmScheduler.synchronize(c, snapshot);
        AudioSettings.saveBase64(c, "lesson", "antes.wav", "audio/wav", "AQID");
        AudioSettings.saveBase64(c, "timer", "fim.wav", "audio/wav", "BAUG");
        AlarmReceiver.createChannel(c);
        String lessonChannel = AudioSettings.lessonChannelId(c), timerChannel = AudioSettings.timerChannelId(c);
        String lessonUri = AudioSettings.lessonSound(c).toString(), timerUri = AudioSettings.timerSound(c).toString();
        String defaultRest = AudioSettings.restChannelId(c);
        JSONObject saved = new JSONObject(bridge.saveCustomSound("rest", "descanso.wav", "audio/wav", "BwgJ"));
        check(saved.optString("error").isEmpty() && saved.optString("restName").equals("descanso.wav"), "bridge saves rest audio");
        check(saved.optBoolean("restSupported"), "new APK capability reported");
        check(saved.optString("lessonName").equals("antes.wav") && saved.optString("timerName").equals("fim.wav"), "other names preserved");
        check(!AudioSettings.restChannelId(c).equals(defaultRest), "custom rest channel independent from default");
        AlarmReceiver.createChannel(c);
        check(c.notifications.getNotificationChannel(AudioSettings.restChannelId(c)).getSound().toString().equals(AudioSettings.restSound(c).toString()), "rest channel uses saved file");
        check(c.notifications.getNotificationChannel(AudioSettings.restChannelId(c)).attributes.usage == android.media.AudioAttributes.USAGE_ALARM, "rest uses alarm volume stream");
        check(AudioSettings.lessonChannelId(c).equals(lessonChannel) && AudioSettings.timerChannelId(c).equals(timerChannel), "other channel IDs preserved");
        JSONObject status = new JSONObject(bridge.getAlarmStatus());
        check(status.optString("restSoundName").equals("descanso.wav") && status.optBoolean("restReady"), "rest status ready with saved title");
        JSONObject request = new JSONObject().put("studentId", "r").put("id", "rest-one")
                .put("exercise", "Agachamento").put("triggerAtMillis", System.currentTimeMillis() + 60000);
        check(bridge.startWorkoutRest(request.toString()), "real rest alarm arms with custom file");
        long deadline = AlarmStore.plan(c, AlarmScheduler.WORKOUT_REST_KEY).getLong("triggerAtMillis");
        Intent pending = NativeAlarmHarness.intent(c, AlarmScheduler.WORKOUT_REST_KEY);
        AudioSettings.saveRingtone(c, "rest", Uri.parse("content://tones/rest-two"), "Segundo toque");
        AlarmReceiver.createChannel(c);
        check(AlarmStore.plan(c, AlarmScheduler.WORKOUT_REST_KEY).getLong("triggerAtMillis") == deadline, "changing rest tone keeps countdown deadline");
        NativeAlarmHarness.fire(c, pending);
        Notification delivered = c.notifications.active.get(AlarmScheduler.WORKOUT_REST_KEY);
        check(delivered != null && delivered.channelId.equals(AudioSettings.restChannelId(c)), "rest receiver selects current custom channel");
        check(c.notifications.getNotificationChannel(delivered.channelId).getSound().toString().equals("content://tones/rest-two"), "actual delivered notification points to chosen ringtone");
        check(delivered.timeout == 30000 && (delivered.flags & Notification.FLAG_INSISTENT) == 0, "rest remains a short interval alert");
        check(AlarmStore.plan(c, AlarmScheduler.WORKOUT_REST_KEY) == null, "successful rest delivery completes pending plan");
        int publications = c.notifications.published;
        NativeAlarmHarness.fire(c, pending);
        check(c.notifications.published == publications, "completed interval does not play twice");
        check(bridge.cancelWorkoutRest() && c.notifications.active.isEmpty(), "stop removes rest notification");
        c.notifications.getNotificationChannel(lessonChannel).sound = null;
        c.notifications.getNotificationChannel(timerChannel).sound = null;
        status = AlarmStatus.inspect(c);
        check(!status.optBoolean("ready") && !status.optBoolean("timerReady") && status.optBoolean("restReady"), "muted class channels do not block rest");
        request.put("id", "rest-two").put("triggerAtMillis", System.currentTimeMillis() + 75000);
        check(bridge.startWorkoutRest(request.toString()), "rest still arms with both class sounds muted");
        pending = NativeAlarmHarness.intent(c, AlarmScheduler.WORKOUT_REST_KEY);
        c.notifications.getNotificationChannel(AudioSettings.restChannelId(c)).sound = null;
        check(AlarmStatus.inspect(c).optString("restIssue").contains("Descanso do treino"), "silent rest diagnostic names correct sound");
        check(!bridge.startWorkoutRest(request.toString()), "silent rest channel is not presented as armed");
        NativeAlarmHarness.fire(c, pending);
        check(c.notifications.published == publications && AlarmStore.plan(c, AlarmScheduler.WORKOUT_REST_KEY) != null, "silenced after start does not fake audible delivery");
        AudioSettings.saveRingtone(c, "rest", Uri.parse("content://tones/rest-three"), "Terceiro toque");
        AlarmReceiver.createChannel(c);
        NativeAlarmHarness.fire(c, pending);
        check(c.notifications.published == publications + 1, "rest can deliver after changing to an audible tone");
        String restUri = AudioSettings.restSound(c).toString();
        c.prefs.failPrefix = "rest_";
        JSONObject rejected = new JSONObject(bridge.saveCustomSound("rest", "falha.wav", "audio/wav", "AQID"));
        check(!rejected.optString("error").isEmpty() && AudioSettings.restSound(c).toString().equals(restUri), "failed file save keeps rest selection");
        c.prefs.failPrefix = "";
        check(!new JSONObject(bridge.saveCustomSound("rest", "vazio.wav", "audio/wav", "")).optString("error").isEmpty(), "empty rest audio rejected");
        AlarmScheduler.restore(c);
        check(AudioSettings.restSound(c).toString().equals(restUri), "alarm restore preserves chosen rest sound");
        check(AudioSettings.lessonSound(c).toString().equals(lessonUri) && AudioSettings.timerSound(c).toString().equals(timerUri), "all rest operations preserve both class selections");
        request.put("id", "cancelled").put("triggerAtMillis", System.currentTimeMillis() + 60000);
        check(bridge.startWorkoutRest(request.toString()), "new interval arms after previous completion");
        pending = NativeAlarmHarness.intent(c, AlarmScheduler.WORKOUT_REST_KEY);
        check(bridge.cancelWorkoutRest(), "rest cancels normally with custom sound");
        publications = c.notifications.published;
        NativeAlarmHarness.fire(c, pending);
        check(c.notifications.published == publications, "cancelled custom rest never delivers");
        System.out.println(checks + " custom rest sound checks passed (production scheduler/receiver/settings; Android simulated).");
    }
}
