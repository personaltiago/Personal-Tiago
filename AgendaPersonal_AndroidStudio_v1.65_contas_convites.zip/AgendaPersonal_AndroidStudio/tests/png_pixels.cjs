'use strict';
// Decode the RGB/RGBA, non-interlaced 8-bit PNG screenshots produced by Chromium.
// This keeps visual regressions runnable with the existing Node dependencies.
const assert=require('node:assert/strict'),zlib=require('node:zlib');
module.exports=function decodePNG(png){
 assert.equal(png.subarray(0,8).toString('hex'),'89504e470d0a1a0a');let width,height,channels;const chunks=[];
 for(let offset=8;offset<png.length;){const length=png.readUInt32BE(offset),type=png.toString('ascii',offset+4,offset+8),bytes=png.subarray(offset+8,offset+8+length);if(type==='IHDR'){width=bytes.readUInt32BE(0);height=bytes.readUInt32BE(4);assert.equal(bytes[8],8);assert.ok([2,6].includes(bytes[9]));channels=bytes[9]===6?4:3;assert.equal(bytes[12],0)}else if(type==='IDAT')chunks.push(bytes);offset+=length+12;if(type==='IEND')break}
 const packed=zlib.inflateSync(Buffer.concat(chunks)),stride=width*channels,raw=Buffer.alloc(height*stride);assert.equal(packed.length,height*(stride+1));
 const paeth=(a,b,c)=>{const p=a+b-c,da=Math.abs(p-a),db=Math.abs(p-b),dc=Math.abs(p-c);return da<=db&&da<=dc?a:db<=dc?b:c};
 for(let y=0;y<height;y++){const filter=packed[y*(stride+1)];assert.ok(filter<=4);for(let x=0;x<stride;x++){const a=x>=channels?raw[y*stride+x-channels]:0,b=y?raw[(y-1)*stride+x]:0,c=y&&x>=channels?raw[(y-1)*stride+x-channels]:0,predict=filter===0?0:filter===1?a:filter===2?b:filter===3?Math.floor((a+b)/2):paeth(a,b,c);raw[y*stride+x]=(packed[y*(stride+1)+1+x]+predict)&255}}
 if(channels===4)return{data:raw,info:{width,height}};const data=Buffer.alloc(width*height*4);for(let i=0;i<width*height;i++){data[i*4]=raw[i*3];data[i*4+1]=raw[i*3+1];data[i*4+2]=raw[i*3+2];data[i*4+3]=255}return{data,info:{width,height}};
};
