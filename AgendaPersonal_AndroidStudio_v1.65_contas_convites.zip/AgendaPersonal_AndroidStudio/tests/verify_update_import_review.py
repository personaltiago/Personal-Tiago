"""Exercise the production importer and its real dialog callbacks with Android API fakes.

Checks file and storage side effects, cancellation, account changes and late replies.
This compiles the real Java importer; it is not a device test or a signed APK build.
"""
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import hashlib
import json
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
PACKAGE = 'com/tiagolima/agendapersonal/'
HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.AlertDialog;import android.net.Uri;import android.webkit.WebView;
import java.nio.file.*;import java.lang.reflect.*;import java.util.Arrays;import org.json.JSONArray;import org.json.JSONObject;
public final class UpdateReviewHarness {
static final String TEACHER="R2EmnDVcvMWt7TjPxOP6DjW1VOn1";
static int checks;
static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
static Object field(Object o,String name)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
static void set(Object o,String name,Object v)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);f.set(o,v);}
static JSONObject release(int seq,String version,Object notes,String marker){String html="<!doctype html><html><head></head><body>"+marker+" agendaPersonalTL_v1 syncNativeAlarms<script data-agenda-ready></script></body></html>";JSONObject value=new JSONObject().put("format",1).put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4).put("version",version).put("sequence",seq).put("files",new JSONObject().put("index.html",html).put("avaliacoes.html",html));if(notes!=null)value.put("notes",notes);return value;}
static void waitFor(UpdateManager m,boolean wantReview)throws Exception{long until=System.currentTimeMillis()+5000;while(System.currentTimeMillis()<until){AlertDialog d=(AlertDialog)field(m,"reviewDialog");if(wantReview&&d!=null&&d.isShowing()&&d.getButton(AlertDialog.BUTTON_POSITIVE).listener!=null)return;if(!wantReview&&!Boolean.TRUE.equals(field(m,"busy")))return;Thread.sleep(5);}throw new AssertionError("Operação não terminou: review="+wantReview+"; "+android.widget.Toast.shown);}
static AlertDialog select(UpdateManager m,Path file,JSONObject value)throws Exception{Files.writeString(file,value.toString());m.importUri(Uri.parse(file.toUri().toString()));waitFor(m,true);return(AlertDialog)field(m,"reviewDialog");}
static void click(AlertDialog dialog,int which){android.widget.Button b=dialog.getButton(which);if(b.listener!=null)b.listener.click(b);}
static void unchanged(Path folder,byte[] original,MainActivity a,WebView view,int loads)throws Exception{
 check(Arrays.equals(original,Files.readAllBytes(folder.resolve("updates/active.json"))),"A revisão/cancelamento alterou a versão instalada");
 check(!Files.exists(folder.resolve("updates/data-before-update.json")),"Dados copiados antes de confirmar");
 check(!Files.exists(folder.resolve("updates/previous.json")),"Histórico alterado antes de confirmar");
 check(!a.prefs.getBoolean("pending",false),"Instalação iniciada sem confirmação");
 check(view.loads==loads,"A página recarregou antes de confirmar");
}
static String hash(String text)throws Exception{return UpdateStorage.sha256(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
static void scoped(Path project,String[] args,boolean v2)throws Exception{
 Path folder=Files.createTempDirectory("agenda-area-"),file=folder.resolve("selected.json"),updates=folder.resolve("updates");
 Files.createDirectories(updates);
 String id=v2?"ap-capybara-face-reaction-assets":"ap-mascot-gesture-runtime",tag="<script type='application/json' id='"+id+"'>";
 String old="original",replacement="corrigido";
 JSONObject installed=release(343,"1.12.237","Versão instalada.","installed");
 installed.getJSONObject("files").put("professor.html",installed.getJSONObject("files").getString("index.html"))
  .put("cadastro.html","<html><head></head><body><!-- "+tag+"ignore</script> -->"+tag+old+"</script></body></html>");
 JSONObject entry=new JSONObject().put("page","cadastro.html").put("id",id).put("before",hash(old)).put("after",hash(replacement)).put("content",replacement);
 JSONObject patch=new JSONObject().put("format","agenda-patch/1").put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4)
  .put("id","urso-teste").put("area","pets").put("version","rótulo A").put("title","Rosto da capivara").put("notes","Ajusta o olhar.").put("changes",new JSONArray().put(entry));
 JSONObject expected=args.length==4?new JSONObject(Files.readString(Path.of(args[3]))):null;
 byte[] initial=args.length==4?Files.readAllBytes(Path.of(args[1])):installed.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
 if(expected!=null)patch=new JSONObject(Files.readString(Path.of(args[2])));
 if(v2)patch.put("format","agenda-patch/2").put("module","capivara");
 String section=v2&&expected==null?"Capivara":"Geral";
 Files.write(updates.resolve("active.json"),initial);
 MainActivity activity=new MainActivity(folder.toFile(),project.resolve("app/src/main/assets"));WebView view=new WebView();
 UpdateManager manager=new UpdateManager(activity,view);view.reader=manager::localResponse;
 try{
  installed=(JSONObject)field(manager,"active");check(installed!=null,"Base instalada não abriu");
  manager.setUpdateAccount(TEACHER);manager.openPage(Uri.parse(LocalPages.HOME));view.awaitLoads(1);
  view.ready=true;manager.pageReady();
  check(view.html.contains("event.target?.id!=='apModFile'")&&view.html.contains("modal.close();Android.openUpdateAction('import')"),"Seleção por área não usa o importador direto");
  manager.requestImport();check(activity.filePickers==1&&activity.lastRequest==UpdateManager.IMPORT_REQUEST,"Seletor inicial ausente");
  JSONObject rejected=new JSONObject(patch.toString()).put("testInvalidSignature",true);
  Files.writeString(file,rejected.toString());manager.importUri(Uri.parse(file.toUri().toString()));waitFor(manager,false);
  check(android.widget.Toast.shown.stream().anyMatch(s->s.contains("assinatura válida")),"Assinatura inválida não bloqueou a correção");
  unchanged(folder,initial,activity,view,1);
  AlertDialog review=select(manager,file,patch);
  check(review.title.equals("Revisar atualização")&&review.message.contains("Seção: Pets · "+section),"Seção de Pets não identificada");
  check(review.getButton(AlertDialog.BUTTON_POSITIVE).text.equals("Instalar"),"Botão Instalar ausente");
  unchanged(folder,initial,activity,view,1);
  click(review,AlertDialog.BUTTON_POSITIVE);view.awaitLoads(2);
  check(activity.filePickers==1,"O instalador abriu outro seletor");
  view.ready=true;manager.pageReady();waitFor(manager,false);
  JSONObject saved=(JSONObject)field(manager,"active");
  check(saved.getInt("sequence")==344&&saved.getString("version").equals("1.12.238"),"Sequência da instalação incorreta");
  for(String name:new String[]{"index.html","professor.html","avaliacoes.html"})
   check(saved.getJSONObject("files").getString(name).equals(installed.getJSONObject("files").getString(name)),"Página fora da área mudou");
  if(expected!=null){
   check(hash(saved.getJSONObject("files").getString("cadastro.html")).equals(expected.getString("cadastroSha256")),"O patch real diverge da montagem do app");
   boolean legacySignature=saved.getJSONArray("modularUpdates").getJSONObject(0).getString("signature").equals(expected.getJSONArray("modularUpdates").getJSONObject(0).getString("signature"));
   check(legacySignature!=v2,"O identificador do arquivo V1 mudou ou o V2 não incluiu o módulo");
  } else check(saved.getJSONObject("files").getString("cadastro.html").contains(tag+replacement+"</script>"),"Componente não aplicado");
  check(Arrays.equals(initial,Files.readAllBytes(updates.resolve("previous.json"))),"Cópia anterior do patch alterada");
  manager.importUri(Uri.parse(file.toUri().toString()));waitFor(manager,false);
  check(field(manager,"reviewDialog")==null&&view.loads==2,"Patch duplicado foi oferecido novamente");
  JSONObject record=new JSONArray(manager.managedUpdates()).getJSONObject(0);
  check(record.optBoolean("downloadable")&&record.optBoolean("reversible"),"Cópia individual ou reversão não foi guardada");
  check(record.optString("module").equals(section.toLowerCase(java.util.Locale.ROOT)),"O histórico não registra a seção validada");
  check(!record.has("undo"),"A reversão foi incluída no pacote principal");
  String patchId=record.getString("id"), signature=record.getString("signature");
  Method resolve=UpdateManager.class.getDeclaredMethod("downloadSource",String.class);resolve.setAccessible(true);
  UpdateDownloads.Source source=(UpdateDownloads.Source)resolve.invoke(manager,record.getString("downloadId"));
  Path exported=folder.resolve("individual.agenda.json");
  source.write.write(exported.toFile(),()->true);
  check(new JSONObject(Files.readString(exported)).toString().equals(patch.toString()),"Download não entregou o arquivo individual");
  manager.removeManagedUpdate(patchId,signature);waitFor(manager,true);
  AlertDialog removal=(AlertDialog)field(manager,"reviewDialog");
  check(removal.title.equals("Desinstalar atualização"),"Revisão de desinstalação ausente");
  click(removal,AlertDialog.BUTTON_NEGATIVE);waitFor(manager,false);
  check(field(manager,"active")==saved,"Cancelamento reverteu a atualização");
  manager.removeManagedUpdate(patchId,signature);waitFor(manager,true);
  click((AlertDialog)field(manager,"reviewDialog"),AlertDialog.BUTTON_POSITIVE);view.awaitLoads(3);
  manager.pageReady();waitFor(manager,false);
  JSONObject after=(JSONObject)field(manager,"active");
  for (String page:new String[]{"index.html","professor.html","avaliacoes.html","cadastro.html"})
   check(after.getJSONObject("files").getString(page).equals(installed.getJSONObject("files").getString(page)),"A reversão alterou a página "+page);
  record=new JSONArray(manager.managedUpdates()).getJSONObject(0);
  check(record.optBoolean("removed")&&record.optBoolean("downloadable")&&!record.optBoolean("reversible"),"O download desapareceu após desinstalar");
  check(activity.filePickers==1,"Desinstalação abriu um seletor de arquivos");
  review=select(manager,file,patch);
  click(review,AlertDialog.BUTTON_POSITIVE);view.awaitLoads(4);
  manager.pageReady();waitFor(manager,false);
  check(new JSONArray(manager.managedUpdates()).getJSONObject(0).optBoolean("reversible"),"Correção baixada não pôde ser reinstalada");
 }finally{manager.destroy();}
}
static JSONObject petChange(String id,String before,String after)throws Exception{
 return new JSONObject().put("page","cadastro.html").put("id",id).put("before",hash(before)).put("after",hash(after)).put("content",after);
}
static JSONObject petPatch(String id,String module,JSONObject... changes){
 JSONArray list=new JSONArray();
 for(JSONObject change:changes)list.put(change);
 return new JSONObject().put("format","agenda-patch/2").put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4)
  .put("area","pets").put("id",id).put("module",module).put("title","Ajuste de rosto").put("version","1").put("notes","Ajusta o olhar.").put("changes",list);
}
static void moduleRules()throws Exception{
 String app="com.tiagolima.agendapersonal";
 String bear="ap-capybara-face-reaction-assets",cat="ap-kitten-face-assets",shared="ap-mascot-gesture-runtime";
 JSONObject base=release(343,"1.12.237","Base.","teste");
 base.getJSONObject("files").put("professor.html",base.getJSONObject("files").getString("index.html"))
  .put("cadastro.html","<html><body><script id=\""+bear+"\">urso antigo</script><script id=\""+cat+"\">gato antigo</script><script id=\""+shared+"\">gestos antigos</script></body></html>");
 JSONObject bearChange=petChange(bear,"urso antigo","urso novo");
 JSONObject catChange=petChange(cat,"gato antigo","gato novo");
 JSONObject sharedChange=petChange(shared,"gestos antigos","gestos novos");
 JSONObject bearPatch=petPatch("urso-rosto","capivara",bearChange);
 JSONObject installedBear=UpdateAreaPatch.apply(base,bearPatch,app,100000);
 JSONObject withCat=UpdateAreaPatch.apply(installedBear,petPatch("gato-rosto","gato",catChange),app,100000);
 JSONArray records=withCat.getJSONArray("modularUpdates");
 check(records.getJSONObject(0).optString("module").equals("gato")&&records.getJSONObject(1).optString("module").equals("capivara"),"A identificação de uma correção afetou a outra");
 JSONObject withoutBear=UpdateAreaPatch.remove(withCat,records.getJSONObject(1),UpdateAreaPatch.inverse(base,bearPatch),app,100000);
 String html=withoutBear.getJSONObject("files").getString("cadastro.html");
 check(html.contains("urso antigo")&&html.contains("gato novo"),"A reversão do Urso alterou o Gato");
 JSONObject newer=UpdateAreaPatch.apply(withCat,petPatch("urso-mais-recente","capivara",petChange(bear,"urso novo","urso mais recente")),app,100000);
 try {
  UpdateAreaPatch.remove(newer,newer.getJSONArray("modularUpdates").getJSONObject(2),UpdateAreaPatch.inverse(base,bearPatch),app,100000);
  throw new AssertionError("Desinstalação sobrescreveu correção posterior");
 } catch (UpdateAreaPatch.Invalid expected) {check(expected.getMessage().contains("Outra atualização"),"Conflito de desinstalação sem indicação");}
 JSONObject sharedResult=UpdateAreaPatch.apply(base,petPatch("urso-gestos","capivara",bearChange,sharedChange),app,100000);
 check(sharedResult.getJSONObject("update").optString("module").equals("geral"),"Componente compartilhado rotulado como exclusivo");
 for(String invalid:new String[]{"gato","inexistente",""}){
  try {
   UpdateAreaPatch.apply(base,petPatch("urso-modulo",invalid,bearChange),app,100000);
   throw new AssertionError("Manifesto inválido aceito: "+invalid);
  } catch (UpdateAreaPatch.Invalid expected) {check(!expected.getMessage().isEmpty(),"Erro de manifesto sem descrição");}
 }
}
static void areaModules()throws Exception{
 String app="com.tiagolima.agendapersonal";
 JSONObject catalog=new JSONObject(UpdateAreaPatch.sectionCatalog());
 String[][] cases={
  {"alunos","cronometro","index.html","ap-cardio-student","Aluno"},
  {"professor","exercicios","professor.html","ap-workout-timed-series","Professor"},
  {"relogio","sincronizacao","professor.html","ap-watch-teacher","Relógio"},
  {"sons","descanso","professor.html","ap-rest-floating","Sons e temporizadores"},
  {"evolucao","sincronizacao","cadastro.html","ap-progress-sync-source","Evolução"},
  {"avaliacoes","pdf","avaliacoes.html","pdf-page-layout-source","Avaliações"},
  {"agenda","espera","professor.html","ap-waitlist","Agenda"},
  {"cadastro","fotos","cadastro.html","ap-registration-photo-js","Cadastro"},
  {"pagamentos","recibos","professor.html","ap-pix-receipt","Pagamentos"},
 };
 check(catalog.length()==10,"Nem todas as áreas têm subseções");
 check(catalog.getJSONArray("alunos").toString().contains("[\"descanso\",\"Descanso\",\"cronometro\"]"),"Descanso não está dentro de Cronômetro");
 for(String[] item:cases){
  String area=item[0],module=item[1],page=item[2],component=item[3];
  JSONObject base=release(343,"1.12.237","Base.","teste");
  JSONObject files=base.getJSONObject("files");
  files.put("professor.html",files.getString("index.html")).put("cadastro.html",files.getString("index.html"));
  files.put(page,files.getString(page).replace("</body>","<script id=\""+component+"\">antigo</script></body>"));
  JSONObject change=petChange(component,"antigo","novo").put("page",page);
  JSONObject patch=petPatch("teste-"+area,module,change).put("area",area);
  JSONObject installed=UpdateAreaPatch.apply(base,patch,app,100000);
  JSONObject record=installed.getJSONArray("modularUpdates").getJSONObject(0);
  check(record.optString("module").equals(module)&&installed.optString("notes").contains("Seção: "+item[4]),"Seção inválida para "+area);
  JSONObject reverted=UpdateAreaPatch.remove(installed,record,UpdateAreaPatch.inverse(base,patch),app,100000);
  check(reverted.getJSONObject("files").getString(page).equals(files.getString(page)),"A desinstalação alterou outros trechos de "+area);
  JSONObject legacy=UpdateAreaPatch.apply(base,petPatch("legado-"+area,"",change).put("area",area).put("format","agenda-patch/1"),app,100000);
  check(legacy.getJSONArray("modularUpdates").getJSONObject(0).optString("module").equals(module),"A classificação de arquivo antigo falhou em "+area);
 }
}
public static void main(String[] args)throws Exception{
 Path project=Path.of(args[0]),folder=Files.createTempDirectory("agenda-review-"),file=folder.resolve("selected.json");
 int base=UpdateManager.BASE_SEQUENCE;JSONObject installed=release(base+1,"1.12.181","Versão instalada.","installed");
 byte[] original=installed.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);Files.createDirectories(folder.resolve("updates"));Files.write(folder.resolve("updates/active.json"),original);
 MainActivity activity=new MainActivity(folder.toFile(),project.resolve("app/src/main/assets"));WebView view=new WebView();UpdateManager manager=new UpdateManager(activity,view);view.reader=manager::localResponse;
 String notes="Corrige o balão do mascote.\nMantém os botões internos de navegação.";
 JSONObject candidate=release(base+2,"1.12.182",notes,"approved-original");
 try{
 manager.setUpdateAccount(TEACHER);manager.openPage(Uri.parse(LocalPages.HOME));view.awaitLoads(1);int before=view.loads;
 AlertDialog review=select(manager,file,candidate);
 check(review.title.equals("Revisar atualização"),"Título da revisão ausente");
 check(review.message.contains("Versão instalada: 1.12.181")&&review.message.contains("Versão do arquivo: 1.12.182"),"Versões não apresentadas");
 check(review.message.contains(notes)&&review.message.contains("Sua conta, cadastros, fichas e históricos serão mantidos"),"Descrição ou efeito sobre os dados ausente");
 check(review.getButton(AlertDialog.BUTTON_POSITIVE).text.equals("Sim, atualizar")&&review.getButton(AlertDialog.BUTTON_NEGATIVE).text.equals("Não, cancelar"),"Escolha explícita ausente");
 unchanged(folder,original,activity,view,before);
 click(review,AlertDialog.BUTTON_NEGATIVE);waitFor(manager,false);unchanged(folder,original,activity,view,before);
 review=select(manager,file,candidate);review.dismiss();waitFor(manager,false);unchanged(folder,original,activity,view,before);
 review=select(manager,file,candidate);view.allowUpdates=false;click(review,AlertDialog.BUTTON_POSITIVE);
 check(review.isShowing()&&review.getButton(AlertDialog.BUTTON_POSITIVE).enabled,"Treino em andamento fechou a revisão ou travou o botão");unchanged(folder,original,activity,view,before);review.dismiss();view.allowUpdates=true;
 review=select(manager,file,candidate);manager.setUpdateAccount("student");waitFor(manager,false);
 check(!review.isShowing()&&field(manager,"reviewBundle")==null,"Troca de conta deixou a revisão aberta");unchanged(folder,original,activity,view,before);
 manager.importUri(Uri.parse(file.toUri().toString()));check(field(manager,"reviewDialog")==null&&!Boolean.TRUE.equals(field(manager,"busy")),"Aluno iniciou importação local");
 manager.setUpdateAccount(TEACHER);
 for(Object invalid:new Object[]{null,"   ",Boolean.TRUE,"x".repeat(4001)}){
  Files.writeString(file,release(base+2,"1.12.182",invalid,"no-notes").toString());manager.importUri(Uri.parse(file.toUri().toString()));waitFor(manager,false);
  check(field(manager,"reviewDialog")==null,"Descrição inválida ofereceu instalação");
  check(AlertDialog.lastCreated.title.equals("Descrição da atualização ausente"),"Falta de descrição não foi explicada");unchanged(folder,original,activity,view,before);
 }
 Files.writeString(file,installed.toString());manager.importUri(Uri.parse(file.toUri().toString()));waitFor(manager,false);check(field(manager,"reviewDialog")==null,"Duplicata foi oferecida");unchanged(folder,original,activity,view,before);
 review=select(manager,file,candidate);set(manager,"active",release(base+3,"1.12.183","Outra atualização.","newer"));click(review,AlertDialog.BUTTON_POSITIVE);waitFor(manager,false);unchanged(folder,original,activity,view,before);set(manager,"active",installed);
 review=select(manager,file,candidate);view.holdUpdateCheck=true;click(review,AlertDialog.BUTTON_POSITIVE);android.webkit.ValueCallback<String> late=view.pendingUpdateCheck;
 check(!review.getButton(AlertDialog.BUTTON_POSITIVE).enabled,"Duplo toque não foi bloqueado");click(review,AlertDialog.BUTTON_NEGATIVE);
 AlertDialog replacement=select(manager,file,candidate);late.onReceiveValue("true");check(replacement.isShowing(),"Resposta antiga confirmou uma seleção nova");unchanged(folder,original,activity,view,before);replacement.dismiss();view.holdUpdateCheck=false;
 review=select(manager,file,candidate);Files.writeString(file,release(base+3,"1.12.183","Arquivo trocado depois da seleção.","changed-after-review").toString());
 click(review,AlertDialog.BUTTON_POSITIVE);click(review,AlertDialog.BUTTON_POSITIVE);view.awaitLoads(before+1);
 check(view.loads==before+1&&view.html.contains("approved-original")&&!view.html.contains("changed-after-review"),"Confirmação reabriu o URI ou instalou duas vezes");
 check(activity.prefs.getBoolean("pending",false),"Instalação não aguardou a abertura da nova página");
 check(Files.readString(folder.resolve("updates/data-before-update.json")).equals(view.snapshot),"Dados não preservados no momento da confirmação");
 check(Arrays.equals(original,Files.readAllBytes(folder.resolve("updates/previous.json"))),"Versão anterior não preservada");
 view.ready=true;manager.pageReady();waitFor(manager,false);check(!activity.prefs.getBoolean("pending",true),"Confirmação de abertura não foi mantida");
 // Published metadata may supply notes for older packages, but still requires a new consent.
 int generation=(Integer)field(manager,"reviewGeneration")+1;set(manager,"reviewGeneration",generation);set(manager,"busy",true);
 Method remote=UpdateManager.class.getDeclaredMethod("reviewUpdate",JSONObject.class,String.class,int.class);remote.setAccessible(true);
 remote.invoke(manager,release(base+3,"1.12.183",null,"published"),"Descrição recebida da publicação.",generation);waitFor(manager,true);
 review=(AlertDialog)field(manager,"reviewDialog");check(review.message.contains("Descrição recebida da publicação."),"Descrição da publicação não aceita");
 int accepted=view.loads;review.dismiss();waitFor(manager,false);check(view.loads==accepted,"Atualização publicada instalou ao cancelar");
 review=select(manager,file,release(base+3,"1.12.183",notes,"abandoned"));manager.destroy();check(!review.isShowing()&&field(manager,"reviewBundle")==null,"Fechar o aplicativo reteve uma instalação pendente");
 scoped(project,args,false);
 scoped(project,new String[]{args[0]},true);
 if(args.length==4)scoped(project,args,true);
 moduleRules();
 areaModules();
 System.out.println(checks+" verificações da importação com revisão passaram; sem rede, APK assinado ou aparelho físico.");
 }finally{manager.destroy();}
}
}'''


def main():
    stubs = dict(runpy.run_path(str(PROJECT/'tests/verify_native_updates.py'))['STUBS'])
    stubs.pop(PACKAGE+'NativeUpdateHarness.java')
    stubs[PACKAGE+'UpdateReviewHarness.java'] = HARNESS
    java = shutil.which('java')
    assert java, 'Java 17 é necessário.'
    compiler = [shutil.which('javac')] if shutil.which('javac') else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-import-review-') as temp:
        work = Path(temp)
        sources = [str(PROJECT/'app/src/main/java'/PACKAGE/name) for name in ('UpdateManager.java','UpdateAreaPatch.java','UpdateArchive.java','AndroidInstaller.java','UpdateStorage.java','UpdateExport.java','UpdateDownloads.java','LocalPages.java','UpdateManifest.java','UpdatePackageSignature.java','NativeLaunch.java','UpdateIdentity.java')]
        for name, text in stubs.items():
            target = work/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text)
            sources.append(str(target))
        subprocess.run(compiler+['-encoding','UTF-8','-d',str(work/'classes')]+sources, check=True)
        fixtures = []
        if len(sys.argv) == 4:
            base, patch, prepared = [Path(value).resolve() for value in sys.argv[1:]]
            expected = json.loads(prepared.read_bytes())
            manifest = work/'expected.json'
            manifest.write_text(json.dumps({
                'cadastroSha256': hashlib.sha256(expected['files']['cadastro.html'].encode()).hexdigest(),
                'modularUpdates': expected['modularUpdates'],
            }))
            fixtures = [str(base), str(patch), str(manifest)]
        subprocess.run([java,'-Xmx'+('512m' if fixtures else '256m'),'-cp',str(work/'classes'),'com.tiagolima.agendapersonal.UpdateReviewHarness',str(PROJECT),*fixtures], check=True)


if __name__ == '__main__':
    main()
