"""Exercise the production importer and its real dialog callbacks with Android API fakes.

Checks file and storage side effects, cancellation, account changes and late replies.
This compiles the real Java importer; it is not a device test or a signed APK build.
"""
from pathlib import Path
import runpy
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
PACKAGE = 'com/tiagolima/agendapersonal/'
HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.AlertDialog;import android.net.Uri;import android.webkit.WebView;
import java.nio.file.*;import java.lang.reflect.*;import java.util.Arrays;import org.json.JSONObject;
public final class UpdateReviewHarness {
static final String TEACHER="R2EmnDVcvMWt7TjPxOP6DjW1VOn1";
static int checks;
static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
static Object field(Object o,String name)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
static void set(Object o,String name,Object v)throws Exception{Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);f.set(o,v);}
static JSONObject release(int seq,String version,Object notes,String marker){String html="<!doctype html><html><head></head><body>"+marker+" agendaPersonalTL_v1 syncNativeAlarms<script data-agenda-ready></script></body></html>";JSONObject value=new JSONObject().put("format",1).put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4).put("version",version).put("sequence",seq).put("files",new JSONObject().put("index.html",html).put("avaliacoes.html",html));if(notes!=null)value.put("notes",notes);return value;}
static void waitFor(UpdateManager m,boolean wantReview)throws Exception{long until=System.currentTimeMillis()+5000;while(System.currentTimeMillis()<until){AlertDialog d=(AlertDialog)field(m,"reviewDialog");if(wantReview&&d!=null&&d.isShowing()&&d.getButton(AlertDialog.BUTTON_POSITIVE).listener!=null)return;if(!wantReview&&!Boolean.TRUE.equals(field(m,"busy")))return;Thread.sleep(5);}throw new AssertionError("Operação não terminou: review="+wantReview);}
static AlertDialog select(UpdateManager m,Path file,JSONObject value)throws Exception{Files.writeString(file,value.toString());m.importUri(Uri.parse(file.toUri().toString()));waitFor(m,true);return(AlertDialog)field(m,"reviewDialog");}
static void click(AlertDialog dialog,int which){android.widget.Button b=dialog.getButton(which);if(b.listener!=null)b.listener.click(b);}
static void unchanged(Path folder,byte[] original,MainActivity a,WebView view,int loads)throws Exception{
 check(Arrays.equals(original,Files.readAllBytes(folder.resolve("updates/active.json"))),"A revisão/cancelamento alterou a versão instalada");
 check(!Files.exists(folder.resolve("updates/data-before-update.json")),"Dados copiados antes de confirmar");
 check(!Files.exists(folder.resolve("updates/previous.json")),"Histórico alterado antes de confirmar");
 check(!a.prefs.getBoolean("pending",false),"Instalação iniciada sem confirmação");
 check(view.loads==loads,"A página recarregou antes de confirmar");
}
public static void main(String[] args)throws Exception{
 Path project=Path.of(args[0]),folder=Files.createTempDirectory("agenda-review-"),file=folder.resolve("selected.json");
 int base=UpdateManager.BASE_SEQUENCE;JSONObject installed=release(base+1,"1.12.181","Versão instalada.","installed");
 byte[] original=installed.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);Files.createDirectories(folder.resolve("updates"));Files.write(folder.resolve("updates/active.json"),original);
 MainActivity activity=new MainActivity(folder.toFile(),project.resolve("app/src/main/assets"));WebView view=new WebView();UpdateManager manager=new UpdateManager(activity,view);view.reader=manager::localResponse;
 String notes="Corrige o balão do mascote.\nMantém os botões internos de navegação.";
 JSONObject candidate=release(base+2,"1.12.182",notes,"approved-original");
 try{
 manager.setUpdateAccount(TEACHER);manager.openPage(Uri.parse(LocalPages.HOME));view.awaitLoads(1);int before=view.loads;
 AlertDialog review=select(manager,file,candidate);
 check(review.title.equals("Revisar atualização"),"Título da revisão ausente");
 check(review.message.contains("Versão instalada: 1.12.181")&&review.message.contains("Versão do arquivo: 1.12.182"),"Versões não apresentadas");
 check(review.message.contains(notes)&&review.message.contains("Sua conta, cadastros, fichas e históricos serão mantidos"),"Descrição ou efeito sobre os dados ausente");
 check(review.getButton(AlertDialog.BUTTON_POSITIVE).text.equals("Sim, atualizar")&&review.getButton(AlertDialog.BUTTON_NEGATIVE).text.equals("Não, cancelar"),"Escolha explícita ausente");
 unchanged(folder,original,activity,view,before);
 click(review,AlertDialog.BUTTON_NEGATIVE);waitFor(manager,false);unchanged(folder,original,activity,view,before);
 review=select(manager,file,candidate);review.dismiss();waitFor(manager,false);unchanged(folder,original,activity,view,before);
 review=select(manager,file,candidate);view.allowUpdates=false;click(review,AlertDialog.BUTTON_POSITIVE);
 check(review.isShowing()&&review.getButton(AlertDialog.BUTTON_POSITIVE).enabled,"Treino em andamento fechou a revisão ou travou o botão");unchanged(folder,original,activity,view,before);review.dismiss();view.allowUpdates=true;
 review=select(manager,file,candidate);manager.setUpdateAccount("student");waitFor(manager,false);
 check(!review.isShowing()&&field(manager,"reviewBundle")==null,"Troca de conta deixou a revisão aberta");unchanged(folder,original,activity,view,before);
 manager.importUri(Uri.parse(file.toUri().toString()));check(field(manager,"reviewDialog")==null&&!Boolean.TRUE.equals(field(manager,"busy")),"Aluno iniciou importação local");
 manager.setUpdateAccount(TEACHER);
 for(Object invalid:new Object[]{null,"   ",Boolean.TRUE,"x".repeat(4001)}){
  Files.writeString(file,release(base+2,"1.12.182",invalid,"no-notes").toString());manager.importUri(Uri.parse(file.toUri().toString()));waitFor(manager,false);
  check(field(manager,"reviewDialog")==null,"Descrição inválida ofereceu instalação");
  check(AlertDialog.lastCreated.title.equals("Descrição da atualização ausente"),"Falta de descrição não foi explicada");unchanged(folder,original,activity,view,before);
 }
 Files.writeString(file,installed.toString());manager.importUri(Uri.parse(file.toUri().toString()));waitFor(manager,false);check(field(manager,"reviewDialog")==null,"Duplicata foi oferecida");unchanged(folder,original,activity,view,before);
 review=select(manager,file,candidate);set(manager,"active",release(base+3,"1.12.183","Outra atualização.","newer"));click(review,AlertDialog.BUTTON_POSITIVE);waitFor(manager,false);unchanged(folder,original,activity,view,before);set(manager,"active",installed);
 review=select(manager,file,candidate);view.holdUpdateCheck=true;click(review,AlertDialog.BUTTON_POSITIVE);android.webkit.ValueCallback<String> late=view.pendingUpdateCheck;
 check(!review.getButton(AlertDialog.BUTTON_POSITIVE).enabled,"Duplo toque não foi bloqueado");click(review,AlertDialog.BUTTON_NEGATIVE);
 AlertDialog replacement=select(manager,file,candidate);late.onReceiveValue("true");check(replacement.isShowing(),"Resposta antiga confirmou uma seleção nova");unchanged(folder,original,activity,view,before);replacement.dismiss();view.holdUpdateCheck=false;
 review=select(manager,file,candidate);Files.writeString(file,release(base+3,"1.12.183","Arquivo trocado depois da seleção.","changed-after-review").toString());
 click(review,AlertDialog.BUTTON_POSITIVE);click(review,AlertDialog.BUTTON_POSITIVE);view.awaitLoads(before+1);
 check(view.loads==before+1&&view.html.contains("approved-original")&&!view.html.contains("changed-after-review"),"Confirmação reabriu o URI ou instalou duas vezes");
 check(activity.prefs.getBoolean("pending",false),"Instalação não aguardou a abertura da nova página");
 check(Files.readString(folder.resolve("updates/data-before-update.json")).equals(view.snapshot),"Dados não preservados no momento da confirmação");
 check(Arrays.equals(original,Files.readAllBytes(folder.resolve("updates/previous.json"))),"Versão anterior não preservada");
 view.ready=true;manager.pageReady();waitFor(manager,false);check(!activity.prefs.getBoolean("pending",true),"Confirmação de abertura não foi mantida");
 // Published metadata may supply notes for older packages, but still requires a new consent.
 int generation=(Integer)field(manager,"reviewGeneration")+1;set(manager,"reviewGeneration",generation);set(manager,"busy",true);
 Method remote=UpdateManager.class.getDeclaredMethod("reviewUpdate",JSONObject.class,String.class,int.class);remote.setAccessible(true);
 remote.invoke(manager,release(base+3,"1.12.183",null,"published"),"Descrição recebida da publicação.",generation);waitFor(manager,true);
 review=(AlertDialog)field(manager,"reviewDialog");check(review.message.contains("Descrição recebida da publicação."),"Descrição da publicação não aceita");
 int accepted=view.loads;review.dismiss();waitFor(manager,false);check(view.loads==accepted,"Atualização publicada instalou ao cancelar");
 review=select(manager,file,release(base+3,"1.12.183",notes,"abandoned"));manager.destroy();check(!review.isShowing()&&field(manager,"reviewBundle")==null,"Fechar o aplicativo reteve uma instalação pendente");
 System.out.println(checks+" verificações da importação com revisão passaram; sem rede, APK assinado ou aparelho físico.");
 }finally{manager.destroy();}
}
}'''


def main():
    stubs = dict(runpy.run_path(str(PROJECT/'tests/verify_native_updates.py'))['STUBS'])
    stubs.pop(PACKAGE+'NativeUpdateHarness.java')
    stubs[PACKAGE+'UpdateReviewHarness.java'] = HARNESS
    java = shutil.which('java')
    assert java, 'Java 17 é necessário.'
    compiler = [shutil.which('javac')] if shutil.which('javac') else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-import-review-') as temp:
        work = Path(temp)
        sources = [str(PROJECT/'app/src/main/java'/PACKAGE/name) for name in ('UpdateManager.java','UpdateStorage.java','LocalPages.java','UpdateManifest.java','NativeLaunch.java','UpdateIdentity.java')]
        for name, text in stubs.items():
            target = work/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text)
            sources.append(str(target))
        subprocess.run(compiler+['-encoding','UTF-8','-d',str(work/'classes')]+sources, check=True)
        subprocess.run([java,'-cp',str(work/'classes'),'com.tiagolima.agendapersonal.UpdateReviewHarness',str(PROJECT)], check=True)


if __name__ == '__main__':
    main()
