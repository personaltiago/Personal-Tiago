'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const {chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const publicPath=process.env.AGENDA_PUBLIC_REGISTRATION||path.resolve(__dirname,'../web/cadastro-aluno-publico.html');
const server=http.createServer((req,res)=>{
 const name=new URL(req.url,'http://local').pathname.slice(1);let html;
 if(name==='cadastro-aluno.html')html=fs.readFileSync(publicPath,'utf8');
 else if(['professor.html','index.html','cadastro.html'].includes(name)){
  html=fs.readFileSync(path.join(assets,name),'utf8');
  if(name==='professor.html')html=html.replace(/(<script data-agenda-registration>)([\s\S]*?)(<\/script>)/,(_,open,code,close)=>open+code.replace(/\n\}\)\(\);\s*$/,'\nwindow.__signupPhotoTest={setSdk:value=>sdk=value};\n})();')+close);
 }else{res.writeHead(404);return res.end()}
 res.setHeader('Content-Type','text/html;charset=utf-8');res.end(html);
});
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});try{
 const ctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});const errors=[];
 await ctx.addInitScript(()=>{window.__auth={currentUser:null};window.__savedRecord=null;window.__creates=0;window.__writes=0;window.__deny=false});
 await ctx.route(/^https:\/\//,async route=>{
  const url=route.request().url();let body='';
  if(url.endsWith('firebase-app.js'))body='export function initializeApp(){return {}}';
  else if(url.endsWith('firebase-auth.js'))body=`export function getAuth(){return window.__auth}export async function createUserWithEmailAndPassword(a,email){__creates++;const user={uid:'signup_student',email};a.currentUser=user;return{user}}export async function signInWithEmailAndPassword(a,email){const user={uid:'signup_student',email};a.currentUser=user;return{user}}export async function updateProfile(){}`;
  else if(url.endsWith('firebase-firestore.js'))body=`export function getFirestore(){return {}}export function doc(db,c,uid){return{c,uid}}export function serverTimestamp(){return 'server-time'}export async function getDoc(){return{exists:()=>__savedRecord!==null,data:()=>__savedRecord}}export async function setDoc(ref,data){__writes++;if(__deny)throw{code:'permission-denied'};__savedRecord=structuredClone(data)}export async function updateDoc(ref,data){__writes++;if(__deny)throw{code:'permission-denied'};Object.assign(__savedRecord,structuredClone(data))}`;
  else return route.abort();await route.fulfill({status:200,contentType:'application/javascript',headers:{'Access-Control-Allow-Origin':'*'},body});
 });
 const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port+'/cadastro-aluno.html');await page.waitForFunction(()=>window.APRegistrationPhoto);
 for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1))}
 const base64=await page.evaluate(()=>{const c=document.createElement('canvas');c.width=600;c.height=800;const g=c.getContext('2d');g.fillStyle='#72549d';g.fillRect(0,0,600,800);g.fillStyle='#f4d0e1';g.fillRect(140,200,320,400);return c.toDataURL('image/png').split(',')[1]});
 const photo={name:'minha-foto.png',mimeType:'image/png',buffer:Buffer.from(base64,'base64')};
 const chooser=page.waitForEvent('filechooser');await page.getByRole('button',{name:'Escolher foto',exact:true}).click();await(await chooser).setFiles(photo);await page.locator('#registrationPhotoEditor').waitFor({state:'visible'});await page.getByRole('button',{name:'Usar este recorte',exact:true}).click();await page.waitForFunction(()=>document.getElementById('registrationPhotoStatus').textContent.includes('Foto pronta'));
 const first=await page.evaluate(()=>APRegistrationPhoto.value());assert.ok(first.length<=120000);assert.ok(await page.locator('#registrationPhotoPreview').isVisible());assert.equal(await page.locator('#registrationPhotoCameraFile').getAttribute('capture'),'user');
 await page.getByRole('button',{name:'Ajustar recorte',exact:true}).click();
 assert.equal(await page.evaluate(()=>{try{APRegistrationPhoto.value();return false}catch(e){return e.message.includes('Confirme o recorte')}}),true,'unconfirmed crop cannot be submitted');
 await page.locator('#registrationPhotoZoom').focus();await page.keyboard.press('End');assert.equal(await page.locator('#registrationPhotoZoom').inputValue(),'4');await page.keyboard.press('Home');
 await page.locator('#registrationPhotoZoom').evaluate(n=>{n.value='2';n.dispatchEvent(new Event('input',{bubbles:true}))});
 for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'crop fits '+width)}await page.setViewportSize({width:390,height:844});
 await page.locator('#registrationPhotoCrop').scrollIntoViewIfNeeded();const touchBounds=await page.locator('#registrationPhotoCrop').boundingBox(),cdp=await ctx.newCDPSession(page),touch={x:touchBounds.x+touchBounds.width/2,y:touchBounds.y+touchBounds.height/2};await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[touch]});await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:touch.x-30,y:touch.y-20}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await cdp.detach();
 await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/signup-photo-crop.png'});
 const bounds=await page.locator('#registrationPhotoCrop').boundingBox();await page.mouse.move(bounds.x+bounds.width/2,bounds.y+bounds.height/2);await page.mouse.down();await page.mouse.move(bounds.x+bounds.width/2+65,bounds.y+bounds.height/2+40,{steps:8});await page.mouse.up();
 await page.getByRole('button',{name:'Usar este recorte',exact:true}).click();const moved=await page.evaluate(()=>APRegistrationPhoto.value());assert.notEqual(moved,first,'pan and zoom change the saved JPEG');
 await page.getByRole('button',{name:'Ajustar recorte',exact:true}).click();assert.equal(await page.locator('#registrationPhotoZoom').inputValue(),'2');await page.locator('#registrationPhotoCrop').focus();await page.keyboard.press('ArrowRight');await page.getByRole('button',{name:'Cancelar',exact:true}).click();assert.equal(await page.evaluate(()=>APRegistrationPhoto.value()),moved,'cancel preserves confirmed crop');
 await page.getByRole('button',{name:'Ajustar recorte',exact:true}).click();
 await page.locator('#registrationPhotoCrop').scrollIntoViewIfNeeded();const limitBounds=await page.locator('#registrationPhotoCrop').boundingBox();await page.mouse.move(limitBounds.x+limitBounds.width/2,limitBounds.y+limitBounds.height/2);await page.mouse.down();await page.mouse.move(5000,5000,{steps:3});await page.mouse.up();
 await page.getByRole('button',{name:'Usar este recorte',exact:true}).click();
 const edge=await page.evaluate(async()=>{const i=new Image();await new Promise(r=>{i.onload=r;i.src=APRegistrationPhoto.value()});const c=document.createElement('canvas');c.width=c.height=320;const g=c.getContext('2d');g.drawImage(i,0,0);return {size:[i.naturalWidth,i.naturalHeight],pixel:[...g.getImageData(1,1,1,1).data]}});assert.deepEqual(edge.size,[320,320]);assert.equal(edge.pixel[3],255);assert.ok(edge.pixel[0]>50,'bounded crop has no blank border');
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/signup-photo-public.png'});
 await page.getByRole('button',{name:'Remover foto',exact:true}).click();assert.equal(await page.evaluate(()=>APRegistrationPhoto.value()),'');assert.ok(await page.locator('#registrationPhotoPreview').isHidden());
 await page.locator('#registrationPhotoFile').setInputFiles(photo);await page.locator('#registrationPhotoEditor').waitFor({state:'visible'});await page.getByRole('button',{name:'Cancelar',exact:true}).click();assert.equal(await page.evaluate(()=>APRegistrationPhoto.value()),'','canceling first selection keeps photo optional');
 await page.locator('#registrationPhotoCameraFile').setInputFiles(photo);await page.locator('#registrationPhotoEditor').waitFor({state:'visible'});await page.getByRole('button',{name:'Usar este recorte',exact:true}).click();await page.waitForFunction(()=>document.getElementById('registrationPhotoStatus').textContent.includes('Foto pronta'));
 await page.locator('#registrationPhotoFile').setInputFiles({name:'bad.jpg',mimeType:'image/jpeg',buffer:Buffer.from('not an image')});await page.waitForFunction(()=>document.getElementById('registrationPhotoStatus').dataset.error==='true');assert.equal(await page.evaluate(()=>APRegistrationPhoto.value()),first,'invalid replacement keeps selected photo');
 await page.locator('#nome').fill('Aluno com foto');await page.locator('#email').fill('aluno@example.com');await page.locator('#whatsapp').fill('69999998888');await page.locator('#nascimento').fill('2000-01-02');await page.locator('#genero').selectOption('Feminino');await page.locator('#senha').fill('teste123');await page.locator('#confirmar').fill('teste123');
 await page.evaluate(()=>__deny=true);await page.locator('#submit').click();await page.waitForFunction(()=>document.getElementById('status').textContent.includes('permissões'));assert.equal(await page.evaluate(()=>__creates),1);assert.equal(await page.evaluate(()=>APRegistrationPhoto.value()),first);
 await page.evaluate(()=>__deny=false);await page.locator('#submit').click();await page.waitForFunction(()=>document.getElementById('done').style.display==='block');assert.equal(await page.evaluate(()=>__creates),1,'retry reuses created account');
 const record=await page.evaluate(()=>__savedRecord);assert.equal(record.fotoCadastro,first);assert.equal(record.ativo,false);assert.equal(record.senha,undefined);assert.equal(record.confirmar,undefined);
 const teacher=await ctx.newPage();teacher.on('pageerror',e=>errors.push(e.message));await teacher.goto('http://127.0.0.1:'+server.address().port+'/professor.html');
 await teacher.evaluate(record=>{
  const uid=agendaRegistration.teacher;window.__approvalWrites=[];
  __signupPhotoTest.setSdk({auth:{currentUser:{uid}},db:{},collection:()=>({}),where:()=>({}),query:()=>({}),getDocs:async()=>({docs:[{id:'signup_student',data:()=>record}]}),doc:(db,c,id)=>({c,id}),serverTimestamp:()=> 'server-time',updateDoc:async(ref,data)=>__approvalWrites.push(data)});
  openRegistrationLink();setRegistrationTab('contacts');
 },record);
 await teacher.waitForSelector('.registration-contact-photo');assert.equal(await teacher.locator('.registration-contact-photo').getAttribute('src'),first);assert.match(await teacher.locator('.registration-contact').innerText(),/Aguardando aprovação/);
 await teacher.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/signup-photo-teacher.png'});
 await teacher.locator('[data-registration-type]').selectOption('presencial');await teacher.locator('[data-registration-approve]').click();await teacher.waitForFunction(()=>state.students.some(s=>s.firebaseUid==='signup_student'));
 const imported=await teacher.evaluate(()=>state.students.find(s=>s.firebaseUid==='signup_student'));assert.equal(imported.photoDataUrl,first);assert.equal(imported.name,'Aluno com foto');assert.equal(imported.studentType,'presencial');assert.deepEqual(await teacher.evaluate(()=>__approvalWrites),[{ativo:true,tipoAluno:'presencial',aprovadoEm:'server-time'}]);
 const keep=await teacher.evaluate(record=>{
  const original={id:'older',name:'Aluno existente',photoDataUrl:'FOTO_DO_PROFESSOR',notes:'nota',firebaseUid:''};const base={...state,students:[original],history:[]};
  const linked=agendaRegistration.prepareImport({...record,uid:'another_student',ativo:true},'online','older',base).student;
  const invalid=agendaRegistration.profileData({...record,uid:'valid_student',fotoCadastro:'data:image/svg+xml;base64,PHN2Zz4='});
  const packet=APStudentModel.makeArea(state,state.students.find(s=>s.firebaseUid==='signup_student'));
  return{linked,invalid,packet};
 },record);assert.equal(keep.linked.photoDataUrl,'FOTO_DO_PROFESSOR');assert.equal(keep.linked.notes,'nota');assert.equal(keep.invalid.photo,'');assert.ok(JSON.stringify(keep.packet.profile).includes(first),'student packet carries signup photo');
 await teacher.reload();assert.equal(await teacher.evaluate(()=>state.students.find(s=>s.firebaseUid==='signup_student').photoDataUrl),first);
 await page.reload();await page.locator('#nome').fill('Aluno sem foto');await page.locator('#email').fill('semfoto@example.com');await page.locator('#whatsapp').fill('69999998888');await page.locator('#nascimento').fill('2000-01-02');await page.locator('#genero').selectOption('Masculino');await page.locator('#senha').fill('teste123');await page.locator('#confirmar').fill('teste123');await page.locator('#submit').click();await page.waitForFunction(()=>document.getElementById('done').style.display==='block');assert.equal(await page.evaluate(()=>__savedRecord.fotoCadastro),undefined,'photo remains optional');
 assert.deepEqual(errors,[]);console.log('PASS: circular crop drag/zoom, keyboard movement, confirm/cancel and readjust, JPEG output bounds, real gallery/camera file inputs, JPEG compression/preview/removal, invalid image preserves choice, optional photo, signup storage and permission retry, pending teacher photo, approval/import, existing photo preservation, unsafe URI ignored, student packet and reload. Browser/image processing real; Firebase simulated.');
 }finally{await browser.close();server.close()}}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
