'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'):require;
const {chromium}=runtime('playwright'),{ctx,storage}=require('./verify_shell_boot.cjs');
const source=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/professor.html'),'utf8');
storage.set('ap_professor_marca_159_professor_teste',JSON.stringify({completed:true,name:'Marca inicial',description:'Personal Trainer',main:'#A12CFF',support:'#08070C',bg:'#08070C',design:'atual'}));
let prepared='';
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(prepared)});
async function run(){
 const teacher=ctx.APStudentModel.TEACHER;ctx.__accountTest.setSdk({auth:{currentUser:{uid:teacher}},signOut:async()=>{}});
 await ctx.__accountTest.activate({uid:teacher,email:'teacher@example.test'},'Professor');prepared=ctx.APprepareTeacherDocument(source);
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,deviceScaleFactor:1});
  await context.route('https://**',route=>route.abort());
  await context.addInitScript(()=>{
   if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[],lessons:[],customData:{keep:17}}));
   const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.failProfileSave&&k==='agendaPersonalTL_v1')throw new DOMException('Full','QuotaExceededError');return set.call(this,k,v)};
  });
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>typeof openTrainerProfile==='function');
  await page.evaluate(()=>openTrainerProfile());await page.locator('#trainerProfileDialog.open').waitFor();
  await page.locator('#trainerName').fill('Personal atualizado');await page.locator('#trainerCref').fill('CREF 012345-G/RO');
  const data=await page.evaluate(()=>{const c=document.createElement('canvas');c.width=600;c.height=1200;const g=c.getContext('2d');for(const [color,y]of [['red',0],['green',400],['blue',800]]){g.fillStyle=color;g.fillRect(0,y,600,400)}return c.toDataURL('image/png').split(',')[1]});
  await page.locator('#trainerPhotoInput').setInputFiles({name:'portrait.png',mimeType:'image/png',buffer:Buffer.from(data,'base64')});
  await page.locator('#trainerPhotoCropDialog.open').waitFor();
  assert.equal(await page.locator('#trainerPhotoPreview img').count(),0,'selection not applied before confirmation');
  await page.locator('#trainerCropZoom').evaluate(el=>{el.value='2';el.dispatchEvent(new Event('input',{bubbles:true}))});
  const canvas=page.locator('#trainerCropCanvas'),box=await canvas.boundingBox();
  const cdp=await context.newCDPSession(page),x=box.x+box.width/2,y=box.y+box.height/2;
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});
  for(const d of [.1,.2,.35])await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x,y:y+box.height*d}]});
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  const geometry=await page.evaluate(()=>({x:trainerCropSession.x,y:trainerCropSession.y,r:trainerCropSession.radius,w:trainerCropSession.image.naturalWidth,h:trainerCropSession.image.naturalHeight}));
  assert.ok(geometry.y>800,'circle follows touch toward bottom of full photo');assert.ok(geometry.y+geometry.r<=geometry.h);
  await page.screenshot({path:path.resolve(__dirname,'../../../../trainer_crop_review.png')});
  await page.locator('#trainerCropApply').click();
  const pixel=await page.evaluate(async()=>{const img=await trainerReadImage(trainerPhotoDraft),c=trainerCanvas(512,512),g=c.getContext('2d');g.drawImage(img,0,0);return {width:img.naturalWidth,height:img.naturalHeight,pixel:Array.from(g.getImageData(256,256,1,1).data)}});
  assert.equal(pixel.width,512);assert.equal(pixel.height,512);assert.ok(pixel.pixel[2]>220&&pixel.pixel[0]<30,'saved crop uses selected blue region');
  await page.screenshot({path:path.resolve(__dirname,'../../../../trainer_profile_review.png')});
  await page.locator('#trainerProfileForm button[type="submit"]').click();
  let profile=await page.evaluate(()=>state.trainerProfile);assert.equal(profile.cref,'012345-G/RO');assert.equal(profile.name,'Personal atualizado');assert.ok(profile.photoCrop.y>.66);
  await page.reload();await page.waitForFunction(()=>typeof openTrainerProfile==='function');
  assert.equal(await page.evaluate(()=>state.trainerProfile.name),'Personal atualizado','brand bootstrap preserves edited profile');
  assert.equal(await page.locator('#moreTrainerCref').textContent(),'CREF 012345-G/RO');
  assert.equal(await page.evaluate(()=>state.customData.keep),17);
  await page.evaluate(()=>openTrainerProfile());await page.locator('#trainerPhotoAdjust').click();await page.locator('#trainerPhotoCropDialog.open').waitFor();
  assert.ok(await page.evaluate(()=>trainerCropSession.y>800));
  await canvas.press('ArrowUp');assert.ok(await page.evaluate(()=>trainerCropSession.y<trainerPhotoCropDraft.y*trainerCropSession.image.naturalHeight));
  await page.locator('#trainerPhotoCropDialog .close').click();assert.equal(await page.evaluate(()=>trainerPhotoDraft),profile.photoDataUrl,'cancel preserves previous crop');
  for(const width of [320,390,480]){
   await page.setViewportSize({width,height:844});
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,'no horizontal page overflow at '+width);
   const inputBox=await page.locator('#trainerCref').boundingBox();assert.ok(inputBox.x>=0&&inputBox.x+inputBox.width<=width+1);
  }
  await page.setViewportSize({width:390,height:844});
  await page.locator('#trainerName').fill('Não persistir');await page.evaluate(()=>window.failProfileSave=true);
  await page.locator('#trainerProfileForm button[type="submit"]').click();assert.equal(await page.evaluate(()=>state.trainerProfile.name),'Personal atualizado');
  assert.equal(await page.locator('#trainerProfileDialog').evaluate(n=>n.classList.contains('open')),true);
  await page.evaluate(()=>{window.failProfileSave=false;resetTrainerPhoto()});await page.locator('#trainerName').fill('Personal atualizado');await page.locator('#trainerCref').fill('');await page.locator('#trainerProfileForm button[type="submit"]').click();
  await page.reload();assert.equal(await page.evaluate(()=>state.trainerProfile.photoDataUrl),'');assert.equal(await page.evaluate(()=>state.trainerProfile.photoSourceDataUrl),'');assert.equal(await page.locator('#moreTrainerCref').isVisible(),false);
  await page.evaluate(()=>{window.APaccounts={isTeacher:()=>true};state.students=normalizeState({...state,students:[{id:'a',firebaseUid:'alice',name:'Silvana Alves',studentType:'presencial'},{id:'b',firebaseUid:'bob',name:'Silvana Alves',studentType:'presencial'}]}).students;showScreen('students-presencial')});
  assert.equal(await page.locator('#studentList [data-student-id="a"] .student-avatar img').count(),0);
  assert.equal(await page.evaluate(photo=>APapplyStudentPhotos([{uid:'alice',photo,revision:'photo_test',updatedAt:new Date().toISOString()}]),profile.photoDataUrl),true);
  assert.equal(await page.locator('#studentList [data-student-id="a"] .student-avatar img').count(),1);assert.equal(await page.locator('#studentList [data-student-id="b"] .student-avatar img').count(),0);
  await page.screenshot({path:path.resolve(__dirname,'../../../../teacher_received_photo_review.png')});
  assert.deepEqual(errors,[]);
  console.log('PASS: real Chromium mobile touch crop/zoom, selected pixels, keyboard, cancel, CREF persistence, branded reload, preserved unrelated data, save-failure rollback, reset and responsive widths 320/390/480. No real Android device used.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
