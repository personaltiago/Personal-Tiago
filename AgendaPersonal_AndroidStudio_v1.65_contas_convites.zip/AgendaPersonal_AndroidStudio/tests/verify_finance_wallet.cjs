'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),vm=require('node:vm'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const root=path.resolve(__dirname,'..'),{chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright');
const model=vm.createContext({Date,Intl});for(const f of ['billing-model.js','finance-wallet-model.js'])vm.runInContext(fs.readFileSync(path.join(root,'web',f),'utf8'),model);
function build(data,at='2026-10-17T12:00:00-04:00'){model.fixture=structuredClone(data);model.at=at;return JSON.parse(vm.runInContext('JSON.stringify(APFinanceWallet.build(fixture,new Date(at)))',model))}
const students=[
 {id:'a',name:'Jéssica',studentType:'presencial',financeEnabled:true,startDate:'2026-09-01',dueDate:'2026-10-17',monthlyValue:'780,00'},
 {id:'b',name:'Nome igual',studentType:'presencial',financeEnabled:true,startDate:'2026-09-01',dueDate:'2026-10-20',monthlyValue:'1.100,50'},
 {id:'c',name:'Nome igual',studentType:'online',financeEnabled:true,startDate:'2026-09-01',dueDate:'2026-10-25',monthlyValue:'350.25'},
 {id:'d',name:'Gratuito',studentType:'online',financeEnabled:true,startDate:'2026-09-01',dueDate:'2026-10-25',monthlyValue:0},
 {id:'e',name:'Valor a definir',studentType:'online',financeEnabled:true,startDate:'2026-09-01',dueDate:'2026-10-25',monthlyValue:''},
 {id:'archived',name:'Arquivado',archived:true,financeEnabled:true,startDate:'2026-09-01',dueDate:'2026-10-25',monthlyValue:'900'},
 {id:'off',name:'Financeiro desligado',financeEnabled:false,monthlyValue:'500'},
 {id:'future',name:'Começa em novembro',financeEnabled:true,startDate:'2026-11-01',dueDate:'2026-11-01',monthlyValue:'100'}
];
const payments=[
 {id:'p1',studentId:'a',studentName:'Jéssica',amount:'750,00',dueDate:'2026-09-17',paidAt:'2026-10-15T14:00:00-04:00'},
 {id:'p2',studentId:'archived',amount:'260',dueDate:'2026-10-01',paidAt:'2026-10-12T14:00:00-04:00'},
 {id:'p2',studentId:'archived',amount:'260',dueDate:'2026-10-01',paidAt:'2026-10-12T14:00:00-04:00'},
 {id:'unknown',studentId:'e',amount:'',dueDate:'2026-09-01',paidAt:'2026-10-01T04:00:00Z'},
 {id:'before',studentId:'a',amount:'999',paidAt:'2026-10-01T03:59:59Z'},
 {id:'future-cash',studentId:'a',amount:'999',paidAt:'2026-10-20T04:00:00Z'},
 {id:'invalid',amount:'999',paidAt:'not-a-date'}
];
const fixture={students,payments:payments.map(p=>({dueDate:'2026-10-01',...p})),lessons:[],history:[],customData:{keep:92},workoutPlans:[],workoutExecutions:[{id:'keep',studentId:'a',loads:[20,22]}]};
const first=build(fixture);assert.equal(first.forecastCents,223075);assert.equal(first.receivedCents,101000);assert.equal(first.pricedCount,4);assert.equal(first.rows.length,5);assert.equal(first.missingCount,1);assert.equal(first.unknownReceipts,1);assert.equal(first.receivedCount,3);assert.equal(first.rows.filter(s=>s.name==='Nome igual').length,2,'same names are separate students');
assert.equal(build({students:[],payments:[]}).forecastCents,0);
assert.equal(build({students:[{...students[0],monthlyValue:'errado'}]}).missingCount,1,'invalid amount is not silently treated as zero');
assert.equal(build({students:[{...students[0],monthlyValue:0}]}).forecastCents,0);
assert.equal(build({students:[{...students[0],monthlyValue:0}]}).missingCount,0);
assert.equal(build({students:[{...students[0],monthlyValue:'R$ 1.234,56'}]}).forecastCents,123456);
assert.equal(build({students:[{...students[0],monthlyValue:'-10'}]}).missingCount,1);
assert.equal(build({students:[{...students[0],monthlyValue:'1000001'}]}).missingCount,1);
assert.equal(build({students:[],payments:[{id:'a',amount:0.1,paidAt:'2026-10-02T12:00:00Z'},{id:'b',amount:0.2,paidAt:'2026-10-02T12:00:00Z'}]}).receivedCents,30,'cent totals are exact');
assert.equal(build({payments:[{id:'edge',amount:'20',paidAt:'2026-11-01T03:59:59Z'}]},'2026-11-01T00:01:00-04:00').receivedCents,0,'receipt stays in local October');
assert.equal(build({payments:[{id:'edge',amount:'20',paidAt:'2026-11-01T04:00:00Z'}]},'2026-11-01T00:01:00-04:00').receivedCents,2000,'local November starts at midnight');
assert.equal(build({students:[students.at(-1)]},'2026-11-01T00:01:00-04:00').forecastCents,10000,'future enrolment joins forecast in its start month');
const safe=JSON.stringify(fixture);build(fixture);assert.equal(JSON.stringify(fixture),safe,'projection does not mutate source data');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(root,'app/src/main/assets/professor.html')))});
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});try{
 const ctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,timezoneId:'America/Cuiaba'});await ctx.route(/^https:\/\//,r=>r.abort());
 await ctx.addInitScript(fixture=>{
  const RealDate=Date;window.__clock=RealDate.parse('2026-10-17T12:00:00-04:00');window.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[__clock]))}static now(){return __clock}};
  if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(fixture));
  const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.__failSave&&k==='agendaPersonalTL_v1')throw Error('quota');return set.call(this,k,v)};
 },fixture);
 const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());await page.goto('http://127.0.0.1:'+server.address().port);await page.evaluate(()=>{showScreen('finance');setFinanceView('all')});
 const text=id=>page.locator('#'+id).innerText(),amount=async(id,value)=>assert.equal((await text(id)).replace(/\s/g,''),value.replace(/\s/g,''));
 await amount('financeWalletForecast','R$ 2.230,75');await amount('financeWalletReceived','R$ 1.010,00');assert.match(await page.locator('#financeList [data-student-id="c"]').innerText(),/350,25/);assert.match(await page.evaluate(()=>chargeMessage(studentById('c'))),/350,25/);assert.match(await text('financeWalletMissing'),/1 aluno/);assert.match(await text('financeWalletUnknownReceipts'),/1 pagamento/);
 const before=await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1'));await page.locator('#financeWalletDetails summary').click();assert.equal(await page.locator('[data-wallet-student]').count(),5);
 await page.locator('#financeSearch').fill('Jéssica');await page.evaluate(()=>setFinanceView('overdue'));await amount('financeWalletForecast','R$ 2.230,75');assert.equal(await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1')),before,'filtering/reading does not save anything');
 await page.locator('[data-wallet-student="a"]').click();await page.locator('#studentMonthlyValue').fill('800,75');await page.locator('#studentForm button[type="submit"]').click();await amount('financeWalletForecast','R$ 2.251,50');assert.ok(await page.locator('#financeWalletDetails').getAttribute('open')!==null);
 await page.evaluate(()=>{document.getElementById('financeSearch').value='';setFinanceView('all');markPaymentPaid('b')});await amount('financeWalletReceived','R$ 2.110,50');await amount('financeWalletForecast','R$ 2.251,50');assert.equal(await page.evaluate(()=>studentById('b').dueDate),'2026-11-20','paying does not remove the monthly forecast');
 await page.evaluate(()=>markPaymentPaid('d'));assert.equal(await page.evaluate(()=>state.payments[0].amount),0,'zero amount is saved as zero, not an unknown receipt');assert.match(await text('financeWalletUnknownReceipts'),/1 pagamento/);const paid=await page.evaluate(()=>JSON.stringify(state.payments));await page.evaluate(()=>{__failSave=true;markPaymentPaid('a');__failSave=false});assert.equal(await page.evaluate(()=>JSON.stringify(state.payments)),paid);await amount('financeWalletReceived','R$ 2.110,50');
 await page.evaluate(()=>toggleStudentArchive('c'));assert.equal(await page.evaluate(()=>studentById('c').archived),true,await page.locator('#toast').innerText());await page.evaluate(()=>showScreen('finance'));await amount('financeWalletForecast','R$ 1.901,25');await amount('financeWalletReceived','R$ 2.110,50');assert.equal(await page.evaluate(()=>JSON.stringify(state.payments)),paid,'archiving preserves paid records');
 const base=await page.evaluate(()=>JSON.stringify({students:state.students,payments:state.payments,customData:state.customData,workoutExecutions:state.workoutExecutions}));
 for(const design of ['current','neon-tl','metal-tl','pro-tl','deep-tl'])for(const mode of ['light','dark'])for(const width of [320,390,480]){
  await page.setViewportSize({width,height:844});await page.evaluate(({design,mode})=>{AgendaColors.selectDesign(design);AgendaColors.save({...AgendaColors.get(),primary:'#b3ff22',secondary:'#7540ab',background:mode==='light'?'#f6f5f9':'#0d0e12'});AgendaAppearance.setMode(mode)}, {design,mode});
  assert.ok(await page.locator('#financeWallet').evaluate(n=>n.getBoundingClientRect().right<=innerWidth+1&&n.scrollWidth<=n.clientWidth+1),'wallet fits '+design+' '+mode+' '+width);
  const low=await page.locator('#financeWallet').evaluate(root=>{
   const rgb=c=>c.match(/[\d.]+/g)?.map(Number)||[0,0,0,0],lum=c=>c.slice(0,3).reduce((sum,v,i)=>{const n=v/255;return sum+[.2126,.7152,.0722][i]*(n<=.04045?n/12.92:((n+.055)/1.055)**2.4)},0),ratio=(a,b)=>(Math.max(lum(a),lum(b))+.05)/(Math.min(lum(a),lum(b))+.05);
   return [...root.querySelectorAll('*')].filter(n=>!n.childElementCount&&n.textContent.trim()&&!n.closest('svg')&&n.checkVisibility({checkVisibilityCSS:true})).flatMap(n=>{let bg;for(let p=n;p;p=p.parentElement){const c=rgb(getComputedStyle(p).backgroundColor);if(c.length===3||c[3]===1){bg=c;break}}const s=getComputedStyle(n),size=parseFloat(s.fontSize),limit=4.5,r=ratio(rgb(s.color),bg||[255,255,255]);return r+.01<limit?[{text:n.textContent,ratio:r,limit}]:[]});
  });assert.deepEqual(low,[],design+' '+mode+' text contrast');
 }
 assert.equal(await page.evaluate(()=>JSON.stringify({students:state.students,payments:state.payments,customData:state.customData,workoutExecutions:state.workoutExecutions})),base,'theme does not change financial data');
 if(process.env.AGENDA_FINANCE_QA_DIR){fs.mkdirSync(process.env.AGENDA_FINANCE_QA_DIR,{recursive:true});await page.setViewportSize({width:390,height:844});await page.evaluate(()=>{AgendaColors.selectDesign('deep-tl');AgendaAppearance.setMode('dark');document.getElementById('financeWallet').scrollIntoView()});await page.screenshot({path:path.join(process.env.AGENDA_FINANCE_QA_DIR,'wallet-dark.png')});await page.evaluate(()=>AgendaAppearance.setMode('light'));await page.screenshot({path:path.join(process.env.AGENDA_FINANCE_QA_DIR,'wallet-light.png')})}
 await page.reload();await page.evaluate(()=>showScreen('finance'));await amount('financeWalletForecast','R$ 1.901,25');await amount('financeWalletReceived','R$ 2.110,50');assert.deepEqual(await page.evaluate(()=>state.customData),{keep:92});
 await page.evaluate(()=>{__clock=Date.parse('2026-11-01T00:01:00-04:00');resumeFinanceCountdown()});await amount('financeWalletReceived','R$ 0,00');await amount('financeWalletForecast','R$ 2.001,25');assert.match(await text('financeMonth'),/Novembro/);
 await page.evaluate(()=>openNewStudent());await page.locator('#studentName').fill('Nova aluna com nome completo de teste');await page.locator('#studentType').selectOption('online');await page.locator('#studentMonthlyValue').fill('99,90');await page.locator('#studentForm button[type="submit"]').click();await amount('financeWalletForecast','R$ 2.101,15');
 const newId=await page.evaluate(()=>state.students.find(s=>s.name==='Nova aluna com nome completo de teste').id);await page.evaluate(id=>openEditStudent(id),newId);await page.locator('#studentFinanceEnabled').selectOption('false');await page.locator('#studentForm button[type="submit"]').click();await amount('financeWalletForecast','R$ 2.001,25');
 await page.evaluate(()=>{state.students=[];state.payments=[];renderFinance()});await amount('financeWalletForecast','R$ 0,00');await amount('financeWalletReceived','R$ 0,00');assert.ok(await page.locator('#financeWalletMissing').isHidden());assert.deepEqual(errors,[]);
 console.log('PASS: monthly-fee sums in cents, zero/missing/invalid currency, same names/stable IDs, future starts, archive exclusions and paid snapshots; actual edit/payment/archive/reload, quota rollback, unchanged filters/data, automatic local month rollover, duplicate receipt handling and local month boundaries; 5 designs × 2 modes × 3 widths, contrast >=4.5 and no horizontal overflow. Browser real; native/cloud simulated.');
 }finally{await browser.close();server.close()}}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
