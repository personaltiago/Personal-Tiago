"""Build delivery contract with tool fakes: never claims Android compilation."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import subprocess
import tempfile
import unittest
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('verify_apk', ROOT/'tools/verify_apk.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class Delivery(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='agenda-delivery-')
        cls.base = Path(cls.temp.name)
        cls.repo = cls.base/'arbitrary-repository-name'
        cls.repo.mkdir()
        (cls.repo/'.git').mkdir()
        cls.project = cls.repo/'arbitrary-subfolder'/'AgendaPersonal_AndroidStudio'
        shutil.copytree(ROOT, cls.project, ignore=shutil.ignore_patterns('node_modules', 'build', '__pycache__', '.git', '.gradle'))
        cls.sdk = cls.base/'sdk-with-spaces'
        (cls.sdk/'platforms/android-35').mkdir(parents=True)
        (cls.sdk/'platforms/android-35/android.jar').write_bytes(b'fake-for-build-script-test-only')
        cls.build_tools = cls.sdk/'build-tools/35.0.0'
        cls.build_tools.mkdir(parents=True)
        aapt = cls.build_tools/'aapt'
        aapt.write_text("#!/usr/bin/env python3\nimport os,sys\nif sys.argv[2]=='badging':print(\"package: name='com.tiagolima.agendapersonal' versionCode='\"+os.environ.get('FAKE_VERSION_CODE','148')+\"' versionName='\"+os.environ.get('FAKE_VERSION_NAME','1.148')+\"'\")\nelse:print('android.permission.SYSTEM_ALERT_WINDOW LessonTimerOverlayService')\n")
        aapt.chmod(0o755)
        cls.gradle = cls.base/'gradle-tool'
        cls.gradle.write_text("#!/usr/bin/env python3\nimport os,sys,json,zipfile,pathlib\np=pathlib.Path(sys.argv[sys.argv.index('-p')+1]);out=p/'app/build/outputs/apk/debug';out.mkdir(parents=True,exist_ok=True)\n(pathlib.Path(os.environ['BUILD_LOG'])).write_text(json.dumps({'project':str(p),'args':sys.argv[1:],'java':os.environ['JAVA_HOME']}))\nwith zipfile.ZipFile(out/'app-debug.apk','w',compression=zipfile.ZIP_DEFLATED) as z:\n for name in ['index','professor','avaliacoes','cadastro']:z.write(p/('app/src/main/assets/'+name+'.html'),'assets/'+name+'.html')\n z.writestr('classes.dex',b'not a real DEX; build-script fixture only; LessonTimerOverlayService')\n")
        cls.gradle.chmod(0o755)
        cls.env = dict(os.environ, ANDROID_HOME=str(cls.sdk), ANDROID_SDK_ROOT=str(cls.sdk), AGENDA_GRADLE_EXEC=str(cls.gradle), JAVA_HOME='/usr/lib/jvm/java-17-openjdk-amd64', BUILD_LOG=str(cls.base/'build-log.json'))
        cls.env.pop('ANDROID_VERSION_CODE', None)
        cls.target = cls.repo/'AgendaPersonal-v1.148.apk'

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def run_launcher(self, **overrides):
        return subprocess.run(['bash', str(self.project/'COMPILAR_NO_CODESPACES.sh')], cwd=self.base, env={**self.env, **overrides}, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    def test_01_real_launcher_uses_own_project_and_verified_version(self):
        result = self.run_launcher()
        self.assertEqual(result.returncode, 0, result.stdout)
        self.assertTrue(self.target.is_file())
        log = json.loads((self.base/'build-log.json').read_text())
        self.assertEqual(log['project'], str(self.project))
        self.assertEqual(log['args'][:2], ['-p', str(self.project)])
        self.assertIn('1.148', result.stdout)
        self.assertNotIn('v1.143.apk', result.stdout)
        with ZipFile(self.target) as archive:
            self.assertIn('assets/professor.html', archive.namelist())

    def test_02_wrong_actual_apk_version_never_replaces_previous_apk(self):
        self.target.write_bytes(b'previous-verified-apk')
        result = self.run_launcher(FAKE_VERSION_NAME='1.143')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('não corresponde', result.stdout)
        self.assertEqual(self.target.read_bytes(), b'previous-verified-apk')
        self.assertFalse(self.target.with_name(self.target.name+'.partial').exists())

    def test_03_changed_source_blocked_before_gradle(self):
        file = self.project/'app/build.gradle'
        original = file.read_text()
        log = self.base/'build-log.json'
        log.unlink(missing_ok=True)
        try:
            file.write_text(original.replace("versionName '1.148'", "versionName '1.143'"))
            result = self.run_launcher()
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('não corresponde', result.stdout)
            self.assertFalse(log.exists())
        finally:
            file.write_text(original)

    def test_04_stale_version_code_blocked(self):
        result = self.run_launcher(ANDROID_VERSION_CODE='143')
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('ANDROID_VERSION_CODE', result.stdout)

    def test_05_missing_finance_or_native_code_in_apk_rejected(self):
        release = json.loads((self.project/'release.json').read_text())
        for missing in ['finance', 'native', 'page']:
            file = self.base/('broken-'+missing+'.apk')
            with ZipFile(file, 'w', compression=ZIP_DEFLATED) as archive:
                for page in ['index', 'professor', 'avaliacoes', 'cadastro']:
                    if missing == 'page' and page == 'cadastro':
                        continue
                    data = (self.project/'app/src/main/assets'/ (page+'.html')).read_bytes()
                    if missing == 'finance' and page == 'professor':
                        data = data.replace(b'ap-finance-results-model', b'old-finance')
                    archive.writestr('assets/'+page+'.html', data)
                archive.writestr('classes.dex', b'no overlay' if missing == 'native' else b'LessonTimerOverlayService')
            with self.assertRaises((RuntimeError, KeyError)):
                module.verify(file, self.sdk, release, 148)


if __name__ == '__main__':
    unittest.main(verbosity=2)
