'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path'),root=path.resolve(__dirname,'../web');
const g=vm.createContext({});for(const f of ['student-mascot-model.js','mascot-hit-areas.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),g);g.APMascotBearPoseProfiles=JSON.parse(fs.readFileSync(path.join(root,'bear-pose-landmarks.json'),'utf8'));g.APMascotBear={supports:()=>false};vm.runInContext(fs.readFileSync(path.join(root,'bear-pose-motion.js'),'utf8'),g);
const A=g.APMascotBearPoses,M=g.APMascotModel;let cases=0,min=Infinity,max=-Infinity;
for(const xp of [0,600,1800])for(const pose of ['default','sit','rest'])for(const color of M.colorsFor('panda')){
 const state={...M.fresh(),species:'panda',xp,colors:{panda:color.id},poses:{panda:pose},owned:['pose-panda-'+pose]},p=A.profile(state);assert.ok(A.supports(state));assert.equal(p.pose,pose);assert.ok(p.eyes.every(e=>e.slice(0,2).every(n=>n>0&&n<320)));const snapshots=[];
 for(const kind of ['look','curious','ear','nose','affection','paw','tail']){
  const v=A.values(p,kind,.60,{x:1,y:-.8});snapshots.push(JSON.stringify(v));
  for(let y=0;y<320;y+=8)for(let x=0;x<320;x+=8){const a=A.project(x,y,p,v),b=A.project(x+8,y,p,v),c=A.project(x,y+8,p,v),d=A.project(x+8,y+8,p,v),area=(a,b,c)=>((b[0]-a[0])*(c[1]-a[1])-(c[0]-a[0])*(b[1]-a[1]))/64;for(const z of [area(a,b,c),area(b,d,c)]){min=Math.min(min,z);max=Math.max(max,z);assert.ok(z>.60&&z<1.45,JSON.stringify({xp,pose,color:color.id,kind,z}))}}
  for(let y=Math.ceil(p.head[4]);y<=320;y+=8)for(let x=0;x<=320;x+=8){assert.equal(A.weight(x,y,p),0);assert.deepEqual(Array.from(A.project(x,y,p,v)),[x,y])}
  const reduced=A.values(p,kind,.6,{x:1,y:-1},false,true);for(const k of ['angle','nod','ear','sniff','gx','gy'])assert.equal(reduced[k],0);
  const end=A.values(p,kind,6,{x:1,y:-1});for(const n of Object.values(end))assert.ok(Math.abs(n)<1e-8);
 }
 assert.notEqual(snapshots[0],snapshots[1]);assert.notEqual(snapshots[4],snapshots[5]);assert.equal(A.values(p,'look',.07,{x:1,y:0}).angle,0,'eyes lead head');assert.ok(A.values(p,'look',.07,{x:1,y:0}).gx>0);cases++;
}
assert.equal(cases,54);g.APMascotBear={supports:()=>true};assert.equal(A.supports({...M.fresh(),species:'panda'}),false,'approved R14 engine retains priority');assert.equal(A.supports({...M.fresh(),species:'wolf'}),false);
const integration=fs.readFileSync(path.join(root,'mascot-petting.js'),'utf8');assert.ok(integration.includes("return bearPose(node,state,'affection'"));assert.ok(integration.includes('return bearPose(node,state,kind,zone)'));assert.ok(!integration.slice(integration.indexOf('async function bearPose('),integration.indexOf('async function react(')).includes("setAttribute('href'"),'pose route never replaces selected artwork');
console.log(`PASS: ${cases} bear pose/phase/coat rigs, seven distinct contacts; mesh area ${min.toFixed(3)}..${max.toFixed(3)}, fixed lower body, eye-first attention, reduced motion, neutral return, R14 priority, pose-preserving integration.`);
