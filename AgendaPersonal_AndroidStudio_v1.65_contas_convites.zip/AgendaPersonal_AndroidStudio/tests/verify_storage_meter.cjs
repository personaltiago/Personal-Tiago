'use strict';
// Runs the REAL ap-storage-meter script from professor.html against a fake localStorage and a tiny fake DOM.
// It checks the numbers (usage, percent, levels), the card text and its place in the "Aplicativo e dados" menu.
// The visual result was checked separately in a browser render; this does not run on a physical device.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const file=process.argv[2]||path.join(__dirname,'..','web','native-release.agenda.json');
const html=JSON.parse(fs.readFileSync(file,'utf8')).files['professor.html'];
const m=html.match(/<script id="ap-storage-meter">([\s\S]*?)<\/script>/);assert.ok(m,'Cartão Armazenamento ausente no professor.html');
let cases=0;const eq=(n,a,b)=>{cases++;assert.deepEqual(a,b,n)},ok=(n,v)=>{cases++;assert.ok(v,n)};
const organizer=html.match(/<script id="ap-more-organization">([\s\S]*?)<\/script>/)[1];
ok('cartão registrado no grupo Aplicativo e dados, entre Backup e Sincronizar',/moreFullBackup:\['app',1,'menu-backup'\],moreStorage:\['app',1\.5,'menu-storage'\],moreTeacherSync:\['app',2/.test(organizer));
const glyphs=html.match(/<script id="ap-more-menu-glyphs">([\s\S]*?)<\/script>/)[1];const g={};new Function('window',glyphs)(g);
eq('ícone do cartão existe',typeof g.APMoreMenuGlyphs['menu-storage'],'string');
function fakeEl(tag){const e={tag,children:[],attrs:{},style:{},classList:{},innerHTML:'',textContent:'',className:'',listeners:{},
 setAttribute(k,v){e.attrs[k]=v},append(...c){e.children.push(...c)},prepend(...c){e.children.unshift(...c)},replaceChildren(...c){e.children=c},
 addEventListener(t,f){e.listeners[t]=f},querySelector(s){return(e.q||(e.q={}))[s]||(e.q[s]=fakeEl('q'+s))},showModal(){e.opened=true},close(){e.opened=false}};
 e.firstElementChild=fakeEl2();return e}
function fakeEl2(){return{style:{}}}
function run(entries){
 const store=new Map(Object.entries(entries));
 const localStorage={get length(){return store.size},key:i=>[...store.keys()][i],getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,String(v))};
 const pet=fakeEl('button');pet.className='more-function more-function-primary';pet.parentElement=fakeEl('div');
 const doc={createElement:fakeEl,getElementById:id=>id==='morePet'?pet:null,head:fakeEl('head'),body:fakeEl('body')};
 const win={addEventListener(){},parent:{addEventListener(){}}};
 const sandbox={document:doc,window:win,localStorage,navigator:{},Math,Object,Array,Map,JSON,String,Number,Error,console};
 sandbox.globalThis=sandbox;vm.createContext(sandbox);vm.runInContext(m[1],sandbox);
 return{api:win.APStorageMeter,pet,dialog:doc.body.children[0]};
}
// 1. Measurement: key + value characters, grouped by kind
const big='x'.repeat(1400000-'agendaPersonalTL_v1'.length);
let r=run({agendaPersonalTL_v1:big});
eq('mede chave + valor em caracteres',r.api.measure().total,1400000);
eq('28% de 5 milhões',r.api.percent(1400000),28);
eq('arredonda e limita em 100%',[r.api.percent(0),r.api.percent(2500000),r.api.percent(9999999)],[0,50,100]);
// 2. Levels
eq('níveis de aviso',[10,49,50,69,70,89,90,100].map(p=>r.api.level(p)),['ok','ok','ok','ok','warn','warn','crit','crit']);
// 3. Groups never expose account ids
r=run({agendaPersonalTL_v1:'a'.repeat(1000),ap_professor_marca_159_x:'b'.repeat(500),['agenda_progress_teacher_v1_UID123_ABC']:'c'.repeat(200),agenda_teacher_mascot_v1_UID123:'d'.repeat(50),outro:'e'.repeat(10)});
const groups=Object.fromEntries(r.api.measure().groups);
eq('grupos legíveis',Object.keys(groups).sort(),['Agenda, alunos e treinos','Marca e fotos do professor','Mascote','Preferências e outros','Progresso dos alunos'].sort());
ok('nenhum rótulo mostra id de conta',Object.keys(groups).every(k=>!/UID123|agenda_progress|ap_professor/.test(k)));
// 4. Card is created in the menu and shows percent
r=run({agendaPersonalTL_v1:big});
const card=r.pet.parentElement.children[0];
ok('cartão criado com id moreStorage',card&&card.id==='moreStorage');
ok('cartão sem destaque primário do Mascote',!/more-function-primary/.test(card.className));
ok('título em português',/<strong>Armazenamento<\/strong>/.test(card.innerHTML));
// 5. Failure to read storage does not throw
const broken={get length(){throw Error('bloqueado')}};
const s2=vm.createContext({document:{createElement:fakeEl,getElementById:()=>null,head:fakeEl('h'),body:fakeEl('b')},window:{addEventListener(){}},localStorage:broken,navigator:{},Math,Object,Array,Map,JSON,String,Number,Error});
vm.runInContext(m[1],s2);eq('armazenamento bloqueado devolve null',s2.window.APStorageMeter.measure(),null);
// 6. Read-only: the script never writes
ok('o cartão só lê o armazenamento',!/localStorage\.(setItem|removeItem|clear)/.test(m[1]));
console.log('Cartão Armazenamento: '+cases+' verificações passaram (medição, níveis, grupos sem ids, cartão no menu). Sem aparelho físico.');
