'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const box={};vm.createContext(box);vm.runInContext(fs.readFileSync('web/icon-material-model.js','utf8'),box);
const palette=box.APIconMaterial.palette,asRgb=hex=>hex.slice(1).match(/../g).map(v=>parseInt(v,16));
function hue(hex){const [r,g,b]=asRgb(hex),hi=Math.max(r,g,b),lo=Math.min(r,g,b),d=hi-lo;if(!d)return null;return ((hi===r?(g-b)/d:hi===g?(b-r)/d+2:(r-g)/d+4)*60+360)%360}
function distance(a,b){return Math.min(Math.abs(a-b),360-Math.abs(a-b))}
for(const color of ['#b7f522','#19945f','#2872e8','#a12cff','#f55da9','#f2b945','#00aaaa','#ff3300']){
 const p=palette(color);assert.equal(Object.keys(p).length,6);let previous=-1;
 for(const key of ['deep','low','mid','upper','rim','light']){assert.match(p[key],/^#[a-f0-9]{6}$/);const rgb=asRgb(p[key]),l=(Math.min(...rgb)+Math.max(...rgb))/2;assert.ok(l>previous,'tonal scale remains ordered');previous=l;assert.ok(distance(hue(color),hue(p[key]))<3,'same hue '+color+' '+p[key])}
 const rgb=asRgb(p.mid);assert.ok(Math.max(...rgb)<120,'matte midtone remains restrained');assert.notEqual(p.mid,color);
}
const green=asRgb(palette('#b7f522').mid);assert.ok(green[1]>green[0]&&green[0]>green[2],'lime theme becomes a matte green/olive material');
for(const color of ['#000000','#ffffff','#808080']){const [r,g,b]=asRgb(palette(color).mid);assert.equal(r,g);assert.equal(g,b)}
assert.equal(palette('bad').mid,palette('#542187').mid);assert.equal(palette(null).mid,palette('#542187').mid);
// Actual renderer is tested with lightweight DOM nodes to exercise live palette updates.
const values=new Map([['--mm-mid','#b7f522']]),elements=new Map(),listeners=new Map();
function element(tag){return {tag,children:[],attrs:{},style:{},setAttribute(k,v){this.attrs[k]=v;if(k==='id')this.id=v},getAttribute(k){return this.attrs[k]??null},append(...nodes){this.children.push(...nodes);for(const n of nodes)if(n.id)elements.set(n.id,n)}}}
const root={style:{getPropertyValue:k=>values.get(k)||'',setProperty:(k,v)=>values.set(k,v)}},body=element('body');
box.document={documentElement:root,body,readyState:'complete',getElementById:k=>elements.get(k)||null,createElementNS:(_,tag)=>element(tag)};box.window=box;box.addEventListener=(k,fn)=>listeners.set(k,fn);box.requestAnimationFrame=fn=>fn();box.MutationObserver=class{constructor(fn){this.fn=fn}observe(){}};
vm.runInContext(fs.readFileSync('web/deep-icon-palette.js','utf8'),box);
function walk(e){return [e,...e.children.flatMap(walk)]}function functions(id){const node=walk(body).find(n=>n.id===id);assert.ok(node,id);return walk(node).filter(n=>['feFuncR','feFuncG','feFuncB'].includes(n.tag)).map(n=>n.attrs.tableValues)}
const first=functions('ap-deep-matte-purple');assert.equal(values.get('--ap-matte-mid'),palette('#b7f522').mid);assert.ok(first[1].split(' ').map(Number).every((v,i)=>v>=Number(first[2].split(' ')[i])),'green transfer curve contains no purple channel cast');
const semantic=functions('ap-deep-matte-danger'),neutral=functions('ap-deep-matte-neutral');
values.set('--mm-mid','#2872e8');listeners.get('agenda-colors-change')();const next=functions('ap-deep-matte-purple');assert.notDeepEqual(next,first);assert.equal(values.get('--ap-matte-mid'),palette('#2872e8').mid);assert.deepEqual(functions('ap-deep-matte-danger'),semantic);assert.deepEqual(functions('ap-deep-matte-neutral'),neutral);
console.log('PASS: selected hue retained across 8 accent colors, restrained matte tonal scale, grayscale/fallback, green vector variables and bitmap transfer curve, live palette update and semantic/inactive colors preserved.');
