const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const runtime = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/') : require;
const { chromium } = runtime('playwright');
const assets = path.resolve(__dirname, '../app/src/main/assets');
const fixture = {
  students: [{ id: 'a', name: 'Aluno igual', studentType: 'presencial', phone: '69911111111', photoDataUrl: '' }, { id: 'b', name: 'Aluno igual', studentType: 'online', phone: '69922222222' }],
  lessons: [], occurrenceStatus: {}, history: [], payments: [], lessonTimers: {},
  workoutPlans: [{ id: 'p', studentId: 'a', name: 'Ficha Outubro', goal: 'Objetivo definido pelo treinador', level: 'Intermediário', startDate: '2026-10-06', endDate: '2026-11-06', organization: 'week', age: '35', sex: 'feminino', weight: '59', height: '170', currentLevel: 'Operacional', visibility: 'always', days: [
    { id: 'd', name: 'DIA A · QUADRÍCEPS + GLÚTEOS', weekday: 1, notes: 'Orientações gerais deste treino', exercises: [
      { id: 'ex', name: 'Agachamento Hack', sets: '3', reps: '10–12', load: '50 kg', rest: '75 s', muscle: 'Inferiores', category: 'Musculação', notes: 'Instruções definidas pelo treinador', observations: 'Observação individual', video: 'https://youtu.be/M7lc1UVf-VE' },
    ] },
  ] }], workoutExecutions: [], workoutDrafts: {}, customData: { preserved: true },
};
const server = http.createServer((req, res) => {
  const file = path.join(assets, new URL(req.url, 'http://localhost').pathname);
  if (!file.startsWith(assets + path.sep) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', file.endsWith('.html') ? 'text/html;charset=utf-8' : 'application/octet-stream'); res.end(fs.readFileSync(file));
});
async function init(context, data = fixture) {
  await context.addInitScript(data => {
    if (!localStorage.getItem('agendaPersonalTL_v1')) localStorage.setItem('agendaPersonalTL_v1', JSON.stringify(data));
    const set = Storage.prototype.setItem;
    Storage.prototype.setItem = function(key, value) { if (key === 'agendaPersonalTL_v1') { if (window.__failSave) throw new Error('quota'); if (window.__failRestConfirmation && JSON.parse(value).workoutRest?.native) { window.__failRestConfirmation = false; throw new Error('quota'); } } return set.call(this, key, value); };
    window.Android = { syncLessonAlarms(json) { window.__snapshot = JSON.parse(json); return true; }, getAlarmStatus() { return '{"ready":true}'; }, openInlineYouTubeVideo(json) { __video = JSON.parse(json); return true; }, positionInlineYouTubeVideo(){},closeInlineYouTubeVideo(){},startWorkoutRest(json) { window.__rest = JSON.parse(json); return !window.__restRejected; }, cancelWorkoutRest() { window.__cancelRest = (window.__cancelRest || 0) + 1; return true; } };
  }, data);
  await context.route('https://i.ytimg.com/**', route => route.fulfill({ status: 200, contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="480" height="270"><rect width="480" height="270" fill="#2c1938"/></svg>' }));
}
async function close(page, id) { await page.locator('#' + id + ' .close').click(); }
async function fits(page) {
  assert.equal(await page.evaluate(() => {
    if (document.documentElement.scrollWidth > innerWidth + 1) return 'page overflow';
    for (const button of document.querySelectorAll('.workout-sheet button, #screen-workouts button')) {
      if (!button.getClientRects().length || button.closest('[inert]')) continue;
      const box = button.getBoundingClientRect();
      if (box.x < 0 || box.right > innerWidth + 1 || box.height < 44 || button.scrollWidth > button.clientWidth + 1) return button.textContent;
    }
    return '';
  }), '');
}
async function openStudent(page) { await page.evaluate(()=>showScreen('workouts')); await page.locator('.workout-student-choice[data-student-id="a"]').click(); }
async function main() {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ executablePath: process.env.AGENDA_CHROMIUM || path.resolve('work/alarm_review/browser/chromium'), headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const errors = [];
  try {
    const context = await browser.newContext({ viewport: { width: 414, height: 900 }, isMobile: true, hasTouch: true, timezoneId: 'America/Cuiaba' }); await init(context);
    const page = await context.newPage(); page.setDefaultTimeout(7000); page.on('pageerror', error => errors.push(error.message)); page.on('dialog', dialog => dialog.accept());
    await page.goto('http://127.0.0.1:' + server.address().port + '/professor.html'); await openStudent(page);
    assert.deepEqual(await page.evaluate(() => __snapshot.students), []); assert.deepEqual(await page.evaluate(() => __snapshot.workoutStudents.map(s => s.id)), ['a', 'b']);
    assert.deepEqual(await page.evaluate(()=>{const p=currentWorkoutPlan();return [p.age,p.weight,p.height]}),['35','59','170']);
    await page.evaluate(()=>openWorkoutAudience()); assert.equal(await page.locator('#workoutAudienceContent input:not(:disabled)').count(), 0); assert.match(await page.locator('#workoutAudienceContent').innerText(), /DIA A/); await fits(page); await close(page, 'workoutAudienceDialog');
    await page.getByRole('button', { name: 'Editar ficha', exact: true }).click(); await page.locator('#workoutPlanVisibility').selectOption('hidden'); await page.locator('#workoutPlanForm').getByRole('button', { name: 'Salvar ficha', exact: true }).click();
    await page.evaluate(()=>openWorkoutAudience()); assert.match(await page.locator('#workoutAudienceContent').innerText(), /indisponível/); await close(page, 'workoutAudienceDialog');
    await page.getByRole('button', { name: 'Editar ficha', exact: true }).click(); await page.locator('#workoutPlanVisibility').selectOption('period'); await page.locator('#workoutPlanStart').fill('2026-11-01'); await page.locator('#workoutPlanForm').getByRole('button', { name: 'Salvar ficha', exact: true }).click();
    await page.evaluate(()=>openWorkoutAudience()); assert.match(await page.locator('#workoutAudienceContent').innerText(), /indisponível/); await close(page, 'workoutAudienceDialog');
    await page.getByRole('button', { name: 'Editar ficha', exact: true }).click(); await page.locator('#workoutPlanVisibility').selectOption('always'); await page.locator('#workoutPlanStart').fill('2026-10-06'); await page.locator('#workoutPlanForm').getByRole('button', { name: 'Salvar ficha', exact: true }).click();
    await close(page, 'workoutStudentDialog'); await page.evaluate(()=>openWorkoutCatalog());
    assert.equal(await page.locator('.workout-catalog-card').count(), 48); assert.match(await page.locator('#workoutCatalogCount').innerText(), /^714 exercícios/);
    await page.locator('#workoutCatalogMuscle').selectOption('Abdômen'); assert.equal(await page.locator('.workout-catalog-card').count(), 48); assert.match(await page.locator('#workoutCatalogCount').innerText(), /^76 exercícios/);
    await page.locator('#workoutCatalogCategory').selectOption('Funcional'); assert.equal(await page.locator('.workout-catalog-card').count(), 22);
    await page.locator('#workoutCatalogSearch').fill('dead'); assert.equal(await page.locator('.workout-catalog-card').count(), 2);
    await page.getByRole('button', { name: 'Favorito: Abdominal Dead Bug', exact: true }).click(); await page.locator('#workoutCatalogFavorites').click(); assert.equal(await page.locator('.workout-catalog-card').count(), 1);
    await page.getByRole('button', { name: 'Limpar filtros', exact: true }).click(); await page.getByRole('button', { name: '+ Criar exercício', exact: true }).click();
    await page.locator('#workoutExerciseName').fill('Meu exercício <&>'); await page.locator('#workoutExerciseMuscle').selectOption('Inferiores'); await page.locator('#workoutExerciseCategory').selectOption('Musculação');
    await page.locator('#workoutExerciseVideo').fill('youtu.be/M7lc1UVf-VE?t=1m'); await page.locator('#workoutVideoPreview').click(); assert.equal(await page.evaluate(() => __video.startSeconds), 60); await close(page, 'workoutVideoDialog');
    await page.locator('#workoutExerciseNotes').fill('Instruções próprias'); await page.locator('#workoutExerciseObservations').fill('Observação própria'); await page.locator('#workoutExerciseFavorite').check();
    const beforeFailure = await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1')); await page.evaluate(() => __failSave = true); await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click(); assert.equal(await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1')), beforeFailure); assert.ok(await page.locator('#workoutExerciseDialog').isVisible());
    await page.evaluate(() => __failSave = false); await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click(); assert.equal(await page.locator('.workout-catalog-card').count(), 1); const catalogId = await page.evaluate(() => state.exerciseCatalog[0].id);
    await close(page, 'workoutCatalogDialog'); await openStudent(page); await page.locator('[data-day-id="d"]').getByRole('button', { name: 'Abrir treino', exact: true }).click();
    assert.ok(await page.locator('#workoutDayContent [data-series-exercise="ex"] input[type=checkbox]').first().isDisabled()); await page.getByRole('button', { name: '+ Exercício', exact: true }).click();
    await page.getByRole('button', { name: 'Escolher no catálogo de exercícios', exact: true }).click(); await page.locator('#workoutCatalogMine').click(); await page.locator(`[data-catalog-id="${catalogId}"]`).getByRole('button', { name: 'Usar no exercício', exact: true }).click();
    assert.equal(await page.locator('#workoutExerciseName').inputValue(), 'Meu exercício <&>'); assert.equal(await page.locator('#workoutExerciseMuscle').inputValue(), 'Inferiores'); await page.locator('#workoutExerciseSets').fill('3'); await page.locator('#workoutExerciseReps').fill('10'); await page.locator('#workoutExerciseLoad').fill('20 kg'); await page.locator('#workoutExerciseRest').fill('1:15'); await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click();
    assert.equal(await page.evaluate(() => currentWorkoutDay().exercises.length), 2); assert.equal(await page.evaluate(() => state.workoutPlans.filter(p => p.studentId === 'b').length), 0);
    await page.getByRole('button', { name: '+ Exercício', exact: true }).click(); await page.getByRole('button', { name: 'Escolher no catálogo de exercícios', exact: true }).click(); await page.getByRole('button', { name: '+ Criar exercício', exact: true }).click(); await page.locator('#workoutExerciseName').fill('Novo pelo catálogo'); assert.ok(await page.locator('#workoutExerciseName').isEditable()); await close(page, 'workoutExerciseDialog'); assert.equal(await page.evaluate(() => currentWorkoutDay().exercises.length), 2);
    await page.getByRole('button',{name:'Iniciar treino presencial',exact:true}).click();
    const startedAt=await page.evaluate(()=>state.workoutDrafts['p|d'].startedAt);assert.ok(startedAt>0);
    await page.evaluate(()=>openWorkoutRest('ex',true));assert.equal(await page.evaluate(()=>__rest.seconds),75);assert.equal(await page.evaluate(()=>state.workoutRest.native),true);
    const restId=await page.evaluate(()=>state.workoutRest.id);await close(page,'workoutRestDialog');assert.ok(await page.locator('#workoutRestNotice').isVisible());
    await page.reload();await openStudent(page);await page.evaluate(()=>openWorkoutDay('d'));assert.equal(await page.evaluate(()=>state.workoutDrafts['p|d'].startedAt),startedAt);assert.equal(await page.evaluate(()=>state.workoutRest.id),restId);
    const beforeRestart=await page.evaluate(()=>JSON.stringify(state));await page.evaluate(()=>{__failSave=true;startWorkoutSession(true)});assert.equal(await page.evaluate(()=>JSON.stringify(state)),beforeRestart);await page.evaluate(()=>{__failSave=false;startWorkoutSession(true)});assert.equal(await page.evaluate(()=>state.workoutRest),null);assert.ok(await page.evaluate(()=>__cancelRest>0));
    await page.evaluate(()=>openWorkoutRest('ex',true));const beforeRest=await page.evaluate(()=>state.workoutRest.id);
    await page.evaluate(()=>__failSave=true);await page.locator('#workoutRestStart').click();assert.equal(await page.evaluate(()=>state.workoutRest.id),beforeRest);
    await page.evaluate(()=>{__failSave=false;__failRestConfirmation=true});await page.locator('#workoutRestStart').click();assert.equal(await page.evaluate(()=>state.workoutRest.native),false);assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')).workoutRest.native),false);
    await page.evaluate(()=>__restRejected=true);await page.locator('#workoutRestStart').click();assert.equal(await page.evaluate(()=>state.workoutRest.native),false);
    await page.evaluate(()=>{__restRejected=false;stopWorkoutRest()});assert.equal(await page.evaluate(()=>state.workoutRest),null);
    await close(page,'workoutRestDialog');await page.evaluate(()=>stopWorkoutSession());assert.equal(await page.evaluate(()=>state.workoutExecutions.length),0);
    assert.deepEqual(await page.evaluate(()=>state.customData),fixture.customData);assert.equal(await page.evaluate(()=>state.workoutPlans.filter(p=>p.studentId==='b').length),0);
    assert.deepEqual(errors,[]);console.log('PASS: plan demographics retained, student visibility/period respected, catalog filters/favorites/reuse and video preview, quota rollback, independent prescriptions, native rest scheduling, reload, restart rollback, failed native acknowledgement cancellation and no invented execution. Native/media simulated.');
  }finally{await browser.close();server.close()}
}
main().catch(e=>{console.error(e);server.close();process.exitCode=1});
