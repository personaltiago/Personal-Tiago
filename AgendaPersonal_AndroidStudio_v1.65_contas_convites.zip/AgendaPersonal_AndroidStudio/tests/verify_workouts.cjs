const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const runtime = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
  ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/') : require;
const { chromium } = runtime('playwright');
const assets = path.resolve(__dirname, '../app/src/main/assets');
const fixture = {
  students: [
    { id: 'a', name: 'Jéssica Silva', phone: '69999991111', studentType: 'presencial', photoDataUrl: '' },
    { id: 'b', name: 'Jéssica Silva', phone: '69999992222', studentType: 'online', photoDataUrl: '' },
  ],
  lessons: [{ id: 'lesson', studentId: 'a', date: '2026-10-06', time: '16:45', duration: 90, lead: 15, repeat: 'none', location: 'Local salvo', type: 'Treino individual' }],
  history: [], payments: [{ id: 'paid', studentId: 'a', dueDate: '2026-10-01', paidAt: '2026-10-01T12:00:00Z' }],
  occurrenceStatus: {}, customData: { preserve: true }, lessonTimers: {},
};
const server = http.createServer((req, res) => {
  const file = path.join(assets, new URL(req.url, 'http://localhost').pathname);
  if (!file.startsWith(assets + path.sep) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', file.endsWith('.html') ? 'text/html;charset=utf-8' : 'application/octet-stream');
  res.end(fs.readFileSync(file));
});
async function init(context, data) {
  await context.addInitScript(data => {
    if (!localStorage.getItem('agendaPersonalTL_v1')) localStorage.setItem('agendaPersonalTL_v1', JSON.stringify(data));
    const RealDate = Date, now = RealDate.parse('2026-10-06T12:00:00-04:00');
    window.Date = class extends RealDate { constructor(...args) { super(...(args.length ? args : [now])); } static now() { return now; } };
    const original = Storage.prototype.setItem;
    Storage.prototype.setItem = function(k, v) {
      if (window.__failWorkoutSave && k === 'agendaPersonalTL_v1') throw new DOMException('Quota exceeded', 'QuotaExceededError');
      return original.call(this, k, v);
    };
    window.Android = {
      syncLessonAlarms(json) { window.__alarms = JSON.parse(json); return true; },
      getAlarmStatus() { return JSON.stringify({ ready: true, issue: '' }); },
      openWhatsApp(phone) { window.__whats = phone; },
    };
  }, data);
}
async function core(page) { return page.evaluate(() => JSON.stringify({ students: state.students, lessons: state.lessons, payments: state.payments, lessonTimers: state.lessonTimers, customData: state.customData })); }
async function fits(page) {
  assert.equal(await page.evaluate(() => {
    if (document.documentElement.scrollWidth > innerWidth + 1) return 'Horizontal page overflow';
    for (const node of document.querySelectorAll('.nav button, #screen-workouts button, .workout-sheet button, .workout-exercise input, .workout-sheet summary')) {
      if (!node.getClientRects().length || node.closest('[inert]')) continue;
      const box = node.getBoundingClientRect();
      if (box.x < -1 || box.right > innerWidth + 1) return 'Outside screen: ' + node.textContent;
      if (node.tagName === 'BUTTON' && box.height < 44) return 'Small button: ' + node.textContent;
      if (node.tagName === 'BUTTON' && node.scrollWidth > node.clientWidth + 1) return 'Clipped button: ' + node.textContent;
    }
    return '';
  }), '');
}
async function close(page, dialog) { await page.locator('#' + dialog + ' .close').click(); }
async function newPlan(page, name, sequence = false) {
  await page.locator('#workoutStudentContent').getByRole('button', { name: /Criar ficha|Nova ficha/ }).click();
  await page.locator('#workoutPlanName').fill(name);
  await page.locator('#workoutPlanGoal').fill('Hipertrofia');
  await page.locator('#workoutPlanLevel').selectOption('Intermediário');
  if (sequence) await page.locator('#workoutPlanOrganization').selectOption('sequence');
  await page.locator('#workoutPlanForm').getByRole('button', { name: 'Salvar ficha', exact: true }).click();
  return page.evaluate(() => workoutPlanId);
}
async function newDay(page, name, weekday) {
  await page.locator('#workoutStudentContent').getByRole('button', { name: 'Adicionar treino', exact: true }).click();
  await page.locator('#workoutDayName').fill(name);
  if (weekday != null) await page.locator('#workoutDayWeekday').selectOption(String(weekday));
  await page.locator('#workoutDayNotes').fill('Respeitar as orientações individuais do aluno.');
  await page.locator('#workoutDayForm').getByRole('button', { name: 'Salvar treino', exact: true }).click();
  return page.evaluate(() => currentWorkoutPlan().days.at(-1).id);
}
async function newExercise(page, name, load) {
  await page.locator('#workoutDayContent').getByRole('button', { name: '+ Exercício', exact: true }).click();
  await page.locator('#workoutExerciseName').fill(name);
  await page.locator('#workoutExerciseSets').fill('3');
  await page.locator('#workoutExerciseReps').fill('10–12');
  await page.locator('#workoutExerciseLoad').fill(load);
  await page.locator('#workoutExerciseRest').fill('60 s');
  await page.locator('#workoutExerciseNotes').fill('Orientações salvas para este exercício.');
  await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click();
  return page.evaluate(() => currentWorkoutDay().exercises.at(-1).id);
}
async function main(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const errors=[];
 try{
  const context=await browser.newContext({viewport:{width:393,height:852},isMobile:true,hasTouch:true});await init(context,fixture);
  const page=await context.newPage();page.setDefaultTimeout(7000);page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
  await page.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await page.evaluate(()=>showScreen('workouts'));
  const baseline=await core(page);await page.locator('.workout-student-choice[data-student-id="b"]').click();
  const plan=await newPlan(page,'Ficha Outubro <&>');
  const dayA=await newDay(page,'DIA A · PERNAS',1),dayB=await newDay(page,'DIA B · COSTAS',2);
  await page.getByRole('button',{name:'Reordenar treinos',exact:true}).click();await page.locator(`#workoutOrderList [data-order-key="day:${dayB}"] button`).press('Home');await page.getByRole('button',{name:'Finalizar ordenação',exact:true}).click();
  assert.deepEqual(await page.evaluate(()=>currentWorkoutPlan().days.map(d=>d.id)),[dayB,dayA]);
  await page.evaluate(id=>openWorkoutDay(id),dayA);
  const hip=await newExercise(page,'Elevação de quadril na máquina','20 kg'),stiff=await newExercise(page,'Stiff com halteres','12 kg');
  await page.getByRole('button',{name:'Reordenar exercícios',exact:true}).click();await page.locator(`#workoutOrderList [data-order-key="exercise:${stiff}"] button`).press('Home');await page.getByRole('button',{name:'Finalizar ordenação',exact:true}).click();
  assert.deepEqual(await page.evaluate(()=>currentWorkoutDay().exercises.map(e=>e.id)),[stiff,hip]);
  const prescriptions=await page.evaluate(()=>JSON.parse(JSON.stringify(currentWorkoutDay().exercises)));
  assert.equal(prescriptions.find(e=>e.id===hip).load,'20 kg');
  await page.evaluate(id=>openWorkoutExerciseEditor(id),hip);await page.locator('#workoutExerciseLoad').fill('50 kg');await page.locator('#workoutExerciseForm button[type=submit]').click();
  assert.equal(await page.evaluate(id=>currentWorkoutDay().exercises.find(e=>e.id===id).load,hip),'50 kg');
  assert.equal(await page.evaluate(()=>state.workoutExecutions.length),0);assert.equal(await core(page),baseline);
  const before=await page.evaluate(()=>JSON.stringify(state));await page.evaluate(()=>window.__failWorkoutSave=true);await page.evaluate(id=>openWorkoutExerciseEditor(id),hip);await page.locator('#workoutExerciseLoad').fill('99 kg');await page.locator('#workoutExerciseForm button[type=submit]').click();assert.equal(await page.evaluate(()=>JSON.stringify(state)),before);await page.evaluate(()=>window.__failWorkoutSave=false);await close(page,'workoutExerciseDialog');
  await close(page,'workoutDayDialog');await page.evaluate(()=>{openWorkoutAudience();document.querySelectorAll('#workoutAudienceContent details').forEach(d=>d.open=true)});assert.match(await page.locator('#workoutAudienceContent').innerText(),/50 kg/);assert.equal(await page.locator('#workoutAudienceContent [contenteditable=true]').count(),0);await close(page,'workoutAudienceDialog');
  await page.getByRole('button',{name:'Arquivar ficha',exact:true}).click();assert.equal(await page.evaluate(id=>workoutPlanArchived(state.workoutPlans.find(p=>p.id===id)),plan),true);
  await page.evaluate(id=>openArchivedWorkoutPlan(id),plan);assert.ok(await page.getByRole('button',{name:'Editar ficha',exact:true}).isDisabled());await page.getByRole('button',{name:'Reativar ficha',exact:true}).click();
  assert.equal(await page.evaluate(id=>workoutPlanArchived(state.workoutPlans.find(p=>p.id===id)),plan),false);
  assert.equal(await page.evaluate(()=>state.workoutPlans.filter(p=>p.studentId==='a').length),0);assert.equal(await core(page),baseline);await fits(page);
  await page.reload();await page.evaluate(()=>{showScreen('workouts');openWorkoutStudent('b')});await page.evaluate(id=>selectWorkoutPlan(id),plan);assert.deepEqual(await page.evaluate(()=>currentWorkoutPlan().days.map(d=>d.id)),[dayB,dayA]);
  assert.equal(await core(page),baseline);assert.deepEqual(errors,[]);
  console.log('PASS: real teacher UI creates plans/days/exercises, isolates students with identical names, reorders through current keyboard/confirmation controls, edits prescriptions, rolls back quota failures, previews safely, archives/reactivates and reloads while preserving students, lessons and payments. Detailed execution coverage is in verify_series, verify_bisets and verify_student_execution.');
 }finally{await browser.close();server.close()}
}
main().catch(e=>{console.error(e);server.close();process.exitCode=1});
