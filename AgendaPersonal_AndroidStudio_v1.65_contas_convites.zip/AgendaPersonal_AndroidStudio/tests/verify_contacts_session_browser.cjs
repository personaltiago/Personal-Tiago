'use strict';
// Real Firebase authentication and storage; identity endpoints and contact rows
// are local fixtures. No real account, contact, approval or email is accessed.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const project=path.resolve(__dirname,'..');
const assets=process.env.AGENDA_CONTACTS_BUNDLE?JSON.parse(fs.readFileSync(process.env.AGENDA_CONTACTS_BUNDLE,'utf8')).files:Object.fromEntries(['index','professor','avaliacoes','cadastro'].map(n=>[n+'.html',fs.readFileSync(path.join(project,'app/src/main/assets',n+'.html'),'utf8')]));
const teacher='R2EmnDVcvMWt7TjPxOP6DjW1VOn1',email='teacher@example.test';
const user={localId:teacher,email,displayName:'Professor de teste',emailVerified:true,providerUserInfo:[{providerId:'password',email,federatedId:email,rawId:email}],createdAt:String(Date.now()-1000),lastLoginAt:String(Date.now())};
const now=Math.floor(Date.now()/1000);
const token=[{alg:'RS256',typ:'JWT'},{iss:'https://securetoken.google.com/agenda-personal-bdb58',aud:'agenda-personal-bdb58',auth_time:now,user_id:teacher,sub:teacher,iat:now,exp:now+3600,email,firebase:{identities:{email:[email]},sign_in_provider:'password'}},'offline-fixture'].map((v,i)=>i===2?v:Buffer.from(JSON.stringify(v)).toString('base64url')).join('.');

async function run(remember){
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||chromium.executablePath(),headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--single-process']});
 try{
  const context=await browser.newContext({viewport:{width:393,height:852},isMobile:true,hasTouch:true});
  const remoteSdk=[];
  await context.route('**/*',async route=>{
   const url=new URL(route.request().url());
   if(url.hostname==='appassets.androidplatform.net'){
    const name=url.pathname.split('/').pop()||'index.html';
    return assets[name]?route.fulfill({contentType:'text/html',body:assets[name]}):route.abort();
   }
   if(url.hostname==='www.gstatic.com'&&url.pathname.includes('firebasejs'))remoteSdk.push(url.pathname);
   if(url.hostname==='identitytoolkit.googleapis.com'){
    if(url.pathname.endsWith('accounts:signInWithPassword'))return route.fulfill({json:{kind:'identitytoolkit#VerifyPasswordResponse',localId:teacher,email,displayName:user.displayName,idToken:token,registered:true,refreshToken:'offline-refresh',expiresIn:'3600'}});
    if(url.pathname.endsWith('accounts:lookup'))return route.fulfill({json:{users:[user]}});
   }
   if(url.hostname==='securetoken.googleapis.com')return route.fulfill({json:{access_token:token,id_token:token,expires_in:'3600',token_type:'Bearer',refresh_token:'offline-refresh',user_id:teacher,project_id:'1044097605904'}});
   return route.abort();
  });
  await context.addInitScript(({teacher})=>{
   if(location.hostname!=='appassets.androidplatform.net'||window.parent!==window)return;
   if(!localStorage.getItem('ap_professor_marca_159_professor_teste'))localStorage.setItem('ap_professor_marca_159_professor_teste',JSON.stringify({version:1,completed:true,name:'Professor',description:'Personal Trainer',main:'#A12CFF',support:'#08070C',bg:'#08070C',design:'atual',photo:'',logo:''}));
   if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[{id:'fixture-existing',firebaseUid:'fixture_linked',name:'Aluno preservado',studentType:'presencial',phone:'69999999999',financeEnabled:false,notes:'Observação preservada',monthlyValue:'350,00'}],history:[],lessons:[],payments:[],workoutPlans:[],occurrenceStatus:{}}));
   window.__contactAudit={authInitializations:0,queries:0,updates:[],fail:false,pause:false,releases:[],rows:[
    {uid:'fixture_linked',nome:'Aluno preservado',email:'linked@example.test',whatsapp:'69999999999',nascimento:'2000-01-01',genero:'Feminino',perfil:'aluno',professorId:teacher,ativo:true},
    {uid:'fixture_pending',nome:'Novo cadastro',email:'pending@example.test',whatsapp:'69999999998',nascimento:'2001-01-01',genero:'Masculino',perfil:'aluno',professorId:teacher,ativo:false}
   ]};
   let localSdk;
   Object.defineProperty(window,'APFirebaseLocal',{configurable:true,get:()=>localSdk,set(original){
    localSdk={...original,auth:{...original.auth,getAuth(app){__contactAudit.authInitializations++;return original.auth.getAuth(app)}},store:{...original.store,
     async getDocs(query){
      const audit=__contactAudit;audit.queries++;
      if(query._query.path.canonicalString()!=='usuarios'||query._query.filters[0]?.field.canonicalString()!=='professorId'||query._query.filters[0]?.value.stringValue!==teacher)throw Error('Consulta de contatos fora do professor esperado');
      if(audit.pause)await new Promise(resolve=>audit.releases.push(resolve));
      if(audit.fail)throw Object.assign(Error('Falha de rede simulada'),{code:'unavailable'});
      return {docs:audit.rows.map(row=>({id:row.uid,data:()=>({...row})}))};
     },
     async getDoc(reference){const row=__contactAudit.rows.find(x=>reference.path==='usuarios/'+x.uid);return {exists:()=>Boolean(row),data:()=>({...row})}},
     async updateDoc(reference,update){const row=__contactAudit.rows.find(x=>reference.path==='usuarios/'+x.uid);if(!row)throw Error('Contato inexistente');__contactAudit.updates.push({path:reference.path,type:update.tipoAluno,active:update.ativo});Object.assign(row,update)},
     onSnapshot(){return ()=>{}}
    }};
   }});
  },{teacher});
  const page=await context.newPage();
  await page.goto('https://appassets.androidplatform.net/assets/index.html',{waitUntil:'load'});
  await page.waitForFunction(()=>window.APaccounts&&window.showLogin);
  await page.evaluate(()=>showLogin('Professor'));
  await page.locator('#email').fill(email);await page.locator('#password').fill('offline-fixture-password');await page.locator('#remember').setChecked(remember);
  await page.locator('#form').evaluate(form=>form.requestSubmit());
  await page.waitForFunction(()=>APaccounts.isTeacher(),{timeout:15000});
  await page.waitForFunction(()=>document.querySelector('#apPreviewTeacher').contentWindow?.openRegistrationLink,{timeout:15000});
  if(remember){
   await page.reload({waitUntil:'load'});
   await page.waitForFunction(()=>window.APaccounts?.isTeacher(),{timeout:15000});
   await page.waitForFunction(()=>document.querySelector('#apPreviewTeacher').contentWindow?.openRegistrationLink,{timeout:15000});
  }
  const frame=page.frameLocator('#apPreviewTeacher');
  await frame.locator('body').evaluate(()=>openRegistrationLink());
  await frame.locator('#registrationContactsTab').click();
  await frame.locator('[data-registration-uid="fixture_linked"]').waitFor({state:'visible'});
  assert.equal(await page.evaluate(()=>APaccounts.isTeacher()),true);
  assert.equal(await page.evaluate(()=>document.querySelector('#apPreviewOverlay').classList.contains('is-open')),true);
  assert.equal(await page.evaluate(()=>__contactAudit.authInitializations),1,'Contatos reinicializou a autenticação');
  assert.deepEqual(remoteSdk,[],'Contatos tentou baixar um segundo SDK');
  await frame.locator('[data-registration-edit="fixture-existing"]').click();
  await frame.locator('#studentDialog').waitFor({state:'visible'});
  await frame.locator('body').evaluate(()=>closeDialog('studentDialog'));
  await page.evaluate(()=>__contactAudit.fail=true);
  await frame.locator('#registrationRefresh').click();
  await frame.locator('#registrationContactsList').getByText(/Não foi possível carregar/).waitFor();
  assert.equal(await page.evaluate(()=>APaccounts.isTeacher()),true,'Falha de consulta encerrou a sessão');
  await page.evaluate(()=>__contactAudit.fail=false);
  await frame.locator('#registrationRefresh').click();
  const pending=frame.locator('[data-registration-uid="fixture_pending"]');
  await pending.locator('[data-registration-type]').selectOption('online');
  await pending.locator('[data-registration-approve]').click();
  await pending.getByText('Na agenda',{exact:true}).waitFor();
  const result=await page.evaluate(()=>({teacher:APaccounts.isTeacher(),updates:__contactAudit.updates,students:JSON.parse(localStorage.getItem('agendaPersonalTL_v1')).students,authInitializations:__contactAudit.authInitializations}));
  assert.equal(result.teacher,true);assert.equal(result.authInitializations,1);
  assert.deepEqual(result.updates,[{path:'usuarios/fixture_pending',type:'online',active:true}]);
  assert.equal(result.students.filter(s=>s.firebaseUid==='fixture_pending').length,1);
  const existing=result.students.find(s=>s.id==='fixture-existing');assert.equal(existing.name,'Aluno preservado');assert.equal(existing.notes,'Observação preservada');assert.equal(existing.monthlyValue,'350,00');
  await frame.locator('#registrationRefresh').click();await pending.getByText('Na agenda',{exact:true}).waitFor();
  assert.equal(await page.evaluate(()=>__contactAudit.updates.length),1,'Atualizar aprovou o contato novamente');
  await page.evaluate(()=>__contactAudit.pause=true);await frame.locator('#registrationRefresh').click();
  await page.waitForFunction(()=>__contactAudit.releases.length===1);
  await page.evaluate(async()=>{await APaccounts.logout();__contactAudit.releases.splice(0).forEach(resolve=>resolve())});
  await page.waitForFunction(()=>!APaccounts.isTeacher());
  assert.equal(await page.evaluate(()=>document.querySelector('#apPreviewOverlay').classList.contains('is-open')),false);
  assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')).students.filter(s=>s.firebaseUid==='fixture_pending').length),1);
  console.log('PASS: '+(remember?'acesso salvo e reaberto':'acesso sem salvar')+'; sessão única, contatos, aluno vinculado, falha/repetição, aprovação, dados preservados e logout durante consulta.');
 }finally{await browser.close()}
}
(async()=>{await run(true);await run(false);console.log('Firebase Auth e armazenamento reais; rede, identidade e cadastros simulados. Sem alterações em serviços reais.')})().catch(error=>{console.error(error);process.exitCode=1});
