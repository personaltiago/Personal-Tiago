'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'),{chromium}=runtime('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';if(!['index.html','professor.html','avaliacoes.html','cadastro.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);
  async function activate(uid='alice',weekly=true){await page.evaluate(({uid,weekly})=>{
   const student={id:'s',name:'Aluna de teste',firebaseUid:uid,gender:'Feminino'};
   const days=[{id:'glute',name:'Glúteo',weekday:3},{id:'back',name:'Costas',weekday:1},{id:'legs',name:'Perna quadríceps',weekday:1},{id:'none',name:'Mobilidade <teste>',weekday:null},{id:'sat',name:'Alongamento',weekday:6}].map(d=>({...d,exercises:[{id:'e-'+d.id,name:'Exercício '+d.name,sets:3,reps:'8–12',load:'30',rest:'60'}]}));
   const state={students:[student],workoutPlans:[{id:'p',studentId:'s',name:'Treino importado · Hipertrofia',organization:weekly?'week':'sequence',days}]};
   const area=APStudentModel.makeArea(state,student);window.__AP_STUDENT_CONTEXT={storageId:uid,role:'student',profile:area.profile,area};APstudentUI.activate();route('workouts');window.__sourceArea=JSON.stringify(area);
  },{uid,weekly})}
  await activate();assert.equal(await page.locator('#wsModeDays').getAttribute('aria-pressed'),'true');
  assert.equal(await page.locator('[data-weekday="1"] [data-workout-id]').count(),2,'same-day workouts both shown');
  assert.deepEqual(await page.locator('[data-weekday="1"] .ws-card-text strong').allTextContents(),['Segunda-feira','Segunda-feira']);
  assert.deepEqual(await page.locator('[data-weekday="1"] .ws-card-text em').allTextContents(),['Costas','Perna quadríceps']);
  assert.equal(await page.locator('[data-weekday="6"] .ws-card-text strong').innerText(),'Sábado');
  assert.equal(await page.locator('.ap-week-unscheduled .ws-card-text em').innerText(),'Mobilidade <teste>','null is not Sunday');
  assert.equal(await page.locator('[data-weekday="0"]').count(),0);assert.equal(await page.locator('[data-weekday="2"] [data-ap-workout]').count(),0,'empty day cannot start a workout');
  assert.equal(await page.locator('#wsCards .ap-muscle-preview').count(),5,'one muscle illustration per workout');
  assert.equal(await page.locator('#wsCards .ap-muscle-body').count(),0,'old geometric drawings removed');
  assert.equal(await page.locator('[data-workout-id="p~glute"] .ap-muscle-highlight[data-muscle="glutes"]').count(),1);
  assert.equal(await page.locator('[data-workout-id="p~back"] .ap-muscle-highlight[data-muscle="lats"]').count(),1);
  assert.equal(await page.locator('[data-workout-id="p~legs"] .ap-muscle-highlight[data-muscle="quads"]').count(),1);
  assert.equal(await page.locator('[data-workout-id="p~glute"] [data-body-gender="female"]').count(),1);
  assert.ok(await page.locator('[data-workout-id="p~glute"] image').evaluate(n=>n.href.baseVal.startsWith('data:image/webp;base64,')),'offline embedded artwork');
  const before=await page.evaluate(()=>JSON.stringify(__AP_STUDENT_CONTEXT.area));
  await page.locator('#wsModeLetters').click();assert.deepEqual(await page.locator('#wsCards .ws-card-text strong').allTextContents(),['Treino A','Treino B','Treino C','Treino D','Treino E']);
  assert.equal(await page.locator('#wsCards .ws-card-text em').first().innerText(),'Glúteo');
  await page.locator('[data-workout-id="p~glute"] .ws-card-cta').click();assert.equal(await page.evaluate(()=>exActiveId),'p~glute');
  await page.evaluate(()=>{exNewSession(exActiveId);saveExerciseLoad(0,0,'37.5');toggleExerciseSet(0,0);const store=exStore();store.history.push({id:'p~back',finishedAt:Date.now(),durationMs:60000,workoutName:'Costas',exerciseRecords:[]});exSave(store);route('workouts')});
  const session=await page.evaluate(()=>JSON.stringify(exStore()));
  await page.locator('#wsModeDays').click();await page.locator('#wsModeLetters').click();assert.equal(await page.evaluate(()=>JSON.stringify(exStore())),session);assert.equal(await page.evaluate(()=>JSON.stringify(__AP_STUDENT_CONTEXT.area)),before);
  await page.locator('#wsTabDone').click();assert.match(await page.locator('#wsCards').innerText(),/Costas/);await page.locator('#wsTabOngoing').click();
  await page.reload();await activate();assert.equal(await page.locator('#wsModeLetters').getAttribute('aria-pressed'),'true','saved preference survives account activation');assert.equal(await page.evaluate(()=>JSON.stringify(exStore())),session);
  await activate('bob');assert.equal(await page.locator('#wsModeDays').getAttribute('aria-pressed'),'true','accounts do not share display preference');
  await activate('imported',false);const sequenceSource=await page.evaluate(()=>JSON.stringify(__AP_STUDENT_CONTEXT.area));await page.locator('#wsModeDays').click();assert.equal(await page.locator('.ap-week-unscheduled .ws-card').count(),0);assert.equal(await page.locator('[data-weekday] .ws-card').count(),5,'sequence displayed A=Monday through E=Friday');assert.match(await page.locator('.ap-week-note').innerText(),/Organização visual/);assert.deepEqual(await page.locator('#wsCards .ws-card-text strong').allTextContents(),['Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira']);assert.equal(await page.evaluate(()=>JSON.stringify(__AP_STUDENT_CONTEXT.area)),sequenceSource,'weekday display does not modify the prescription');
  await page.evaluate(()=>{APstudentStorage.setItem('agenda_demo_genero','Masculino');renderWorkouts()});assert.equal(await page.locator('[data-body-gender="female"]').count(),0);assert.ok(await page.locator('[data-body-gender="male"]').count()>0);await page.evaluate(()=>APstudentStorage.setItem('agenda_demo_genero','Feminino'));
  for(const mode of ['letters','days'])for(const light of [false,true])for(const width of [320,390,480]){
   await page.setViewportSize({width,height:844});await page.evaluate(({mode,light})=>{const p=prefs();APstudentStorage.setItem(PREF_KEY,JSON.stringify({...p,mode:light?'claro':'escuro'}));changeWorkoutMode(mode)}, {mode,light});
   assert.equal(await page.locator('#workoutsScreen').evaluate(n=>n.classList.contains('ws-light')),light);
   assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'no page overflow '+mode+' '+width);
   const overflow=await page.locator('#wsCards .ws-card').evaluateAll(nodes=>nodes.some(n=>n.scrollWidth>n.clientWidth+1));assert.equal(overflow,false);
  }
  await activate('scheduled');await page.setViewportSize({width:390,height:844});await page.locator('#wsModeLetters').click();await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/workouts-letters.png'});await page.locator('#wsModeDays').click();await page.screenshot({path:'/workspace/scratch/9330e8f92c6b/tmp/workouts-week.png'});
  await page.evaluate(()=>{__AP_STUDENT_CONTEXT.area.enabled=false;__AP_STUDENT_CONTEXT.area.plans=[];renderWorkouts()});assert.match(await page.locator('#wsCards').innerText(),/Nenhum treino disponível/);assert.equal(await page.locator('#wsCards [data-ap-workout]').count(),0);
  assert.deepEqual(errors,[]);console.log('PASS: detailed offline muscle illustrations, correct glute/back/quad highlights and male/female models; letter/day headings; sequence-week presentation, real weekdays/weekends, exact workout opening, active loads/sets/history, reload, account isolation, archived access, light/dark at 320–480 px. Real browser; account/media simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
