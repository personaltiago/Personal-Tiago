'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'):require,{chromium}=runtime('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const {ctx}=require('./verify_shell_boot.cjs'),B=ctx.APBilling;
for(const [raw,expected]of [['350,00',35000],['1.234,56',123456],['350.50',35050],[350.5,35050],['350',35000],['',null],['-5',null],['1,2,3',null],['0',0]])assert.equal(B.cents(raw),expected,String(raw));
const base={enabled:true,amountCents:35000,dueDate:'2026-10-20',startDate:'2026-09-20',manualOverdue:false,pixKey:'chave-teste',history:[]};
assert.equal(B.status(base,new Date(2026,9,15)).kind,'upcoming');assert.equal(B.status(base,new Date(2026,9,20)).kind,'today');assert.equal(B.status(base,new Date(2026,9,21)).kind,'overdue');assert.equal(B.status({...base,manualOverdue:true},new Date(2026,9,15)).kind,'overdue');
assert.equal(B.valid({...base,amountCents:NaN}),false);assert.equal(B.valid({...base,dueDate:'2026-02-31'}),false);assert.equal(B.valid(base),true);
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.split('/').pop()||'index.html';if(!['index.html','professor.html'].includes(name)){res.writeHead(404);res.end();return}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true,timezoneId:'America/Cuiaba'});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{
   const RealDate=Date,now=RealDate.parse('2026-10-15T12:00:00-04:00');window.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[now]))}static now(){return now}};
   Object.defineProperty(navigator,'clipboard',{value:{writeText:async value=>window.__copiedPix=value},configurable:true});
   window.__staged=[];window.APaccounts={isTeacher:()=>true,stage:p=>window.__staged.push(JSON.parse(JSON.stringify(p))),refreshPreview(){},knownAreas:()=>[],status:()=>({state:'sent',message:'Enviado'})};
   if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[
    {id:'a',firebaseUid:'alice_billing',name:'Aluna',studentType:'presencial',financeEnabled:true,startDate:'2026-09-20',dueDate:'2026-10-20',monthlyValue:'350,00'},
    {id:'b',firebaseUid:'bob_billing',name:'Aluna',studentType:'online',financeEnabled:true,startDate:'2026-09-10',dueDate:'2026-10-10',monthlyValue:'900,00'}
   ],lessons:[],payments:[{id:'pa',studentId:'a',dueDate:'2026-09-20',paidAt:'2026-09-20T15:00:00Z',amount:'350,00'},{id:'pb',studentId:'b',dueDate:'2026-09-10',paidAt:'2026-09-10T15:00:00Z',amount:'900,00'}],customData:{preserve:9}}));
  });
  const teacher=await context.newPage(),errors=[];teacher.on('pageerror',e=>errors.push(e.message));teacher.on('dialog',d=>d.accept());await teacher.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await teacher.waitForFunction(()=>__staged.length>=2);
  const packet=await teacher.evaluate(()=>__staged.find(p=>p.studentUid==='alice_billing')),other=await teacher.evaluate(()=>__staged.find(p=>p.studentUid==='bob_billing'));
  assert.equal(packet.billing.amountCents,35000);assert.equal(packet.billing.pixKey,await teacher.evaluate(()=>PIX_KEY));assert.equal(packet.billing.history.length,1);assert.equal(packet.billing.history[0].id,'pa');assert.equal(other.billing.history[0].id,'pb','same-name students do not share records');
  const student=await context.newPage();student.on('pageerror',e=>errors.push(e.message));await student.goto('http://127.0.0.1:'+server.address().port+'/index.html');
  await student.evaluate(area=>{window.__AP_STUDENT_CONTEXT={storageId:area.studentUid,role:'student',profile:area.profile,area};APstudentUI.activate();route('payments')},packet);
  assert.match(await student.locator('#apBillingAmount').textContent(),/350,00/);assert.equal(await student.locator('#apBillingDue').textContent(),'20/10/2026');assert.equal(await student.locator('#apBillingCountdown').textContent(),'Vence em 5 dias');assert.equal(await student.locator('#apBillingStatus').textContent(),'A vencer');
  assert.equal(await student.locator('.ap-billing-history').count(),1);assert.doesNotMatch(await student.locator('#payContent').textContent(),/900,00|fictício|teste local|demonstração/);
  const before=await student.evaluate(()=>JSON.stringify(__AP_STUDENT_CONTEXT.area));await student.locator('#apBillingCopyPix').click();assert.equal(await student.evaluate(()=>__copiedPix),packet.billing.pixKey);assert.equal(await student.evaluate(()=>JSON.stringify(__AP_STUDENT_CONTEXT.area)),before,'copy does not mark paid or edit financial packet');
  // Edit the real teacher financial form, and observe the automatic queue.
  await teacher.evaluate(()=>openEditStudent('a'));await teacher.locator('#studentMonthlyValue').fill('420,50');await teacher.locator('#studentDueDate').fill('2026-10-25');await teacher.locator('#studentSubmitButton').click();await teacher.waitForFunction(()=>__staged.some(p=>p.studentUid==='alice_billing'&&p.billing.amountCents===42050));
  const updated=await teacher.evaluate(()=>__staged.filter(p=>p.studentUid==='alice_billing').at(-1));await student.evaluate(area=>{__AP_STUDENT_CONTEXT.area=area;APstudentUI.repaint()},updated);assert.match(await student.locator('#apBillingAmount').textContent(),/420,50/);assert.equal(await student.locator('#apBillingDue').textContent(),'25/10/2026','payment view refreshes without reopening');
  await teacher.evaluate(()=>markPaymentPaid('a'));await teacher.waitForFunction(()=>__staged.some(p=>p.studentUid==='alice_billing'&&p.billing.dueDate==='2026-11-25'));
  const paid=await teacher.evaluate(()=>__staged.filter(p=>p.studentUid==='alice_billing').at(-1));assert.equal(paid.billing.history.length,2);assert.equal(paid.billing.history[0].amountCents,42050);assert.equal(paid.billing.history[0].dueDate,'2026-10-25');assert.equal(await teacher.evaluate(()=>state.customData.preserve),9);
  await student.evaluate(area=>{__AP_STUDENT_CONTEXT.area=area;APstudentUI.repaint()},paid);assert.equal(await student.locator('#apBillingDue').textContent(),'25/11/2026');assert.equal(await student.locator('.ap-billing-history').count(),2);
  await student.evaluate(()=>{__AP_STUDENT_CONTEXT.area.billing.pixKey='pix-teste@example.test';payRender()});
  for(const width of [320,390,480]){await student.setViewportSize({width,height:844});assert.equal(await student.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);const box=await student.locator('#apBillingPixKey').boundingBox();assert.ok(box.x>=0&&box.x+box.width<=width+1)}
  await student.setViewportSize({width:390,height:844});await student.screenshot({path:path.resolve(__dirname,'../../../../student_billing_review.png')});
  await student.evaluate(()=>{__AP_STUDENT_CONTEXT.area.billing.dueDate='2026-10-14';payRender()});assert.equal(await student.locator('#apBillingStatus').textContent(),'Em atraso');
  await student.evaluate(()=>{__AP_STUDENT_CONTEXT.area.billing.dueDate='2026-10-15';payRender()});assert.equal(await student.locator('#apBillingStatus').textContent(),'Vence hoje');
  await student.evaluate(()=>{__AP_STUDENT_CONTEXT.area.billing.amountCents=null;__AP_STUDENT_CONTEXT.area.billing.pixKey='';payRender()});assert.equal(await student.locator('#apBillingAmount').textContent(),'Valor não informado');assert.equal(await student.locator('#apBillingCopyPix').count(),0);
  await student.evaluate(()=>{__AP_STUDENT_CONTEXT={...__AP_STUDENT_CONTEXT,storageId:'bob_billing'};APstudentUI.repaint()});assert.equal(await student.locator('#apBillingAmount').count(),0,'UID mismatch cannot display another account payment');
  await student.evaluate(()=>{__AP_STUDENT_CONTEXT.storageId='alice_billing';__AP_STUDENT_CONTEXT.area.billing.enabled=false;payRender()});assert.equal(await student.locator('#apBillingAmount').count(),0);
  await student.evaluate(()=>{__AP_STUDENT_CONTEXT=null;dispatchEvent(new Event('ap-account-changed'))});assert.equal(await student.locator('#payContent').textContent(),'');assert.equal(await student.locator('#payDialog').isVisible(),false);
  assert.deepEqual(errors,[]);
  console.log('PASS: money/date validation, real teacher queue with own-student history/Pix, financial form edit and confirmed payment advance, live student refresh, exact clipboard without payment mutation, due/today/overdue states, absent values/Pix, UID isolation, disabled finance, logout and responsive widths 320/390/480. Firebase/clipboard simulated; no payment or real publication made.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
