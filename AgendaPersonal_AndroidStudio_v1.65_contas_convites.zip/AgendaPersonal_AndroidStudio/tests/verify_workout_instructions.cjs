'use strict';
const assert=require('node:assert/strict'),{chromium}=require('playwright');
const {fixture,init,openDay,server}=require('./verify_bisets.cjs');
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const data=structuredClone(fixture);data.workoutPlans[0].days[0].exercises[0].observations='Respeite a amplitude.';
  data.workoutDrafts={'p|d':{active:true,sessionId:'instructions',startedAt:Date.now()}};
  const ctx=await browser.newContext({viewport:{width:360,height:780}});await init(ctx,data);
  const p=await ctx.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
  await p.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await p.waitForFunction(()=>__ready);await openDay(p);
  const card=p.locator('#workoutDayContent .workout-exercise[data-exercise-id="a"]'),button=card.locator('.ap-instruction-toggle'),notes=card.locator('.ap-instruction-copy');
  const baseline=await p.evaluate(()=>JSON.stringify(state));
  assert.equal(await button.innerText(),'Instruções');assert.ok(await notes.isVisible());
  const order=await card.evaluate(c=>{const b=c.querySelector('.ap-instruction-toggle'),body=c.querySelector('.workout-exercise-body');return !!(b.compareDocumentPosition(body)&Node.DOCUMENT_POSITION_FOLLOWING)});assert.ok(order,'control precedes prescription');
  async function metrics(){assert.ok(await card.locator('.workout-prescription').isVisible());assert.ok(await card.locator('.workout-rest-trigger').isVisible());assert.ok(await card.locator('[data-series-table="a"]').isVisible());assert.equal(await card.locator('.ws-set-row').count(),3);assert.ok(await card.locator('[data-series-field="load"]').first().isVisible());assert.ok(await card.locator('.workout-exercise-side').isVisible());}
  await button.click();assert.equal(await button.getAttribute('aria-expanded'),'false');assert.ok(await notes.isHidden());await metrics();assert.equal(await p.evaluate(()=>JSON.stringify(state)),baseline,'visibility never changes workout data');
  await card.screenshot({path:'/tmp/workout-instructions-hidden.png'});
  await p.evaluate(()=>renderWorkoutDay());assert.ok(await notes.isHidden(),'choice survives rerender');await metrics();
  await button.click();assert.ok(await notes.isVisible());assert.match(await notes.innerText(),/Mantenha o tronco estável/);assert.match(await notes.innerText(),/Respeite a amplitude/);
  await card.screenshot({path:'/tmp/workout-instructions-open.png'});
  await p.getByRole('button',{name:'Ocultar instruções',exact:true}).click();assert.ok(await notes.isHidden());await metrics();
  await p.getByRole('button',{name:'Mostrar instruções',exact:true}).click();assert.ok(await notes.isVisible());
  await button.click();await card.locator('[data-series-field="load"]').first().fill('24');await card.locator('.ws-set-row input[type=checkbox]').first().click();assert.ok(await notes.isHidden());await metrics();assert.equal(await card.locator('[data-series-field="load"]').first().inputValue(),'24');
  await card.locator('.workout-rest-trigger').click();assert.ok(await p.locator('#apRestFloating').isVisible());assert.ok(await notes.isHidden());
  for(const width of [280,360,600]){await p.setViewportSize({width,height:780});await p.evaluate(()=>document.documentElement.style.fontSize='20px');await p.evaluate(()=>renderWorkoutDay());await metrics();const fit=await button.evaluate(b=>{const r=b.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1&&b.scrollWidth<=b.clientWidth+1});assert.ok(fit,'instructions button fits '+width);assert.ok(await notes.isHidden());}
  assert.deepEqual(errors,[]);await ctx.close();
  console.log('PASS: top instruction control hides only guidance, retains prescription/video/three series and load entry, preserves visibility on rerender and series completion, bulk actions, floating rest and 280/360/600 px layouts. Android bridge simulated.');
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);server.close();process.exitCode=1});
