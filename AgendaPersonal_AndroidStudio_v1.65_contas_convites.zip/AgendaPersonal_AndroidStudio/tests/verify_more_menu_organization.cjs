'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const {server,init,fixture}=require('./verify_bisets.cjs');
async function main(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const errors=[],layouts=[],checks=[];
 try{
  const ctx=await browser.newContext({viewport:{width:393,height:852},isMobile:true,hasTouch:true});await init(ctx,fixture);
  await ctx.addInitScript(()=>{window.APaccounts={isTeacher:()=>true,teacherUid:()=> 'R2EmnDVcvMWt7TjPxOP6DjW1VOn1',getPhotoToken:async()=>''}});
  const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:'+server.address().port+'/professor.html');
  await page.waitForFunction(()=>window.__ready&&document.querySelector('#apMoreOrganized'));
  await page.evaluate(()=>{AgendaColors.selectDesign('deep-tl');AgendaColors.save({...AgendaColors.get(),id:'custom',primary:'#b7f522'});showScreen('more')});
  await page.waitForFunction(()=>document.querySelectorAll('#apMoreOrganized button.more-function').length===23);
  const getMenu=()=>page.evaluate(()=>{
   const menu=document.getElementById('screen-more');
   return {groups:[...menu.querySelectorAll('.ap-more-group')].map(g=>({id:g.dataset.moreGroup,cards:[...g.querySelectorAll('.more-function')].map(b=>b.id||b.dataset.screen||b.dataset.panelAction)})),icons:[...menu.querySelectorAll('.ap-more-group .more-function')].map(b=>b.dataset.apMenuIcon),old:menu.querySelectorAll('.more-group:not(.ap-more-group)').length,last:menu.lastElementChild.id};
  });
  const model=await getMenu();
  assert.deepEqual(model.groups,[
   {id:'training',cards:['workouts','evaluations','moreWorkoutCatalog','pdf','moreSmartwatch']},
   {id:'agenda',cards:['today','week','availability','makeup']},
   {id:'students',cards:['students-presencial','students-online','student','moreRegistrationLink','moreFollowup','finance']},
   {id:'appearance',cards:['moreThemeButton','moreLessonSounds','settings','morePet']},
   {id:'app',cards:['updates','moreFullBackup','moreTeacherSync','history']},
   {id:'account',cards:['moreAccountLogout']}
  ]);
  assert.equal(model.old,0);assert.equal(model.last,'apMoreAccount');assert.equal(model.icons.length,24);assert.equal(new Set(model.icons).size,24);
  const glyphs=JSON.parse(fs.readFileSync(path.join(__dirname,'../web/more-menu-icons.json')));assert.equal(new Set(Object.values(glyphs)).size,24);
  checks.push('24 funções preservadas em seis grupos, ícones diferentes, sem categorias vazias; conta após o histórico recente');
  // Move an existing late-mounted card back to its former mounting point.
  await page.evaluate(()=>document.querySelector('#morePet').parentElement.append(document.querySelector('#moreTeacherSync')));
  await page.waitForFunction(()=>document.querySelector('#moreTeacherSync').closest('[data-more-group]').dataset.moreGroup==='app');
  assert.deepEqual(await getMenu(),model);checks.push('Cartão inserido tardiamente retorna ao grupo correto sem duplicação');
  await page.evaluate(()=>{window.__updateCalls=0;window.openAppUpdates=()=>{window.__updateCalls++}});
  const update=page.locator('#apMoreOrganized [data-panel-action="updates"]');await update.click();assert.equal(await page.evaluate(()=>__updateCalls),0);await update.click();assert.equal(await page.evaluate(()=>__updateCalls),1);
  const settings=page.locator('#apMoreOrganized [data-screen="settings"]');await settings.click();assert.equal(await page.locator('#screen-more').evaluate(n=>n.classList.contains('active')),true);await settings.click();assert.equal(await page.locator('#screen-settings').evaluate(n=>n.classList.contains('active')),true);
  await page.evaluate(()=>showScreen('more'));await page.locator('#moreWorkoutCatalog').click();await page.locator('#moreWorkoutCatalog').click();
  assert.ok(await page.locator('.dialog.open').count()>0);await page.evaluate(()=>{for(const d of document.querySelectorAll('.dialog.open'))closeDialog(d.id);showScreen('more')});
  checks.push('Seleção e ações originais de Atualizações, Configurações e Catálogo continuam funcionando');
  for(const [width,font,design]of [[320,20,'deep-tl'],[393,16,'deep-tl'],[430,16,'metal-tl'],[393,20,'pro-tl'],[393,16,'neon-tl'],[820,16,'deep-tl']]){
   await page.setViewportSize({width,height:852});await page.evaluate(({font,design})=>{document.documentElement.style.fontSize=font+'px';AgendaColors.selectDesign(design);showScreen('more')},{font,design});
   await page.waitForTimeout(120);
   const layout=await page.evaluate(()=>{
    const menu=document.querySelector('#screen-more');const bad=[];
    for(const n of menu.querySelectorAll('.ap-more-group .more-function')){const r=n.getBoundingClientRect();if(r.width<44||r.height<44||r.left<0||r.right>innerWidth+1||n.scrollWidth>n.clientWidth+2)bad.push(n.id||n.dataset.screen||n.dataset.panelAction);const title=n.querySelector('strong');if(getComputedStyle(title).wordBreak!=='normal')bad.push('word-break')}
    return {bad,overflow:document.documentElement.scrollWidth>innerWidth+1,design:document.documentElement.dataset.agendaDesign};
   });assert.deepEqual(layout.bad,[]);assert.equal(layout.overflow,false);layouts.push({width,font,requestedDesign:design,...layout});
  }
  await page.setViewportSize({width:393,height:852});await page.evaluate(()=>{document.documentElement.style.fontSize='16px';AgendaColors.selectDesign('deep-tl');document.querySelector('#apMoreOrganized').scrollIntoView()});
  await page.screenshot({path:path.resolve(__dirname,'../../menu-training.png')});
  await page.locator('#apMoreAccount').scrollIntoViewIfNeeded();await page.screenshot({path:path.resolve(__dirname,'../../menu-bottom.png')});
  const data=await page.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')));assert.deepEqual(data.workoutPlans[0].days,fixture.workoutPlans[0].days);assert.deepEqual(data.workoutDrafts,{});assert.deepEqual(data.workoutExecutions,[]);assert.deepEqual(data.payments,[]);assert.deepEqual(data.customData,fixture.customData);assert.equal(data.students[0].id,'s');assert.equal(data.students[0].name,'Jéssica');assert.deepEqual(errors,[]);
  checks.push('Dados de alunos e treinos permanecem iguais; sem erros de JavaScript');
  const report={passed:true,checks,layouts,errors,physicalDeviceTest:false};fs.writeFileSync(path.join(__dirname,'../VERIFICACAO_MENU_ORGANIZADO.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await ctx.close();
 }finally{await browser.close();server.close()}
}
main().catch(e=>{console.error(e);process.exitCode=1;server.close()});
