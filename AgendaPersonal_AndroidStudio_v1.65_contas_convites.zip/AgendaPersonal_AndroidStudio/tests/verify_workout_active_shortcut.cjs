'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const html=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/professor.html'),'utf8');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(html)});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const ctx=await browser.newContext({viewport:{width:390,height:844},timezoneId:'America/Cuiaba'});await ctx.route('https://**',r=>r.abort());
  await ctx.addInitScript(()=>{
   window.__starts=0;window.Android={syncLessonAlarms:()=>true,getAlarmStatus:()=>'{"ready":true}',getCustomSoundStatus:()=> '{}',getTimerOverlayStatus:()=>'{"showing":false}',cancelWorkoutRest:()=>true,cancelLessonTimer(){},startLessonTimer(){__starts++;return true},startWorkoutRest(){__starts++;return true}};
   const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(this===sessionStorage&&k==='ap_workout_return_v1'&&window.__failRoute)throw Error('quota');return set.call(this,k,v)};
   if(localStorage.getItem('agendaPersonalTL_v1'))return;
   const days=()=>Array.from({length:5},(_,i)=>({id:'d'+(i+1),name:'Treino '+(i+1),exercises:[{id:'e'+i,name:'Agachamento',sets:'3',reps:'10',load:'22 kg',rest:'60'}]}));
   localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[{id:'s',name:'Aluna',studentType:'presencial'},{id:'other',name:'Outra aluna',studentType:'presencial'}],
    workoutPlans:[{id:'p1',studentId:'s',name:'Ficha principal',createdAt:'2026-10-23',visibility:'always',days:days()},{id:'p2',studentId:'s',name:'Ficha em uso',createdAt:'2026-10-20',visibility:'always',days:days()},{id:'archived',studentId:'s',name:'Arquivada',archived:true,days:days()},{id:'expired',studentId:'s',name:'Arquivada automaticamente',autoArchive:true,endDate:'2026-01-01',days:days()},{id:'other-plan',studentId:'other',name:'Ficha de outra aluna',days:days()}],
    workoutDrafts:{'p2|d5':{active:true,sessionId:'keep-session',startedAt:1792857600000,values:{'e4|0':{done:true,load:'24 kg',reps:'9'}}}},
    workoutExecutions:[{id:'prior',studentId:'s',planId:'p2',dayId:'d5',duration:600}],history:[{id:'keep-history',text:'Registro anterior'}],customData:{keep:true}}));
  });
  const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.clock.install({time:new Date('2026-10-24T16:00:00Z')});
  await page.goto('http://127.0.0.1:'+server.address().port);await page.clock.pauseAt(new Date('2026-10-24T16:01:00Z'));
  const open=()=>page.evaluate(()=>{showScreen('workouts');openWorkoutStudent('s')});
  const click=()=>page.locator('#workoutStudentContent .workout-plan-collection-tab').filter({hasText:'Ativas'}).click();
  const current=()=>page.evaluate(()=>({student:workoutStudentId,plan:workoutPlanId,day:workoutDayId,open:document.getElementById('workoutDayDialog').classList.contains('open'),starts:__starts}));
  const expectDay=async(plan,day)=>assert.deepEqual(await current(),{student:'s',plan,day,open:true,starts:0});
  await open();assert.match(await page.locator('.workout-plan-collection-tab').first().innerText(),/Ativas\s+2/);await click();await expectDay('p2','d5');
  assert.equal(await page.evaluate(()=>state.workoutDrafts['p2|d5'].sessionId),'keep-session');assert.equal(await page.evaluate(()=>state.workoutDrafts['p2|d5'].values['e4|0'].load),'24 kg');
  await page.evaluate(()=>{closeDialog('workoutDayDialog');showWorkoutPlanCollection('archived');openArchivedWorkoutPlan('archived');openWorkoutDay('d3');closeDialog('workoutDayDialog')});await click();await expectDay('p2','d5');
  // After completion, return to the last opened day without starting it.
  await page.evaluate(()=>{closeDialog('workoutDayDialog');state.workoutDrafts={};selectWorkoutPlan('p1');openWorkoutDay('d2');closeDialog('workoutDayDialog');openWorkoutStudent('s')});await click();await expectDay('p1','d2');
  // The navigation preference belongs to the student, not to the day ID alone.
  await page.evaluate(()=>{closeDialog('workoutDayDialog');openWorkoutStudent('other');selectWorkoutPlan('other-plan');openWorkoutDay('d4');closeDialog('workoutDayDialog');openWorkoutStudent('s')});await click();await expectDay('p1','d2');
  // Save only the fixture changes. A normal shortcut must not write to the DB.
  const snapshot=await page.evaluate(()=>{closeDialog('workoutDayDialog');localStorage.setItem(DB_KEY,JSON.stringify(state));return localStorage.getItem(DB_KEY)});await click();await expectDay('p1','d2');assert.equal(await page.evaluate(()=>localStorage.getItem(DB_KEY)),snapshot);
  await page.reload();await open();await click();await expectDay('p1','d2');
  // Stale or archived routes cannot open the old workout. Jump to the list.
  await page.evaluate(()=>{closeDialog('workoutDayDialog');state.workoutPlans.find(p=>p.id==='p1').archived=true;openWorkoutStudent('s')});await click();assert.equal((await current()).open,false);
  const position=await page.locator('#workoutSheetTrainingsTitle').boundingBox();assert.ok(position&&position.y>=0&&position.y<500,'list heading brought into view');
  await page.evaluate(()=>{state.workoutPlans.find(p=>p.id==='p2').days=[state.workoutPlans.find(p=>p.id==='p2').days[0]];openWorkoutStudent('s')});await click();await expectDay('p2','d1');
  // Deleted days do not revive through the saved navigation record.
  await page.evaluate(()=>{closeDialog('workoutDayDialog');state.workoutPlans.find(p=>p.id==='p2').days=[];openWorkoutStudent('s')});await click();assert.equal((await current()).open,false);
  await page.evaluate(()=>{state.workoutPlans.find(p=>p.id==='p2').archived=true;openWorkoutStudent('s')});await click();assert.equal((await current()).open,false);assert.match(await page.locator('#workoutStudentContent').innerText(),/Nenhuma ficha ativa/);
  // Two running workouts: with no navigation record, use the most recent one.
  await page.evaluate(()=>{for(const id of ['p1','p2']){const p=state.workoutPlans.find(p=>p.id===id);p.archived=false;p.days=[{id:'d1',name:'Treino',exercises:[{id:'e',name:'Agachamento',sets:'3',reps:'10',load:'22 kg'}]}]};state.workoutDrafts={'p1|d1':{active:true,startedAt:1000},'p2|d1':{active:true,startedAt:2000},'archived|d1':{active:true,startedAt:9000},'other-plan|d1':{active:true,startedAt:99999}};localStorage.setItem(DB_KEY,JSON.stringify(state));sessionStorage.removeItem('ap_workout_return_v1')});
  await page.reload();await open();await click();await expectDay('p2','d1');
  // Quota failures in navigation preferences do not block opening or lose data.
  await page.evaluate(()=>{closeDialog('workoutDayDialog');__failRoute=true;selectWorkoutPlan('p1');openWorkoutDay('d1');closeDialog('workoutDayDialog');openWorkoutStudent('s')});await click();await expectDay('p1','d1');
  assert.equal(await page.evaluate(()=>state.customData.keep),true);assert.equal(await page.evaluate(()=>state.workoutExecutions[0].id),'prior');assert.equal(await page.evaluate(()=>state.history[0].id),'keep-history');assert.deepEqual(errors,[]);
  await ctx.close();console.log('PASS: Ativas opens the student\'s running/last day; active count retains plan meaning; archived/expired/deleted/other-student targets excluded; multi-day fallback scrolls to workouts; single-day opens directly; reload, quota failures and records preserved; no timers started. Real generated UI in Chromium; native bridge simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
