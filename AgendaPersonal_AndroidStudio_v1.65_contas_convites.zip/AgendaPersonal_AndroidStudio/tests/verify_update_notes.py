"""Check that the generator includes human notes and refuses undocumented output."""
from pathlib import Path
import json
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]


def main():
    release = json.loads((PROJECT/'release.json').read_text())
    with tempfile.TemporaryDirectory(prefix='agenda-release-notes-') as temp:
        folder = Path(temp)
        notes_file = folder/'notes.txt'
        target = folder/'update.agenda.json'
        command = ['node','tools/build_web_update.cjs',release['contentVersion'],str(release['sequence']),str(target)]
        result = subprocess.run(command,cwd=PROJECT,capture_output=True,text=True)
        assert result.returncode and not target.exists(), 'Arquivo criado sem descrição.'
        notes = 'Correção de teste com acentuação.\nSegunda mudança descrita separadamente.'
        notes_file.write_text('\n'+notes+'\n')
        subprocess.run(command+[str(notes_file)],cwd=PROJECT,check=True,capture_output=True,text=True)
        bundle = json.loads(target.read_text())
        assert bundle['notes']==notes
        assert bundle['version']==release['contentVersion'] and bundle['sequence']==release['sequence']
        for name, text in bundle['files'].items():
            assert text==(PROJECT/'app/src/main/assets'/name).read_text()
        accepted = target.read_bytes()
        for invalid in ['   \n\t','x'*4001]:
            notes_file.write_text(invalid)
            result = subprocess.run(command+[str(notes_file)],cwd=PROJECT,capture_output=True,text=True)
            assert result.returncode and target.read_bytes()==accepted, 'Erro na descrição substituiu um arquivo válido.'
    print('Gerador verificado: descrição, acentuação, quebras de linha, limite, ausência e preservação das quatro telas.')


if __name__ == '__main__':
    main()
