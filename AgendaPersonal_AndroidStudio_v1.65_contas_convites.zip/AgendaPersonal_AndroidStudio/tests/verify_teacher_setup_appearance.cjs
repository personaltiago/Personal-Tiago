'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const {chromium}=require('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const review=process.env.AGENDA_REVIEW_DIR||path.resolve(__dirname,'../../../review/setup-icons');fs.mkdirSync(review,{recursive:true});
const BRAND='ap_professor_marca_159_professor_teste',fixture={completed:true,name:'Professora Teste',description:'Personal Trainer',photo:'',logo:'',main:'#A12CFF',support:'#08070C',bg:'#08070C',design:'deep'};
const server=http.createServer((req,res)=>{const name=req.url.slice(1)||'index.html';if(!['index.html','professor.html','avaliacoes.html','cadastro.html'].includes(name)){res.writeHead(404);res.end();return}let s=fs.readFileSync(path.join(assets,name),'utf8');if(name==='index.html')s=s.replace('window.APaccounts=Object.freeze({','window.__setupTest={setSdk:v=>sdk=v,activate};window.APaccounts=Object.freeze({');res.setHeader('Content-Type','text/html;charset=utf-8');res.end(s)});
async function activate(page){await page.evaluate(async()=>{const current={uid:APStudentModel.TEACHER,email:'teacher@example.test'};__setupTest.setSdk({auth:{currentUser:current},db:{},doc:(_, ...p)=>p.join('/'),onSnapshot:()=>()=>{},signOut:async()=>{}});await __setupTest.activate(current,'Professor')});await page.frameLocator('#apPreviewTeacher').locator('#screen-dashboard').waitFor({state:'attached'})}
async function audit(page){return page.evaluate(()=>{
 const rgb=c=>c.match(/[\d.]+/g)?.map(Number)||[0,0,0,0],l=c=>c.slice(0,3).map(n=>n/255).reduce((s,n,i)=>s+[.2126,.7152,.0722][i]*(n<=.04045?n/12.92:((n+.055)/1.055)**2.4),0),ratio=(a,b)=>(Math.max(l(a),l(b))+.05)/(Math.min(l(a),l(b))+.05);
 function back(el){for(let n=el;n;n=n.parentElement){const s=getComputedStyle(n);if(/gradient/.test(s.backgroundImage)){const colors=[...s.backgroundImage.matchAll(/rgba?\([^)]*\)/g)].map(m=>rgb(m[0])).filter(c=>c.length===3||c[3]===1);if(colors.length)return colors}const c=rgb(s.backgroundColor);if(c.length===3||c[3]===1)return [c]}return [[255,255,255]]}
 return [...document.querySelectorAll('#apTeacherSetup *')].filter(n=>n.childElementCount===0&&(n.textContent.trim()||n.matches('input[type=text]'))&&!n.closest('svg')&&n.checkVisibility({checkOpacity:true,checkVisibilityCSS:true})).map(n=>{const s=getComputedStyle(n),min=Math.min(...back(n).map(c=>ratio(rgb(s.color),c))),size=parseFloat(s.fontSize),threshold=size>=24||size>=18.66&&Number(s.fontWeight)>=700?3:4.5;return {text:(n.textContent.trim()||n.value).slice(0,60),ratio:min,threshold,color:s.color}}).filter(x=>x.ratio+.01<x.threshold);
 })}
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const ctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await ctx.route('https://**',r=>r.abort());
  await ctx.addInitScript(({BRAND,fixture})=>{if(!localStorage.getItem(BRAND))localStorage.setItem(BRAND,JSON.stringify(fixture));if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[],lessons:[],payments:[],workoutPlans:[],customData:{preserve:71}}));const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(window.__failKey===key)throw Error('quota');return set.call(this,key,value)}},{BRAND,fixture});
  const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port+'/index.html');await page.waitForFunction(()=>window.__setupTest);await activate(page);
  const frame=page.frameLocator('#apPreviewTeacher'),baseline=await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1'));
  for(const design of ['atual','neon','metal','performance','deep']){
   await page.evaluate(()=>APeditTeacherBrand());await page.locator('#apsDesigns button').nth(['atual','neon','metal','performance','deep'].indexOf(design)).click();
   await page.locator('[data-setup-mode="light"]').click();assert.equal(await page.locator('#apTeacherSetup').getAttribute('data-appearance'),'light');assert.deepEqual(await audit(page),[],design+' light contrast');
   await page.locator('#apsSave').click();await frame.locator('body').evaluate(()=>AgendaAppearance.getMode()==='light'||Promise.reject(Error('light not applied')));
   const colors=await frame.locator('body').evaluate(()=>AgendaColors.get());assert.equal(colors.primary,fixture.main.toLowerCase());assert.equal(colors.secondary,fixture.support.toLowerCase());
   await frame.locator('body').evaluate(()=>{openColorPanel();chooseTeacherAppearance('dark');closeDialog('colorPanelDialog')});
   await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-mode="dark"]').getAttribute('aria-pressed'),'true');assert.deepEqual(await audit(page),[],design+' dark contrast');
   await page.locator('#apsSave').click();assert.equal(await frame.locator('body').evaluate(()=>AgendaAppearance.getMode()),'dark','brand save retains panel selection');
  }
  await page.evaluate(()=>APeditTeacherBrand());await page.locator('[data-setup-mode="light"]').click();
  for(const width of [320,360,390,480]){await page.setViewportSize({width,height:844});assert.ok(await page.locator('.aps-mode-options[aria-label="Modo de exibição do professor"]').evaluate(n=>n.getBoundingClientRect().right<=innerWidth&&[...n.querySelectorAll('button')].every(b=>b.scrollWidth<=b.clientWidth+1)),'fits '+width)}
  await page.setViewportSize({width:390,height:844});await page.locator('#apTeacherSetup').evaluate(n=>n.scrollTop=0);await page.screenshot({path:path.join(review,'setup_light_review.png')});
  // Unsaved mode previews must cancel without modifying stored colors.
  const stored=await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_design_v1'));await page.locator('#apsClose').click();assert.equal(await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_design_v1')),stored);await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('#apTeacherSetup').getAttribute('data-appearance'),'dark');
  // Quota failure keeps the editor open and restores every previous value.
  await page.locator('[data-setup-mode="light"]').click();const before=await page.evaluate(()=>Object.fromEntries(Object.entries(localStorage)));await page.evaluate(()=>__failKey='agendaPersonalTL_design_v1');await page.locator('#apsSave').click();assert.ok(await page.locator('#apTeacherSetup').isVisible());assert.match(await page.locator('#apsStatus').innerText(),/Não foi possível salvar/);assert.deepEqual(await page.evaluate(()=>Object.fromEntries(Object.entries(localStorage))),before);await page.evaluate(()=>__failKey='');
  await page.locator('#apsSave').click();assert.equal(await frame.locator('body').evaluate(()=>AgendaAppearance.getMode()),'light');
  await page.reload();await page.waitForFunction(()=>window.__setupTest);await activate(page);assert.equal(await frame.locator('body').evaluate(()=>AgendaAppearance.getMode()),'light','restart does not reset saved mode');
  await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-mode="light"]').getAttribute('aria-pressed'),'true');
  await page.locator('[data-setup-mode="dark"]').click();await page.locator('#apTeacherSetup').evaluate(n=>n.scrollTop=0);await page.screenshot({path:path.join(review,'setup_dark_review.png')});
  // A color preset changes accents only, in either mode, even with a custom background.
  for(const mode of ['light','dark']){
   await page.locator('[data-setup-mode="'+mode+'"]').click();
   const background=mode==='light'?'#f2edf6':'#121f2e';await page.locator('#apsBg').fill(background);await page.locator('#apsBg').dispatchEvent('input');
   const count=await page.locator('#apsPresets button').count();assert.ok(count>1);
   for(let i=0;i<count;i++){
    await page.locator('#apsPresets button').nth(i).click();assert.equal(await page.locator('#apTeacherSetup').getAttribute('data-appearance'),mode,'preset '+i+' keeps '+mode);assert.equal(await page.locator('#apsBg').inputValue(),background,'exact custom background kept');assert.equal(await page.locator('#apsPresets button').nth(i).getAttribute('aria-pressed'),'true');
   }
   const main=await page.locator('#apsMain').inputValue(),support=await page.locator('#apsSupport').inputValue();await page.locator('#apsSave').click();assert.equal(await frame.locator('body').evaluate(()=>AgendaAppearance.getMode()),mode);const saved=await frame.locator('body').evaluate(()=>AgendaColors.get());assert.equal(saved.background,background);assert.equal(saved.primary,main);assert.equal(saved.secondary,support);await page.evaluate(()=>APeditTeacherBrand());
  }
  // The missing control must exist in the actual entry setup, not only the frame.
  const finishKey='agendaPersonalTL_icon_finish_v1';
  assert.equal(await page.locator('[data-setup-finish="matte"]').count(),1);
  assert.ok(await page.locator('.aps-appearance .aps-finish').count(),'finish is next to light/dark');
  const savedFinish=await page.evaluate(key=>localStorage.getItem(key),finishKey);
  await page.locator('[data-setup-finish="matte"]').click();assert.equal(await page.locator('[data-setup-finish="matte"]').getAttribute('aria-pressed'),'true');
  assert.equal(await page.evaluate(key=>localStorage.getItem(key),finishKey),savedFinish,'draft does not silently save');
  await page.locator('#apsClose').click();await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-finish="theme"]').getAttribute('aria-pressed'),'true','cancel reloads the saved preference');
  for(const mode of ['light','dark']){
   await page.locator('[data-setup-mode="'+mode+'"]').click();await page.locator('[data-setup-finish="matte"]').click();
   const palette=await page.locator('#apsMain').inputValue(),background=await page.locator('#apsBg').inputValue();
   for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.ok(await page.locator('.aps-mode-options[aria-label="Acabamento dos ícones"]').evaluate(n=>n.getBoundingClientRect().right<=innerWidth&&[...n.querySelectorAll('button')].every(b=>b.scrollWidth<=b.clientWidth+1)),'finish fits '+width)}
   await page.setViewportSize({width:390,height:844});await page.locator('.aps-appearance').screenshot({path:path.join(review,'setup_finish_'+mode+'.png')});
   await page.locator('#apsSave').click();await frame.locator('body').evaluate(()=>AgendaIconFinish.get()==='matte'||Promise.reject(Error('matte not applied')));
   assert.equal(await frame.locator('body').evaluate(()=>AgendaAppearance.getMode()),mode);assert.equal(await frame.locator('body').evaluate(()=>AgendaColors.get().primary),palette);assert.equal(await frame.locator('body').evaluate(()=>AgendaColors.get().background),background);
   await frame.locator('body').evaluate(()=>{openColorPanel();AgendaIconFinish.set('theme');closeDialog('colorPanelDialog')});
   await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-finish="theme"]').getAttribute('aria-pressed'),'true','setup reads panel choice');
  }
  // Card color is a separate draft and does not replace the chosen icon finish.
  const oldCards=await page.evaluate(key=>localStorage.getItem(key),finishKey);
  await page.locator('[data-setup-cards="colored"]').click();assert.equal(await page.evaluate(key=>localStorage.getItem(key),finishKey),oldCards);await page.locator('#apsClose').click();await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-cards="theme"]').getAttribute('aria-pressed'),'true');
  await page.locator('[data-setup-cards="colored"]').click();for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.ok(await page.locator('.aps-mode-options[aria-label="Cor dos cartões"]').evaluate(n=>n.scrollWidth<=n.clientWidth+1&&[...n.querySelectorAll('button')].every(b=>b.scrollWidth<=b.clientWidth+1)))}await page.locator('#apsSave').click();assert.equal(await frame.locator('body').evaluate(()=>AgendaIconFinish.getCards()),'colored');await frame.locator('body').evaluate(()=>AgendaIconFinish.set('matte'));assert.equal(await frame.locator('body').evaluate(()=>AgendaIconFinish.getCards()),'colored');await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-cards="colored"]').getAttribute('aria-pressed'),'true');
  await page.locator('[data-setup-cards="theme"]').click();await page.locator('#apsSave').click();assert.equal(await frame.locator('body').evaluate(()=>AgendaIconFinish.getCards()),'theme');await page.evaluate(()=>APeditTeacherBrand());
  // Teacher text size is visible in setup, drafts cancel, and save reaches the real frame.
  const textKey='agendaPersonalTL_teacher_text_v1';
  assert.equal(await page.locator('[data-setup-text]').count(),3);
  const oldText=await page.evaluate(key=>localStorage.getItem(key),textKey);
  await page.locator('[data-setup-text="xlarge"]').click();assert.equal(await page.evaluate(key=>localStorage.getItem(key),textKey),oldText);
  await page.locator('#apsClose').click();await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-text="normal"]').getAttribute('aria-pressed'),'true');
  await page.locator('[data-setup-text="xlarge"]').click();await page.locator('.aps-appearance').screenshot({path:path.join(review,'setup-text-extra-large.png')});const textBefore=await page.evaluate(()=>Object.fromEntries(Object.entries(localStorage)));await page.evaluate(key=>__failKey=key,textKey);await page.locator('#apsSave').click();assert.match(await page.locator('#apsStatus').innerText(),/Não foi possível salvar/);assert.deepEqual(await page.evaluate(()=>Object.fromEntries(Object.entries(localStorage))),textBefore);await page.evaluate(()=>__failKey='');
  for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.ok(await page.locator('.aps-text-options').evaluate(n=>n.getBoundingClientRect().right<=innerWidth&&[...n.querySelectorAll('button')].every(b=>b.scrollWidth<=b.clientWidth+1)),'text options fit '+width)}
  await page.locator('#apsSave').click();assert.equal(await frame.locator('body').evaluate(()=>APTeacherText.get()),'xlarge');
  await frame.locator('body').evaluate(()=>APTeacherText.set('large'));await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-text="large"]').getAttribute('aria-pressed'),'true','setup reads panel text choice');
  // Failure while writing this preference rolls back the rest of the save too.
  await page.locator('[data-setup-finish="matte"]').click();const beforeFinish=await page.evaluate(()=>Object.fromEntries(Object.entries(localStorage)));await page.evaluate(key=>__failKey=key,finishKey);await page.locator('#apsSave').click();
  assert.ok(await page.locator('#apTeacherSetup').isVisible());assert.match(await page.locator('#apsStatus').innerText(),/Não foi possível salvar/);assert.deepEqual(await page.evaluate(()=>Object.fromEntries(Object.entries(localStorage))),beforeFinish);await page.evaluate(()=>__failKey='');
  await page.locator('#apsSave').click();await page.reload();await page.waitForFunction(()=>window.__setupTest);await activate(page);assert.equal(await frame.locator('body').evaluate(()=>AgendaIconFinish.get()),'matte','restart retains saved finish');
  await page.evaluate(()=>APeditTeacherBrand());assert.equal(await page.locator('[data-setup-finish="matte"]').getAttribute('aria-pressed'),'true');
  assert.equal(await page.evaluate(()=>localStorage.getItem('agendaPersonalTL_v1')),baseline,'business records unchanged');assert.deepEqual(errors,[]);
  console.log('PASS: real entry personalization → save → teacher frame across 5 designs; finish control in the setup beside light/dark, saved in both modes, synchronized with panel, cancel/restart/quota rollback, preserved brand/colors/data and 3–4 mobile widths.');
 }finally{await browser.close();server.close()}}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
