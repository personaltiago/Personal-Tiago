'use strict';
// Runs the REAL ap-native-mirror script from professor.html against a fake Android bridge and a fake localStorage.
// It checks: automatic copy after saving, only the main key is copied, the copy is not shrunk by tiny/empty data
// (protection against data loss), the explicit "update now" path, status reporting, and the card text in the meter.
// It does not run on a physical device; the Java side is checked by tests/verify_native_mirror.py.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const file=process.argv[2]||path.join(__dirname,'..','web','native-release.agenda.json');
const html=JSON.parse(fs.readFileSync(file,'utf8')).files['professor.html'];
const m=html.match(/<script id="ap-native-mirror">([\s\S]*?)<\/script>/);assert.ok(m,'Cópia no telefone ausente no professor.html');
assert.ok(html.indexOf('id="ap-native-mirror"')<html.indexOf('id="ap-storage-meter"'),'A cópia precisa carregar antes do cartão Armazenamento');
let cases=0;const eq=(n,a,b)=>{cases++;assert.deepEqual(a,b,n)},ok=(n,v)=>{cases++;assert.ok(v,n)};
function fixture(withBridge=true){
 const store=new Map(),timers=[];let info={exists:false},saved=null;const calls=[];
 class Storage{setItem(k,v){store.set(k,String(v))}getItem(k){return store.has(k)?store.get(k):null}}
 const ls=new Storage(),win={};let hash;
 const bridge={mirrorSave(k,v){calls.push(['save',k]);if(k!=='agendaPersonalTL_v1')return false;if(info.exists&&info.length>20000&&v.length<info.length/2)return false;saved=v;info={exists:true,length:v.length,bytes:v.length,hash:hash(v),savedAt:1700000000000};return true},
  mirrorSaveForce(k,v){calls.push(['force',k]);saved=v;info={exists:true,length:v.length,bytes:v.length,hash:hash(v),savedAt:1700000000000};return true},
  mirrorInfo(){return JSON.stringify(info)}};
 if(withBridge)win.Android=bridge;win.window=win;win.localStorage=ls;win.Storage=Storage;
 const doc={hidden:false,addEventListener(){}};
 new Function('window','document','localStorage','Storage','addEventListener','setTimeout','clearTimeout','setInterval','Math',m[1])(win,doc,ls,Storage,()=>{},f=>{timers.push(f);return timers.length},()=>{},()=>0,Math);
 hash=win.APNativeMirror.hash;
 return{ls,win,timers,calls,get saved(){return saved},run(){const t=timers.splice(0);t.forEach(f=>f())}};
}
let f=fixture();
f.ls.setItem('agendaPersonalTL_v1','{"alunos":[1,2,3]}');f.run();
eq('copia automática após salvar',f.saved,'{"alunos":[1,2,3]}');
let st=f.win.APNativeMirror.status();ok('status em dia',st.available&&st.exists&&st.inSync&&!st.refused);
const before=f.calls.length;f.ls.setItem('outra_chave','{"x":1}');f.run();eq('outras chaves não geram cópia',f.calls.length,before);
f.ls.setItem('agendaPersonalTL_v1','{"alunos":[1,2,3,4]}');f.run();eq('nova gravação atualiza a cópia',f.saved,'{"alunos":[1,2,3,4]}');
const big='{"x":"'+'a'.repeat(40000)+'"}';f.ls.setItem('agendaPersonalTL_v1',big);f.run();eq('cópia grande gravada',f.saved,big);
f.ls.setItem('agendaPersonalTL_v1','{}');f.win.APNativeMirror.flush();eq('dados quase vazios NÃO substituem a cópia grande',f.saved,big);
st=f.win.APNativeMirror.status();ok('situação marca recusa e fora de sincronia',st.refused&&!st.inSync);
ok('atualizar agora força a gravação',f.win.APNativeMirror.now()&&f.saved==='{}'&&f.win.APNativeMirror.status().inSync);
f=fixture(false);f.ls.setItem('agendaPersonalTL_v1','{"a":1}');f.run();eq('sem ponte nativa (navegador) não faz nada nem falha',f.win.APNativeMirror.status(),{available:false});
f=fixture();f.ls.setItem('agendaPersonalTL_v1','{"a":1}');f.run();f.win.localStorage=null;
// cartão: texto da situação
const meter=html.match(/<script id="ap-storage-meter">([\s\S]*?)<\/script>/)[1];
ok('cartão tem a seção Cópia no telefone',meter.includes('Cópia no telefone')&&meter.includes('data-mirror-now')&&meter.includes('mirrorLine'));
ok('cartão confirma antes de substituir cópia maior',/status\(\)\.refused&&!confirm\(/.test(meter));
console.log('PASS Cópia no telefone: '+cases+' verificações (ponte simulada, sem aparelho).');
