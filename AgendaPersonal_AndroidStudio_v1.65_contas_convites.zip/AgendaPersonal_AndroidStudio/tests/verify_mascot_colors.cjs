'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets'),review=process.env.AGENDA_REVIEW_DIR;
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://local').pathname.slice(1)||'index.html';if(!['index.html','professor.html','cadastro.html','avaliacoes.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:900},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[{id:'saved-student',name:'Aluno de teste',studentType:'presencial'}],workoutFeedbackRequests:[],workoutFeedbackDeleted:{}}));const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.failPetSave&&(k.startsWith('agenda_teacher_mascot_v1_')||k.includes('agenda_demo_exercise_sessions_v1_')))throw new DOMException('Full','QuotaExceededError');return set.call(this,k,v)}});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  async function boot(role,uid='colors_'+role){
   await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>!!window.APmascot);
   await page.evaluate(async({role,uid})=>{
    await APMascotArt.load();window.APaccounts={isTeacher:()=>role==='teacher',teacherUid:()=>uid};
    if(role==='teacher'){document.getElementById('apPreviewOverlay').classList.add('is-open');document.getElementById('apPreviewTeacher').srcdoc=await(await fetch('professor.html')).text()}
    else{const student={id:uid,name:'Aluno de teste'},area=APStudentModel.makeArea({students:[student],workoutPlans:[]},student);window.__AP_STUDENT_CONTEXT={storageId:uid,role:'student',area,profile:area.profile};APstudentUI.activate();route('home')}
   },{role,uid});
   if(role==='teacher')await page.frameLocator('#apPreviewTeacher').locator('#apTeacherMascotOpen').waitFor();
  }
  const open=role=>page.evaluate(role=>role==='teacher'?APteacherMascot.open('colors'):APmascot.open('colors'),role);
  let checked=0;
  for(const role of (process.env.AGENDA_COLORS_RASTER_ONLY?[]:['teacher','student'])){
   await boot(role);
   const frame=page.frameLocator('#apPreviewTeacher'),card=role==='teacher'?frame.locator('#apTeacherMascotOpen'):page.locator('#apMascotHome');
   const business=role==='teacher'?await frame.locator('body').evaluate(()=>JSON.stringify(state)):null;
   await page.evaluate(role=>{
    const pet={...APMascotModel.fresh(),species:'wolf',name:'Léo',xp:1800,coins:840,owned:['ball','band','shirt','hoodie','home-bamboo'],food:{fruit:2,bowl:1},equipped:{head:'band',body:'hoodie',home:'home-bamboo'},events:[{at:Date.now(),text:'Histórico preservado'}]};
    if(role==='teacher')localStorage.setItem('agenda_teacher_mascot_v1_colors_teacher',JSON.stringify(pet));
    else{const s=exStore();s.mascot=pet;s.history=[{id:'saved',finishedAt:Date.now()-86400000,workoutName:'Treino preservado'}];s.active={saved:{id:'saved',startedAt:Date.now(),loads:{0:[20]},done:{0:[true]}}};exSave(s)}
   },role);
   await open(role);assert.equal(await page.locator('#apMascotTab-colors').textContent(),'Cores');assert.equal(await page.locator('#apMascotTab-clothes').count(),0);
   for(const species of ['kitten','wolf','capybara','panda','rooster','alligator'])for(const xp of [0,600,1800]){
    console.log('Checking '+role+'/'+species+'/'+xp);
    await page.evaluate(({role,species,xp})=>{const store=role==='teacher'?APteacherMascot.read():exStore();store.mascot={...APmascot.state(),species,xp};if(role==='teacher')APteacherMascot.save(store);else exSave(store)},{role,species,xp});await open(role);
    const before=await page.evaluate(role=>{const s=role==='teacher'?APteacherMascot.read():exStore();s.mascot=APmascot.state();delete s.mascot.colors;return JSON.stringify(s)},role);
    const options=await page.evaluate(species=>APMascotModel.colorsFor(species),species);assert.ok(options.length>=5);
    for(const {id:color} of options){
     await page.locator('[data-mascot-action="color"][data-mascot-item="'+color+'"]').evaluate(n=>n.click());
     assert.equal(await page.locator('.ap-mascot-colors [aria-pressed="true"]').count(),1);
     assert.equal(await page.locator('#apMascotArt>svg').getAttribute('data-mascot-color'),color);
     assert.equal(await card.locator('.ap-teacher-mascot-mark>svg,.ap-mascot-mini>svg').getAttribute('data-mascot-color'),color,role+' home refreshes color even with the same cached portrait');
     assert.equal(await page.locator('#apMascotArt filter').count(),0,'no global tint filter');assert.equal(await page.locator('#apMascotArt [data-mascot-frame]').count(),0,'complete isolated portrait, no cropped neighboring cells');assert.equal(await page.locator('#apMascotArt image').getAttribute('preserveAspectRatio'),'xMidYMid meet');
     const after=await page.evaluate(role=>{const s=role==='teacher'?APteacherMascot.read():exStore();delete s.mascot.colors;return JSON.stringify(s)},role);assert.equal(after,before,role+'/'+species+'/'+xp+'/'+color+' preserves every other saved field');checked++;
    }
   }
   // Each animal retains its own color, including after reload; default artwork is reversible.
   for(const [species,color] of [['wolf','black'],['panda','white']]){
    await page.evaluate(({role,species})=>{const s=role==='teacher'?APteacherMascot.read():exStore();s.mascot={...APmascot.state(),species};if(role==='teacher')APteacherMascot.save(s);else exSave(s)},{role,species});await open(role);await page.locator('[data-mascot-action="color"][data-mascot-item="'+color+'"]').click();
   }
   await boot(role);await open(role);assert.equal(await page.evaluate(()=>APmascot.state().colors.wolf),'black');assert.equal(await page.evaluate(()=>APmascot.state().colors.panda),'white');
   assert.equal(await page.locator('#apMascotArt>svg').getAttribute('data-mascot-color'),'white');
   const saved=await page.evaluate(role=>JSON.stringify(role==='teacher'?APteacherMascot.read():exStore()),role);await page.evaluate(()=>window.failPetSave=true);
   await page.locator('[data-mascot-action="color"][data-mascot-item="brown"]').click();assert.equal(await page.evaluate(role=>JSON.stringify(role==='teacher'?APteacherMascot.read():exStore()),role),saved,'failed color save is atomic');assert.match(await page.locator('#apMascotStatus').textContent(),/não foram alterados/);assert.equal(await page.locator('#apMascotArt>svg').getAttribute('data-mascot-color'),'white');await page.evaluate(()=>window.failPetSave=false);
   for(const width of [320,390,480])for(const mode of ['claro','escuro']){
    await page.setViewportSize({width,height:900});await page.locator('#apMascot').evaluate((n,mode)=>n.classList.toggle('ap-mascot-light',mode==='claro'),mode);
    assert.ok(await page.locator('.ap-mascot-sheet').evaluate(n=>n.scrollWidth<=n.clientWidth+1));assert.equal(await page.locator('.ap-mascot-colors button').count(),6);
    assert.ok(await page.locator('.ap-mascot-colors').evaluate(n=>[...n.children].every(b=>b.getBoundingClientRect().height>=44&&b.scrollWidth<=b.clientWidth+1)));
   }
   await page.locator('#apMascotTab-shop').click();assert.equal(await page.locator('[data-mascot-item="shirt"],[data-mascot-item="band"],[data-mascot-item="hoodie"]').count(),0,'clothes no longer offered in the UI');assert.ok(await page.evaluate(()=>APmascot.state().owned.includes('hoodie')),'previous purchases retained');
   await page.locator('#apMascotTab-history').click();await page.keyboard.press('ArrowRight');assert.equal(await page.locator('#apMascotTab-colors').getAttribute('aria-selected'),'true');
   if(review){fs.mkdirSync(review,{recursive:true});await page.setViewportSize({width:390,height:1000});await page.locator('#apMascotTabs').evaluate(n=>n.scrollIntoView({block:'start'}));await page.screenshot({path:path.join(review,role+'-colors.png')});await page.evaluate(()=>APmascot.close());await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));await card.screenshot({path:path.join(review,role+'-panda-white.png')})}
   else await page.evaluate(()=>APmascot.close());
   if(business)assert.equal(await frame.locator('body').evaluate(()=>JSON.stringify(state)),business);
   await boot(role,'colors_other_'+role);await open(role);assert.equal(await page.evaluate(()=>Object.keys(APmascot.state().colors).length),0,'colors isolated by account');
  }
  // Render every palette in isolation and sample actual raster output. Neutral
  // panda fur must also change, alpha and the three floor-anchored sizes stay intact.
  if(process.env.AGENDA_COLORS_RASTER_ONLY)await boot('student');
  const raster=await page.evaluate(async()=>{
   const results=[];
   for(const species of APMascotModel.choices.map(c=>c.id))for(const xp of [0,600,1800]){
    const variants=[];
    for(const c of APMascotModel.colorsFor(species)){
     const holder=document.createElement('div');holder.innerHTML=APMascotArt.render({species,xp,name:'Teste',colors:{[species]:c.id}});const svg=holder.firstChild;svg.setAttribute('xmlns','http://www.w3.org/2000/svg');svg.setAttribute('width','128');svg.setAttribute('height','128');
     const image=new Image();await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=reject;image.src='data:image/svg+xml;base64,'+btoa(unescape(encodeURIComponent(svg.outerHTML)))});
     const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);const data=ctx.getImageData(0,0,128,128).data,mean=[0,0,0];let count=0,alpha=0;const bounds=[128,128,-1,-1];
     for(let i=0;i<data.length;i+=4){alpha+=data[i+3];if(data[i+3]>32){const index=i/4,x=index%128,y=Math.floor(index/128);bounds[0]=Math.min(bounds[0],x);bounds[1]=Math.min(bounds[1],y);bounds[2]=Math.max(bounds[2],x);bounds[3]=Math.max(bounds[3],y)}if(data[i+3]>240){for(let ch=0;ch<3;ch++)mean[ch]+=data[i+ch];count++}}
     const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',data))].map(b=>b.toString(16).padStart(2,'0')).join('');variants.push({id:c.id,mean:mean.map(n=>n/count),alpha,count,bounds,hash});
    }
    results.push({species,xp,variants});
   }
   return results;
  });
  for(const {species,xp,variants} of raster){
   assert.ok(variants.length>=5,species+' has five natural designs');assert.equal(new Set(variants.map(v=>v.hash)).size,variants.length,species+'/'+xp+' renders different actual drawings');
   for(const v of variants){assert.ok(v.count>50,species+'/'+xp+'/'+v.id+' portrait is visible');assert.ok(v.alpha<128*128*255*.95,species+'/'+xp+'/'+v.id+' keeps a transparent cutout');}
   if(['wolf','panda','kitten'].includes(species)){const black=variants.find(v=>v.id==='black'),white=variants.find(v=>v.id==='white');assert.ok(white.mean.reduce((a,b)=>a+b,0)>black.mean.reduce((a,b)=>a+b,0)+180,species+'/'+xp+' has truly white and truly dark coats');}
  }
  if(review){
   await page.setViewportSize({width:1100,height:1400});
   await page.evaluate(()=>{const root=document.createElement('main');root.id='coatReview';root.style='position:absolute;z-index:2147483600;left:0;top:0;width:1100px;background:#e8ece5;color:#202720;padding:24px;font:14px Arial;display:grid;grid-template-columns:repeat(6,1fr);gap:12px';document.body.append(root);for(const species of APMascotModel.choices)for(const color of APMascotModel.colorsFor(species.id)){const cell=document.createElement('article');cell.style='text-align:center;background:#f7f8f4;border-radius:14px;padding:8px';cell.innerHTML='<div style="aspect-ratio:1">'+APMascotArt.render({species:species.id,name:species.name,xp:1800,colors:{[species.id]:color.id}})+'</div><b>'+species.name+' · '+color.name+'</b>';cell.querySelector('svg').style='display:block;width:100%;height:100%';root.append(cell)}});
   await page.locator('#coatReview').screenshot({path:path.join(review,'natural-coats-adult-overview.png')});
  }
  assert.deepEqual(errors,[]);if(process.env.AGENDA_COLORS_RASTER_ONLY)console.log('PASS: raster output of six species × three phases with at least five natural coat drawings each; distinct pixels, transparent cutouts and genuinely white/black fur.');else console.log('PASS: '+checked+' actual teacher/student color selections; six species × three phases × species-specific coats, no tint filters, distinct natural drawings including white/black panda, transparent cutouts, per-species reload, cached teacher refresh, free changes, exact progress and legacy purchases, failed-save rollback, account isolation, 12 mobile/theme layouts and keyboard tabs. Local Chromium; network/auth simulated.');
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);server.close();process.exitCode=1});
