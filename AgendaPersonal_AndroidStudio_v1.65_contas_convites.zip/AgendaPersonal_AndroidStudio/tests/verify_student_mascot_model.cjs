'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const ctx={Date,console};ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.resolve(__dirname,'../web/student-mascot-model.js'),'utf8'),ctx);const M=ctx.APMascotModel;
const at=(day,week=0)=>new Date(2026,9,18+day+week*7,16,30).getTime();
const record=(day,week=0)=>({id:'p~d',startedAt:at(day,week)-3600000,finishedAt:at(day,week),incomplete:false,exerciseRecords:[{done:[true,true],sets:2}]});
for(const goal of [1,2,3,4,5,6,7]){
 let s=M.fresh(goal);
 for(let day=0;day<goal;day++){const r=M.reward(s,record(day));assert.equal(r.reason,'earned');s=r.state}
 assert.equal(s.xp,300,'equal XP for weekly goal '+goal);assert.equal(s.coins,100*goal);
 assert.equal(M.reward(s,record(0)).reason,'duplicate');
 const second={...record(0),id:'another',startedAt:at(0)-2000000};assert.equal(M.reward(s,second).reason,'day');
 if(goal<7)assert.equal(M.reward(s,record(goal)).reason,'week');
 assert.equal(M.reward(s,record(0,1)).reason,'earned','next week unlocks');
 assert.equal(M.weekKey(at(0)),M.weekKey(at(6)));assert.notEqual(M.weekKey(at(6)),M.weekKey(at(0,1)));
}
let s=M.fresh(3);s=M.reward(s,record(0)).state;s=M.change(s,'goal','1').state;assert.equal(s.weeks[M.weekKey(at(0))].goal,3,'active week goal is locked');assert.equal(M.reward(s,record(0,1)).state.weeks[M.weekKey(at(0,1))].goal,1);
assert.equal(M.reward(null,{...record(0),incomplete:true}).reason,'incomplete');assert.equal(M.reward(null,{...record(0),exerciseRecords:[{done:[true,false]}]}).reason,'incomplete');
let evolving=M.fresh(1);for(let w=0;w<6;w++){evolving=M.reward(evolving,record(0,w)).state;assert.equal(M.phase(evolving.xp).id,w<1?'baby':w<5?'teen':'adult')}
s=M.fresh();s.coins=500;s.xp=700;let result=M.change(s,'buy','hoodie');assert.equal(result.ok,true);s=result.state;assert.equal(s.coins,240);assert.equal(s.xp,700);assert.equal(M.change(s,'buy','hoodie').ok,false);
result=M.change(s,'use','hoodie');assert.equal(result.state.equipped.body,'hoodie');assert.equal(result.state.xp,700);assert.equal(M.change(result.state,'remove','body').state.equipped.body,'');
result=M.change(s,'buy','fruit');assert.equal(result.state.coins,215);assert.equal(result.state.food.fruit,1);s=M.change(result.state,'use','fruit').state;assert.equal(s.food.fruit,0);assert.equal(s.xp,700);assert.equal(M.change(s,'use','fruit').ok,false);
assert.equal(M.change(M.fresh(),'buy','band').ok,false);assert.equal(M.change(s,'use','band').ok,false);assert.equal(M.change(s,'goal',8).ok,false);assert.equal(M.change(s,'name',' ').ok,false);assert.equal(M.change(s,'name','x'.repeat(25)).ok,false);
const prior=JSON.stringify(s);M.change(s,'buy','band');M.reward(s,record(0));assert.equal(JSON.stringify(s),prior,'pure transitions do not mutate their input');
assert.equal(M.read({...s,coins:-99,xp:NaN}).coins,0);assert.equal(M.read({...s,coins:-99,xp:NaN}).xp,0);
assert.equal(M.read({...s,owned:{broken:true}}).owned.join(','),'home-yard','malformed inventory keeps only the free home and cannot block training');
assert.equal(M.reward({...s,owned:42},record(0)).reason,'earned');
assert.equal(M.reward(s,{...record(0),exerciseRecords:'broken'}).reason,'incomplete');
const savedPet={...s,species:'panda',name:'Lua',xp:1900,coins:840,owned:['hoodie','band'],equipped:{body:'hoodie',head:'band'}};
for(const choice of M.choices){const changed=M.change(savedPet,'species',choice.id);assert.equal(changed.ok,true);assert.equal(changed.state.species,choice.id);for(const key of ['name','xp','coins','owned','equipped','food','rewards','weeks','events'])assert.equal(JSON.stringify(changed.state[key]),JSON.stringify(M.read(savedPet)[key]),'choice preserves '+key)}
assert.equal(M.change(savedPet,'species','unknown').ok,false);assert.equal(M.fresh().species,'');
const legacy={...savedPet};delete legacy.species;assert.equal(M.read(legacy).species,'capybara');assert.equal(M.read(legacy).xp,1900);
console.log('PASS: seven weekly frequencies earn 300 XP; per-session/day/week deduplication; Sunday boundaries; locked goals; 3 growth stages; no penalties; coin balance, clothes, food, ownership, validation and pure rollback-safe transitions.');

const legacyPet={...savedPet,colors:undefined};
assert.equal(M.color(M.read(legacyPet)).id,'original');
let painted=M.read(legacyPet);
for(const species of M.choices){
 painted=M.change(painted,'species',species.id).state;const options=M.colorsFor(species.id);assert.ok(options.length>=5);assert.ok(new Set(options.map(c=>c.id)).size===options.length);
 for(const color of options){
  const before=JSON.stringify(painted),r=M.change(painted,'color',color.id);assert.equal(r.ok,true);assert.equal(JSON.stringify(painted),before,'coat does not mutate source');
  const expected=JSON.parse(before),actual=JSON.parse(JSON.stringify(r.state));delete expected.colors;delete actual.colors;assert.deepEqual(actual,expected,'coat preserves all progress and legacy inventory');assert.equal(M.color(r.state).id,color.id);painted=r.state;
 }
 const selected=options[1].id;painted=M.change(painted,'color',selected).state;
}
assert.equal(Object.keys(M.read(painted).colors).length,6);
assert.equal(M.change(painted,'color','url(evil)').ok,false);assert.equal(M.change(M.fresh(),'color','black').ok,false);
assert.equal(M.change({...painted,species:'alligator'},'color','blue').ok,false,'species cannot use artificial generic colors');
const aliases={wolf:{black:'black',red:'brown',blue:'original',gold:'sand',violet:'original'},alligator:{black:'dark',red:'sand',blue:'olive',gold:'sand',violet:'original'},panda:{black:'black',red:'cinnamon',blue:'original',gold:'cream',violet:'brown'},kitten:{black:'black',red:'ginger',blue:'tabby',gold:'ginger',violet:'calico'},capybara:{black:'chocolate',red:'chocolate',blue:'ash',gold:'sand',violet:'ivory'},rooster:{black:'black',red:'original',blue:'barred',gold:'buff',violet:'white'}};
for(const [species,values] of Object.entries(aliases))for(const [oldColor,newColor] of Object.entries(values)){
 const input={...legacyPet,species,colors:{[species]:oldColor}},read=M.read(input);assert.equal(M.color(read).id,newColor);assert.equal(read.xp,legacyPet.xp);assert.equal(read.coins,legacyPet.coins);assert.equal(JSON.stringify(input.colors),JSON.stringify({[species]:oldColor}),'reading legacy choices is nonmutating');
}
assert.equal(M.color({...painted,species:'alligator',colors:{}}).id,'original');assert.equal(M.color({...painted,species:'alligator',colors:{}}).frame,0,'default alligator is green');
for(const species of M.choices){painted=M.change(painted,'species',species.id).state;painted=M.change(painted,'color','original').state;assert.equal(M.color(painted).id,'original')}
console.log('PASS: at least five species-specific natural designs, free reversible changes, safe legacy-color migration, green default alligator, invalid/cross-species rejection and exact preservation of XP, coins, purchases, equipment, rewards, goals and history.');
// Species-specific poses are durable virtual purchases, not repeat-use charges.
for(const c of M.choices){
 let pet=M.read({...savedPet,species:c.id,coins:1000,colors:{[c.id]:M.colorsFor(c.id)[1].id}});const base=M.read(pet);assert.equal(M.posesFor(c.id).length,4);assert.equal(M.pose(pet).id,'default');
 for(const p of M.posesFor(c.id).slice(1)){
  assert.equal(M.change(pet,'pose',p.id).ok,false,'unowned pose rejected');const before=JSON.stringify(pet),bought=M.change(pet,'buy',p.itemId);assert.equal(bought.ok,true);assert.equal(JSON.stringify(pet),before,'buy does not mutate source');assert.equal(bought.state.coins,pet.coins-p.price);assert.equal(M.pose(bought.state).id,p.id);assert.equal(M.change(bought.state,'buy',p.itemId).ok,false,'no duplicate charge');
  const restored=M.read(JSON.parse(JSON.stringify(bought.state)));assert.equal(M.pose(restored).id,p.id);const original=M.change(restored,'pose','default');assert.equal(M.pose(original.state).id,'default');const again=M.change(original.state,'pose',p.id);assert.equal(again.state.coins,restored.coins,'reuse is free');assert.equal(again.state.xp,base.xp);assert.equal(again.state.name,base.name);assert.equal(JSON.stringify(again.state.equipped),JSON.stringify(base.equipped));assert.equal(M.color(again.state).id,M.color(base).id);
  const other=M.choices.find(x=>x.id!==c.id),away=M.change(again.state,'species',other.id);assert.equal(M.pose(away.state).id,'default');assert.equal(M.pose(M.change(away.state,'species',c.id).state).id,p.id,'return remembers pose per species');assert.equal(M.change(away.state,'buy',p.itemId).ok,false,'cross-species purchase rejected');pet=bought.state;
 }
 assert.equal(M.change({...pet,coins:0,owned:['home-yard']},'buy',M.posesFor(c.id)[1].itemId).ok,false);assert.equal(M.pose({...pet,owned:[]}).id,'default','unowned equipped value is ignored');
}
console.log('PASS: 18 species-specific pose purchases, atomic debit and auto-apply, duplicate/cross-species/unowned rejection, free reuse/default, per-species memory, JSON reload, coat/XP/goals/inventory preservation.');
