'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const ctx={Date,console};ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.resolve(__dirname,'../web/student-mascot-model.js'),'utf8'),ctx);const M=ctx.APMascotModel;
const at=(day,week=0)=>new Date(2026,9,18+day+week*7,16,30).getTime();
const record=(day,week=0)=>({id:'p~d',startedAt:at(day,week)-3600000,finishedAt:at(day,week),incomplete:false,exerciseRecords:[{done:[true,true],sets:2}]});
for(const goal of [1,2,3,4,5,6,7]){
 let s=M.fresh(goal);
 for(let day=0;day<goal;day++){const r=M.reward(s,record(day));assert.equal(r.reason,'earned');s=r.state}
 assert.equal(s.xp,300,'equal XP for weekly goal '+goal);assert.equal(s.coins,100*goal);
 assert.equal(M.reward(s,record(0)).reason,'duplicate');
 const second={...record(0),id:'another',startedAt:at(0)-2000000};assert.equal(M.reward(s,second).reason,'day');
 if(goal<7)assert.equal(M.reward(s,record(goal)).reason,'week');
 assert.equal(M.reward(s,record(0,1)).reason,'earned','next week unlocks');
 assert.equal(M.weekKey(at(0)),M.weekKey(at(6)));assert.notEqual(M.weekKey(at(6)),M.weekKey(at(0,1)));
}
let s=M.fresh(3);s=M.reward(s,record(0)).state;s=M.change(s,'goal','1').state;assert.equal(s.weeks[M.weekKey(at(0))].goal,3,'active week goal is locked');assert.equal(M.reward(s,record(0,1)).state.weeks[M.weekKey(at(0,1))].goal,1);
assert.equal(M.reward(null,{...record(0),incomplete:true}).reason,'incomplete');assert.equal(M.reward(null,{...record(0),exerciseRecords:[{done:[true,false]}]}).reason,'incomplete');
let evolving=M.fresh(1);for(let w=0;w<6;w++){evolving=M.reward(evolving,record(0,w)).state;assert.equal(M.phase(evolving.xp).id,w<1?'baby':w<5?'teen':'adult')}
s=M.fresh();s.coins=500;s.xp=700;let result=M.change(s,'buy','hoodie');assert.equal(result.ok,true);s=result.state;assert.equal(s.coins,240);assert.equal(s.xp,700);assert.equal(M.change(s,'buy','hoodie').ok,false);
result=M.change(s,'use','hoodie');assert.equal(result.state.equipped.body,'hoodie');assert.equal(result.state.xp,700);assert.equal(M.change(result.state,'remove','body').state.equipped.body,'');
result=M.change(s,'buy','fruit');assert.equal(result.state.coins,215);assert.equal(result.state.food.fruit,1);s=M.change(result.state,'use','fruit').state;assert.equal(s.food.fruit,0);assert.equal(s.xp,700);assert.equal(M.change(s,'use','fruit').ok,false);
assert.equal(M.change(M.fresh(),'buy','band').ok,false);assert.equal(M.change(s,'use','band').ok,false);assert.equal(M.change(s,'goal',8).ok,false);assert.equal(M.change(s,'name',' ').ok,false);assert.equal(M.change(s,'name','x'.repeat(25)).ok,false);
const prior=JSON.stringify(s);M.change(s,'buy','band');M.reward(s,record(0));assert.equal(JSON.stringify(s),prior,'pure transitions do not mutate their input');
assert.equal(M.read({...s,coins:-99,xp:NaN}).coins,0);assert.equal(M.read({...s,coins:-99,xp:NaN}).xp,0);
assert.equal(M.read({...s,owned:{broken:true}}).owned.length,0,'malformed inventory cannot block training');
assert.equal(M.reward({...s,owned:42},record(0)).reason,'earned');
assert.equal(M.reward(s,{...record(0),exerciseRecords:'broken'}).reason,'incomplete');
const savedPet={...s,species:'panda',name:'Lua',xp:1900,coins:840,owned:['hoodie','band'],equipped:{body:'hoodie',head:'band'}};
for(const choice of M.choices){const changed=M.change(savedPet,'species',choice.id);assert.equal(changed.ok,true);assert.equal(changed.state.species,choice.id);for(const key of ['name','xp','coins','owned','equipped','food','rewards','weeks','events'])assert.equal(JSON.stringify(changed.state[key]),JSON.stringify(M.read(savedPet)[key]),'choice preserves '+key)}
assert.equal(M.change(savedPet,'species','unknown').ok,false);assert.equal(M.fresh().species,'');
const legacy={...savedPet};delete legacy.species;assert.equal(M.read(legacy).species,'capybara');assert.equal(M.read(legacy).xp,1900);
console.log('PASS: seven weekly frequencies earn 300 XP; per-session/day/week deduplication; Sunday boundaries; locked goals; 3 growth stages; no penalties; coin balance, clothes, food, ownership, validation and pure rollback-safe transitions.');
