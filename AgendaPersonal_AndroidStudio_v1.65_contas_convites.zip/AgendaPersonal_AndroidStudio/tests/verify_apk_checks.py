"""Exercise the APK verifier with actual generated pages and simulated SDK tools.

The ZIP fixture is not an installable APK. aapt/apksigner output is simulated;
page bytes, identity, hashes, version guards and feature guards are real.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(os.environ.get('AGENDA_APK_VERIFIER', ROOT / 'tools/verify_apk.py'))
spec = importlib.util.spec_from_file_location('apk_verifier', SOURCE)
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
release = json.loads((ROOT / 'release.json').read_text())
pages = {name + '.html': (ROOT / 'app/src/main/assets' / (name + '.html')).read_bytes()
         for name in ('index', 'professor', 'avaliacoes', 'cadastro')}
assert b'showLessonTimerOverlay' not in pages['professor.html']
checks = 0


def run_case(label, change=None, error=None, badging=None, expected_code=release['versionCode']):
    global checks
    with TemporaryDirectory(prefix='agenda-apk-verifier-') as directory:
        root = Path(directory)
        assets = root / 'app/src/main/assets'
        assets.mkdir(parents=True)
        shutil.copyfile(ROOT / 'release.json', root / 'release.json')
        content = dict(pages)
        if change:
            change(content)
        for name, data in content.items():
            (assets / name).write_bytes(data)
        identity = {key: release[key] for key in ('format', 'applicationId', 'androidVersion', 'versionCode', 'contentVersion', 'sequence')}
        identity['versionCode'] = expected_code
        identity['sourceSha256'] = hashlib.sha256((root / 'release.json').read_bytes()).hexdigest()
        identity['files'] = {name: hashlib.sha256(data).hexdigest() for name, data in content.items()}
        identity_bytes = json.dumps(identity).encode()
        (assets / 'agenda-build.json').write_bytes(identity_bytes)
        archive_path = root / 'compiled-fixture.zip'
        entries = {'assets/' + name: data for name, data in content.items()}
        entries['assets/agenda-build.json'] = identity_bytes
        entries['classes.dex'] = b'SDK fixture: LessonTimerOverlayService'
        if label == 'missing dex service':
            entries['classes.dex'] = b'SDK fixture without the native service'
        if label == 'altered packaged page':
            entries['assets/index.html'] += b'altered'
        if label == 'missing packaged page':
            del entries['assets/cadastro.html']
        if label == 'wrong source identity':
            identity['sourceSha256'] = '0' * 64
            entries['assets/agenda-build.json'] = json.dumps(identity).encode()
            (assets / 'agenda-build.json').write_bytes(entries['assets/agenda-build.json'])
        with ZipFile(archive_path, 'w', ZIP_DEFLATED) as archive:
            for name, data in entries.items():
                archive.writestr(name, data)
        tools = root / 'sdk/build-tools/35.0.0'
        tools.mkdir(parents=True)
        signer = tools / 'apksigner'
        signer.write_text('fixture')
        signer.chmod(0o700)
        commands = []

        def sdk_run(command, **kwargs):
            commands.append(command)
            if command[1:3] == ['dump', 'badging']:
                output = badging or ("package: name='%s' versionCode='%s' versionName='%s'" %
                                     (release['applicationId'], expected_code, release['androidVersion']))
            elif command[1:3] == ['dump', 'xmltree']:
                output = 'android.permission.SYSTEM_ALERT_WINDOW LessonTimerOverlayService'
                if label == 'missing overlay permission':
                    output = 'LessonTimerOverlayService'
            else:
                assert command == [str(signer), 'verify', str(archive_path)], command
                output = ''
            return subprocess.CompletedProcess(command, 0, stdout=output)

        with patch.object(verifier, 'locate_aapt', return_value=tools / 'aapt'), patch.object(verifier.subprocess, 'run', side_effect=sdk_run):
            try:
                result = verifier.verify(archive_path, root / 'sdk', release, expected_code, assets)
            except RuntimeError as exc:
                if error is None or error not in str(exc):
                    raise AssertionError(label + ': ' + str(exc)) from exc
            else:
                assert error is None, label + ': an invalid package was accepted'
                assert result == release['androidVersion']
                assert commands[-1] == [str(signer), 'verify', str(archive_path)]
        checks += 1


run_case('current pages without the removed lesson bridge')
run_case('CI versionCode override', expected_code=1025)
for token in (b'id="financeResults"', b'ap-compact-week-agenda', b'id="ap-rest-floating"', b'ap-rest-grip'):
    run_case('missing current feature ' + token.decode(), lambda files, token=token: files.__setitem__('professor.html', files['professor.html'].replace(token, b'absent-feature')), 'Recurso ausente')
for token in (b'showLessonTimerOverlay', b'workoutRestNotice', b'lesson-timer-floating'):
    run_case('retired view ' + token.decode(), lambda files, token=token: files.__setitem__('professor.html', files['professor.html'] + token), 'Cronômetro retirado')
run_case('missing dex service', error='serviço nativo')
run_case('altered packaged page', error='tela diferente')
run_case('missing packaged page', error='Tela ausente')
run_case('wrong source identity', error='identificação de fontes')
run_case('wrong application version', error='aplicativo/versão esperado', badging="package: name='wrong.app' versionCode='1' versionName='1.0'")
run_case('missing overlay permission', error='permissão ou o serviço')
print(f'PASS: {checks} APK-verifier checks; actual generated pages accepted without the removed lesson bridge; missing features, retired views, wrong bytes/identity/version and native service rejected. aapt/apksigner simulated; no installable APK generated.')
