"""Run every project regression; any failed test makes the command fail.

Node.js, Java 17+, npm install, and pip install -r tests/requirements.txt are
required. AGENDA_CHROMIUM may select an existing Chromium. Android API jars
are optional because assembleDebug/lintDebug perform the full Android check.
"""
import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jobs', type=int, default=2)
    parser.add_argument('--timeout', type=int, default=180)
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--match', default='')
    parser.add_argument('--android-jar', type=Path)
    parser.add_argument('--androidx-jar', type=Path)
    parser.add_argument('--dependency-dir', type=Path)
    args = parser.parse_args()
    if args.jobs < 1 or args.timeout < 1:
        parser.error('jobs and timeout must be positive')
    env = os.environ.copy()
    # Financial fixtures exercise local Brazilian month/day boundaries.
    # A host-wide TZ=UTC must not silently change the fixtures' calendar.
    env['TZ'] = 'America/Cuiaba'
    if not env.get('CODEX_PRIMARY_RUNTIME_NODE_MODULES'):
        package = subprocess.check_output(['node', '-p', "require.resolve('playwright/package.json')"], cwd=ROOT, text=True).strip()
        env['CODEX_PRIMARY_RUNTIME_NODE_MODULES'] = str(Path(package).parent.parent)
    if not env.get('AGENDA_CHROMIUM'):
        browser = subprocess.check_output(['node', '-e', "const {createRequire}=require('node:module');process.stdout.write(createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright').chromium.executablePath())"], cwd=ROOT, env=env, text=True)
        if not Path(browser).is_file():
            parser.error('Install the browser with npx playwright install chromium or set AGENDA_CHROMIUM.')
        env['AGENDA_CHROMIUM'] = browser
    output = (args.output_dir or Path(tempfile.mkdtemp(prefix='agenda-review-'))).resolve()
    output.mkdir(parents=True, exist_ok=True)
    native = (ROOT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateManager.java').read_text()
    version = re.search(r'BASE_VERSION = "([0-9.]+)"', native).group(1)
    sequence = re.search(r'BASE_SEQUENCE = (\d+);', native).group(1)
    bundle = output / 'candidate.agenda.json'
    subprocess.run(['node', 'tools/build_web_update.cjs', version, sequence, str(bundle)], cwd=ROOT, env=env, check=True, stdout=subprocess.DEVNULL)
    tests = [p for p in sorted((ROOT / 'tests').glob('verify_*')) if p.suffix in ('.cjs', '.py') and args.match in p.name]

    def run(test):
        command = ['node' if test.suffix == '.cjs' else sys.executable, str(test)]
        if test.name == 'verify_release_compatibility.cjs':
            command.append(str(bundle))
        if test.name == 'verify_android_compile.py':
            if not args.android_jar or not args.androidx_jar:
                return dict(test=test.name, status='SKIP', reason='Pass --android-jar and --androidx-jar, or run the Android Gradle build separately.')
            command += ['--android-jar', str(args.android_jar.resolve()), '--androidx-jar', str(args.androidx_jar.resolve())]
            if args.dependency_dir:
                command += ['--dependency-dir', str(args.dependency_dir.resolve())]
        started = time.monotonic()
        log = output / (test.name + '.log')
        with log.open('w') as stream:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = process.wait(timeout=args.timeout)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                code = 124
        result = dict(test=test.name, status='PASS' if code == 0 else 'FAIL', code=code, seconds=round(time.monotonic() - started, 1))
        if 'SKIP:' in log.read_text(errors='replace'):
            result['limitation'] = 'External distribution server source was not supplied; local release contracts were verified.'
        print(result['status'] + ': ' + test.name, flush=True)
        return result

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        results = list(pool.map(run, tests))
    counts = {kind: sum(row['status'] == kind for row in results) for kind in ('PASS', 'FAIL', 'SKIP')}
    report = dict(version=version, sequence=int(sequence), counts=counts, results=results,
                  limits=['Android APIs and browser exercised locally. Physical-device behavior, real Firebase authentication, live media playback, actual receipt OCR and the external distribution service require their own integration checks.'])
    (output / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps(counts), flush=True)
    print('Results and logs: ' + str(output), flush=True)
    return 1 if counts['FAIL'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
