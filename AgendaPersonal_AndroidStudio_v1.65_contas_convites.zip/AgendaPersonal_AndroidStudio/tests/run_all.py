"""Checks included in the consolidated native-source distribution."""
from pathlib import Path
import subprocess,sys

root=Path(__file__).resolve().parents[1]
commands=[['node','tools/prepare_assets.cjs'],['node','tools/check_release.cjs','--assets'],[sys.executable,'tests/verify_release_sources.py']]
commands += [['node','tests/verify_'+name+'.cjs'] for name in ['registration_link','reps_by_series','drag_reorder','agenda','availability','finance','pdf_roundtrip','panel_link']]
commands += [[sys.executable,'tests/verify_'+name+'.py'] for name in ['system_back','native_updates','recovery_updates','update_import_review']]
for command in commands:
    print('Verificando: '+' '.join(command),flush=True)
    subprocess.run(command,cwd=root,check=True)
print('Verificações concluídas. O APK assinado ainda precisa ser compilado no GitHub.')
