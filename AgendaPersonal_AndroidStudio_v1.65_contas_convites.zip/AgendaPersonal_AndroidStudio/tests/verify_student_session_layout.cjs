'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets'),uid='student_restore_test';
const server=http.createServer((req,res)=>{
 const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html',file=path.join(assets,name);
 if(!file.startsWith(assets+'/')||!fs.existsSync(file)){res.writeHead(404);return res.end()}
 let text=fs.readFileSync(file,'utf8');
 if(name==='index.html'){
  const anchor='sdk={...b,...c,auth:b.getAuth(app),db:c.getFirestore(app)};';assert.ok(text.includes(anchor));
  text=text.replace(anchor,anchor+'sdk.getDoc=window.__studentProfileDoc;sdk.onSnapshot=window.__studentSubscribe;');
 }
 res.setHeader('Content-Type','text/html;charset=utf-8');res.end(text);
});
async function seed(page){await page.evaluate(async uid=>{
 const app=APFirebaseLocal.app.getApps()[0],now=Math.floor(Date.now()/1000),enc=o=>btoa(JSON.stringify(o)).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
 const jwt=enc({alg:'HS256',typ:'JWT'})+'.'+enc({sub:uid,user_id:uid,iat:now,exp:now+3600,auth_time:now,email:'student@example.test',firebase:{sign_in_provider:'password',identities:{email:['student@example.test']}}})+'.test-signature';
 const value={uid,email:'student@example.test',emailVerified:true,isAnonymous:false,providerData:[{providerId:'password',uid:'student@example.test',email:'student@example.test'}],stsTokenManager:{refreshToken:'test-refresh',accessToken:jwt,expirationTime:Date.now()+3600000},createdAt:String(Date.now()-86400000),lastLoginAt:String(Date.now()),apiKey:app.options.apiKey,appName:'[DEFAULT]'};
 await new Promise((resolve,reject)=>{const q=indexedDB.open('firebaseLocalStorageDb',1);q.onupgradeneeded=()=>q.result.createObjectStore('firebaseLocalStorage',{keyPath:'fbase_key'});q.onerror=()=>reject(q.error);q.onsuccess=()=>{const db=q.result,tx=db.transaction('firebaseLocalStorage','readwrite');tx.objectStore('firebaseLocalStorage').put({fbase_key:'firebase:authUser:'+app.options.apiKey+':[DEFAULT]',value});tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>reject(tx.error)}});
 const student={id:'s',name:'Aluna teste',firebaseUid:uid,gender:'Feminino'},area=APStudentModel.makeArea({students:[student],workoutPlans:[{id:'p',studentId:'s',name:'Ficha',days:[{id:'d',name:'Treino A',exercises:[{id:'a',name:'Agachamento',sets:2,reps:'12',load:'20',rest:'60'},{id:'b',name:'Remada',sets:2,reps:'10',load:'15',rest:'60'}]}]}]},student);
 localStorage.setItem('agenda_student_area_v2_'+uid,JSON.stringify(area));localStorage.setItem('testRestoreStudent','true');
 },uid)}
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const ctx=await browser.newContext({viewport:{width:360,height:780}});await ctx.route('https://**',r=>r.abort());
  await ctx.route('https://identitytoolkit.googleapis.com/v1/accounts:lookup?**',r=>r.fulfill({contentType:'application/json',body:JSON.stringify({users:[{localId:uid,email:'student@example.test',emailVerified:true,createdAt:String(Date.now()-86400000),lastLoginAt:String(Date.now()),providerUserInfo:[{providerId:'password',email:'student@example.test',rawId:'student@example.test'}]}]})}));
  await ctx.addInitScript(()=>{
   window.__visibleEntry=[];window.__profileListeners=[];
   window.__studentProfileDoc=()=>new Promise(resolve=>{window.__waitingProfile=true;window.__releaseProfile=()=>resolve({exists:()=>true,data:()=>({perfil:'aluno',professorId:APStudentModel.TEACHER,ativo:true,nome:'Aluna teste',genero:'Feminino'})})});
   window.__studentSubscribe=(ref,options,next)=>{const fn=typeof options==='function'?options:next;window.__profileListeners.push(fn);return ()=>{}};
   document.addEventListener('DOMContentLoaded',()=>{
    if(localStorage.getItem('testRestoreStudent')!=='true')return;
    function inspect(){if(['landing','login'].includes(document.body.dataset.view)&&getComputedStyle(document.body).visibility!=='hidden'&&!document.documentElement.hasAttribute('data-ap-startup'))__visibleEntry.push(document.body.dataset.view);requestAnimationFrame(inspect)}requestAnimationFrame(inspect);
   });
  });
  const p=await ctx.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));const url='http://127.0.0.1:'+server.address().port+'/index.html';await p.goto(url,{waitUntil:'domcontentloaded'});await p.waitForFunction(()=>window.APFirebaseLocal&&!document.documentElement.hasAttribute('data-ap-startup'));
  await seed(p);await p.reload({waitUntil:'domcontentloaded'});await p.waitForFunction(()=>window.__waitingProfile===true);assert.equal(await p.evaluate(()=>document.documentElement.getAttribute('data-ap-startup')),'pending');assert.equal(await p.locator('#login').evaluate(n=>getComputedStyle(n).visibility),'hidden');await p.evaluate(()=>__releaseProfile());await p.waitForFunction(()=>document.body.dataset.view==='home'&&!document.documentElement.hasAttribute('data-ap-startup'));
  assert.deepEqual(await p.evaluate(()=>__visibleEntry),[],'no entry screen painted during account restoration');assert.ok(await p.locator('#studentHome').isVisible(),'home opens without a legacy customization completion flag');
  await p.evaluate(()=>{route('landing');route('login')});assert.equal(await p.evaluate(()=>document.body.dataset.view),'home','back cannot expose login while authenticated');
  await p.evaluate(()=>openExerciseHub('p~d'));const list=p.locator('#exListView');assert.ok(await list.locator('.flow-top-cta').isVisible());assert.equal(await list.locator('.flow-bottom-cta').count(),0);
  assert.ok(await list.evaluate(n=>!!(n.querySelector('.flow-top-cta').compareDocumentPosition(n.querySelector('.flow-exercises'))&Node.DOCUMENT_POSITION_FOLLOWING)));
  await p.screenshot({path:'/tmp/student-start-top.png'});await list.getByRole('button',{name:/Iniciar treino/}).click();await p.evaluate(()=>{exView='list';renderExerciseApp()});assert.equal(await list.locator('.flow-top-cta').count(),0);assert.ok(await list.getByRole('button',{name:'Finalizar treino',exact:true}).isDisabled());
  assert.ok(await list.evaluate(n=>!!(n.querySelector('.flow-exercises').compareDocumentPosition(n.querySelector('.flow-bottom-cta'))&Node.DOCUMENT_POSITION_FOLLOWING)));
  await p.evaluate(()=>{for(let i=0;i<2;i++)for(let s=0;s<2;s++)toggleExerciseSet(i,s);exView='list';renderExerciseApp()});assert.ok(await list.getByRole('button',{name:'Finalizar treino',exact:true}).isEnabled());await list.getByRole('button',{name:'Finalizar treino',exact:true}).scrollIntoViewIfNeeded();await p.screenshot({path:'/tmp/student-finish-bottom.png'});
  const record=await p.evaluate(()=>JSON.stringify(exStore()));await p.reload({waitUntil:'domcontentloaded'});await p.waitForFunction(()=>window.__waitingProfile===true);await p.evaluate(()=>__releaseProfile());await p.waitForFunction(()=>document.body.dataset.view==='home');assert.equal(await p.evaluate(()=>JSON.stringify(exStore())),record,'session retained across reopening');assert.deepEqual(await p.evaluate(()=>__visibleEntry),[]);
  await p.evaluate(()=>{localStorage.removeItem('testRestoreStudent');profileLogout()});await p.waitForFunction(()=>document.body.dataset.view==='landing'&&!document.documentElement.hasAttribute('data-ap-startup'));assert.equal(await p.evaluate(()=>__AP_STUDENT_CONTEXT),null);await p.reload({waitUntil:'domcontentloaded'});await p.waitForFunction(()=>!document.documentElement.hasAttribute('data-ap-startup'));assert.equal(await p.evaluate(()=>document.body.dataset.view),'landing','explicit logout persists');
  assert.deepEqual(errors,[]);await ctx.close();console.log('PASS: actual bundled Firebase restores a synthetic persisted student account; entry stays covered through delayed profile validation; direct home, protected back navigation, start above exercises, finish below, completion gate, saved execution, and explicit logout/reload. Firestore and auth endpoints simulated.');
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);server.close();process.exitCode=1});
