'use strict';
const assert=require('node:assert/strict'),{chromium}=require('playwright');
const {fixture,init,server}=require('./verify_bisets.cjs');
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const ctx=await browser.newContext({viewport:{width:360,height:780}});await init(ctx,fixture);
  await ctx.addInitScript(()=>{window.__pair=[];window.__watch={connection:{state:'checked',nodes:[],appNodes:[]},results:[]};Android.getWatchStatus=()=>JSON.stringify(__watch);Android.openWatchPairing=vendor=>__pair.push(vendor)});
  const p=await ctx.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await p.waitForFunction(()=>__ready);await p.evaluate(()=>showScreen('more'));
  const card=p.locator('#moreSmartwatch');assert.equal(await card.count(),1);await card.click();assert.equal(await p.locator('#apWatchSetup').count(),0,'first tap preserves More selection pattern');await card.click();assert.ok(await p.locator('#apWatchSetup').isVisible());
  const panel=p.locator('#apWatchSetup');assert.equal(await panel.evaluate(n=>n.scrollTop),0,'setup opens at the title');await p.screenshot({path:'/tmp/watch-setup-top.png'});assert.match(await panel.locator('[data-connection-status]').innerText(),/Nenhum relógio/);
  await panel.locator('[data-watch-pair]').click();assert.deepEqual(await p.evaluate(()=>__pair),['samsung']);assert.match(await panel.locator('[data-connection-status]').innerText(),/Nenhum relógio/,'launching setup never fakes a connection');
  await panel.locator('select').selectOption('google');await panel.locator('[data-watch-pair]').click();await panel.locator('select').selectOption('other');await panel.locator('[data-watch-pair]').click();assert.deepEqual(await p.evaluate(()=>__pair),['samsung','google','other']);
  await p.evaluate(()=>__watch.connection={state:'checked',nodes:[{id:'w',name:'Relógio teste'}]});await panel.locator('[data-watch-refresh]').click();assert.match(await panel.locator('[data-connection-status]').innerText(),/Conectado ao celular: Relógio teste/);assert.match(await panel.locator('[data-watch-app-status]').innerText(),/ainda não confirmado/);
  await p.evaluate(()=>__watch.connection.appNodes=['w']);await panel.locator('[data-watch-refresh]').click();assert.match(await panel.locator('[data-watch-app-status]').innerText(),/detectado no relógio/);
  await panel.screenshot({path:'/tmp/watch-setup-360.png'});
  await p.evaluate(()=>delete Android.openWatchPairing);await panel.locator('[data-watch-pair]').click();assert.match(await panel.locator('[data-watch-setup-help]').innerText(),/versão 1.151/);
  await p.evaluate(()=>delete __watch.connection);await panel.locator('[data-watch-refresh]').click();assert.match(await panel.locator('[data-connection-status]').innerText(),/Atualize o aplicativo/);
  await p.evaluate(()=>__watch.connection={state:'unavailable',nodes:[]});await panel.locator('[data-watch-refresh]').click();assert.match(await panel.locator('[data-connection-status]').innerText(),/indisponível/);
  for(const width of [280,360,640]){await p.setViewportSize({width,height:780});assert.ok(await panel.evaluate(n=>n.scrollWidth<=n.clientWidth+1),'panel fits '+width);}
  await panel.locator('[data-watch-close]').click();assert.equal(await panel.count(),0);await p.evaluate(()=>APWatchUI.setup('student'));await p.locator('[data-watch-results]').click();assert.equal(await p.locator('#apWatchSetup').count(),0);assert.match(await p.locator('.ap-watch-dialog').innerText(),/Nenhum treino recebido/);await p.evaluate(()=>APWatchUI.close());
  assert.deepEqual(errors,[]);await ctx.close();console.log('PASS: More watch icon/selection, vendor setup dispatch, no false pairing, connected versus installed app, old APK and unavailable service fallback, student role, dialog cleanup and 280/360/640 px. Native bridge simulated.');
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);server.close();process.exitCode=1});
