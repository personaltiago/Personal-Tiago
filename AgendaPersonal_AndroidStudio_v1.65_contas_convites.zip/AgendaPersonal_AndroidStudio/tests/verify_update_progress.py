"""Barra de progresso da importação (21/11/2026).

Parte A compila a classe REAL UpdateProgress com Android de mentira e confere a barra: leitura de 0 a 40% pelos bytes, etapas,
100% só em done(), erro ou cancelamento parado abaixo de 100% e "Ocultar" respeitado.
Parte B compila o UpdateManager REAL (com o registrador de verify_native_updates.py no lugar da barra) e confere onde ele chama a
barra: arquivo válido até a revisão, cancelar, arquivo inválido, conteúdo já instalado e instalação confirmada até pageReady.
Não é teste em aparelho nem APK assinado.
"""
from pathlib import Path
import runpy
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
PACKAGE = 'com/tiagolima/agendapersonal/'

UI_STUBS = {
    'android/content/DialogInterface.java': '''package android.content;public interface DialogInterface{void dismiss();interface OnClickListener{void onClick(DialogInterface d,int which);}interface OnDismissListener{void onDismiss(DialogInterface d);}interface OnCancelListener{void onCancel(DialogInterface d);}}''',
    'android/app/AlertDialog.java': '''package android.app;import android.content.DialogInterface;
public class AlertDialog implements DialogInterface{public static final int BUTTON_NEGATIVE=-2;public android.widget.Button hide=new android.widget.Button();public android.widget.Button getButton(int w){return showing?hide:null;}public String title;public Object view;public boolean showing;public int shows;public String negative;public DialogInterface.OnClickListener negativeListener;public DialogInterface.OnDismissListener onDismiss;public DialogInterface.OnCancelListener onCancel;
public void setTitle(CharSequence t){title=String.valueOf(t);}public void show(){showing=true;shows++;}public boolean isShowing(){return showing;}public void dismiss(){if(showing){showing=false;if(onDismiss!=null)onDismiss.onDismiss(this);}}
public void setOnDismissListener(DialogInterface.OnDismissListener l){onDismiss=l;}public void setOnCancelListener(DialogInterface.OnCancelListener l){onCancel=l;}
public android.view.Window getWindow(){return new android.view.Window();}
public void tapNegative(){if(negativeListener!=null)negativeListener.onClick(this,-2);dismiss();}
public static class Builder{private final AlertDialog d=new AlertDialog();public Builder(android.content.Context c,int s){}public Builder setTitle(CharSequence t){d.title=String.valueOf(t);return this;}public Builder setView(Object v){d.view=v;return this;}public Builder setCancelable(boolean b){return this;}
public Builder setNegativeButton(CharSequence s,DialogInterface.OnClickListener l){d.negative=String.valueOf(s);d.negativeListener=l;return this;}public AlertDialog create(){return d;}}}''',
    'android/view/Window.java': '''package android.view;public class Window{public View getDecorView(){return new View();}}''',
    'android/view/View.java': '''package android.view;public class View{public static java.util.List<Runnable> delayed=new java.util.ArrayList<>();public boolean postDelayed(Runnable r,long ms){delayed.add(r);return true;}public void setPadding(int a,int b,int c,int d){}public void setMinimumHeight(int h){}public void setAlpha(float a){}}''',
    'android/view/Gravity.java': '''package android.view;public class Gravity{public static final int START=1,END=2,CENTER_VERTICAL=3;}''',
    'android/graphics/Typeface.java': '''package android.graphics;public class Typeface{public static final Typeface DEFAULT_BOLD=new Typeface();}''',
    'android/graphics/drawable/Drawable.java': '''package android.graphics.drawable;public class Drawable{}''',
    'android/graphics/drawable/GradientDrawable.java': '''package android.graphics.drawable;public class GradientDrawable extends Drawable{public int color;public void setCornerRadius(float r){}public void setColor(int c){color=c;}}''',
    'android/graphics/drawable/ClipDrawable.java': '''package android.graphics.drawable;public class ClipDrawable extends Drawable{public static final int HORIZONTAL=1;public ClipDrawable(Drawable d,int g,int o){}}''',
    'android/graphics/drawable/LayerDrawable.java': '''package android.graphics.drawable;public class LayerDrawable extends Drawable{public LayerDrawable(Drawable[] l){}public void setId(int i,int id){}}''',
    'android/content/Context.java': '''package android.content;public class Context{}''',
    'android/content/ContentResolver.java': '''package android.content;public class ContentResolver{public android.database.Cursor query(android.net.Uri u,String[] p,String s,String[] a,String o){return new android.database.Cursor(android.net.Uri.size);}}''',
    'android/content/res/ColorStateList.java': '''package android.content.res;public class ColorStateList{public final int color;private ColorStateList(int c){color=c;}public static ColorStateList valueOf(int c){return new ColorStateList(c);}}''',
    'android/content/res/Resources.java': '''package android.content.res;public class Resources{public android.util.DisplayMetrics getDisplayMetrics(){return new android.util.DisplayMetrics();}}''',
    'android/util/DisplayMetrics.java': '''package android.util;public class DisplayMetrics{public float density=2f;}''',
    'android/util/TypedValue.java': '''package android.util;public class TypedValue{public static final int COMPLEX_UNIT_SP=2;}''',
    'android/database/Cursor.java': '''package android.database;public class Cursor implements AutoCloseable{private final long size;public Cursor(long s){size=s;}public boolean moveToFirst(){return true;}public boolean isNull(int i){return size<0;}public long getLong(int i){return size;}public void close(){}}''',
    'android/net/Uri.java': '''package android.net;public class Uri{public static long size=-1;}''',
    'android/os/SystemClock.java': '''package android.os;public class SystemClock{public static long now;public static long uptimeMillis(){return now;}}''',
    'android/provider/OpenableColumns.java': '''package android.provider;public class OpenableColumns{public static final String SIZE="_size";}''',
    'android/R.java': '''package android;public class R{public static class attr{public static final int progressBarStyleHorizontal=1;}public static class style{public static final int Theme_Material_Dialog_Alert=1;}public static class id{public static final int background=1,progress=2;}}''',
    'android/widget/TextView.java': '''package android.widget;public class TextView extends android.view.View{public String text="";public int color;public TextView(android.content.Context c){}public void setText(CharSequence s){text=String.valueOf(s);}public void setTextSize(int u,float s){}public void setTypeface(android.graphics.Typeface t){}public void setTextColor(int c){color=c;}public void setGravity(int g){}}''',
    'android/widget/Button.java': '''package android.widget;public class Button extends android.view.View{public int color;public String text="";public void setTextColor(int c){color=c;}public void setText(CharSequence t){text=String.valueOf(t);}}''',
    'android/widget/ProgressBar.java': '''package android.widget;public class ProgressBar extends android.view.View{public int progress,max;public boolean indeterminate;public int tint;public ProgressBar(android.content.Context c,Object a,int s){}public void setMax(int m){max=m;}public void setProgress(int p){progress=p;}public void setIndeterminate(boolean b){indeterminate=b;}
public void setProgressDrawable(android.graphics.drawable.Drawable d){}public void setIndeterminateTintList(android.content.res.ColorStateList c){}}''',
    'android/widget/LinearLayout.java': '''package android.widget;public class LinearLayout extends android.view.View{public static final int VERTICAL=1;public final java.util.List<Object> children=new java.util.ArrayList<>();public LinearLayout(android.content.Context c){}public void setOrientation(int o){}public void setGravity(int g){}public void addView(Object v){children.add(v);}public void addView(Object v,Object p){children.add(v);}
public static final int HORIZONTAL=0;public static class LayoutParams{public static final int MATCH_PARENT=-1,WRAP_CONTENT=-2;public LayoutParams(int w,int h){}public LayoutParams(int w,int h,float g){}public void setMargins(int a,int b,int c,int d){}}}''',
    PACKAGE + 'MainActivity.java': '''package com.tiagolima.agendapersonal;public class MainActivity extends android.content.Context{public boolean finishing;public void runOnUiThread(Runnable r){r.run();}public boolean isFinishing(){return finishing;}public android.content.res.Resources getResources(){return new android.content.res.Resources();}public android.content.ContentResolver getContentResolver(){return new android.content.ContentResolver();}}''',
}

UI_HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.AlertDialog;import android.widget.*;import java.lang.reflect.Field;
public final class ProgressUiHarness{
static int checks;static void check(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m);}
static Object get(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
static AlertDialog dialog(UpdateProgress p)throws Exception{return(AlertDialog)get(p,"dialog");}
static ProgressBar bar(UpdateProgress p)throws Exception{return(ProgressBar)get(p,"bar");}
static int fill(UpdateProgress p)throws Exception{return((android.graphics.drawable.GradientDrawable)get(p,"fill")).color;}
static String t(UpdateProgress p,String n)throws Exception{return((TextView)get(p,n)).text;}
static String name(UpdateProgress p)throws Exception{return t(p,"nameView");}static String pct(UpdateProgress p)throws Exception{return t(p,"percentView");}
static String size(UpdateProgress p)throws Exception{return t(p,"sizeView");}static String detail(UpdateProgress p)throws Exception{return t(p,"detailView");}
public static void main(String[] a)throws Exception{
 MainActivity act=new MainActivity();UpdateProgress p=new UpdateProgress(act);
 android.net.Uri.size=12_000_000;check(p.sizeOf(new android.net.Uri())==12_000_000,"Tamanho do arquivo não lido");
 android.net.Uri.size=-1;check(p.sizeOf(new android.net.Uri())==-1,"Sem tamanho devia dar -1");
 // 1. leitura com tamanho: 0..40%, nunca passa de 40 na leitura; verde; estimativa de tempo depois de 1 s
 p.start();check(dialog(p).isShowing()&&bar(p).indeterminate&&name(p).equals("Lendo o arquivo")&&pct(p).equals("—")&&size(p).equals("Etapa 1 de 4"),"Início: "+name(p)+" / "+pct(p)+" / "+size(p));
 long total=12_000_000;int last=-1;boolean eta=false;for(long r=0;r<=total;r+=1_000_000){android.os.SystemClock.now+=300;p.reading(r,total);int v=bar(p).progress;check(!bar(p).indeterminate&&v>=last&&v<=40&&pct(p).equals(v+"%"),"Leitura fora de 0..40 ou voltando: "+v);last=v;if(detail(p).startsWith("Estimativa: cerca de "))eta=true;}
 check(eta,"A estimativa de tempo restante não apareceu na leitura");
 check(dialog(p).hide.text.equals("Ocultar"),"Durante a importação o botão devia ser Ocultar: "+dialog(p).hide.text);
 // 1.209: textos com cor explícita e clara (no 1.208 herdavam a cor escura do tema e sumiam no fundo cinza)
 check(((TextView)get(p,"nameView")).color==UpdateProgress.TEXT&&((TextView)get(p,"sizeView")).color==UpdateProgress.TEXT_SOFT&&((TextView)get(p,"detailView")).color==UpdateProgress.TEXT_MUTED,"Textos sem a cor clara explícita");
 check(last==40&&size(p).equals("11,4 de 11,4 MB")&&fill(p)==UpdateProgress.GREEN&&pct(p).equals("40%")&&((TextView)get(p,"percentView")).color==UpdateProgress.TEXT_GREEN&&dialog(p).hide.color==UpdateProgress.TEXT_GREEN,"Fim da leitura não mostrou 40% e os MB: "+pct(p)+" / "+size(p));
 // limite de atualizações por segundo
 String before=size(p);p.reading(1,total);check(size(p).equals(before),"Leitura atualizou antes de 100 ms");
 // leitura sem tamanho: indeterminada, sem porcentagem inventada
 UpdateProgress q=new UpdateProgress(act);q.start();android.os.SystemClock.now+=150;q.reading(3_000_000,-1);check(bar(q).indeterminate&&pct(q).equals("—")&&size(q).equals("2,9 MB lidos"),"Sem tamanho devia ficar indeterminada: "+pct(q)+" / "+size(q));q.close();
 // 2. etapas, revisão e instalação
 p.step(48,"Etapa 2 de 4 · Conferindo a assinatura","x");check(bar(p).progress==48&&pct(p).equals("48%")&&name(p).equals("Conferindo a assinatura")&&size(p).equals("Etapa 2 de 4")&&detail(p).equals("x"),"Etapa 48% não aplicada");
 p.waitReview();check(dialog(p)==null,"A barra devia sair da frente da revisão");
 p.step(70,"Etapa 3 de 4 · Copiando os dados","y");check(dialog(p).isShowing()&&bar(p).progress==70,"A barra não voltou depois da confirmação");
 p.step(90,"Etapa 3 de 4 · Abrindo a nova versão","z");check(bar(p).progress==90&&pct(p).equals("90%"),"90% errado");
 p.done("Atualização aplicada. Seus dados foram mantidos.");
 check(dialog(p).hide.text.equals("Fechar")&&bar(p).progress==100&&pct(p).equals("100%")&&name(p).equals("Concluído")&&dialog(p).title.equals("Atualização concluída")&&fill(p)==UpdateProgress.GREEN,"Concluído não mostrou 100%");
 p.fail("tarde demais");check(bar(p).progress==100&&dialog(p).title.equals("Atualização concluída"),"Erro depois de concluído mudou o resultado");
 check(!android.view.View.delayed.isEmpty(),"Concluído devia fechar sozinho depois");android.view.View.delayed.get(android.view.View.delayed.size()-1).run();check(dialog(p)==null,"A janela concluída não fechou");
 // 3. erro no meio: para onde estava, vermelho, nunca 100%
 UpdateProgress e=new UpdateProgress(act);e.start();android.os.SystemClock.now+=150;e.reading(3_000_000,12_000_000);e.step(48,"Etapa 2 de 4 · Conferindo a assinatura","x");
 e.fail("A assinatura não confere.");check(bar(e).progress==48&&fill(e)==UpdateProgress.ERROR&&pct(e).equals("48%")&&((TextView)get(e,"percentView")).color==UpdateProgress.ERROR&&dialog(e).title.equals("Nada foi instalado")&&name(e).equals("Parou em: Conferindo a assinatura")&&detail(e).equals("A assinatura não confere.")&&size(e).equals("Etapa 2 de 4")&&dialog(e).hide.text.equals("Fechar"),"Erro não parou em 48% em vermelho: "+name(e));
 e.done("não pode");check(bar(e).progress==48&&dialog(e).title.equals("Nada foi instalado"),"Concluído depois do erro virou 100%");
 // erro depois de 90% (a nova versão não abriu): 90, não 100
 UpdateProgress r=new UpdateProgress(act);r.step(90,"Etapa 3 de 4 · Abrindo a nova versão","z");r.fail("A nova versão não abriu corretamente. A versão anterior foi recuperada.");check(bar(r).progress==90&&dialog(r).title.equals("Nada foi instalado")&&fill(r)==UpdateProgress.ERROR,"Erro em 90% errado");
 // cancelamento na revisão: para em 60
 UpdateProgress c=new UpdateProgress(act);c.start();c.step(55,"Etapa 2 de 4 · Montando","x");c.waitReview();c.fail("Nenhuma atualização foi instalada.");check(bar(c).progress==60&&name(c).equals("Parou em: Aguardando sua confirmação")&&dialog(c).isShowing(),"Cancelar na revisão devia parar em 60%: "+name(c));
 // 4. Ocultar: fecha só a janela; etapas seguintes não reabrem; resultado final reabre
 UpdateProgress h=new UpdateProgress(act);h.start();dialog(h).tapNegative();check(dialog(h)==null,"Ocultar não fechou");
 h.step(70,"Etapa 3 de 4 · Copiando os dados","y");check(!dialog(h).isShowing(),"Etapa reabriu depois de Ocultar");
 h.done("Atualização aplicada.");check(dialog(h).isShowing()&&bar(h).progress==100,"O resultado final devia aparecer mesmo depois de Ocultar");
 // 5. sem início, erro não abre janela à toa
 UpdateProgress n=new UpdateProgress(act);n.fail("x");n.done("y");check(get(n,"dialog")==null,"Janela aberta sem importação");
 System.out.println("PASS UpdateProgress real: "+checks+" verificações (leitura 0-40% com MB e estimativa, etapas, 100% só concluído, erro parado em vermelho, Ocultar).");
}}
'''


FLOW_HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.AlertDialog;import android.net.Uri;import android.webkit.WebView;import java.nio.file.*;import java.lang.reflect.*;import java.util.*;import org.json.JSONObject;
public final class ProgressFlowHarness{
static final String TEACHER="R2EmnDVcvMWt7TjPxOP6DjW1VOn1";static int checks;
static void check(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m+"\nEventos: "+UpdateProgress.events);}
static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
static JSONObject release(int seq,String version,String marker)throws Exception{String html="<!doctype html><html><head></head><body>"+marker+" agendaPersonalTL_v1 syncNativeAlarms<script data-agenda-ready></script></body></html>";
 return new JSONObject().put("format",1).put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4).put("version",version).put("sequence",seq).put("notes","Teste da barra.")
  .put("files",new JSONObject().put("index.html",html).put("professor.html",html).put("avaliacoes.html",html).put("cadastro.html",html.replace(" data-agenda-ready","")));}
static void waitFor(UpdateManager m,boolean review)throws Exception{long until=System.currentTimeMillis()+8000;while(System.currentTimeMillis()<until){AlertDialog d=(AlertDialog)field(m,"reviewDialog");if(review&&d!=null&&d.isShowing()&&d.getButton(AlertDialog.BUTTON_POSITIVE).listener!=null)return;if(!review&&!Boolean.TRUE.equals(field(m,"busy")))return;Thread.sleep(5);}throw new AssertionError("Tempo esgotado: "+UpdateProgress.events);}
static void click(AlertDialog d,int which){android.widget.Button b=d.getButton(which);if(b.listener!=null)b.listener.click(b);}
static List<String> take(){synchronized(UpdateProgress.events){List<String> c=new ArrayList<>(UpdateProgress.events);UpdateProgress.events.clear();return c;}}
static boolean has(List<String> e,String prefix){return e.stream().anyMatch(x->x.startsWith(prefix));}
static void noHundredUnlessDone(List<String> e,String when){for(String x:e)if(x.contains(":100")&&!x.startsWith("done:100"))throw new AssertionError(when+": 100% fora do concluído: "+e);checks++;}
public static void main(String[] a)throws Exception{
 Path project=Path.of(a[0]),folder=Files.createTempDirectory("agenda-progress-"),file=folder.resolve("selected.json");
 int base=UpdateManager.BASE_SEQUENCE;JSONObject installed=release(base+1,"1.12.181","installed");Files.createDirectories(folder.resolve("updates"));Files.writeString(folder.resolve("updates/active.json"),installed.toString());
 MainActivity activity=new MainActivity(folder.toFile(),project.resolve("app/src/main/assets"));WebView view=new WebView();UpdateManager m=new UpdateManager(activity,view);view.reader=m::localResponse;
 try{
  m.setUpdateAccount(TEACHER);m.openPage(Uri.parse(LocalPages.HOME));view.awaitLoads(1);view.ready=true;m.pageReady();Thread.sleep(50);take();
  // 1. arquivo válido até a revisão, depois cancelar
  UpdateProgress.size=-1;Files.writeString(file,release(base+2,"1.12.182","candidate").toString());m.importUri(Uri.parse(file.toUri().toString()));waitFor(m,true);
  List<String> e=take();
  check(e.get(0).equals("start")&&has(e,"read:")&&has(e,"step:42:")&&has(e,"step:48:Etapa 2 de 4 · Conferindo a assinatura")&&has(e,"step:55:")&&e.get(e.size()-1).equals("review:60"),"Etapas até a revisão: "+e);
  check(e.indexOf("review:60")>e.indexOf(e.stream().filter(x->x.startsWith("step:55")).findFirst().get()),"Revisão antes de montar");
  noHundredUnlessDone(e,"Até a revisão");
  click((AlertDialog)field(m,"reviewDialog"),AlertDialog.BUTTON_NEGATIVE);waitFor(m,false);e=take();
  check(e.size()==1&&e.get(0).startsWith("fail:60:"),"Cancelar na revisão devia parar em 60%: "+e);
  // 2. arquivo inválido: para na leitura, nunca 100
  Files.writeString(file,"não é json");m.importUri(Uri.parse(file.toUri().toString()));waitFor(m,false);e=take();
  check(e.get(0).equals("start")&&e.get(e.size()-1).startsWith("fail:")&&!has(e,"review")&&!has(e,"done"),"Arquivo inválido: "+e);noHundredUnlessDone(e,"Arquivo inválido");
  int stoppedAt=Integer.parseInt(e.get(e.size()-1).split(":")[1]);check(stoppedAt<=42,"Arquivo inválido parou longe demais: "+stoppedAt);
  // 3. instalação confirmada: 70, 80, 90 e só depois do pageReady 100
  Files.writeString(file,release(base+2,"1.12.182","candidate").toString());m.importUri(Uri.parse(file.toUri().toString()));waitFor(m,true);take();
  int loads=view.loads;click((AlertDialog)field(m,"reviewDialog"),AlertDialog.BUTTON_POSITIVE);view.awaitLoads(loads+1);Thread.sleep(50);e=take();
  check(has(e,"step:70:Etapa 3 de 4 · Copiando os dados")&&has(e,"step:80:")&&has(e,"step:90:Etapa 3 de 4 · Abrindo a nova versão")&&!has(e,"done")&&!has(e,"fail"),"Instalação antes de abrir: "+e);
  check(e.indexOf(e.stream().filter(x->x.startsWith("step:70")).findFirst().get())<e.indexOf(e.stream().filter(x->x.startsWith("step:90")).findFirst().get()),"Ordem 70 → 90");
  m.pageReady();waitFor(m,false);Thread.sleep(50);e=take();
  check(e.size()==1&&e.get(0).equals("done:100:Atualização aplicada. Seus dados foram mantidos."),"100% devia vir só do pageReady: "+e);
  // 4. o mesmo conteúdo de novo: o app não oferece (já instalado) e a barra termina em erro, não em 100
  m.importUri(Uri.parse(file.toUri().toString()));waitFor(m,false);e=take();
  check(e.get(0).equals("start")&&e.get(e.size()-1).startsWith("fail:")&&!has(e,"done"),"Conteúdo já instalado: "+e);noHundredUnlessDone(e,"Já instalado");
 }finally{m.destroy();}
 check(take().contains("close"),"destroy() devia fechar a barra");
 System.out.println("PASS UpdateManager com a barra: "+checks+" verificações (revisão, cancelar, inválido, instalação até pageReady, já instalado).");
}}
'''


def compile_and_run(stubs, extra_sources, main, work, java, compiler, args):
    sources = list(extra_sources)
    for name, text in stubs.items():
        target = work / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding='utf-8')
        sources.append(str(target))
    subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + sources, check=True)
    subprocess.run([java, '-cp', str(work / 'classes'), 'com.tiagolima.agendapersonal.' + main] + args, check=True)


def main():
    java = shutil.which('java')
    assert java, 'Java 17 é necessário.'
    compiler = [shutil.which('javac')] if shutil.which('javac') else [java, 'com.sun.tools.javac.Main']
    src = PROJECT / 'app/src/main/java' / PACKAGE
    with tempfile.TemporaryDirectory(prefix='agenda-progress-ui-') as temp:
        stubs = dict(UI_STUBS)
        stubs[PACKAGE + 'ProgressUiHarness.java'] = UI_HARNESS
        compile_and_run(stubs, [str(src / 'UpdateProgress.java')], 'ProgressUiHarness', Path(temp), java, compiler, [])
    with tempfile.TemporaryDirectory(prefix='agenda-progress-flow-') as temp:
        stubs = dict(runpy.run_path(str(PROJECT / 'tests/verify_native_updates.py'))['STUBS'])
        stubs.pop(PACKAGE + 'NativeUpdateHarness.java')
        stubs[PACKAGE + 'ProgressFlowHarness.java'] = FLOW_HARNESS
        names = ('UpdateManager.java', 'UpdateAreaPatch.java', 'UpdateArchive.java', 'AndroidInstaller.java', 'UpdateStorage.java', 'UpdateExport.java',
                 'UpdateDownloads.java', 'LocalPages.java', 'UpdateManifest.java', 'UpdatePackageSignature.java', 'NativeLaunch.java', 'UpdateIdentity.java')
        compile_and_run(stubs, [str(src / n) for n in names], 'ProgressFlowHarness', Path(temp), java, compiler, [str(PROJECT)])


if __name__ == '__main__':
    main()
