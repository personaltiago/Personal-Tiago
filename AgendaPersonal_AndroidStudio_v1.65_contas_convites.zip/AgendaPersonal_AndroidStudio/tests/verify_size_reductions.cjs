// Reduções de peso sem mudança de funcionamento: fontes do PDF de evolução (subconjunto conferido contra o próprio
// arquivo TTF embutido), e foto padrão do professor.
const fs=require('fs'),path=require('path'),assert=require('assert');
const rel=JSON.parse(fs.readFileSync(path.join(__dirname,'..','web','native-release.agenda.json'),'utf8'));
const p=rel.files['professor.html'],a=rel.files['avaliacoes.html'];let checks=0;const ok=(c,m)=>{checks++;assert(c,m)};
// ---------- fontes ----------
const i=p.indexOf('const WORKOUT_REPORT_FONTS='),j=p.indexOf('\n',i);ok(i>0&&j>i,'fontes presentes');
const fonts=JSON.parse(p.slice(i+'const WORKOUT_REPORT_FONTS='.length,j).replace(/;$/,''));
function sfnt(buf){const n=buf.readUInt16BE(4),t={};for(let k=0;k<n;k++){const o=12+16*k;t[buf.toString('latin1',o,o+4)]={off:buf.readUInt32BE(o+8),len:buf.readUInt32BE(o+12)}}return t}
function cmapLookup(buf,t){const base=t.cmap.off,n=buf.readUInt16BE(base+2);let best=null;
  for(let k=0;k<n;k++){const pid=buf.readUInt16BE(base+4+8*k),eid=buf.readUInt16BE(base+6+8*k),off=base+buf.readUInt32BE(base+8+8*k),fmt=buf.readUInt16BE(off);
    if(fmt===12&&((pid===3&&eid===10)||pid===0))best={fmt,off};else if(fmt===4&&!best&&((pid===3&&eid===1)||pid===0))best={fmt,off}}
  assert(best,'tabela cmap não reconhecida');
  if(best.fmt===12){const groups=buf.readUInt32BE(best.off+12);return cp=>{for(let g=0;g<groups;g++){const o=best.off+16+12*g,s=buf.readUInt32BE(o),e=buf.readUInt32BE(o+4);if(cp>=s&&cp<=e)return buf.readUInt32BE(o+8)+cp-s}return 0}}
  const o=best.off,seg=buf.readUInt16BE(o+6)/2,endO=o+14,startO=endO+2*seg+2,deltaO=startO+2*seg,rangeO=deltaO+2*seg;
  return cp=>{if(cp>0xffff)return 0;for(let s=0;s<seg;s++){const end=buf.readUInt16BE(endO+2*s);if(cp<=end){const start=buf.readUInt16BE(startO+2*s);if(cp<start)return 0;const ro=buf.readUInt16BE(rangeO+2*s),delta=buf.readInt16BE(deltaO+2*s);if(!ro)return (cp+delta)&0xffff;const g=buf.readUInt16BE(rangeO+2*s+ro+2*(cp-start));return g?(g+delta)&0xffff:0}}return 0}}
// as larguras originais foram arredondadas com "metade para o par" (regra do gerador); mantém a mesma regra
const half=x=>{const f=Math.floor(x),d=x-f;return d>.5?f+1:d<.5?f:(f%2?f+1:f)};
const MUST='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .,;:!?()[]{}/\\+-=%*"\'@#&_áàâãäéèêëíìîïóòôõöúùûüçñÁÀÂÃÉÊÍÓÔÕÚÇ°ºª²³½¼¾×÷±µ·–—‘’“”•…€←↑→↓≤≥≠≈∞√✓✔✗★☆♥■□●○▶▲▼⚠αβγπΩЖя';
for(const [weight,data] of Object.entries(fonts)){
  const buf=Buffer.from(data.base64,'base64'),t=sfnt(buf);
  ok(buf.readUInt32BE(0)===0x00010000,'TrueType válido ('+weight+')');
  for(const need of ['cmap','glyf','loca','hmtx','hhea','head','maxp','name'])ok(t[need],'tabela '+need+' presente ('+weight+')');
  const glyphs=buf.readUInt16BE(t.maxp.off+4),upm=buf.readUInt16BE(t.head.off+18),nh=buf.readUInt16BE(t.hhea.off+34);
  ok(data.widths.length===glyphs,'uma largura por glifo ('+weight+'): '+data.widths.length+' x '+glyphs);
  const adv=g=>buf.readUInt16BE(t.hmtx.off+4*Math.min(g,nh-1)),look=cmapLookup(buf,t);
  const cps=Object.keys(data.cmap).map(Number);ok(cps.length>=3500,'conjunto amplo de símbolos ('+weight+'): '+cps.length);
  for(const cp of cps){const gid=data.cmap[cp];if(!(gid>0&&gid<glyphs))assert.fail('glifo fora da fonte: U+'+cp.toString(16));
    if(look(cp)!==gid)assert.fail('cmap do app diverge da fonte em U+'+cp.toString(16)+' ('+weight+')');
    if(half(adv(gid)*1000/upm)!==data.widths[gid])assert.fail('largura diverge da fonte em U+'+cp.toString(16)+' ('+weight+')')}
  checks+=3;
  for(const ch of MUST)ok(data.cmap[ch.codePointAt(0)]!==undefined,'símbolo obrigatório ausente ('+weight+'): '+ch);
  for(const ch of 'אبܐ')ok(data.cmap[ch.codePointAt(0)]===undefined,'escrita da direita para a esquerda não deveria estar na fonte: '+ch);
  ok(buf.length<450000,'fonte reduzida ('+weight+'): '+buf.length);
  ok(buf.toString('latin1',t.name.off,t.name.off+t.name.len).replace(/\0/g,'').includes('DejaVu'),'tabela de nomes/licença preservada ('+weight+')');
}
ok(p.includes("if(glyph===undefined)throw new Error('Um símbolo do texto não pode ser exibido no PDF: '"),'aviso de símbolo não aceito continua no gerador');
// ---------- imagens ----------
function uriAfter(html,marker){const k=html.indexOf(marker);assert(k>=0,'marcador ausente: '+marker);const s=html.indexOf('data:image/',k),e=html.indexOf(')',s);return html.slice(s,e).replace(/['"]$/,'')}
function jpegSize(b){let o=2;while(o<b.length){if(b[o]!==0xff)return null;const m=b[o+1],len=b.readUInt16BE(o+2);if(m>=0xc0&&m<=0xcf&&m!==0xc4&&m!==0xc8&&m!==0xcc)return [b.readUInt16BE(o+7),b.readUInt16BE(o+5)];o+=2+len}return null}
// Mascotes/logotipo da Avaliação ficam na imagem original (sem redução), a pedido.
const orig={'.report-logo,.tl-mark{':[1229,1536],'.hero-figure.male{background-image:url(':[1024,1536],'.hero-figure.female{background-image:url(':[1024,1536]};
function pngSize(b){return b.readUInt32BE(0)===0x89504e47?[b.readUInt32BE(16),b.readUInt32BE(20)]:null}
for(const [m,dim] of Object.entries(orig)){const u=uriAfter(a,m),b=Buffer.from(u.split(',')[1],'base64'),sz=pngSize(b)||jpegSize(b);ok(sz&&sz[0]===dim[0]&&sz[1]===dim[1],'imagem original mantida em '+m+': '+sz)}
ok(a.includes(".report-logo,.tl-mark{display:block;flex:none;width:46px;height:46px")&&a.includes("center 39%/154% no-repeat"),'enquadramento do logotipo inalterado');
ok(a.includes("for (const selector of ['.report-logo', '.hero-figure.male', '.hero-figure.female'])"),'exportação do relatório continua levando logotipo e figuras');
// Foto do professor: não existe foto de exemplo; sem foto enviada aparecem as iniciais do nome.
ok(!p.includes('trainer-reference-photo')&&!p.includes('879.412%'),'foto de exemplo do professor removida');
ok(p.includes('<span id="headerTrainerPhoto" class="trainer-photo trainer-photo-empty"></span>')&&p.includes('<span id="trainerPhotoPreview" class="trainer-photo trainer-photo-empty"></span>'),'círculos começam vazios');
ok(p.includes("photo.classList.toggle('trainer-photo-empty',!profile.photoDataUrl)")&&p.includes('${hesc(studentInitials(profile.name))}</span>'),'topo mostra as iniciais sem foto');
ok(p.includes("photo.classList.toggle('trainer-photo-empty',!trainerPhotoDraft)"),'prévia mostra as iniciais sem foto');
ok(p.includes('onclick="resetTrainerPhoto()">Remover foto</button>')&&!p.includes('>Usar foto do painel</button>'),'botão passa a ser Remover foto');
ok(!fs.existsSync(path.join(__dirname,'..','app','src','main','assets','icon.png')),'ícone antigo sem uso removido');
for(const page of Object.values(rel.files))ok(!page.includes('icon.png'),'nenhuma tela pede icon.png');
console.log('PASS Reduções de peso: '+checks+' verificações (fontes conferidas contra o TTF embutido; sem aparelho físico).');
