'use strict';
const assert=require('node:assert/strict'),{chromium}=require('playwright');
const {fixture,init,server}=require('./verify_bisets.cjs');
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const data=structuredClone(fixture);data.students=[{id:'c',name:'Carla',studentType:'presencial'},{id:'b',name:'Bruna',studentType:'presencial'},{id:'a',name:'Ana',studentType:'presencial'},{id:'x',name:'Online',studentType:'online'},{id:'z',name:'Arquivada',studentType:'presencial',archived:true}];
  const lesson=(id,studentId,time,extra={})=>({id,studentId,time,date:'2026-10-21',repeat:'none',duration:60,type:'Presencial',...extra});
  data.lessons=[lesson('lc','c','09:00'),lesson('la','a','11:00',{repeat:'weekly',repeatDays:[3]}),lesson('lb','b','12:00'),lesson('lx','x','11:00'),lesson('lz','z','11:00')];data.occurrenceStatus={};
  const ctx=await browser.newContext({viewport:{width:360,height:800},timezoneId:'America/Cuiaba'});await init(ctx,data);
  const p=await ctx.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.clock.install({time:new Date('2026-10-21T10:59:59-04:00')});
  await p.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await p.waitForFunction(()=>__ready);await p.evaluate(()=>showScreen('students-presencial'));
  const order=()=>p.locator('#studentList > .student').evaluateAll(rows=>rows.map(r=>r.dataset.studentId));
  const current=()=>p.locator('#studentList > .ap-lesson-current').evaluateAll(rows=>rows.map(r=>r.dataset.studentId));
  const before=await p.evaluate(()=>JSON.stringify(state));
  assert.deepEqual(await order(),['a','b','c']);assert.deepEqual(await current(),[]);
  await p.clock.fastForward(1000);assert.deepEqual(await current(),['a']);assert.match(await p.locator('#studentList .student').first().innerText(),/Horário da aula agora · 11:00–12:00/);
  await p.locator('#studentList .student[data-student-id="a"]').screenshot({path:'/tmp/student-lesson-priority-360.png'});
  await p.locator('#studentList .student').first().locator('.workout-shortcut').click();assert.equal(await p.evaluate(()=>workoutStudentId),'a','first card opens the correct student workout');await p.evaluate(()=>closeDialog('workoutStudentDialog'));
  await p.evaluate(()=>window.__priorityFirst=document.querySelector('#studentList .student'));await p.clock.fastForward(1000);assert.ok(await p.evaluate(()=>__priorityFirst===document.querySelector('#studentList .student')),'timer preserves existing nodes');
  await p.clock.fastForward(3599000);assert.deepEqual(await order(),['b','c','a']);assert.deepEqual(await current(),['b'],'12:00 switches without reopening');
  assert.equal(await p.evaluate(()=>JSON.stringify(state)),before,'sorting never changes stored student/lesson data');
  await p.locator('#studentSearch').fill('Ana');await p.evaluate(()=>renderStudents());assert.deepEqual(await order(),['a']);await p.locator('#studentSearch').fill('');await p.evaluate(()=>renderStudents());assert.deepEqual(await order(),['b','c','a']);
  await p.evaluate(()=>{state.occurrenceStatus[occurrenceKey('lb','2026-10-21')]='realizada';renderStudents()});assert.deepEqual(await current(),[]);assert.deepEqual(await order(),['c','b','a']);
  await p.clock.setSystemTime(new Date('2026-10-28T11:10:00-04:00'));await p.evaluate(()=>renderStudents());assert.deepEqual(await current(),['a'],'weekly occurrence on next Wednesday');
  await p.evaluate(()=>{state.occurrenceStatus[occurrenceKey('la','2026-10-28')]='cancelada';renderStudents()});assert.deepEqual(await current(),[],'cancelled weekly occurrence excluded');
  await p.evaluate(()=>{state.lessons.push({id:'overnight',studentId:'c',date:'2026-10-28',repeat:'none',time:'23:45',duration:60,type:'Presencial'});});await p.clock.setSystemTime(new Date('2026-10-29T00:10:00-04:00'));await p.evaluate(()=>renderStudents());assert.deepEqual(await current(),['c'],'lesson crossing midnight stays current');
  await p.clock.setSystemTime(new Date('2026-10-29T00:45:00-04:00'));await p.evaluate(()=>renderStudents());assert.deepEqual(await current(),[],'end boundary excluded');
  await p.evaluate(()=>showScreen('students-online'));assert.deepEqual(await order(),['x']);assert.equal(await p.locator('#studentList .ap-student-lesson-time').count(),0);
  await p.evaluate(()=>showScreen('students-archived'));assert.deepEqual(await order(),['z']);assert.equal(await p.locator('#studentList .ap-student-lesson-time').count(),0);
  await p.clock.setSystemTime(new Date('2026-10-21T11:10:00-04:00'));await p.evaluate(()=>{showScreen('workouts');renderWorkouts()});assert.equal(await p.locator('#workoutStudentList .workout-student-choice').first().getAttribute('data-student-id'),'a');
  await p.evaluate(()=>{showScreen('students-presencial');state.occurrenceStatus[occurrenceKey('la','2026-10-21')]='cancelada';save();document.dispatchEvent(new Event('visibilitychange'))});assert.deepEqual(await current(),[],'refresh on foreground');
  for(const width of [280,360]){await p.setViewportSize({width,height:800});await p.evaluate(()=>{document.documentElement.style.fontSize='20px';delete state.occurrenceStatus[occurrenceKey('la','2026-10-21')];renderStudents()});assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);const b=p.locator('#studentList .ap-student-lesson-time').first();assert.ok(await b.evaluate(n=>n.scrollWidth<=n.clientWidth+1));}
  assert.deepEqual(errors,[]);await ctx.close();console.log('PASS: current lesson first, exact start/end transitions without reopening, next appointments, original order restored, weekly occurrence exceptions, overnight, archived/online isolation, search, workout roster, foreground refresh and narrow layouts. No persisted data mutation; Android simulated.');
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);server.close();process.exitCode=1});
