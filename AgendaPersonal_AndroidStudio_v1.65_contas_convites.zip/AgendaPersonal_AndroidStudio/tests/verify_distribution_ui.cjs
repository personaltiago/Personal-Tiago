'use strict';
const assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const {ctx,element,storage}=require('./verify_shell_boot.cjs');
const teacher=ctx.APStudentModel.TEACHER,extra=new Map(),get=ctx.document.getElementById;
ctx.document.getElementById=id=>extra.get(id)||get(id);
ctx.document.body.appendChild=node=>{extra.set(node.id,node);for(const match of node.innerHTML.matchAll(/id="([^"]+)"/g))element(match[1]);};
let tokenCalls=0,posted=[],applied=[],account='',testTime=Date.now();
ctx.Date=class extends Date{static now(){return testTime}};
ctx.XMLHttpRequest=class{
 constructor(){this.headers={};const listeners={};this.upload={addEventListener:(type,fn)=>{listeners[type]=fn},fire:(type,event={})=>listeners[type]?.(event)}}
 open(method,url){this.method=method;this.url=url}setRequestHeader(name,value){this.headers[name]=value}
 send(body){this.body=body;posted.push(this)}
 complete(status,value){this.status=status;this.responseText=JSON.stringify(value);this.onload()}
};
const candidate={format:1,appId:'com.tiagolima.agendapersonal',bridgeVersion:3,dataSchema:4,sequence:100,version:'1.11.94',files:Object.fromEntries(['index.html','professor.html','avaliacoes.html','cadastro.html'].map(n=>[n,fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets',n),'utf8')]))};
ctx.AbortSignal=AbortSignal;
ctx.Android={setUpdateAccount:uid=>account=uid,getUpdateStatus:()=>JSON.stringify({installedSequence:99,manifest:{available:true,sequence:100,version:'1.11.94'}}),getPublishableUpdate:()=>JSON.stringify(candidate),applyPublishedUpdate:manifest=>applied.push(JSON.parse(manifest)),openUpdates(){}};
const user={uid:teacher,getIdToken:async force=>{assert.equal(force,true);tokenCalls++;return 'fresh-teacher-token'}},sdk={auth:{currentUser:user},signOut:async auth=>auth.currentUser=null};
ctx.__accountTest.setSdk(sdk);
storage.set('ap_professor_marca_159_professor_teste',JSON.stringify({completed:true,name:'Professor',description:'Personal Trainer',main:'#A12CFF',support:'#08070C',bg:'#08070C',design:'atual'}));
async function run(){
 assert.equal(ctx.APupdates.openPublisher(),false);assert.equal(tokenCalls,0);
 await ctx.__accountTest.activate(user,'Professor');assert.equal(account,teacher);
 assert.equal(ctx.APupdates.openPublisher(),true);assert.equal(extra.get('apUpdatePublisher').hidden,false);
 const file={size:JSON.stringify(candidate).length,text:async()=>JSON.stringify(candidate)};
 await element('apPublishFile').fire('change',{target:{files:[file]}});assert.equal(element('apPublishSend').disabled,false);
 element('apPublishNotes').value='Correção de exercício';
 const sending=element('apPublishSend').onclick();await new Promise(r=>setImmediate(r));assert.equal(posted.length,1);
 assert.equal(await element('apPublishSend').onclick(),false,'duplicate sends blocked');assert.equal(ctx.APupdates.closePublisher(),false,'sending is not silently canceled');
 assert.equal(posted[0].headers.Authorization,'Bearer fresh-teacher-token');assert.equal(posted[0].body,JSON.stringify(candidate));
 const xhr=posted[0],bytes=new TextEncoder().encode(xhr.body).byteLength;testTime+=2000;xhr.upload.fire('progress',{lengthComputable:true,loaded:Math.floor(bytes/2),total:bytes});
 const halfPercent=Math.floor(Math.floor(bytes/2)/bytes*100);assert.equal(element('apPublishProgressPercent').textContent,halfPercent+'% do envio');assert.equal(element('apPublishProgressBar').value,halfPercent);assert.match(element('apPublishProgressEta').textContent,/Estimativa/);
 xhr.upload.fire('load');assert.equal(element('apPublishProgressPercent').textContent,'100% do envio');assert.equal(element('apPublishProgress').dataset.state,'confirming');assert.equal(applied.length,0,'100% upload is not publication success');assert.equal(element('apPublishSend').disabled,true);
 assert.ok(xhr.url.endsWith('/api/publish'));xhr.complete(201,{published:true,manifest:{available:true,sequence:100,version:'1.11.94'}});assert.equal(await sending,true);assert.equal(applied.length,1);assert.equal(element('apPublishStatus').dataset.kind,'success');assert.equal(element('apPublishProgress').dataset.state,'done');
 // Retry failures preserve the honest last byte count and unlock the controls.
 const rejected=element('apPublishSend').onclick();await new Promise(r=>setImmediate(r));const xhr2=posted.at(-1);xhr2.upload.fire('progress',{lengthComputable:false});assert.equal(element('apPublishProgressPercent').textContent,'—');xhr2.complete(403,{error:'Sessão recusada.'});assert.equal(await rejected,false);assert.equal(element('apPublishStatus').textContent,'Sessão recusada.');assert.equal(element('apPublishProgress').dataset.state,'error');assert.equal(element('apPublishSend').disabled,false);assert.equal(applied.length,1);
 const timed=element('apPublishSend').onclick();await new Promise(r=>setImmediate(r));posted.at(-1).ontimeout();assert.equal(await timed,false);assert.match(element('apPublishStatus').textContent,/demorou/);assert.equal(element('apPublishSend').disabled,false);
 const broken=element('apPublishSend').onclick();await new Promise(r=>setImmediate(r));posted.at(-1).onerror();assert.equal(await broken,false);assert.match(element('apPublishStatus').textContent,/conexão/);
 ctx.__AP_STUDENT_CONTEXT={role:'student',storageId:'student_s'};vm.runInContext("exActiveId='p';exNewSession=function(){return null};APstudentStorage.setItem(exStorageKey(),JSON.stringify({active:{p:{id:'p'}},history:[]}))",ctx);
 assert.equal(ctx.APupdates.canInstall(),false,'active student workout blocks reload');
 ctx.__AP_STUDENT_CONTEXT=null;assert.equal(ctx.APupdates.canInstall(),true);ctx.APupdates.refreshNotice();assert.equal(element('apProfileUpdates').dataset.available,'true');
 await ctx.APaccounts.logout();assert.equal(account,'');assert.equal(extra.get('apUpdatePublisher').hidden,true);assert.equal(ctx.APupdates.openPublisher(),false);
 await assert.rejects(()=>ctx.APaccounts.getPublicationToken(),/professor/);assert.equal(tokenCalls,4);
 console.log('PASS: real page bundle selection, XHR byte progress, measured ETA, unknown size, upload complete versus confirmed publication, HTTP error, timeout, network failure, fresh ID token, duplicate lock, success/apply, active-workout guard, update badge and logout. DOM/Firebase/network simulated.');
}
run().catch(error=>{console.error(error);process.exitCode=1});
