'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{spawnSync}=require('node:child_process'),{chromium}=require('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets'),review=process.env.AGENDA_REVIEW_DIR||path.resolve(__dirname,'../../../review/icon-finish');fs.mkdirSync(review,{recursive:true});
const fixture={students:[{id:'s',name:'Aluna de teste',studentType:'presencial'},{id:'a',name:'Arquivada',studentType:'online',archived:true}],workoutPlans:[],lessons:[],payments:[],history:[],customData:{preserved:67}};
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,req.url.includes('avaliacoes')?'avaliacoes.html':'professor.html')))});
const settle=page=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(()=>requestAnimationFrame(r)))));
function median(png){const r=spawnSync('python3',['-c',"import io,sys,json\nfrom PIL import Image\nfrom statistics import median\np=[x for x in Image.open(io.BytesIO(sys.stdin.buffer.read())).convert('RGB').getdata() if x[2]-x[1]>22 and x[0]-x[1]>12 and 40<sum(x)<570]\nprint(json.dumps([median([x[i] for x in p]) for i in range(3)] if len(p)>8 else None))"],{input:png});assert.equal(r.status,0,r.stderr.toString());return JSON.parse(r.stdout.toString())}
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});const context=await browser.newContext({viewport:{width:390,height:900},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());await context.addInitScript(f=>{if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(f))},fixture);
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>!!window.AgendaIconFinish&&!!window.AgendaAppearance);
 assert.equal(await page.evaluate(()=>AgendaIconFinish.get()),'theme','new preference does not force an icon change');
 const before=await page.evaluate(()=>JSON.stringify(state));await page.evaluate(()=>{AgendaColors.selectDesign('deep-tl');AgendaColors.save({...AgendaColors.get(),primary:'#a12cff',secondary:'#d77cff'});AgendaAppearance.setMode('light');openColorPanel()});await settle(page);
 const colors=await page.evaluate(()=>AgendaColors.get());await page.locator('[data-icon-finish="matte"]').click();await settle(page);
 assert.equal(await page.locator('[data-icon-finish="matte"]').getAttribute('aria-pressed'),'true');assert.deepEqual(await page.evaluate(()=>AgendaColors.get()),colors);assert.equal(await page.evaluate(()=>AgendaColors.getDesign()),'deep-tl','finish selection does not select a design');
 await page.locator('#colorPanelDialog .color-panel-sheet').screenshot({path:path.join(review,'seletor-claro.png')});await page.evaluate(()=>{closeDialog('colorPanelDialog');showScreen('more')});await settle(page);
 const selectors=['[data-screen="today"]','[data-screen="makeup"]','[data-screen="students-presencial"]','[data-screen="students-online"]','[data-screen="settings"]','[data-panel-action="logout"]','#morePet'];
 for(const selector of selectors){const icon=page.locator('.more-function'+selector+' .more-function-icon>svg').first();if(selector==='#morePet')continue;assert.ok(await icon.getAttribute('data-deep-decorated')!==null,'matte renderer decorates '+selector)}
 const raster=page.locator('.more-function[data-screen="today"] .more-function-icon>svg'),vector=page.locator('#morePet .more-function-icon>svg');
 const rasterLight=median(await raster.screenshot()),vectorLight=median(await vector.screenshot());assert.ok(rasterLight&&vectorLight,'raster and vector are visibly purple');
 const material=()=>vector.evaluate(n=>['light','upper','mid','low','deep','rim'].map(k=>getComputedStyle(n).getPropertyValue('--dp-'+k)));
 const fixed=await material();assert.equal(fixed[2],'#481e69');assert.ok(vectorLight[2]<170,'matte vector has controlled dark material');
 await page.locator('[aria-labelledby="moreOptionsTitle"]').screenshot({path:path.join(review,'mais-claro.png')});await page.locator('[aria-labelledby="morePrincipalTitle"]').screenshot({path:path.join(review,'principal-claro.png')});
 await page.evaluate(()=>AgendaAppearance.setMode('dark'));await settle(page);assert.deepEqual(await material(),fixed);
 for(const [actual,expected]of [[median(await raster.screenshot()),rasterLight],[median(await vector.screenshot()),vectorLight]])actual.forEach((v,i)=>assert.ok(Math.abs(v-expected[i])<=10,'same matte material with translucent edges composited on different backgrounds in light and dark: '+actual+' / '+expected));
 await page.locator('[aria-labelledby="moreOptionsTitle"]').screenshot({path:path.join(review,'mais-escuro.png')});await page.locator('[aria-labelledby="morePrincipalTitle"]').screenshot({path:path.join(review,'principal-escuro.png')});
 await page.evaluate(()=>{AgendaColors.save({...AgendaColors.get(),primary:'#2872e8',secondary:'#19945f'});showScreen('students-presencial')});await settle(page);await page.screenshot({path:path.join(review,'alunos-escuro.png')});
 for(const width of [320,390,480]){await page.setViewportSize({width,height:900});await page.evaluate(()=>openColorPanel());await settle(page);assert.ok(await page.locator('.icon-finish-choices').evaluate(n=>n.scrollWidth<=n.clientWidth+1),'choice fits '+width);await page.evaluate(()=>closeDialog('colorPanelDialog'))}
 await page.setViewportSize({width:390,height:900});
 for(const design of ['current','neon-tl','metal-tl','pro-tl','deep-tl']){
  await page.evaluate(design=>{AgendaColors.selectDesign(design);showScreen('more')},design);await settle(page);assert.deepEqual(await material(),fixed,'finish is independent of '+design);assert.equal(await page.evaluate(()=>AgendaIconFinish.get()),'matte');
  assert.equal(await page.locator('#morePet svg[data-deep-decorated]').count(),1);assert.equal(await page.locator('.screen svg[data-metal-decorated]').count(),0,'no stacked metal renderer');
  assert.deepEqual(await vector.evaluate(n=>[...n.querySelectorAll('.deep-part[filter]')].map(x=>getComputedStyle(x).filter)),['none'],'matte suppresses specular gloss');
  await page.evaluate(()=>AgendaIconFinish.set('theme'));await settle(page);
  if(design!=='deep-tl')assert.equal(await page.locator('.screen svg[data-deep-decorated]').count(),0,'restores '+design+' original icons');
  await page.evaluate(()=>AgendaIconFinish.set('matte'));await settle(page);
 }
 await page.reload();await page.waitForFunction(()=>window.AgendaIconFinish?.get()==='matte');await page.evaluate(()=>showScreen('more'));await settle(page);assert.deepEqual(await material(),fixed,'persisted before render');
 const assess=await context.newPage();assess.on('pageerror',e=>errors.push(e.message));await assess.goto('http://127.0.0.1:'+server.address().port+'/avaliacoes.html');await assess.waitForFunction(()=>window.AgendaIconFinish?.get()==='matte');await settle(assess);
 assert.ok(await assess.locator('svg[data-deep-decorated]').count()>0,'assessments use same finish');await page.evaluate(()=>AgendaIconFinish.set('theme'));await assess.waitForFunction(()=>AgendaIconFinish.get()==='theme');await page.evaluate(()=>AgendaIconFinish.set('matte'));await assess.waitForFunction(()=>AgendaIconFinish.get()==='matte');
 await page.evaluate(()=>{openColorPanel();const original=Storage.prototype.setItem;window.restoreStorage=()=>Storage.prototype.setItem=original;Storage.prototype.setItem=function(k,v){if(k===AgendaIconFinish.key)throw new Error('quota');return original.call(this,k,v)}});
 await page.locator('[data-icon-finish="theme"]').click();assert.equal(await page.evaluate(()=>AgendaIconFinish.get()),'matte');assert.equal(await page.locator('#iconFinishStatus').getAttribute('data-error'),'true');assert.equal(await page.locator('[data-icon-finish="matte"]').getAttribute('aria-pressed'),'true');await page.evaluate(()=>restoreStorage());
 await page.evaluate(()=>AgendaColors.save({...AgendaColors.get(),primary:'#19945f'}));await settle(page);assert.deepEqual(await material(),fixed,'palette changes do not recolor matte');
 assert.equal(await page.evaluate(()=>JSON.stringify(state)),before,'no business-data edits');assert.deepEqual(errors,[]);console.log('PASS: real UI selects/restores finish; dark purple raster/vector stable across light/dark and custom colors; independent in 5 designs; no stacked renderers; restart, assessments live sync, save failure, 3 mobile widths and business data preservation.');
 }finally{if(browser)await browser.close();await new Promise(r=>server.close(r))}}
run().catch(e=>{console.error(e);process.exitCode=1});
