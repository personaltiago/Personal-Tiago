package org.json;
import java.util.*;

/** Real JSON text for native tests, including production-sized page strings. */
public class JSONObject {
    final Map<String,Object> fields = new LinkedHashMap<>();
    public static final Object NULL = new Object() {
        public boolean equals(Object other) { return other == null || other == this; }
        public int hashCode() { return 0; }
        public String toString() { return "null"; }
    };
    public JSONObject() {}
    public JSONObject(String text) {
        JSONTokener parser = new JSONTokener(text);
        Object result = parser.nextValue();
        if (!(result instanceof JSONObject) || parser.more()) throw new IllegalArgumentException("JSON inválido");
        fields.putAll(((JSONObject) result).fields);
    }
    public JSONObject put(String key,Object value) { fields.put(key,value == null ? NULL : value); return this; }
    public Object opt(String key) { return fields.get(key); }
    public int optInt(String key) { return optInt(key,0); }
    public int optInt(String key,int fallback) { Object value=fields.get(key); return value instanceof Number ? ((Number)value).intValue() : fallback; }
    public String optString(String key) { return optString(key,""); }
    public String optString(String key,String fallback) { Object value=fields.get(key);return value==null||value==NULL?fallback:String.valueOf(value); }
    public boolean optBoolean(String key) { return Boolean.TRUE.equals(fields.get(key)); }
    public JSONObject getJSONObject(String key) { Object value=fields.get(key);if(!(value instanceof JSONObject))throw new IllegalArgumentException(key);return (JSONObject)value; }
    public JSONArray getJSONArray(String key) { Object value=fields.get(key);if(!(value instanceof JSONArray))throw new IllegalArgumentException(key);return (JSONArray)value; }
    public String getString(String key) { if(!fields.containsKey(key))throw new IllegalArgumentException(key);return String.valueOf(fields.get(key)); }
    public int getInt(String key) { return ((Number)fields.get(key)).intValue(); }
    public int length() { return fields.size(); }
    public boolean has(String key) { return fields.containsKey(key); }
    public Iterator<String> keys() { return fields.keySet().iterator(); }
    public String toString() { StringBuilder out=new StringBuilder();append(out,this);return out.toString(); }
    public static String quote(String value) { StringBuilder out=new StringBuilder();string(out,value);return out.toString(); }
    static String arrayText(JSONArray value) { StringBuilder out=new StringBuilder();append(out,value);return out.toString(); }
    private static void append(StringBuilder out,Object value) {
        if(value==null||value==NULL){out.append("null");return;}
        if(value instanceof JSONObject){out.append('{');boolean first=true;for(Map.Entry<String,Object> entry:((JSONObject)value).fields.entrySet()){if(!first)out.append(',');first=false;string(out,entry.getKey());out.append(':');append(out,entry.getValue());}out.append('}');return;}
        if(value instanceof JSONArray){out.append('[');boolean first=true;for(Object item:((JSONArray)value).values){if(!first)out.append(',');first=false;append(out,item);}out.append(']');return;}
        if(value instanceof Number||value instanceof Boolean){out.append(value);return;}
        string(out,String.valueOf(value));
    }
    private static void string(StringBuilder out,String value) {
        out.append('"');
        for(int n=0;n<value.length();n++){
            char c=value.charAt(n);
            switch(c){
                case '"':out.append("\\\"");break;
                case '\\':out.append("\\\\");break;
                case '\n':out.append("\\n");break;
                case '\r':out.append("\\r");break;
                case '\t':out.append("\\t");break;
                case '\b':out.append("\\b");break;
                case '\f':out.append("\\f");break;
                default:if(c<32){out.append("\\u00");out.append("0123456789abcdef".charAt(c>>4));out.append("0123456789abcdef".charAt(c&15));}else out.append(c);
            }
        }
        out.append('"');
    }
}
