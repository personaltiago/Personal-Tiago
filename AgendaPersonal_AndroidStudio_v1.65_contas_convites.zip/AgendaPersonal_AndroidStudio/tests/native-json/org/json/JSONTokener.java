package org.json;
import java.util.*;

/** Strict tokenizer used by tests; no symbolic JSON IDs or retained object registry. */
public class JSONTokener {
    private final String text;
    private int position;
    public JSONTokener(String text) { if(text==null)throw new IllegalArgumentException("JSON nulo");this.text=text; }
    private void space(){while(position<text.length()&&Character.isWhitespace(text.charAt(position)))position++;}
    public boolean more(){space();return position!=text.length();}
    private char take(){if(position>=text.length())throw new IllegalArgumentException("JSON incompleto");return text.charAt(position++);}
    public Object nextValue(){
        space();char c=take();
        if(c=='"')return string();
        if(c=='{'){
            JSONObject object=new JSONObject();space();if(position<text.length()&&text.charAt(position)=='}'){position++;return object;}
            while(true){space();if(take()!='"')throw new IllegalArgumentException("Chave inválida");String key=string();space();if(take()!=':')throw new IllegalArgumentException("Separador inválido");object.put(key,nextValue());space();char end=take();if(end=='}')return object;if(end!=',')throw new IllegalArgumentException("Objeto inválido");}
        }
        if(c=='['){JSONArray values=new JSONArray();space();if(position<text.length()&&text.charAt(position)==']'){position++;return values;}while(true){values.put(nextValue());space();char end=take();if(end==']')return values;if(end!=',')throw new IllegalArgumentException("Lista inválida");}}
        int start=position-1;while(position<text.length()&&!Character.isWhitespace(text.charAt(position))&&",]}".indexOf(text.charAt(position))<0)position++;
        String token=text.substring(start,position);
        if(token.equals("true"))return Boolean.TRUE;if(token.equals("false"))return Boolean.FALSE;if(token.equals("null"))return JSONObject.NULL;
        try{if(token.matches("-?(0|[1-9][0-9]*)"))return Long.valueOf(token);if(token.matches("-?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+-]?[0-9]+)?")){double value=Double.parseDouble(token);if(Double.isFinite(value))return value;}}catch(NumberFormatException ignored){}
        throw new IllegalArgumentException("Valor inválido");
    }
    private String string(){
        StringBuilder value=new StringBuilder();
        while(position<text.length()){
            char c=take();if(c=='"')return value.toString();if(c<32)throw new IllegalArgumentException("Caractere inválido");
            if(c=='\\'){
                c=take();switch(c){
                    case '"':case '\\':case '/':break;
                    case 'n':c='\n';break;case 'r':c='\r';break;case 't':c='\t';break;case 'b':c='\b';break;case 'f':c='\f';break;
                    case 'u':if(position+4>text.length())throw new IllegalArgumentException("Unicode incompleto");try{c=(char)Integer.parseInt(text.substring(position,position+4),16);}catch(NumberFormatException e){throw new IllegalArgumentException("Unicode inválido");}position+=4;break;
                    default:throw new IllegalArgumentException("Escape inválido");
                }
            }
            value.append(c);
        }
        throw new IllegalArgumentException("Texto incompleto");
    }
}
