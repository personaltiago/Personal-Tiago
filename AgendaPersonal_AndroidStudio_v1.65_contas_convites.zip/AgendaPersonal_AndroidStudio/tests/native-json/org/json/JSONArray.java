package org.json;
import java.util.*;

public class JSONArray {
    final List<Object> values = new ArrayList<>();
    public JSONArray put(Object value) { values.add(value == null ? JSONObject.NULL : value); return this; }
    public int length() { return values.size(); }
    public Object opt(int index) { return index < 0 || index >= values.size() ? null : values.get(index); }
    public String toString() { return JSONObject.arrayText(this); }
}
