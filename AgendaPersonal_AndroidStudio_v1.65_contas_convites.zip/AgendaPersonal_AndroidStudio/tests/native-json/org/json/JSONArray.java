package org.json;
import java.util.*;

public class JSONArray {
    final List<Object> values = new ArrayList<>();
    public JSONArray() {}
    public JSONArray(String text) {
        JSONTokener parser = new JSONTokener(text);
        Object value = parser.nextValue();
        if (!(value instanceof JSONArray) || parser.more()) throw new IllegalArgumentException("Lista inválida");
        values.addAll(((JSONArray) value).values);
    }
    public JSONObject optJSONObject(int index) { return opt(index) instanceof JSONObject ? (JSONObject) opt(index) : null; }
    public JSONObject getJSONObject(int index) {
        JSONObject object = optJSONObject(index);
        if (object == null) throw new IllegalArgumentException("Objeto ausente");
        return object;
    }
    public JSONArray put(Object value) { values.add(value == null ? JSONObject.NULL : value); return this; }
    public int length() { return values.size(); }
    public Object opt(int index) { return index < 0 || index >= values.size() ? null : values.get(index); }
    public String toString() { return JSONObject.arrayText(this); }
}
