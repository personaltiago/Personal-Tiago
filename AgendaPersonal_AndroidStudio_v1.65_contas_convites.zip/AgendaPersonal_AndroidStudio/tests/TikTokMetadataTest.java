package com.tiagolima.agendapersonal;
import java.net.URI;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.JSONObject;
public class TikTokMetadataTest {
 static int count;static void check(boolean value){count++;if(!value)throw new AssertionError("check "+count);}
 static void reject(String link,TikTokVideoResolver.Fetcher f)throws Exception{try{TikTokVideoResolver.resolve(link,f);throw new AssertionError("accepted "+link);}catch(IllegalArgumentException expected){count++;}}
 public static void main(String[] args)throws Exception{
  String id="7509287531498769720",full="https://www.tiktok.com/@tiagolima.treinos/video/"+id;
  JSONObject m=new JSONObject().put("thumbnail_url","https://p16.muscdn.com/cover.jpg").put("title","Título do vídeo");List<String> calls=new ArrayList<>();
  TikTokVideoResolver.Fetcher f=u->{calls.add(u.toString());return u.getHost().equals("vt.tiktok.com")?new TikTokVideoResolver.Response(302,full+"?_t=tracking",""):new TikTokVideoResolver.Response(200,null,m.toString());};
  JSONObject result=TikTokVideoResolver.resolve("https://vt.tiktok.com/short/",f);check(result.getString("videoId").equals(id));check(result.getString("url").equals(full));check(result.getString("thumbnail").endsWith("cover.jpg"));check(calls.size()==2);check(calls.get(1).startsWith("https://www.tiktok.com/oembed?url="));
  calls.clear();result=TikTokVideoResolver.resolve(full,f);check(calls.size()==1);check(result.getString("videoId").equals(id));
  result=TikTokVideoResolver.resolve(full,u->{throw new java.io.IOException("offline");});check(result.getString("videoId").equals(id));check(result.getString("thumbnail").isEmpty());
  result=TikTokVideoResolver.resolve(full,u->new TikTokVideoResolver.Response(200,null,new JSONObject().put("thumbnail_url","file:///private").toString()));check(result.getString("thumbnail").isEmpty());
  for(String bad:Arrays.asList("http://www.tiktok.com/@a/video/"+id,"https://tiktok.com.evil.test/@a/video/"+id,"https://x@www.tiktok.com/@a/video/"+id,"https://www.tiktok.com:444/@a/video/"+id,"file:///x","https://127.0.0.1/x"))reject(bad,f);
  reject("https://vt.tiktok.com/short/",u->new TikTokVideoResolver.Response(302,"https://evil.test/", ""));
  reject("https://vt.tiktok.com/short/",u->new TikTokVideoResolver.Response(302,"/loop/", ""));
  reject("https://www.tiktok.com/@a",u->new TikTokVideoResolver.Response(200,null,""));
  check(TikTokVideoResolver.postId(new URI(full+"?a=b")).equals(id));check(TikTokVideoResolver.postId(new URI("https://www.tiktok.com/player/v1/"+id)).equals(id));check(!TikTokVideoResolver.validId("'+alert(1)+'"));
  String html=TikTokPlayerPage.html(id),template=new String(Files.readAllBytes(Paths.get(args[0])),StandardCharsets.UTF_8);check(html.equals(template.replace("__VIDEO_ID__",id)));check(!html.contains("Android."));check(html.contains("event.source!==frame.contentWindow"));check(html.contains("event.origin!==origin"));
  try{TikTokPlayerPage.html("x<script>");throw new AssertionError();}catch(IllegalArgumentException expected){count++;}
  System.out.println("PASS: "+count+" native TikTok URL/redirect/oEmbed, missing-cover/offline, origin/credential/port, player ID and generated-page checks. Network simulated.");
 }
}
