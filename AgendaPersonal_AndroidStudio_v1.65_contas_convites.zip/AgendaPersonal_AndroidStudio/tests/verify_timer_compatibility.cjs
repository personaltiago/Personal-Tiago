'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),vm=require('node:vm');
const {chromium}=require('playwright'),root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'app/src/main/assets/professor.html'),'utf8');
const helper=fs.readFileSync(path.join(root,'web/timer-compatibility.js'),'utf8');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(html)});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{for(const modern of [false,true]){
  const ctx=await browser.newContext({viewport:{width:390,height:844},timezoneId:'America/Cuiaba'});await ctx.route('https://**',r=>r.abort());
  await ctx.addInitScript(modern=>{
   window.__starts=[];window.__cancels=[];window.__plans={rest:true,'old|2026-10-24':true};window.__beeps=0;
   window.Android={
    getTimerOverlayStatus(){return JSON.stringify({showing:Object.values(__plans).some(Boolean),kind:'workout-rest',...(modern?{dismissed:false}:{})})},
    // This reproduces the legacy bridge: starting an alarm also creates a wide overlay.
    startLessonTimer(raw){const p=JSON.parse(raw);__starts.push('lesson');__plans[p.lessonId+'|'+p.classDate]=true;return true},
    startWorkoutRest(){__starts.push('rest');__plans.rest=true;return true},
    cancelLessonTimer(id,date){__cancels.push(id+'|'+date);delete __plans[id+'|'+date]},
    cancelWorkoutRest(){__cancels.push('rest');delete __plans.rest;return true},
    syncLessonAlarms(){return true},getAlarmStatus(){return '{"ready":true}'},getCustomSoundStatus(){return '{}'}
   };
   const seedNow=Date.parse('2026-10-24T16:00:00Z');const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k==='agendaPersonalTL_v1'&&window.__quota)throw Error('quota');return set.call(this,k,v)};
   if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({
    students:[{id:'s',name:'Aluna',studentType:'presencial'}],lessons:[{id:'old',studentId:'s',date:'2026-10-24',time:'12:00',duration:60,repeat:'none',repeatDays:[]}],
    workoutPlans:[{id:'p',studentId:'s',name:'Ficha',visibility:'always',days:[{id:'d',name:'Treino',exercises:[{id:'a',name:'Agachamento',sets:'3',reps:'12',load:'20 kg',rest:'60'}]}]}],
    workoutDrafts:{'p|d':{active:true,sessionId:'saved-session',startedAt:seedNow,exercises:{a:{sets:[{done:true,load:'23 kg',reps:'11'}]}}}},
    workoutExecutions:[{id:'prior-result',studentId:'s',duration:900}],customData:{keep:'preserved'},
    lessonTimers:{'old|2026-10-24':{lessonId:'old',date:'2026-10-24',studentId:'s',startedAt:seedNow,endAt:seedNow+3600000,duration:60,native:true,notified:false}},
    workoutRest:{id:'prior-rest',studentId:'s',planId:'p',dayId:'d',exerciseId:'a',student:'Aluna',exercise:'Agachamento',seconds:60,endAt:seedNow+60000,native:true,notified:false}
   }));
  },modern);
  const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.clock.install({time:new Date('2026-10-24T16:00:00Z')});await page.goto('http://127.0.0.1:'+server.address().port);
  const saved=await page.evaluate(()=>({rest:state.workoutRest,lesson:state.lessonTimers['old|2026-10-24'],draft:state.workoutDrafts['p|d'],data:state.customData,results:state.workoutExecutions,plans:__plans,cancels:__cancels}));
  assert.ok(saved.lesson,JSON.stringify({modern,saved,diagnostic:await page.evaluate(()=>({lessons:state.lessons,students:state.students,now:Date.now(),valid:validWorkoutDate('2026-10-24'),occurs:isOccurrence(state.lessons[0],'2026-10-24')})),errors}));
  assert.equal(saved.rest.native,modern);assert.equal(saved.lesson.native,modern);assert.equal(saved.rest.endAt,Date.parse('2026-10-24T16:01:00Z'));assert.equal(saved.lesson.endAt,Date.parse('2026-10-24T17:00:00Z'));
  assert.equal(saved.draft.sessionId,'saved-session');assert.equal(saved.draft.exercises.a.sets[0].load,'23 kg');assert.equal(saved.results[0].id,'prior-result');assert.equal(saved.data.keep,'preserved');
  assert.equal(Object.keys(saved.plans).length,modern?2:0,'legacy overlay plans cancelled, modern native alarms retained');
  assert.equal(saved.cancels.length,modern?0:2);
  await page.evaluate(()=>{workoutRestBeep=()=>__beeps++;showScreen('workouts');openWorkoutStudent('s');selectWorkoutPlan('p');openWorkoutDay('d');openWorkoutRest('a',true)});
  assert.equal(await page.evaluate(()=>state.workoutRest.native),modern);assert.equal(await page.evaluate(()=>__starts.length),modern?1:0);
  if(!modern){
   assert.ok(await page.locator('#apRestFloating').isVisible());assert.match(await page.evaluate(()=>lessonTimerHelp(state.lessonTimers['old|2026-10-24'])),/no aplicativo/);
   // Even a restored stale native flag must not reopen the legacy system bar.
   await page.evaluate(()=>{window.__reopens=0;Android.showWorkoutRestOverlay=()=>__reopens++;state.workoutRest.native=true;floatWorkoutRest();state.workoutRest.native=false});
   assert.equal(await page.evaluate(()=>__reopens),0);
  }
  const deadline=await page.evaluate(()=>state.workoutRest.endAt);
  await page.evaluate(()=>{__quota=true;document.getElementById('workoutRestSeconds').value='90';saveWorkoutRest({preventDefault(){}});__quota=false});
  assert.equal(await page.evaluate(()=>state.workoutRest.endAt),deadline);assert.equal(await page.evaluate(()=>__starts.length),modern?1:0);
  await page.evaluate(()=>{stopLessonTimer('old','2026-10-24');startLessonTimer('old','2026-10-24')});assert.equal(await page.evaluate(()=>state.lessonTimers['old|2026-10-24'].native),modern);assert.equal(await page.evaluate(()=>__starts.length),modern?2:0);
  await page.clock.fastForward(61000);await page.evaluate(()=>{updateWorkoutSessionLabels();updateWorkoutSessionLabels()});assert.equal(await page.evaluate(()=>__beeps),modern?0:1,'foreground sound fires once');
  await page.reload();assert.equal(await page.evaluate(()=>state.customData.keep),'preserved');assert.equal(await page.evaluate(()=>state.lessonTimers['old|2026-10-24'].native),modern);assert.deepEqual(errors,[]);
  await ctx.close();
 }
 // Execute the actual bi-set arm function too: it must not bypass the facade.
 const begin=html.indexOf('  function armRest(rest,old){'),end=html.indexOf('\n  window.completeWorkoutBisetPart',begin);assert.ok(begin>0&&end>begin);
 for(const modern of [false,true]){
  let starts=0;const api={getTimerOverlayStatus:()=>JSON.stringify(modern?{dismissed:false}:{}),startWorkoutRest(){starts++;return true}};
  const box={window:{Android:api},Android:api,state:{},localStorage:{setItem(){}},DB_KEY:'test',document:{documentElement:{}},getComputedStyle:()=>({getPropertyValue:()=> '#9CC72C'}),updateWorkoutSessionLabels(){},cancelNativeWorkoutRest(){throw Error('Unexpected cancellation')},toast(){}};
  vm.createContext(box);vm.runInContext(helper,box);vm.runInContext(html.slice(begin,end),box);const rest={endAt:12345,native:false};box.armRest(rest,null);assert.equal(starts,modern?1:0);assert.equal(rest.native,modern);assert.equal(rest.endAt,12345);
 }
 // Storage failure during migration must never erase drafts or stop JS counting.
 const old={workoutRest:{native:true,endAt:9000},lessonTimers:{x:{native:true,lessonId:'l',date:'d',endAt:10000}},customData:{keep:true}},box={window:{Android:{getTimerOverlayStatus:()=> '{}',cancelWorkoutRest:()=>true,cancelLessonTimer(){}}},localStorage:{setItem(){throw Error('quota')}}};
 vm.createContext(box);vm.runInContext(helper,box);box.window.APTimerCompatibility.migrate(old,'test');assert.equal(old.workoutRest.native,false);assert.equal(old.lessonTimers.x.native,false);assert.equal(old.lessonTimers.x.endAt,10000);assert.equal(old.customData.keep,true);
 console.log('PASS: real generated page with legacy/modern Android bridge mocks; existing overlays cancelled only on legacy, all 3 timer start paths guarded, compact view/deadlines/data/reload/quota preserved, one-shot foreground sound and modern native alarms retained. Physical-device background behavior not exercised.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
