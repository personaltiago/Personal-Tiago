'use strict';
// Checks the fixed Agenda Personal symbol: the teacher panel uses it in the header and the profile card, the green layer is
// tinted by the theme accent (var(--ac-accent)), the white layer stays white, the logo upload is gone from the brand setup
// (the teacher photo stays), and old stored logos are cleaned out of the brand record (frees space).
// The visual result was checked separately in a browser render; this does not run on a physical device.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const file=process.argv[2]||path.join(__dirname,'..','web','native-release.agenda.json');
const files=JSON.parse(fs.readFileSync(file,'utf8')).files,p=files['professor.html'],ix=files['index.html'];
let cases=0;const eq=(n,a,b)=>{cases++;assert.deepEqual(a,b,n)},ok=(n,v)=>{cases++;assert.ok(v,n)};
ok('cabeçalho usa o símbolo fixo',p.includes('<div class="brand"><span class="ap-app-symbol" role="img" aria-label="Agenda Personal"></span>'));
ok('cartão de perfil usa o símbolo fixo',p.includes('<span class="more-identity-logo ap-app-symbol" role="img" aria-label="Agenda Personal"></span>'));
ok('sem imagem de logo antiga no cabeçalho',!/<div class="brand"><img/.test(p)&&!p.includes('data-ap-shared-logo'));
const css=p.match(/<style id="ap-app-symbol-css">([\s\S]*?)<\/style>/);ok('CSS do símbolo presente',css);
ok('emblema original embutido',/--ap-sym-src:url\(data:image\/webp;base64,/.test(css[1]));
ok('emblema recolorido tem prioridade sobre o original',css[1].includes('var(--ap-sym-img,var(--ap-sym-src))'));
ok('sem borda dupla no emblema',css[1].includes('border:0!important')&&css[1].includes('box-shadow:none!important'));
ok('regras de tamanho e borda do cabeçalho valem para o símbolo',/\.brand img,\.brand \.ap-app-symbol\{width:44px/.test(p)&&p.includes(':is(.brand img,.brand .ap-app-symbol,'));
ok('mesmo CSS no index para a prévia da marca',/<style id="ap-app-symbol-css">/.test(ix)&&ix.includes('#apTeacherSetup .aps-preview-logo .ap-app-symbol'));
ok('index não troca mais o logo do painel pelo da marca',!ix.includes('let o=t.logo')&&!ix.includes('(e,t,a)=>t+o+a'));
ok('envio de logo removido da tela de marca (foto fica)',ix.includes('<div class="aps-imagebox" hidden><strong>Logotipo da marca</strong>')&&ix.includes('apsPhotoFile')&&ix.includes('Colocar minha foto'.slice(0,0)));
ok('caixa do logo some de verdade e a foto ocupa a largura toda',ix.includes('#apTeacherSetup .aps-imagebox[hidden]{display:none!important}')&&ix.includes('#apTeacherSetup .aps-images{grid-template-columns:minmax(0,1fr)!important}'));
ok('menu sem a palavra logo',p.includes('Personalizar nome e foto')&&!p.includes('Personalizar nome, foto e logo'));
// cleanup script of old stored logos
const m=ix.match(/<script id="ap-brand-logo-cleanup">([\s\S]*?)<\/script>/);ok('limpeza de logos antigos presente',m);
function run(initial){const store=new Map(initial?[['ap_professor_marca_159_professor_teste',JSON.stringify(initial)]]:[]);
 const ls={getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,String(v))};
 new Function('localStorage','addEventListener',m[1])(ls,()=>{});return ls.getItem('ap_professor_marca_159_professor_teste')}
const big='data:image/png;base64,'+'A'.repeat(500000);
let out=JSON.parse(run({name:'Tiago',description:'Personal Trainer',photo:'data:image/jpeg;base64,xyz',logo:big,imageEdits:{logo:{source:big,crop:{zoom:1}},photo:{source:'p',crop:{zoom:2}}},main:'#A12CFF'}));
eq('logo apagado',out.logo,'');ok('original do logo apagado',!out.imageEdits.logo);
eq('foto preservada',out.photo,'data:image/jpeg;base64,xyz');eq('edição da foto preservada',out.imageEdits.photo.crop.zoom,2);eq('nome e cor preservados',[out.name,out.main],['Tiago','#A12CFF']);
eq('sem registro não cria nada',run(null),null);
const small=JSON.stringify({name:'A',logo:'',main:'#111111'});const st=new Map([['ap_professor_marca_159_professor_teste',small]]);
eq('registro já limpo não é regravado',run({name:'A',logo:'',main:'#111111'}),small);
console.log('PASS Símbolo fixo do aplicativo: '+cases+' verificações (sem aparelho físico).');
// Reforço no index: mesmo com uma tela do professor antiga, o emblema substitui o logo enviado e usa a cor real do tema.
{const fs=require('fs'),path=require('path');const r=JSON.parse(fs.readFileSync(path.join(__dirname,'..','web','native-release.agenda.json'),'utf8'));const ix=r.files['index.html'];
 const a=ix.indexOf('<script id="ap-app-symbol-enforce">'),b=ix.indexOf('</script>',a);if(a<0||ix.lastIndexOf('</body>')<a)throw Error('reforço do emblema ausente no index');
 const code=ix.slice(a+35,b);let prev=s=>s;const win={APprepareTeacherDocument:s=>prev(s)},doc={getElementById:id=>id==='ap-app-symbol-css'?{textContent:'.ap-app-symbol{}'}:null,querySelectorAll:()=>[],querySelector:()=>null,addEventListener:()=>{},documentElement:{}};
 new Function('window','document','addEventListener',code)(win,doc,()=>{});
 const out=win.APprepareTeacherDocument('<html><head></head><body><img class="more-identity-logo"></body></html>');
 if(!out.includes('id="ap-app-symbol-css"')||!out.includes('id="ap-app-symbol-fix"')||!out.includes("img.more-identity-logo,.brand>img")||!out.includes('--ap-sym-img'))throw Error('reforço não injetado');
 const out2=win.APprepareTeacherDocument('<html><head><style id="ap-app-symbol-css"></style></head><body></body></html>');
 if(out2.split('id="ap-app-symbol-css"').length!==2)throw Error('CSS duplicado');
 console.log('PASS reforço do emblema no index.');}
