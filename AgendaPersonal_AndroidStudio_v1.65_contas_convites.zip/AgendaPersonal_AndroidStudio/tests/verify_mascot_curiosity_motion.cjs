'use strict';
require('./mascot_continuous_harness.cjs').run('curious').catch(error=>{console.error(error);process.exitCode=1});
