'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'):require;
const {chromium}=runtime('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';if(!['index.html','professor.html','avaliacoes.html','cadastro.html'].includes(name)){res.writeHead(404);res.end();return}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.failStudentPhoto&&k.endsWith('agenda_demo_foto_perfil_Feminino'))throw new DOMException('Full','QuotaExceededError');return set.call(this,k,v)}});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>!!window.APStudentPhoto);
  async function activate(uid,name){await page.evaluate(({uid,name})=>{
   const s={id:'local_'+uid,firebaseUid:uid,name,gender:'Feminino'},area=APStudentModel.makeArea({students:[s],trainerProfile:{name:'Professor de teste',subtitle:'Personal Trainer',cref:'012345-G/RO',photoDataUrl:'',photoSourceDataUrl:'private source'},workoutPlans:[]},s);
   if(area.trainer.photoSourceDataUrl!==undefined)throw Error('Private crop source leaked');window.__fixtureArea=area;
   window.__AP_STUDENT_CONTEXT={storageId:uid,role:'student',profile:area.profile,area};APstudentUI.activate();route('home');
  },{uid,name})}
  await activate('alice','Aluna A');assert.equal(await page.locator('#apHomeProfessional .ap-professional-cref').textContent(),'CREF 012345-G/RO');
  assert.equal(await page.locator('#apHomeProfessional strong').textContent(),'Professor de teste');
  await page.evaluate(()=>route('profile'));assert.equal(await page.locator('#apProfileProfessional .ap-professional-cref').textContent(),'CREF 012345-G/RO');
  await page.evaluate(()=>openProfilePhoto());
  const data=await page.evaluate(()=>{const c=document.createElement('canvas');c.width=1200;c.height=600;const g=c.getContext('2d');g.fillStyle='red';g.fillRect(0,0,600,600);g.fillStyle='blue';g.fillRect(600,0,600,600);return c.toDataURL().split(',')[1]});
  const file={name:'landscape.png',mimeType:'image/png',buffer:Buffer.from(data,'base64')};await page.locator('#profilePhotoGallery').setInputFiles(file);await page.locator('#apStudentPhotoCrop').waitFor({state:'visible'});
  assert.equal(await page.evaluate(()=>savedProfilePhoto()),'');
  await page.locator('#apStudentCropZoom').evaluate(n=>{n.value='2';n.dispatchEvent(new Event('input',{bubbles:true}))});
  const box=await page.locator('#apStudentCropCanvas').boundingBox(),cdp=await context.newCDPSession(page),x=box.x+box.width/2,y=box.y+box.height/2;
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});for(const d of [.1,.2,.3])await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+box.width*d,y}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  await page.locator('#apStudentPhotoCrop .ap-student-crop-save').click();
  const saved=await page.evaluate(()=>({photo:savedProfilePhoto(),meta:JSON.parse(APstudentStorage.getItem(profilePhotoKey()+'_crop_v1')),key:profilePhotoKey()}));assert.ok(saved.meta.x>.65);
  const pixel=await page.evaluate(async()=>{const img=new Image();img.src=savedProfilePhoto();await img.decode();const c=document.createElement('canvas');c.width=c.height=512;const g=c.getContext('2d');g.drawImage(img,0,0);return [...g.getImageData(256,256,1,1).data]});assert.ok(pixel[2]>220&&pixel[0]<30);
  await page.evaluate(()=>openProfilePhoto());await page.locator('#adjustStudentPhoto').click();await page.locator('#apStudentPhotoCrop').waitFor({state:'visible'});await page.locator('#apStudentCropCanvas').press('ArrowLeft');await page.evaluate(()=>handleAgendaSystemBack());assert.equal(await page.evaluate(()=>APStudentPhoto.isOpen()),false);assert.equal(await page.evaluate(()=>savedProfilePhoto()),saved.photo);
  await page.locator('#adjustStudentPhoto').click();await page.locator('#apStudentPhotoCrop').waitFor({state:'visible'});await page.locator('#apStudentCropCanvas').press('ArrowLeft');await page.evaluate(()=>window.failStudentPhoto=true);await page.locator('.ap-student-crop-save').click();assert.equal(await page.evaluate(()=>savedProfilePhoto()),saved.photo);assert.deepEqual(await page.evaluate(()=>JSON.parse(APstudentStorage.getItem(profilePhotoKey()+'_crop_v1'))),saved.meta);assert.equal(await page.evaluate(()=>APStudentPhoto.isOpen()),true);await page.evaluate(()=>{window.failStudentPhoto=false;APStudentPhoto.cancel()});
  await activate('bob','Aluno B');assert.equal(await page.evaluate(()=>savedProfilePhoto()),'','account B cannot see account A photo');assert.equal(await page.evaluate(()=>APstudentStorage.getItem(profilePhotoKey()+'_crop_v1')),null);
  await page.evaluate(()=>openProfilePhoto());await page.locator('#profilePhotoCamera').setInputFiles(file);await page.locator('#apStudentPhotoCrop').waitFor({state:'visible'});
  await activate('alice','Aluna A');await page.evaluate(()=>APStudentPhoto.apply());assert.equal(await page.evaluate(()=>savedProfilePhoto()),saved.photo,'account change rejects an in-flight crop');assert.equal(await page.evaluate(()=>APStudentPhoto.isOpen()),false);
  await page.reload();await page.waitForFunction(()=>!!window.APStudentPhoto);await activate('alice','Aluna A');assert.equal(await page.evaluate(()=>savedProfilePhoto()),saved.photo);
  await page.evaluate(()=>{__AP_STUDENT_CONTEXT.area.trainer.name='Nome profissional atualizado';__AP_STUDENT_CONTEXT.area.trainer.cref='999999-G/RO';APstudentUI.repaint()});assert.equal(await page.locator('#apHomeProfessional .ap-professional-cref').textContent(),'CREF 999999-G/RO');
  await page.screenshot({path:path.resolve(__dirname,'../../../../student_professional_review.png')});
  for(const width of [320,390,480]){await page.setViewportSize({width,height:844});const fits=await page.locator('#apHomeProfessional').evaluate(n=>{const b=n.getBoundingClientRect();return b.x>=0&&b.right<=innerWidth+1&&n.scrollWidth<=n.clientWidth+1});assert.ok(fits,'professional bar fits '+width)}
  await page.evaluate(()=>{delete __AP_STUDENT_CONTEXT.area.trainer;APstudentUI.repaint()});assert.equal(await page.locator('#apHomeProfessional').isVisible(),false,'legacy packets do not invent credentials');
  await page.evaluate(()=>route('profile'));await page.evaluate(()=>openProfilePhoto());await page.locator('#removeProfilePhoto').click();assert.equal(await page.evaluate(()=>savedProfilePhoto()),'');assert.equal(await page.evaluate(()=>APstudentStorage.getItem(profilePhotoKey()+'_crop_v1')),null);
  assert.deepEqual(errors,[]);console.log('PASS: student mobile touch crop and zoom, blue-region pixel output, cancel/Android Back, storage rollback, source retention, camera/gallery, cross-account isolation, reload, packet-based professional CREF, live repaint and responsive bar. Firebase/device simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
