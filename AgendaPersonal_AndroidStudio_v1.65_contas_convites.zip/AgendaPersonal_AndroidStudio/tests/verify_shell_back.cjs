'use strict';
// Exercises the REAL shell handler (window.handleAgendaSystemBack in index.html) with small fakes.
// It does not simulate a physical swipe or the Android WebView; it checks the decision the page returns
// to WebBackController: true = handled (stay in the app), false = nothing left to close.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const file=process.argv[2]||path.join(__dirname,'..','web','native-release.agenda.json');
const html=JSON.parse(fs.readFileSync(file,'utf8')).files['index.html'];
const START='window.handleAgendaSystemBack=function(){',END='};for(const e of[t,n])';
const from=html.indexOf(START);assert.ok(from>0,'Tratador do Voltar não encontrado no index.html');
const to=html.indexOf(END,from);assert.ok(to>from,'Fim do tratador do Voltar não encontrado');
const body=html.slice(from+START.length,to);
let cases=0;
function run({open=true,mode='teacher',inner,view='home',studentPhoto=false}){
 const calls={close:0,toAssess:0,agendaBack:0};
 const frame={contentWindow:inner===undefined?{}:{handleAgendaSystemBack:inner}};
 const container={classList:{contains:n=>n==='is-open'&&open}};
 const window={APStudentPhoto:{isOpen:()=>studentPhoto,cancel(){}}};
 const document={getElementById:()=>null,body:{dataset:{view}}};
 const handler=new Function('e','a','n','t','f','h','window','document','agendaBack',body);
 const result=handler(container,mode,frame,frame,()=>{calls.toAssess++},()=>{calls.close++},window,document,()=>{calls.agendaBack++});
 return {result,calls};
}
function check(name,actual,expected){cases++;assert.deepEqual(actual,expected,name)}
// 1. The reported bug: Back on the teacher dashboard root must not close the panel (profile chooser).
let r=run({inner:()=>false});
check('painel na raiz: não fecha o painel',r.calls.close,0);
check('painel na raiz: Voltar é consumido',r.result,true);
// 2. Inner page handled it (dialog, sub-screen): same, and nothing closes.
r=run({inner:()=>true});check('subtela interna',[r.result,r.calls.close],[true,0]);
// 3. Avaliações at its root returns to the teacher panel, like the on-screen back button, never to the chooser.
r=run({mode:'assess',inner:()=>false});check('avaliações na raiz volta ao painel',[r.result,r.calls.toAssess,r.calls.close],[true,1,0]);
r=run({mode:'assess',inner:()=>true});check('avaliações subtela',[r.result,r.calls.toAssess,r.calls.close],[true,0,0]);
// 4. Page not ready (no handler): keep the escape hatch so a failed load is not a trap.
r=run({inner:undefined});check('painel sem tratador mantém a saída',[r.result,r.calls.close],[true,1]);
// 5. Inner page throws: swallow, stay.
r=run({inner:()=>{throw Error('x')}});check('erro interno',[r.result,r.calls.close],[true,0]);
// 6. Panel closed: landing/home are the only roots reported as "nothing to close"; other views go back.
r=run({open:false,view:'landing'});check('seleção inicial',[r.result,r.calls.agendaBack],[false,0]);
r=run({open:false,view:'home'});check('home do aluno',[r.result,r.calls.agendaBack],[false,0]);
r=run({open:false,view:'other'});check('outra tela',[r.result,r.calls.agendaBack],[true,1]);
console.log('Voltar do shell: '+cases+' verificações passaram; painel do professor, avaliações, página sem tratador, erro interno e raízes fechadas. Sem aparelho físico.');
