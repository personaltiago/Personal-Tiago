'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const code=f=>fs.readFileSync(path.join(__dirname,'../web',f),'utf8');
const store=new Map(),id='teacher-alpha',petKey='agenda_teacher_mascot_v1_'+id,cacheOld='agenda_teacher_mascot_portrait_v1_'+id,cacheNew='agenda_teacher_mascot_portrait_v2_'+id;
let failCache=false;
const env={window:null,localStorage:{getItem:k=>store.get(k)||null,removeItem:k=>store.delete(k),setItem:(k,v)=>{if(failCache&&k===cacheNew)throw Error('quota');store.set(k,v)}},APaccounts:{isTeacher:()=>true,teacherUid:()=>id},APprepareTeacherDocument:s=>s,APmascot:{isEnabled:()=>true},addEventListener(){},setInterval(){},document:{addEventListener(){}}};env.window=env;
vm.createContext(env);for(const f of ['student-mascot-model.js','mascot-homes.js','student-mascot-art.js','mascot-daily-message.js','teacher-mascot.js'])vm.runInContext(code(f),env);
store.set(petKey,JSON.stringify({schema:1,species:'wolf',name:'<Léo>',coins:321,xp:1800,owned:['shirt'],equipped:{body:'shirt'}}));
const original=store.get(petKey),opaque='data:image/jpeg;base64,YQ==',alpha='data:image/webp;base64,UklGRg==';
const entry={version:2,uid:id,species:'wolf',phase:'adult',photo:alpha};
const doc='<html><div id="apTeacherMascotOpen" class="home-card ap-teacher-mascot"><button><span class="ap-teacher-mascot-mark"></span><span><strong>Seu mascote</strong></span></button><button>Casa</button></div></html>';
store.set(cacheOld,JSON.stringify({...entry,version:1,photo:opaque}));assert.ok(!env.APprepareTeacherDocument(doc).includes(opaque),'legacy opaque bitmap does not flash');
for(const change of [{version:1},{uid:'another'},{phase:'baby'},{species:'panda'},{photo:opaque}]){store.set(cacheNew,JSON.stringify({...entry,...change}));assert.ok(!env.APprepareTeacherDocument(doc).includes('<image'),'invalid cache stays neutral');}
store.set(cacheNew,JSON.stringify(entry));let output=env.APprepareTeacherDocument(doc);assert.ok(output.includes(alpha),'valid transparent cache is available before image library hydration');assert.ok(output.includes('&lt;Léo&gt;'),'pet name stays escaped');assert.ok(!output.includes('<rect'),'no white loading tile');
const originalArt=env.APMascotArt;env.APMascotArt={...originalArt,portrait:()=>alpha};output=env.APprepareTeacherDocument(doc);assert.equal(JSON.parse(store.get(cacheNew)).version,4);assert.equal(store.has(cacheOld),false,'only derived old bitmap is removed');assert.equal(store.get(petKey),original,'bitmap refresh never rewrites pet progress');
failCache=true;store.delete(cacheNew);const nextAlpha=alpha+'YQ==';env.APMascotArt={...originalArt,portrait:()=>nextAlpha};output=env.APprepareTeacherDocument(doc);assert.equal(store.has(cacheNew),false);assert.ok(output.includes(nextAlpha),'cache quota does not hide the loaded pet');assert.equal(store.get(petKey),original);env.APmascot.isEnabled=()=>false;output=env.APprepareTeacherDocument(doc);assert.ok(output.includes('ap-recado-only'));assert.ok(output.includes('Recados do dia'));assert.ok(output.includes('background-image:none'));assert.ok(!output.includes('<image'));assert.ok(!output.match(/id="apTeacherMascotOpen"[^>]* hidden/));assert.equal(store.get(petKey),original);console.log('PASS: opaque cache rejected, account/species/phase guards, transparent first paint, neutral fallback, escaped name, derived-cache cleanup and pet preservation on cache quota failure.');
// Natural portraits may reuse the same species and phase, but never a different coat.
env.APmascot.isEnabled=()=>true;env.APMascotArt={...originalArt,portrait:()=>''};
const blackPet=JSON.stringify({schema:1,species:'wolf',name:'Léo',xp:1800,coins:321,colors:{wolf:'black'},owned:['hoodie'],equipped:{body:'hoodie'}});store.set(petKey,blackPet);
store.set(cacheNew,JSON.stringify(entry));assert.ok(!env.APprepareTeacherDocument(doc).includes('<image'),'legacy source cache cannot stand in for a new coat');
store.set(cacheNew,JSON.stringify({...entry,version:3,color:'white'}));assert.ok(!env.APprepareTeacherDocument(doc).includes('<image'),'different coat cache rejected');
store.set(cacheNew,JSON.stringify({...entry,version:3,color:'black'}));output=env.APprepareTeacherDocument(doc);assert.ok(output.includes(alpha)&&output.includes('data-mascot-color="black"'),'matching natural coat cached at first paint');assert.ok(!output.includes('<filter'),'no global hue filter');assert.equal(store.get(petKey),blackPet,'cache checks preserve progress and choice');
console.log('PASS: natural coat cache matches species, phase and selected design; incompatible legacy/different-coat caches rejected without changing saved state.');

const posedPet=JSON.stringify({...JSON.parse(blackPet),poses:{wolf:'play'},owned:['hoodie','pose-wolf-play']});store.set(petKey,posedPet);
for(const change of [{version:3,color:'black'},{version:4,color:'black',pose:'default'},{version:4,color:'black',pose:'sit'}]){store.set(cacheNew,JSON.stringify({...entry,...change}));assert.ok(!env.APprepareTeacherDocument(doc).includes('<image'),'different or legacy pose cache rejected')}
store.set(cacheNew,JSON.stringify({...entry,version:4,color:'black',pose:'play'}));output=env.APprepareTeacherDocument(doc);assert.ok(output.includes(alpha)&&output.includes('data-mascot-pose="play"'),'matching pose cached at first paint');assert.equal(store.get(petKey),posedPet);
console.log('PASS: selected-pose cache guard prevents previous poses from flashing and preserves saved purchases.');
