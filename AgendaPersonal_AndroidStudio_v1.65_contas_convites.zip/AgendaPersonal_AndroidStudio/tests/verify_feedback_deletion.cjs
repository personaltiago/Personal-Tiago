'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const {chromium}=require('playwright'),{server,init,fixture}=require('./verify_bisets.cjs');
const root=path.resolve(__dirname,'..'),checks=[],layouts=[];
function modelTests(){
 const sandbox={};vm.runInNewContext(fs.readFileSync(path.join(root,'web/teacher-sync-model.js'),'utf8'),sandbox);const M=sandbox.APTeacherSyncModel;
 const a={id:'fb_A',response:{comment:'Conteúdo privado A'}},b={id:'fb_B',response:{comment:'Conteúdo privado B'}};
 const base={agenda:{students:[{id:'s',name:'Aluno'}],workoutFeedbackRequests:[a,b],workoutExecutions:[{id:'w'}]},assessments:{clients:[]}};
 const local=structuredClone(base);local.agenda.workoutFeedbackRequests=[b];local.agenda.workoutFeedbackDeleted={fb_A:true};
 const remote=structuredClone(base);remote.agenda.workoutFeedbackRequests[0].seenAt='2026-10-22';remote.agenda.workoutFeedbackDeleted={fb_B:true};
 for(const mode of ['', 'local','remote']){
  const result=M.merge(base,local,remote,mode);assert.equal(result.conflicts.length,0);assert.equal(result.data.agenda.workoutFeedbackRequests.length,0);assert.equal(result.data.agenda.workoutFeedbackDeleted.fb_A,true);assert.equal(result.data.agenda.workoutFeedbackDeleted.fb_B,true);assert.equal(result.data.agenda.workoutExecutions.length,1);
 }
 const merged=M.merge(undefined,local,base);assert.equal(merged.data.agenda.workoutFeedbackRequests.some(r=>r.id==='fb_A'),false);
 const snapshot=M.snapshot({...base.agenda,workoutFeedbackDeleted:{fb_A:true}});assert.equal(snapshot.agenda.workoutFeedbackRequests.length,1);assert.equal(JSON.stringify(snapshot).includes('Conteúdo privado A'),false);
 const again=M.merge(snapshot,base,snapshot);assert.equal(again.data.agenda.workoutFeedbackRequests.some(r=>r.id==='fb_A'),false);
 assert.equal(JSON.stringify(base).includes('Conteúdo privado A'),true,'model never mutates callers');
 checks.push('Sincronização reúne exclusões de dois aparelhos e impede que cópia antiga ou alteração concorrente restaure o conteúdo');
}
function feedback(id,day,response=true,source='online'){
 const start=Date.parse('2026-10-20T18:00:00Z');return {id,uid:'alice',studentId:'s',studentName:'Aluna de teste',professorId:'R2EmnDVcvMWt7TjPxOP6DjW1VOn1',source,planName:'Ficha de teste',dayName:day,startedAt:start,finishedAt:start+3600000,durationSeconds:3600,status:'sent',seenAt:null,teacherEvaluation:null,response:response?{intensity:'Intensa',comment:('Comentário '+id+' com execução controlada. ').repeat(35),publicationBasis:'contract',mutationId:'m_'+id,receivedAt:'2026-10-21T12:00:00Z'}:null};
}
async function main(){
 modelTests();await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});const errors=[];
 try{
  const data=structuredClone(fixture);data.students[0].name='Aluna de teste';data.students[0].firebaseUid='alice';data.workoutExecutions=[{id:'keep-history',studentId:'s',note:'Histórico deve permanecer'}];
  data.workoutFeedbackRequests=[feedback('fb_A','Treino A'),feedback('fb_B','Treino B',true,'presencial'),feedback('fb_C','Treino C'),feedback('fb_W','Pedido pendente',false,'presencial')];
  const incoming=structuredClone(data.workoutFeedbackRequests),ctx=await browser.newContext({viewport:{width:393,height:852},isMobile:true,hasTouch:true,timezoneId:'America/Cuiaba'});await init(ctx,data);
  await ctx.addInitScript(({incoming})=>{
   window.APaccounts={isTeacher:()=>window.__teacher!==false,teacherUid:()=> 'R2EmnDVcvMWt7TjPxOP6DjW1VOn1',getPhotoToken:async()=>''};
   window.__incoming=incoming;window.__syncCalls=0;window.APTeacherSync={changed:()=>{window.__syncCalls++}};
   window.APFeedbackSync={inbox:async()=>{const items=structuredClone(window.__incoming);if(window.__holdInbox)await new Promise(resolve=>window.__releaseInbox=resolve);return items},create:async()=>{throw Error('Unexpected request')}};
  },{incoming});
  const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));
  async function ready(){await page.waitForFunction(()=>window.__ready&&window.APFeedbackTeacher);await page.evaluate(()=>APFullBackup.ready);await page.evaluate(()=>{AgendaColors.selectDesign('deep-tl');AgendaColors.save({...AgendaColors.get(),id:'custom',primary:'#b7f522'});showScreen('students-presencial');APFeedbackTeacher.open()});await page.waitForFunction(()=>!document.getElementById('apFeedbackTeacherRefresh').disabled)}
  await page.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await ready();
  const stored=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')));
  const pristine=await stored(),bytesBefore=Buffer.byteLength(JSON.stringify(pristine));
  const one=id=>page.locator('[data-feedback-id="'+id+'"] [data-feedback-action="delete"]');
  await one('fb_A').click();assert.equal(await page.locator('#apFeedbackDelete').evaluate(d=>d.open),true);assert.equal(await page.locator('#apFeedbackDeleteCancel').evaluate(n=>n===document.activeElement),true);await page.locator('#apFeedbackDeleteCancel').click();assert.deepEqual(await stored(),pristine);
  await one('fb_A').click();await page.evaluate(()=>window.__failSave=true);await page.locator('#apFeedbackDeleteConfirm').click();assert.match(await page.locator('#apFeedbackDeleteStatus').innerText(),/Nenhum feedback foi apagado/);assert.equal((await stored()).workoutFeedbackRequests.length,4);await page.evaluate(()=>window.__failSave=false);await page.locator('#apFeedbackDeleteConfirm').click();
  let current=await stored();assert.equal(current.workoutFeedbackRequests.some(r=>r.id==='fb_A'),false);assert.equal(current.workoutFeedbackDeleted.fb_A,true);assert.ok(Buffer.byteLength(JSON.stringify(current))<bytesBefore-500);assert.equal(await page.locator('#apFeedbackTeacherCount').innerText(),'2 novos');
  assert.deepEqual(current.students,pristine.students);assert.deepEqual(current.workoutPlans,pristine.workoutPlans);assert.deepEqual(current.workoutExecutions,pristine.workoutExecutions);
  await page.evaluate(()=>APFeedbackTeacher.refresh());assert.equal(await page.locator('[data-feedback-id="fb_A"]').count(),0);await page.reload();await ready();assert.equal(await page.locator('[data-feedback-id="fb_A"]').count(),0);assert.equal((await stored()).workoutFeedbackRequests.some(r=>r.id==='fb_A'),false);
  checks.push('Cancelar preserva os dados; falha de armazenamento não apaga; exclusão confirmada reduz bytes, atualiza contador e persiste após atualização e reabertura');
  // A response already in flight must not restore a just-deleted feedback.
  await page.evaluate(()=>{window.__holdInbox=true;APFeedbackTeacher.refresh()});await page.waitForFunction(()=>typeof __releaseInbox==='function');await one('fb_B').click();await page.locator('#apFeedbackDeleteConfirm').click();await page.evaluate(()=>{window.__holdInbox=false;__releaseInbox()});await page.waitForFunction(()=>!document.getElementById('apFeedbackTeacherRefresh').disabled);assert.equal((await stored()).workoutFeedbackRequests.some(r=>r.id==='fb_B'),false);
  checks.push('Resposta recebida durante a exclusão não recoloca o feedback na lista');
  await page.locator('#apFeedbackTeacherSelect').click();await page.locator('#apFeedbackSelectAll').check();assert.equal(await page.locator('#apFeedbackSelectionCount').innerText(),'1 selecionado');await page.locator('[data-feedback-filter="waiting"]').click();assert.equal(await page.locator('#apFeedbackDeleteSelected').isDisabled(),true);await page.locator('[data-feedback-filter="received"]').click();await page.locator('#apFeedbackTeacherSearch').fill('Treino C');await page.locator('#apFeedbackSelectAll').check();await page.locator('#apFeedbackDeleteSelected').click();
  const newItem=feedback('fb_D','Treino D');await page.evaluate(async row=>{window.__incoming.push(row);await APFeedbackTeacher.refresh()},newItem);await page.locator('#apFeedbackDeleteConfirm').click();current=await stored();assert.equal(current.workoutFeedbackRequests.some(r=>r.id==='fb_C'),false);assert.equal(current.workoutFeedbackRequests.some(r=>r.id==='fb_D'),true);assert.equal(current.workoutFeedbackRequests.some(r=>r.id==='fb_W'),true);
  checks.push('Seleção respeita busca e filtro; trocar filtro limpa seleção; novos feedbacks recebidos após abrir a confirmação são preservados');
  await page.locator('#apFeedbackTeacherSearch').fill('');await page.locator('#apFeedbackTeacherSelect').click();
  await page.locator('[data-feedback-filter="waiting"]').click();await one('fb_W').click();assert.equal(await page.locator('#apFeedbackDeletePending').isVisible(),true);await page.evaluate(()=>handleAgendaSystemBack());assert.equal(await page.locator('#apFeedbackDelete').evaluate(n=>n.open),false);assert.equal(await page.locator('#apFeedbackTeacher').evaluate(n=>n.open),true);
  await one('fb_W').click();const beforeAccount=await stored();await page.evaluate(()=>{window.__teacher=false;dispatchEvent(new Event('ap-account-changed'))});assert.equal(await page.locator('#apFeedbackDelete').evaluate(n=>n.open),false);assert.equal(await page.locator('#apFeedbackTeacher').evaluate(n=>n.open),false);assert.deepEqual(await stored(),beforeAccount);await page.evaluate(()=>{window.__teacher=true;dispatchEvent(new Event('ap-account-changed'));APFeedbackTeacher.open()});await page.waitForFunction(()=>!document.getElementById('apFeedbackTeacherRefresh').disabled);
  checks.push('Voltar cancela a confirmação; sair da conta fecha exclusão e preserva os registros');
  await page.locator('[data-feedback-filter="received"]').click();await page.locator('[data-feedback-id="fb_D"] [data-feedback-action="image"]').click();await page.locator('#apFeedbackImage canvas').waitFor();await page.locator('#apFeedbackImage header button').click();await page.waitForFunction(()=>!document.querySelector('#apFeedbackImage canvas'));assert.equal(await page.locator('#apFeedbackImage [data-save-feedback]').evaluate(n=>n.onclick),null);
  checks.push('Fechar a prévia libera o canvas e as referências à imagem, em vez de mantê-las na janela escondida');
  for(const [width,font]of [[280,16],[320,20],[393,16],[640,16]]){
   await page.setViewportSize({width,height:852});await page.evaluate(font=>document.documentElement.style.fontSize=font+'px',font);
   for(const mode of ['list','selection','confirm']){
    if(mode==='selection')await page.locator('#apFeedbackTeacherSelect').click();if(mode==='confirm'){await page.locator('#apFeedbackSelectAll').check();await page.locator('#apFeedbackDeleteSelected').click()}
    const layout=await page.evaluate(()=>{const d=document.getElementById('apFeedbackDelete').open?document.getElementById('apFeedbackDelete'):document.getElementById('apFeedbackTeacher');return {overflow:d.scrollWidth>d.clientWidth+1,small:[...d.querySelectorAll('button')].filter(b=>{const r=b.getBoundingClientRect();return r.width&&r.height&&r.height<43}).map(b=>b.id)}});assert.equal(layout.overflow,false,width+'/'+font+'/'+mode);assert.deepEqual(layout.small,[]);layouts.push({width,font,mode,...layout});
    if(mode==='confirm')await page.locator('#apFeedbackDeleteCancel').click();
   }
   await page.locator('#apFeedbackTeacherSelect').click();
  }
  await page.setViewportSize({width:393,height:852});await page.evaluate(()=>{document.documentElement.style.fontSize='16px';document.getElementById('apFeedbackTeacher').scrollTop=0});await page.screenshot({path:path.resolve(root,'../../feedback-delete-list.png')});
  await one('fb_D').click();await page.screenshot({path:path.resolve(root,'../../feedback-delete-confirm.png')});await page.locator('#apFeedbackDeleteCancel').click();
  await page.locator('[data-feedback-filter="all"]').click();await page.locator('#apFeedbackTeacherSelect').click();await page.locator('#apFeedbackSelectAll').check();await page.locator('#apFeedbackDeleteSelected').click();assert.equal(await page.locator('#apFeedbackDeleteTitle').innerText(),'Apagar 2 feedbacks?');await page.locator('#apFeedbackDeleteConfirm').click();await page.evaluate(()=>APFeedbackTeacher.refresh());assert.equal(await page.locator('#apFeedbackTeacherList .ap-feedback-card').count(),0);assert.equal(await page.locator('#apFeedbackTeacherCount').innerText(),'0 novos');checks.push('Exclusão em lote remove apenas os dois itens confirmados e mantém a lista vazia ao sincronizar novamente');
  current=await stored();assert.deepEqual(current.workoutExecutions,pristine.workoutExecutions);assert.deepEqual(current.workoutPlans,pristine.workoutPlans);assert.deepEqual(current.students,pristine.students);assert.ok(await page.evaluate(()=>__syncCalls)>0);assert.deepEqual(errors,[]);
  const report={passed:true,checks,layouts,errors,storage:{beforeBytes:bytesBefore,afterBytes:Buffer.byteLength(JSON.stringify(current)),removedFeedbacks:Object.keys(current.workoutFeedbackDeleted).length,remainingFeedbacks:current.workoutFeedbackRequests.length},scope:'Exclusão da caixa de feedbacks do professor. Guarda apenas IDs para impedir reimportação; histórico de treino, conta do aluno, fotos de perfil e arquivos exportados permanecem. Sincronização de agenda é simulada no navegador; união de exclusões usa o modelo real.',physicalDeviceTest:false};fs.writeFileSync(path.join(root,'VERIFICACAO_EXCLUSAO_FEEDBACK.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await ctx.close();
 }finally{await browser.close();server.close()}
}
main().catch(e=>{console.error(e);process.exitCode=1;server.close()});
