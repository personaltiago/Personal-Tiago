'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const map=new Map(),events={},nodes=new Map(),teacher='R2EmnDVcvMWt7TjPxOP6DjW1VOn1';let mode='student',calls=[],reply=null,offline=false,applied=[];
function node(id){if(!nodes.has(id))nodes.set(id,{hidden:true,textContent:'',contentWindow:{APstudentPhotoTargets:()=>[{uid:'alice',revision:''}],APapplyStudentPhotos:r=>{applied.push(r);return true},APstudentPhotoSyncNotice(){}}});return nodes.get(id)}
const ctx={console,crypto,TextEncoder,Uint8Array,AbortSignal,Date,Math,JSON,Promise,Image:class{set src(v){queueMicrotask(()=>this.onload())}},navigator:{get onLine(){return !offline}},localStorage:{getItem:k=>map.get(k)||null,setItem:(k,v)=>map.set(k,v)},__AP_STUDENT_CONTEXT:{role:'student',storageId:'alice'},APstudentStorage:{getItem:()=>null},profilePhotoKey:()=> 'photo',APaccounts:{isTeacher:()=>mode==='teacher',getPhotoToken:async()=>mode==='teacher'?'teacher-token':'alice-token'},setInterval(){},addEventListener:(n,f)=>(events[n]??=[]).push(f),document:{hidden:false,addEventListener(){},getElementById:node,createElement:()=>({getContext:()=>({fillRect(){},drawImage(){}}),toDataURL:()=> 'small-jpeg'})},fetch:async(url,opt)=>{calls.push({url,data:JSON.parse(opt.body),token:opt.headers.Authorization});if(reply)return reply(url,opt);const data=JSON.parse(opt.body);return {ok:true,json:async()=>url.endsWith('student-photos')?{photos:[{uid:'alice',photo:'small-jpeg',revision:'r'}]}:{saved:true,revision:data.mutationId}}}};
ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.resolve(__dirname,'../web/photo-sync.js'),'utf8'),ctx);
const job=uid=>JSON.parse(map.get('agenda_student_photo_sync_v1_'+uid)||'null'),tick=()=>new Promise(r=>setImmediate(r));
async function run(){
 offline=true;await ctx.APPhotoSync.changed('full-local-photo');assert.equal(job('alice').pending,true);assert.equal(job('alice').photo,'small-jpeg');assert.equal(calls.length,0);assert.ok(!JSON.stringify([...map]).includes('alice-token'));
 offline=false;await ctx.APPhotoSync.pump();assert.equal(job('alice').pending,false);assert.equal(calls[0].token,'Bearer alice-token');assert.equal(calls[0].data.uid,undefined);
 reply=async()=>{throw Error('network')};await ctx.APPhotoSync.changed('second-photo');await tick();assert.equal(job('alice').pending,true);
 reply=null;await ctx.APPhotoSync.pump();assert.equal(job('alice').pending,false);
 let finish;reply=async(url,opt)=>new Promise(resolve=>finish=()=>resolve({ok:true,json:async()=>({saved:true,revision:JSON.parse(opt.body).mutationId})}));
 await ctx.APPhotoSync.changed('third-photo');await tick();assert.ok(finish);const pending=job('alice').mutationId;
 ctx.__AP_STUDENT_CONTEXT={role:'student',storageId:'bob'};for(const fn of events['ap-account-changed'])fn();finish();await tick();assert.equal(job('alice').mutationId,pending);assert.equal(job('alice').pending,true);assert.equal(job('bob'),null);
 reply=null;mode='teacher';ctx.__AP_STUDENT_CONTEXT=null;await ctx.APPhotoSync.receive();assert.equal(applied.length,1);assert.equal(calls.at(-1).token,'Bearer teacher-token');assert.equal(calls.at(-1).data.students[0].uid,'alice');
 const state={students:[{id:'a',firebaseUid:'alice',name:'Aluno A',photoDataUrl:'old'},{id:'b',firebaseUid:'bob',name:'Aluno A',photoDataUrl:'keep'}]};let fail=false,saves=0;
 const target={window:{parent:{APaccounts:{isTeacher:()=>true}}},state,document:{getElementById:()=>null},currentProfileStudentId:'',save(){if(fail)throw Error('quota');saves++},renderStudents(){}};
 vm.createContext(target);vm.runInContext(fs.readFileSync(path.resolve(__dirname,'../web/teacher-photo-sync.js'),'utf8'),target);
 const photo='data:image/jpeg;base64,/9j/2Q==',record={uid:'alice',photo,revision:'r1',updatedAt:'now'};
 assert.equal(target.window.APapplyStudentPhotos([record]),true);assert.equal(state.students[0].photoDataUrl,photo);assert.equal(state.students[1].photoDataUrl,'keep');assert.equal(saves,1);
 target.window.APapplyStudentPhotos([record]);assert.equal(saves,1);fail=true;assert.equal(target.window.APapplyStudentPhotos([{...record,photo:'',revision:'r2'}]),false);assert.equal(state.students[0].photoDataUrl,photo);assert.equal(state.students[0].photoRemoteRevision,'r1');
 fail=false;assert.equal(target.window.APapplyStudentPhotos([{...record,photo:'',revision:'r2'}]),true);assert.equal(state.students[0].photoDataUrl,'');
 target.window.parent.APaccounts.isTeacher=()=>false;assert.equal(target.window.APapplyStudentPhotos([record]),false);
 console.log('PASS: offline outbox, confirmed acknowledgement, network retry, no persisted tokens, account-change isolation, teacher batch reception, UID-only matching, duplicate suppression, persisted teacher avatar and rollback on quota. Network/DOM/Firebase simulated.');
}
run().catch(e=>{console.error(e);process.exitCode=1});
