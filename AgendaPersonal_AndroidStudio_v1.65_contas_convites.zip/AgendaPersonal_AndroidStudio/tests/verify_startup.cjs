'use strict';
// Real shipped scripts; Firebase, DOM and time are simulated, never a real account.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {createHarness}=require('./verify_shell_boot.cjs'),tick=()=>new Promise(r=>setImmediate(r));
const TEACHER='R2EmnDVcvMWt7TjPxOP6DjW1VOn1',saved=JSON.stringify({students:[{id:'preserved',name:'Aluno preservado'}],lessons:[]});
function start(user,profile,{fail=false,hang=false,setup=false,publicLink=false}={}){
 let release,clock=0,reloads=0,mounted=[];const timers=new Map(),wait=new Promise(r=>release=r),auth={currentUser:user,authStateReady:()=>wait};
 const sdk={getApps:()=>[],initializeApp:()=>({}),getAuth:()=>auth,getFirestore:()=>({}),
  onAuthStateChanged(a,fn){queueMicrotask(()=>fn(a.currentUser));return ()=>{}},
  doc:(db,...p)=>p.join('/'),getDoc:async()=>({exists:()=>!!profile,data:()=>profile}),onSnapshot:()=>()=>{},
  signInWithEmailAndPassword:async()=>{throw {code:'auth/invalid-credential'}},signOut:async()=>{auth.currentUser=null}};
 const harness=createHarness({bootstrap({ctx,element,storage}){
  if(publicLink)ctx.location.href+='?cadastro=1';storage.set('agendaPersonalTL_v1',saved);if(!setup)storage.set('ap_professor_marca_159_professor_teste',JSON.stringify({completed:true,name:'Professor',description:'Personal Trainer',main:'#A12CFF',support:'#08070C',bg:'#08070C',design:'atual'}));
  ctx.__startupImport=()=>fail?Promise.reject(Error('SDK unavailable')):hang?new Promise(()=>{}):Promise.resolve(sdk);
  ctx.setTimeout=(fn,ms)=>{timers.set(++clock,{fn,ms});return clock};ctx.clearTimeout=id=>timers.delete(id);
  ctx.document.readyState='complete';ctx.location.reload=()=>reloads++;
  const create=ctx.document.createElement;ctx.document.createElement=tag=>{if(tag!=='section')return create(tag);const n=element('startup-'+clock),p={},button={};n.querySelector=s=>s==='p'?p:button;n.remove=()=>mounted=mounted.filter(x=>x!==n);return n};ctx.document.body.appendChild=n=>mounted.push(n);
 }});
 return {...harness,release,timers,mounted:()=>mounted,reloads:()=>reloads,pending:()=>harness.ctx.document.documentElement.hasAttribute('data-ap-startup')};
}
async function main(){
 let h=start({uid:TEACHER,email:'teacher@example.test'});await tick();assert.ok(h.pending());assert.equal(h.mounted().length,1);assert.equal(h.storage.get('agendaPersonalTL_v1'),saved);
 h.release();await tick();await tick();assert.equal(h.ctx.APaccounts.isTeacher(),true);assert.ok(h.element('apPreviewTeacher').srcdoc.includes("const DB_KEY='agendaPersonalTL_v1';"));assert.ok(h.pending(),'wait for actual teacher frame readiness');
 h.element('apPreviewTeacher').contentWindow={openRegistrationLink(){}};await h.element('apPreviewTeacher').fire('load');assert.equal(h.pending(),false);assert.equal(h.mounted().length,0);
 h=start(null);await tick();assert.ok(h.pending());h.release();await tick();assert.equal(h.pending(),false,'confirmed signed-out session can see roles');
 h=start({uid:TEACHER},null,{setup:true});h.release();await tick();assert.equal(h.element('apTeacherSetup').hidden,false);assert.equal(h.pending(),false);
 h=start({uid:'student_approved'},{perfil:'aluno',professorId:TEACHER,ativo:true,nome:'Aluna'});h.release();await tick();assert.equal(h.ctx.__AP_STUDENT_CONTEXT.storageId,'student_approved');assert.equal(h.pending(),false);
 h=start({uid:'student_pending'},{perfil:'aluno',professorId:TEACHER,ativo:false,nome:'Aluna'});h.release();await tick();assert.equal(h.ctx.__AP_STUDENT_CONTEXT,null);assert.match(h.element('apAccountStatus').textContent,/aprovação/);assert.equal(h.pending(),false);
 h=start(null,null,{fail:true});await tick();assert.ok(h.pending());assert.equal(h.mounted()[0].querySelector('button').hidden,false);assert.match(h.mounted()[0].querySelector('p').textContent,/conexão/);h.mounted()[0].querySelector('button').onclick();assert.equal(h.reloads(),1);
 h=start(null,null,{hang:true});await tick();const timeout=[...h.timers.values()].find(x=>x.ms===20000);assert.ok(timeout);timeout.fn();assert.equal(h.mounted()[0].querySelector('button').hidden,false);assert.match(h.mounted()[0].querySelector('p').textContent,/demorando/);
 h=start(null);h.release();await tick();h.ctx.showLogin('Professor');h.element('email').value='teacher@example.test';h.element('password').value='incorrect';await h.element('form').fire('submit',{preventDefault(){},stopImmediatePropagation(){}});assert.equal(h.pending(),false);assert.equal(h.ctx.document.body.dataset.view,'login');assert.match(h.element('apAccountStatus').textContent,/incorretos/);assert.equal(h.storage.get('agendaPersonalTL_v1'),saved);
 h=start(null,null,{publicLink:true,hang:true});await tick();assert.equal(h.pending(),false,'public registration does not wait for login');assert.equal(h.storage.get('agendaPersonalTL_v1'),saved);
 assert.ok(h.html.indexOf('id="ap-startup"')<h.html.indexOf('<body'));
 const root=path.resolve(__dirname,'..'),manifest=fs.readFileSync(path.join(root,'app/src/main/AndroidManifest.xml'),'utf8');assert.match(manifest,/<activity[^>]*android:name="\.MainActivity"[^>]*android:theme="@style\/Theme.AgendaPersonal"/);
 for(const dir of ['values','values-v31']){const theme=fs.readFileSync(path.join(root,'app/src/main/res',dir,'styles.xml'),'utf8');assert.match(theme,/name="android:windowBackground">#09080C/);if(dir==='values-v31')assert.match(theme,/name="android:windowSplashScreenBackground">#09080C/)}
 console.log('PASS: delayed restored teacher session covered until frame load; signed-out roles, public registration, first teacher setup, approved/rejected students, SDK failure/timeout/retry, invalid login, data preservation and dark Android launch resources. DOM/Firebase simulated; not device rendering.');
}
main().catch(e=>{console.error(e);process.exitCode=1});
