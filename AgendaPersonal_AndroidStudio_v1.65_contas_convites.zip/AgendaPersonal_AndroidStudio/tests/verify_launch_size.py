"""Check that all three launch stages use the same logo geometry and artwork."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
a = '{http://schemas.android.com/apk/res/android}'
resources = root / 'app/src/main/res'
dimensions = ET.parse(resources / 'values/launch_dimensions.xml').getroot()
size = float(next(e.text for e in dimensions if e.get('name') == 'launch_logo_size').removesuffix('dp'))
assert size == 112
for path in ['drawable/launch_background.xml', 'drawable/launch_splash_icon.xml']:
    tree = ET.parse(resources / path).getroot()
    logo = next(e for e in tree if e.get(a + 'drawable') == '@drawable/launch_logo')
    assert logo.get(a + 'width') == logo.get(a + 'height') == '@dimen/launch_logo_size'
    assert logo.get(a + 'gravity') == 'center'
    if 'splash' in path:
        assert next(iter(tree)).get(a + 'width') == next(iter(tree)).get(a + 'height') == '288dp'
        assert size * 2 ** .5 < 192, 'logo must fit within the Android 12 splash mask'
theme = ET.parse(resources / 'values-v31/styles.xml').getroot()
assert any(e.get('name') == 'android:windowSplashScreenAnimatedIcon' and e.text == '@drawable/launch_splash_icon' for e in theme.iter('item'))
source = (root / 'app/src/main/java/com/tiagolima/agendapersonal/MainActivity.java').read_text()
assert 'bootLogo.setImageResource(R.drawable.launch_logo)' in source
assert 'getDimensionPixelSize(R.dimen.launch_logo_size)' in source
assert 'if (Build.VERSION.SDK_INT >= 31)' in source
assert 'setOnExitAnimationListener(android.window.SplashScreenView::remove)' in source
assert (resources / 'drawable-nodpi/launch_logo.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
print('PASS: fixed 112dp logo across native and system loaders, Android 12 mask, API guard, unchanged launcher icon.')
