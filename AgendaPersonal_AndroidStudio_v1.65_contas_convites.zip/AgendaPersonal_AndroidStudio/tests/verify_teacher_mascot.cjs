'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const {chromium}=require('playwright'),assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';if(!['index.html','professor.html','cadastro.html','avaliacoes.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.failTeacherMascot&&k.startsWith('agenda_teacher_mascot_v1_'))throw Error('quota');return set.call(this,k,v)}});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  async function boot(uid='teacher_alice'){
   await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>window.APmascot&&window.APaccounts);
   await page.evaluate(async uid=>{window.testTeacherUid=uid;window.testIsTeacher=true;window.APaccounts={isTeacher:()=>testIsTeacher,teacherUid:()=>testTeacherUid};window.__AP_STUDENT_CONTEXT=null;document.getElementById('apPreviewOverlay').classList.add('is-open');document.getElementById('apPreviewTeacher').srcdoc=await (await fetch('professor.html')).text()},uid);
   await page.frameLocator('#apPreviewTeacher').locator('#apTeacherMascotOpen').waitFor();
  }
  await boot();const frame=page.frameLocator('#apPreviewTeacher');const originalBusiness=await frame.locator('body').evaluate(()=>localStorage.getItem('agendaPersonalTL_v1'));
  await frame.locator('#apTeacherMascotOpen').click();await page.locator('#apMascotTeacherTools').waitFor();
  assert.equal(await page.locator('#apMascotPreview').isVisible(),false);assert.equal(await page.locator('#apMascotHome').isVisible(),false);
  assert.ok(await page.locator('#apMascot').evaluate(n=>document.elementFromPoint(innerWidth/2,innerHeight/2)?.closest('#apMascot')===n),'modal is above the teacher iframe');
  await page.locator('#apMascotChoices [data-mascot-item="alligator"]').click();await page.waitForFunction(()=>APMascotArt.ready());assert.equal(await frame.locator('.ap-teacher-mascot-mark image').getAttribute('data-mascot-photo'),'alligator');await page.locator('[data-mascot-action="test-workout"]').click();await page.locator('[data-mascot-action="test-workout"]').click();
  assert.equal(await page.evaluate(()=>APmascot.state().coins),200);assert.equal(await page.evaluate(()=>APmascot.state().xp),200);
  await page.locator('#apMascotTab-shop').click();await page.locator('[data-mascot-action="buy"][data-mascot-item="shirt"]').click();await page.locator('#apMascotTab-clothes').click();await page.locator('[data-mascot-action="use"][data-mascot-item="shirt"]').click();assert.equal(await page.evaluate(()=>APmascot.state().equipped.body),'shirt');
  for(const phase of ['baby','teen','adult'])for(const width of [320,390,480])for(const mode of ['light','dark']){
   await page.setViewportSize({width,height:844});await frame.locator('body').evaluate((_,mode)=>AgendaAppearance.setMode(mode),mode);await page.locator('[data-mascot-action="test-phase"][data-mascot-item="'+phase+'"]').click();
   assert.equal(await page.locator('#apMascotArt image').getAttribute('data-mascot-photo-phase'),phase);
   assert.ok(await page.locator('.ap-mascot-sheet').evaluate(n=>n.scrollWidth<=n.clientWidth+1));assert.equal(await page.locator('#apMascot').evaluate(n=>n.classList.contains('ap-mascot-light')),mode==='light');
  }
  assert.equal(await page.evaluate(()=>APmascot.state().coins),20);assert.equal(await page.evaluate(()=>APmascot.state().equipped.body),'shirt');
  const before=await page.evaluate(()=>localStorage.getItem('agenda_teacher_mascot_v1_teacher_alice'));await page.evaluate(()=>window.failTeacherMascot=true);await page.locator('[data-mascot-action="test-workout"]').click();assert.equal(await page.evaluate(()=>localStorage.getItem('agenda_teacher_mascot_v1_teacher_alice')),before);assert.match(await page.locator('#apMascotStatus').textContent(),/não foram alterados/);await page.evaluate(()=>window.failTeacherMascot=false);
  await page.evaluate(()=>handleAgendaSystemBack());assert.equal(await page.locator('#apMascot').isVisible(),false);assert.equal(await page.locator('#apPreviewOverlay').evaluate(n=>n.classList.contains('is-open')),true);
  await frame.locator('#apTeacherMascotOpen').click();assert.equal(await page.evaluate(()=>APmascot.state().coins),20);await page.keyboard.press('Escape');
  await page.evaluate(()=>window.dispatchEvent(new MessageEvent('message',{data:{kind:'AP_OPEN_TEACHER_MASCOT'},source:window})));assert.equal(await page.locator('#apMascot').isVisible(),false,'foreign message cannot open');
  assert.equal(await frame.locator('body').evaluate(()=>localStorage.getItem('agendaPersonalTL_v1')),originalBusiness,'student/business records unchanged');
  await boot('teacher_bob');await frame.locator('#apTeacherMascotOpen').click();assert.equal(await page.evaluate(()=>APmascot.state().coins),0);assert.equal(await page.evaluate(()=>APmascot.state().species),'');await page.evaluate(()=>{window.testIsTeacher=false;window.dispatchEvent(new Event('ap-account-changed'))});assert.equal(await page.locator('#apMascot').isVisible(),false);assert.equal(await page.evaluate(()=>APteacherMascot.open()),false);
  await boot();await frame.locator('#apTeacherMascotOpen').click();assert.equal(await page.evaluate(()=>APmascot.state().coins),20);assert.equal(await page.evaluate(()=>APmascot.state().species),'alligator');
  for(const species of ['capybara','kitten','wolf','alligator']){await page.locator('#apMascotChoiceTitle').click();await page.locator('#apMascotChoices [data-mascot-item="'+species+'"]').click();assert.equal(await page.evaluate(()=>APmascot.state().species),species);assert.equal(await page.evaluate(()=>APmascot.state().coins),20);assert.equal(await page.evaluate(()=>APmascot.state().equipped.body),'shirt')}
  if(process.env.AGENDA_REVIEW_DIR){fs.mkdirSync(process.env.AGENDA_REVIEW_DIR,{recursive:true});await page.setViewportSize({width:390,height:1000});await page.locator('[data-mascot-action="test-phase"][data-mascot-item="teen"]').click();await page.locator('.ap-mascot-sheet').evaluate(n=>n.scrollTop=0);await page.screenshot({path:path.join(process.env.AGENDA_REVIEW_DIR,'mascote-professor.png')});await page.keyboard.press('Escape');await page.screenshot({path:path.join(process.env.AGENDA_REVIEW_DIR,'inicio-professor.png')})}
  await page.evaluate(()=>{window.__AP_STUDENT_CONTEXT={storageId:'student',role:'student',area:{enabled:true}}});assert.equal(await page.evaluate(()=>APteacherMascot.open()),false,'student context cannot use teacher sandbox');await page.evaluate(()=>APmascot.open());assert.equal(await page.locator('#apMascotTeacherTools').isVisible(),false);
  assert.deepEqual(errors,[]);console.log('PASS: teacher card opens internal modal above iframe; real shop/equipment; simulation and three phases; 18 mobile/theme layouts; quota rollback; Back/Escape; restart; account isolation; student data preserved; sandbox hidden for students; forged message rejected. Authentication/network simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
