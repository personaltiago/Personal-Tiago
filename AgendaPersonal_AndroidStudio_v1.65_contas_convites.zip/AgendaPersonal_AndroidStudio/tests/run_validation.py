#!/usr/bin/env python3
"""Verifica os testes que o ambiente permite, sem confundir infraestrutura ausente com bug.

Uso:
  python3 tests/run_validation.py          # Testes estáticos + Java com mocks
  python3 tests/run_validation.py --browser # Inclui Playwright (requer npm install; npx playwright install chromium)

Um teste nunca é considerado APROVADO por ter sido pulado.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / 'tests'
BROWSER_CJS = {
    'verify_bisets.cjs', 'verify_catalog_import.cjs', 'verify_finance_archive.cjs',
    'verify_home_assessments.cjs', 'verify_lesson_alarm_controls.cjs',
    'verify_pdf_instruction_priority.cjs', 'verify_pdf_numbered.cjs',
    'verify_publish_progress_browser.cjs', 'verify_registration_link_editor.cjs',
    'verify_reordering.cjs', 'verify_series.cjs', 'verify_sound_preview.cjs',
    'verify_student_archive.cjs', 'verify_student_billing.cjs',
    'verify_student_identity_browser.cjs', 'verify_student_inline_video.cjs',
    'verify_student_notifications.cjs', 'verify_student_videos.cjs',
    'verify_teacher_appearance.cjs', 'verify_teacher_setup_appearance.cjs',
    'verify_technique_flow.cjs', 'verify_techniques.cjs', 'verify_trainer_profile.cjs',
    'verify_video_controls.cjs', 'verify_workout_features.cjs',
    'verify_workout_organization.cjs', 'verify_workout_pdf_review.cjs',
    'verify_workout_video_gallery.cjs', 'verify_workouts.cjs', 'verify_youtube.cjs',
}
BROWSER_PY = {'verify_stop_without_evolution.py'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--browser', action='store_true', help='executar também todos os testes Playwright')
    parser.add_argument('--android-jar', type=Path, help='android.jar para teste opcional de compilação nativa')
    parser.add_argument('--androidx-jar', type=Path, help='androidx.core.jar para compilação nativa')
    parser.add_argument('--release-bundle', type=Path, help='JSON distribuído a validar com o serviço de distribuição')
    parser.add_argument('--timeout', type=int, default=120, help='tempo limite por teste em segundos')
    args = parser.parse_args()
    if args.browser:
        test = subprocess.run(['node', '-e', "require('playwright');"], cwd=ROOT,
                              stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
        if test.returncode:
            parser.error('Playwright ausente. Execute: npm install && npx playwright install chromium')
    results = []
    files = sorted([*TESTS.glob('verify_*.cjs'), *TESTS.glob('verify_*.py')])
    for test in files:
        reason = None
        cmd = ['node' if test.suffix == '.cjs' else sys.executable, str(test)]
        if test.name in BROWSER_CJS | BROWSER_PY and not args.browser:
            reason = 'necessita de navegador Playwright (não executado)'
        elif test.name == 'verify_android_compile.py':
            if not args.android_jar or not args.androidx_jar:
                reason = 'necessita de android.jar e androidx.core.jar (não executado)'
            else:
                cmd += ['--android-jar', str(args.android_jar), '--androidx-jar', str(args.androidx_jar)]
        elif test.name == 'verify_release_compatibility.cjs':
            if not args.release_bundle:
                reason = 'necessita JSON de publicação e distribution-service/worker (não executado)'
            else:
                cmd += [str(args.release_bundle)]
        if reason:
            status = 'BLOQUEADO'
            detail = reason
        else:
            try:
                run = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True,
                                     timeout=args.timeout, env=os.environ.copy())
                status = 'APROVADO' if run.returncode == 0 else 'FALHOU'
                detail = (run.stdout if run.returncode == 0 else run.stderr).strip()[-1200:]
            except subprocess.TimeoutExpired:
                status = 'FALHOU'
                detail = f'Tempo limite: {args.timeout}s'
        results.append(dict(teste=test.name, status=status, detalhe=detail))
        print(f'{status:9} {test.name}', flush=True)
        if status == 'FALHOU':
            print('  ' + detail[-500:].replace('\n', '\n  '), flush=True)
    output = ROOT / 'RESULTADOS_TESTES.json'
    output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    counts = {s: sum(r['status'] == s for r in results) for s in ('APROVADO', 'FALHOU', 'BLOQUEADO')}
    print('\nRESUMO:', json.dumps(counts, ensure_ascii=False), '\nArquivo:', output)
    return 1 if counts['FALHOU'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
