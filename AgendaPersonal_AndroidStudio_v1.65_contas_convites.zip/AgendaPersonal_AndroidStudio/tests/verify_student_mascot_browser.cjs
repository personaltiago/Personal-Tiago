'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'):require,{chromium}=runtime('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';if(!['index.html','professor.html','avaliacoes.html','cadastro.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,timezoneId:'America/Cuiaba'});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(window.failMascotSave&&k.includes('agenda_demo_exercise_sessions_v1_'))throw new DOMException('Full','QuotaExceededError');return set.call(this,k,v)}});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>!!window.APmascot);
  async function activate(uid='mascot_alice',role='student'){
   await page.evaluate(({uid,role})=>{
    const student={id:'local_'+uid,firebaseUid:uid,name:'Aluna de teste',gender:'Feminino'};
    const area=APStudentModel.makeArea({students:[student],workoutPlans:[{id:'p',studentId:student.id,name:'Plano de teste',days:[{id:'d',name:'Treino A',exercises:[{id:'e',name:'Agachamento',sets:1,reps:'12',rest:'0',load:'10'}]}]}]},student);
    window.__AP_STUDENT_CONTEXT={storageId:uid,role,area,profile:area.profile};APstudentUI.activate(role==='preview');route('home');
   },{uid,role});
  }
  async function complete(fail=false){
   await page.evaluate(()=>{openExerciseHub('p~d');beginExerciseWorkout();toggleExerciseSet(0,0);finishExerciseWorkout()});
   await page.locator('#exFinishIntensity').selectOption('Moderada');await page.evaluate(fail=>window.failMascotSave=fail,fail);await page.locator('.ex-finish-confirm').click();
  }
  await activate();assert.equal(await page.locator('#apMascotHome').count(),1);await page.locator('#apMascotHome .ap-habitat-house').click();
  await page.locator('#apMascotChoices [data-mascot-item="panda"]').click();
  assert.equal(await page.locator('#apMascotPhase').textContent(),'Filhote');assert.match(await page.locator('#apMascotBalance').textContent(),/0 moedas/);
  await page.locator('#apMascotTab-shop').click();assert.equal(await page.locator('[data-mascot-action="buy"]:not(:disabled)').count(),0);
  await page.evaluate(()=>handleAgendaSystemBack());assert.equal(await page.locator('#apMascot').isVisible(),false);
  await complete(true);assert.equal(await page.evaluate(()=>exStore().history.length),0);assert.equal(await page.evaluate(()=>APmascot.state().coins),0,'failed completion does not grant rewards');assert.ok(await page.evaluate(()=>exStore().active['p~d']));
  await page.evaluate(()=>window.failMascotSave=false);await page.locator('.ex-finish-confirm').click();assert.equal(await page.evaluate(()=>exStore().history.length),1);assert.equal(await page.evaluate(()=>APmascot.state().coins),100);
  await page.evaluate(()=>confirmExerciseWorkoutFinish());assert.equal(await page.evaluate(()=>APmascot.state().coins),100,'duplicate finish has no reward');
  await complete();assert.equal(await page.evaluate(()=>exStore().history.length),2);assert.equal(await page.evaluate(()=>APmascot.state().coins),100,'second workout same day is recorded but not rewarded');
  await page.evaluate(()=>route('home'));await page.locator('#apMascotHome .ap-habitat-house').click();assert.equal(await page.locator('#apMascotTab-care').count(),0);await page.locator('#apMascotTab-shop').click();
  const pose=page.locator('[data-mascot-action="buy"][data-mascot-item="pose-panda-sit"]');
  const beforeFailure=await page.evaluate(()=>APstudentStorage.getItem(exStorageKey()));await page.evaluate(()=>window.failMascotSave=true);await pose.click();assert.equal(await page.evaluate(()=>APstudentStorage.getItem(exStorageKey())),beforeFailure);assert.match(await page.locator('#apMascotStatus').textContent(),/não foram alterados/);await page.evaluate(()=>window.failMascotSave=false);
  await pose.click();assert.equal(await page.evaluate(()=>APmascot.state().coins),20);assert.equal(await page.evaluate(()=>APmascot.state().poses.panda),'sit');assert.equal(await page.evaluate(()=>APmascot.state().xp),100);
  await page.locator('.ap-mascot-settings summary').click();await page.locator('#apMascotName').fill('Pingo');await page.locator('#apMascotGoal').selectOption('5');await page.locator('#apMascotSettings button').click();assert.equal(await page.locator('#apMascotTitle').textContent(),'Pingo');assert.match(await page.locator('#apMascotWeeklyCount').textContent(),/de 3 treinos/,'current week goal preserved');
  await page.locator('.ap-mascot-settings summary').click();await page.locator('#apMascotTab-history').click();await page.keyboard.press('ArrowRight');assert.equal(await page.locator('#apMascotTab-colors').getAttribute('aria-selected'),'true');
  await page.keyboard.press('Escape');assert.equal(await page.locator('#apMascot').isVisible(),false);
  const saved=await page.evaluate(()=>APstudentStorage.getItem(exStorageKey()));await page.reload();await page.waitForFunction(()=>!!window.APmascot);await activate();assert.equal(await page.evaluate(()=>APmascot.state().name),'Pingo');assert.equal(await page.evaluate(()=>APmascot.state().coins),20);
  await activate('mascot_bob');assert.equal(await page.evaluate(()=>APmascot.state().coins),0);assert.equal(await page.evaluate(()=>APmascot.state().name),'Nino');
  await activate();assert.equal(await page.evaluate(()=>APstudentStorage.getItem(exStorageKey())),saved);
  await page.evaluate(()=>{const store=exStore();store.mascot={...APmascot.state(),coins:500,xp:600};exSave(store);APmascot.open()});
  await page.locator('#apMascotTab-shop').click();await page.locator('[data-mascot-action="buy"][data-mascot-item="pose-panda-rest"]').click();
  await page.locator('#apMascotTab-colors').click();await page.locator('[data-mascot-action="color"][data-mascot-item="white"]').click();assert.equal(await page.evaluate(()=>APmascot.state().colors.panda),'white');assert.equal(await page.evaluate(()=>APmascot.state().coins),380);
  assert.equal(await page.locator('#apMascotPhase').textContent(),'Adolescente');
  for(const phase of [0,600,1800])for(const width of [320,390,480])for(const mode of ['escuro','claro']){
   await page.setViewportSize({width,height:844});await page.evaluate(({phase,mode})=>{const store=exStore();store.mascot={...APmascot.state(),xp:phase};exSave(store);const p=prefs();p.color='#a8e34a';p.mode=mode;APstudentStorage.setItem(PREF_KEY,JSON.stringify(p));APmascot.open()},{phase,mode});
   for(const name of ['colors','house','shop','history']){
    await page.locator('#apMascotTab-'+name).click();const fits=await page.locator('.ap-mascot-sheet').evaluate(n=>n.scrollWidth<=n.clientWidth+1&&n.getBoundingClientRect().right<=innerWidth+1);assert.ok(fits,'fits '+[phase,width,mode,name]);
   }
  }
  // Review screenshots contain only synthetic test data, never student records.
  if(process.env.AGENDA_REVIEW_DIR){fs.mkdirSync(process.env.AGENDA_REVIEW_DIR,{recursive:true});await page.setViewportSize({width:390,height:1000});await page.evaluate(()=>{const s=exStore();s.mascot={...APmascot.state(),name:'Pingo',xp:600};exSave(s);const p=prefs();p.mode='escuro';APstudentStorage.setItem(PREF_KEY,JSON.stringify(p));APmascot.open()});await page.locator('#apMascotTab-colors').click();await page.locator('.ap-mascot-sheet').evaluate(n=>n.scrollTop=0);await page.screenshot({path:path.join(process.env.AGENDA_REVIEW_DIR,'mascote-aluno.png')})}
  await page.locator('#apMascotTab-shop').click();await activate('mascot_alice','preview');await page.evaluate(()=>APmascot.open());assert.equal(await page.locator('#apMascotPreview').isVisible(),true);assert.equal(await page.locator('#apMascotContent [data-mascot-action]:not(:disabled)').count(),0);const previewData=await page.evaluate(()=>APstudentStorage.getItem(exStorageKey()));assert.equal(await page.evaluate(()=>APmascot.prepareReward(exStore(),{id:'bad'})),null);assert.equal(await page.evaluate(()=>APstudentStorage.getItem(exStorageKey())),previewData);
  await page.evaluate(()=>{window.__AP_STUDENT_CONTEXT=null;window.dispatchEvent(new Event('ap-account-changed'))});assert.equal(await page.locator('#apMascot').isVisible(),false);assert.equal(await page.locator('#apMascotHome').isVisible(),false);
  assert.deepEqual(errors,[]);console.log('PASS: real mobile browser workout completion/retry, atomic quota rollback, duplicate finish/day, coins, pose purchase, care removal, rename, weekly goal, color, reload, account/preview isolation, Back/Escape, keyboard tabs, three growth phases and 72 responsive panels. Network/native services simulated.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
