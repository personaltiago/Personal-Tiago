'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const {chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets');
const server=http.createServer((req,res)=>{const file=path.join(assets,new URL(req.url,'http://local').pathname.endsWith('professor.html')?'professor.html':'index.html');res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(file))});
async function setup(page,paired=false){
 await page.evaluate(paired=>{
  clearWorkoutInlineVideo();
  const s={id:'s',name:'Aluna',firebaseUid:'student_inline',gender:'Feminino'};
  const ex=(id,name,video)=>({id,name,sets:3,reps:'8-12',load:'30',rest:'60',video});
  const day={id:'d',name:'Glúteo',exercises:[ex('a','Abdução de Quadril Máquina','https://youtu.be/M7lc1UVf-VE?t=1m30s'),ex('b','Agachamento','https://www.youtube.com/shorts/aqz-KE-bpKQ'),ex('c','Sem vídeo','')]};
  if(paired)day.bisets=[{id:'pair',exerciseIds:['a','b'],rounds:3,restSeconds:60}];
  const area=APStudentModel.makeArea({students:[s],workoutPlans:[{id:'p',studentId:'s',name:'Ficha',days:[day]}]},s);
  __AP_STUDENT_CONTEXT={storageId:'student_inline',role:'student',area,profile:area.profile};
  localStorage.clear();exActiveId='p~d';exIndex=0;exView='detail';exTab='video';route('exercise');exNewSession(exActiveId);
  __opens=[];__positions=[];__closes=[];__separate=0;__external=[];
 },paired);
}
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const ctx=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
  await ctx.route('https://**',r=>r.abort());await ctx.addInitScript(()=>{
   window.__opens=[];window.__positions=[];window.__closes=[];window.__separate=0;window.__external=[];
   window.Android={updatePageReady(){},syncLessonAlarms(){return true},getAlarmStatus(){return '{}'},getCustomSoundStatus(){return '{}'},
    openInlineYouTubeVideo(json){__opens.push(JSON.parse(json));return !window.__reject},positionInlineYouTubeVideo(key,json){__positions.push({key,...JSON.parse(json)})},closeInlineYouTubeVideo(key){__closes.push(key)},
    openYouTubeVideo(){__separate++;return true},openExternal(url){__external.push(url)},startWorkoutRest(){return true},cancelWorkoutRest(){return true}};
  });
  const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>window.APStudentModel&&window.APstudentUI);
  for(const [width,height]of [[320,568],[360,740],[390,844],[480,844],[844,390]]){
   await page.setViewportSize({width,height});await setup(page);
   const before=await page.evaluate(()=>JSON.stringify(exGetSession()));
   await page.getByRole('button',{name:'Ver vídeo de Abdução de Quadril Máquina',exact:true}).click();
   let result=await page.evaluate(()=>({payload:__opens.at(-1),separate:__separate,frames:document.querySelectorAll('#exTabContent iframe').length,view:document.body.dataset.view,session:JSON.stringify(exGetSession())}));
   assert.equal(result.payload.videoId,'M7lc1UVf-VE');assert.equal(result.payload.startSeconds,90);assert.equal(result.separate,0);assert.equal(result.frames,0);assert.equal(result.view,'exercise');assert.equal(result.session,before);
   assert.ok(result.payload.bounds.width>=200&&result.payload.bounds.height>=248);assert.ok(result.payload.bounds.left>=-1&&result.payload.bounds.left+result.payload.bounds.width<=width+1);
   await page.evaluate(()=>{document.querySelector('.ap-student-video-playing').dataset.preserved='yes';saveExerciseLoad(0,0,'37.5');toggleExerciseSet(0,0)});
   assert.equal(await page.locator('.ap-student-video-playing').getAttribute('data-preserved'),'yes');assert.equal(await page.evaluate(()=>__opens.length),1,'series redraw does not restart media');
   assert.equal(await page.evaluate(()=>exGetSession().loads[0][0]),37.5);assert.equal(await page.evaluate(()=>exGetSession().done[0][0]),true);
   await page.evaluate(()=>document.getElementById('exScroll').scrollTop=350);await page.waitForTimeout(70);assert.ok(await page.evaluate(()=>__positions.length)>0);
   const key=result.payload.key;await page.evaluate(()=>setExerciseTab('description'));await page.waitForTimeout(40);assert.ok((await page.evaluate(()=>__closes)).includes(key));assert.equal(await page.locator('.ap-student-video-playing').count(),0);
   await page.evaluate(()=>setExerciseTab('video'));assert.equal(await page.evaluate(()=>__opens.length),1,'return does not autoplay');
  }
  await page.setViewportSize({width:390,height:844});await setup(page,true);
  await page.getByRole('button',{name:'Ver vídeo de Abdução de Quadril Máquina',exact:true}).click();const first=await page.evaluate(()=>__opens.at(-1).key);
  await page.getByRole('button',{name:'Ver vídeo de Agachamento',exact:true}).click();assert.ok((await page.evaluate(()=>__closes)).includes(first));assert.equal(await page.evaluate(()=>__opens.at(-1).videoId),'aqz-KE-bpKQ');assert.equal(await page.locator('.ap-student-video-playing').count(),1);
  await page.evaluate(()=>{toggleExerciseSet(0,0);toggleExerciseSet(1,0)});assert.equal(await page.evaluate(()=>__opens.length),2,'bi-set checks do not restart media');
  await page.evaluate(()=>route('workouts'));assert.equal(await page.locator('.ap-student-video-playing').count(),0);
  await setup(page);await page.getByRole('button',{name:'Ver vídeo de Abdução de Quadril Máquina',exact:true}).click();await page.evaluate(()=>openExerciseDetail(1));assert.equal(await page.locator('.ap-student-video-playing').count(),0);
  await setup(page);await page.evaluate(()=>__reject=true);await page.getByRole('button',{name:'Ver vídeo de Abdução de Quadril Máquina',exact:true}).click();assert.ok(await page.getByRole('button',{name:'Tentar novamente'}).isVisible());assert.equal(await page.evaluate(()=>__separate),0);assert.equal(await page.locator('#exTabContent iframe').count(),0);assert.equal(await page.evaluate(()=>__external.length),0);
  await page.evaluate(()=>__reject=false);await page.getByRole('button',{name:'Tentar novamente'}).click();const key=await page.evaluate(()=>__opens.at(-1).key);
  await page.evaluate(()=>workoutInlineVideoError('old-key'));assert.equal(await page.getByRole('button',{name:'Tentar novamente'}).count(),0);await page.evaluate(key=>workoutInlineVideoError(key),key);await page.getByRole('button',{name:'Abrir no YouTube',exact:true}).click();assert.equal(await page.evaluate(()=>__external.length),1);
  await setup(page);await page.evaluate(()=>delete Android.openInlineYouTubeVideo);await page.getByRole('button',{name:'Ver vídeo de Abdução de Quadril Máquina',exact:true}).click();assert.equal(await page.evaluate(()=>__separate),0);assert.equal(await page.locator('#exTabContent iframe').count(),0,'old APK cannot host untrusted iframe in privileged view');
  await setup(page);await page.evaluate(()=>delete window.Android);await page.getByRole('button',{name:'Ver vídeo de Abdução de Quadril Máquina',exact:true}).click();assert.match(await page.locator('#exTabContent iframe').getAttribute('src'),/playsinline=1.*start=90/);await page.evaluate(()=>setExerciseTab('muscles'));assert.equal(await page.locator('#exTabContent iframe').count(),0);
  assert.deepEqual(errors,[]);console.log('PASS: student inline native bridge in 5 mobile/landscape viewports; no separate Activity/privileged iframe; offsets, stable player across sets/loads and bi-set, scroll clipping, tab/exercise/route cleanup, rejection/retry/late errors, old APK handling and browser fallback. Media/Android bridge simulated; no device playback tested.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
