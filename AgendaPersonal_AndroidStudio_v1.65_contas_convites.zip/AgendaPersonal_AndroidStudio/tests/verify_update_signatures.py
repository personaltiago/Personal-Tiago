"""Exercise the shipping signer and verifier with temporary keys, real package JSON and Android API doubles."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
PACKAGE = 'com/tiagolima/agendapersonal'
HARNESS = """
package com.tiagolima.agendapersonal;

import android.content.Context;
import android.os.Build;
import java.nio.file.*;
import org.json.JSONObject;

class SignatureHarness {
    public static void main(String[] args) throws Exception {
        Context context = new Context();
        context.manager.cert = Files.readAllBytes(Path.of(args[0]));
        JSONObject original = new JSONObject(Files.readString(Path.of(args[1])));
        JSONObject signed = new JSONObject(Files.readString(Path.of(args[2])));
        JSONObject reordered = new JSONObject().put("agendaSignature", signed.getString("agendaSignature"));
        original.keys().forEachRemaining(k -> reordered.put(k, original.opt(k)));
        UpdatePackageTrust.verify(context, signed);
        UpdatePackageTrust.verify(context, reordered);
        Build.VERSION.SDK_INT = 26;
        UpdatePackageTrust.verify(context, signed);
        reject(context, original);
        signed.put("notes", "texto alterado depois da assinatura");
        reject(context, signed);
        signed = new JSONObject(Files.readString(Path.of(args[2])));
        context.manager.cert = Files.readAllBytes(Path.of(args[3]));
        reject(context, signed);
        System.out.println("Assinatura verificada com o certificado do APK, Android 26 e 35 simulados; pacote sem assinatura, adulterado ou com chave diferente rejeitado.");
    }

    private static void reject(Context context, JSONObject value) throws Exception {
        try {
            UpdatePackageTrust.verify(context, value);
            throw new AssertionError("Pacote sem assinatura válida foi aceito");
        } catch (UpdatePackageSignature.Invalid expected) { }
    }
}
"""
STUBS = {
    'android/os/Build.java': 'package android.os; public class Build {public static class VERSION {public static int SDK_INT=35;}}',
    'android/content/Context.java': '''
        package android.content;
        public class Context {
            public final android.content.pm.PackageManager manager = new android.content.pm.PackageManager();
            public android.content.pm.PackageManager getPackageManager(){return manager;}
            public String getPackageName(){return "com.tiagolima.agendapersonal";}
        }''',
    'android/content/pm/PackageManager.java': '''
        package android.content.pm;
        public class PackageManager {
            public static final int GET_SIGNATURES=1, GET_SIGNING_CERTIFICATES=2;
            public byte[] cert;
            public PackageInfo getPackageInfo(String name, int flags){
                PackageInfo info = new PackageInfo();
                info.signatures = new Signature[]{new Signature(cert)};
                info.signingInfo = new SigningInfo(info.signatures);
                return info;
            }
        }''',
    'android/content/pm/PackageInfo.java': '''
        package android.content.pm;
        public class PackageInfo {public Signature[] signatures; public SigningInfo signingInfo;}''',
    'android/content/pm/SigningInfo.java': '''
        package android.content.pm;
        public record SigningInfo(Signature[] signers) {public Signature[] getApkContentsSigners(){return signers;}}''',
    'android/content/pm/Signature.java': '''
        package android.content.pm;
        public record Signature(byte[] cert) {public byte[] toByteArray(){return cert;}}''',
    PACKAGE + '/SignatureHarness.java': HARNESS,
}


def main():
    with tempfile.TemporaryDirectory(prefix='agenda-signature-') as tmp:
        work = Path(tmp)
        paths = []
        for name, source in STUBS.items():
            path = work / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(source)
            paths.append(str(path))
        paths.extend(str(path) for path in (PROJECT / 'tests/native-json').rglob('*.java'))
        paths.extend(str(PROJECT / 'app/src/main/java' / PACKAGE / name) for name in (
            'UpdatePackageTrust.java', 'UpdatePackageSignature.java'))
        subprocess.run(['java', 'com.sun.tools.javac.Main', '-encoding', 'UTF-8', '-d', str(work), *paths], check=True)
        test_password = 'agenda-fixture'
        keys = []
        for alg in ('RSA', 'EC'):
            key = work / (alg + '.p12')
            cert = work / (alg + '.der')
            base = ['-alias', 'fixture', '-storepass', test_password, '-keystore', str(key)]
            subprocess.run(['keytool', '-genkeypair', '-keyalg', alg, '-dname', 'CN=Fixture only',
                            '-validity', '2', *base], check=True, capture_output=True)
            subprocess.run(['keytool', '-exportcert', '-file', str(cert), *base], check=True, capture_output=True)
            keys.append((key, cert))
        fixture = work / 'area.agenda.json'
        fixture.write_text(json.dumps({
            'format': 'agenda-patch/2', 'appId': 'com.tiagolima.agendapersonal', 'area': 'pets',
            'notes': 'Olhar do Léo 🐻', 'meta': {'𐐀': True, 'ç': [False, None, 17, -9, '1.0']},
            'changes': [{'content': 'carinho à noite'}]
        }), encoding='utf-8')
        for source in (fixture, Path(sys.argv[1]) if len(sys.argv) > 1 else PROJECT / 'web/native-release.agenda.json'):
            for i, (key, cert) in enumerate(keys):
                output = work / (source.stem + f'-signed-{i}.json')
                env = dict(os.environ, ANDROID_KEYSTORE_PATH=str(key), ANDROID_KEY_ALIAS='fixture',
                           ANDROID_KEYSTORE_PASSWORD=test_password, ANDROID_KEY_PASSWORD=test_password)
                subprocess.run(['node', 'tools/sign_update.cjs', str(source), str(output)], cwd=PROJECT, env=env, check=True)
                subprocess.run(['java', '-cp', str(work), PACKAGE.replace('/', '.') + '.SignatureHarness',
                                str(cert), str(source), str(output), str(keys[1-i][1])], check=True)


if __name__ == '__main__':
    main()
