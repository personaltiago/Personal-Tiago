'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const {fixture,init,openDay,create,start,fits,server}=require('./verify_bisets.cjs');
const root=path.resolve(__dirname,'..'),qa=path.resolve(root,'../../qa');fs.mkdirSync(qa,{recursive:true});
const model={window:{}};vm.runInNewContext(fs.readFileSync(path.join(root,'web/workout-previous-series.js'),'utf8'),model);
const read=model.window.APWorkoutPreviousSeries.read;
const plan={id:'p',studentId:'s'},day={id:'d'},exercise={id:'a'};
const record=(id,date,reps=[9,8,7])=>({id,studentId:'s',planId:'p',dayId:'d',date,recordedAt:date+'T12:00:00Z',exercises:[{exerciseId:'a',name:'Rosca direta',performedSets:reps.map((reps,i)=>({round:i+1,reps,load:'20 kg'}))}]});
const older=record('old','2026-10-20'),partial=record('partial','2026-10-21',[10]);
let data={workoutExecutions:[older,partial],workoutDrafts:{'p|d':{values:{a:{series:{1:{done:true,reps:99}}}}}}};
let before=JSON.stringify(data),result=read(data,plan,day,exercise);assert.equal(result.values[1],10);assert.equal(result.values[2],undefined);assert.equal(JSON.stringify(data),before);
for(const key of ['studentId','planId','dayId']){const isolated={...record('other','2026-10-22',[99]),[key]:'other'};assert.equal(read({workoutExecutions:[isolated,older]},plan,day,exercise).values[1],9)}
const legacy={...record('legacy','2026-10-22'),exercises:[{exerciseId:'a',sets:'3',reps:'12'}]};assert.equal(Object.keys(read({workoutExecutions:[older,legacy]},plan,day,exercise).values).length,0);
const invalid=record('invalid','2026-10-22',['8-12',0,1000]);assert.equal(Object.keys(read({workoutExecutions:[invalid]},plan,day,exercise).values).length,0);
assert.equal(read({workoutExecutions:[older]},plan,day,{id:'unknown'}),null);
const sameDateA={...record('first','2026-10-21',[8]),recordedAt:'2026-10-21T12:00:00Z'},sameDateB={...record('second','2026-10-21',[11]),recordedAt:'2026-10-21T18:00:00Z'};
assert.equal(read({workoutExecutions:[sameDateA,sameDateB]},plan,day,exercise).values[1],11);
const row=(p,id,n,guide=false)=>p.locator((guide?'#workoutBisetContent':'#workoutDayContent')+' .ws-set-row[data-series-exercise="'+id+'"][data-series-round="'+n+'"]');
const previous=(p,id,n,guide=false)=>row(p,id,n,guide).locator('[data-series-previous]');
const stored=p=>p.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')));
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const errors=[],checks=['Histórico isolado por aluno, ficha, dia e exercício; rascunho atual não participa; treino parcial não herda séries antigas; registro agregado não inventa resultados'],layouts=[];
 try{
  data=structuredClone(fixture);data.workoutPlans[0].days[0].exercises[0].reps='8-12';data.workoutExecutions=[older];
  const context=await browser.newContext({viewport:{width:393,height:852},hasTouch:true,timezoneId:'America/Cuiaba'});await init(context,data);
  const p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));p.on('dialog',d=>d.accept());await p.clock.install({time:new Date('2026-10-22T16:00:00Z')});
  await p.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await p.waitForFunction(()=>__ready);await openDay(p);
  assert.deepEqual(await p.locator('#workoutDayContent [data-series-table="a"] [data-series-previous]').allTextContents(),['9','8','7']);assert.equal(await previous(p,'b',1).innerText(),'—');
  const prescription=await p.evaluate(()=>JSON.parse(JSON.stringify(currentWorkoutPlan())));await start(p);
  assert.match(await row(p,'a',1).locator('.ws-set-target').innerText(),/8-12/);assert.equal(await row(p,'a',1).locator('[data-series-field="reps"]').inputValue(),'');
  for(let n=1;n<=3;n++){
   await row(p,'a',n).locator('[data-series-field="reps"]').fill(String(11-n));await row(p,'a',n).locator('[data-series-field="load"]').fill('25');await row(p,'a',n).locator('input[type=checkbox]').check();
  }
  assert.deepEqual(await p.locator('#workoutDayContent [data-series-table="a"] [data-series-previous]').allTextContents(),['9','8','7'],'current completions do not replace the previous workout');
  await p.reload();await p.waitForFunction(()=>__ready);await openDay(p);assert.equal(await previous(p,'a',1).innerText(),'9');assert.equal(await row(p,'a',1).locator('[data-series-field="reps"]').inputValue(),'10');
  await p.getByRole('button',{name:'Finalizar treino',exact:true}).click();await p.locator('#workoutExecutionForm button[type=submit]').click();await openDay(p);await start(p);
  assert.deepEqual(await p.locator('#workoutDayContent [data-series-table="a"] [data-series-previous]').allTextContents(),['10','9','8']);assert.equal(await row(p,'a',1).locator('input[type=checkbox]').isChecked(),false);assert.equal(await row(p,'a',1).locator('[data-series-field="reps"]').inputValue(),'');
  assert.deepEqual(await p.evaluate(()=>JSON.parse(JSON.stringify(currentWorkoutPlan()))),prescription);checks.push('Ciclo real: 9/8/7 anteriores, 10/9/8 hoje; fechar e reabrir preserva tudo; finalizar e iniciar zera apenas o treino atual e atualiza a referência');
  await row(p,'a',1).locator('[data-series-field="reps"]').fill('12');await row(p,'a',1).locator('input[type=checkbox]').check();await p.getByRole('button',{name:'Limpar marcações',exact:true}).click();
  assert.equal(await previous(p,'a',1).innerText(),'10');assert.equal((await stored(p)).workoutExecutions.length,2);checks.push('Limpar marcações conserva o último treino finalizado e não cria evolução');
  for(const width of [320,360,393,430,640,852])for(const font of [16,20]){
   await p.setViewportSize({width,height:852});await p.evaluate(font=>document.documentElement.style.fontSize=font+'px',font);assert.equal(await fits(p),'',JSON.stringify({width,font}));
   const geometry=await row(p,'a',1).evaluate(n=>{const s=n.closest('.sheet').getBoundingClientRect(),r=n.getBoundingClientRect();return {sheetLeft:s.left,sheetRight:s.right,rowLeft:r.left,rowRight:r.right,width:innerWidth,scroll:n.scrollWidth,client:n.clientWidth}});
   assert.ok(geometry.scroll<=geometry.client+1);if(width<=620){assert.ok(geometry.sheetLeft<1);assert.ok(geometry.sheetRight>=width-1);assert.ok(geometry.rowLeft<=34);assert.ok(geometry.rowRight>=width-34)}
   layouts.push({width,font,...geometry});
  }
  await p.setViewportSize({width:393,height:852});await p.evaluate(()=>{document.documentElement.style.fontSize='16px';document.getElementById('toast').style.display='none'});await row(p,'a',1).scrollIntoViewIfNeeded();await p.screenshot({path:path.join(qa,'repeticoes-393.png')});
  await p.setViewportSize({width:320,height:852});await row(p,'a',1).scrollIntoViewIfNeeded();await p.screenshot({path:path.join(qa,'repeticoes-320.png')});await context.close();
  const pairContext=await browser.newContext({viewport:{width:393,height:852},timezoneId:'America/Cuiaba'});await init(pairContext,data);const q=await pairContext.newPage();q.on('pageerror',e=>errors.push(e.message));q.on('dialog',d=>d.accept());await q.clock.install({time:new Date('2026-10-22T16:00:00Z')});await q.goto('http://127.0.0.1:'+server.address().port+'/professor.html');await q.waitForFunction(()=>__ready);await openDay(q);await create(q,'a','b',3,0);await start(q);await q.evaluate(id=>openWorkoutBiset(id),(await stored(q)).workoutPlans[0].days[0].bisets[0].id);
  assert.equal(await previous(q,'a',1,true).innerText(),'9');assert.equal(await previous(q,'b',1,true).innerText(),'—');
  for(const width of [320,393,852]){await q.setViewportSize({width,height:852});assert.equal(await fits(q),'')}
  checks.push('Bi-set exibe resultado anterior próprio de A e B; cinco colunas cabem no celular, com campos tocáveis');await pairContext.close();assert.deepEqual(errors,[]);
  const report={passed:true,checks,layouts,errors};fs.writeFileSync(path.join(qa,'previous-series-review.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);process.exitCode=1;server.close()});
