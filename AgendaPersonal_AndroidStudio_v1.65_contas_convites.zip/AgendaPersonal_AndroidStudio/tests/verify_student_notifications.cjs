'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'):require,{chromium}=runtime('playwright');
const source=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/index.html'),'utf8');
async function integration(){
 const {ctx,storage}=require('./verify_shell_boot.cjs'),callbacks=new Map(),teacher=ctx.APStudentModel.TEACHER;
 ctx.Android={setUpdateAccount(){},getUpdateStatus:()=>JSON.stringify({installedSequence:108,installedVersion:'1.12.2',manifest:{available:false}})};
 const user={uid:'alice_notif',email:'alice@example.test'},sdk={auth:{currentUser:user},doc:(db,...p)=>p.join('/'),getDoc:async()=>({exists:()=>true,data:()=>({perfil:'aluno',professorId:teacher,ativo:true,nome:'Aluna',genero:'Feminino'})}),onSnapshot:(ref,...args)=>{callbacks.set(ref,args.find(a=>typeof a==='function'));return()=>{}}};
 ctx.__accountTest.setSdk(sdk);await ctx.__accountTest.activate(user,'Aluno');
 const student={id:'s',firebaseUid:user.uid,name:'Aluna'},state={students:[student],workoutPlans:[{id:'p',studentId:'s',days:[{id:'d',name:'Treino',exercises:[{id:'e',name:'Exercício',sets:3,reps:'12',rest:'60'}]}]}]};
 const area=ctx.APStudentModel.makeArea(state,student);let receive=callbacks.get('usuarios/'+user.uid+'/treinos/atual');assert.ok(receive);
 function send(packet,cache=false){receive({exists:()=>true,metadata:{fromCache:cache},data:()=>({version:2,professorId:teacher,studentUid:user.uid,studentId:'s',payload:JSON.stringify(packet)})})}
 send(area,true);assert.equal(ctx.APnotifications.unread(),0,'cache does not create update event');
 send(area);assert.equal(ctx.APnotifications.unread(),1,'first actual prescription received');
 send(area);assert.equal(ctx.APnotifications.unread(),1,'metadata/reconnect does not duplicate');
 const photo=structuredClone(area);photo.profile.photo='data:image/jpeg;base64,test';photo.trainer={name:'Outro nome'};send(photo);assert.equal(ctx.APnotifications.unread(),1,'profile/branding changes do not announce workout change');
 const changed=structuredClone(area);changed.plans[0].days[0].exercises[0].rows[0].load=31;send(changed);assert.equal(ctx.APnotifications.unread(),2);
 send(area,true);send(changed);assert.equal(ctx.APnotifications.unread(),2,'stale cached event cannot replace notification baseline');
 const saved=storage.get('agenda_student_notifications_v1_'+user.uid);assert.ok(saved);
 await ctx.__accountTest.activate(user,'Aluno');receive=callbacks.get('usuarios/'+user.uid+'/treinos/atual');send(changed);assert.equal(ctx.APnotifications.unread(),2,'account reopen retains baseline and unread count');
 assert.equal(storage.get('agenda_student_notifications_v1_'+user.uid),saved,'unchanged reception does not append');
 console.log('PASS: real account/Firebase listener integration with doubles: approved UID, cached snapshot ignored, initial prescription, changed load, deduplication, branding/photo exclusion and persisted reconnect baseline.');
}
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(source)});
async function browserTest(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{window.__status={installedSequence:108,installedVersion:'1.12.2',manifest:{available:false}};window.__openUpdates=0;window.Android={getUpdateStatus:()=>JSON.stringify(window.__status),openUpdates(){window.__openUpdates++}}});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);
  async function student(uid='alice') {await page.evaluate(uid=>{
   const s={id:'s',firebaseUid:uid,name:'Aluna',gender:'Feminino'},area=APStudentModel.makeArea({students:[s],workoutPlans:[{id:'p',studentId:'s',name:'Ficha',days:[{id:'d',name:'Treino',exercises:[{id:'e',name:'Exercício',sets:3,reps:'12',rest:'60'}]}]}]},s);
   window.__AP_STUDENT_CONTEXT={storageId:uid,role:'student',profile:s,area};window.dispatchEvent(new Event('ap-account-changed'));APstudentUI.activate();window.dispatchEvent(new Event('ap-student-ready'));route('home');
  },uid)}
  await student();assert.equal(await page.locator('#apStudentNotificationCount').isVisible(),false);
  await page.locator('#apStudentNotificationBell').click();await page.getByText('Nenhuma notificação por enquanto.',{exact:true}).waitFor();await page.locator('#apStudentNotificationsClose').click();
  await page.evaluate(()=>{window.__status.manifest={available:true,sequence:109,version:'1.12.3'};APupdates.refreshNotice();APupdates.refreshNotice()});
  assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'1');
  assert.equal(await page.locator('#apUpdateNotice').isVisible(),false,'app update belongs to the bell for students');
  await page.evaluate(()=>{const area=structuredClone(__AP_STUDENT_CONTEXT.area);area.plans[0].days[0].exercises[0].rows[0].load=28;APnotifications.receiveWorkout(area);__AP_STUDENT_CONTEXT.area=area});
  assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'2');
  await page.evaluate(()=>{window.__status.manifest={available:true,sequence:110,version:'1.12.4'};APupdates.refreshNotice()});
  assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'3');
  await page.locator('#apStudentNotificationBell').click();assert.equal(await page.locator('.ap-notif-item.is-unread').count(),3);assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'3','opening does not silently mark all read');
  await page.getByRole('button',{name:'Baixar atualização',exact:true}).first().click();assert.equal(await page.evaluate(()=>__openUpdates),1);assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'2');
  await page.reload();await page.evaluate(()=>{window.__status.manifest={available:true,sequence:110,version:'1.12.4'}});await student();assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'2','count survives page reload');
  await student('bob');assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'1','other account has only the current app release');
  // Bob sees the same current app release once, but not Alice workout notice.
  assert.equal(await page.evaluate(()=>APnotifications.unread()),1);
  await student('alice');assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'2');
  await page.locator('#apStudentNotificationBell').click();
  for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);const box=await page.locator('.ap-notif-sheet').boundingBox();assert.ok(box.x>=0&&box.x+box.width<=width+1)}
  await page.screenshot({path:path.resolve(__dirname,'../../../../student_notifications_review.png')});
  await page.getByRole('button',{name:'Ver treino',exact:true}).click();assert.equal(await page.evaluate(()=>document.body.dataset.view),'workouts');
  await page.evaluate(()=>route('home'));await page.locator('#apStudentNotificationBell').click();await page.getByRole('button',{name:'Marcar todas como lidas',exact:true}).click();assert.equal(await page.locator('#apStudentNotificationCount').isVisible(),false);
  await page.evaluate(()=>handleAgendaSystemBack());assert.equal(await page.locator('#apStudentNotifications').isVisible(),false,'Android Back closes notification sheet');
  await page.evaluate(()=>{window.__status.installedSequence=110;window.__status.installedVersion='1.12.4';APupdates.refreshNotice()});assert.equal(await page.locator('#apStudentNotificationCount').textContent(),'1');
  await page.locator('#apStudentNotificationBell').click();await page.getByRole('heading',{name:'Aplicativo atualizado',exact:true}).waitFor();assert.match(await page.locator('.ap-notif-item').first().textContent(),/1\.12\.4 instalada/);
  await page.getByRole('button',{name:'Marcar todas como lidas',exact:true}).click();await page.evaluate(()=>{window.__AP_STUDENT_CONTEXT=null;window.dispatchEvent(new Event('ap-account-changed'))});assert.equal(await page.locator('#apStudentNotifications').isVisible(),false);assert.equal(await page.locator('#apStudentNotificationCount').isVisible(),false);
  assert.deepEqual(errors,[]);
  console.log('PASS: real mobile browser bell count 1/2/3, list/read actions, native update handoff, workout route, persisted dedup/read state, per-account isolation, installed receipt, Android Back, responsive widths and logout cleanup. Native download and real Firebase not exercised.');
 }finally{await browser.close();server.close()}
}
integration().then(browserTest).catch(e=>{console.error(e);server.close();process.exitCode=1});
