'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const names=['index.html','professor.html','avaliacoes.html','cadastro.html'],assets=path.resolve(__dirname,'../app/src/main/assets');
const candidate=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
for(const n of names)assert.equal(candidate.files[n],fs.readFileSync(path.join(assets,n),'utf8'),'artifact matches current asset '+n);
const currentSource=fs.readFileSync(path.resolve(__dirname,'../web/distribution-controls.js'),'utf8');
const originalSource=currentSource.replace(/  \/\/ Keep the runtime marker[\s\S]*?const nativeMarker='window\.__agendaNativeReleaseToken'\+'=';\n/,'').replace('bundle.files[n].includes(nativeMarker)',"bundle.files[n].includes('window.__agendaNativeReleaseToken=')");
function validator(source){const fn=source.match(/function validate\(bundle\)\{[\s\S]*?\n \}/)?.[0];assert.ok(fn);return vm.runInNewContext('('+fn+')',{names})}
const legacySource=process.argv[3]?(process.argv[3].endsWith('.js')?fs.readFileSync(process.argv[3],'utf8'):JSON.parse(fs.readFileSync(process.argv[3],'utf8')).files['index.html']):originalSource;
const oldValidate=validator(legacySource),newValidate=validator(currentSource);
assert.doesNotThrow(()=>oldValidate(candidate),'actual package accepted by original installed publisher');
assert.doesNotThrow(()=>newValidate(candidate),'actual package accepted by corrected publisher');
const bug=structuredClone(candidate);bug.files['index.html']+="<script>var check='window.__agendaNativeReleaseToken=';</script>";
assert.throws(()=>oldValidate(bug),/compatível/,'reproduces self-rejection of old packages');
const bad=structuredClone(candidate);bad.files['index.html']+='<script>window.__agendaNativeReleaseToken="private-runtime";</script>';
assert.throws(()=>oldValidate(bad));assert.throws(()=>newValidate(bad),'runtime assignment still blocked');
async function run(){
 const worker=process.env.AGENDA_DISTRIBUTION_WORKER||path.resolve(__dirname,'../../../../distribution-service/worker/index.js');
 if(!fs.existsSync(worker)){console.log('PASS: artifact bytes in four pages, installed/current publisher validation and rejection of runtime injection. SKIP: external distribution server source is not part of the Android project. Set AGENDA_DISTRIBUTION_WORKER to test it.');return}
 const {createHandler}=await import(worker);
 const store=new Map(),env={BUCKET:{async get(key){const value=store.get(key);return value?{etag:'1',json:async()=>JSON.parse(value)}:null},async put(key,value){store.set(key,typeof value==='string'?value:Buffer.from(value).toString());return {etag:'1'}},async delete(key){store.delete(key)}}};
 const api=createHandler(async()=>Response.json({users:[{localId:'R2EmnDVcvMWt7TjPxOP6DjW1VOn1'}]}));
 const result=await api(new Request('https://example.test/api/publish',{method:'POST',headers:{Authorization:'Bearer '+'t'.repeat(40),'Content-Type':'application/json'},body:JSON.stringify(candidate)}),env);
 const value=await result.json();assert.equal(result.status,201,JSON.stringify(value));assert.equal(value.manifest.sequence,candidate.sequence);assert.equal(value.manifest.size,Buffer.byteLength(JSON.stringify(candidate)));
 const manifest=await (await api(new Request('https://example.test/api/manifest'),env)).json();assert.equal(manifest.sha256,value.manifest.sha256);
 console.log('PASS: delivered JSON matches all 4 pages, original APK publisher accepts it, corrected publisher accepts it, prior false-positive reproduced, real runtime injection rejected and production server handler publishes exact artifact. Auth/R2 simulated; no live release published.');
}
run().catch(e=>{console.error(e);process.exitCode=1});
