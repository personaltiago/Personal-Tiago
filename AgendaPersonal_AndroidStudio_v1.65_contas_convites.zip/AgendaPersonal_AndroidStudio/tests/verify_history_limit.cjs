// O histórico fica limitado às 200 movimentações mais recentes (ao abrir e ao salvar).
const fs=require('fs'),path=require('path'),assert=require('assert');
const p=JSON.parse(fs.readFileSync(path.join(__dirname,'..','web','native-release.agenda.json'),'utf8')).files['professor.html'];
assert(p.includes('d.history=Array.isArray(d.history)?d.history.slice(0,200):[];'),'limite ao abrir');
const m=p.match(/function save\(\)\{(if\(Array\.isArray\(state\.history\)&&state\.history\.length>200\)state\.history\.length=200;)localStorage\.setItem\(DB_KEY,JSON\.stringify\(state\)\);/);assert(m,'limite ao salvar');
const state={history:Array.from({length:450},(_,i)=>({id:'h'+i}))};new Function('state',m[1])(state);
assert.strictEqual(state.history.length,200);assert.strictEqual(state.history[0].id,'h0');assert.strictEqual(state.history[199].id,'h199');
const few={history:[{id:'a'}]};new Function('state',m[1])(few);assert.strictEqual(few.history.length,1);
assert(p.includes('state.history.slice(0,80).map(historyRowHtml)'),'tela continua mostrando 80');
console.log('PASS Histórico limitado a 200 (mais recentes preservados).');
