const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/professor.html'), 'utf8');
const source = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const initial = {
  students: [{id:'aluno-a', name:'Aluno A', phone:'', location:'Academia'}],
  lessons: [{
    id:'fixa-seg', studentId:'aluno-a', date:'2026-10-05', time:'06:30', duration:60,
    type:'Treino individual', location:'Academia', lead:15, repeat:'weekly', repeatDays:[1], notes:''
  }],
  occurrenceStatus:{}, history:[]
};
const storage = new Map([['agendaPersonalTL_v1', JSON.stringify(initial)]]);
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    value:'', style:{}, dataset:{}, innerHTML:'', textContent:'', options:[],
    querySelector(){return null;},focus(){},setCustomValidity(){},setAttribute(){},removeAttribute(){},getAttribute(){return null;},classList:{names:new Set(),add(...n){n.forEach(v=>this.names.add(v));},remove(...n){n.forEach(v=>this.names.delete(v));},contains(n){return this.names.has(n);},toggle(n,force){const active=force===undefined?!this.names.has(n):!!force;if(active)this.names.add(n);else this.names.delete(n);return active;}}, reset(){}, addEventListener(){},querySelectorAll(){return [];}
  });
  return elements.get(id);
}
const native = {syncLessonAlarms(){return true;}};
const context = {
  URL, Date, console, setInterval(){}, setTimeout(){return 1;}, clearTimeout(){},
  localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,value)=>storage.set(key,value)},
  document:{body:element('body'),documentElement:element('html'),querySelector(){return null;},getElementById:element,querySelectorAll(){return [];},addEventListener(){},hidden:false},
  Android:native, window:{scrollTo(){},Android:native,open(){},addEventListener(){}}
};
vm.createContext(context);
vm.runInContext(html.match(/<script id="ap-timer-compatibility">([\s\S]*?)<\/script>/)[1], context);
vm.runInContext(source, context);

assert.equal(context.conflictsForSlot('2026-10-05','06:30','07:30').length, 1, 'horário idêntico deve estar ocupado');
assert.equal(context.conflictsForSlot('2026-10-05','07:00','08:00').length, 1, 'sobreposição parcial deve estar ocupada');
assert.equal(context.conflictsForSlot('2026-10-05','07:30','08:30').length, 0, 'horário que começa quando a aula termina deve estar livre');

const oneOffConflict = context.candidateConflict({date:'2026-10-12',time:'06:45',duration:30,repeat:'none',repeatDays:[]});
assert.ok(oneOffConflict, 'nova aula sobreposta à recorrência deve ser bloqueada');
assert.equal(oneOffConflict.date, '2026-10-12');

const otherDay = context.candidateConflict({date:'2026-10-06',time:'06:45',duration:30,repeat:'weekly',repeatDays:[2]});
assert.equal(otherDay, null, 'recorrência em outro dia deve continuar livre');

const recurringConflict = context.candidateConflict({date:'2026-10-05',time:'07:00',duration:30,repeat:'weekly',repeatDays:[1]});
assert.ok(recurringConflict, 'duas recorrências sobrepostas no mesmo dia devem ser bloqueadas');

// Ao editar a própria aula, ela não pode ser tratada como conflito contra si mesma.
const editedSameLesson = {date:'2026-10-05',time:'06:45',duration:60,repeat:'weekly',repeatDays:[1]};
assert.equal(context.candidateConflict(editedSameLesson, 'fixa-seg'), null, 'edição deve ignorar a própria aula na checagem de conflito');
const editedWithoutExclusion = context.candidateConflict(editedSameLesson);
assert.ok(editedWithoutExclusion, 'sem exclusão, a mesma faixa continua sendo reconhecida como ocupada');

// Cancelar uma única ocorrência libera somente aquela data.
context.setStatusBy('fixa-seg','2026-10-05','cancelada');
assert.equal(context.conflictsForSlot('2026-10-05','06:30','07:30').length, 0, 'ocorrência cancelada deve liberar o horário');
assert.equal(context.conflictsForSlot('2026-10-12','06:30','07:30').length, 1, 'próxima recorrência deve continuar ocupada');

// A tela de consulta deve mostrar livre/ocupado usando a mesma agenda.
element('availabilityStart').value='06:30';
element('availabilityEnd').value='07:30';
element('availabilityTimeForm').onsubmit({preventDefault(){}});
assert.match(element('availabilityResult').innerHTML, /LIVRE/);
assert.match(element('availabilityResult').innerHTML, /OCUPADO/);
assert.match(element('availabilityResult').innerHTML, /Aluno A/);
assert.equal((element('availabilityResult').innerHTML.match(/class="compact-availability-day"/g)||[]).length,7,'resumo em sete dias da semana');

console.log('Disponibilidade verificada: sobreposição, recorrência, cancelamento, bloqueio de conflito e busca de dias livres.');
