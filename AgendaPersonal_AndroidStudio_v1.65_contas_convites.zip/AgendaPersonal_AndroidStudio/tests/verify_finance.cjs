const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/professor.html'), 'utf8');
const source = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const initial = {
  students:[{id:'s1',name:'Jéssica',phone:'69999999999',location:'Academia',notes:'',financeEnabled:true,startDate:'2026-10-03',dueDate:'2026-11-03',monthlyValue:'350,00',paymentReminderDays:3}],
  lessons:[{id:'l1',studentId:'s1',date:'2026-10-03',time:'06:45',duration:60,type:'Treino individual',location:'Academia',lead:15,repeat:'weekly',repeatDays:[1],notes:''}],
  occurrenceStatus:{'l1|2026-10-05':'cancelada'},history:[],payments:[]
};
function runtime(seed=initial){
const storage = new Map([['agendaPersonalTL_v1', JSON.stringify(seed)]]);
const elements = new Map();
function element(id){if(!elements.has(id))elements.set(id,{value:'',style:{},dataset:{},innerHTML:'',textContent:'',options:[],querySelector(){return null;},focus(){},setCustomValidity(){},setAttribute(){},removeAttribute(){},getAttribute(){return null;},classList:{names:new Set(),add(...n){n.forEach(v=>this.names.add(v));},remove(...n){n.forEach(v=>this.names.delete(v));},contains(n){return this.names.has(n);},toggle(n,force){const active=force===undefined?!this.names.has(n):!!force;if(active)this.names.add(n);else this.names.delete(n);return active;}},reset(){},addEventListener(){},querySelectorAll(){return []}});return elements.get(id)}
const calls=[],windowEvents=new Map(),documentEvents=new Map(),timers=new Map();let timerId=0;
function listen(map,name,fn){if(!map.has(name))map.set(name,[]);map.get(name).push(fn)}
const native={syncLessonAlarms(json){calls.push(JSON.parse(json));return true},openWhatsAppMessage(phone,msg){calls.push({phone,msg})}};
const context={URL,Date,console,confirm(){return true},setInterval(){},setTimeout(fn,ms){const id=++timerId;timers.set(id,{fn,ms});return id},clearTimeout(id){timers.delete(id)},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},document:{body:element('body'),documentElement:element('html'),querySelector(){return null;},getElementById:element,querySelectorAll(){return []},addEventListener(name,fn){listen(documentEvents,name,fn)},hidden:false},Android:native,window:{scrollTo(){},Android:native,open(){},addEventListener(name,fn){listen(windowEvents,name,fn)}}};
vm.createContext(context);vm.runInContext(html.match(/<script id="ap-timer-compatibility">([\s\S]*?)<\/script>/)[1], context);
vm.runInContext(source,context);
context.dateOnlyNow=()=>new Date(2026,9,4);
return {context,storage,calls,elements,timers,windowEvents,documentEvents};
}
const {context,storage,calls}=runtime();
assert.equal(context.addMonthsSafe('2026-10-03',1),'2026-11-03');
assert.equal(context.addMonthsSafe('2027-01-31',1),'2027-02-28');
const msg=context.chargeMessage(context.studentById('s1'));
assert.match(msg,/69992913628/);assert.match(msg,/Jéssica/);assert.match(msg,/R\$\s*350,00/);
context.openChargeWhatsFor('s1');
const wa=calls.find(x=>x&&x.phone);assert.equal(wa.phone,'69999999999');assert.match(wa.msg,/PIX/);
context.markPaymentPaid('s1');
assert.equal(context.studentById('s1').dueDate,'2026-12-03');
assert.equal(JSON.parse(storage.get('agendaPersonalTL_v1')).payments.length,1);
assert.equal(calls.at(-1).schema,4);
assert.equal(calls.at(-1).students[0].dueDate,'2026-12-03');
context.deleteStudent('s1');
const afterDelete=JSON.parse(storage.get('agendaPersonalTL_v1'));assert.equal(afterDelete.students.length,0);assert.equal(afterDelete.lessons.length,0);assert.equal(Object.keys(afterDelete.occurrenceStatus).length,0);

const financial=runtime({...initial,students:[
 {...initial.students[0],studentType:'presencial',photoDataUrl:'data:image/png;base64,foto-a'},
 {...initial.students[0],id:'s2',studentType:'online',phone:'69988888888',photoDataUrl:'data:image/png;base64,foto-b'},
 {...initial.students[0],id:'s3',dueDate:'2026-10-01'},
 {...initial.students[0],id:'s4',dueDate:'2026-10-04'},
 {...initial.students[0],id:'s5',dueDate:'2026-10-06'},
 {...initial.students[0],id:'s6',financeEnabled:false},
 {...initial.students[0],id:'s7',dueDate:''}
],customData:{keep:'preservado'}});
const fc=financial.context,stored=()=>JSON.parse(financial.storage.get('agendaPersonalTL_v1'));
const before=financial.storage.get('agendaPersonalTL_v1'),studentBefore={...fc.studentById('s1')};
assert.equal(fc.financeStatus(fc.studentById('s1')).kind,'ok');
assert.equal(fc.financeStatus(fc.studentById('s3')).kind,'overdue');
assert.equal(fc.financeStatus(fc.studentById('s4')).kind,'today');
assert.equal(fc.financeStatus(fc.studentById('s5')).kind,'soon');
assert.equal(fc.financeStatus(fc.studentById('s6')).kind,'off');
assert.equal(fc.financeStatus(fc.studentById('s7')).kind,'off');
fc.setFinanceView('current');
assert.equal(financial.elements.get('financeCurrentTabCount').textContent,4);
assert.equal(financial.elements.get('financeOverdueTabCount').textContent,1);
assert.ok(!financial.elements.get('financeList').innerHTML.includes('data-student-id="s3"'));
assert.ok(financial.elements.get('financeList').innerHTML.includes('data-student-id="s1"'));
assert.equal(financial.storage.get('agendaPersonalTL_v1'),before);
fc.markPaymentOverdue('s1');
assert.equal(fc.financeStatus(fc.studentById('s1')).kind,'overdue');
assert.equal(fc.financeStatus(fc.studentById('s1')).manual,true);
assert.equal(fc.studentById('s1').dueDate,studentBefore.dueDate);
assert.equal(fc.studentById('s1').phone,studentBefore.phone);
assert.equal(fc.studentById('s1').photoDataUrl,studentBefore.photoDataUrl);
assert.equal(stored().payments.length,0);
assert.equal(financial.elements.get('financeOverdueTabCount').textContent,2);
assert.ok(financial.elements.get('financeList').innerHTML.includes('data-student-id="s1"'));
assert.ok(!financial.elements.get('financeList').innerHTML.includes('data-student-id="s2"'));
assert.equal(fc.financeStatus(fc.studentById('s2')).kind,'ok');
assert.match(fc.chargeMessage(fc.studentById('s1')),/Sua mensalidade está em atraso/);
assert.doesNotMatch(fc.chargeMessage(fc.studentById('s1')),/venceu em/);
const marked=financial.storage.get('agendaPersonalTL_v1');fc.markPaymentOverdue('s1');assert.equal(financial.storage.get('agendaPersonalTL_v1'),marked);
const reloaded=runtime(stored());assert.equal(reloaded.context.financeStatus(reloaded.context.studentById('s1')).kind,'overdue');
fc.clearPaymentOverdue('s3');assert.equal(financial.storage.get('agendaPersonalTL_v1'),marked);
fc.clearPaymentOverdue('s1');assert.equal(fc.financeStatus(fc.studentById('s1')).kind,'ok');assert.equal(stored().payments.length,0);
assert.ok(financial.elements.get('financeList').innerHTML.includes('data-student-id="s1"'));
fc.markPaymentOverdue('s1');
fc.confirm=()=>false;const cancelled=financial.storage.get('agendaPersonalTL_v1');fc.markPaymentPaid('s1');assert.equal(financial.storage.get('agendaPersonalTL_v1'),cancelled);assert.equal(fc.studentById('s1').paymentOverdue,true);
fc.confirm=()=>true;fc.markPaymentPaid('s1');
assert.equal(fc.studentById('s1').paymentOverdue,false);assert.equal(fc.studentById('s1').dueDate,'2026-12-03');assert.equal(stored().payments.length,1);
assert.equal(stored().payments[0].studentId,'s1');assert.equal(stored().payments[0].dueDate,'2026-11-03');
assert.equal(fc.financeStatus(fc.studentById('s1')).kind,'ok');assert.equal(fc.financeStatus(fc.studentById('s3')).kind,'overdue');
assert.ok(financial.elements.get('financeList').innerHTML.includes('data-student-id="s1"'));
assert.equal(financial.calls.at(-1).students.find(s=>s.id==='s1').dueDate,'2026-12-03');
assert.deepEqual(stored().lessons,initial.lessons);assert.deepEqual(stored().occurrenceStatus,initial.occurrenceStatus);assert.deepEqual(stored().customData,{keep:'preservado'});
const failed=runtime(initial),failureBefore=failed.storage.get('agendaPersonalTL_v1');
failed.context.localStorage.setItem=()=>{throw Error('Sem espaço')};failed.context.markPaymentOverdue('s1');
assert.equal(failed.storage.get('agendaPersonalTL_v1'),failureBefore);assert.equal(failed.context.studentById('s1').paymentOverdue,undefined);
failed.context.markPaymentPaid('s1');assert.equal(failed.storage.get('agendaPersonalTL_v1'),failureBefore);assert.equal(failed.context.studentById('s1').dueDate,'2026-11-03');
assert.equal(vm.runInContext('state.payments.length',failed.context),0);
const undoFailure=runtime({...initial,students:[{...initial.students[0],paymentOverdue:true,overdueDueDate:'2026-11-03'}]});
undoFailure.context.localStorage.setItem=()=>{throw Error('Sem espaço')};undoFailure.context.clearPaymentOverdue('s1');assert.equal(undoFailure.context.studentById('s1').paymentOverdue,true);
const months=runtime({...initial,students:[{...initial.students[0],dueDate:'2026-09-03',paymentOverdue:true,overdueDueDate:'2026-09-03'}]});
months.context.markPaymentPaid('s1');assert.equal(months.context.studentById('s1').dueDate,'2026-10-03');assert.equal(months.context.financeStatus(months.context.studentById('s1')).kind,'overdue');
assert.match(months.elements.get('financeList').innerHTML,/data-student-id="s1"/);
months.context.markPaymentPaid('s1');assert.equal(months.context.studentById('s1').dueDate,'2026-11-03');assert.equal(months.context.financeStatus(months.context.studentById('s1')).kind,'ok');
const stale={...initial.students[0],paymentOverdue:true,overdueDueDate:'2026-10-03'};assert.equal(fc.financeStatus(stale).kind,'ok');
console.log('Financeiro verificado: listas em dia/em atraso, atraso automático e manual, nomes iguais, retirada, pagamento, mês ainda vencido, cancelamento, persistência, PIX, sincronização e falha de armazenamento sem alterar os dados.');

// Keep the app open across midnight and catch up immediately after suspension.
const countdown=runtime({...initial,students:[{...initial.students[0],dueDate:'2026-11-14'}]});
const cc=countdown.context;
let clockTime=new Date(2026,9,15,23,59,59,500).getTime();
cc.Date=class extends Date {constructor(...args){super(...(args.length?args:[clockTime]))}static now(){return clockTime}};
cc.dateOnlyNow=()=>{const n=new cc.Date();return new Date(n.getFullYear(),n.getMonth(),n.getDate())};
cc.setFinanceView('current');cc.resumeFinanceCountdown();
const countdownStudent=cc.studentById('s1'),countdownBefore=countdown.storage.get('agendaPersonalTL_v1');
const htmlCountdown=()=>countdown.elements.get('financeList').innerHTML;
assert.equal(cc.financeStatus(countdownStudent).days,30);
assert.match(htmlCountdown(),/VENCE EM 30 DIAS/i);
const midnight=Array.from(countdown.timers.values()).find(t=>t.fn.toString().includes('scheduleFinanceCountdown'));
assert.equal(midnight.ms,550);
clockTime=new Date(2026,9,16,0,0,0,50).getTime();midnight.fn();
assert.match(htmlCountdown(),/VENCE EM 29 DIAS/i);
assert.equal(Array.from(countdown.timers.values()).filter(t=>t.fn.toString().includes('scheduleFinanceCountdown')).at(-1).ms,86400000);
clockTime=new Date(2026,10,13,18).getTime();
for(const fn of countdown.windowEvents.get('focus'))fn({});
assert.match(htmlCountdown(),/VENCE EM 1 DIA/i);
clockTime=new Date(2026,10,14,8).getTime();
for(const fn of countdown.windowEvents.get('pageshow'))fn({persisted:false});
assert.equal(cc.financeStatus(countdownStudent).kind,'today');assert.match(htmlCountdown(),/VENCE HOJE/i);
clockTime=new Date(2026,10,15,8).getTime();
for(const fn of countdown.documentEvents.get('visibilitychange'))fn({});
assert.equal(cc.financeStatus(cc.studentById('s1')).days,-1);
cc.setFinanceView('overdue');assert.match(htmlCountdown(),/VENCIDA HÁ 1 DIA/i);
assert.equal(countdown.storage.get('agendaPersonalTL_v1'),countdownBefore);
assert.equal(cc.studentById('s1').dueDate,'2026-11-14');
console.log('Contagem verificada: 30 → 29 dias na meia-noite, 1 dia, vence hoje e atraso; retorno por foco, pageshow e visibilidade sem alterar cobranças.');
