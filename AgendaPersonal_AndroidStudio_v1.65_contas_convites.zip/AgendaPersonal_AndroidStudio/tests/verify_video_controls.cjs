'use strict';
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{execFileSync}=require('node:child_process'),{createRequire}=require('node:module');
const {chromium}=createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/')('playwright'),project=path.resolve(__dirname,'..'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'agenda-video-controls-'));
execFileSync('java',['com.sun.tools.javac.Main','-encoding','UTF-8','-d',temp,path.join(project,'app/src/main/java/com/tiagolima/agendapersonal/YouTubePlayerPage.java'),path.join(__dirname,'YouTubePageHarness.java')]);
execFileSync('java',['-cp',temp,'com.tiagolima.agendapersonal.YouTubePageHarness',path.join(temp,'normal.html'),path.join(temp,'inline.html')]);
const inline=fs.readFileSync(path.join(temp,'inline.html'),'utf8');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(req.url==='/clipped'?inline.replace('autoplay:1','autoplay:0').replace('autoStart=true','autoStart=false'):req.url==='/normal'?fs.readFileSync(path.join(temp,'normal.html')):inline)});
const api=`window.__play=0;window.__pause=0;window.__seek=[];window.YT={Player:function(id,config){window.__config=config;window.__fakePlayer=this;
 this.playVideo=function(){window.__play++;config.events.onStateChange({data:1})};this.pauseVideo=function(){window.__pause++;config.events.onStateChange({data:2})};this.seekTo=function(n){__seek.push(n)};
 var frame=document.createElement('iframe');frame.id=id;frame.title='Player de teste';frame.src='about:blank';document.getElementById(id).replaceWith(frame);
 if(location.pathname!='/suspended')queueMicrotask(()=>config.events.onReady({target:this}));}};onYouTubeIframeAPIReady();`;
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const ctx=await browser.newContext({viewport:{width:390,height:720},isMobile:true,hasTouch:true}),errors=[];
  await ctx.route('https://www.youtube.com/iframe_api',r=>r.fulfill({contentType:'text/javascript',body:api}));const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));
  const url='http://127.0.0.1:'+server.address().port;
  await page.goto(url+'/inline');await page.waitForFunction(()=>window.__play===1);
  assert.equal(await page.evaluate(()=>__config.playerVars.controls),0);assert.equal(await page.evaluate(()=>__config.playerVars.start),90);assert.equal(await page.locator('#videoPlay').textContent(),'Pausar');
  await page.locator('#videoPlay').click();assert.equal(await page.evaluate(()=>__pause),1);assert.equal(await page.locator('#videoPlay').textContent(),'Reproduzir');
  await page.locator('#videoPlay').click();assert.equal(await page.evaluate(()=>__play),2);
  await page.locator('#videoRepeat').click();assert.deepEqual(await page.evaluate(()=>__seek),[90]);assert.equal(await page.evaluate(()=>__play),3);
  await page.evaluate(()=>__config.events.onAutoplayBlocked());assert.equal(await page.locator('#videoPlay').textContent(),'Reproduzir');assert.equal(await page.evaluate(()=>__play),3,'blocked autoplay does not loop');
  await page.locator('#videoPlay').click();assert.equal(await page.evaluate(()=>__play),4);
  await page.evaluate(()=>{document.querySelector('main').requestFullscreen=()=>{window.__full=true;return Promise.resolve()}});await page.locator('#videoFull').click();assert.equal(await page.evaluate(()=>__full),true);
  await page.evaluate(()=>{Object.defineProperty(document,'hidden',{value:true,configurable:true});document.dispatchEvent(new Event('visibilitychange'))});assert.equal(await page.locator('#videoPlay').textContent(),'Reproduzir');
  const plays=await page.evaluate(()=>__play);await page.evaluate(()=>__config.events.onStateChange({data:1}));assert.equal(await page.evaluate(()=>__play),plays);assert.equal(await page.locator('#videoPlay').textContent(),'Reproduzir','late playing event cannot resume hidden media');
  await page.goto(url+'/suspended');await page.waitForFunction(()=>window.__fakePlayer);await page.evaluate(()=>{pauseWorkoutVideo();__config.events.onReady({target:__fakePlayer})});assert.equal(await page.evaluate(()=>__play),0,'backgrounded before ready does not start later');
  await page.goto(url+'/clipped');await page.waitForFunction(()=>window.videoReady);assert.equal(await page.evaluate(()=>__config.playerVars.autoplay),0);assert.equal(await page.evaluate(()=>__play),0);await page.locator('#videoPlay').click();assert.equal(await page.evaluate(()=>__play),1);
  for(const [width,height]of [[320,248],[320,844],[390,844],[480,844]]){
   await page.setViewportSize({width,height});await page.goto(url+'/inline');await page.waitForFunction(()=>window.videoReady);
   const layout=await page.evaluate(()=>{const v=document.querySelector('#player').getBoundingClientRect();return{height:v.height,buttons:[...document.querySelectorAll('#videoControls button')].map(e=>{const r=e.getBoundingClientRect();return{left:r.left,right:r.right,bottom:r.bottom,height:r.height,overflow:e.scrollWidth>e.clientWidth+1}})}});
   assert.ok(layout.height>=200);for(const b of layout.buttons){assert.ok(b.left>=0&&b.right<=width&&b.bottom<=height+1&&b.height>=44);assert.equal(b.overflow,false)}
  }
  await page.setViewportSize({width:320,height:248});await page.evaluate(()=>__config.events.onError({data:150}));assert.equal(await page.locator('#videoControls').isVisible(),false);assert.equal(await page.locator('#status a').getAttribute('href'),'https://www.youtube.com/watch?v=M7lc1UVf-VE&t=90');assert.ok((await page.locator('#status a').boundingBox()).y>=200);
  await page.setViewportSize({width:568,height:320});await page.goto(url+'/normal');await page.waitForFunction(()=>window.videoReady);assert.equal(await page.evaluate(()=>document.documentElement.scrollHeight>innerHeight+1),false);
  assert.deepEqual(errors,[]);console.log('PASS: native HTML with simulated YouTube API: one ready→play, external controls, pause/replay/start offset, autoplay-block fallback, fullscreen, background/late-ready prevention, clipped no-autoplay, error link, 200px player/44px controls and mobile widths. No real media playback tested.');
 }finally{await browser.close();server.close();fs.rmSync(temp,{recursive:true,force:true})}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
