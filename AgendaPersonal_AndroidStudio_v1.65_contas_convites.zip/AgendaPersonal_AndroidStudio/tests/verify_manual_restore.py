"""Exercise the production native restore through its buttons and on-disk journal.
Android classes are faked; no device install, network, or signing is simulated as success.
"""
from pathlib import Path
import runpy, shutil, subprocess, tempfile
PROJECT=Path(__file__).resolve().parents[1]
PACKAGE='com/tiagolima/agendapersonal/'
HARNESS=r'''package com.tiagolima.agendapersonal;
import java.nio.file.*;import java.lang.reflect.*;import java.util.concurrent.*;
import android.net.Uri;import android.webkit.WebView;import android.widget.Toast;import android.app.AlertDialog;import org.json.JSONObject;
public class ManualRestoreHarness {
static int checks;
static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
static Object call(Object o,String n)throws Exception{Method m=o.getClass().getDeclaredMethod(n);m.setAccessible(true);return m.invoke(o);}
static JSONObject bundle(int n,String label){String html="<!doctype html><html><head></head><body>"+label+" agendaPersonalTL_v1 syncNativeAlarms<script data-agenda-ready></script></body></html>";return new JSONObject().put("format",1).put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4).put("version","1.12."+n).put("sequence",n).put("files",new JSONObject().put("index.html",html).put("avaliacoes.html",html));}
static class Case implements AutoCloseable {
 final Path folder,updates;final MainActivity activity;final WebView view=new WebView();UpdateManager m;final int base;final String current,prior;
 Case(Path project,String previous)throws Exception{folder=Files.createTempDirectory("manual-restore-");updates=Files.createDirectories(folder.resolve("updates"));activity=new MainActivity(folder.toFile(),project.resolve("app/src/main/assets"));base=UpdateManager.BASE_SEQUENCE;current=bundle(base+2,"CURRENT_RELEASE").toString();prior=bundle(base+1,"PREVIOUS_RELEASE").toString();Files.writeString(updates.resolve("active.json"),current);if(previous.equals("valid"))Files.writeString(updates.resolve("previous.json"),prior);else if(previous.equals("corrupt"))Files.writeString(updates.resolve("previous.json"),"invalid archive");else if(previous.equals("same"))Files.writeString(updates.resolve("previous.json"),current);Files.writeString(updates.resolve("data-before-update.json"),"{\"old-student-data\":\"MUST_NOT_RESTORE\"}");activity.prefs.edit().putBoolean("legacyImported",true).commit();m=new UpdateManager(activity,view);view.reader=m::localResponse;view.snapshot="{\"students\":\"CURRENT_DATA\"}";m.openPage(Uri.parse(LocalPages.HOME));view.awaitLoads(1);view.ready=true;m.pageReady();Toast.shown.clear();}
 void restore()throws Exception{view.ready=false;call(m,"restorePreviousRelease");view.awaitLoads(2);check(activity.prefs.getBoolean("manualRestorePending",false),"Restauração confirmada antes da abertura");check(Boolean.TRUE.equals(field(m,"busy")),"Operação liberada antes de abrir");check(!view.html.contains("localStorage.clear()")&&!view.html.contains("MUST_NOT_RESTORE"),"Restauração manual alterou dados dos alunos");check(Toast.shown.stream().noneMatch(s->s.startsWith("Versão anterior restaurada")),"Sucesso antecipado");}
 void ready(){view.ready=true;m.pageReady();check(!activity.prefs.getBoolean("manualRestorePending",true),"Restauração não confirmada");check(!activity.prefs.getBoolean("restoreData",true),"Restauração de dados antigos habilitada");check(!Files.exists(updates.resolve("release-before-manual-restore.json")),"Diário não removido após sucesso");check(view.snapshot.equals("{\"students\":\"CURRENT_DATA\"}"),"Dados atuais alterados");}
 public void close(){m.destroy();}
}
public static void main(String[] args)throws Exception{Path project=Path.of(args[0]);
try(Case c=new Case(project,"valid")){
 // Hold the network lookup before it starts. Real UI must restore locally while offline/checking.
 ExecutorService network=(ExecutorService)field(c.m,"checkExecutor");CountDownLatch running=new CountDownLatch(1),release=new CountDownLatch(1);network.submit(()->{running.countDown();try{release.await();}catch(InterruptedException ignored){}});check(running.await(2,TimeUnit.SECONDS),"Worker de consulta não iniciou");c.m.setUpdateAccount("R2EmnDVcvMWt7TjPxOP6DjW1VOn1");c.m.showScreen();check(Boolean.TRUE.equals(field(c.m,"checking")),"Consulta não ficou pendente");check(!Boolean.TRUE.equals(field(c.m,"busy")),"Consulta bloqueou restauração local");AlertDialog panel=AlertDialog.lastCreated;android.widget.Button restore=(android.widget.Button)((android.widget.LinearLayout)panel.view).children.get(1);check(restore.enabled,"Botão de restauração desabilitado durante consulta");restore.listener.click(null);check(AlertDialog.lastCreated.title.equals("Restaurar versão anterior?"),"Toque foi ignorado sem confirmação");c.view.ready=false;AlertDialog.lastCreated.getButton(AlertDialog.BUTTON_POSITIVE).listener.click(null);c.view.awaitLoads(2);check(c.view.html.contains("PREVIOUS_RELEASE"),"Botão não carregou versão anterior");check(!c.view.html.contains("localStorage.clear()"),"Botão restaurou dados antigos");check(!Boolean.TRUE.equals(field(c.m,"checking"))&&field(c.m,"manifest")==null,"Consulta antiga permaneceu ativa");check(Toast.shown.stream().noneMatch(s->s.startsWith("Versão anterior restaurada")),"Sucesso antes da confirmação");c.m.pageReady();check(c.activity.prefs.getBoolean("manualRestorePending",false),"Página não pronta confirmou");c.ready();check(Toast.shown.stream().filter(s->s.startsWith("Versão anterior restaurada")).count()==1,"Sucesso não confirmado uma única vez");network.shutdownNow();release.countDown();
}
for(String prior:new String[]{"missing","corrupt","same"})try(Case c=new Case(project,prior)){c.restore();check(!c.view.html.contains("CURRENT_RELEASE")&&!c.view.html.contains("PREVIOUS_RELEASE"),"Sem histórico válido não voltou à base do APK: "+prior);check(field(c.m,"active")==null,"Atualização não foi retirada");c.ready();check(!Files.exists(c.updates.resolve("active.json")),"Arquivo ativo não foi removido");}
try(Case c=new Case(project,"valid")){c.restore();c.m.pageFinished();android.os.Handler.fire();c.view.awaitLoads(3);check(c.view.html.contains("CURRENT_RELEASE"),"Falha de abertura não recuperou a versão atual");check(!c.view.html.contains("localStorage.clear()"),"Falha restaurou snapshot antigo");check(!c.activity.prefs.getBoolean("manualRestorePending",true),"Falha deixou diário pendente");}
try(Case c=new Case(project,"valid")){c.restore();c.m.destroy();c.m=new UpdateManager(c.activity,c.view);c.view.reader=c.m::localResponse;c.m.openPage(Uri.parse(LocalPages.HOME));c.view.awaitLoads(3);check(c.view.html.contains("CURRENT_RELEASE"),"Processo interrompido não recuperou versão atual");check(!c.view.html.contains("localStorage.clear()"),"Reabertura alterou dados");check(!c.activity.prefs.getBoolean("restoreData",true),"Reabertura habilitou dados antigos");}
try(Case c=new Case(project,"valid")){c.activity.prefs.failNextCommit=true;call(c.m,"restorePreviousRelease");long until=System.currentTimeMillis()+3000;while(Boolean.TRUE.equals(field(c.m,"busy"))&&System.currentTimeMillis()<until)Thread.sleep(10);check(Files.readString(c.updates.resolve("active.json")).equals(c.current),"Falha ao salvar preferências perdeu a versão atual");check(!c.activity.prefs.getBoolean("manualRestorePending",false),"Falha iniciou restauração");}
System.out.println("PASS: "+checks+" verificações da restauração manual: botão durante consulta/offline, versão anterior/base, histórico corrompido/duplicado, confirmação após abrir, falha de abertura, interrupção e falha de gravação; dados atuais preservados. Java real, Android APIs fakes; sem instalação em aparelho.");
}}
'''
def main():
 stubs=dict(runpy.run_path(str(PROJECT/'tests/verify_native_updates.py'))['STUBS']);stubs.pop(PACKAGE+'NativeUpdateHarness.java')
 k='android/app/AlertDialog.java';stubs[k]=stubs[k].replace('d.getButton(BUTTON_POSITIVE).setText(s);return this;', 'd.getButton(BUTTON_POSITIVE).setText(s);if(o!=null)d.getButton(BUTTON_POSITIVE).setOnClickListener(v->o.onClick(d,BUTTON_POSITIVE));return this;')
 k=PACKAGE+'MainActivity.java';stubs[k]=stubs[k].replace('private final Map<String,Boolean> data=', 'public volatile boolean failNextCommit;private final Map<String,Boolean> data=').replace('public boolean commit(){data.putAll(next);return true;}', 'public boolean commit(){if(failNextCommit){failNextCommit=false;return false;}data.putAll(next);return true;}')
 stubs[PACKAGE+'ManualRestoreHarness.java']=HARNESS
 java=shutil.which('java');assert java,'Java 17 necessário';javac=shutil.which('javac');compiler=[javac]if javac else[java,'com.sun.tools.javac.Main']
 with tempfile.TemporaryDirectory(prefix='agenda-manual-restore-') as tmp:
  root=Path(tmp);sources=[]
  for name,text in stubs.items():
   p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);sources.append(str(p))
  sources += [str(PROJECT/'app/src/main/java'/PACKAGE/(n+'.java'))for n in ['UpdateManager','LocalPages','UpdateManifest']]
  subprocess.run(compiler+['-encoding','UTF-8','-d',str(root/'classes')]+sources,check=True)
  subprocess.run([java,'-cp',str(root/'classes'),'com.tiagolima.agendapersonal.ManualRestoreHarness',str(PROJECT)],check=True)
if __name__=='__main__':main()
