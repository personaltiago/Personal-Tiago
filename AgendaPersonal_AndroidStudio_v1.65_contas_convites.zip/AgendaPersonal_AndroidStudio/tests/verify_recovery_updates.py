"""Regression for recovery 1.11.81 (sequence 90) blocking release 1.11.84 (85).

Runs the current production importer with Android API fakes and real HTML/file bytes.
Older counters are simulated with the current bridge contract; this does not emulate an old APK.
Optional installed/rejected/fixed .agenda.json arguments exercise delivered files.
The default fixture keeps the known recovery metadata and uses project assets.
This is not an Android SDK build or a device installation test.
"""
from pathlib import Path
import json
import re
import runpy
import shutil
import subprocess
import sys
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
NATIVE = PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateManager.java'
PACKAGE = 'com/tiagolima/agendapersonal/'
HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.AlertDialog;import android.net.Uri;import android.webkit.WebView;import android.widget.Toast;
import java.nio.file.*;import java.lang.reflect.*;import org.json.JSONObject;
public final class RecoveryUpdateHarness {
static int checks;
static void check(boolean b,String m){checks++;if(!b)throw new AssertionError(m);}
static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
static void set(Object o,String n,Object v)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
static void invoke(UpdateManager m,String n)throws Exception{Method f=UpdateManager.class.getDeclaredMethod(n);f.setAccessible(true);f.invoke(m);}
static String description(UpdateManager m)throws Exception{Method f=UpdateManager.class.getDeclaredMethod("description",String.class);f.setAccessible(true);return(String)f.invoke(m,"");}
static void settled(UpdateManager m)throws Exception{long until=System.currentTimeMillis()+10000;while(Boolean.TRUE.equals(field(m,"busy"))&&System.currentTimeMillis()<until)Thread.sleep(10);check(!Boolean.TRUE.equals(field(m,"busy")),"Importação não terminou");}
static void approveImport(UpdateManager m)throws Exception{long until=System.currentTimeMillis()+5000;AlertDialog review;do{review=(AlertDialog)field(m,"reviewDialog");if(review!=null&&review.isShowing()&&review.getButton(AlertDialog.BUTTON_POSITIVE).listener!=null)break;Thread.sleep(5);}while(System.currentTimeMillis()<until);check(review!=null&&review.getButton(AlertDialog.BUTTON_POSITIVE).listener!=null,"Revisão não apareceu");review.getButton(AlertDialog.BUTTON_POSITIVE).listener.click(null);}
static String stripMarker(String html){int start=html.indexOf("<script>window.__agendaNativeReleaseToken=");if(start<0)throw new AssertionError("Marcador ausente");int end=html.indexOf("</script>",start)+9;if(html.startsWith("<script>window.addEventListener('error'",end))end=html.indexOf("</script>",end)+9;if(!html.startsWith(NativeLaunch.HTML,end))throw new AssertionError("Alinhamento nativo ausente");end+=NativeLaunch.HTML.length();return html.substring(0,start)+html.substring(end);}
static JSONObject register(Path inputs,String name,String version,int sequence)throws Exception{
String index=Files.readString(inputs.resolve(name+"-index.html")),eval=Files.readString(inputs.resolve(name+"-avaliacoes.html"));
JSONObject b=new JSONObject().put("format",1).put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",3).put("dataSchema",4).put("version",version).put("sequence",sequence).put("notes",Files.readString(inputs.resolve(name+"-notes.txt"))).put("files",new JSONObject().put("index.html",index).put("avaliacoes.html",eval));
JSONObject.register(Files.readString(inputs.resolve(name+".json")),b);return b;}
static void confirm(UpdateManager m,MainActivity a,WebView v){
check(a.prefs.getBoolean("pending",false),"Confirmação antes da abertura");v.ready=false;m.pageReady();check(a.prefs.getBoolean("pending",false),"Página antiga confirmou a atualização");v.ready=true;m.pageReady();check(!a.prefs.getBoolean("pending",true),"Nova página não confirmou");}
public static void main(String[] args)throws Exception{
Path project=Path.of(args[0]),inputs=Path.of(args[1]),folder=Files.createTempDirectory("agenda-gap-");boolean old=args[2].equals("old");
JSONObject installed=register(inputs,"installed",args[3],Integer.parseInt(args[4]));
JSONObject rejected=register(inputs,"rejected",args[5],Integer.parseInt(args[6]));
JSONObject fixed=register(inputs,"fixed",args[7],Integer.parseInt(args[8]));
byte[] installedBytes=Files.readAllBytes(inputs.resolve("installed.json"));Files.createDirectories(folder.resolve("updates"));Files.write(folder.resolve("updates/active.json"),installedBytes);
MainActivity activity=new MainActivity(folder.toFile(),project.resolve("app/src/main/assets"));WebView view=new WebView();
view.snapshot="{\"agendaPersonalTL_v1\":\"alunos-fichas-histórico-á\",\"outro\":\"valor\"}";
UpdateManager manager=new UpdateManager(activity,view);manager.setUpdateAccount("R2EmnDVcvMWt7TjPxOP6DjW1VOn1");view.reader=manager::localResponse;AlertDialog dialog=new AlertDialog();set(manager,"dialog",dialog);
String home="https://appassets.androidplatform.net/assets/index.html",eval="https://appassets.androidplatform.net/assets/avaliacoes.html?agendaStudentId=aluno-2&name=Ana%20Silva";
try {
manager.openPage(Uri.parse(home));view.awaitLoads(1);check(home.equals(view.base)&&home.equals(view.history),"Origem de armazenamento mudou");
if(old){
 check(description(manager).contains("Versão instalada: 1.11.81"),"Recuperação não carregada");
 check(stripMarker(view.html).equals(installed.getJSONObject("files").getString("index.html")),"Conteúdo da recuperação mudou");
 int before=view.loads;manager.importUri(Uri.parse(inputs.resolve("rejected.json").toUri().toString()));settled(manager);
 check(view.loads==before,"Pacote 85 entrou sobre a sequência 90");
 check(Toast.shown.stream().noneMatch(s->s.startsWith("Arquivo recebido")),"Versão anterior foi anunciada como recebida");
 check(java.util.Arrays.equals(installedBytes,Files.readAllBytes(folder.resolve("updates/active.json"))),"Rejeição alterou a versão ativa");
 check(!Files.exists(folder.resolve("updates/data-before-update.json")),"Rejeição copiou dados");
 check(!activity.prefs.getBoolean("pending",false),"Rejeição iniciou instalação");
 manager.importUri(Uri.parse(inputs.resolve("fixed.json").toUri().toString()));approveImport(manager);view.awaitLoads(before+1);
 check(stripMarker(view.html).equals(fixed.getJSONObject("files").getString("index.html")),"Arquivo corrigido não abriu integralmente");
 check(view.html.contains("__agendaNativeReleaseSequence="+fixed.optInt("sequence")),"Contador da nova página incorreto");
 check(home.equals(view.base)&&home.equals(view.history),"Importação mudou a origem dos dados");
 check(Files.readString(folder.resolve("updates/data-before-update.json")).equals(view.snapshot),"Cópia UTF-8 incompleta");
 check(Toast.shown.stream().noneMatch(s->s.startsWith("Atualização aplicada")),"Sucesso anunciado antes da confirmação");
 confirm(manager,activity,view);check(description(manager).contains("Versão instalada: "+fixed.optString("version")),"Versão instalada exibida errada");
 check(Toast.shown.stream().filter(s->s.startsWith("Atualização aplicada")).count()==1,"Sucesso não confirmado uma única vez");
 int accepted=view.loads;byte[] activeBytes=Files.readAllBytes(folder.resolve("updates/active.json"));
 manager.importUri(Uri.parse(inputs.resolve("fixed.json").toUri().toString()));settled(manager);
 check(view.loads==accepted,"Duplicata foi instalada");check(java.util.Arrays.equals(activeBytes,Files.readAllBytes(folder.resolve("updates/active.json"))),"Duplicata alterou arquivos");
 manager.openPage(Uri.parse(eval));view.awaitLoads(accepted+1);check(eval.equals(view.base)&&eval.equals(view.history),"Avaliação perdeu parâmetros");
 check(stripMarker(view.html).equals(fixed.getJSONObject("files").getString("avaliacoes.html")),"Avaliação incorreta");
 view.snapshot="{\"agendaPersonalTL_v1\":\"novos-dados-após-atualizar\"}";
 invoke(manager,"restorePreviousRelease");view.awaitLoads(accepted+2);view.ready=true;manager.pageReady();settled(manager);
 check(description(manager).contains("1.11.81"),"Restauração manual não voltou à recuperação");
 check(!activity.prefs.getBoolean("restoreData",false),"Restauração manual puxou dados antigos");
 check(stripMarker(view.html).equals(installed.getJSONObject("files").getString("index.html")),"Recuperação anterior alterada");
 manager.importUri(Uri.parse(inputs.resolve("fixed.json").toUri().toString()));approveImport(manager);view.awaitLoads(accepted+3);
 check(Files.readString(folder.resolve("updates/data-before-update.json")).equals(view.snapshot),"Reimportação não preservou os dados atuais");confirm(manager,activity,view);
 manager.destroy();manager=new UpdateManager(activity,view);manager.setUpdateAccount("R2EmnDVcvMWt7TjPxOP6DjW1VOn1");view.reader=manager::localResponse;manager.openPage(Uri.parse(home));view.awaitLoads(accepted+4);
 check(description(manager).contains(fixed.optString("version")),"Reabertura perdeu a versão confirmada");
 check(stripMarker(view.html).equals(fixed.getJSONObject("files").getString("index.html")),"Reabertura perdeu as páginas");
}else{
 check(field(manager,"active")==null,"APK novo foi substituído pela recuperação de sequência 90");
 check(description(manager).contains("Versão instalada: "+fixed.optString("version")),"Base do APK novo errada");
 check(stripMarker(view.html).equals(Files.readString(project.resolve("app/src/main/assets/index.html"))),"APK novo abriu páginas antigas");
 manager.importUri(Uri.parse(inputs.resolve("fixed.json").toUri().toString()));settled(manager);check(view.loads==1,"Pacote já incluído no APK foi reinstalado");
 check(!activity.prefs.getBoolean("pending",false),"Duplicata marcou pendência");
}
System.out.println((old?"APK anterior":"APK corrigido")+": "+checks+" verificações passaram.");
}finally{manager.destroy();}
}
}'''


def default_bundle(version, sequence):
    return dict(format=1, appId='com.tiagolima.agendapersonal', bridgeVersion=3,
                dataSchema=4, version=version, sequence=sequence, notes='Pacote de teste da recuperação e preservação dos dados.',
                files={n:(PROJECT/'app/src/main/assets'/n).read_text()
                       for n in ('index.html', 'avaliacoes.html')})


def main():
    source = NATIVE.read_text()
    version = re.search(r'BASE_VERSION = "([0-9.]+)"', source).group(1)
    sequence = int(re.search(r'BASE_SEQUENCE = (\d+);', source).group(1))
    assert sequence > 90, 'A sequência da entrega deve superar a recuperação 1.11.81 / 90.'
    if len(sys.argv) == 4:
        raw = [Path(p).read_bytes() for p in sys.argv[1:]]
        bundles = [json.loads(b) for b in raw]
    else:
        assert len(sys.argv) == 1, 'Forneça os três arquivos: instalado, rejeitado e corrigido.'
        bundles = [default_bundle('1.11.81',90), default_bundle('1.11.84',85), default_bundle(version,sequence)]
        raw = [json.dumps(b,ensure_ascii=False,separators=(',',':')).encode() for b in bundles]
    installed, rejected, fixed = bundles
    assert installed['version']=='1.11.81' and installed['sequence']==90
    assert rejected['version']=='1.11.84' and rejected['sequence']==85
    assert fixed['version']==version and fixed['sequence']==sequence
    assert fixed['sequence'] > max(installed['sequence'], rejected['sequence'])
    for b,data in zip(bundles,raw):
        assert len(data) < 12*1024*1024
        assert b['format']==1 and b['appId']=='com.tiagolima.agendapersonal'
        assert b['bridgeVersion']==3 and b['dataSchema']==4
        assert set(b['files'])=={'index.html','avaliacoes.html'}
    for n,html in fixed['files'].items():
        assert html==(PROJECT/'app/src/main/assets'/n).read_text()
    stubs=dict(runpy.run_path(str(PROJECT/'tests/verify_native_updates.py'))['STUBS'])
    stubs.pop(PACKAGE+'NativeUpdateHarness.java')
    stubs['org/json/JSONObject.java']=stubs['org/json/JSONObject.java'].replace('public JSONObject(){}', 'public static void register(String s,JSONObject value){saved.put(s,new LinkedHashMap<>(value.fields));}\npublic JSONObject(){}')
    stubs['android/widget/TextView.java']='package android.widget; public class TextView {public String value="";public void setText(String s){value=s;}public void setPadding(int a,int b,int c,int d){}}'
    stubs['android/app/AlertDialog.java']=stubs['android/app/AlertDialog.java'].replace('public boolean isShowing()', 'public final android.widget.TextView text=new android.widget.TextView(); public boolean isShowing()').replace('public <T>T findViewById(int i){return null;}', '@SuppressWarnings("unchecked") public <T>T findViewById(int i){return (T)text;}')
    stubs[PACKAGE+'RecoveryUpdateHarness.java']=HARNESS
    java=shutil.which('java');assert java, 'Java 17 é necessário.'
    javac=shutil.which('javac');compiler=[javac] if javac else [java,'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-recovery-tests-') as temp:
        work=Path(temp);inputs=work/'inputs';inputs.mkdir()
        params=[]
        for name,b,data in zip(('installed','rejected','fixed'),bundles,raw):
            (inputs/(name+'.json')).write_bytes(data)
            (inputs/(name+'-notes.txt')).write_text(b['notes'])
            for n,html in b['files'].items():
                (inputs/(name+'-'+n)).write_text(html)
            params.extend([b['version'],str(b['sequence'])])
        sources=[str(PROJECT/'app/src/main/java'/PACKAGE/n) for n in ('LocalPages.java','UpdateManifest.java','NativeLaunch.java')]
        for name,text in stubs.items():
            p=work/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);sources.append(str(p))
        target=work/(PACKAGE+'UpdateManager.java')
        for base_version,base_sequence,mode in [('1.11.78',79,'old'),('1.11.81',82,'old'),('1.11.84',85,'old'),(version,sequence,'new')]:
            simulated=re.sub(r'BASE_VERSION = "[0-9.]+"', 'BASE_VERSION = "'+base_version+'"',source)
            simulated=re.sub(r'BASE_SEQUENCE = \d+;', 'BASE_SEQUENCE = '+str(base_sequence)+';',simulated)
            target.write_text(simulated)
            subprocess.run(compiler+['-encoding','UTF-8','-d',str(work/'classes')]+sources+[str(target)],check=True,text=True)
            result=subprocess.run([java,'-cp',str(work/'classes'),'com.tiagolima.agendapersonal.RecoveryUpdateHarness',str(PROJECT),str(inputs),mode]+params,capture_output=True,text=True)
            if result.returncode: raise RuntimeError(result.stdout+result.stderr)
            print('Base '+base_version+' / '+str(base_sequence)+' — '+result.stdout.strip())
    print('Rejeição 90→85 e aceitação 90→'+str(sequence)+' verificadas com páginas completas, dados, confirmação, duplicata e restauração.')


if __name__ == '__main__':
    main()
