"""Compile the real importer and verify content-based reinstalls/restores with Android API fakes.
No network, signed APK, Android SDK build, or physical device is used.
"""
from pathlib import Path
import runpy, shutil, subprocess, tempfile
PROJECT=Path(__file__).resolve().parents[1]
PACKAGE='com/tiagolima/agendapersonal/'
original=runpy.run_path(str(PROJECT/'tests/verify_update_import_review.py'))['HARNESS']
PREFIX=original.split('public static void main(String[] args)')[0].replace('UpdateReviewHarness','RecoveryContentHarness')
HARNESS=PREFIX+r'''public static void main(String[] args)throws Exception{
 Path project=Path.of(args[0]),folder=Files.createTempDirectory("agenda-content-"),file=folder.resolve("selected.json");
 int base=UpdateManager.BASE_SEQUENCE;
 JSONObject installed=release(base+10,"1.12.205","Versão atual.","current-205");
 Files.createDirectories(folder.resolve("updates"));byte[] original=installed.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);Files.write(folder.resolve("updates/active.json"),original);
 MainActivity activity=new MainActivity(folder.toFile(),project.resolve("app/src/main/assets"));WebView view=new WebView();
 UpdateManager manager=new UpdateManager(activity,view);view.reader=manager::localResponse;manager.setUpdateAccount(TEACHER);
 try{
 manager.openPage(Uri.parse(LocalPages.HOME));view.awaitLoads(1);int loads=view.loads;
 JSONObject duplicate=release(base+100,"1.12.999","Apenas os rótulos foram trocados.","current-205");
 String html=duplicate.getJSONObject("files").getString("index.html");duplicate.put("files",new JSONObject().put("avaliacoes.html",html).put("index.html",html));
 Files.writeString(file,duplicate.toString());manager.importUri(Uri.parse(file.toUri().toString()));waitFor(manager,false);
 check(field(manager,"reviewDialog")==null,"Metadados novos transformaram conteúdo idêntico em atualização");unchanged(folder,original,activity,view,loads);
 check(UpdateIdentity.compareVersions("1.12.204","1.12.205")<0,"Comparação de versões incorreta");
 check(UpdateIdentity.compareVersions("1.12.100000000000000000000","1.12.9")>0,"Componente longo causou overflow");
 JSONObject lower=release(base-5,"1.12.204","Conteúdo anterior selecionado pelo professor.","restore-204");
 AlertDialog review=select(manager,file,lower);
 check(review.title.equals("Revisar restauração"),"Versão menor não foi apresentada como restauração");
 check(review.message.contains("pode retirar funções mais recentes"),"Efeito de restaurar não foi explicado");
 check(review.getButton(AlertDialog.BUTTON_POSITIVE).text.equals("Restaurar esta versão"),"Confirmação de restauração ausente");
 unchanged(folder,original,activity,view,loads);click(review,AlertDialog.BUTTON_NEGATIVE);waitFor(manager,false);unchanged(folder,original,activity,view,loads);
 review=select(manager,file,lower);click(review,AlertDialog.BUTTON_POSITIVE);view.awaitLoads(loads+1);
 check(view.html.contains("restore-204"),"Arquivo menor diferente não abriu");
 check(activity.prefs.getBoolean("pending",false),"Sucesso foi registrado antes da abertura");
 check(new JSONObject(Files.readString(folder.resolve("updates/active.json"))).optInt("sequence")==base-5,"A sequência foi renumerada para contornar o teste");
 check(Arrays.equals(original,Files.readAllBytes(folder.resolve("updates/previous.json"))),"A versão mais recente não foi guardada");
 view.ready=true;manager.pageReady();waitFor(manager,false);
 Path journal=folder.resolve("updates/verified-release.json");long until=System.currentTimeMillis()+5000;while(!Files.exists(journal)&&System.currentTimeMillis()<until)Thread.sleep(5);
 check(Files.exists(journal),"Falta registro após abertura confirmada");JSONObject verified=new JSONObject(Files.readString(journal));
 check(verified.optString("version").equals("1.12.204")&&verified.optInt("sequence")==base-5,"Registro não identifica a versão realmente aberta");
 JSONObject status=new JSONObject(manager.distributionStatus());
 check(status.optBoolean("contentVerified")&&status.optString("installedContentSha256").equals(verified.optString("contentSha256")),"Registro não corresponde ao conteúdo servido");
 manager.destroy();manager=new UpdateManager(activity,view);manager.setUpdateAccount(TEACHER);view.reader=manager::localResponse;int before=view.loads;manager.openPage(Uri.parse(LocalPages.HOME));view.awaitLoads(before+1);
 check(((JSONObject)field(manager,"active")).optInt("sequence")==base-5&&view.html.contains("restore-204"),"Reabrir descartou um conteúdo válido só pela sequência menor que a base do APK");
 view.ready=true;manager.pageReady();
 java.lang.reflect.Method previous=UpdateManager.class.getDeclaredMethod("previousVersion");previous.setAccessible(true);check(previous.invoke(manager).equals("1.12.205"),"Cópia com número maior foi ignorada");
 view.snapshot="{\"agendaPersonalTL_v1\":\"dados-atualizados-depois-da-restauracao\"}";
 java.lang.reflect.Method restore=UpdateManager.class.getDeclaredMethod("restorePreviousRelease");restore.setAccessible(true);before=view.loads;restore.invoke(manager);view.awaitLoads(before+1);view.ready=true;manager.pageReady();waitFor(manager,false);
 check(view.html.contains("current-205"),"Não foi possível retornar ao backup com numeração maior");
 check(!activity.prefs.getBoolean("restoreData",false)&&!view.html.contains("localStorage.clear()"),"Retorno manual substituiu dados atuais por snapshot antigo");
 JSONObject patched=release(base+10,"1.12.205","Correção diferente com a mesma numeração.","patched-205");
 review=select(manager,file,patched);check(review.title.equals("Revisar reinstalação"),"Mesma numeração com arquivos diferentes foi rejeitada");
 JSONObject current=(JSONObject)field(manager,"active");before=view.loads;byte[] beforeRace=Files.readAllBytes(folder.resolve("updates/active.json"));
 set(manager,"active",release(base+10,"1.12.205","Outra instalação de mesmo número.","concurrent"));click(review,AlertDialog.BUTTON_POSITIVE);waitFor(manager,false);
 check(view.loads==before&&Arrays.equals(beforeRace,Files.readAllBytes(folder.resolve("updates/active.json"))),"Troca de conteúdo com a mesma sequência escapou da confirmação");set(manager,"active",current);
 review=select(manager,file,patched);String priorIdentity=new JSONObject(manager.distributionStatus()).optString("installedContentSha256");before=view.loads;click(review,AlertDialog.BUTTON_POSITIVE);view.awaitLoads(before+1);view.ready=true;manager.pageReady();waitFor(manager,false);
 check(view.html.contains("patched-205"),"Reinstalação de mesmo número não abriu o conteúdo escolhido");
 check(!new JSONObject(manager.distributionStatus()).optString("installedContentSha256").equals(priorIdentity),"Identidade não mudou com o conteúdo real");
 JSONObject bad=release(base-6,"1.12.204","Candidato que não conclui a abertura.","broken-204");review=select(manager,file,bad);before=view.loads;view.ready=false;click(review,AlertDialog.BUTTON_POSITIVE);view.awaitLoads(before+1);manager.pageFinished();android.os.Handler.fire();view.awaitLoads(before+2);
 check(view.html.contains("patched-205")&&!view.html.contains("broken-204"),"Falha ao abrir versão menor não recuperou o conteúdo anterior");
 check(activity.prefs.getBoolean("restoreData",false),"Falha de abertura não protegeu o snapshot de dados atual");view.ready=true;manager.pageReady();waitFor(manager,false);
 byte[] safe=Files.readAllBytes(folder.resolve("updates/active.json"));before=view.loads;JSONObject invalid=release(base+200,"1.12.206","Contrato incompatível.","invalid").put("dataSchema",99);Files.writeString(file,invalid.toString());manager.importUri(Uri.parse(file.toUri().toString()));waitFor(manager,false);
 check(field(manager,"reviewDialog")==null&&view.loads==before&&Arrays.equals(safe,Files.readAllBytes(folder.resolve("updates/active.json"))),"Conferência de conteúdo removeu a validação de compatibilidade");
 System.out.println(checks+" verificações: conteúdo idêntico com rótulo diferente, restauração 205→204, versão abaixo da base, reinício, retorno ao backup maior, reinstalação de mesmo número, troca concorrente, rollback e dados preservados. Sem APK assinado ou aparelho físico.");
 }finally{manager.destroy();}
}
}'''

def main():
 stubs=dict(runpy.run_path(str(PROJECT/'tests/verify_native_updates.py'))['STUBS'])
 stubs.pop(PACKAGE+'NativeUpdateHarness.java');stubs[PACKAGE+'RecoveryContentHarness.java']=HARNESS
 java=shutil.which('java');assert java,'Java 17 é necessário.'
 compiler=[shutil.which('javac')] if shutil.which('javac') else [java,'com.sun.tools.javac.Main']
 with tempfile.TemporaryDirectory(prefix='agenda-content-tests-') as temp:
  work=Path(temp);sources=[str(PROJECT/'app/src/main/java'/PACKAGE/n) for n in ('UpdateManager.java','UpdateStorage.java','UpdateExport.java','UpdateDownloads.java','UpdateIdentity.java','LocalPages.java','UpdateManifest.java','NativeLaunch.java')]
  for name,text in stubs.items():
   p=work/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);sources.append(str(p))
  subprocess.run(compiler+['-encoding','UTF-8','-d',str(work/'classes')]+sources,check=True)
  subprocess.run([java,'-cp',str(work/'classes'),'com.tiagolima.agendapersonal.RecoveryContentHarness',str(PROJECT)],check=True)
if __name__=='__main__':main()
