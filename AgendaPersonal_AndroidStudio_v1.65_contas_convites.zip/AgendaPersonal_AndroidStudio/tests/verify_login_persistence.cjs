'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../web/login-session.js'),'utf8');
async function preferences(){
 const data=new Map(),box={},calls=[];let localBlocked=false,sessionBlocked=false,fail=new Set();
 const storage=blocked=>({getItem:k=>data.get(k)||null,setItem(k,v){if(blocked())throw Error('storage blocked');data.set(k,String(v))},removeItem:k=>data.delete(k)});
 const ctx={localStorage:storage(()=>localBlocked),sessionStorage:storage(()=>sessionBlocked),document:{getElementById:()=>box}};ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(source,ctx);
 const sdk={auth:{},browserLocalPersistence:'LOCAL',indexedDBLocalPersistence:'INDEXED',browserSessionPersistence:'SESSION',async setPersistence(_,p){calls.push(p);if(fail.has(p))throw Error('not available')}};
 await ctx.APLoginSession.configure(sdk,true);assert.deepEqual(calls,['LOCAL']);assert.equal(data.get('agenda_remember_login_v1'),'true');ctx.APLoginSession.restoreChoice();assert.equal(box.checked,true);
 calls.length=0;localBlocked=true;await ctx.APLoginSession.configure(sdk,true);assert.deepEqual(calls,['INDEXED'],'blocked Safari localStorage uses durable IndexedDB');
 localBlocked=false;calls.length=0;fail.add('LOCAL');await ctx.APLoginSession.configure(sdk,true);assert.deepEqual(calls,['LOCAL','INDEXED']);fail.add('INDEXED');await assert.rejects(()=>ctx.APLoginSession.configure(sdk,true),/manter o acesso/);assert.ok(!calls.includes('SESSION'),'never silently downgrade remember-me to a session');
 fail.clear();calls.length=0;await ctx.APLoginSession.configure(sdk,false);assert.deepEqual(calls,['SESSION']);ctx.APLoginSession.restoreChoice();assert.equal(box.checked,false);sessionBlocked=true;await assert.rejects(()=>ctx.APLoginSession.configure(sdk,false),/iniciar uma sessão/);
 assert.deepEqual([...data.keys()],['agenda_remember_login_v1'],'application stores only a boolean preference, no credentials');
}
const {createHarness}=require('./verify_shell_boot.cjs'),tick=()=>new Promise(setImmediate),providers={browserLocalPersistence:'LOCAL',indexedDBLocalPersistence:'INDEXED',browserSessionPersistence:'SESSION'};
async function app({saved=null,profileFail=false,disabled=false}={}){
 let mode='LOCAL',persisted=saved,signins=0,signouts=0,profileReads=0,fail=profileFail,hold=false,release,authCallback;
 const profile=()=>({perfil:'aluno',professorId:'R2EmnDVcvMWt7TjPxOP6DjW1VOn1',ativo:!disabled,nome:'Aluna'}),auth={currentUser:saved,authStateReady:async()=>{}};
 const sdk={...providers,getApps:()=>[],initializeApp:()=>({}),getAuth:()=>auth,getFirestore:()=>({}),onAuthStateChanged(a,fn){authCallback=fn;queueMicrotask(()=>fn(a.currentUser));return ()=>{}},
  async setPersistence(_,p){mode=p},async signInWithEmailAndPassword(_,email,password){signins++;assert.equal(password,'not-stored');auth.currentUser={uid:'alice',email};persisted=mode==='SESSION'?null:auth.currentUser;return {user:auth.currentUser}},
  async signOut(){signouts++;auth.currentUser=null;persisted=null;authCallback?.(null)},doc:(_, ...p)=>p.join('/'),async getDoc(){profileReads++;if(hold)await new Promise(r=>release=r);if(fail)throw {code:'unavailable'};return {exists:()=>true,data:profile}},onSnapshot:()=>()=>{}};
 const h=createHarness({bootstrap({ctx,element,storage}){ctx.__startupImport=()=>Promise.resolve(sdk);storage.set('agendaPersonalTL_v1','{"custom":"preserved"}');element('remember').checked=false;ctx.navigator.onLine=true;}});
 await tick();await tick();return {...h,sdk,auth,state:()=>({mode,persisted,signins,signouts,profileReads}),fail:v=>fail=v,hold:v=>hold=v,release:()=>release?.()};
}
async function integration(){
 let h=await app();h.ctx.showLogin('Aluno');h.element('email').value='alice@example.test';h.element('password').value='not-stored';h.element('remember').checked=true;
 await h.ctx.APaccounts.login({preventDefault(){},stopImmediatePropagation(){}});assert.equal(h.state().mode,'LOCAL');assert.equal(h.ctx.__AP_STUDENT_CONTEXT.storageId,'alice');assert.equal(h.element('password').value,'');assert.equal(h.storage.get('agenda_remember_login_v1'),'true');assert.equal(h.storage.get('agendaPersonalTL_v1'),'{"custom":"preserved"}');
 const saved=h.state().persisted;h=await app({saved});assert.equal(h.ctx.__AP_STUDENT_CONTEXT.storageId,'alice','reopen restores approved exact account without password');assert.equal(h.state().signins,0);
 await h.ctx.APaccounts.logout();assert.equal(h.state().persisted,null);h.ctx.dispatchEvent(new h.ctx.Event('pageshow'));await tick();assert.equal(h.ctx.__AP_STUDENT_CONTEXT,null,'explicit logout cannot be revived');assert.equal(h.state().signouts,1);
 h=await app();h.ctx.showLogin('Aluno');h.element('email').value='alice@example.test';h.element('password').value='not-stored';h.element('remember').checked=false;await h.ctx.APaccounts.login({preventDefault(){},stopImmediatePropagation(){}});assert.equal(h.state().mode,'SESSION');assert.equal(h.state().persisted,null);
 h=await app({saved,profileFail:true});assert.equal(h.ctx.__AP_STUDENT_CONTEXT,null,'profile must still be verified');assert.equal(h.auth.currentUser.uid,'alice','network failure does not erase SDK authentication');h.fail(false);h.hold(true);const before=h.state().profileReads;h.ctx.dispatchEvent(new h.ctx.Event('online'));h.ctx.dispatchEvent(new h.ctx.Event('pageshow'));await tick();assert.equal(h.state().profileReads,before+1,'deduplicate concurrent restore attempts');h.release();await tick();assert.equal(h.ctx.__AP_STUDENT_CONTEXT.storageId,'alice');assert.equal(h.state().signins,0,'reconnection never requests or resubmits password');
 h=await app({saved,disabled:true});assert.equal(h.ctx.__AP_STUDENT_CONTEXT,null,'remember-me never bypasses teacher approval');assert.match(h.element('apAccountStatus').textContent,/aprovação/);
 h=await app({saved,profileFail:true});h.fail(false);h.hold(true);h.ctx.dispatchEvent(new h.ctx.Event('online'));await tick();await h.ctx.APaccounts.logout();h.release();await tick();assert.equal(h.ctx.__AP_STUDENT_CONTEXT,null,'late approval cannot undo explicit logout');
}
(async()=>{await preferences();await integration();console.log('PASS: remember checkbox selects durable/session SDK persistence; local/IndexedDB fallback; blocked-storage errors; reopens without password; network recovery deduplicates; approval and logout races preserved. Actual shipped scripts, DOM/Firebase simulated.');})().catch(e=>{console.error(e);process.exitCode=1});
