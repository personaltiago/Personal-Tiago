'use strict';
// Runs the REAL ap-save-guard script from each page with small fakes. It checks the decision (banner or not),
// not how the banner looks on a device.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const file=process.argv[2]||path.join(__dirname,'..','web','native-release.agenda.json');
const files=JSON.parse(fs.readFileSync(file,'utf8')).files;
let cases=0;const eq=(n,a,b)=>{cases++;assert.deepEqual(a,b,n)};
function el(tag){const e={tag,children:[],style:{},listeners:{},attrs:{},setAttribute(k,v){e.attrs[k]=v},addEventListener(t,f){e.listeners[t]=f},append(...c){e.children.push(...c)},appendChild(c){e.children.push(c)},remove(){e.removed=true}};return e}
for(const page of ['index.html','professor.html','avaliacoes.html']){
 const m=files[page].match(/<script id="ap-save-guard">([\s\S]*?)<\/script>/);assert.ok(m,'Proteção de salvamento ausente em '+page);
 assert.ok(files[page].indexOf('id="ap-save-guard"')<files[page].indexOf('<script',files[page].indexOf('id="ap-save-guard"')+10),page+': posição');
 const listeners={},body=el('body'),timers=[];let now=1e6;
 const win={addEventListener(t,f){listeners[t]=f}},doc={body,createElement:el,addEventListener(){}};
 const sandbox={window:win,document:doc,Date:{now:()=>now,...Date},setTimeout:f=>timers.push(f),console};
 sandbox.Date=class extends Date{static now(){return now}};
 vm.createContext(sandbox);vm.runInContext(m[1],sandbox);
 const banner=()=>body.children.filter(c=>c.attrs.role==='alert'&&!c.removed);
 const quota=Object.assign(new Error("Failed to execute 'setItem' on 'Storage': exceeded the quota."),{name:'QuotaExceededError'});
 listeners.error({error:quota});
 eq(page+': erro de armazenamento mostra o aviso',banner().length,1);
 const text=banner()[0].children[0].textContent;eq(page+': texto em português',/Não foi possível salvar.*backup/.test(text),true);
 listeners.unhandledrejection({reason:quota});eq(page+': não repete em menos de 30 s',banner().length,1);
 now+=31000;listeners.unhandledrejection({reason:quota});eq(page+': repete depois de 30 s',banner().length,2);
 now+=31000;const before=banner().length;listeners.error({error:new TypeError('x is undefined')});listeners.unhandledrejection({reason:new Error('rede caiu')});
 eq(page+': outros erros não mostram o aviso',banner().length,before);
 const guard=win.APSaveGuard;eq(page+': registra erros para diagnóstico',guard.errors().length>=4,true);
 eq(page+': detecta erro de cota',[guard.isStorageError(quota),guard.isStorageError(new Error('ok'))],[true,false]);
 banner()[0].children[1].listeners.click();eq(page+': botão Entendi fecha o aviso',banner()[0]===undefined||banner().length<before+2,true);
}
console.log('Proteção de salvamento: '+cases+' verificações passaram em index, professor e avaliações. Sem aparelho físico.');
