"""Compile all production Java sources against the real Android APIs."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--android-jar', type=Path, required=True)
    parser.add_argument('--androidx-jar', type=Path, required=True)
    parser.add_argument('--dependency-dir', type=Path, help='Additional dependency API jars, including ML Kit.')
    args = parser.parse_args()
    jars = [args.android_jar.resolve(), args.androidx_jar.resolve()]
    if args.dependency_dir:
        jars.extend(sorted(args.dependency_dir.resolve().glob('*.jar')))
    for jar in jars:
        if not jar.is_file():
            parser.error(f'Missing API jar: {jar}')
    sources = sorted((PROJECT / 'app/src/main/java').rglob('*.java')) + sorted((PROJECT / 'watch-common/src/main/java').rglob('*.java'))
    if not sources:
        parser.error('No production Java sources found.')
    javac, java = shutil.which('javac'), shutil.which('java')
    if not javac and not java:
        parser.error('Java 17 is required.')
    compiler = [javac] if javac else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-android-compile-') as directory:
        subprocess.run(compiler + [
            '-encoding', 'UTF-8', '-source', '17', '-target', '17',
            '-classpath', os.pathsep.join(str(jar) for jar in jars),
            '-d', directory,
        ] + [str(source) for source in sources], check=True)
    print(f'{len(sources)} production Java files compiled against the real Android APIs.')


if __name__ == '__main__':
    main()
