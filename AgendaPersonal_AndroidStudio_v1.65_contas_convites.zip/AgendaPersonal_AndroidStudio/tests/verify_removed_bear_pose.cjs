'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),g=vm.createContext({});
vm.runInContext(fs.readFileSync(path.join(root,'web/student-mascot-model.js'),'utf8'),g);
const M=g.APMascotModel,manifest=JSON.parse(fs.readFileSync(path.join(root,'web/mascot-poses/manifest.json'))),landmarks=JSON.parse(fs.readFileSync(path.join(root,'web/bear-pose-landmarks.json')));
assert.deepEqual(Array.from(M.posesFor('panda'),p=>p.id),['default','sit','rest']);
assert.equal(M.catalog.some(p=>p.id==='pose-panda-play'),false);
assert.equal(Object.hasOwn(manifest.panda,'play'),false);
assert.equal(fs.readdirSync(path.join(root,'web/mascot-poses')).some(n=>n.startsWith('panda-play-')),false);
assert.equal(Object.keys(landmarks.poses).some(k=>k.startsWith('play:')),false);
for(const choice of M.choices.filter(c=>c.id!=='panda'))assert.deepEqual(Array.from(M.posesFor(choice.id),p=>p.id),['default','sit','rest','play']);
let legacy=0;
for(const xp of [0,600,1800])for(const color of M.colorsFor('panda')){
 const saved={...M.fresh(),species:'panda',name:'Léo',xp,coins:2317,colors:{panda:color.id,wolf:'black'},poses:{panda:'play',wolf:'play'},owned:['home-yard','home-bamboo','pose-panda-play','pose-panda-sit','pose-wolf-play'],equipped:{head:'',body:'',home:'home-bamboo'},events:[{at:12345,text:'Compra anterior'}]};
 const before=JSON.stringify(saved),s=M.read(saved);
 assert.equal(M.pose(saved).id,'default');assert.equal(M.pose(s).id,'default');assert.equal(s.poses.panda,undefined);assert.equal(s.poses.wolf,'play');
 assert.ok(s.owned.includes('pose-panda-play'),'retain retired purchase for existing owners');
 for(const key of ['xp','coins','name','events','equipped'])assert.deepEqual(JSON.parse(JSON.stringify(s[key])),JSON.parse(JSON.stringify(saved[key])),key+' preserved');
 for(const [action,id]of [['pose','play'],['buy','pose-panda-play'],['use','pose-panda-play']])assert.equal(M.change(saved,action,id).ok,false,'retired pose cannot be restored through '+action);
 assert.equal(JSON.stringify(saved),before,'reading or rejecting retired selection never mutates stored source');
 assert.equal(M.change(s,'pose','sit').state.coins,2317,'existing available purchase still usable for free');
 legacy++;
}
const html=fs.readFileSync(path.join(root,'app/src/main/assets/cadastro.html'),'utf8'),match=html.match(/<script\b([^>]*\bid="ap-mascot-pose-assets"[^>]*)>([\s\S]*?)<\/script>/i);
assert.ok(match,'shipped pose collection');const shipped=JSON.parse(/data-ap-gzip/.test(match[1])?zlib.gunzipSync(Buffer.from(match[2],'base64')).toString():match[2]);
assert.deepEqual(Object.keys(shipped.panda).sort(),['rest','sit']);
for(const species of Object.keys(manifest))assert.deepEqual(Object.keys(shipped[species]).sort(),Object.keys(manifest[species]).sort());
console.log('PASS: retired belly-up bear removed from catalog, artwork, rig and shipped assets; '+legacy+' legacy phase/coat selections cannot restore it; purchase record, currency, XP, history, homes and other animals retained.');
