"""Exercise production overlay lifecycle with Android fakes, never a device claim."""
from pathlib import Path
import importlib.util
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('alarm_fakes', ROOT/'tests/verify_native_alarms.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
STUBS = dict(module.STUBS)
STUBS.update({
    'android/os/IBinder.java': 'package android.os;public interface IBinder{}',
    'android/os/Looper.java': 'package android.os;public class Looper{public static Looper getMainLooper(){return new Looper();}}',
    'android/os/Handler.java': '''package android.os;import java.util.*;public class Handler{public static List<Runnable> tasks=new ArrayList<>();public Handler(Looper l){}public void removeCallbacks(Runnable r){tasks.removeIf(x->x==r);}public boolean postDelayed(Runnable r,long t){tasks.add(r);return true;}public static void next(){List<Runnable> copy=new ArrayList<>(tasks);tasks.clear();for(Runnable r:copy)r.run();}}''',
    'android/os/SystemClock.java': 'package android.os;public class SystemClock{public static long elapsedRealtime(){return java.lang.System.currentTimeMillis();}}',
    'android/content/res/Configuration.java': 'package android.content.res;public class Configuration{}',
    'android/util/DisplayMetrics.java': 'package android.util;public class DisplayMetrics{public float density=1;public int widthPixels=390,heightPixels=844;}',
    'android/content/res/Resources.java': 'package android.content.res;public class Resources{public final android.util.DisplayMetrics metrics=new android.util.DisplayMetrics();public android.util.DisplayMetrics getDisplayMetrics(){return metrics;}}',
    'android/app/Service.java': '''package android.app;public class Service extends android.content.Context{public static final int START_NOT_STICKY=2,STOP_FOREGROUND_REMOVE=1;public boolean stopped,foreground;public void onCreate(){}public int onStartCommand(android.content.Intent i,int f,int s){return 0;}public android.os.IBinder onBind(android.content.Intent i){return null;}public void onConfigurationChanged(android.content.res.Configuration c){}public void onDestroy(){}public void startForeground(int i,Notification n){foreground=true;notifications.notify(i,n);}public void stopForeground(int f){foreground=false;}public void stopSelf(){stopped=true;}public void startActivity(android.content.Intent i){}}''',
    'android/graphics/Color.java': 'package android.graphics;public class Color{public static int WHITE=-1,TRANSPARENT=0;public static int parseColor(String s){return (int)Long.parseLong(s.substring(1),16);}public static int rgb(int r,int g,int b){return r<<16|g<<8|b;}}',
    'android/graphics/PixelFormat.java': 'package android.graphics;public class PixelFormat{public static final int TRANSLUCENT=-3;}',
    'android/graphics/Typeface.java': 'package android.graphics;public class Typeface{public static final Typeface MONOSPACE=new Typeface();public static final int BOLD=1;}',
    'android/graphics/drawable/GradientDrawable.java': 'package android.graphics.drawable;public class GradientDrawable{public void setColor(int c){}public void setCornerRadius(float r){}public void setStroke(int w,int c){}}',
    'android/text/TextUtils.java': 'package android.text;public class TextUtils{public enum TruncateAt{END}}',
    'android/view/MotionEvent.java': 'package android.view;public class MotionEvent{public static final int ACTION_DOWN=0,ACTION_UP=1,ACTION_MOVE=2,ACTION_CANCEL=3;int a;float x,y;public MotionEvent(int a,float x,float y){this.a=a;this.x=x;this.y=y;}public int getActionMasked(){return a;}public float getRawX(){return x;}public float getRawY(){return y;}}',
    'android/view/ViewConfiguration.java': 'package android.view;public class ViewConfiguration{public static ViewConfiguration get(android.content.Context c){return new ViewConfiguration();}public int getScaledTouchSlop(){return 8;}}',
    'android/view/Gravity.java': 'package android.view;public class Gravity{public static final int LEFT=3,TOP=48,CENTER_HORIZONTAL=1,CENTER_VERTICAL=16,CENTER=17;}',
    'android/view/View.java': '''package android.view;public class View{public interface OnClickListener{void onClick(View v);}public interface OnTouchListener{boolean onTouch(View v,MotionEvent e);}public OnTouchListener touch;public void setOnTouchListener(OnTouchListener t){touch=t;}public int getHeight(){return 64;}public OnClickListener click;public CharSequence description;public void setPadding(int a,int b,int c,int d){}public void setContentDescription(CharSequence s){description=s;}public void setOnClickListener(OnClickListener l){click=l;}public void performClick(){if(click!=null)click.onClick(this);}public void setBackground(Object d){}public void setElevation(float v){}}''',
    'android/view/WindowManager.java': '''package android.view;public class WindowManager{public View root;public LayoutParams params;public boolean reject;public void addView(View v,LayoutParams p){if(reject)throw new SecurityException();root=v;params=p;}public void removeView(View v){if(root==v)root=null;}public void updateViewLayout(View v,LayoutParams p){params=p;}public static class LayoutParams{public static final int TYPE_APPLICATION_OVERLAY=2038,FLAG_NOT_FOCUSABLE=8,FLAG_NOT_TOUCH_MODAL=32;public int width,height,type,flags,gravity,x,y;public LayoutParams(int w,int h,int t,int f,int p){width=w;height=h;type=t;flags=f;}}}''',
    'android/widget/TextView.java': '''package android.widget;public class TextView extends android.view.View{public CharSequence text="";public TextView(android.content.Context c){}public void setText(CharSequence s){text=s;}public void setGravity(int g){}public void setTextColor(int c){}public void setTextSize(float s){}public void setLetterSpacing(float f){}public void setSingleLine(boolean b){}public void setEllipsize(android.text.TextUtils.TruncateAt t){}public void setTypeface(android.graphics.Typeface t,int s){}}''',
    'android/widget/Button.java': '''package android.widget;public class Button extends TextView{public Button(android.content.Context c){super(c);}public void setBackgroundColor(int c){}public void setMinWidth(int n){}public void setMinimumWidth(int n){}}''',
    'android/widget/LinearLayout.java': '''package android.widget;import java.util.*;public class LinearLayout extends android.view.View{public static final int HORIZONTAL=0,VERTICAL=1;public final List<android.view.View> children=new ArrayList<>();public LinearLayout(android.content.Context c){}public void setOrientation(int n){}public void setGravity(int n){}public void addView(android.view.View v){children.add(v);}public void addView(android.view.View v,LayoutParams p){children.add(v);}public static class LayoutParams{public LayoutParams(int w,int h){}public LayoutParams(int w,int h,float weight){}}}''',
    'com/tiagolima/agendapersonal/MainActivity.java': 'package com.tiagolima.agendapersonal;public class MainActivity extends android.app.Activity{}',
})

STUBS['android/content/Context.java'] = STUBS['android/content/Context.java'].replace('POWER_SERVICE="power"', 'POWER_SERVICE="power",WINDOW_SERVICE="window"').replace('public boolean granted=true;', 'public boolean granted=true;public final android.view.WindowManager windows=new android.view.WindowManager();public final android.content.res.Resources resources=new android.content.res.Resources();public int starts;public android.content.Intent startForegroundService(android.content.Intent i){starts++;return i;}public android.content.res.Resources getResources(){return resources;}').replace('switch(n){', 'switch(n){case WINDOW_SERVICE:return windows;')
STUBS['android/content/Intent.java'] = STUBS['android/content/Intent.java'].replace('FLAG_ACTIVITY_NEW_TASK=1,', 'FLAG_ACTIVITY_NEW_TASK=1,FLAG_ACTIVITY_SINGLE_TOP=16,')
STUBS['android/provider/Settings.java'] = STUBS['android/provider/Settings.java'].replace('public class Settings {', 'public class Settings {public static boolean allowed=true;public static boolean canDrawOverlays(android.content.Context c){return allowed;}')
STUBS['android/R.java'] = STUBS['android/R.java'].replace('ic_lock_idle_alarm=1,', 'ic_lock_idle_alarm=1,ic_menu_close_clear_cancel=7,')
STUBS['android/app/Notification.java'] = STUBS['android/app/Notification.java'].replace('public class Notification {', 'public class Notification {public static final String CATEGORY_STOPWATCH="stopwatch";').replace('public Builder setAutoCancel(boolean b)', 'public Builder setOngoing(boolean b){return this;}public Builder setOnlyAlertOnce(boolean b){return this;}public Builder setUsesChronometer(boolean b){return this;}public Builder setChronometerCountDown(boolean b){return this;}public Builder setAutoCancel(boolean b)')
# Existing alarm fakes already define channel lockscreen visibility.
STUBS['android/app/NotificationManager.java'] = STUBS['android/app/NotificationManager.java'].replace('public class NotificationManager{', 'public class NotificationManager{public void notify(int i,Notification n){notify("overlay",i,n);}')
STUBS['android/app/PendingIntent.java'] = STUBS['android/app/PendingIntent.java'].replace('public class PendingIntent {', 'public class PendingIntent {public static PendingIntent getService(android.content.Context c,int i,android.content.Intent n,int f){return getBroadcast(c,i,n,f);}')
STUBS['com/tiagolima/agendapersonal/OverlayHarness.java'] = r'''package com.tiagolima.agendapersonal;
import java.util.*;import org.json.JSONObject;import android.content.*;import android.os.*;import android.widget.*;
public class OverlayHarness{
 static int checks;static void check(boolean b,String s){checks++;if(!b)throw new AssertionError(s);}
 static void save(Context c,String key,long end,String kind)throws Exception{AlarmStore.savePlan(c,new JSONObject().put("alarmKey",key).put("student","Aluno teste").put("triggerAtMillis",end).put("kind",kind));}
 static LessonTimerOverlayService service(){LessonTimerOverlayService s=new LessonTimerOverlayService();s.onCreate();return s;}
 public static void main(String[] a)throws Exception{
  long now=System.currentTimeMillis();
  List<LessonTimerOverlayModel.Timer> mixed=Arrays.asList(new LessonTimerOverlayModel.Timer("lesson","A",now+60000),new LessonTimerOverlayModel.Timer("expired","B",now-1,"workout-rest","Agachamento","#9CC72C"),new LessonTimerOverlayModel.Timer("rest","C",now+30000,"workout-rest","Prancha","#9CC72C"));
  List<LessonTimerOverlayModel.Timer> live=LessonTimerOverlayModel.active(mixed,now);check(live.size()==1&&live.get(0).key.equals("rest"),"only active rest can float");
  check(LessonTimerOverlayModel.clock(1).equals("00:01"),"ceil fractional second");check(LessonTimerOverlayModel.clock(-1).equals("00:00"),"no negative clock");
  LessonTimerOverlayService s=service();save(s,"timer|lesson|today",now+110000,"timer");save(s,"lesson",now+150000,"lesson");
  android.provider.Settings.allowed=true;check(!LessonTimerOverlayService.refresh(s,true)&&s.starts==0,"lesson-only timers cannot open a window even explicitly");
  s.onStartCommand(new Intent(s,LessonTimerOverlayService.class),0,1);check(s.stopped&&!LessonTimerOverlayService.isShowing()&&s.windows.root==null,"legacy lesson service invocation leaves no window");check(AlarmStore.plans(s).size()==2,"lesson alarms are preserved");
  save(s,"rest",now+50000,"workout-rest");android.provider.Settings.allowed=false;check(!LessonTimerOverlayService.refresh(s,false),"rest still requires permission");
  android.provider.Settings.allowed=true;check(LessonTimerOverlayService.refresh(s,true),"rest can still be shown");s.onStartCommand(new Intent(s,LessonTimerOverlayService.class),0,2);
  check(LessonTimerOverlayService.isShowing()&&s.windows.root!=null,"rest attaches its window");check(LessonTimerOverlayService.showingKind().equals("workout-rest"),"rest kind unchanged");check(s.windows.params.width==286,"rest stays compact");check((s.windows.params.flags&8)!=0&&(s.windows.params.flags&32)!=0,"rest does not steal focus");
  LinearLayout row=(LinearLayout)s.windows.root;
  check(((TextView)row.children.get(0)).description.toString().equals("Arrastar cronômetro do intervalo"),"dedicated accessible grip");
  check(((TextView)((LinearLayout)row.children.get(1)).children.get(0)).text.toString().equals("INTERVALO"),"compact heading without student prefix");
  check(s.windows.params.x==12&&s.windows.params.y==652,"bottom-left default position");
  android.view.View grip=row.children.get(0);grip.touch.onTouch(grip,new android.view.MotionEvent(0,20,660));grip.touch.onTouch(grip,new android.view.MotionEvent(2,50,500));grip.touch.onTouch(grip,new android.view.MotionEvent(1,50,500));
  check(s.windows.params.x==42&&s.windows.params.y==492,"grip moves system window");
  check(s.getSharedPreferences("agenda_lesson_timer_overlay",0).getLong("compact_x",-1)==42,"compact position saved");((Button)row.children.get(3)).performClick();check(!LessonTimerOverlayService.isShowing(),"rest close works");check(LessonTimerOverlayService.isDismissed(s),"web bridge can suppress fallback after native X");check(AlarmStore.plans(s).size()==3,"closing window preserves all alarms");check(!LessonTimerOverlayService.refresh(s,false),"rest remains dismissed");check(LessonTimerOverlayService.refresh(s,true),"rest explicitly reopens");
  s.onStartCommand(new Intent(s,LessonTimerOverlayService.class),0,3);AlarmStore.removePlan(s,"rest");Handler.next();check(!LessonTimerOverlayService.isShowing()&&s.windows.root==null,"rest end never reveals a lesson overlay");check(AlarmStore.plans(s).size()==2,"rest window expiry never removes lesson alarms");
  check(!LessonTimerOverlayService.refresh(s,false),"returning to app cannot reveal remaining lesson timers");
  System.out.println("PASS: "+checks+" production model/service checks: only rest floats; lesson alarms preserved; dismissal, permission and expiry retained. Android APIs simulated.");
 }
}'''



def main():
    import xml.etree.ElementTree as ET
    manifest = ET.parse(ROOT/'app/src/main/AndroidManifest.xml')
    ns = '{http://schemas.android.com/apk/res/android}'
    service = next(x for x in manifest.findall('./application/service') if x.get(ns+'name') == '.LessonTimerOverlayService')
    assert service.get(ns+'exported') == 'false' and service.get(ns+'foregroundServiceType') == 'specialUse'
    permissions = {x.get(ns+'name') for x in manifest.findall('uses-permission')}
    assert all('android.permission.'+p in permissions for p in ['SYSTEM_ALERT_WINDOW', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_SPECIAL_USE'])
    native = (ROOT/'app/src/main/java/com/tiagolima/agendapersonal/MainActivity.java').read_text()
    assert 'AlarmScheduler.startLessonTimer(activity, new JSONObject(timerJson));' in native
    assert 'offerFloatingTimer(false)' not in native
    lesson_bridge = native.split('@JavascriptInterface public void showLessonTimerOverlay() {', 1)[1].split('}', 1)[0]
    assert 'offerFloatingTimer(' not in lesson_bridge
    assert 'showWorkoutRestOverlay()' in native
    assert '@JavascriptInterface public void showLessonTimerOverlay()' in native
    with tempfile.TemporaryDirectory(prefix='lesson-overlay-') as folder:
        root = Path(folder)
        sources = []
        skip = {'android/app/AlertDialog.java', 'android/content/DialogInterface.java'}
        for name, code in STUBS.items():
            if name in skip or name.startswith('com/tiagolima/agendapersonal/') and name not in ['com/tiagolima/agendapersonal/OverlayHarness.java', 'com/tiagolima/agendapersonal/MainActivity.java']:
                continue
            p = root/name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(code)
            sources.append(str(p))
        sources += [str(ROOT/'app/src/main/java/com/tiagolima/agendapersonal'/n) for n in ['LessonTimerOverlayModel.java', 'LessonTimerOverlayService.java', 'AlarmStore.java']]
        import shutil
        java = shutil.which('java') or '/usr/lib/jvm/java-17-openjdk-amd64/bin/java'
        subprocess.run([java, 'com.sun.tools.javac.Main', '-encoding', 'UTF-8', '-d', str(root/'classes')]+sources, check=True)
        subprocess.run([java, '-cp', str(root/'classes'), 'com.tiagolima.agendapersonal.OverlayHarness'], check=True)


if __name__ == '__main__':
    main()
