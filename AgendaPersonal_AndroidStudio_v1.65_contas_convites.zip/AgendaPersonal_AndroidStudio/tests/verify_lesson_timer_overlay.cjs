const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const html=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/professor.html'),'utf8');
const begin=html.indexOf('function lessonCountdownHtml('),end=html.indexOf('function cancelNativeLessonTimer(',begin);assert.ok(begin>=0&&end>begin);
const timer={lessonId:'lesson',date:'2026-10-20',native:true,endAt:Date.now()+60000};
const context={window:{Android:{}},Date,hesc:String,uiIcon:()=>'',lessonTimerLabel:()=>'',lessonTimerHelp:()=>'',formatTimerMs:()=> '01:00'};
vm.createContext(context);vm.runInContext(html.slice(begin,end),context);
const card=context.lessonCountdownHtml(timer,'lesson|2026-10-20');assert.ok(card.includes('01:00'));assert.ok(card.includes('lesson-timer-stop'));assert.ok(!card.includes('lesson-timer-float'));assert.ok(!html.includes('Mostrar no alto da tela'));assert.ok(!html.includes('function showFloatingLessonTimer'));
assert.ok(html.includes('id="ap-rest-floating"'));assert.ok(html.includes('showWorkoutRestOverlay'));assert.ok(html.includes('id="workoutRestCounter"'));
console.log('PASS: lesson reopening action removed, inline lesson countdown/stop retained, floating rest widget and native rest action retained.');
