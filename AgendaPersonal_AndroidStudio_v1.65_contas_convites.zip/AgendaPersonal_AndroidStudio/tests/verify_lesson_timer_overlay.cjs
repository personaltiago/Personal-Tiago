const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const html=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/professor.html'),'utf8');
const begin=html.indexOf('function lessonCountdownHtml('),end=html.indexOf('function cancelNativeLessonTimer(',begin);
assert.ok(begin>=0&&end>begin);
const timer={lessonId:'lesson',date:'2026-10-20',native:true,endAt:Date.now()+60000};
let calls=0,message='';
const context={window:{},Android:{showLessonTimerOverlay(){calls++}},Date,hesc:String,uiIcon:()=>'',lessonTimerLabel:()=>'',lessonTimerHelp:()=>'',formatTimerMs:()=> '01:00',toast:s=>message=s};
vm.createContext(context);vm.runInContext(html.slice(begin,end),context);
function button(){return context.lessonCountdownHtml(timer,'lesson|2026-10-20').match(/<button class="btn timer lesson-timer-float"[^>]*>/)[0]}
assert.match(button(),/ hidden/,'web and older APK hide native-only feature');
context.window.Android=context.Android;
assert.doesNotMatch(button(),/ hidden/,'new APK offers re-open for armed active timer');
context.showFloatingLessonTimer();assert.equal(calls,1);
timer.endAt=Date.now()-1;assert.match(button(),/ hidden/,'expired timer cannot start overlay');
timer.endAt=Date.now()+60000;timer.native=false;assert.match(button(),/ hidden/,'unarmed timer cannot claim native overlay');
context.window.Android=undefined;context.showFloatingLessonTimer();assert.match(message,/Android 1.144/);assert.equal(calls,1);
console.log('PASS: actual generated teacher HTML: bridge action, older APK/web compatibility, expiry and native-alarm requirement.');
