package com.tiagolima.agendapersonal;

import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/** Executable protocol checks; run with a real org.json implementation on the classpath. */
public final class GoogleSignInProtocolChecks {
    private static int checks;
    private static final String CLIENT = "1044097605904-fixture.apps.googleusercontent.com";
    private static final String ENDPOINT = "https://accounts.google.com/o/oauth2/auth?client_id=";
    private static void check(boolean value) { if (!value) throw new AssertionError("check " + checks); checks++; }
    private static void reject(String endpoint) throws Exception {
        try { GoogleSignInProtocol.clientId(new JSONObject().put("authUri", endpoint)); }
        catch (Exception expected) { checks++; return; }
        throw new AssertionError("Invalid Google endpoint accepted");
    }
    private static JSONObject payload(String nonce) throws Exception {
        return new JSONObject().put("iss", "https://accounts.google.com").put("aud", CLIENT)
            .put("exp", 2000).put("nonce", nonce);
    }
    private static String token(JSONObject payload) {
        return "fixture-header." + Base64.getUrlEncoder().withoutPadding()
            .encodeToString(payload.toString().getBytes(StandardCharsets.UTF_8)) + ".fixture-signature";
    }
    public static void main(String[] args) throws Exception {
        check(GoogleSignInProtocol.validRequest("0123456789abcdef0123456789abcdef"));
        for (String value : new String[]{null, "short", "x".repeat(101), "x".repeat(20) + "\n", "<script>".repeat(3)})
            check(!GoogleSignInProtocol.validRequest(value));
        String nonce = GoogleSignInProtocol.nonce();
        check(nonce.matches("[A-Za-z0-9_-]{43}"));
        check(!nonce.equals(GoogleSignInProtocol.nonce()));
        check(CLIENT.equals(GoogleSignInProtocol.clientId(new JSONObject().put("authUri", ENDPOINT + CLIENT + "&scope=email"))));
        reject("http://accounts.google.com/oauth?client_id=" + CLIENT);
        reject("https://accounts.google.com.evil.test/oauth?client_id=" + CLIENT);
        reject("https://evil.test/oauth?client_id=" + CLIENT);
        reject("https://user@accounts.google.com/oauth?client_id=" + CLIENT);
        reject("https://accounts.google.com:443/oauth?client_id=" + CLIENT);
        reject(ENDPOINT + "other-project.apps.googleusercontent.com");
        reject(ENDPOINT + CLIENT + "&client_id=" + CLIENT);
        reject("https://accounts.google.com/oauth?scope=email");
        check(GoogleSignInProtocol.boundToken(token(payload(nonce)), CLIENT, nonce, 1000));
        check(!GoogleSignInProtocol.boundToken(token(payload("another-request")), CLIENT, nonce, 1000));
        check(!GoogleSignInProtocol.boundToken(token(payload(nonce).put("aud", "other-client")), CLIENT, nonce, 1000));
        check(!GoogleSignInProtocol.boundToken(token(payload(nonce).put("iss", "https://evil.test")), CLIENT, nonce, 1000));
        check(!GoogleSignInProtocol.boundToken(token(payload(nonce).put("exp", 999)), CLIENT, nonce, 1000));
        check(!GoogleSignInProtocol.boundToken(token(payload(nonce).put("nonce", "")), CLIENT, nonce, 1000));
        check(!GoogleSignInProtocol.boundToken("malformed", CLIENT, nonce, 1000));
        check(!GoogleSignInProtocol.boundToken("x".repeat(65537), CLIENT, nonce, 1000));
        check(!GoogleSignInProtocol.boundToken(null, CLIENT, nonce, 1000));
        System.out.println(checks + " Google request binding checks passed; signature authentication belongs to Firebase.");
    }
}
