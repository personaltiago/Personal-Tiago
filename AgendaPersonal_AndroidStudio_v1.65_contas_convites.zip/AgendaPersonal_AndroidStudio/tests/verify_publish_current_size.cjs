'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),http=require('node:http'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),MAX=24*1024*1024;
const release=JSON.parse(fs.readFileSync(path.join(root,'release.json'),'utf8'));
const text=process.argv[2]?fs.readFileSync(process.argv[2],'utf8'):JSON.stringify({format:1,appId:release.applicationId,bridgeVersion:3,dataSchema:4,version:release.contentVersion,sequence:release.sequence,files:Object.fromEntries(['index.html','professor.html','avaliacoes.html','cadastro.html'].map(n=>[n,fs.readFileSync(path.join(root,'app/src/main/assets',n),'utf8')]))}),bundle=JSON.parse(text),android=text.replaceAll('/','\\/');
assert.ok(Buffer.byteLength(text)<=MAX);assert.ok(Buffer.byteLength(android)>MAX,'Android slash escaping reproduces oversize bridge serialization');
assert.deepEqual(JSON.parse(android),bundle);
const source=fs.readFileSync(path.join(root,'web/distribution-controls.js'),'utf8');
const shipped=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8').match(/<script id="ap-distribution-controls">([\s\S]*?)<\/script>/)[1];
const prior=source.replace('setSelection(JSON.stringify(JSON.parse(raw)))','setSelection(raw)');
const manifest={available:true,version:bundle.version,sequence:bundle.sequence,size:Buffer.byteLength(text),sha256:crypto.createHash('sha256').update(text).digest('hex')};
(async()=>{
 const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<html><body></body></html>')});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  for(const [code,old]of [[prior,true],[shipped,false]]){
   const page=await browser.newPage({viewport:{width:390,height:844}});await page.route('https://**/*',r=>r.abort());await page.goto('http://127.0.0.1:'+server.address().port);
   await page.evaluate(({android,manifest})=>{
    window.teacher=true;window.raw=android;window.sent=null;window.applied=null;window.authCalls=0;
    window.APaccounts={isTeacher:()=>teacher,getPublicationToken:async()=>{authCalls++;return 'fixture'}};window.toast=()=>{};
    window.Android={getPublishableUpdate:()=>raw,applyPublishedUpdate:m=>{applied=JSON.parse(m)}};
    window.fetch=async()=>({ok:true,json:async()=>manifest});
    window.cryptoMock=manifest;window.XMLHttpRequest=class{
     constructor(){this.upload={addEventListener(){}}}open(){}setRequestHeader(){}
     send(body){sent=body;this.status=201;this.responseText=JSON.stringify({published:true,manifest});queueMicrotask(()=>this.onload())}
    };
   },{android,manifest});
   await page.addScriptTag({content:code});await page.evaluate(()=>APupdates.openPublisher());await page.locator('#apPublishCurrent').click();await page.waitForFunction(()=>!document.getElementById('apPublishStatus').textContent.startsWith('Preparando'));
   assert.equal(await page.locator('#apPublishSend').isDisabled(),old,old?'old publisher reproduces failure':'normalized publisher accepts installed update');
   if(old){await page.close();continue}
   assert.match(await page.locator('#apPublishSelected').textContent(),new RegExp(bundle.version));
   await page.locator('#apPublishSend').click();await page.waitForFunction(()=>document.getElementById('apPublishStatus').dataset.kind==='success');
   assert.equal(await page.evaluate(()=>sent),text,'uploaded bytes are exactly canonical delivered artifact');assert.deepEqual(await page.evaluate(()=>JSON.parse(sent).files),bundle.files,'no HTML or runtime data changed');
   assert.equal(await page.evaluate(()=>applied.sequence),bundle.sequence);assert.equal(await page.evaluate(()=>authCalls),1);
   for(const [raw,error]of [['',/ler a versão/],['{',/incompleta/],[JSON.stringify({...bundle,files:{}}),/compatível/],[JSON.stringify({...bundle,files:{...bundle.files,'cadastro.html':bundle.files['cadastro.html']+'x'.repeat(100000)}}),/24 MB/]]){
    await page.evaluate(raw=>{APupdates.closePublisher();APupdates.openPublisher();window.raw=raw},raw);await page.locator('#apPublishCurrent').click();await page.waitForFunction(()=>document.getElementById('apPublishStatus').dataset.kind==='error');
    assert.equal(await page.locator('#apPublishSend').isDisabled(),true);assert.match(await page.locator('#apPublishStatus').textContent(),error);
   }
   await page.evaluate(()=>{window.raw='';APupdates.closePublisher();APupdates.openPublisher();document.getElementById('apPublishCurrent').click();APupdates.closePublisher()});await page.waitForTimeout(60);assert.equal(await page.locator('#apUpdatePublisher').isHidden(),true);assert.equal(await page.evaluate(()=>authCalls),1,'preparation never sends or authorizes');
   await page.close();
  }
  console.log('PASS: old failure reproduced above 24 MiB, corrected current-version path uploads exact canonical four-page artifact, confirmed hash/version, real oversized and incompatible bundles rejected, empty/malformed bridge diagnostics, close race and no automatic publication. Local fixtures only.');
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
