'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync('app/src/main/assets/professor.html','utf8'),read=n=>fs.readFileSync('web/'+n,'utf8');
const now=new Date('2026-10-20T12:00:00-04:00'),RealDate=Date;class Clock extends RealDate{constructor(...args){super(...(args.length?args:[now]))}static now(){return now.getTime()}}
const state={students:[{id:'keep',monthlyValue:'9999'}],custom:{untouched:true},payments:[
 {id:'p1',amount:'1.000,10',paidAt:'2026-10-01T04:00:00Z',dueDate:'2026-09-01',studentId:'archived'},
 {id:'p1',amount:'1.000,10',paidAt:'2026-10-01T04:00:00Z'},
 {id:'p2',amount:0.2,paidAt:'2026-10-05T12:00:00Z'},
 {id:'p3',amount:'',paidAt:'2026-10-10T12:00:00Z'},
 {id:'edge',amount:'50',paidAt:'2026-10-01T03:59:59Z'},
 {id:'later',amount:'99',paidAt:'2026-11-01T12:00:00Z'},
 {id:'zero',amount:0,paidAt:'2026-01-01T12:00:00Z'},
 {id:'old',amount:'10',paidAt:'2025-12-31T23:59:00-04:00'},
 {id:'bad',amount:20,paidAt:'bad'}],financeExpenses:[
 {id:'e1',description:'Aluguel <teste>',date:'2026-10-01',amountCents:70000,extra:'keep'},
 {id:'e2',description:'Equipamentos',date:'2026-09-30',amountCents:10000},
 {id:'e3',description:'Excluída',date:'2026-10-01',amountCents:90000,deleted:true},
 {id:'future',description:'Futura',date:'2026-10-21',amountCents:9000},
 {id:'leap',description:'Ano bissexto',date:'2024-02-29',amountCents:2000}]};
const nodes=new Map();function el(id){if(!nodes.has(id))nodes.set(id,{id,value:'',textContent:'',innerHTML:'',hidden:false,open:false,showModal(){this.open=true},close(){this.open=false}});return nodes.get(id)}
let fail=false,syncs=0,ids=0,renders=0;const store=new Map(),storage={setItem(k,v){if(fail)throw Object.assign(Error('quota'),{name:'QuotaExceededError'});store.set(k,v)},getItem:k=>store.get(k)};
const box={Date:Clock,Intl,console,state,document:{getElementById:el},localStorage:storage,DB_KEY:'agendaPersonalTL_v1',id:()=> 'new'+(++ids),confirm:()=>true,alert:()=>{},hesc:s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),renderFinance(){renders++}};box.window=box;box.APTeacherSync={changed(){syncs++}};vm.createContext(box);
for(const name of ['billing-model.js','finance-wallet-model.js','teacher-sync-model.js'])vm.runInContext(read(name),box);
for(const id of ['ap-finance-results-model','ap-finance-results']){const match=html.match(new RegExp('<script id="'+id+'">([\\s\\S]*?)</script>'));assert.ok(match,id+' is shipped');vm.runInContext(match[1],box)}
const M=box.APFinanceResults,clone=v=>JSON.parse(JSON.stringify(v));let data=M.build(state,2026,now),oct=data.months[9];
assert.equal(oct.receivedCents,100030);assert.equal(oct.receipts,3);assert.equal(oct.expenseCents,70000);assert.equal(oct.resultCents,30030);assert.equal(oct.unknownReceipts,1);assert.equal(data.months[8].receivedCents,5000);assert.equal(data.months[8].resultCents,-5000);assert.equal(data.total.receivedCents,105030);assert.equal(data.total.expenseCents,80000);assert.equal(data.invalidDates,1);assert.equal(M.build(state,2024,now).months[1].expenseCents,2000);
assert.equal(M.build({},2026,now).total.resultCents,0);assert.equal(M.build({payments:[{id:'a',amount:0.1,paidAt:now.toISOString()},{id:'b',amount:0.2,paidAt:now.toISOString()}]},2026,now).total.receivedCents,30);
const source=JSON.stringify(state);M.build(state,2026,now);assert.equal(JSON.stringify(state),source);
assert.match(el('frMonthCards').innerHTML,/300,30/);assert.match(el('frMonthCards').innerHTML,/parcial/);assert.equal((el('frChart').innerHTML.match(/data-fr-month=/g)||[]).length,12);assert.equal((el('frTable').innerHTML.match(/<tr>/g)||[]).length,12);assert.match(el('frExpenses').innerHTML,/Aluguel &lt;teste&gt;/);assert.doesNotMatch(el('frExpenses').innerHTML,/Excluída/);
for(const bad of [{description:'',date:'2026-10-01',amount:1},{description:'x',date:'2026-02-30',amount:1},{description:'x',date:'2026-10-21',amount:1},{description:'x',date:'2026-10-01',amount:-1},{description:'x',date:'2026-10-01',amount:0},{description:'x',date:'2026-10-01',amount:'abc'}])assert.throws(()=>M.expense(bad,null,now));
// Exercise actual generated form, failure retention, successful reload and edit/delete.
el('frAdd').onclick();assert.equal(el('frDialog').open,true);el('frDescription').value='Material';el('frAmount').value='10,25';el('frDate').value='2026-10-20';fail=true;el('frForm').onsubmit({preventDefault(){}});assert.equal(state.financeExpenses.length,5);assert.equal(el('frDialog').open,true);assert.match(el('frError').textContent,/Libere espaço/);assert.equal(syncs,0);
fail=false;el('frForm').onsubmit({preventDefault(){}});assert.equal(state.financeExpenses.length,6);assert.equal(el('frDialog').open,false);assert.equal(syncs,1);assert.equal(JSON.parse(storage.getItem(box.DB_KEY)).financeExpenses[0].amountCents,1025);assert.deepEqual(state.custom,{untouched:true});assert.match(el('frMonthCards').innerHTML,/290,05/);
const click=(attr,id)=>({target:{closest:q=>q==='['+attr+']'?{dataset:{[attr==='data-fr-edit'?'frEdit':'frDelete']:id}}:null}});
el('frExpenses').onclick(click('data-fr-edit','e1'));el('frAmount').value='1.200';el('frForm').onsubmit({preventDefault(){}});assert.equal(state.financeExpenses.find(e=>e.id==='e1').extra,'keep');assert.equal(state.financeExpenses.find(e=>e.id==='e1').amountCents,120000);assert.match(el('frMonthCards').innerHTML,/Prejuízo/);
fail=true;el('frExpenses').onclick(click('data-fr-delete','e1'));assert.equal(state.financeExpenses.find(e=>e.id==='e1').deleted,false);fail=false;el('frExpenses').onclick(click('data-fr-delete','e1'));assert.equal(state.financeExpenses.find(e=>e.id==='e1').deleted,true);assert.doesNotMatch(el('frExpenses').innerHTML,/Aluguel/);
el('frMonth').value='9';el('frMonth').onchange();assert.match(el('frMonthCards').innerHTML,/Prejuízo/);assert.match(el('frMonthCards').innerHTML,/50,00/);
// Generic normalizer keeps additive fields across reload/import and cloud apply.
const normalize=html.slice(html.indexOf('function blankState()'),html.indexOf('function load(){'));vm.runInContext(normalize,box);const restored=box.normalizeState(JSON.parse(storage.getItem(box.DB_KEY)));assert.deepEqual(clone(restored.financeExpenses),clone(state.financeExpenses));assert.deepEqual(restored.custom,{untouched:true});assert.equal(box.blankState().financeExpenses.length,0);
const S=box.APTeacherSyncModel,base=S.snapshot({students:[],financeExpenses:[]}),local=clone(base),remote=clone(base);local.agenda.financeExpenses=[{id:'local',description:'A'}];remote.agenda.financeExpenses=[{id:'remote',description:'B'}];let merged=S.merge(base,local,remote);assert.equal(merged.conflicts.length,0);assert.equal(merged.data.agenda.financeExpenses.length,2);assert.equal(S.meaningful(local),true);const deleted=clone(local);deleted.agenda.financeExpenses[0].deleted=true;assert.equal(S.merge(local,deleted,local).data.agenda.financeExpenses[0].deleted,true);remote.agenda.financeExpenses=clone(local.agenda.financeExpenses);remote.agenda.financeExpenses[0].description='Changed';assert.equal(S.merge(local,deleted,remote).conflicts.length,0); // description edit and tombstone both retained, deletion stays effective
assert.equal(S.merge(local,deleted,remote).data.agenda.financeExpenses[0].deleted,true);
console.log('PASS: 12 months, local cash dates, receipt deduplication, archived student revenue, paid expense dates, forecast excluded, exact cents, missing values, losses, leap year, form CRUD, escaping, quota rollback, state preservation, reload and cloud merge.');
