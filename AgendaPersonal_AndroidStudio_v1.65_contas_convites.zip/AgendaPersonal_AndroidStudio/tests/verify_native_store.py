"""Compila e executa NativeStore.java (Java puro): ativação com verificação, gravação atômica, cadeia de recuperação
(principal → anterior → reserva), recusa de conteúdo inválido e desativação. Não roda em aparelho."""
import subprocess,tempfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'app/src/main/java/com/tiagolima/agendapersonal'
TEST='''package com.tiagolima.agendapersonal;
import java.io.File;import java.nio.file.*;
public class NativeStoreHarness{static int n=0;static void c(boolean b,String m){n++;if(!b)throw new AssertionError(m);}
public static void main(String[] a)throws Exception{File b=Files.createTempDirectory("ns").toFile();String v="{\\"a\\":\\"ação 😀\\"}";
c(!NativeStore.active(b),"inativo no início");c(NativeStore.read(b).isEmpty(),"sem dados no início");
c(NativeStore.activate(b,"texto").contains("\\"ok\\":false"),"ativação recusa inválido");c(!NativeStore.active(b),"continua inativo");
c(NativeStore.activate(b,v).contains("\\"ok\\":true"),"ativa");c(NativeStore.active(b),"ativo");
c(NativeStore.read(b).equals(v)&&NativeStore.lastSource().equals("main"),"lê principal");
String v2="{\\"a\\":2}";c(NativeStore.write(b,v2)&&NativeStore.read(b).equals(v2),"gravação");
c(!NativeStore.write(b,"x")&&!NativeStore.write(b,null),"rejeita inválido");c(NativeStore.read(b).equals(v2),"inválido não altera");
Files.write(new File(b,"nstore/main.json").toPath(),"{lixo}".getBytes());
c(NativeStore.read(b).equals(v)&&NativeStore.lastSource().equals("prev"),"cai na geração anterior");
Files.delete(new File(b,"nstore/main.prev").toPath());
c(NativeStore.read(b).equals(v)&&NativeStore.lastSource().equals("reserve"),"cai na reserva");
NativeMirror.save(b,NativeMirror.MAIN_KEY,v2);
c(NativeStore.read(b).equals(v2)&&NativeStore.lastSource().equals("mirror"),"cópia de segurança vem antes da reserva");
c(NativeStore.deactivate(b)&&!NativeStore.active(b),"desativa");c(NativeStore.info(b).contains("\\"active\\":false"),"info");
System.out.println("PASS NativeStore: "+n+" verificações.");}}
'''
def main():
    work=Path(tempfile.mkdtemp(prefix='native-store-'))
    try:
        pkg=work/'src/com/tiagolima/agendapersonal';pkg.mkdir(parents=True)
        (pkg/'NativeStoreHarness.java').write_text(TEST,encoding='utf-8')
        subprocess.run(['javac','-encoding','UTF-8','-d',str(work/'classes'),str(D/'NativeMirror.java'),str(D/'NativeStore.java'),str(pkg/'NativeStoreHarness.java')],check=True)
        subprocess.run(['java','-Dfile.encoding=UTF-8','-cp',str(work/'classes'),'com.tiagolima.agendapersonal.NativeStoreHarness'],check=True)
    finally:
        shutil.rmtree(work,ignore_errors=True)
if __name__=='__main__':main()
