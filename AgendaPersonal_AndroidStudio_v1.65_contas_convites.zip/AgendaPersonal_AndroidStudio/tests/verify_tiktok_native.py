from pathlib import Path
import importlib.util, subprocess, tempfile
project=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('alarm_stubs',project/'tests/verify_native_alarms.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
with tempfile.TemporaryDirectory(prefix='agenda-tiktok-') as directory:
    temp=Path(directory);stub=temp/'org/json/JSONObject.java';stub.parent.mkdir(parents=True);stub.write_text(module.STUBS['org/json/JSONObject.java'])
    array=temp/'org/json/JSONArray.java';array.write_text(module.STUBS['org/json/JSONArray.java'])
    sources=[stub,array]+[project/'app/src/main/java/com/tiagolima/agendapersonal'/name for name in ['TikTokVideoResolver.java','TikTokPlayerPage.java']]+[project/'tests/TikTokMetadataTest.java']
    subprocess.run(['java','com.sun.tools.javac.Main','-encoding','UTF-8','-d',str(temp),*[str(p) for p in sources]],check=True)
    subprocess.run(['java','-cp',str(temp),'com.tiagolima.agendapersonal.TikTokMetadataTest',str(project/'web/tiktok-player-page.html')],check=True)
