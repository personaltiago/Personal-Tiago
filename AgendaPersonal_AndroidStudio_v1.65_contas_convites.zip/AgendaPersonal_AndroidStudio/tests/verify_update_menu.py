"""Exercise native menu routing and compare the real XML to the update menu design."""
from pathlib import Path
import json
import runpy
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

PROJECT = Path(__file__).resolve().parents[1]
PACKAGE = 'com/tiagolima/agendapersonal'
ANDROID = '{http://schemas.android.com/apk/res/android}'
ORDER = ['import', 'restore', 'conference', 'details', 'verify', 'publish', 'installer', 'installer_publish', 'close']
LABELS = ['Importar arquivo baixado do painel', 'Restaurar versão anterior', 'Conferência de atualizações', 'Detalhes', 'Verificar', 'Publicar para os alunos', 'Instalador Android', 'Publicar instalador Android', 'Fechar']

HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.AlertDialog;import android.view.View;import android.webkit.WebView;import android.widget.Button;
import java.nio.file.*;import java.lang.reflect.*;import java.util.*;import org.json.*;
public final class UpdateMenuHarness{
static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);}
static Object get(Object o,String key)throws Exception{Field f=o.getClass().getDeclaredField(key);f.setAccessible(true);return f.get(o);}
static void set(Object o,String key,Object v)throws Exception{Field f=o.getClass().getDeclaredField(key);f.setAccessible(true);f.set(o,v);}
static Button button(AlertDialog d,int id){return ((View)d.view).findViewById(id);}
public static void main(String[]args)throws Exception{
 Path root=Path.of(args[0]),folder=Files.createTempDirectory("agenda-update-menu-");
 MainActivity activity=new MainActivity(folder.toFile(),root.resolve("app/src/main/assets"));WebView web=new WebView();UpdateManager manager=new UpdateManager(activity,web);
 try{
  manager.setUpdateAccount("R2EmnDVcvMWt7TjPxOP6DjW1VOn1");set(manager,"busy",true);manager.showScreen();AlertDialog menu=(AlertDialog)get(manager,"dialog");
  check(menu.title.equals("Atualizar aplicativo"),"Wrong menu title");check(((View)menu.view).nodes.size()==9,"Nine menu actions required");
  for(Object item:((View)menu.view).nodes.values())check(((Button)item).visibility==View.VISIBLE,"Teacher action hidden");
  check(!button(menu,R.id.update_import).enabled&&!button(menu,R.id.update_verify).enabled,"Busy operations enabled");
  check(button(menu,R.id.update_close).enabled&&button(menu,R.id.update_details).enabled,"Read-only/close unnecessarily blocked");
  int picks=activity.filePickers;manager.performMenuAction("import");check(activity.filePickers==picks,"Busy import opened picker");
  set(manager,"busy",false);Method display=UpdateManager.class.getDeclaredMethod("display",String.class);display.setAccessible(true);display.invoke(manager,"Pronto");
  check(button(menu,R.id.update_import).enabled,"Import not restored after busy state");check(!button(menu,R.id.update_restore).enabled,"Invented previous update for fresh APK");
  manager.performMenuAction("import");check(activity.filePickers==picks+1,"Import not wired to file chooser");
  int loads=web.loads;manager.performMenuAction("details");AlertDialog details=AlertDialog.lastCreated;
  check(details.title.equals("Detalhes da versão instalada")&&details.message.contains("1.12.257")&&details.message.contains("urso"),"Installed details missing");check(web.loads==loads,"Details navigated/installed content");
  web.ready=false;manager.performMenuAction("conference");check(menu.isShowing(),"Missing web conference dismissed native installer");
  web.ready=true;manager.performMenuAction("conference");check(web.check.contains("openConference")&&!web.check.contains("openPublisher"),"Conference routed to wrong screen");check(!menu.isShowing(),"Native modal obscured conference");
  set(manager,"busy",true);manager.showScreen();menu=(AlertDialog)get(manager,"dialog");set(manager,"busy",false);manager.performMenuAction("publish");check(web.check.contains("openPublisher")&&!menu.isShowing(),"Publish flow changed");
  String lastScript=web.check;int lastPicks=activity.filePickers;manager.performMenuAction("unknown");check(web.check.equals(lastScript)&&activity.filePickers==lastPicks,"Unknown action accepted");
  manager.setUpdateAccount("student");for(String action:new String[]{"import","restore","conference","publish","publish-installer"})manager.performMenuAction(action);check(activity.filePickers==lastPicks&&web.check.equals(lastScript),"Student invoked teacher action through bridge");
  set(manager,"busy",true);manager.showScreen();AlertDialog student=(AlertDialog)get(manager,"dialog");
  for(int id:new int[]{R.id.update_import,R.id.update_restore,R.id.update_conference,R.id.update_publish,R.id.update_installer_publish})check(button(student,id).visibility==View.GONE,"Student has teacher action");
  for(int id:new int[]{R.id.update_details,R.id.update_verify,R.id.update_installer,R.id.update_close})check(button(student,id).visibility==View.VISIBLE,"Student lost own update actions");
  button(student,R.id.update_close).listener.click(null);check(!student.isShowing(),"Close button failed");
  JSONObject status=new JSONObject(manager.distributionStatus());check(status.optInt("updateMenuVersion")==1&&status.optInt("contentInstallerVersion")==3,"Capabilities regressed");
  check(!Files.exists(folder.resolve("updates/active.json"))&&!Files.exists(folder.resolve("updates/data-before-update.json")),"Menu changed code or student snapshot");
  System.out.println("PASS native nine-action routing, busy state, permissions, missing-content fallback, details, import, publish, conference and close; no data mutations");
 }finally{manager.destroy();}
}}
'''


def main():
    xml = ET.parse(PROJECT / 'app/src/main/res/layout/update_actions.xml').getroot()
    assert xml.tag == 'ScrollView', 'Actions must scroll on short screens or large text'
    container = list(xml)[0]
    assert container.attrib[ANDROID + 'orientation'] == 'vertical'
    assert [button.attrib[ANDROID + 'id'] for button in container] == ['@+id/update_' + name for name in ORDER]
    values = ET.parse(PROJECT / 'app/src/main/res/values/update_menu.xml').getroot()
    strings = {node.attrib['name']: node.text for node in values.findall('string')}
    assert [strings['update_' + name] for name in ORDER] == LABELS
    styles = {node.attrib['name']: node.text for node in values.find('style').findall('item')}
    assert styles['android:layout_width'] == 'match_parent' and styles['android:minHeight'] == '52dp'
    assert styles['android:layout_height'] == 'wrap_content', 'Long labels must wrap rather than clip'
    assert styles['android:background'] == '@drawable/update_action_background'
    assert styles['android:drawablePadding'] == '12dp' and styles['android:gravity'] == 'start|center_vertical'
    for name, button in zip(ORDER, container):
        assert button.attrib['style'] == '@style/AgendaUpdateAction'
        icon = {'installer': 'verify', 'installer_publish': 'publish'}.get(name, name)
        assert button.attrib[ANDROID + 'drawableStart'] == '@drawable/update_' + icon
        vector = ET.parse(PROJECT / ('app/src/main/res/drawable/update_' + icon + '.xml')).getroot()
        assert vector.attrib[ANDROID + 'width'] == '44dp' and vector.attrib[ANDROID + 'height'] == '32dp'
        assert vector.findall('path')[-1].attrib[ANDROID + 'pathData'] == 'M43,1 L43,31'
    main_source = (PROJECT / 'app/src/main/java' / PACKAGE / 'MainActivity.java').read_text()
    assert '@JavascriptInterface public int getUpdateMenuVersion() { return 1; }' in main_source
    assert '@JavascriptInterface public void openUpdateAction(String action)' in main_source
    print('PASS native XML: nine ordered equal-width actions, consistent icons/dividers, wrapping text and scroll container')
    stubs = dict(runpy.run_path(str(PROJECT / 'tests/verify_native_updates.py'))['STUBS'])
    stubs.pop(PACKAGE + '/NativeUpdateHarness.java')
    stubs[PACKAGE + '/UpdateMenuHarness.java'] = HARNESS
    compiler = [shutil.which('javac')] if shutil.which('javac') else [shutil.which('java'), 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-native-menu-') as temporary:
        work = Path(temporary)
        files = []
        for name, content in stubs.items():
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content)
            files.append(str(target))
        for name in ['UpdateManager', 'UpdateAreaPatch', 'UpdateArchive', 'AndroidInstaller', 'UpdateStorage','UpdateExport','UpdateDownloads', 'UpdateIdentity', 'NativeLaunch', 'LocalPages', 'UpdateManifest', 'UpdatePackageSignature']:
            files.append(str(PROJECT / 'app/src/main/java' / PACKAGE / (name + '.java')))
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + files, check=True)
        subprocess.run([shutil.which('java'), '-cp', str(work / 'classes'), PACKAGE.replace('/', '.') + '.UpdateMenuHarness', str(PROJECT)], check=True, timeout=30)


if __name__ == '__main__':
    main()
