'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets'),review=path.resolve(__dirname,'../../../review/colored-cards');fs.mkdirSync(review,{recursive:true});
const fixture={students:[
 {id:'s1',name:'Aluna de teste',studentType:'presencial',phone:'',financeEnabled:true,monthlyValue:200,dueDate:'2026-10-20'},
 {id:'s2',name:'Aluno de teste',studentType:'online',phone:'',financeEnabled:true,monthlyValue:150,dueDate:'2026-10-21'},
 {id:'s3',name:'Outro aluno',studentType:'presencial',phone:'',financeEnabled:true,monthlyValue:250,dueDate:'2026-11-05'}
],lessons:[{id:'l1',studentId:'s1',date:'2026-10-21',time:'16:45',duration:60,repeat:'none'},{id:'l2',studentId:'s2',date:'2026-10-22',time:'10:00',duration:60,repeat:'none'}],payments:[],history:[],customData:{keep:'preservado'}};
const server=http.createServer((req,res)=>{const file=path.join(assets,new URL(req.url,'http://local').pathname.split('/').pop()||'professor.html');res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.existsSync(file)?fs.readFileSync(file):'')});
const settle=page=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
async function audit(page,selector){return page.locator(selector).evaluateAll(nodes=>{
 const rgb=c=>c.match(/[\d.]+/g).slice(0,3).map(Number),lum=c=>rgb(c).map(n=>n/255).reduce((s,n,i)=>s+[.2126,.7152,.0722][i]*(n<=.04045?n/12.92:((n+.055)/1.055)**2.4),0);
 const sample=document.createElement('span');sample.style.background='var(--ac-primary-fill)';document.body.append(sample);const expected=getComputedStyle(sample).backgroundColor;sample.remove();
 return nodes.filter(n=>n.checkVisibility()).map(n=>{
  const bg=getComputedStyle(n).backgroundColor;
  const text=[...n.querySelectorAll('strong,small,p,h2,h3,h4,span,label,summary')].filter(t=>t.checkVisibility()&&[...t.childNodes].some(c=>c.nodeType===3&&c.textContent.trim())&&!t.closest('svg'));
  const bad=text.map(t=>{let el=t,b;while(el){b=getComputedStyle(el).backgroundColor;if(b!=='rgba(0, 0, 0, 0)'&&b!=='transparent')break;el=el.parentElement}const a=lum(getComputedStyle(t).color),v=lum(b);return {text:t.textContent.trim().slice(0,50),ratio:(Math.max(a,v)+.05)/(Math.min(a,v)+.05),color:getComputedStyle(t).color,bg:b}}).filter(t=>t.ratio<4.49);
  return {name:n.className,bg,expected,bad};
 });
})}
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});try{
 const ctx=await browser.newContext({viewport:{width:390,height:900},isMobile:true,hasTouch:true});await ctx.route('https://**',r=>r.abort());
 await ctx.addInitScript(fixture=>{const RealDate=Date;window.Date=class extends RealDate{constructor(...a){super(...(a.length?a:['2026-10-21T12:00:00Z']))}static now(){return new RealDate('2026-10-21T12:00:00Z').getTime()}};if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(fixture))},fixture);
 const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));const url='http://127.0.0.1:'+server.address().port;
 await page.goto(url+'/professor.html');await page.waitForFunction(()=>window.AgendaIconFinish);const before=await page.evaluate(()=>JSON.stringify(state));
 await page.evaluate(()=>{AgendaIconFinish.set('matte');AgendaIconFinish.setCards('colored')});
 const failures=new Map();
 const screens={dashboard:'.home-card,.home-quick,.home-row,.home-upcoming-row,.home-category,.home-finance-stat',more:'.more-identity,.more-pending,.more-pending-link',today:'#todayList .lesson',week:'#weekList>.day-card,#weekList .agenda-lesson',students:'.student-stat,.action-tile,#studentList .student',finance:'#financeWallet,#financeResults,.finance-card,.finance-summary .box',workouts:'.workout-summary>div,.workout-student-choice',settings:'.teacher-text-setting,.alarm-tools,.sound-choice-group',availability:'.availability-card,.availability-setup,.compact-availability-day'};
 for(const design of ['current','neon-tl','metal-tl','pro-tl','deep-tl'])for(const color of ['#b7f522','#2872e8','#a12cff'])for(const mode of ['light','dark']){
  await page.evaluate(({design,color,mode})=>{AgendaColors.selectDesign(design);AgendaColors.save({...AgendaColors.get(),id:'custom',primary:color});AgendaAppearance.setMode(mode)},{design,color,mode});
  for(const [screen,selector] of Object.entries(screens)){
   await page.evaluate(screen=>{showScreen(screen);if(screen==='finance'){financeView='all';renderFinance()}},screen);await settle(page);const result=await audit(page,selector);assert.ok(result.length,screen+' has visible cards');
   for(const a of result){if(a.bg!==a.expected||a.bad.length)failures.set(screen+' '+a.name+' '+mode+' '+a.bad.map(b=>b.text).join(),{design,color,mode,screen,...a})}
  }
 }
 assert.deepEqual([...failures.values()],[],'cards and text across modules');
 await page.evaluate(()=>{AgendaColors.selectDesign('deep-tl');AgendaColors.save({...AgendaColors.get(),id:'custom',primary:'#b7f522'});AgendaAppearance.setMode('dark');showScreen('dashboard')});await settle(page);
 for(const width of [320,390,480]){await page.setViewportSize({width,height:900});for(const screen of ['dashboard','more','week','students','finance','workouts']){await page.evaluate(s=>showScreen(s),screen);await settle(page);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),screen+' fits '+width)}}
 await page.setViewportSize({width:390,height:900});await page.evaluate(()=>showScreen('dashboard'));await page.screenshot({path:path.join(review,'painel-verde.png'),fullPage:true});
 await page.evaluate(()=>{openStudentProfile('s1')});await page.locator('#studentProfileDialog.open').waitFor();await settle(page);for(const a of await audit(page,'.profile-action-card,.profile-section,.profile-metric')){assert.equal(a.bg,a.expected);assert.deepEqual(a.bad,[],a.name)}
 await page.evaluate(()=>closeDialog('studentProfileDialog'));
 assert.equal(await page.evaluate(()=>JSON.stringify(state)),before,'appearance never edits business data');
 await page.reload();await page.waitForFunction(()=>window.AgendaIconFinish);assert.equal(await page.evaluate(()=>AgendaIconFinish.getCards()),'colored');
 await page.evaluate(()=>AgendaIconFinish.setCards('theme'));await settle(page);assert.notEqual((await audit(page,'.home-quick'))[0].bg,(await audit(page,'.home-quick'))[0].expected,'default theme restores original surfaces');
 await page.evaluate(()=>AgendaIconFinish.setCards('colored'));await page.goto(url+'/avaliacoes.html?new=1');await page.waitForFunction(()=>window.AgendaIconFinish);await page.locator('#workspace').waitFor({state:'visible'});await settle(page);
 for(const mode of ['light','dark']){await page.evaluate(mode=>AgendaColors.save({...AgendaColors.get(),id:'custom',background:mode==='light'?'#f6f5f9':'#0d0e12'}),mode);for(const a of await audit(page,'.workspace .card,.workspace .live-card')){assert.equal(a.bg,a.expected);assert.deepEqual(a.bad,[],a.name)}}
 assert.deepEqual(errors,[]);console.log('PASS: colored cards across dashboard, More summary, day/week agenda, students, finance, workouts, availability, profile and assessment form; five designs, three hues, light/dark, contrast, editable inset controls, 320/390/480 widths, restart/default restoration and data preservation.');
 }finally{await browser.close();await new Promise(r=>server.close(r))}}
run().catch(e=>{console.error(e);process.exitCode=1});
