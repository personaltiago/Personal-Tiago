'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/') : require):require,{chromium}=runtime('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets'),source=fs.readFileSync(path.join(assets,'index.html'),'utf8');
const home=source.match(/<section class="home-detail-panel home-evolution-panel">[\s\S]*?<\/section>/)[0];
for(const sample of ['72,5','24,1','16,3%','-1,8','-2,4'])assert.equal(home.includes(sample),false,'sample removed before JavaScript '+sample);
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(source)});
async function run(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);
  await page.evaluate(()=>{
   const profile={name:'Aluna',gender:'Feminino'};
   window.__AP_STUDENT_CONTEXT={storageId:'alice',role:'student',profile,area:{enabled:true,plans:[],profile}};
   APstudentUI.activate();route('home');
  });
  assert.equal(await page.locator('#apHomeAssessmentEmpty').textContent(),'Sem avaliações registradas');
  assert.equal(await page.locator('#apHomeAssessmentSummary').isVisible(),false);
  // Demo flag and non-assessment profile weight must never populate summary.
  await page.evaluate(()=>{assDemo=true;APstudentStorage.setItem(profileStorageKey(),JSON.stringify({weight:72.5,height:173}));renderHome()});
  assert.equal(await page.locator('#apHomeAssessmentEmpty').isVisible(),true);
  async function records(data){await page.evaluate(data=>{APstudentStorage.setItem('agenda_demo_avaliacoes_Feminino',JSON.stringify(data));renderHome()},data)}
  await records([{date:'12/10/2026',weight:81.2,imc:26.1,fat:22.3}]);
  assert.match(await page.locator('#apHomeAssessmentSummary').textContent(),/81,2/);
  assert.equal(await page.locator('#apHomeAssessmentSummary em').count(),0,'one assessment has no invented change');
  assert.match(await page.locator('#apHomeAssessmentDate').textContent(),/Primeira avaliação/);
  await records([{date:'12/10/2026',weight:81.2,imc:26.1,fat:22.3},{date:'01/10/2026',weight:83.7,imc:27.1,fat:24.7}]);
  assert.deepEqual(await page.locator('#apHomeAssessmentSummary em').allTextContents(),['−2,5 kg','−1','−2,4 p.p.']);
  assert.match(await page.locator('#apHomeAssessmentDate').textContent(),/Comparada com 01\/10\/2026/);
  await records([{date:'01/10/2026',weight:83.7,imc:27.1,fat:24.7},{date:'12/10/2026',weight:81.2,imc:null,fat:null}]);
  assert.deepEqual(await page.locator('#apHomeAssessmentSummary strong').allTextContents(),['81,2 kg','—','—']);
  assert.equal(await page.locator('#apHomeAssessmentSummary em').count(),1,'missing fields never become zero or borrow older values');
  const before=await page.evaluate(()=>APstudentStorage.getItem('agenda_demo_avaliacoes_Feminino'));
  for(const width of [320,390,480]){await page.setViewportSize({width,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false)}
  await page.locator('.home-evolution-panel button').click();assert.equal(await page.evaluate(()=>document.body.dataset.view),'assessments','details opens real body assessments');
  await page.evaluate(()=>{window.__AP_STUDENT_CONTEXT={...window.__AP_STUDENT_CONTEXT,storageId:'bob'};APstudentUI.activate();route('home')});
  assert.equal(await page.locator('#apHomeAssessmentEmpty').isVisible(),true,'same-gender account does not inherit another student measurements');
  await page.evaluate(()=>{window.__AP_STUDENT_CONTEXT.storageId='alice';renderHome()});
  assert.equal(await page.evaluate(()=>APstudentStorage.getItem('agenda_demo_avaliacoes_Feminino')),before,'render never changes records');
  await records([{date:'31/02/2026',weight:99}]);assert.equal(await page.locator('#apHomeAssessmentEmpty').isVisible(),true,'invalid calendar date ignored');
  await page.evaluate(()=>{APstudentStorage.setItem('agenda_demo_avaliacoes_Feminino','broken');renderHome()});assert.equal(await page.locator('#apHomeAssessmentEmpty').isVisible(),true);
  assert.deepEqual(errors,[]);
  console.log('PASS: static demo removed, real student home empty, demo/profile defaults ignored, first assessment without delta, chronological comparison, missing metrics, real details route, per-account isolation, invalid data, unchanged records and mobile widths 320/390/480. Browser real; Firebase not contacted.');
 }finally{await browser.close();server.close()}
}
run().catch(e=>{console.error(e);server.close();process.exitCode=1});
