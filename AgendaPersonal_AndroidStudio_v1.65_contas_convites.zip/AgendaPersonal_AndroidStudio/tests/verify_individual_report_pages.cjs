'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
let html=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/avaliacoes.html'),'utf8');
html=html.replace('window.__downloadCurrentReportPdf = downloadCurrentReportPdf;','window.__qaReport={buildReport,pdfExportCssText,prepareReportPdfPages,renderSheetForDirectPdf,createRasterPdfDoc,embeddedPdfRoundTrip,pdfSheetHasOverflow};window.__downloadCurrentReportPdf = downloadCurrentReportPdf;');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(html)});
const generic={format:'agenda-personal-pdf-data',version:1,kind:'single',data:{kind:'single',clientName:'Aluna de teste',professional:'Profissional de teste',equation:'female',age:31,date:'2026-10-19',nextDate:'2026-12-19',nextTime:'15:24',height:151,weight:42.65,goalModel:'competitionFitnessWeight',goalSource:'manual',peakFat:13.6,fitnessFat:13.6,circumference:{neck:29,shoulder:87,chest:77,armLeft:22,armRight:22,waist:64,abdomen:68,hip:83.5,thighLeft:43.2,thighRight:43,calfLeft:27.5,calfRight:28.4},folds:{triceps:10.1,subscapular:5.8,suprailiac:5,pectoral:5.2,midaxillary:5.3,abdominal:5.9,thigh:20.8},goal:'',notes:'',photos:[]}};
const snapshot=process.env.AGENDA_REPORT_INPUT?JSON.parse(fs.readFileSync(process.env.AGENDA_REPORT_INPUT,'utf8')):generic;
async function run(){await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});try{
 const context=await browser.newContext({viewport:{width:794,height:1123},timezoneId:'America/Cuiaba'});await context.route('https://**',r=>r.abort());const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>!!window.__qaReport);
 const result=await page.evaluate(async snapshot=>{
  AgendaIconFinish.setCards('colored');
  const data={...snapshot.data,previous:{date:'',age:null,weight:null,circumference:{},folds:{}}},before=JSON.stringify(data);
  __qaReport.buildReport(data,[]);
  const sheets=[...document.querySelectorAll('#report-content>.sheet')],kinds=sheets.map(s=>s.dataset.individualPage||'photos');
  window.__preparedReport=await __qaReport.prepareReportPdfPages(sheets,__qaReport.pdfExportCssText());
  return {kinds,unchanged:before===JSON.stringify(data),pages:__preparedReport.pages.map(sheet=>({kind:sheet.dataset.individualPage||'photos',overflow:__qaReport.pdfSheetHasOverflow(sheet),width:sheet.getBoundingClientRect().width,height:sheet.getBoundingClientRect().height,type:sheet.style.getPropertyValue('--pdf-type'),text:sheet.innerText,folds:sheet.querySelectorAll('.fold-row').length,metrics:sheet.querySelectorAll('.metric').length,tableRows:sheet.querySelectorAll('.report-table tbody tr').length}))};
 },snapshot);
 assert.equal(result.unchanged,true);assert.deepEqual(result.kinds.slice(0,5),['composition','indicators','perimeters','folds','method']);assert.equal(result.pages.length,result.kinds.length,'no spill pages for a normal first assessment');
 for(const p of result.pages){assert.equal(p.overflow,false,p.kind);assert.equal(p.width,794);assert.equal(p.height,1123)}
 assert.equal(result.pages[0].metrics,0);assert.equal(result.pages[1].metrics,4);assert.equal(result.pages[2].tableRows,12);assert.equal(result.pages[2].folds,0);assert.equal(result.pages[3].folds,7);assert.equal(result.pages[3].tableRows,0);assert.match(result.pages[0].text,/13,6/);assert.match(result.pages[1].text,/18,71/);assert.match(result.pages[2].text,/594,6/);assert.match(result.pages[3].text,/58,1/);
 if(process.env.AGENDA_REPORT_PDF){
  const bytes=await page.evaluate(async snapshot=>{const css=__qaReport.pdfExportCssText(),images=[];for(const sheet of __preparedReport.pages)images.push(await __qaReport.renderSheetForDirectPdf(sheet,css));window.__qaImages=images;const data=await __qaReport.createRasterPdfDoc(images,snapshot).save();window.__qaRestored=__qaReport.embeddedPdfRoundTrip(data);return Array.from(data)},snapshot);
  fs.mkdirSync(path.dirname(process.env.AGENDA_REPORT_PDF),{recursive:true});fs.writeFileSync(process.env.AGENDA_REPORT_PDF,Buffer.from(bytes));const restored=await page.evaluate(()=>__qaRestored);assert.equal(restored.clientName,snapshot.data.clientName);assert.deepEqual(restored.photos,snapshot.data.photos);assert.deepEqual(restored.folds,snapshot.data.folds);assert.deepEqual(restored.circumference,snapshot.data.circumference);assert.equal(restored.weight,snapshot.data.weight);
 }
 assert.deepEqual(errors,[]);console.log(JSON.stringify({passed:true,pages:result.pages.map(({kind,type,width,height})=>({kind,type,width,height})),readOnly:true,roundTrip:!!process.env.AGENDA_REPORT_PDF}));
 }finally{await browser.close();server.close()}}
run().catch(error=>{console.error(error);server.close();process.exitCode=1});
