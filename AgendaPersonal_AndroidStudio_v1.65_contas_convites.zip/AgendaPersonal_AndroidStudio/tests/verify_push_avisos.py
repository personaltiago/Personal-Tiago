"""Aviso "Novo cadastro" na tela bloqueada (Android 1.211, pedido do Tiago em 24/11/2026).

Parte A confere as ligações no projeto: dependência do Firebase Messaging, leitura de app/google-services.json, APK oficial
barrado sem a configuração, serviço e metadados no manifesto, ponte com o conteúdo e o ícone monocromático.
Parte B compila as classes REAIS PushAvisos e AgendaMessagingService com Android e Firebase de mentira e confere a leitura da
mensagem, a notificação (canal, tela bloqueada, versão pública sem o nome, toque que não recarrega o app), a abertura pelo toque,
o endereço de push (só depois de o conteúdo pedir), o estado para a tela "Sons e alertas" e as configurações do canal.
Não é teste em aparelho: a entrega real na tela bloqueada do Xiaomi só se confirma no celular, pelo botão "Testar aviso".
"""
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal'


def static_checks():
    gradle = (PROJECT / 'app/build.gradle').read_text()
    for token in ["platform('com.google.firebase:firebase-bom:33.13.0')", "implementation 'com.google.firebase:firebase-messaging'",
                  "file('google-services.json')", "'agenda-personal-bdb58'", "'1044097605904'", "/1:1044097605904:android:[0-9a-f]+/",
                  "graph.hasTask(':app:assembleRelease')", "resValue 'string', name, value", "versionName '1.211'"]:
        assert token in gradle, 'build.gradle sem: ' + token
    assert 'com.google.gms.google-services' not in gradle, 'O plugin google-services não é usado: a leitura é feita no próprio build.gradle.'

    manifest = (PROJECT / 'app/src/main/AndroidManifest.xml').read_text()
    service = re.search(r'<service android:name="\.AgendaMessagingService" android:exported="false">\s*'
                        r'<intent-filter><action android:name="com\.google\.firebase\.MESSAGING_EVENT" /></intent-filter>\s*</service>', manifest)
    assert service, 'Serviço do aviso ausente ou exportado.'
    assert '<meta-data android:name="firebase_messaging_auto_init_enabled" android:value="false" />' in manifest, \
        'O Firebase Messaging precisa ficar parado até o app do professor pedir.'
    assert 'android:resource="@drawable/ic_stat_cadastro"' in manifest

    main = (SOURCE / 'MainActivity.java').read_text()
    for token in ['if (savedInstanceState == null) pushOpen.set(PushAvisos.abertura(getIntent()));', 'PushAvisos.criarCanal(this);',
                  'String push=PushAvisos.abertura(intent);', "new Event('ap-push-open')", "new Event('ap-push-token')",
                  '@JavascriptInterface public int getPushVersion() { return PushAvisos.VERSAO; }',
                  '@JavascriptInterface public String getPushStatus()', '@JavascriptInterface public String getPushToken()',
                  '@JavascriptInterface public void refreshPushToken()', '@JavascriptInterface public void openPushSettings()',
                  '@JavascriptInterface public String takePushOpen() { return ((MainActivity) activity).pushOpen.getAndSet(""); }']:
        assert token in main, 'MainActivity sem: ' + token
    assert main.count('PushAvisos.atualizarToken(') == 1, 'O endereço de push só é buscado quando o conteúdo pede.'

    icon = (PROJECT / 'app/src/main/res/drawable/ic_stat_cadastro.xml').read_text()
    colors = set(re.findall(r'android:(?:fill|stroke)Color="([^"]+)"', icon))
    assert colors == {'@android:color/transparent', '#FFFFFFFF'}, 'Ícone da barra de status precisa ser branco sobre transparente.'
    assert 'android:viewportWidth="24"' in icon and 'android:width="24dp"' in icon


STUBS = {
    'android/Manifest.java': 'package android;public final class Manifest{public static final class permission{public static final String POST_NOTIFICATIONS="android.permission.POST_NOTIFICATIONS";}}',
    'android/os/Build.java': 'package android.os;public class Build{public static class VERSION{public static int SDK_INT=35;}}',
    'android/content/pm/PackageManager.java': '''package android.content.pm;public class PackageManager{public static final int PERMISSION_GRANTED=0,PERMISSION_DENIED=-1;public String versionName="1.211";
public PackageInfo getPackageInfo(String name,int flags)throws NameNotFoundException{if(versionName==null)throw new NameNotFoundException();PackageInfo i=new PackageInfo();i.versionName=versionName;return i;}
public static class NameNotFoundException extends Exception{}}''',
    'android/content/pm/PackageInfo.java': 'package android.content.pm;public class PackageInfo{public String versionName;}',
    'android/provider/Settings.java': '''package android.provider;public final class Settings{public static final String ACTION_CHANNEL_NOTIFICATION_SETTINGS="android.settings.CHANNEL_NOTIFICATION_SETTINGS",
ACTION_APP_NOTIFICATION_SETTINGS="android.settings.APP_NOTIFICATION_SETTINGS",EXTRA_APP_PACKAGE="android.provider.extra.APP_PACKAGE",EXTRA_CHANNEL_ID="android.provider.extra.CHANNEL_ID";}''',
    'android/content/SharedPreferences.java': '''package android.content;public interface SharedPreferences{String getString(String k,String d);long getLong(String k,long d);Editor edit();
interface Editor{Editor putString(String k,String v);Editor putLong(String k,long v);Editor remove(String k);void apply();boolean commit();}}''',
    'android/content/Context.java': '''package android.content;import java.util.*;
public class Context{public static final int MODE_PRIVATE=0;public static final String NOTIFICATION_SERVICE="notification";
public android.app.NotificationManager manager=new android.app.NotificationManager();public int permission=0;public final Map<String,Map<String,Object>> stores=new HashMap<>();
public Object getSystemService(String name){return NOTIFICATION_SERVICE.equals(name)?manager:null;}public Context getApplicationContext(){return this;}
public int checkSelfPermission(String p){return permission;}public String getPackageName(){return "com.tiagolima.agendapersonal";}
public android.content.pm.PackageManager packages=new android.content.pm.PackageManager();public android.content.pm.PackageManager getPackageManager(){return packages;}
public SharedPreferences getSharedPreferences(String name,int mode){Map<String,Object> s=stores.computeIfAbsent(name,k->new HashMap<>());return new SharedPreferences(){
public String getString(String k,String d){Object v=s.get(k);return v==null?d:(String)v;}public long getLong(String k,long d){Object v=s.get(k);return v==null?d:(Long)v;}
public Editor edit(){Map<String,Object> next=new HashMap<>(s);return new Editor(){public Editor putString(String k,String v){next.put(k,v);return this;}public Editor putLong(String k,long v){next.put(k,v);return this;}
public Editor remove(String k){next.remove(k);return this;}public void apply(){s.clear();s.putAll(next);}public boolean commit(){apply();return true;}};}};}}''',
    'android/content/Intent.java': '''package android.content;import java.util.*;
public class Intent{public static final int FLAG_ACTIVITY_NEW_TASK=0x10000000,FLAG_ACTIVITY_CLEAR_TOP=0x04000000,FLAG_ACTIVITY_SINGLE_TOP=0x20000000;
public final String action;public final Class<?> target;public int flags;public final Map<String,String> extras=new LinkedHashMap<>();
public Intent(String action){this.action=action;target=null;}public Intent(Context c,Class<?> t){action=null;target=t;}
public Intent addFlags(int f){flags|=f;return this;}public Intent putExtra(String k,String v){extras.put(k,v);return this;}
public String getStringExtra(String k){return extras.get(k);}public void removeExtra(String k){extras.remove(k);}}''',
    'android/app/Activity.java': '''package android.app;import android.content.Intent;import java.util.*;
public class Activity extends android.content.Context{public final List<Intent> started=new ArrayList<>();public Set<String> missing=new HashSet<>();
public void startActivity(Intent i){if(missing.contains(i.action))throw new RuntimeException("ActivityNotFoundException");started.add(i);}}''',
    'android/app/PendingIntent.java': '''package android.app;
public class PendingIntent{public static final int FLAG_UPDATE_CURRENT=0x08000000,FLAG_IMMUTABLE=0x04000000;public final int requestCode,flags;public final android.content.Intent intent;
private PendingIntent(int r,android.content.Intent i,int f){requestCode=r;intent=i;flags=f;}
public static PendingIntent getActivity(android.content.Context c,int r,android.content.Intent i,int f){return new PendingIntent(r,i,f);}}''',
    'android/app/Notification.java': '''package android.app;
public class Notification{public static final int VISIBILITY_PUBLIC=1,VISIBILITY_PRIVATE=0,VISIBILITY_SECRET=-1;
public String channel,title,text,bigText;public int icon,color,visibility=VISIBILITY_PRIVATE;public long when;public boolean autoCancel,showWhen;public PendingIntent contentIntent;public Notification publicVersion;
public static class Style{}public static class BigTextStyle extends Style{public String text;public BigTextStyle bigText(CharSequence t){text=String.valueOf(t);return this;}}
public static class Builder{private final Notification n=new Notification();public Builder(android.content.Context c,String channel){n.channel=channel;}
public Builder setSmallIcon(int i){n.icon=i;return this;}public Builder setColor(int c){n.color=c;return this;}public Builder setContentTitle(CharSequence t){n.title=String.valueOf(t);return this;}
public Builder setContentText(CharSequence t){n.text=String.valueOf(t);return this;}public Builder setStyle(Style s){n.bigText=((BigTextStyle)s).text;return this;}
public Builder setContentIntent(PendingIntent p){n.contentIntent=p;return this;}public Builder setAutoCancel(boolean b){n.autoCancel=b;return this;}
public Builder setShowWhen(boolean b){n.showWhen=b;return this;}public Builder setWhen(long w){n.when=w;return this;}
public Builder setVisibility(int v){n.visibility=v;return this;}public Builder setPublicVersion(Notification p){n.publicVersion=p;return this;}public Notification build(){return n;}}}''',
    'android/app/NotificationChannel.java': '''package android.app;
public class NotificationChannel{public final String id;public String name,description;public int importance,lockscreen=-1000;public boolean badge,vibration;
public NotificationChannel(String id,CharSequence name,int importance){this.id=id;this.name=String.valueOf(name);this.importance=importance;}
public void setDescription(String d){description=d;}public void setLockscreenVisibility(int v){lockscreen=v;}public void setShowBadge(boolean b){badge=b;}public void enableVibration(boolean b){vibration=b;}
public int getImportance(){return importance;}public int getLockscreenVisibility(){return lockscreen;}}''',
    'android/app/NotificationManager.java': '''package android.app;import java.util.*;
public class NotificationManager{public static final int IMPORTANCE_NONE=0,IMPORTANCE_MIN=1,IMPORTANCE_LOW=2,IMPORTANCE_DEFAULT=3,IMPORTANCE_HIGH=4;
public final Map<String,NotificationChannel> channels=new HashMap<>();public final Map<String,Notification> posted=new LinkedHashMap<>();public boolean enabled=true,refuse;public int creates;
public void createNotificationChannel(NotificationChannel c){creates++;NotificationChannel old=channels.get(c.id);if(old==null)channels.put(c.id,c);else{old.name=c.name;old.description=c.description;}}
public NotificationChannel getNotificationChannel(String id){return channels.get(id);}public boolean areNotificationsEnabled(){return enabled;}
public void notify(String tag,int id,Notification n){if(refuse)throw new SecurityException("refused");posted.put(tag+"#"+id,n);}}''',
    'com/google/android/gms/tasks/OnCompleteListener.java': 'package com.google.android.gms.tasks;public interface OnCompleteListener<T>{void onComplete(Task<T> task);}',
    'com/google/android/gms/tasks/Task.java': '''package com.google.android.gms.tasks;
public class Task<T>{private final T result;private final Exception error;public Task(T r,Exception e){result=r;error=e;}
public boolean isSuccessful(){return error==null;}public T getResult(){if(error!=null)throw new IllegalStateException("not successful");return result;}public Exception getException(){return error;}
public Task<T> addOnCompleteListener(OnCompleteListener<T> l){l.onComplete(this);return this;}}''',
    'com/google/firebase/FirebaseApp.java': '''package com.google.firebase;import java.util.*;
public class FirebaseApp{public static final List<FirebaseApp> apps=new ArrayList<>();public static List<FirebaseApp> getApps(android.content.Context c){return apps;}}''',
    'com/google/firebase/messaging/FirebaseMessaging.java': '''package com.google.firebase.messaging;import com.google.android.gms.tasks.Task;
public class FirebaseMessaging{public static int instances;public static Boolean autoInit;public static Task<String> next;public static RuntimeException crash;
public static FirebaseMessaging getInstance(){instances++;if(crash!=null)throw crash;return new FirebaseMessaging();}
public void setAutoInitEnabled(boolean b){autoInit=b;}public Task<String> getToken(){return next;}}''',
    'com/google/firebase/messaging/RemoteMessage.java': '''package com.google.firebase.messaging;import java.util.Map;
public class RemoteMessage{private final Map<String,String> data;public RemoteMessage(Map<String,String> d){data=d;}public Map<String,String> getData(){return data;}}''',
    'com/google/firebase/messaging/FirebaseMessagingService.java': '''package com.google.firebase.messaging;
public class FirebaseMessagingService extends android.content.Context{public void onNewToken(String token){}public void onMessageReceived(RemoteMessage message){}}''',
    'com/tiagolima/agendapersonal/R.java': 'package com.tiagolima.agendapersonal;public final class R{public static final class drawable{public static final int ic_stat_cadastro=0x7f080001;}}',
    'com/tiagolima/agendapersonal/MainActivity.java': 'package com.tiagolima.agendapersonal;public class MainActivity extends android.app.Activity{}',
}

HARNESS = r'''package com.tiagolima.agendapersonal;
import android.app.*;import android.content.*;import com.google.android.gms.tasks.Task;import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.*;import org.json.JSONObject;import java.util.*;
public final class PushAvisosHarness{
static int checks;static void check(boolean ok,String m){checks++;if(!ok)throw new AssertionError(m);}
static Map<String,String> data(String... kv){Map<String,String> m=new LinkedHashMap<>();for(int i=0;i<kv.length;i+=2)m.put(kv[i],kv[i+1]);return m;}
static JSONObject status(Context c){return new JSONObject(PushAvisos.status(c));}
public static void main(String[] a){
 // 1. Leitura da mensagem do Firebase.
 PushAvisos.Aviso ana=PushAvisos.ler(data("tipo","cadastro","titulo","Novo cadastro","texto","Ana se cadastrou. Toque para aprovar.","aluno","abcDEF123"));
 check(ana!=null&&ana.titulo.equals("Novo cadastro")&&ana.texto.equals("Ana se cadastrou. Toque para aprovar.")&&ana.tag().equals("cadastro:abcDEF123"),"cadastro lido");
 check(PushAvisos.ler(null)==null&&PushAvisos.ler(data("tipo","promo","titulo","x"))==null&&PushAvisos.ler(data("titulo","sem tipo"))==null,"só tipos conhecidos");
 PushAvisos.Aviso vazio=PushAvisos.ler(data("tipo","cadastro"));
 check(vazio.titulo.equals("Novo cadastro")&&vazio.texto.equals("Um aluno se cadastrou. Toque para aprovar.")&&vazio.tag().equals("cadastro"),"textos padrão");
 check(PushAvisos.ler(data("tipo","cadastro","aluno","../x")).aluno.isEmpty()&&PushAvisos.ler(data("tipo","cadastro","aluno","a b")).aluno.isEmpty(),"aluno inválido descartado");
 PushAvisos.Aviso sujo=PushAvisos.ler(data("tipo","cadastro","titulo","\nNovo\u0007 cadastro\t","texto","Bia\u0000 se cadastrou."));
 check(!sujo.titulo.matches("(?s).*[\\u0000-\\u001f].*")&&!sujo.texto.matches("(?s).*[\\u0000-\\u001f].*"),"sem caracteres de controle");
 StringBuilder longo=new StringBuilder();for(int i=0;i<300;i++)longo.append("😀");
 String cortado=PushAvisos.ler(data("tipo","teste","texto",longo.toString())).texto;
 check(cortado.codePointCount(0,cortado.length())==240&&!Character.isHighSurrogate(cortado.charAt(cortado.length()-1)),"texto longo cortado sem quebrar emoji");

 // 2. Notificação.
 Context c=new Context();
 check(PushAvisos.mostrar(c,ana),"aviso mostrado");
 NotificationChannel canal=c.manager.getNotificationChannel("cadastros");
 check(canal!=null&&canal.name.equals("Cadastros de alunos")&&canal.importance==NotificationManager.IMPORTANCE_HIGH&&canal.lockscreen==Notification.VISIBILITY_PRIVATE&&canal.badge&&canal.vibration&&!canal.description.isEmpty(),"canal com alerta e tela bloqueada");
 Notification n=c.manager.posted.get("cadastro:abcDEF123#4101");
 check(n!=null&&n.channel.equals("cadastros")&&n.icon==R.drawable.ic_stat_cadastro&&n.color==0xFF568900,"canal, ícone e cor");
 check(n.title.equals("Novo cadastro")&&n.text.equals(ana.texto)&&n.bigText.equals(ana.texto)&&n.autoCancel&&n.showWhen&&n.when>0,"textos e toque único");
 check(n.visibility==Notification.VISIBILITY_PRIVATE&&n.publicVersion!=null&&!n.publicVersion.text.contains("Ana")&&n.publicVersion.title.equals("Novo cadastro")&&n.publicVersion.icon==R.drawable.ic_stat_cadastro,"tela bloqueada sem conteúdo sensível mostra versão sem o nome");
 PendingIntent toque=n.contentIntent;
 check(toque.flags==(PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE)&&toque.requestCode=="cadastro:abcDEF123".hashCode(),"toque imutável, um por aluno");
 check(toque.intent.target==MainActivity.class&&toque.intent.flags==(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP),"toque abre o app sem recriar a tela");
 check("cadastro".equals(toque.intent.extras.get("agenda_aviso_tipo"))&&"abcDEF123".equals(toque.intent.extras.get("agenda_aviso_aluno"))&&toque.intent.extras.size()==2,"extras do toque");
 PushAvisos.mostrar(c,PushAvisos.ler(data("tipo","cadastro","texto","Caio se cadastrou. Toque para aprovar.","aluno","zzz999")));
 check(c.manager.posted.size()==2&&c.manager.posted.get("cadastro:zzz999#4101").contentIntent.requestCode!=toque.requestCode,"dois alunos, dois avisos");
 PushAvisos.mostrar(c,ana);check(c.manager.posted.size()==2,"o mesmo aluno substitui o aviso anterior");
 PushAvisos.Aviso teste=PushAvisos.ler(data("tipo","teste","titulo","Teste do aviso","texto","Se isto apareceu na tela bloqueada, os avisos de cadastro estão funcionando."));
 check(PushAvisos.mostrar(c,teste)&&c.manager.posted.get("teste#4101").publicVersion.text.equals(teste.texto),"aviso de teste");
 check(!PushAvisos.mostrar(c,null)&&c.manager.posted.size()==3,"mensagem desconhecida não mostra nada");
 Context recusa=new Context();recusa.manager.refuse=true;check(!PushAvisos.mostrar(recusa,ana),"Android recusou: sem travar");

 // 3. Abertura pelo toque.
 Intent aberto=new Intent(c,MainActivity.class).putExtra("agenda_aviso_tipo","cadastro").putExtra("agenda_aviso_aluno","abcDEF123").putExtra("outro","fica");
 check(PushAvisos.abertura(aberto).equals("cadastro")&&aberto.extras.keySet().equals(Set.of("outro")),"abertura lida uma vez");
 check(PushAvisos.abertura(aberto).isEmpty()&&PushAvisos.abertura(null).isEmpty(),"não repete");
 check(PushAvisos.abertura(new Intent(c,MainActivity.class).putExtra("tipo","cadastro")).isEmpty(),"só os extras do próprio aviso");
 check(PushAvisos.abertura(new Intent(c,MainActivity.class).putExtra("agenda_aviso_tipo","pagamento")).isEmpty(),"tipo desconhecido ignorado");

 // 4. Endereço de push: só quando o conteúdo pede.
 Context p=new Context();final int[] prontos={0};Runnable pronto=()->prontos[0]++;
 PushAvisos.atualizarToken(p,pronto);
 check(prontos[0]==1&&FirebaseMessaging.instances==0&&status(p).optString("erro").equals("sem-configuracao")&&!status(p).optBoolean("configurado"),"sem google-services.json: desligado sem tocar no Firebase");
 FirebaseApp.apps.add(new FirebaseApp());
 String token="fcmToken_abcdefghijklmnopqrstuvwxyz:0123456789-ABCDEF";
 FirebaseMessaging.next=new Task<>(token,null);PushAvisos.atualizarToken(p,pronto);
 check(prontos[0]==2&&Boolean.TRUE.equals(FirebaseMessaging.autoInit)&&PushAvisos.token(p).equals(token)&&status(p).optString("erro").isEmpty()&&status(p).optBoolean("token"),"endereço guardado e Firebase ligado só agora");
 FirebaseMessaging.next=new Task<>(null,new java.io.IOException("SERVICE_NOT_AVAILABLE"));PushAvisos.atualizarToken(p,pronto);
 check(prontos[0]==3&&PushAvisos.token(p).equals(token)&&status(p).optString("erro").equals("SERVICE_NOT_AVAILABLE"),"falha passageira mantém o endereço que funciona");
 FirebaseMessaging.crash=new IllegalStateException("Default FirebaseApp is not initialized");PushAvisos.atualizarToken(p,pronto);FirebaseMessaging.crash=null;
 check(prontos[0]==4&&status(p).optString("erro").startsWith("Default FirebaseApp"),"erro do Firebase não derruba o app");
 PushAvisos.salvarToken(p,"curto");check(PushAvisos.token(p).equals(token)&&status(p).optString("erro").equals("endereco-invalido"),"endereço inválido recusado");
 PushAvisos.atualizarToken(p,null);check(prontos[0]==4,"sem retorno também funciona");

 // 5. Estado para "Sons e alertas".
 Context s=new Context();JSONObject e=status(s);
 check(e.optString("app").equals("1.211"),"versão do APK no estado");
 s.packages.versionName=null;check(status(s).optString("app").isEmpty()&&status(s).optInt("versao")==1,"sem a versão do APK: estado continua");s.packages.versionName="1.211";
 check(e.optInt("versao")==1&&e.optString("canal").equals("ausente")&&!e.optBoolean("telaBloqueada")&&e.optBoolean("permissao")&&!e.optBoolean("token"),"antes do canal");
 PushAvisos.criarCanal(s);check(status(s).optString("canal").equals("alerta")&&status(s).optBoolean("telaBloqueada"),"canal com alerta");
 NotificationChannel sc=s.manager.getNotificationChannel("cadastros");
 sc.importance=NotificationManager.IMPORTANCE_DEFAULT;check(status(s).optString("canal").equals("som"),"sem pop-up");
 sc.importance=NotificationManager.IMPORTANCE_LOW;check(status(s).optString("canal").equals("silencioso"),"silencioso");
 sc.importance=NotificationManager.IMPORTANCE_NONE;check(status(s).optString("canal").equals("desligado"),"desligado");
 PushAvisos.criarCanal(s);check(sc.importance==NotificationManager.IMPORTANCE_NONE,"o app não desfaz a escolha do Tiago no canal");
 sc.lockscreen=Notification.VISIBILITY_SECRET;check(!status(s).optBoolean("telaBloqueada"),"tela bloqueada desligada no canal");
 s.permission=-1;check(!status(s).optBoolean("permissao"),"Android 13+: sem permissão de notificação");
 android.os.Build.VERSION.SDK_INT=32;check(status(s).optBoolean("permissao"),"Android 12: permissão não existe");android.os.Build.VERSION.SDK_INT=35;
 s.permission=0;s.manager.enabled=false;check(!status(s).optBoolean("permissao"),"notificações do app desligadas");

 // 6. Configurações do canal.
 Activity t=new Activity();PushAvisos.abrirConfiguracoes(t);
 check(t.started.size()==1&&t.started.get(0).action.equals("android.settings.CHANNEL_NOTIFICATION_SETTINGS")&&"cadastros".equals(t.started.get(0).extras.get("android.provider.extra.CHANNEL_ID"))&&"com.tiagolima.agendapersonal".equals(t.started.get(0).extras.get("android.provider.extra.APP_PACKAGE")),"abre o canal");
 Activity u=new Activity();u.missing.add("android.settings.CHANNEL_NOTIFICATION_SETTINGS");PushAvisos.abrirConfiguracoes(u);
 check(u.started.size()==1&&u.started.get(0).action.equals("android.settings.APP_NOTIFICATION_SETTINGS"),"sem tela do canal: notificações do app");
 Activity v=new Activity();v.missing.add("android.settings.CHANNEL_NOTIFICATION_SETTINGS");v.missing.add("android.settings.APP_NOTIFICATION_SETTINGS");PushAvisos.abrirConfiguracoes(v);
 check(v.started.isEmpty(),"sem nenhuma tela: sem travar");

 // 7. Serviço do Firebase.
 AgendaMessagingService servico=new AgendaMessagingService();
 servico.onMessageReceived(new RemoteMessage(data("tipo","cadastro","titulo","Novo cadastro","texto","Duda se cadastrou. Toque para aprovar.","aluno","uidDuda1")));
 check(servico.manager.posted.containsKey("cadastro:uidDuda1#4101"),"mensagem com o app fechado vira aviso");
 servico.onMessageReceived(new RemoteMessage(data("tipo","marketing","titulo","x")));check(servico.manager.posted.size()==1,"mensagem estranha ignorada");
 servico.onNewToken(token+"2");check(PushAvisos.token(servico).equals(token+"2"),"endereço novo guardado");
 System.out.println("PASS: aviso de cadastro, "+checks+" verificações.");
}}
'''


def main():
    static_checks()
    java = shutil.which('java')
    javac = shutil.which('javac')
    if not java:
        raise SystemExit('Java 17 é necessário para estes testes.')
    compiler = [javac] if javac else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-push-tests-') as temporary:
        work = Path(temporary)
        stubs = dict(STUBS)
        for name in ['JSONObject', 'JSONArray', 'JSONTokener']:
            stubs['org/json/' + name + '.java'] = (PROJECT / 'tests/native-json/org/json' / (name + '.java')).read_text()
        stubs['com/tiagolima/agendapersonal/PushAvisosHarness.java'] = HARNESS
        sources = []
        for name, content in stubs.items():
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding='utf-8')
            sources.append(str(target))
        sources += [str(SOURCE / 'PushAvisos.java'), str(SOURCE / 'AgendaMessagingService.java')]
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + sources, check=True)
        subprocess.run([java, '-ea', '-cp', str(work / 'classes'), 'com.tiagolima.agendapersonal.PushAvisosHarness'], check=True)
    print('PASS: ligações do aviso de cadastro no projeto (Firebase, manifesto, ponte, ícone) conferidas.')


if __name__ == '__main__':
    main()
