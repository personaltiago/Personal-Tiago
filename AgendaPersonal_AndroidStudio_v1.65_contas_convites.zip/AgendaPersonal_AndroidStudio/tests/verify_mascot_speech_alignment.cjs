'use strict';
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{chromium}=require('playwright');
const assets=path.resolve(__dirname,'../app/src/main/assets'),review=process.env.AGENDA_REVIEW_DIR;
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://local').pathname.slice(1)||'index.html';if(!['index.html','professor.html','cadastro.html','avaliacoes.html'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type','text/html;charset=utf-8');res.end(fs.readFileSync(path.join(assets,name)))});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const context=await browser.newContext({viewport:{width:390,height:900},isMobile:true,hasTouch:true});await context.route('https://**',r=>r.abort());
  await context.addInitScript(()=>{if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify({students:[],workoutFeedbackRequests:[],workoutFeedbackDeleted:{}}))});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port);await page.waitForFunction(()=>!!window.APmascot);
  await page.evaluate(async()=>{window.APaccounts={isTeacher:()=>true,teacherUid:()=> 'speech_teacher'};document.getElementById('apPreviewOverlay').classList.add('is-open');document.getElementById('apPreviewTeacher').srcdoc=await(await fetch('professor.html')).text();await APMascotArt.load()});
  const frame=page.frameLocator('#apPreviewTeacher');await frame.locator('#apTeacherMascotOpen').waitFor();
  const original=await frame.locator('body').evaluate(()=>JSON.stringify(state));let checked=0;
  for(const role of ['teacher','student']){
   if(role==='student')await page.evaluate(()=>{document.getElementById('apPreviewOverlay').classList.remove('is-open');window.APaccounts={isTeacher:()=>false};const student={id:'speech_student',name:'Aluno de teste'},area=APStudentModel.makeArea({students:[student],workoutPlans:[]},student);window.__AP_STUDENT_CONTEXT={storageId:'speech_student',role:'student',area,profile:area.profile};APstudentUI.activate();route('home')});
   const card=role==='teacher'?frame.locator('#apTeacherMascotOpen'):page.locator('#apMascotHome');
   for(const species of ['kitten','wolf','capybara','panda','rooster','alligator'])for(const [phase,xp] of [['baby',0],['teen',600],['adult',1800]])for(const width of [320,390,480]){
    await page.setViewportSize({width,height:900});
    const before=await page.evaluate(({role,species,xp})=>{const pet={schema:1,species,xp,name:'Léo',coins:321,owned:['shirt','home-bamboo'],equipped:{body:'shirt',home:'home-bamboo'}};if(role==='teacher'){localStorage.setItem('agenda_teacher_mascot_v1_speech_teacher',JSON.stringify(pet));APteacherMascot.refreshCard();return localStorage.getItem('agenda_teacher_mascot_v1_speech_teacher')}const store=exStore();store.mascot=pet;exSave(store);APmascot.refreshHome();return APstudentStorage.getItem(exStorageKey())},{role,species,xp});
    await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
    const geometry=await card.evaluate(n=>{
     const c=n.getBoundingClientRect(),mark=n.querySelector('.ap-teacher-mascot-mark,.ap-mascot-mini').getBoundingClientRect(),portrait=n.querySelector('[data-mascot-frame],image').getBoundingClientRect(),speech=n.querySelector('.ap-mascot-speech'),b=speech.getBoundingClientRect(),tail=n.querySelector('.ap-mascot-speech-tail path').getBoundingClientRect();
     const range=n.ownerDocument.createRange();range.selectNodeContents(speech);const text=range.getBoundingClientRect();
     return {left:b.left-c.left,right:c.right-b.right,headGap:portrait.top-b.bottom,size:portrait.width/mark.width,markWidth:mark.width,portraitLeft:portrait.left-c.left,portraitRight:c.right-portrait.right,orientation:n.querySelector('image').getAttribute('transform'),tailWidth:tail.width,tailHeight:tail.height,tailCount:n.querySelectorAll('.ap-mascot-speech-tail').length,fits:text.left>=b.left+8&&text.right<=b.right-8&&text.top>=b.top+8&&text.bottom<=b.bottom-8,visible:!!b.width&&!!b.height&&speech.textContent.length>30,box:[b.left,b.top,b.width,b.height]};
    });
    const label=role+'/'+species+'/'+phase+'/'+width;
    const turned=({kitten:['teen','adult'],wolf:['adult'],capybara:['baby','teen'],panda:['teen','adult'],rooster:['teen','adult'],alligator:['teen','adult']}[species]||[]).includes(phase);assert.equal(geometry.orientation,turned?'translate(320 0) scale(-1 1)':null,label+' faces the speech');assert.ok(Math.abs(geometry.size-({baby:.7,teen:.85,adult:1}[phase]))<.001,label+' keeps the three growth sizes');assert.ok(Math.abs(geometry.markWidth-(width<=360?88:112)*(phase==='adult'?1.6:1))<.03,label+' adult viewport is 1.6x the base, 35.6% above the prior adult');assert.ok(geometry.portraitLeft>=10&&geometry.portraitRight>=10,label+' keeps the whole portrait inside the scene');
    assert.ok(geometry.left>=8&&geometry.right>=8,label+' stays inside the scenery');assert.ok(geometry.headGap>=5&&geometry.headGap<=14,label+' keeps the balloon immediately above the head');assert.ok(geometry.tailWidth<=60&&geometry.tailHeight>=12&&geometry.tailHeight<=36&&geometry.tailCount===1,label+' has one short curved pointer');assert.ok(geometry.fits&&geometry.visible,label+' keeps all message text visible');
    await page.evaluate(role=>role==='teacher'?APteacherMascot.refreshCard():APmascot.refreshHome(),role);await page.evaluate(()=>new Promise(requestAnimationFrame));
    const after=await card.locator('.ap-mascot-speech').boundingBox();assert.ok(Math.abs(after.x-geometry.box[0])<.5&&Math.abs(after.y-geometry.box[1])<.5,label+' does not drift on refresh');
    assert.equal(await page.evaluate(role=>role==='teacher'?localStorage.getItem('agenda_teacher_mascot_v1_speech_teacher'):APstudentStorage.getItem(exStorageKey()),role),before,label+' does not modify saved pet/progress');
    if(review&&width===390){fs.mkdirSync(review,{recursive:true});await card.screenshot({path:path.join(review,role+'-'+species+'-'+phase+'.png')})}checked++;
   }
   await page.setViewportSize({width:320,height:900});
   await card.evaluate(n=>{n.querySelector('[data-mascot-name],.ap-mascot-home-copy strong').textContent='Companheiro querido';n.querySelector('.ap-mascot-speech').textContent='Hoje você tem 12 aulas na agenda. A próxima é às 17:55. Vamos organizar os próximos horários e reservar uma pausa entre os atendimentos?';const api=n.ownerDocument.defaultView.parent.APMascotHomes||APMascotHomes;api.decorate(n,{species:'alligator',xp:1800,equipped:{home:'home-bamboo'}})});
   await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const longLayout=await card.evaluate(n=>{const b=n.querySelector('.ap-mascot-speech').getBoundingClientRect(),title=n.querySelector('[data-mascot-name],.ap-mascot-home-copy strong').getBoundingClientRect(),image=n.querySelector('[data-mascot-frame],image').getBoundingClientRect(),range=n.ownerDocument.createRange();range.selectNodeContents(n.querySelector('.ap-mascot-speech'));const text=range.getBoundingClientRect();return {belowTitle:b.top-title.bottom,aboveAnimal:image.top-b.bottom,textBottom:b.bottom-text.bottom,right:n.getBoundingClientRect().right-b.right}});assert.ok(longLayout.belowTitle>=5&&longLayout.aboveAnimal>=5&&longLayout.textBottom>0&&longLayout.right>=8,role+' keeps longer names and messages clear of the animal '+JSON.stringify(longLayout));
  }
  assert.equal(await frame.locator('body').evaluate(()=>JSON.stringify(state)),original);assert.deepEqual(errors,[]);
  console.log('PASS: '+checked+' teacher/student layouts, six species, three growth phases and three mobile widths; correct portrait orientation, compact overhead balloon and short curved pointer, no drift, complete text, adult viewport enlarged 35.6% over the prior adult, original younger sizes and saved records preserved. Local browser; auth/network simulated.');
 }finally{await browser.close();server.close()}
})().catch(e=>{console.error(e);server.close();process.exitCode=1});
