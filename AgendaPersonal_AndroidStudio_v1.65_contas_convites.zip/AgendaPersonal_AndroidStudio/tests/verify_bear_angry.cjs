'use strict';
// Loads the REAL bear runtime packed in cadastro.html (plus the real mascot model from index.html) and checks the
// numbers that drive the "bravo" reaction. The reported case is the adult black panda in the default or rest pose,
// which is drawn by APMascotBearPoseAttention (its own values + mesh), NOT by the lower APMascotBearPoses layer.
// "Bravo" must change only the face: the paw/chest mesh warp belongs to the paw and tail gestures.
// This checks reaction weights and mesh vertex displacement; it does not render the bear on a device.
const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),vm=require('node:vm'),assert=require('node:assert/strict');
const file=process.argv[2]||path.join(__dirname,'..','web','native-release.agenda.json');
const files=JSON.parse(fs.readFileSync(file,'utf8')).files;
const packed=files['cadastro.html'].match(/id="ap-mascot-gesture-runtime"[^>]*data-ap-gzip>([\s\S]*?)<\/script>/);
if(!packed){console.log('Urso: pacote usa outro formato de runtime (versão 1.12.25x); verificação específica ignorada.');process.exit(0);}
const runtime=JSON.parse(zlib.gunzipSync(Buffer.from(packed[1].trim(),'base64')).toString('utf8'));
const model=files['index.html'].match(/<script\b[^>]*\bid="ap-student-mascot-model"[^>]*>([\s\S]*?)<\/script>/);
assert.ok(model,'Modelo do mascote não encontrado no index.html');
const sandbox={console,Math,Object,Array,Number,String,JSON,Map,Set,WeakMap,Promise,Float32Array,Uint16Array,Uint8Array,Uint8ClampedArray,Error,Date,Image:function(){},
 document:{addEventListener(){},removeEventListener(){}},navigator:{},requestAnimationFrame:()=>0,cancelAnimationFrame(){},addEventListener(){}};
sandbox.globalThis=sandbox;sandbox.window=sandbox;vm.createContext(sandbox);
vm.runInContext(model[1],sandbox,{filename:'ap-student-mascot-model'});
// The packed runtime registers its modules first and may touch DOM-only code at the very end; the modules are what matter here.
try{vm.runInContext(runtime,sandbox,{filename:'ap-mascot-gesture-runtime'})}catch(error){if(!/addEventListener|document|window|is not/.test(String(error.message)))throw error}
const attention=sandbox.APMascotBearPoseAttention,poses=sandbox.APMascotBearPoses;
assert.ok(attention&&typeof attention.values==='function'&&typeof attention.project==='function'&&typeof attention.supports==='function','Camada de atenção do urso não encontrada');
assert.ok(poses&&typeof poses.values==='function'&&typeof poses.profile==='function','Camada base de poses do urso não encontrada');
let cases=0;
const eq=(name,a,b)=>{cases++;assert.deepEqual(a,b,name)},ok=(name,v)=>{cases++;assert.ok(v,name)};
const still={x:0,y:0,ear:0};
function state(pose){return{schema:1,species:'panda',name:'Léo',goal:3,xp:1800,xpSpent:0,colorShop:1,coins:275,colors:{panda:'black'},poses:pose==='default'?{}:{panda:pose},owned:['color-panda-black','pose-panda-sit','pose-panda-rest']}}
function maxDisplacement(profile,values){let best=0;for(let y=0;y<=320;y+=4)for(let x=0;x<=320;x+=4){const p=attention.project(x,y,profile,values);best=Math.max(best,Math.hypot(p[0]-x,p[1]-y))}return best}
// --- Reported case: adult black panda (Léo), default and rest poses ---------------------------------------------
for(const pose of ['default','rest']){
 const s=state(pose);ok('urso adulto preto usa a camada de atenção ('+pose+')',attention.supports(s));
 const base=poses.profile(s);ok('perfil do urso ('+pose+')',base&&base.pose===pose);
 const profile={...base,eyes:attention.eyes[pose]};
 for(const reduced of [false,true]){
  const label=pose+(reduced?' estático':'');
  for(const t of [.3,.6,1,1.6,2.3]){
   const angry=attention.values(profile,'angry',t,still,reduced);
   eq('bravo ('+label+', '+t+'s) não levanta pata/peito',angry.paw,0);
   ok('bravo ('+label+', '+t+'s) continua mostrando o rosto bravo',t>=.3&&angry.grump>0);
   eq('bravo ('+label+', '+t+'s) não gira nem move a cabeça',[angry.angle,angry.nod,angry.sniff,angry.ear0,angry.ear1],[0,0,0,0,0]);
   eq('bravo ('+label+', '+t+'s) não desloca nenhum ponto da malha',maxDisplacement(profile,angry),0);
  }
 }
 // Controls: the paw and tail gestures keep lifting the paw, so this test can really see a regression.
 for(const kind of ['paw','tail']){
  const v=attention.values(profile,kind,1,still,false);
  eq(kind+' ('+pose+') continua levantando a pata',v.paw,1);
  ok(kind+' ('+pose+') continua deslocando a malha',maxDisplacement(profile,v)>10);
 }
}
// --- Lower layer used by the other bear variants (baby/teen, other colours, authored poses) -----------------------
const lower={pose:'default',age:'teen',head:[160,40,60,0,120],nose:[160,100],ears:[],authoredWholePose:false,style:{tilt:.024,nod:1.1,ear:.65,sniff:.6,recoil:1.15}};
const lowerAngry=poses.values(lower,'angry',1,still,false,false),lowerStill=poses.values(lower,'angry',1,still,false,true);
eq('camada base: bravo não levanta pata/peito',lowerAngry.paw,0);eq('camada base estática: bravo não levanta pata/peito',lowerStill.paw,0);
ok('camada base: bravo mostra o rosto',lowerAngry.angry===1&&lowerStill.angry===1);
eq('camada base: pata continua levantando',poses.values(lower,'paw',1,still,false,false).paw,1);
console.log('Urso bravo: '+cases+' verificações passaram; Léo (panda adulto preto) em pose normal e deitado, movimento normal e reduzido: só o rosto muda, nenhum ponto do peito/pata se move; pata e rabo preservados. Sem aparelho físico.');
