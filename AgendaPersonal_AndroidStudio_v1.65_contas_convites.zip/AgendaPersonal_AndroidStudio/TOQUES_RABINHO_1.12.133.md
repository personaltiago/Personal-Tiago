# Correção dos toques — conteúdo 1.12.133 / sequência 239

## Correções

A cauda era reconhecida por uma elipse pequena, que não cobria pontas, curvas ou caudas enroladas. Ela também não existia no reconhecimento de algumas poses de descanso e pelagens do panda. O reconhecimento agora acompanha o contorno da cauda, com áreas próprias por espécie, pose e idade, incluindo as imagens temporárias de carinho e patinha levantada. Asas e patas não recebem uma área de cauda; a capivara continua sem cauda fictícia.

Um toque breve no corpo agora produz curiosidade, sem imagem de protesto. Orelha e nariz mantêm suas reações próprias. O rabinho produz protesto. A patinha/asa de dois toques exige dois contatos distintos, do mesmo tipo e na mesma região, separados por até 280 ms e por até 24 pixels. Eventos de mouse de compatibilidade emitidos logo após um toque são ignorados, impedindo que um único contato seja contado duas vezes. O toque simples aguarda 285 ms para distinguir o gesto duplo.

O carinho continua sendo acionado ao deslizar. Em entrada por toque, há tolerância de até 5 pixels nas bordas transparentes, sempre buscando um pixel realmente opaco. O cenário distante, o balão e a casa não viram áreas de reação.

O carregamento da imagem protege a reação desde o início. Atualizar o cartão do aluno durante a resposta não substitui o desenho animado pela pose anterior. A pose escolhida retorna normalmente ao terminar; gesto cancelado e pressão longa não viram toque breve.

## Preservação

Nenhuma imagem, pelagem, compra, moeda, XP, treino, histórico ou dado dos alunos é alterado por esta correção. As imagens de carinho e protesto permanecem exatamente iguais à versão 1.12.132. A diferença entre filhote, adolescente e adulto e o tamanho adulto permanecem preservados. Não há novo campo de dados nem migração de dados pessoais.

Esta é uma atualização de conteúdo para a central normal do aplicativo. O projeto mantém Android 1.158, identificador e assinatura existentes. Não foi gerado um APK novo nesta entrega.

## Verificação

- Contatos marcados manualmente nas pontas e curvas das caudas, independentes das áreas definidas pelo código, nas poses normais, durante carinho e durante a patinha levantada; pelagens alternativas e pontos negativos em asas/corpo.
- Contatos reais pelo protocolo de toque do Chromium no professor e no aluno: toque único curioso, mouse de compatibilidade duplicado, dois toques reais, ponta da cauda, pressão longa, cancelamento, imagem com decodificação atrasada e atualização do cartão durante a reação.
- Regressões de espécies, idades, poses, anatomia, carinho, corações, realce de toque, movimento reduzido, navegação pela casa e geometria estável.
- Inventário, integridade dos arquivos e contrato de importação do pacote de conteúdo.

Os testes usam Chromium local e autenticação/rede simuladas. A confirmação no aparelho do usuário continua sendo a verificação final do comportamento específico do WebView instalado.
