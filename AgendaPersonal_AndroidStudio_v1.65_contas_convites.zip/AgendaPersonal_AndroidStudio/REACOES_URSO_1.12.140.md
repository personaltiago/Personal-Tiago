# Conteúdo 1.12.140 / sequência 246

Correção da integração das reações do urso adulto sentado nas seis pelagens.

A versão 1.12.139 ativava a prévia R14 somente para o adulto preto sentado. O vídeo `1000044833.mp4` mostra a pelagem Canela na pose sentada; por isso ela ainda usava curiosidade sem deslocamento dos olhos e o protesto anterior. Esta versão inclui um caminho específico para as outras cinco pelagens, preservando seus retratos existentes.

- Toque no cenário: as pupilas acompanham o ponto tocado dentro dos contornos dos próprios olhos. A cabeça recebe apenas a inclinação pequena da prévia, sem girar o animal inteiro.
- Um toque no corpo: curiosidade com o mesmo comportamento de olhar. As coordenadas do ponto tocado são normalizadas uma única vez.
- Orelha e nariz: reações locais, com os parâmetros suaves da prévia.
- Dois toques rápidos: protesto de 2,8 segundos, boca fechada e expressão contrariada. Uma pata fica apoiada na barriga e a outra fica levantada, com a almofadinha para a frente. A imagem permanece estática; depois volta à pose escolhida.
- O carinho conserva a função `react()` e o catálogo de imagens da 1.12.139 sem alterações. A base de conferência está em `web/approved-bear/affection-baseline-139.json`.
- Inicialização do relógio da animação corrigida para que a preparação do primeiro quadro não consuma a duração da reação.
- Mesmo atendimento nas telas do professor, aluno e casa. A casinha continua sendo o atalho que abre a personalização.

As cinco novas expressões de protesto foram produzidas com edição de imagem a partir dos respectivos sprites existentes. A conversão para WebP de 240 × 240 é somente preparação do formato consumido pelo aplicativo. Os hashes de origem e de entrega constam em `web/approved-bear/expressions-140.json`.

Escopo: adulto sentado, nas pelagens Preto e branco, Todo branco, Todo preto, Castanho e branco, Creme e Canela. Os filhotes, adolescentes, outras poses e demais espécies não foram redesenhados nesta entrega. Os outros animais seguem para uma etapa posterior.

Atualização de conteúdo: bridgeVersion 3, dataSchema 4, Android 1.158. Não contém novo APK nem indica publicação no servidor. Esquemas de dados, backups, alunos, treinos, cargas, históricos, links, moedas e compras continuam preservados.

Validação: `tests/verify_bear_coat_gestures.cjs` usa toques reais em Chromium, contas simuladas e rede externa bloqueada. Mede o deslocamento visível das pupilas no quadro renderizado, verifica o protesto estático e o carinho nas seis pelagens, nas telas do professor e aluno, e compara os dados salvos antes/depois. `tests/verify_approved_bear.cjs` confere a integração R14 preta. Não substitui teste em Android/iPhone físico.
