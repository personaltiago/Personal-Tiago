# Feedbacks online e presenciais — 1.12.93

Atualização de conteúdo sobre o APK Android 1.151, sem reinstalação. Professor e aluno devem atualizar o aplicativo.

## Uso

1. O professor abre o treino presencial, registra a execução e confirma **Finalizar treino**. O pedido de feedback é salvo junto com a sessão.
2. Com conexão, o pedido é entregue à conta vinculada do aluno. Sem conexão, fica salvo no aparelho do professor para nova tentativa.
3. A avaliação final do professor (Feedback / observações e esforço opcional de 1 a 10) acompanha o pedido. No aplicativo aberto ou ao reabrir, o pet do aluno mostra o aviso vermelho perto do início da tela. O toque abre o formulário com a avaliação do professor, horários da sessão, duração, intensidade e comentário opcional do aluno.
4. O rascunho e a resposta aguardando envio são preservados ao fechar o aplicativo. A pendência some após confirmação do serviço. Se o aluno ocultou o pet, um botão mantém o acesso ao pedido.
5. **Alunos → Feedbacks**, entre Online e Arquivados, reúne respostas recebidas e pedidos aguardando resposta. A resposta pertence a um único aluno e sessão; o nome não é usado para associar contas.
6. O feedback que o aluno online já preenche ao finalizar chega à mesma central, sem outro questionário. Recibos já enviados anteriormente também aparecem ao atualizar. A foto vinculada à conta é sincronizada e aparece no cartão, se disponível.
7. O proprietário informou que a publicação dos feedbacks é prevista no contrato. Essa configuração libera Preparar imagem e Copiar texto, sem pedir autorização por feedback. O aplicativo não transforma registros antigos em novos aceites individuais. O professor confere a imagem, salva ou compartilha pelo seletor do telefone. Os textos originais do aluno e a avaliação final do professor são apresentados separadamente.

## Entrega e limites

- O aluno precisa de uma conta ativa aprovada e vinculada ao cadastro. Sem conta, o pedido permanece local e indica a necessidade de vínculo no perfil; depois, o professor pode tocar em Tentar envio.
- O aviso é interno ao aplicativo e sincroniza enquanto ele está aberto ou ao reabrir. Esta entrega não adiciona push do Android com o aplicativo encerrado.
- Não são disparados pedidos para sessões antigas, simulações do pet ou resumos importados de smartwatch.
- A resposta recebida é única por sessão. Reenvios de rede não substituem nem duplicam o comentário recebido.
- Pedidos e respostas do professor fazem parte da agenda, da sincronização existente e do backup completo. Credenciais e observações privadas do exercício não são enviadas no pedido. Somente a avaliação final escrita no encerramento é incluída para o aluno.
- Não há postagem automática em redes sociais. A imagem é conferida e compartilhada pelo professor.
- Os cronômetros em segundos, resultados da última realização, observações e correções de séries foram preservados. A central reconhece também séries cronometradas válidas acima de 999 segundos.

## Serviço e verificação

Serviço existente: https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site

Sites versão 8; commit 95118f5a3807f851615db84626129314077be16f. As três novas rotas exigem autenticação Firebase; dados ficam privados no armazenamento existente. O vínculo ativo do aluno é conferido no servidor. O código do serviço está no repositório do mesmo Site.

Testes: testes de API e integração das telas reais do professor e aluno, em armazenamentos independentes, usando o Worker atual e identidades/armazenamento remotos de teste. Incluem conclusão real, falha de gravação sem pedido falso, envio sem internet, reabertura, confirmação, duplicação, conta errada, rascunho, avaliação final do professor, feedback online original sem segundo formulário, foto recebida e exportada, política de publicação contratual sem aceite individual, texto escapado, exportação PNG com comentários longos e larguras de 280 a 640 px. Pontes Android são simuladas. Abertura, central, backup e cronômetros por série também verificados.

Validação em celulares físicos e com contas reais continua pendente. Não foram enviados pedidos ou respostas de teste a alunos reais.

Para repetir o teste integrado, obtenha o código atual do serviço e defina AGENDA_DISTRIBUTION_WORKER apontando para worker/index.js e AGENDA_CHROMIUM apontando para o Chromium local; execute node tests/verify_feedback.cjs.


## Limpeza da central (1.12.96)

Apagar feedback remove o conteúdo da lista do professor e grava apenas o ID em workoutFeedbackDeleted. O identificador impede reimportação do mesmo recibo no refresh. A gravação de conteúdo removido e identificador é atômica no mesmo JSON da agenda. Erro de armazenamento não altera o estado em memória nem anuncia exclusão. Não muda o treino, o aluno, as respostas no serviço ou arquivos exportados.

Selecionar permite exclusão em lote, sempre limitada aos IDs confirmados. Busca e troca de aba limpam a seleção. Feedbacks que chegam depois de abrir a confirmação não entram no lote. Troca de conta fecha a confirmação. Pedidos pendentes enviados continuam disponíveis ao aluno e essa condição aparece antes de confirmar.

O modelo de sincronização reúne os identificadores de remoção antes de comparar registros. Uma cópia desatualizada não reintroduz o texto apagado, inclusive em conflito entre leitura e exclusão. A regra é específica para feedbacks; as demais regras de conflito de alunos, treinos e avaliações permanecem. As duas instalações devem estar atualizadas para aplicar esta regra. Backups antigos continuam representando o estado da data em que foram criados.

A imagem do cartão é transitória: ao fechar a prévia, o canvas é zerado e os manipuladores que retêm base64 são liberados. Não há segunda cópia de foto por feedback; o avatar usa a foto existente do cadastro. A exclusão não pretende limpar todos os arquivos e caches do aplicativo.
