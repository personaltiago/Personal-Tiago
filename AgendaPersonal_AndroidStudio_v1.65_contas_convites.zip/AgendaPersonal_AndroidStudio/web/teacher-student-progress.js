(function(){
 'use strict';
 const M=APStudentProgressModel,$=id=>document.getElementById(id),safe=value=>hesc(String(value??''));
 const root=document.createElement('div');root.id='studentEvolutionDialog';root.className='dialog';root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-labelledby','studentEvolutionTitle');
 root.innerHTML='<div class="sheet ap-student-evolution"><div class="sheet-head"><h3 id="studentEvolutionTitle">Evolução do aluno</h3><button class="close" type="button" id="studentEvolutionClose" aria-label="Fechar evolução do aluno">×</button></div><p id="studentEvolutionName" class="ap-student-evolution-name"></p><div class="ap-student-evolution-source"><div><strong>Treinos do aplicativo</strong><p id="studentEvolutionSync" role="status" aria-live="polite"></p></div><button class="btn" id="studentEvolutionRefresh" type="button">Atualizar</button></div><div id="studentEvolutionContent"></div><section id="apTeacherUnifiedHistory"></section><section class="ap-student-evolution-pdf"><h4>Registros da agenda e PDF</h4><p>Consulte também os treinos registrados pelo professor e gere o relatório que você já utiliza.</p><button id="studentEvolutionAgenda" class="btn primary full" type="button">Ver evolução da agenda e gerar PDF</button></section></div>';
 document.body.appendChild(root);
 let selection=null,period='3m',metric='load',exerciseKey='',series=0,generation=0,busy=false;
 const active=()=>!!selection&&root.classList.contains('open')&&(studentById(selection.studentId)?.firebaseUid||'')===selection.uid&&window.parent.APaccounts?.isTeacher()===true;
 const format=n=>Number(n).toLocaleString('pt-BR',{maximumFractionDigits:2});
 const date=t=>new Date(t).toLocaleDateString('pt-BR');
 const fullDate=t=>new Date(t).toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'});
 function source(){try{return window.parent.APWorkoutSync}catch(_){return null}}
 function records(){if(!active()||!selection.uid)return [];return source()?.records(selection.uid)||[]}
 function from(){if(period==='all')return -Infinity;const d=new Date();d.setMonth(d.getMonth()-Number(period.slice(0,-1)));d.setHours(0,0,0,0);return d.getTime()}
 function syncStatus(){
  if(!selection)return;const info=source()?.summary(selection.uid),button=$('studentEvolutionRefresh');button.disabled=busy||!selection.uid;
  $('studentEvolutionSync').textContent=!selection.uid?'Este aluno ainda não tem uma conta vinculada ao aplicativo.':busy?'Consultando os treinos enviados pelo aluno…':info?.message|| (info?.at?'Última consulta: '+fullDate(new Date(info.at).getTime())+'.':'O aluno precisa abrir o aplicativo atualizado e conectar à internet para enviar seus treinos concluídos.');
 }
 function chart(points,label,unit){
  if(!points.length)return '<div class="empty"><strong>Sem valores para este gráfico.</strong>As cargas não informadas e as séries sem registro ficam fora da comparação.</div>';
  const w=360,h=220,left=48,right=20,top=25,bottom=42,pw=w-left-right,ph=h-top-bottom,values=points.map(p=>p.value),min=Math.min(...values),max=Math.max(...values),pad=max===min?Math.max(1,max*.06):(max-min)*.12,low=Math.max(0,min-pad),high=max+pad,first=points[0].when,last=points.at(-1).when;
  const xy=points.map(p=>({...p,x:left+(last===first?pw/2:(p.when-first)/(last-first)*pw),y:top+ph-(p.value-low)/(high-low)*ph}));
  const desc=points.map(p=>fullDate(p.when)+': '+format(p.value)+' '+unit).join('; '),color='var(--purple2,#c777f6)';
  return '<svg class="ap-student-evolution-chart" viewBox="0 0 '+w+' '+h+'" role="img" aria-label="'+safe(label+' — '+desc)+'"><title>'+safe(label)+'</title><desc>'+safe(desc)+'</desc>'+[low,(low+high)/2,high].map(v=>{const y=top+ph-(v-low)/(high-low)*ph;return '<line x1="'+left+'" x2="'+(w-right)+'" y1="'+y+'" y2="'+y+'" stroke="var(--line,#3b3045)"/><text x="'+(left-7)+'" y="'+(y+4)+'" text-anchor="end">'+safe(format(v))+'</text>'}).join('')+'<text x="'+left+'" y="13">'+safe(unit)+'</text>'+(points.length>1?'<polyline points="'+xy.map(p=>p.x+','+p.y).join(' ')+'" fill="none" stroke="'+color+'" stroke-width="3" stroke-linejoin="round"/>':'')+xy.map(p=>'<circle cx="'+p.x+'" cy="'+p.y+'" r="4" fill="'+color+'"><title>'+safe(fullDate(p.when)+': '+format(p.value)+' '+unit)+'</title></circle>').join('')+'<text x="'+left+'" y="'+(h-12)+'">'+safe(date(first))+'</text>'+(first!==last?'<text x="'+(w-right)+'" y="'+(h-12)+'" text-anchor="end">'+safe(date(last))+'</text>':'')+'</svg>';
 }
 function render(){
  if(!active())return;syncStatus();const selectedRecords=records().filter(r=>r.finishedAt>=from()),groups=M.groups(selectedRecords),group=groups.find(g=>g.key===exerciseKey)||groups[0];exerciseKey=group?.key||'';series=Math.min(series,Math.max(0,(group?.sets||1)-1));
  const points=M.points(group,metric,series),first=points[0],last=points.at(-1),unit=metric==='load'?'kg':'rep',label=metric==='load'?'Carga · série '+(series+1):'Repetições prescritas concluídas',difference=first&&points.length>1?last.value-first.value:null;
  const focused=document.activeElement?.id;
  $('studentEvolutionContent').innerHTML='<div class="ap-student-evolution-filters"><label class="field"><span>Período</span><select id="studentEvolutionPeriod">'+[['1m','Último mês'],['3m','Últimos 3 meses'],['6m','Últimos 6 meses'],['12m','Últimos 12 meses'],['all','Todo o histórico']].map(([v,n])=>'<option value="'+v+'" '+(period===v?'selected':'')+'>'+n+'</option>').join('')+'</select></label><label class="field"><span>Exercício e treino</span><select id="studentEvolutionExercise" '+(group?'':'disabled')+'>'+(group?groups.map(g=>'<option value="'+safe(g.key)+'" '+(exerciseKey===g.key?'selected':'')+'>'+safe(g.name+' · '+g.workoutName)+'</option>').join(''):'<option>Sem exercícios registrados</option>')+'</select></label></div><div class="ap-student-evolution-metrics" role="group" aria-label="Dado do gráfico"><button class="btn '+(metric==='load'?'primary':'')+'" data-progress-metric="load" aria-pressed="'+(metric==='load')+'">Cargas</button><button class="btn '+(metric==='reps'?'primary':'')+'" data-progress-metric="reps" aria-pressed="'+(metric==='reps')+'">Repetições da ficha</button></div>'+
   (!selectedRecords.length?'<div class="empty"><strong>Nenhum treino do aluno neste período.</strong>Os treinos concluídos serão exibidos depois que o aplicativo do aluno os enviar com conexão. Os registros da agenda continuam disponíveis abaixo.</div>':
   '<div class="ap-student-evolution-summary"><div><span>Treinos no período</span><strong>'+selectedRecords.length+'</strong></div><div><span>Último registro no gráfico</span><strong>'+(last?format(last.value)+' <small>'+unit+'</small>':'—')+'</strong></div><div><span>Variação no período</span><strong>'+(difference===null?'—':(difference>0?'+':difference<0?'−':'')+format(Math.abs(difference))+' <small>'+unit+'</small>')+'</strong></div></div>'+
   (metric==='load'&&group?'<label class="field ap-student-evolution-series"><span>Série comparada</span><select id="studentEvolutionSeries">'+Array.from({length:group.sets},(_,i)=>'<option value="'+i+'" '+(i===series?'selected':'')+'>Série '+(i+1)+'</option>').join('')+'</select></label>':'')+
   '<section class="ap-student-evolution-plot"><h4>'+safe(group?.name||'Exercício')+'</h4><p>'+safe(label)+(metric==='reps'?'. Quantidade prevista nas séries marcadas como concluídas.':'. Valores em kg registrados pelo aluno; séries sem carga não viram zero.')+'</p>'+chart(points,label,unit)+(points.length===1?'<p class="note">Primeiro valor registrado. A comparação ficará disponível após outro treino com este dado.</p>':'')+'</section>'+
   (points.length?'<div class="ap-student-evolution-table"><table><caption>Valores usados no gráfico</caption><thead><tr><th scope="col">Data e hora</th><th scope="col">'+safe(label)+'</th></tr></thead><tbody>'+points.slice().reverse().map(p=>'<tr><td>'+safe(fullDate(p.when))+'</td><td>'+safe(format(p.value)+' '+unit)+'</td></tr>').join('')+'</tbody></table></div>':''));
  $('studentEvolutionPeriod').onchange=e=>{period=e.target.value;render()};$('studentEvolutionExercise').onchange=e=>{exerciseKey=e.target.value;series=0;render()};if($('studentEvolutionSeries'))$('studentEvolutionSeries').onchange=e=>{series=Number(e.target.value);render()};
  for(const b of root.querySelectorAll('[data-progress-metric]'))b.onclick=()=>{metric=b.dataset.progressMetric;render();root.querySelector('[data-progress-metric="'+metric+'"]').focus({preventScroll:true})};
  window.APWatchHistory?.renderTeacher(selection.studentId,records(),from(),$('apTeacherUnifiedHistory'));
  if(focused?.startsWith('studentEvolution'))$(focused)?.focus({preventScroll:true});
 }
 async function refresh(){
  if(!active()||!selection.uid||busy)return;busy=true;syncStatus();const ticket=generation,id=selection.uid;
  try{const api=await window.parent.APloadWorkoutSync();if(ticket!==generation||!active())return;await api.refresh(id)}catch(_){}finally{if(ticket===generation&&active()){busy=false;render()}}
 }
 function open(){
  if(window.parent.APaccounts?.isTeacher()!==true)return;const s=currentProfileStudent();if(!s)return;
  generation++;selection={studentId:s.id,uid:s.firebaseUid||''};busy=false;period='3m';metric='load';exerciseKey='';series=0;$('studentEvolutionName').textContent=s.name||'Aluno';openDialog(root.id);render();refresh();
 }
 function close(){generation++;busy=false;closeDialog(root.id)}
 $('studentEvolutionClose').onclick=close;$('studentEvolutionRefresh').onclick=refresh;
 $('studentEvolutionAgenda').onclick=()=>{if(!active())return;workoutStudentId=selection.studentId;openStudentWorkoutProgress()};
 window.APTeacherProgress=Object.freeze({open,refresh,render});
})();
