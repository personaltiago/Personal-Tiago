(function(){
 'use strict';
 function normalize(value){
  let raw=String(value||'').trim();
  if(/^(?:(?:www|m|vt|vm)\.)?tiktok\.com\//i.test(raw))raw='https://'+raw;
  try{const url=new URL(raw);return ['https:','http:'].includes(url.protocol)&&!url.username&&!url.password?url.href:''}catch(_){return ''}
 }
 function isTikTok(value){try{return ['tiktok.com','www.tiktok.com','m.tiktok.com','vt.tiktok.com','vm.tiktok.com'].includes(new URL(normalize(value)).hostname.toLowerCase())}catch(_){return false}}
 function action(value){return isTikTok(value)?'Abrir no TikTok ↗':'Abrir vídeo ↗'}
 function open(value){
  const url=normalize(value);if(!url)return false;
  try{if(window.Android?.openExternal){Android.openExternal(url);return true}window.open(url,'_blank','noopener,noreferrer');return true}catch(_){return false}
 }
 window.APExternalVideo={normalize,isTikTok,action,open};
})();
