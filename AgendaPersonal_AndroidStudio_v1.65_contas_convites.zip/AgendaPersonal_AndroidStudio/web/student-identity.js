(function(){
 'use strict';
 const $=id=>document.getElementById(id),owner=()=>{const c=window.__AP_STUDENT_CONTEXT;return c?.role==='student'?c.storageId:''};
 const modal=$('apStudentPhotoCrop'),canvas=$('apStudentCropCanvas');let session=null,request=0,returnFocus=null;
 function cancel(){request++;session=null;modal.hidden=true;document.body.classList.remove('ap-student-cropping');returnFocus?.focus?.();returnFocus=null}
 function current(s){return !!s&&s.owner===owner()&&s.key===profilePhotoKey()}
 function image(src){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>img.naturalWidth&&img.naturalHeight?resolve(img):reject(Error());img.onerror=reject;img.src=src})}
 function read(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=reject;r.readAsDataURL(file)})}
 function surface(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return c}
 function clamp(s){s.zoom=Math.max(1,Math.min(5,Number(s.zoom)||1));s.r=Math.min(s.img.naturalWidth,s.img.naturalHeight)/2/s.zoom;s.x=Math.max(s.r,Math.min(s.img.naturalWidth-s.r,s.x));s.y=Math.max(s.r,Math.min(s.img.naturalHeight-s.r,s.y))}
 function draw(){const s=session;if(!s)return;clamp(s);const g=canvas.getContext('2d'),W=canvas.width,H=canvas.height,scale=Math.min((W-32)/s.img.naturalWidth,(H-32)/s.img.naturalHeight),w=s.img.naturalWidth*scale,h=s.img.naturalHeight*scale,left=(W-w)/2,top=(H-h)/2,x=left+s.x*scale,y=top+s.y*scale,r=s.r*scale;s.viewport={scale,left,top};
  g.fillStyle='#08070c';g.fillRect(0,0,W,H);g.drawImage(s.img,left,top,w,h);g.beginPath();g.rect(0,0,W,H);g.moveTo(x+r,y);g.arc(x,y,r,0,Math.PI*2,true);g.fillStyle='#05030aa6';g.fill('evenodd');g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.strokeStyle='#fff';g.lineWidth=3;g.stroke();$('apStudentCropZoom').value=s.zoom;$('apStudentCropZoomValue').textContent=Number(s.zoom.toFixed(2))+'×';
 }
 async function open(src,geometry=null){
  const ticket=++request,id=owner(),key=profilePhotoKey();if(!id){toast('A alteração da foto está disponível na conta do aluno.');return}
  try{const img=await image(src);if(ticket!==request||id!==owner()||key!==profilePhotoKey()||$('profilePhotoDialog').hidden)return;session={owner:id,key,source:src,img,x:Number.isFinite(geometry?.x)?geometry.x*img.naturalWidth:img.naturalWidth/2,y:Number.isFinite(geometry?.y)?geometry.y*img.naturalHeight:img.naturalHeight/2,zoom:geometry?.zoom||1,pointer:null};returnFocus=document.activeElement;modal.style.setProperty('--crop-accent',prefs().color||'#c22276');modal.hidden=false;document.body.classList.add('ap-student-cropping');draw();canvas.focus()}catch(_){if(ticket===request)toast('Não foi possível abrir a foto. Escolha outra imagem.')}
 }
 async function select(event){
  const file=event.target.files?.[0];event.target.value='';if(!file)return;
  if(!owner())return toast('A alteração da foto está disponível na conta do aluno.');
  if(!['image/jpeg','image/png','image/webp'].includes(file.type))return toast('Escolha uma foto JPG, PNG ou WebP.');
  if(file.size>8*1024*1024)return toast('Escolha uma foto com até 8 MB.');
  const ticket=++request,id=owner(),key=profilePhotoKey();try{const img=await image(await read(file));if(ticket!==request||id!==owner()||key!==profilePhotoKey())return;
   const scale=Math.min(1,1200/Math.max(img.naturalWidth,img.naturalHeight)),c=surface(Math.max(1,Math.round(img.naturalWidth*scale)),Math.max(1,Math.round(img.naturalHeight*scale))),g=c.getContext('2d');g.fillStyle='#121b27';g.fillRect(0,0,c.width,c.height);g.drawImage(img,0,0,c.width,c.height);await open(c.toDataURL('image/jpeg',.86));
  }catch(_){if(ticket===request)toast('Não foi possível abrir a foto. Escolha outra imagem.')}
 }
 function adjust(){let geometry=null;try{geometry=JSON.parse(APstudentStorage.getItem(profilePhotoKey()+'_crop_v1')||'null')}catch(_){}return open(geometry?.source||savedProfilePhoto(),geometry)}
 function apply(){const s=session;if(!current(s)){cancel();return}clamp(s);
  let photo,meta,oldPhoto,oldMeta;const metaKey=s.key+'_crop_v1';
  try{const c=surface(512,512);c.getContext('2d').drawImage(s.img,s.x-s.r,s.y-s.r,s.r*2,s.r*2,0,0,512,512);photo=c.toDataURL('image/jpeg',.9);meta=JSON.stringify({source:s.source,x:s.x/s.img.naturalWidth,y:s.y/s.img.naturalHeight,zoom:s.zoom});oldPhoto=APstudentStorage.getItem(s.key);oldMeta=APstudentStorage.getItem(metaKey)}catch(_){toast('Não foi possível preparar o recorte. Tente outra foto.');return}
  try{APstudentStorage.setItem(metaKey,meta);APstudentStorage.setItem(s.key,photo);APstudentStorage.removeItem(s.key+'_removed_v1')}catch(_){try{if(oldMeta===null)APstudentStorage.removeItem(metaKey);else APstudentStorage.setItem(metaKey,oldMeta);if(oldPhoto===null)APstudentStorage.removeItem(s.key);else APstudentStorage.setItem(s.key,oldPhoto)}catch(_){}toast('Não foi possível salvar a foto. Verifique o espaço disponível.');return}
  profilePhotoCache[s.key]=photo;cancel();refreshProfilePhoto();if(document.body.dataset.view==='profile')profileRender();closeProfilePhoto();toast('Foto de perfil salva!');window.APPhotoSync?.changed(photo);
 }
 function move(e){const s=session;if(!current(s)||!s.viewport)return;const b=canvas.getBoundingClientRect(),v=s.viewport,x=((e.clientX-b.left)*canvas.width/b.width-v.left)/v.scale,y=((e.clientY-b.top)*canvas.height/b.height-v.top)/v.scale;
  if(e.type==='pointerdown'){s.pointer=e.pointerId;const inside=Math.hypot(x-s.x,y-s.y)<=s.r;s.dx=inside?s.x-x:0;s.dy=inside?s.y-y:0;canvas.setPointerCapture(e.pointerId)}if(s.pointer!==e.pointerId)return;s.x=x+s.dx;s.y=y+s.dy;draw();e.preventDefault();
 }
 canvas.addEventListener('pointerdown',move);canvas.addEventListener('pointermove',move);
 for(const type of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(type,e=>{if(session?.pointer===e.pointerId)session.pointer=null});
 canvas.addEventListener('keydown',e=>{const s=session;if(e.key==='Escape'){cancel();return}if(!current(s)||!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();const d=Math.min(s.img.naturalWidth,s.img.naturalHeight)*(e.shiftKey?.05:.01);s.x+=e.key==='ArrowLeft'?-d:e.key==='ArrowRight'?d:0;s.y+=e.key==='ArrowUp'?-d:e.key==='ArrowDown'?d:0;draw()});
 $('apStudentCropZoom').addEventListener('input',e=>{if(session){session.zoom=Number(e.target.value);draw()}});
 const oldRefresh=refreshProfilePhoto;refreshProfilePhoto=function(){oldRefresh();$('adjustStudentPhoto').hidden=!savedProfilePhoto()||!owner()};
 const oldClose=closeProfilePhoto;closeProfilePhoto=function(){cancel();return oldClose()};
 const oldRemove=removeProfilePhoto;removeProfilePhoto=function(){cancel();const key=profilePhotoKey();try{APstudentStorage.setItem(key+'_removed_v1','true');APstudentStorage.removeItem(key+'_crop_v1');APstudentStorage.removeItem(key)}catch(_){toast('Não foi possível remover a foto.');return}oldRemove();window.APPhotoSync?.changed('')};
 handleProfilePhoto=select;
 window.APStudentPhoto=Object.freeze({adjust,apply,cancel,isOpen:()=>!modal.hidden});
 window.addEventListener('ap-account-changed',cancel);
 // Only the professor's published student-area packet supplies professional data.
 function renderProfessional(){
  const context=window.__AP_STUDENT_CONTEXT,trainer=context?.area?.trainer;
  for(const [parentId,id]of [['homeScroll','apHomeProfessional'],['profileScroll','apProfileProfessional']]){
   const parent=$(parentId);if(!parent)continue;let bar=$(id);
   if(!bar){bar=document.createElement('aside');bar.id=id;bar.className='ap-professional-bar';bar.setAttribute('aria-label','Seu profissional');const head=parent.querySelector('header');if(head)head.after(bar);else parent.prepend(bar)}
   if(!trainer||!trainer.name||context?.area?.enabled===false){bar.hidden=true;bar.textContent='';continue}
   bar.hidden=false;bar.replaceChildren();const avatar=document.createElement('span');avatar.className='ap-professional-photo';
   if(typeof trainer.photo==='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(trainer.photo)&&trainer.photo.length<200000){const img=document.createElement('img');img.src=trainer.photo;img.alt='';avatar.append(img)}else avatar.textContent=String(trainer.name).split(/\s+/).map(v=>v[0]).slice(0,2).join('').toLocaleUpperCase('pt-BR');
   const info=document.createElement('div');info.className='ap-professional-info';const label=document.createElement('small');label.textContent='Seu profissional';const name=document.createElement('strong');name.textContent=String(trainer.name).slice(0,120);info.append(label,name);
   if(trainer.subtitle){const subtitle=document.createElement('span');subtitle.textContent=String(trainer.subtitle).slice(0,100);info.append(subtitle)}
   if(trainer.cref){const cref=document.createElement('span');cref.className='ap-professional-cref';cref.textContent='CREF '+String(trainer.cref).slice(0,40).replace(/^CREF\s*[:\-]?\s*/i,'');info.append(cref)}bar.append(avatar,info);
  }
 }
 const oldHome=renderHome,oldProfile=profileRender;
 renderHome=function(...args){const result=oldHome(...args);renderProfessional();return result};profileRender=function(...args){const result=oldProfile(...args);renderProfessional();window.APPhotoSync?.summary();return result};
 window.addEventListener('ap-account-changed',()=>{for(const id of ['apHomeProfessional','apProfileProfessional']){const bar=$(id);if(bar){bar.hidden=true;bar.textContent=''}}});
})();
