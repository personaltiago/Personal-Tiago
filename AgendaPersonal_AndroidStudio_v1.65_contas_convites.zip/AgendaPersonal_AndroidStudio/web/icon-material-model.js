(function(global){
 'use strict';
 // The chosen hue is retained; controlled saturation and a tonal range provide
 // the matte material. Shared by SVG fills and bitmap recoloring.
 function palette(value){
  const hex=typeof value==='string'&&/^#[a-f0-9]{6}$/i.test(value)?value:'#542187';
  const [r,g,b]=hex.slice(1).match(/../g).map(v=>parseInt(v,16)/255),hi=Math.max(r,g,b),lo=Math.min(r,g,b),delta=hi-lo,light=(hi+lo)/2;
  let hue=0,saturation=0;
  if(delta){saturation=delta/(1-Math.abs(2*light-1));hue=(hi===r?(g-b)/delta+(g<b?6:0):hi===g?(b-r)/delta+2:(r-g)/delta+4)/6}
  const sat=Math.min(.58,saturation*.68);
  function shade(l){
   const c=(1-Math.abs(2*l-1))*sat,h=hue*6,x=c*(1-Math.abs(h%2-1)),m=l-c/2;
   const rgb=h<1?[c,x,0]:h<2?[x,c,0]:h<3?[0,c,x]:h<4?[0,x,c]:h<5?[x,0,c]:[c,0,x];
   return '#'+rgb.map(n=>Math.round((n+m)*255).toString(16).padStart(2,'0')).join('');
  }
  return Object.freeze({light:shade(.56),upper:shade(.39),mid:shade(.28),low:shade(.18),deep:shade(.09),rim:shade(.43)});
 }
 global.APIconMaterial=Object.freeze({palette});
})(globalThis);
