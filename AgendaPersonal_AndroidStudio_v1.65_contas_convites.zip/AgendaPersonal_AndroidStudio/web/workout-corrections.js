(function(){
 'use strict';
 const drafts=new Map();let serial=0;
 const key=(p,d,e)=>JSON.stringify([p.studentId,p.id,d.id,e.id]);
 function saved(k){const n=state.workoutExerciseNotes?.[k];return n&&typeof n.text==='string'?n.text:''}
 function persist(k,text,status,button){
  const notes={...state.workoutExerciseNotes};if(text.trim())notes[k]={text:text.slice(0,2000),updatedAt:new Date().toISOString()};else delete notes[k];
  try{localStorage.setItem(DB_KEY,JSON.stringify({...state,workoutExerciseNotes:notes}));state.workoutExerciseNotes=notes;drafts.delete(k);const message=text.trim()?'Salva para os próximos treinos deste exercício.':'Espaço do professor. A observação fica para o próximo treino.';if(status.textContent!==message)status.textContent=message;status.classList.remove('is-error');button.disabled=!text.trim();window.APTeacherSync?.changed();return true}
  catch(_){drafts.set(k,text);status.textContent='Não foi possível salvar. Seu texto está aqui; toque fora do campo para tentar novamente.';status.classList.add('is-error');return false}
 }
 function add(section,p,day,ex){
  if(section.nextElementSibling?.classList.contains('ap-exercise-observation'))return;
  const k=key(p,day,ex),text=drafts.has(k)?drafts.get(k):saved(k),box=document.createElement('section'),id='apObservation'+(++serial);
  box.className='ap-exercise-observation';box.dataset.observationExercise=ex.id;
  const label=document.createElement('label');label.htmlFor=id;label.textContent='Observação deste aluno';
  const input=document.createElement('textarea');input.id=id;input.maxLength=2000;input.rows=2;input.placeholder='Ex.: relatou desconforto neste exercício. Conferir no próximo treino.';input.value=text;input.setAttribute('aria-describedby',id+'Status');
  const footer=document.createElement('div');footer.className='ap-exercise-observation-footer';const status=document.createElement('p');status.className='ap-exercise-observation-status';status.id=id+'Status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');
  status.textContent=drafts.has(k)?'Alteração ainda não salva. Toque fora do campo para tentar novamente.':text?'Salva para os próximos treinos deste exercício.':'Espaço do professor. A observação fica para o próximo treino.';
  const clear=document.createElement('button');clear.type='button';clear.className='btn ghost';clear.textContent='Apagar';clear.setAttribute('aria-label','Apagar observação de '+ex.name);clear.disabled=!text.trim();
  const editable=()=>{const current=currentWorkoutPlan(),d=currentWorkoutDay();return current?.id===p.id&&current.studentId===p.studentId&&d?.id===day.id&&d.exercises.some(e=>e.id===ex.id)&&!workoutPlanArchived(current)};
  input.oninput=()=>{if(!editable())return;persist(k,input.value,status,clear)};
  input.onblur=()=>{if(editable()&&drafts.has(k))persist(k,input.value,status,clear)};
  clear.onclick=()=>{if(!editable())return;if(persist(k,'',status,clear)){input.value='';input.focus({preventScroll:true})}};
  input.disabled=workoutPlanArchived(p);clear.disabled=input.disabled||clear.disabled;footer.append(status,clear);box.append(label,input,footer);section.after(box);
 }
 function decorateRoot(root,p,day){
  if(!root||!p||!day||workoutExercisesOrdering)return;
  for(const section of root.querySelectorAll('.ws-set-section[data-series-table]')){
   const ex=day.exercises.find(e=>e.id===section.dataset.seriesTable);if(ex)add(section,p,day,ex);
  }
 }
 function decorate(){
  const p=currentWorkoutPlan(),day=currentWorkoutDay();if(!p||!day)return;
  const root=document.getElementById('workoutDayContent');
  for(const card of root.querySelectorAll('.workout-exercise[data-exercise-id]')){
   if(!workoutRunning(p,day))continue;card.classList.add('ap-correctable');const details=card.querySelector('details[data-exercise-id]');if(details)details.open=true;
  }
  decorateRoot(root,p,day);
  for(const card of root.querySelectorAll('.workout-exercise[data-exercise-id]')){
   if(card.querySelector('.ap-exercise-observation'))continue;
   const ex=day.exercises.find(e=>e.id===card.dataset.exerciseId),last=card.querySelector('.workout-exercise-body')?.lastElementChild;if(ex&&last)add(last,p,day,ex);
  }
 }
 function validateInput(input){
  if(input.dataset.seriesField!=='reps'||Number.isInteger(Number(input.value))&&Number(input.value)>=1&&Number(input.value)<=999)return;
  const p=currentWorkoutPlan(),d=currentWorkoutDay();if(!p||!d)return;const round=Number(input.dataset.seriesRound),draft=state.workoutDrafts[workoutDraftKey(p.id,d.id)];
  const stored=input.dataset.seriesGroup?draft?.bisets?.[input.dataset.seriesGroup]?.rounds?.[round-1]?.[input.dataset.seriesPart]:draft?.values?.[input.dataset.seriesExercise]?.series?.[round];
  if(stored&&(input.dataset.seriesGroup||stored.done)){input.value=String(stored.reps);toast('Use de 1 a 999 repetições. O valor anterior foi mantido.')}
 }
 const original=renderWorkoutDay;renderWorkoutDay=function(...args){const result=original(...args);decorate();return result};
 const completion=updateWorkoutExerciseCompletion;updateWorkoutExerciseCompletion=function(...args){const result=completion(...args);decorate();return result};
 try{window.parent.addEventListener('ap-account-changed',()=>drafts.clear())}catch(_){}
 window.APWorkoutCorrections=Object.freeze({decorate,decorateGuide:(p,d)=>decorateRoot(document.getElementById('workoutBisetContent'),p,d),validateInput});
 decorate();
})();
