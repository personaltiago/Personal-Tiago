(function(){
 'use strict';
 if(window.APFeedbackSync||window.__AP_PUBLIC_REGISTER)return;
 const M=APFeedbackModel,endpoint='https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site';
 const uid=()=>window.__AP_STUDENT_CONTEXT?.role==='student'&&window.__AP_STUDENT_CONTEXT.area?.enabled!==false?window.__AP_STUDENT_CONTEXT.storageId:'',teacher=()=>window.APaccounts?.isTeacher()===true;
 let epoch=0,busy=false,timer=0,message='';
 const key=id=>'agenda_feedback_v1_'+id;
 const read=()=>{try{const v=JSON.parse(localStorage.getItem(key(uid()))||'null');if(v?.version===1&&Array.isArray(v.items)&&v.outbox&&v.drafts)return v}catch(_){}return {version:1,items:[],outbox:{},drafts:{}}};
 const notify=()=>dispatchEvent(new CustomEvent('ap-feedback-changed'));
 function write(value,owner=uid()){if(!owner||owner!==uid())throw Error('A conta foi alterada.');try{localStorage.setItem(key(owner),JSON.stringify(value))}catch(_){throw Error('Não foi possível salvar a resposta neste aparelho. Confira o espaço disponível e tente novamente.')}notify()}
 async function post(path,data){
  const owner=uid(),isTeacher=teacher(),ticket=epoch;if(!owner&&!isTeacher)throw Error('Entre na sua conta.');
  const token=await APaccounts.getPhotoToken();if(ticket!==epoch||owner!==uid()||isTeacher!==teacher())throw Error('A conta foi alterada.');
  const r=await fetch(endpoint+path,{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(data),cache:'no-store',signal:AbortSignal.timeout(20000)});
  let value;try{value=await r.json()}catch(_){throw Error('O serviço não respondeu. Tente novamente com conexão.')}
  if(ticket!==epoch||owner!==uid()||isTeacher!==teacher())throw Error('A conta foi alterada.');
  if(!r.ok){const e=Error(value.error||'Não foi possível sincronizar o feedback.');e.status=r.status;throw e}return value;
 }
 async function inbox(owner){
  if(!M.uid(owner)||!teacher()&&owner!==uid())throw Error('Conta inválida.');let cursor=null,items=[],pages=0;
  do{const r=await post('/api/feedback-inbox',teacher()?{uid:owner,cursor,includeOnline:true}:{cursor});if(r.uid!==owner||!Array.isArray(r.items)||r.cursor!==null&&typeof r.cursor!=='string')throw Error('O feedback recebido não corresponde à conta.');
   for(const raw of r.items){const item=M.normalize(raw,owner);if(!item)throw Error('O pedido de feedback está incompleto.');items.push(item)}cursor=r.cursor;if(cursor&&++pages>=100)throw Error('Histórico extenso. Tente novamente.');
  }while(cursor);return [...new Map(items.map(r=>[r.id,r])).values()];
 }
 async function create(session){if(!teacher())throw Error('Entre como professor.');const r=await post('/api/feedback-request',{session}),item=M.normalize(r.item,session.uid);if(!r.saved||!item||item.id!==session.id||item.studentId!==session.studentId)throw Error('O pedido não foi confirmado.');return item}
 function schedule(){clearTimeout(timer);if(uid())timer=setTimeout(refresh,600)}
 async function refresh(){
  const owner=uid(),ticket=epoch;if(!owner||busy)return;if(navigator.onLine===false){message='Sem conexão. Suas respostas ficam salvas até o envio.';notify();return}
  busy=true;message='Atualizando seus feedbacks…';notify();
  try{
   let value=read();for(const payload of Object.values(value.outbox)){
    if(owner!==uid()||ticket!==epoch)return;
    const r=await post('/api/feedback-submit',payload),item=M.normalize(r.item,owner);if(!r.saved||!item?.response||item.id!==payload.id)throw Error('Sua resposta não foi confirmada.');
    value=read();value.items=[item,...value.items.filter(r=>r.id!==item.id)];delete value.outbox[item.id];delete value.drafts[item.id];write(value,owner);
   }
   const incoming=await inbox(owner);if(owner!==uid()||ticket!==epoch)return;value=read();const merged=new Map(value.items.map(r=>[r.id,r]));for(const item of incoming){merged.set(item.id,item);if(item.response){delete value.outbox[item.id];delete value.drafts[item.id]}}
   value.items=[...merged.values()].sort((a,b)=>b.finishedAt-a.finishedAt);write(value,owner);message='';
  }catch(e){if(owner===uid()&&ticket===epoch)message=e.status===403?e.message:'Não foi possível atualizar agora. As respostas salvas serão tentadas novamente com conexão.'}
  finally{busy=false;if(owner===uid()&&ticket===epoch)notify();else if(uid())schedule()}
 }
 function submit(id,data){const owner=uid(),value=read(),item=value.items.find(r=>r.id===id);if(!owner||!item||item.response||value.outbox[id])throw Error('Este feedback já foi respondido.');
  if(!M.intensities.includes(data.intensity)||typeof data.comment!=='string'||data.comment.length>2000)throw Error('Selecione a intensidade e confira o comentário.');
  value.outbox[id]={id,intensity:data.intensity,comment:data.comment.trim(),publicationBasis:'contract',mutationId:crypto.randomUUID()};write(value,owner);schedule();return true;
 }
 function draft(id,data){const owner=uid(),value=read();if(!owner||!value.items.some(r=>r.id===id&&!r.response)||value.outbox[id])return;value.drafts[id]={intensity:M.intensities.includes(data.intensity)?data.intensity:'',comment:String(data.comment||'').slice(0,2000)};localStorage.setItem(key(owner),JSON.stringify(value))}
 const items=()=>uid()?read().items.map(r=>M.normalize(r,uid())).filter(Boolean):[];
 window.APFeedbackSync=Object.freeze({create,inbox,refresh,schedule,submit,draft,items,pending:()=>items().filter(r=>!r.response),local:()=>uid()?read():{items:[],outbox:{},drafts:{}},status:()=>({busy,message}),uid});
 addEventListener('ap-account-changed',()=>{epoch++;clearTimeout(timer);message='';notify();schedule()});addEventListener('ap-student-ready',schedule);addEventListener('online',schedule);document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule()});setInterval(()=>{if(!document.hidden)schedule()},30000);schedule();
})();
