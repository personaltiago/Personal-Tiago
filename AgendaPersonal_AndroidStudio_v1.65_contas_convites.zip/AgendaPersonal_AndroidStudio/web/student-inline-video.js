(function(){
 'use strict';
 if(window.__AP_PUBLIC_REGISTER)return;
 let active=null,tick=0,serial=0,playGeneration=0;
 const root=()=>document.getElementById('exTabContent');
 const owner=()=>window.__AP_STUDENT_CONTEXT?.storageId||'';
 const originalMedia=renderExerciseMedia;
 renderExerciseMedia=function(index,label){
  let markup=originalMedia(index,label).replace('<div class="ex-media">','<div class="ex-media" data-ex-media-index="'+index+'">');
  const e=exercisesFor(exActiveId)[index],url=e?.video;
  if(APExternalVideo.isTikTok(url)){
   markup=markup.replace('class="ex-media"','class="ex-media ap-student-tiktok-video" data-tiktok-preview="'+htmlSafe(url)+'"').replace(/<img[^>]*>/,'<img hidden alt="" referrerpolicy="no-referrer">');
  }else if(url&&!APStudentModel.youtube(url)){
   markup=markup.replace('class="ex-media"','class="ex-media ap-student-external-video"').replace(/<div class="ex-media-overlay">[\s\S]*?<\/div>/,'<div class="ex-media-overlay"><button class="ap-student-external-link" type="button" onclick="exercisePlayVideo('+index+')"><strong>Abrir vídeo ↗</strong><small>Abre fora da Agenda Personal</small></button></div>');
  }
  return markup;
 };
 function current(video){
  const e=exercisesFor(exActiveId)[video.index];
  return document.body.dataset.view==='exercise'&&exView==='detail'&&exTab==='video'&&
   owner()===video.owner&&exActiveId===video.workout&&exIndex===video.viewIndex&&e?.id===video.exerciseId&&e?.video===video.url;
 }
 function bounds(video){
  const box=video.media.getBoundingClientRect(),scroll=document.getElementById('exScroll').getBoundingClientRect();
  const clipTop=Math.max(0,scroll.top),clipBottom=Math.min(innerHeight,scroll.bottom);
  const covered=['exFinishModal','homeModal','bgDialog','profilePhotoDialog','profileEditor'].some(id=>{const node=document.getElementById(id);return node&&!node.hidden});
  return {viewportWidth:innerWidth,viewportHeight:innerHeight,left:box.left,top:box.top,width:box.width,height:box.height,clipTop,clipBottom,
   visible:!document.hidden&&!covered&&video.media.isConnected&&box.bottom>clipTop&&box.top<clipBottom};
 }
 function close(){
  playGeneration++;const video=active;active=null;if(tick)cancelAnimationFrame(tick);tick=0;if(!video)return;
  if(video.native)try{Android.closeInlineYouTubeVideo(video.key)}catch(_){}
  if(video.frame){video.frame.src='about:blank';video.frame.remove()}
  video.media.classList.remove('ap-student-video-playing');
  if(video.media.isConnected)video.media.innerHTML=video.poster;
 }
 function update(){
  tick=0;const video=active;if(!video)return;
  if(!video.media.isConnected||!current(video)){close();return}
  const b=bounds(video),encoded=JSON.stringify(b);
  if(video.native&&encoded!==video.lastBounds){try{Android.positionInlineYouTubeVideo(video.key,encoded);video.lastBounds=encoded}catch(_){failed(video.key)}}
  if(video.frame){
   if(!b.visible&&video.wasVisible)video.frame.contentWindow.postMessage(video.provider==='tiktok'?{type:'pause','x-tiktok-player':true}:JSON.stringify({event:'command',func:'pauseVideo',args:[]}),video.provider==='tiktok'?'https://www.tiktok.com':'https://www.youtube.com');
   video.frame.style.visibility=b.visible?'visible':'hidden';
  }
  video.wasVisible=b.visible;tick=requestAnimationFrame(update);
 }
 function external(url){if(!APExternalVideo.open(url))toast('Não foi possível abrir o vídeo. Confira o endereço e tente novamente.')}
 function failed(key){
  const video=active;if(!video||video.key!==key)return false;
  if(video.native)try{Android.closeInlineYouTubeVideo(video.key)}catch(_){}
  video.native=false;video.media.replaceChildren();
  const panel=document.createElement('div');panel.className='ap-student-video-status';
  const status=document.createElement('p');status.setAttribute('role','status');status.textContent='Não foi possível iniciar o vídeo. Confira a conexão e tente novamente.';
  const retry=document.createElement('button');retry.type='button';retry.textContent='Tentar novamente';retry.onclick=()=>exercisePlayVideo(video.index);
  const link=document.createElement('button');link.type='button';link.textContent=video.provider==='tiktok'?'Abrir no TikTok':'Abrir no YouTube';link.onclick=()=>external(video.url);
  panel.append(status,retry,link);video.media.append(panel);return true;
 }
 function startTime(raw){
  try{const u=new URL(raw),h=new URLSearchParams(u.hash.slice(1)),s=u.searchParams.get('start')||u.searchParams.get('t')||h.get('t')||'0';
   if(/^\d+$/.test(s))return Math.min(2147483647,Number(s));
   const m=s.match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/);return m?Math.min(2147483647,Number(m[1]||0)*3600+Number(m[2]||0)*60+Number(m[3]||0)):0;
  }catch(_){return 0}
 }
 exercisePlayVideo=async function(index=exIndex){
  const e=exercisesFor(exActiveId)[index],tiktok=APExternalVideo.isTikTok(e?.video);let videoId=APStudentModel.youtube(e?.video);
  if(tiktok){
   if(window.Android&&typeof Android.openInlineTikTokVideo!=='function')return toast('Instale o APK 1.117 para assistir ao TikTok dentro da Agenda.');
   close();const ticket=playGeneration,account=owner(),workout=exActiveId;
   try{const m=await APTikTok.metadata(e.video);if(ticket!==playGeneration||owner()!==account||exActiveId!==workout||document.body.dataset.view!=='exercise'||exView!=='detail'||exTab!=='video'||exercisesFor(exActiveId)[index]?.id!==e.id||exercisesFor(exActiveId)[index]?.video!==e.video)return;videoId=m.videoId}catch(err){toast(err.message||'Não foi possível carregar este vídeo.');return}
  }
  if(!videoId){close();if(e?.video)external(e.video);else toast('Este exercício ainda não tem um vídeo cadastrado.');return}
  if(active&&current(active)&&active.index===index&&active.native)return;
  close();
  const media=root()?.querySelector('[data-ex-media-index="'+index+'"]');
  if(!media||document.body.dataset.view!=='exercise'||exView!=='detail'||exTab!=='video')return;
  const video={key:'student_'+Date.now()+'_'+(++serial),index,owner:owner(),workout:exActiveId,viewIndex:exIndex,exerciseId:e.id,url:e.video,
   provider:tiktok?'tiktok':'youtube',media,poster:media.innerHTML,native:false,frame:null,lastBounds:'',wasVisible:true};
  active=video;media.classList.add('ap-student-video-playing');
  const status=document.createElement('p');status.className='ap-student-video-status';status.setAttribute('role','status');status.textContent='Carregando vídeo…';media.replaceChildren(status);
  const payload={provider:video.provider,key:video.key,videoId,startSeconds:startTime(e.video),title:String(e.name).slice(0,180),bounds:bounds(video)};
  if(window.Android){
   // Never embed remote scripts in the privileged app WebView or open a new Activity.
   try{video.native=typeof Android[tiktok?'openInlineTikTokVideo':'openInlineYouTubeVideo']==='function'&&Android[tiktok?'openInlineTikTokVideo':'openInlineYouTubeVideo'](JSON.stringify(payload))===true;if(!video.native)failed(video.key)}catch(_){failed(video.key)}
  }else{
   const frame=document.createElement('iframe');frame.title='Vídeo de '+e.name;
   frame.src=tiktok?APTikTok.frameUrl(videoId):'https://www.youtube.com/embed/'+videoId+'?playsinline=1&autoplay=1&enablejsapi=1&rel=0&start='+payload.startSeconds;
   frame.allow='autoplay; encrypted-media; fullscreen';frame.allowFullscreen=true;frame.referrerPolicy='strict-origin-when-cross-origin';media.replaceChildren(frame);video.frame=frame;
  }
  update();
 };
 const detail=renderExerciseDetail;
 renderExerciseDetail=function(){
  const video=active,keep=video&&video.native&&current(video);if(video&&!keep)close();
  const result=detail.apply(this,arguments);
  // Set completion redraws the card. Reattach its native surface without restarting playback.
  if(keep&&active===video){const replacement=root()?.querySelector('[data-ex-media-index="'+video.index+'"]');if(replacement&&current(video))replacement.replaceWith(video.media);else close()}
  return result;
 };
 const routeBefore=route;
 route=function(){close();return routeBefore.apply(this,arguments)};
 const appBefore=renderExerciseApp;
 renderExerciseApp=function(){if(active&&!current(active))close();return appBefore.apply(this,arguments)};
 const clearBefore=window.clearWorkoutInlineVideo,errorBefore=window.workoutInlineVideoError;
 window.clearWorkoutInlineVideo=function(){close();if(clearBefore)clearBefore()};
 window.workoutInlineVideoError=function(key){if(!failed(key)&&errorBefore)errorBefore(key)};
 document.addEventListener('visibilitychange',()=>{if(active){if(tick)cancelAnimationFrame(tick);update()}});
 window.addEventListener('pagehide',close);
})();
