 // Organization changes presentation only. IDs, prescriptions and sessions stay intact.
 function workoutLetter(index){let text='';for(let n=index+1;n>0;n=Math.floor((n-1)/26))text=String.fromCharCode(65+(n-1)%26)+text;return text}
 function scheduledWeekday(w){return Number.isInteger(w.weekday)&&w.weekday>=0&&w.weekday<=6?w.weekday:null}
 renderWorkouts=function(){
  renderWorkoutsWeekMode();el('wsOrganize').hidden=true;
  const p=prefs(),screen=el('workoutsScreen');screen.style.setProperty('--ws-accent',p.color||'#8f35df');screen.style.setProperty('--ws-scale',({pequena:.92,media:1,grande:1.12}[p.font]||1));screen.classList.toggle('ws-light',p.mode==='claro');
  document.querySelectorAll('#workoutsScreen [data-ws-icon]').forEach(node=>node.innerHTML=iconSvg(p.icons||'padrao',node.dataset.wsIcon));
  for(const [id,value]of [['wsTabOngoing','ongoing'],['wsTabDone','done']]){el(id).classList.toggle('selected',wsTab===value);el(id).setAttribute('aria-selected',String(wsTab===value))}
  el('wsListContent').hidden=false;el('wsPreviewContent').hidden=true;
  const entries=currentWorkouts(),cards=el('wsCards'),letters=new Map(entries.map((w,i)=>[w.id,workoutLetter(i)]));
  const weekdayNames=['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
  const sequenceWeek=entries.length>0&&entries.every(w=>scheduledWeekday(w)===null);
  const displayDay=w=>scheduledWeekday(w)??(sequenceWeek&&entries.indexOf(w)<5?entries.indexOf(w)+1:null);
  el('wsModeLetters').textContent=entries.length>1?'Treinos A–'+workoutLetter(entries.length-1):'Treinos A–E';
  cards.hidden=false;el('wsEmpty').hidden=true;
  if(wsTab==='done'){renderDoneWorkoutCards();return}
  const card=w=>{
   const code=letters.get(w.id),day=displayDay(w),weekly=wsMode==='days';
   return '<article class="ws-card ap-organized-card" data-workout-id="'+htmlSafe(w.id)+'"><button type="button" class="ws-card-main" data-ap-workout="'+htmlSafe(w.id)+'">'+APWorkoutMuscles.render(w)+'<span class="ws-card-text"><strong>'+htmlSafe(weekly&&day!==null?weekdayNames[day]:'Treino '+code)+'</strong><em>'+htmlSafe(w.label)+'</em><small class="ap-workout-plan">'+htmlSafe((weekly?'Treino '+code+' · ':'')+w.planName)+'</small><span class="ws-card-facts">'+w.count+(w.count===1?' exercício':' exercícios')+' · '+w.tech+(w.tech===1?' técnica':' técnicas')+(w.min?' · '+w.min+' min':'')+'</span></span><span class="ws-card-chevron">'+WORKOUT_ICONS.chevron+'</span></button><button class="ws-card-cta" type="button" data-ap-workout="'+htmlSafe(w.id)+'">Ver exercícios '+WORKOUT_ICONS.arrow+'</button></article>';
  };
  if(!entries.length){cards.innerHTML='<section class="ap-area-empty"><h2>Nenhum treino disponível</h2><p>O professor precisa disponibilizar sua ficha. Ela aparecerá aqui na sua conta.</p></section>';return}
  if(wsMode==='letters')cards.innerHTML=entries.map(card).join('');
  else{
   const names=['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
   const days=[1,2,3,4,5,...[6,0].filter(day=>entries.some(w=>displayDay(w)===day))];
   let content=days.map(day=>{
    const workouts=entries.filter(w=>displayDay(w)===day);
    return '<section class="ap-week-group" data-weekday="'+day+'" aria-label="'+names[day]+'">'+(workouts.length?workouts.map(card).join(''):'<h2>'+names[day]+'</h2><p class="ap-week-empty">Sem treino programado</p>')+'</section>';
   }).join('');
   const unscheduled=entries.filter(w=>displayDay(w)===null);
   if(unscheduled.length===entries.length)content='<div class="ap-week-summary">'+days.map(day=>'<section data-weekday="'+day+'"><strong>'+['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'][day]+'</strong><small>Sem programação</small></section>').join('')+'</div>';
   if(unscheduled.length)content='<p class="ap-week-note">Os dias de '+(unscheduled.length===entries.length?'seus treinos ainda não foram definidos':'alguns treinos ainda não foram definidos')+' pelo professor. Eles continuam disponíveis abaixo.</p>'+content+'<section class="ap-week-group ap-week-unscheduled"><h2>Sem dia definido</h2>'+unscheduled.map(card).join('')+'</section>';
   if(sequenceWeek)content='<p class="ap-week-note">A → segunda · B → terça · C → quarta · D → quinta · E → sexta. Organização visual da sequência.</p>'+content;
   cards.innerHTML=content;
  }
  cards.querySelectorAll('[data-ap-workout]').forEach(button=>button.onclick=()=>openExerciseHub(button.dataset.apWorkout));
 };
