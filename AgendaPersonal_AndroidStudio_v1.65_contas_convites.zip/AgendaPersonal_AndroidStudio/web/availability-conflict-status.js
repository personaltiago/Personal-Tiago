// Summaries use the same overlapping occurrences as the detailed query.
function availabilityOverviewStatus(date,range,busy,usable){
 const kind=busy.length?(usable.length?'partial':'busy'):usable.length?'free':'outside';
 const label={busy:'OCUPADO',partial:'PARCIALMENTE OCUPADO',free:'LIVRE',outside:'SEM ENCAIXE'}[kind];
 const names=busy.map(item=>{
  const end=item.end>1440?minutesToTime(item.end-1440)+' do dia seguinte':minutesToTime(item.end);
  return `${hesc(lessonParticipant(item.lesson)?.name||'Aluno removido')} · ${minutesToTime(item.start)}–${end}`;
 });
 const detail=busy.length?`${busy.length} ${busy.length===1?'aula':'aulas'} · ${names.join('; ')}`:`${usable.length} ${usable.length===1?'intervalo livre':'intervalos livres'}`;
 const past=date<iso(new Date())?'<small class="availability-overview-past">Data passada</small>':'';
 return `<small class="availability-overview-status ${kind}">${label} · ${range.start}–${range.end}</small><small class="availability-overview-detail ${busy.length?'busy':''}">${detail}</small>${past}`;
}
