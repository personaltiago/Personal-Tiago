(function(){
 'use strict';
 const endpoint='https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site',prefix='agenda_student_photo_sync_v1_';
 const student=()=>window.__AP_STUDENT_CONTEXT?.role==='student'?window.__AP_STUDENT_CONTEXT.storageId:'',frame=()=>document.getElementById('apPreviewTeacher')?.contentWindow;
 let sending=false,reading=false,selection=0,epoch=0,lastTeacherNotice='';const preparationFailures=new Set();
 function read(uid){try{return JSON.parse(localStorage.getItem(prefix+uid)||'null')}catch(_){return null}}
 function status(message){for(const id of ['apStudentPhotoSyncStatus','apStudentPhotoModalStatus']){const n=document.getElementById(id);if(n){n.hidden=!message;n.textContent=message}}}
 function summary(){if(preparationFailures.has(student())){status('A foto ficou salva neste aparelho, mas o envio não pôde ser preparado. Escolha a foto novamente para tentar.');return}const job=read(student());status(job?.pending?(navigator.onLine===false?'Foto salva neste aparelho. Aguardando conexão para enviar ao professor.':'Foto salva neste aparelho. Aguardando envio ao professor.'):job?'Foto enviada ao professor.':'')}
 async function hash(value){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value));return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('')}
 async function thumbnail(photo){if(!photo)return '';const img=new Image();await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=photo});const c=document.createElement('canvas');c.width=c.height=320;const g=c.getContext('2d');g.fillStyle='#121b27';g.fillRect(0,0,320,320);g.drawImage(img,0,0,320,320);for(const q of [.82,.65,.5]){const result=c.toDataURL('image/jpeg',q);if(result.length<160000)return result}throw Error('Escolha uma foto menor.')}
 async function changed(photo){
  const uid=student(),ticket=++selection;if(!uid)return;preparationFailures.delete(uid);status('Foto salva neste aparelho. Preparando envio ao professor…');
  try{const digest=await hash(photo);if(uid!==student()||ticket!==selection)return;const previous=read(uid);if(previous?.sourceHash===digest){summary();pump();return}
   const compressed=await thumbnail(photo);if(uid!==student()||ticket!==selection)return;
   const job={photo:compressed,sourceHash:digest,mutationId:crypto.randomUUID().replaceAll('-',''),pending:true};localStorage.setItem(prefix+uid,JSON.stringify(job));summary();pump();
  }catch(_){if(uid===student()&&ticket===selection){preparationFailures.add(uid);summary()}}
 }
 async function post(path,data){const token=await APaccounts.getPhotoToken();const result=await fetch(endpoint+path,{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(data),signal:AbortSignal.timeout(20000)});let value;try{value=await result.json()}catch(_){throw Error('Resposta indisponível.')};if(!result.ok)throw Error(value.error||'Envio indisponível.');return value}
 async function pump(){
  const uid=student(),job=read(uid),token=epoch;if(sending||!uid||!job?.pending||navigator.onLine===false)return;sending=true;status('Enviando foto ao professor…');
  try{const result=await post('/api/student-photo',{photo:job.photo,mutationId:job.mutationId});if(token!==epoch||uid!==student())return;
   if(!result.saved||result.revision!==job.mutationId)throw Error('Confirmação inválida.');const latest=read(uid);
   if(latest?.mutationId===job.mutationId){latest.pending=false;localStorage.setItem(prefix+uid,JSON.stringify(latest));summary()}
  }catch(_){if(token===epoch&&uid===student())status('Foto salva neste aparelho. O envio ao professor será tentado novamente quando houver conexão.')}
  finally{sending=false;const latest=read(student());if(latest?.pending&&latest.mutationId!==job.mutationId)pump()}
 }
 async function receive(){
  if(reading||!APaccounts.isTeacher()||navigator.onLine===false||document.hidden)return;let child,targets;
  try{child=frame();targets=child?.APstudentPhotoTargets?.()}catch(_){return}if(!targets?.length)return;
  reading=true;const token=epoch;
  try{for(let i=0;i<targets.length;i+=50){if(token!==epoch||!APaccounts.isTeacher())return;const result=await post('/api/student-photos',{students:targets.slice(i,i+50)});if(token!==epoch||!APaccounts.isTeacher())return;if(!Array.isArray(result.photos))throw Error();if(!child.APapplyStudentPhotos(result.photos))throw Error('Não foi possível salvar as fotos recebidas.')}
   child.APstudentPhotoSyncNotice?.('');lastTeacherNotice='';
  }catch(_){if(token===epoch&&APaccounts.isTeacher()){const notice='Não foi possível sincronizar as fotos dos alunos agora. Tentaremos novamente com conexão.';if(notice!==lastTeacherNotice){try{child.APstudentPhotoSyncNotice?.(notice)}catch(_){}lastTeacherNotice=notice}}}
  finally{reading=false}
 }
 function ready(){const uid=student(),photo=uid?APstudentStorage.getItem(profilePhotoKey()):null;if(uid&&APstudentStorage.getItem(profilePhotoKey()+'_removed_v1')==='true')changed('');else if(photo)changed(photo);else{summary();pump()}receive()}
 window.APPhotoSync=Object.freeze({changed,pump,receive,ready,summary});
 window.addEventListener('ap-account-changed',()=>{epoch++;selection++;status('')});
 window.addEventListener('ap-student-ready',ready);window.addEventListener('ap-teacher-ready',receive);window.addEventListener('online',()=>{ready()});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)ready()});
 setInterval(()=>{pump();receive()},60000);
})();
