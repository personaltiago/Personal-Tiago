(function(){
 'use strict';
 const M=APStudentFollowupModel,$=id=>document.getElementById(id),safe=v=>hesc(String(v??''));
 const parentApi=()=>{try{return window.parent.APaccounts}catch(_){return null}},allowed=()=>parentApi()?.isTeacher()===true&&!window.parent.__AP_STUDENT_CONTEXT;
 const source=()=>{try{return window.parent.APWorkoutSync}catch(_){return null}};
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 4h6m-6 0H6a2 2 0 0 0-2 2v14h16V6a2 2 0 0 0-2-2h-3M9 2v4h6V2zM8 11h3m-3 5h3m4-5 1 1 2-2m-3 6 1 1 2-2"/></svg>';
 const titles={attention:'Prioridades',completed:'Treinos concluídos',inactive:'Sem registro recente',reassessment:'Reavaliações',pending:'Envios ao aluno'};
 let filter='attention',period=7,query='',busy=false,generation=0,assessmentMap={},remote={},loadedAt='',assessmentError=false,model=null,progressDone=0,progressTotal=0;
 const active=()=>currentScreen==='followup'&&allowed();
 const date=d=>d===null?'—':new Date(d*86400000).toLocaleDateString('pt-BR',{timeZone:'UTC'});
 const stamp=t=>{const d=new Date(t);return Number.isFinite(d.getTime())?d.toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'}):''};
 function mount(){
  if(!$('apFollowupEntry')){
   const grid=document.querySelector('#screen-dashboard .home-quick-grid');
   if(grid){const b=document.createElement('button');b.id='apFollowupEntry';b.type='button';b.className='home-card ap-followup-entry';b.innerHTML=icon+'<span><strong>Acompanhamento dos alunos</strong><small>Treinos, reavaliações e envios em um lugar.</small></span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg>';b.onclick=()=>showScreen('followup');grid.after(b)}
  }
  const anchor=$('morePet');if(anchor?.parentElement&&!$('moreFollowup')){
   const b=document.createElement('button');b.id='moreFollowup';b.type='button';b.className=anchor.className.replace(/more-function-primary/g,'').trim();b.setAttribute('aria-pressed','false');b.setAttribute('aria-describedby','apMoreSelectHint');b.innerHTML='<span class="more-function-icon">'+icon+'</span><span class="more-function-copy"><strong>Acompanhamento</strong><small>Registros e atenção aos alunos.</small></span><span class="more-chevron">›</span>';b.onclick=()=>showScreen('followup');anchor.parentElement.prepend(b);
  }
 }
 function deliveries(){
  const result=Object.create(null),api=parentApi();
  for(const area of api?.knownAreas?.()||[]){
   const s=state.students.find(s=>s.id===area.studentId&&s.firebaseUid&&s.firebaseUid===area.studentUid);if(!s)continue;
   const status=api.status?.(s.firebaseUid);if(status)result[s.id]={...status,blocked:area.enabled===false};
  }
  return result;
 }
 function cachedRemote(){
  const api=source(),result=Object.create(null);
  for(const s of state.students){if(s.archived===true||!s.firebaseUid)continue;try{result[s.id]={records:api?.records(s.firebaseUid)||[],...api?.summary(s.firebaseUid)}}catch(_){result[s.id]={records:[],message:'Não foi possível consultar os registros.'}}}
  return result;
 }
 function tag(text,attention=false){return '<span class="ap-followup-tag'+(attention?' is-attention':'')+'">'+safe(text)+'</span>'}
 function row(r){
  const s=r.student,tags=[];
  if(r.pending)tags.push(tag(r.delivery.state==='error'?'Envio com falha':r.delivery.blocked?'Bloqueio aguardando envio':'Ficha aguardando envio',true));
  if(r.inactive)tags.push(tag(r.days+' dias sem registro recente',true));
  if(r.reassessment)tags.push(tag(r.lastAssessment===null?'Primeira avaliação':r.assessmentAge+' dias desde a avaliação',true));
  if(r.completed)tags.push(tag(r.completed+' '+(r.completed===1?'treino concluído':'treinos concluídos')+' no período'));
  if(r.missing)tags.push(tag('Sem registro recebido'));
  const detail=[];
  if(!r.archived){
   detail.push(r.last===null?'Ainda não há treino registrado na agenda ou recebido deste aluno.':'Último registro de treino: '+date(r.last)+'.');
   detail.push(r.assessmentUnknown?'Avaliações ainda não consultadas ou indisponíveis.':r.lastAssessment===null?'Nenhuma avaliação vinculada.':'Última avaliação: '+date(r.lastAssessment)+'.');
   if(s.firebaseUid)detail.push(r.remote?.message|| (r.remote?.at?'App do aluno consultado em '+stamp(r.remote.at)+'.':'App do aluno ainda não consultado. Toque em Atualizar.'));
   else detail.push('Sem conta vinculada ao app; acompanhamento pelos registros do professor.');
  }
  if(r.pending)detail.push(r.delivery.message||'O recebimento ainda não foi confirmado.');
  const button=(action,label,primary=false)=>'<button class="btn'+(primary?' primary':'')+'" type="button" data-followup-action="'+action+'">'+label+'</button>';
  const primary=r.pending?button('retry','Tentar envio',true):r.reassessment?button('assessment','Ver avaliações',true):button('progress',r.lastSource==='teacher'?'Registros da agenda':r.lastSource==='student'?'Registros do app':'Ver registros',true);
  return '<article class="ap-followup-row" data-followup-student="'+safe(s.id)+'"><h4>'+safe(s.name||'Aluno')+'</h4><p class="ap-followup-sub">'+safe(r.archived?'Arquivado · pendência de acesso':s.studentType==='online'?'Online':s.studentType==='presencial'?'Presencial':'Modalidade a definir')+'</p><div class="ap-followup-tags">'+tags.join('')+'</div>'+detail.map(p=>'<p>'+safe(p)+'</p>').join('')+'<div class="ap-followup-row-actions">'+primary+button('profile','Perfil do aluno')+'</div></article>';
 }
 function render(){
  if(!active())return;
  const focused=document.activeElement?.closest('[data-followup-action]'),focusStudent=focused?.closest('[data-followup-student]')?.dataset.followupStudent,focusAction=focused?.dataset.followupAction;
  model=M.build({students:state.students,executions:state.workoutExecutions,watch:state.watchWorkoutResults||[],remote,assessments:assessmentMap,deliveries:deliveries(),preferences:state.studentFollowupPreferences,period});
  for(const [key,value]of Object.entries(model.counts))document.querySelector('[data-followup-count="'+key+'"]').textContent=value;
  $('apFollowupInactiveHint').textContent=model.preferences.inactiveDays+' dias ou sem registro';$('apFollowupAssessmentHint').textContent=model.preferences.reassessmentDays+' dias ou primeira avaliação';
  for(const button of document.querySelectorAll('[data-followup-filter]'))button.setAttribute('aria-pressed',String(button.dataset.followupFilter===filter));
  $('apFollowupPriorities').setAttribute('aria-pressed',String(filter==='attention'));$('apFollowupListTitle').textContent=titles[filter];
  const matched=r=>filter==='attention'?r.rank<6||r.assessmentUnknown:filter==='completed'?r.completed>0:filter==='inactive'?r.inactive||r.missing:filter==='reassessment'?r.reassessment:r.pending;
  const normalize=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR');
  let rows=model.rows.filter(matched).filter(r=>normalize(r.student.name).includes(normalize(query)));
  if(filter==='completed')rows=rows.slice().sort((a,b)=>(b.last??0)-(a.last??0)||String(a.student.name).localeCompare(String(b.student.name),'pt-BR'));
  $('apFollowupListCount').textContent=rows.length+' '+(rows.length===1?'aluno':'alunos')+(query?' na busca':'');
  $('apFollowupList').innerHTML=rows.length?rows.map(row).join(''):'<div class="ap-followup-empty">'+safe(query?'Nenhum aluno encontrado com esse nome.':!state.students.length?'Cadastre seu primeiro aluno para acompanhar os registros.':filter==='attention'?'Nenhuma prioridade nos registros consultados.':'Nenhum aluno neste grupo pelos registros disponíveis.')+'</div>';
  $('apFollowupRefresh').disabled=busy;
  $('apFollowupStatus').textContent=busy?'Atualizando os registros dos alunos…'+(progressTotal?' '+progressDone+' de '+progressTotal+'.':''):(navigator.onLine===false?'Sem conexão. Exibindo os dados já recebidos neste aparelho.':loadedAt?'Central atualizada em '+stamp(loadedAt)+'.':'Exibindo registros salvos neste aparelho.')+(assessmentError?' As avaliações não puderam ser lidas; nenhum prazo foi presumido.':'');
  if(focusStudent&&focusAction){const row=[...$('apFollowupList').children].find(n=>n.dataset.followupStudent===focusStudent);row?.querySelector('[data-followup-action="'+focusAction+'"]')?.focus({preventScroll:true})}
 }
 async function refresh(){
  if(!active()||busy)return;busy=true;progressDone=0;progressTotal=0;const ticket=++generation;remote=cachedRemote();render();
  const valid=()=>ticket===generation&&active();
  try{
   try{const workspace=await readEvaluationWorkspace();if(!valid())return;assessmentMap=Object.create(null);assessmentError=false;
    for(const s of state.students){
     const linked=workspace.clients.filter(c=>c.agendaStudentId===s.id);if(linked.length>1){assessmentMap[s.id]={state:'unknown'};continue}
     const client=linkedEvaluationClient(workspace.clients,s),phone=studentPhoneKey(s.phone);
     const ambiguous=!client&&phone&&workspace.clients.some(c=>!c.agendaStudentId&&studentNameKey(c.name)===studentNameKey(s.name)&&studentPhoneKey(c.phone||c.assessments?.at(-1)?.data?.clientPhone)===phone);
     assessmentMap[s.id]=ambiguous?{state:'unknown'}:{state:'known',records:client?.assessments||[]};
    }
   }catch(_){if(!valid())return;assessmentMap={};assessmentError=true}
   render();let api=source();try{if(!api&&typeof window.parent.APloadWorkoutSync==='function')api=await window.parent.APloadWorkoutSync()}catch(_){}
   if(!valid())return;
   if(api&&navigator.onLine!==false){const students=state.students.filter(s=>s.archived!==true&&s.firebaseUid),queue=students.slice();progressTotal=queue.length;
    const worker=async()=>{while(queue.length&&valid()){const s=queue.shift();try{await api.refresh(s.firebaseUid)}catch(_){}if(!valid())return;remote[s.id]={records:api.records(s.firebaseUid)||[],...api.summary(s.firebaseUid)};progressDone++;render()}};
    await Promise.all(Array.from({length:Math.min(3,queue.length)},worker));
   }
   if(valid())loadedAt=new Date().toISOString();
  }finally{if(ticket===generation){busy=false;if(active())render()}}
 }
 function open(){if(!allowed()){toast('Entre com a conta do professor para acompanhar os alunos.');return}showScreen('followup')}
 const previousShow=showScreen;showScreen=function(screen,...args){
  if(screen==='followup'&&!allowed())return toast('Entre com a conta do professor para acompanhar os alunos.');
  const before=currentScreen,result=previousShow(screen,...args);
  if(currentScreen==='followup'){if(before!=='followup'){remote=cachedRemote();const prefs=M.settings(state.studentFollowupPreferences);$('apFollowupInactiveDays').value=prefs.inactiveDays;$('apFollowupAssessmentDays').value=prefs.reassessmentDays;render();refresh()}}
  else if(before==='followup'){generation++;busy=false}
  return result;
 };
 $('apFollowupRefresh').onclick=refresh;$('apFollowupPriorities').onclick=()=>{filter='attention';render()};
 for(const b of document.querySelectorAll('[data-followup-filter]'))b.onclick=()=>{filter=b.dataset.followupFilter;render()};
 $('apFollowupPeriod').onchange=e=>{period=Number(e.target.value);render()};$('apFollowupSearch').oninput=e=>{query=e.target.value;render()};
 $('apFollowupSettings').onsubmit=e=>{e.preventDefault();if(!active())return;
  const inactiveDays=Number($('apFollowupInactiveDays').value),reassessmentDays=Number($('apFollowupAssessmentDays').value);
  if(![inactiveDays,reassessmentDays].every(n=>Number.isInteger(n)&&n>=1&&n<=365))return toast('Informe prazos inteiros de 1 a 365 dias.');
  if(commitWorkoutChange({studentFollowupPreferences:{inactiveDays,reassessmentDays}},'Critérios de acompanhamento atualizados',false)){render();toast('Critérios salvos.');$('apFollowupSettings').closest('details').open=false}
 };
 $('apFollowupList').onclick=e=>{
  const button=e.target.closest('[data-followup-action]'),sid=button?.closest('[data-followup-student]')?.dataset.followupStudent;if(!sid||!active())return;const s=studentById(sid);if(!s)return;
  const action=button.dataset.followupAction;
  if(action==='retry'){
   const api=parentApi(),area=(api?.knownAreas?.()||[]).find(a=>a.studentId===s.id&&a.studentUid===s.firebaseUid);if(!area)return toast('Abra o perfil e confira o vínculo da conta do aluno.');
   try{const current=APStudentModel.makeArea(state,s,{pixKey:PIX_KEY,video:workoutExerciseVideoUrl,visible:workoutPlanVisible,groups:window.workoutBisetGroups,shared:window.workoutBisetExercisePrescription,prescription:window.workoutTechniqueRoundPrescription});api.stage(current);api.retry(s.firebaseUid);render()}catch(_){toast('Não foi possível preparar o envio. Confira a área do aluno no perfil.')}
   return;
  }
  if(action==='assessment'){openEvaluations(sid,'history');return}
  openStudentProfile(sid);
  if(action==='progress'){const item=model?.rows.find(r=>r.student.id===sid);if(item?.lastSource==='watch'||item?.lastSource==='student'&&s.firebaseUid)APTeacherProgress.open();else{workoutStudentId=sid;openStudentWorkoutProgress()}}
 };
 const previousAll=renderAll;renderAll=function(...args){const result=previousAll(...args);if(active()){remote=cachedRemote();render()}return result};
 const previousStatus=window.APupdateAreaStatus;window.APupdateAreaStatus=function(...args){const result=previousStatus?.(...args);if(active())render();return result};
 function clear(){generation++;busy=false;remote={};assessmentMap={};loadedAt='';model=null;$('apFollowupList').replaceChildren();if(currentScreen==='followup')previousShow('dashboard')}
 try{window.parent.addEventListener('ap-account-changed',clear)}catch(_){}
 addEventListener('storage',()=>{if(active()){remote=cachedRemote();refresh()}});addEventListener('online',()=>{if(active())refresh()});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&active())refresh()});
 const poll=setInterval(()=>{if(!document.hidden&&active()){remote=cachedRemote();render()}},30000);
 addEventListener('pagehide',()=>{generation++;clearInterval(poll);try{window.parent.removeEventListener('ap-account-changed',clear)}catch(_){}},{once:true});
 window.APStudentFollowup=Object.freeze({open,refresh,render,snapshot:()=>allowed()?model:null});mount();
})();
