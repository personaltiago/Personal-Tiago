let soundPreviewKind='',soundPreviewPoll=null;
function renderSoundPreviewButtons(){
 document.querySelectorAll('[data-sound-preview]').forEach(button=>{
  const kind=button.dataset.soundPreview,active=soundPreviewKind===kind;
  button.textContent=active?'■ Parar':'▶ Ouvir';button.setAttribute('aria-pressed',String(active));
  button.setAttribute('aria-label',(active?'Parar som ':'Ouvir som ')+(kind==='rest'?'do descanso do treino':kind==='timer'?'do fim da aula':'antes da aula'));
 });
}
function stopSoundPreview(){
 clearInterval(soundPreviewPoll);soundPreviewPoll=null;soundPreviewKind='';
 try{window.Android?.stopCustomSoundPreview?.()}catch(_){}
 renderSoundPreviewButtons();
}
function toggleSoundPreview(kind){
 if(!['lesson','timer','rest'].includes(kind))return;
 if(soundPreviewKind===kind)return stopSoundPreview();
 stopSoundPreview();
 if(!ensureRestSoundSupport(kind))return;
 if(!window.Android?.playCustomSound||!Android.getSoundPreviewStatus)return toast('Para ouvir o áudio salvo, instale o APK 1.102 ou posterior.',5500);
 try{
  if(Android.playCustomSound(kind)!==true)return toast('Não foi possível iniciar a prévia do som.',4500);
  soundPreviewKind=kind;renderSoundPreviewButtons();
  soundPreviewPoll=setInterval(()=>{
   try{const status=JSON.parse(Android.getSoundPreviewStatus());
    if(status.error){const message=status.error;stopSoundPreview();toast(message,5500)}
    else if(!status.kind){stopSoundPreview()}
    else if(soundPreviewKind!==status.kind){soundPreviewKind=status.kind;renderSoundPreviewButtons()}
   }catch(_){stopSoundPreview();toast('Não foi possível conferir a reprodução do áudio.',4500)}
  },250);
 }catch(_){stopSoundPreview();toast('Não foi possível reproduzir esse áudio.',4500)}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopSoundPreview()});
window.addEventListener('pagehide',stopSoundPreview);
renderSoundPreviewButtons();
function choosePhoneAlarmRingtone(kind){
 if(!['lesson','timer','rest'].includes(kind))return;stopSoundPreview();if(!ensureRestSoundSupport(kind))return;
 if(!window.Android?.chooseAlarmRingtone)return toast('Para escolher os toques do celular, instale o APK 1.106 ou posterior. Você pode continuar escolhendo um arquivo de áudio.',6500);
 try{if(Android.chooseAlarmRingtone(kind)!==true)toast('Não foi possível abrir a lista de toques do celular.',4500)}catch(_){toast('Não foi possível abrir a lista de toques do celular.',4500)}
}
function openLessonSoundSettings(){
 showScreen('settings');
 const choice=document.querySelector('[data-phone-ringtone="rest"]');
 if(choice){choice.scrollIntoView({block:'center'});choice.focus({preventScroll:true})}
}
function ensureRestSoundSupport(kind){
 if(kind!=='rest')return true;
 try{if(JSON.parse(Android.getCustomSoundStatus()).restSupported===true)return true}catch(_){}
 toast('Para escolher e ouvir o som do descanso entre séries, instale o APK 1.111 ou posterior.',6500);return false;
}
