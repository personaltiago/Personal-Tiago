let soundPreviewKind='',soundPreviewPoll=null;
function renderSoundPreviewButtons(){
 document.querySelectorAll('[data-sound-preview]').forEach(button=>{
  const kind=button.dataset.soundPreview,active=soundPreviewKind===kind;
  button.textContent=active?'■ Parar':'▶ Ouvir';button.setAttribute('aria-pressed',String(active));
  button.setAttribute('aria-label',(active?'Parar som ':'Ouvir som ')+(kind==='timer'?'do fim da aula':'antes da aula'));
 });
}
function stopSoundPreview(){
 clearInterval(soundPreviewPoll);soundPreviewPoll=null;soundPreviewKind='';
 try{window.Android?.stopCustomSoundPreview?.()}catch(_){}
 renderSoundPreviewButtons();
}
function toggleSoundPreview(kind){
 if(!['lesson','timer'].includes(kind))return;
 if(soundPreviewKind===kind)return stopSoundPreview();
 stopSoundPreview();
 if(!window.Android?.playCustomSound||!Android.getSoundPreviewStatus)return toast('Para ouvir o áudio salvo, instale o APK 1.102 ou posterior.',5500);
 try{
  if(Android.playCustomSound(kind)!==true)return toast('Não foi possível iniciar a prévia do som.',4500);
  soundPreviewKind=kind;renderSoundPreviewButtons();
  soundPreviewPoll=setInterval(()=>{
   try{const status=JSON.parse(Android.getSoundPreviewStatus());
    if(status.error){const message=status.error;stopSoundPreview();toast(message,5500)}
    else if(!status.kind){stopSoundPreview()}
    else if(soundPreviewKind!==status.kind){soundPreviewKind=status.kind;renderSoundPreviewButtons()}
   }catch(_){stopSoundPreview();toast('Não foi possível conferir a reprodução do áudio.',4500)}
  },250);
 }catch(_){stopSoundPreview();toast('Não foi possível reproduzir esse áudio.',4500)}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopSoundPreview()});
window.addEventListener('pagehide',stopSoundPreview);
renderSoundPreviewButtons();
