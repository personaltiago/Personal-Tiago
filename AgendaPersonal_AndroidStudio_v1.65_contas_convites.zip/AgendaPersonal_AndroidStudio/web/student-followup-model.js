(function(global){
 'use strict';
 const DAY=86400000;
 function day(value){
  const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value||''));if(!m)return null;
  const [y,mo,d]=m.slice(1).map(Number),date=new Date(y,mo-1,d);
  return date.getFullYear()===y&&date.getMonth()===mo-1&&date.getDate()===d?Date.UTC(y,mo-1,d)/DAY:null;
 }
 function calendar(time){const d=new Date(time);return Number.isFinite(d.getTime())?Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/DAY:null}
 function age(date,today){return date===null?null:today-date}
 function fullyCompleted(record){
  if(!Number.isInteger(record.totalExercises)||record.totalExercises<1||!Array.isArray(record.exercises)||record.exercises.length!==record.totalExercises)return false;
  const ids=record.exercises.map(e=>e.exerciseId);if(ids.some(id=>typeof id!=='string'||!id)||new Set(ids).size!==ids.length)return false;
  return record.exercises.every(ex=>{
   const technique=ex.technique?.rows,raw=ex.biset?.roundsPlanned??(Array.isArray(technique)&&technique.length?technique.reduce((n,r)=>n+Number(r.sets),0):ex.prescribed?.sets),expected=Number(raw);
   if(!Number.isInteger(expected)||expected<1||expected>100||!Array.isArray(ex.performedSets)||ex.performedSets.length!==expected)return false;
   const rounds=ex.performedSets.map(r=>Number(r.round));
   return new Set(rounds).size===expected&&ex.performedSets.every(r=>{const timed=r.unit==='seconds',value=Number(timed?r.seconds??r.reps:r.reps);return Number.isInteger(Number(r.round))&&Number(r.round)>=1&&Number(r.round)<=expected&&Number.isInteger(value)&&value>=1&&value<=(timed?86400:999)&&(!timed||r.seconds===undefined||Number(r.reps)===value)});
  });
 }
 function settings(value={}){if(!value||typeof value!=='object')value={};const valid=(n,f)=>Number.isInteger(Number(n))&&Number(n)>=1&&Number(n)<=365?Number(n):f;return {inactiveDays:valid(value.inactiveDays,7),reassessmentDays:valid(value.reassessmentDays,60)}}
 function build({students=[],executions=[],watch=[],remote={},assessments={},deliveries={},preferences={},now=Date.now(),period=7}){
  const today=calendar(now),prefs=settings(preferences),rows=[];
  for(const student of students){
   const sid=student.id,delivery=deliveries[sid],pending=!!delivery&&['pending','sending','error'].includes(delivery.state);
   if(student.archived===true){if(pending)rows.push({student,pending:true,delivery,archived:true,rank:delivery.state==='error'?0:1,completed:0,inactive:false,reassessment:false,missing:false});continue}
   const info=remote[sid]||{},records=[];
   for(const r of executions.filter(r=>r.studentId===sid)){
    if(!Array.isArray(r.exercises)||!r.exercises.length)continue;
    // The recorded training date can intentionally differ from the save date.
    const date=r.date?day(r.date):calendar(r.finishedAt||r.recordedAt);if(date!==null&&date<=today)records.push({date,key:'teacher:'+String(r.id||r.sessionId),source:'teacher',complete:fullyCompleted(r)});
   }
   for(const r of info.records||[]){
    const date=calendar(r.finishedAt);if(r.incomplete===false&&Array.isArray(r.exerciseRecords)&&r.exerciseRecords.length&&r.exerciseRecords.every(e=>Array.isArray(e.done)&&e.done.length&&e.done.every(v=>v===true))&&date!==null&&date<=today)records.push({date,key:'student:'+JSON.stringify([r.id,r.startedAt,r.finishedAt]),source:'student',complete:true});
   }
   for(const r of watch.filter(r=>r.studentId===sid&&r.role==='teacher')){const date=calendar(r.finishedAt);if(date!==null&&date<=today&&Number.isInteger(r.total)&&r.total>0&&Number.isInteger(r.completed)&&r.completed>0&&r.completed<=r.total)records.push({date,key:'watch:'+r.owner+':'+r.token,source:'watch',complete:r.completed===r.total})}
   const unique=[...new Map(records.map(r=>[r.key,r])).values()],last=unique.length?Math.max(...unique.map(r=>r.date)):null,days=age(last,today);
   const assessment=assessments[sid]||{state:'unknown'},assessmentRecords=Array.isArray(assessment.records)?assessment.records:[],dates=assessmentRecords.map(r=>day(r?.date)).filter(d=>d!==null&&d<=today),lastAssessment=dates.length?Math.max(...dates):null,assessmentAge=age(lastAssessment,today),assessmentKnown=assessment.state==='known'&&(assessment.records===undefined||Array.isArray(assessment.records))&&(!assessmentRecords.length||dates.length>0);
   const inactive=days!==null&&days>=prefs.inactiveDays,missing=last===null;
   const reassessment=assessmentKnown&&(lastAssessment===null||assessmentAge>=prefs.reassessmentDays);
   const completed=unique.filter(r=>r.complete&&r.date>=today-(period-1)).length;
   const rank=pending?(delivery.state==='error'?0:1):reassessment&&lastAssessment!==null?2:inactive?3:reassessment?4:missing?5:6;
   const lastSource=unique.find(r=>r.date===last)?.source||'';
   rows.push({student,pending,delivery,archived:false,completed,last,lastSource,days,inactive,missing,reassessment,lastAssessment,assessmentAge,assessmentUnknown:!assessmentKnown,remote:info,rank});
  }
  rows.sort((a,b)=>a.rank-b.rank||(b.days??-1)-(a.days??-1)||String(a.student.name).localeCompare(String(b.student.name),'pt-BR'));
  return {rows,preferences:prefs,counts:{completed:rows.filter(r=>r.completed>0).length,inactive:rows.filter(r=>r.inactive||r.missing).length,reassessment:rows.filter(r=>r.reassessment).length,pending:rows.filter(r=>r.pending).length},attention:rows.filter(r=>r.rank<6||r.assessmentUnknown).length};
 }
 global.APStudentFollowupModel=Object.freeze({build,settings,day,calendar,fullyCompleted});
})(globalThis);
