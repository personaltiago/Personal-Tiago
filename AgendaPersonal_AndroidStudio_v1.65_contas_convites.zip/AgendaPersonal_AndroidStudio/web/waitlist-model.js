(function(global){
 'use strict';
 const durations=[30,45,60,90,120];
 function phone(value){const s=String(value||'').trim(),d=s.replace(/\D/g,'');if(/[^\d\s()+.\-]/.test(s))return '';if(s.startsWith('+'))return d.length>=10&&d.length<=15?d:'';return d.length===10||d.length===11?'55'+d:/^55\d{10,11}$/.test(d)?d:''}
 const minutes=t=>/^([01]\d|2[0-3]):[0-5]\d$/.test(t||'')?Number(t.slice(0,2))*60+Number(t.slice(3)):NaN;
 const time=n=>String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0');
 const key=s=>s.date+'|'+s.time+'|'+s.duration;
 function ordered(rows){return (Array.isArray(rows)?rows:[]).filter(r=>r&&typeof r.id==='string'&&r.status==='waiting').slice().sort((a,b)=>String(a.createdAt||'').localeCompare(String(b.createdAt||''))||a.id.localeCompare(b.id))}
 function entry(input,previous,now,id){
  const name=String(input.name||'').trim().replace(/\s+/g,' '),number=phone(input.phone),duration=Number(input.duration),start=minutes(input.start),end=minutes(input.end),days=[...new Set((input.days||[]).map(Number))].filter(d=>Number.isInteger(d)&&d>=0&&d<=6).sort();
  if(name.length<2||name.length>90)throw Error('Informe o nome, com 2 a 90 caracteres.');
  if(!number)throw Error('Informe um WhatsApp válido com DDD. Para outro país, use + e o código do país.');
  if(!durations.includes(duration)||!Number.isFinite(start)||!Number.isFinite(end)||end-start<duration)throw Error('O período disponível precisa comportar a duração da aula.');
  if(!days.length)throw Error('Selecione pelo menos um dia da semana.');
  return {...previous,id:previous?.id||id,name,phone:number,studentId:String(input.studentId||''),duration,start:time(start),end:time(end),days,status:'waiting',createdAt:previous?.createdAt||now,updatedAt:now,declinedSlots:Array.isArray(previous?.declinedSlots)?previous.declinedSlots:[]};
 }
 function fits(row,slot,day){const a=minutes(slot.time),b=a+Number(row.duration);return row.status==='waiting'&&row.days?.includes(day)&&Number.isFinite(a)&&a>=minutes(row.start)&&b<=minutes(row.end)&&Number(row.duration)<=Number(slot.duration)&&!(row.declinedSlots||[]).some(k=>k===key(slot)||k===slot.date+'|'+slot.time)}
 function candidates(rows,slot,day){return ordered(rows).filter(r=>fits(r,slot,day))}
 function opportunities(rows,windows,nowDate,nowMinutes){
  const active=ordered(rows),found=new Map();
  for(const w of windows)for(const r of active){
   if(!r.days?.includes(w.day)||w.date<nowDate)continue;
   let a=Math.ceil(Math.max(w.start,minutes(r.start),w.date===nowDate?nowMinutes+1:0)/15)*15;
   const b=Math.min(w.end,minutes(r.end)),duration=Number(r.duration);
   // Check each possible start: declining one offer must not hide the entire
   // free interval, and a short preference can fit inside a larger vacancy.
   for(;Number.isFinite(a)&&a+duration<=b;a+=15){const slot={date:w.date,time:time(a),duration};if(!fits(r,slot,w.day))continue;found.set(key(slot),slot);break}
  }
  return [...found.values()].sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)||a.duration-b.duration).slice(0,60);
 }
 function message(row,slot,dateLabel){const end=time(minutes(slot.time)+Number(row.duration));return 'Olá, '+row.name+'! Surgiu uma vaga para aula presencial em '+dateLabel+', das '+slot.time+' às '+end+' ('+row.duration+' minutos). Você é a próxima pessoa da lista de espera compatível com esse horário. Tem interesse? Me confirme por aqui para combinarmos o agendamento.'}
 global.APWaitlistModel=Object.freeze({phone,minutes,time,key,ordered,entry,fits,candidates,opportunities,message,durations});
})(globalThis);
