(function() {
    "use strict";
    const CONFIG = {
        apiKey: "AIzaSyBRGoqS1jLnv8qqt3yfOZzL2JWhgSQfzfM",
        authDomain: "agenda-personal-bdb58.firebaseapp.com",
        projectId: "agenda-personal-bdb58",
        storageBucket: "agenda-personal-bdb58.firebasestorage.app",
        messagingSenderId: "1044097605904",
        appId: "1:1044097605904:web:29d9c6bb7afa7484c34595"
    };
    const TEACHER = "R2EmnDVcvMWt7TjPxOP6DjW1VOn1";
    const SDK_BASE = "https://www.gstatic.com/firebasejs/10.14.1/";
    let tab = "link", sdk = null, sdkPromise = null, contacts = [], requestEpoch = 0;
    const el = id => document.getElementById(id);
    const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[c]));
    function say(message, error = false) {
        const out = el("registrationStatus");
        out.textContent = message;
        out.dataset.error = String(error);
    }
    function registrationUrl(value) {
        const raw = String(value || "").trim();
        if (!raw) return "";
        try {
            const u = new URL(raw);
            if (u.protocol !== "https:" || u.username || u.password || !u.hostname.includes(".") || /^(localhost|127\.|0\.|\[)/i.test(u.hostname)) return "";
            u.hash = "";
            u.searchParams.set("cadastro", "1");
            return u.toString();
        } catch (_) {
            return "";
        }
    }
    function publishedPageUrl() {
        try {
            const address = window.parent?.location?.href || window.location.href, u = new URL(address);
            if (/(^|\.)(chatgpt\.com|openai\.com|oaiusercontent\.com|blob\.core\.windows\.net|amazonaws\.com)$/i.test(u.hostname)) return "";
            if (u.hostname === "appassets.androidplatform.net") return "";
            u.search = "";
            u.hash = "";
            return registrationUrl(u.toString());
        } catch (_) {
            return "";
        }
    }
    function currentUrl() {
        const stored = registrationUrl(state.registrationLink?.url);
        return stored && !stored.includes("appassets.androidplatform.net") ? stored : publishedPageUrl() || registrationUrl("https://personaltiago.github.io/Personal-Tiago/cadastro-aluno.html");
    }
    function renderLink() {
        const url = currentUrl();
        el("registrationPublicUrl").value = url;
        el("registrationUrlSetting").value = currentUrl();
        el("registrationCopy").disabled = !url;
        el("registrationWhatsApp").disabled = !url;
        el("registrationUrlHint").textContent = url ? "O aluno preenche o formulário. O cadastro fica aguardando sua aprovação." : "Publique este HTML completo na internet para gerar o link de cadastro. Se já estiver publicado, informe seu endereço abaixo.";
        el("registrationConfig").hidden = Boolean(url);
        el("registrationEdit").setAttribute("aria-expanded", String(!url));
    }
    function editLink() {
        el("registrationUrlSetting").value = currentUrl();
        el("registrationConfig").hidden = false;
        el("registrationEdit").setAttribute("aria-expanded", "true");
        say("");
        el("registrationUrlSetting").focus();
        el("registrationUrlSetting").select();
        el("registrationConfig").scrollIntoView({
            block: "nearest",
            behavior: "smooth"
        });
    }
    function cancelEdit() {
        renderLink();
        say("");
        el("registrationEdit").focus();
    }
    function saveUrl(event) {
        event.preventDefault();
        const url = registrationUrl(el("registrationUrlSetting").value);
        if (!url) {
            say("Informe um endereço https:// publicado na internet.", true);
            return;
        }
        const settings = {
            version: 1,
            url: url
        };
        try {
            localStorage.setItem(DB_KEY, JSON.stringify({
                ...state,
                registrationLink: settings
            }));
            state.registrationLink = settings;
            renderLink();
            say("Endereço de cadastro salvo.");
        } catch (_) {
            say("Não foi possível salvar o endereço. Confira o armazenamento do aplicativo.", true);
        }
    }
    function normalPhone(value) {
        const digits = String(value || "").replace(/\D/g, "");
        return digits.length === 10 || digits.length === 11 ? "55" + digits : digits;
    }
    function registrationPhoto(value) {
        return typeof value === "string" && value.length <= 12e4 && /^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(value) ? value : "";
    }
    function profileData(value) {
        if (!value || !/^[A-Za-z0-9_-]{1,128}$/.test(String(value.uid || "")) || value.professorId !== TEACHER || value.perfil !== "aluno") throw Error("Cadastro inválido para este professor.");
        const name = String(value.nome || "").trim(), email = String(value.email || "").trim().toLowerCase(), phone = String(value.whatsapp || "").trim();
        if (name.length < 2 || name.length > 120 || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !/^\+?[\d\s().-]+$/.test(phone) || normalPhone(phone).length < 10 || normalPhone(phone).length > 15) throw Error("Confira o nome, o e-mail e o WhatsApp deste cadastro.");
        const birth = String(value.nascimento || "");
        if (birth) {
            const d = new Date(birth + "T12:00:00");
            if (!/^\d{4}-\d{2}-\d{2}$/.test(birth) || Number.isNaN(d.getTime()) || d.getFullYear() !== Number(birth.slice(0, 4)) || d.getMonth() + 1 !== Number(birth.slice(5, 7)) || d.getDate() !== Number(birth.slice(8, 10)) || birth > iso(new Date)) throw Error("Confira a data de nascimento deste cadastro.");
        }
        return {
            uid: value.uid,
            name: name,
            email: email,
            phone: phone,
            birth: birth,
            gender: String(value.genero || "").slice(0, 60),
            photo: registrationPhoto(value.fotoCadastro)
        };
    }
    function prepareImport(record, type, targetId = "", base = state) {
        const p = profileData(record);
        if (record.ativo !== true) throw Error("A solicitação ainda precisa ser aprovada.");
        if (![ "presencial", "online" ].includes(type)) throw Error("Selecione Presencial ou Online para aprovar.");
        const linked = base.students.filter(s => s.firebaseUid === p.uid);
        if (linked.length > 1) throw Error("Há mais de um aluno vinculado a este cadastro. Confira a agenda.");
        if (linked.length && targetId && targetId !== linked[0].id) throw Error("Este cadastro já está vinculado a outro aluno.");
        const existing = linked[0] || (targetId ? base.students.find(s => s.id === targetId) : null);
        if (targetId && !existing) throw Error("O aluno escolhido não está mais na agenda.");
        if (existing?.firebaseUid && existing.firebaseUid !== p.uid) throw Error("Este aluno já tem outro cadastro online vinculado.");
        if (linked.length) return {
            unchanged: true,
            student: linked[0],
            next: base
        };
        const student = {
            ...existing || {
                id: "firebase_" + p.uid,
                name: p.name,
                phone: p.phone,
                photoDataUrl: "",
                location: "",
                notes: "",
                financeEnabled: false,
                startDate: "",
                dueDate: "",
                monthlyValue: "",
                paymentReminderDays: 3,
                trainingDocuments: []
            },
            studentType: type,
            photoDataUrl: existing?.photoDataUrl || p.photo,
            firebaseUid: p.uid,
            email: existing?.email || p.email,
            birthDate: existing?.birthDate || p.birth,
            gender: existing?.gender || p.gender,
            phone: existing?.phone || p.phone,
            signupSource: "link",
            registrationApprovedAt: (new Date).toISOString()
        };
        if (!existing && base.students.some(s => s.id === student.id)) throw Error("O identificador deste aluno já existe na agenda.");
        const students = existing ? base.students.map(s => s.id === existing.id ? student : s) : [ ...base.students, student ];
        const history = [ {
            id: id(),
            at: (new Date).toISOString(),
            text: existing ? "Cadastro por link vinculado · " + student.name : "Aluno cadastrado por link · " + student.name
        }, ...base.history ];
        return {
            unchanged: false,
            student: student,
            next: {
                ...base,
                students: students,
                history: history
            }
        };
    }
    function importApproved(record, type, targetId = "") {
        const result = prepareImport(record, type, targetId);
        if (result.unchanged) return result.student;
        localStorage.setItem(DB_KEY, JSON.stringify(result.next));
        state.students = result.next.students;
        state.history = result.next.history;
        try {
            renderAll();
            syncNativeAlarms();
        } catch (problem) {
            console.warn("Cadastro salvo; falha ao atualizar a interface.", problem);
        }
        return result.student;
    }
    function problemText(problem) {
        const code = problem?.code || "";
        return {
            "auth/invalid-email": "Informe um e-mail válido.",
            "auth/invalid-credential": "E-mail ou senha incorretos.",
            "auth/wrong-password": "E-mail ou senha incorretos.",
            "auth/user-not-found": "E-mail ou senha incorretos.",
            "auth/too-many-requests": "Muitas tentativas. Aguarde um pouco e tente novamente.",
            "auth/network-request-failed": "Não foi possível conectar. Confira a internet e tente novamente.",
            "permission-denied": "O cadastro online ainda não permite esta operação. Confira as permissões do Firebase.",
            unavailable: "O cadastro online está indisponível. Tente novamente."
        }[code] || problem?.message || "Não foi possível concluir esta ação.";
    }
    function registrationHost() {
        try {
            return window.parent !== window ? window.parent.APaccounts || null : null;
        } catch (_) {
            return null;
        }
    }
    async function ensureSdk() {
        // Embedded panels always use the owner's registration service. A delayed
        // account bootstrap must never create a second authentication instance.
        if (window.parent !== window) throw Error("Aguarde a confirmação da sessão do professor e tente novamente.");
        if (sdk) return sdk;
        if (sdkPromise) return sdkPromise;
        sdkPromise = (async () => {
            const [appModule, authModule, storeModule] = await Promise.all([ import(SDK_BASE + "firebase-app.js"), import(SDK_BASE + "firebase-auth.js"), import(SDK_BASE + "firebase-firestore.js") ]);
            const app = appModule.getApps().find(a => a.name === "[DEFAULT]") || appModule.initializeApp(CONFIG);
            // Match the entry page's persistence order. Firebase's default
            // indexedDB-first initialization migrates the saved local session
            // and makes the entry page observe a false sign-out.
            const auth = authModule.initializeAuth(app, {
                persistence: [authModule.browserLocalPersistence, authModule.indexedDBLocalPersistence, authModule.browserSessionPersistence]
            });
            if (auth.authStateReady) await auth.authStateReady();
            sdk = {
                ...authModule,
                ...storeModule,
                auth: auth,
                db: storeModule.getFirestore(app)
            };
            sdk.onAuthStateChanged(sdk.auth, () => {
                if (tab === "contacts" && el("registrationLinkDialog").classList.contains("open")) renderContacts();
            });
            return sdk;
        })().catch(problem => {
            sdkPromise = null;
            throw problem;
        });
        return sdkPromise;
    }
    function teacherSignedIn() {
        const host = registrationHost();
        return host ? host.isTeacher() === true && !window.parent.__AP_STUDENT_CONTEXT : sdk?.auth?.currentUser?.uid === TEACHER;
    }
    function open() {
        tab = "link";
        renderLink();
        setTab("link");
        openDialog("registrationLinkDialog");
    }
    function setTab(next) {
        tab = next === "contacts" ? "contacts" : "link";
        requestEpoch++;
        say("");
        for (const key of [ "link", "contacts" ]) {
            const active = key === tab;
            el(key === "link" ? "registrationLinkTab" : "registrationContactsTab").setAttribute("aria-selected", String(active));
            el(key === "link" ? "registrationLinkPanel" : "registrationContactsPanel").hidden = !active;
        }
        if (tab === "link") renderLink(); else renderContacts();
    }
    async function renderContacts() {
        const root = el("registrationContactsView"), epoch = ++requestEpoch, host = registrationHost();
        if (host) {
            if (!teacherSignedIn()) {
                root.innerHTML = '<p class="registration-help">Entre pela tela de acesso do aplicativo com a conta do professor para consultar os cadastros.</p>';
                return;
            }
            if (typeof host.registrations?.list !== "function") {
                root.innerHTML = '<p class="registration-help">Atualize o aplicativo para consultar os contatos nesta tela.</p>';
                return;
            }
        } else if (!sdk) {
            root.innerHTML = '<div class="registration-empty">Conectando ao cadastro online…</div>';
            try {
                await ensureSdk();
                if (epoch === requestEpoch && tab === "contacts") renderContacts();
            } catch (problem) {
                if (epoch !== requestEpoch || tab !== "contacts") return;
                root.innerHTML = '<div class="registration-empty">Não foi possível abrir o cadastro online.</div><button class="btn" type="button" onclick="setRegistrationTab(\'contacts\')">Tentar novamente</button>';
                say(problemText(problem), true);
            }
            return;
        }
        if (!teacherSignedIn()) {
            root.innerHTML = '<p class="registration-help">Entre com a conta do professor para ver e aprovar as solicitações recebidas.</p><form class="registration-login" id="registrationTeacherLogin"><label class="field full"><span>E-mail do professor</span><input name="email" type="email" autocomplete="username" required></label><label class="field full"><span>Senha</span><input name="password" type="password" autocomplete="current-password" required></label><button class="btn" type="submit">Entrar</button></form>';
            el("registrationTeacherLogin").onsubmit = async event => {
                event.preventDefault();
                const form = event.currentTarget, button = form.querySelector("button"), data = new FormData(form);
                button.disabled = true;
                say("Entrando…");
                try {
                    const result = await sdk.signInWithEmailAndPassword(sdk.auth, String(data.get("email")).trim(), data.get("password"));
                    if (result.user.uid !== TEACHER) {
                        await sdk.signOut(sdk.auth);
                        throw Error("Use a conta do professor da Agenda Personal.");
                    }
                    say("");
                    if (tab === "contacts") renderContacts();
                } catch (problem) {
                    button.disabled = false;
                    say(problemText(problem), true);
                }
            };
            return;
        }
        root.innerHTML = '<div class="registration-contact-toolbar"><button class="btn" id="registrationRefresh" type="button">Atualizar contatos</button>' + (host ? "" : '<button class="btn" id="registrationSignOut" type="button">Sair desta conta</button>') + '</div><p class="registration-help">Escolha o tipo de aluno antes de aprovar. O cadastro aprovado entra na sua agenda.</p><div id="registrationContactsList" aria-live="polite"><div class="registration-empty">Buscando cadastros…</div></div>';
        el("registrationRefresh").onclick = () => renderContacts();
        if (!host) el("registrationSignOut").onclick = async () => {
            try {
                await sdk.signOut(sdk.auth);
                say("Você saiu do cadastro online.");
                renderContacts();
            } catch (problem) {
                say(problemText(problem), true);
            }
        };
        try {
            let rows;
            if (host) rows = await host.registrations.list(); else {
                const result = await sdk.getDocs(sdk.query(sdk.collection(sdk.db, "usuarios"), sdk.where("professorId", "==", TEACHER)));
                rows = result.docs.map(row => ({
                    ...row.data(),
                    uid: row.id
                })).filter(row => row.perfil === "aluno" && row.professorId === TEACHER);
            }
            if (epoch !== requestEpoch || tab !== "contacts" || !teacherSignedIn()) return;
            contacts = rows;
            renderList();
        } catch (problem) {
            if (epoch !== requestEpoch || tab !== "contacts") return;
            const list = el("registrationContactsList");
            if (list) list.innerHTML = '<div class="registration-empty">Não foi possível carregar os cadastros. Toque em Atualizar contatos para tentar novamente.</div>';
            say(problemText(problem), true);
        }
    }
    function renderList() {
        const root = el("registrationContactsList");
        if (!root || !teacherSignedIn() || tab !== "contacts") return;
        const list = contacts.slice().sort((a, b) => Number(a.ativo === true) - Number(b.ativo === true) || String(a.nome || "").localeCompare(String(b.nome || ""), "pt-BR"));
        root.innerHTML = list.length ? list.map(record => {
            const linked = state.students.find(s => s.firebaseUid === record.uid), key = esc(record.uid), status = linked ? "Na agenda" : record.ativo === true ? "Aprovado · adicionar à agenda" : "Aguardando aprovação";
            const options = state.students.filter(s => !s.firebaseUid || s.firebaseUid === record.uid).map(s => '<option value="' + esc(s.id) + '">' + esc(s.name) + "</option>").join("");
            return '<article class="registration-contact" data-registration-uid="' + key + '">' + (registrationPhoto(record.fotoCadastro) ? '<img class="registration-contact-photo" src="' + esc(registrationPhoto(record.fotoCadastro)) + '" alt="Foto de ' + esc(record.nome) + '" width="72" height="72">' : "") + "<strong>" + esc(record.nome) + '</strong><span class="registration-contact-status">' + status + "</span><p>" + esc(record.email) + "<br>" + esc(record.whatsapp) + (record.nascimento ? "<br>" + esc(fmtDate(record.nascimento)) : "") + (record.genero ? " · " + esc(record.genero) : "") + "</p>" + (linked ? '<button class="btn" type="button" data-registration-edit="' + esc(linked.id) + '">Ver aluno na agenda</button>' : '<label class="field full"><span>Tipo de aluno</span><select data-registration-type required><option value="">Selecione</option><option value="presencial">Presencial</option><option value="online">Online</option></select></label>' + (options ? '<label class="field full"><span>Cadastro na agenda</span><select data-registration-target><option value="">Criar novo aluno</option>' + options + "</select></label>" : "") + '<button class="btn" type="button" data-registration-approve>' + (record.ativo === true ? "Adicionar à agenda" : "Aprovar aluno") + "</button>") + "</article>";
        }).join("") : '<div class="registration-empty">Nenhum cadastro recebido ainda.<br>Envie seu link aos novos alunos.</div>';
        root.querySelectorAll("[data-registration-approve]").forEach(button => button.onclick = () => approve(button));
        root.querySelectorAll("[data-registration-edit]").forEach(button => button.onclick = () => openEditStudent(button.dataset.registrationEdit));
    }
    async function approve(button) {
        if (!teacherSignedIn()) {
            say("Entre com a conta do professor para aprovar.", true);
            return;
        }
        const card = button.closest("[data-registration-uid]"), record = contacts.find(d => d.uid === card.dataset.registrationUid), type = card.querySelector("[data-registration-type]").value, target = card.querySelector("[data-registration-target]")?.value || "";
        try {
            prepareImport({
                ...record,
                ativo: true
            }, type, target);
        } catch (problem) {
            say(problemText(problem), true);
            return;
        }
        button.disabled = true;
        say(record.ativo === true ? "Adicionando à agenda…" : "Aprovando cadastro…");
        let approved = record.ativo === true;
        try {
            if (!approved) {
                const host = registrationHost();
                if (host) await host.registrations.approve(record.uid, type); else await sdk.updateDoc(sdk.doc(sdk.db, "usuarios", record.uid), {
                    ativo: true,
                    tipoAluno: type,
                    aprovadoEm: sdk.serverTimestamp()
                });
                approved = true;
                record.ativo = true;
            }
            if (!teacherSignedIn()) throw Error("Entre novamente com a conta do professor.");
            const student = importApproved({
                ...record,
                ativo: true
            }, type, target);
            say(student.name + " está na sua agenda.");
            renderList();
        } catch (problem) {
            button.disabled = false;
            say(approved ? "O cadastro está aprovado, mas não foi salvo na agenda. Use Adicionar à agenda para tentar novamente. " + problemText(problem) : problemText(problem), true);
            if (approved) renderList();
        }
    }
    async function copy() {
        const url = currentUrl();
        if (!url) {
            say("Configure o endereço publicado do formulário primeiro.", true);
            return;
        }
        try {
            await navigator.clipboard.writeText(url);
            say("Link copiado.");
        } catch (_) {
            const input = el("registrationPublicUrl");
            input.focus();
            input.select();
            let copied = false;
            try {
                copied = document.execCommand("copy");
            } catch (_) {}
            say(copied ? "Link copiado." : "O link está selecionado. Toque e segure para copiar.");
        }
    }
    function share() {
        const url = currentUrl();
        if (!url) {
            say("Configure o endereço publicado do formulário primeiro.", true);
            return;
        }
        const target = "https://wa.me/?text=" + encodeURIComponent(url);
        try {
            if (window.Android?.openExternal) {
                Android.openExternal(target);
                return;
            }
        } catch (_) {}
        window.open(target, "_blank", "noopener");
    }
    el("registrationUrlForm").onsubmit = saveUrl;
    window.editRegistrationLink = editLink;
    window.cancelRegistrationLinkEdit = cancelEdit;
    window.openRegistrationLink = open;
    window.setRegistrationTab = setTab;
    window.copyRegistrationLink = copy;
    window.shareRegistrationLink = share;
    window.agendaRegistration = Object.freeze({
        registrationUrl: registrationUrl,
        profileData: profileData,
        prepareImport: prepareImport,
        importApproved: importApproved,
        teacher: TEACHER
    });
})();
