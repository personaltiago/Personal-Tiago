(function(global){
 'use strict';
 const phrases=Object.freeze({
  increased:Object.freeze([
   'Hoje teve aumento de carga no seu registro. Que bom acompanhar esse passo com você!',
   'Uma carga maior entrou para a sua história. Valorize a conquista e continue respeitando seu ritmo.',
   'Você registrou um avanço nas cargas. Vamos seguir com essa atenção, um treino de cada vez.',
   'Tem novidade no seu histórico: mais carga hoje. Guarde essa conquista sem cobrar um recorde a cada treino.',
   'Hoje você foi além de uma carga anterior. Eu estou aqui para comemorar esse passo com você.',
   'Seu registro ganhou uma nova marca de carga. Aproveite a satisfação de ter avançado hoje!',
   'Mais carga em parte do treino, mais um momento para celebrar. Continue seguindo a orientação do seu professor.',
   'O aumento de hoje ficou registrado. Você pode reconhecer seu esforço sem pensar já no próximo desafio.',
   'Hoje houve um passo adiante nas cargas. Pequenas conquistas também merecem espaço na sua história.',
   'Vi um aumento nas cargas do seu treino. Que esse momento seja motivo de satisfação, sem virar cobrança.',
   'Sua carga mudou para cima hoje. Comemore o registro e mantenha o cuidado com cada movimento.',
   'Você acrescentou um novo avanço ao histórico. Eu sigo por aqui para acompanhar cada etapa.',
   'Treino concluído com aumento de carga registrado. Hoje há uma conquista concreta para reconhecer.',
   'Tem um passo novo no seu caminho: uma carga maior neste treino. Aproveite a conquista de hoje.',
   'Hoje uma carga anterior ficou para trás. O próximo treino pode ter outro ritmo, e tudo bem.',
   'Seu treino trouxe um aumento nas cargas. Vamos valorizar o que aconteceu hoje, sem pressa para repetir.',
   'Eu vi esse avanço no registro! Continue construindo sua trajetória com atenção e orientação.',
   'Mais carga hoje é um momento para celebrar. Seu cuidado com o treino continua tendo o mesmo valor.',
   'Você registrou uma carga maior e concluiu o treino. Reconheça esse passo antes de pensar no seguinte.',
   'Hoje seu histórico ganhou um motivo a mais para sorrir: um aumento de carga. Parabéns pelo treino!',
   'Seu avanço de hoje está salvo. Não precisa ser enorme para merecer reconhecimento.',
   'A carga aumentou em parte do treino. Vamos comemorar com os pés no chão e seguir no seu ritmo.',
   'Hoje teve uma conquista nas cargas. Continue dando espaço tanto aos avanços quanto às pausas previstas.',
   'Um aumento registrado, mais uma etapa da sua história. Eu estou acompanhando esse caminho com você.',
   'Você terminou o treino e registrou mais carga. Aproveite essa conquista; o próximo passo vem no tempo certo.'
  ]),
  maintained:Object.freeze([
   'As cargas comparáveis ficaram iguais hoje. Seu treino continua merecendo reconhecimento.',
   'Hoje não teve aumento de carga, mas teve treino concluído. Vamos seguir sem transformar cada sessão em uma prova.',
   'Você manteve as cargas e concluiu a sessão. Eu valorizo esse compromisso com o seu treino.',
   'O peso ficou igual; a sua história ganhou mais um treino. Continue no seu ritmo.',
   'Nem todo treino precisa trazer uma carga nova. Hoje você deu continuidade ao que está construindo.',
   'As cargas se mantiveram hoje. Ainda há espaço para valorizar a atenção que você dedica ao treino.',
   'Treino concluído com as mesmas cargas. Vamos preparar os próximos passos junto do seu professor, sem pressa.',
   'Hoje foi dia de manter. Você não precisa provar nada para merecer reconhecer seu esforço.',
   'O registro de hoje tem as mesmas cargas, e isso não tira o valor da sessão. Seguimos juntos.',
   'Uma sessão com as mesmas cargas também faz parte do caminho. Continue dando atenção a cada movimento.',
   'Não apareceu aumento hoje. Isso não é motivo para desistir do que você está construindo.',
   'Você concluiu mais um treino com as cargas mantidas. Valorize a sessão inteira, além dos números.',
   'Hoje a carga não mudou. Vamos continuar com atenção à execução e aos ajustes orientados pelo professor.',
   'Seu compromisso não precisa de um número maior para ser reconhecido. Treino concluído!',
   'Manter as cargas hoje não define até onde você pode chegar. Um treino de cada vez.',
   'O treino ficou registrado, mesmo sem aumento. Eu continuo aqui para acompanhar seus próximos passos.',
   'Hoje você manteve o peso dos exercícios comparáveis. Continue com paciência e atenção ao seu plano.',
   'A carga ficou igual, e a sua dedicação merece espaço nessa conversa. Vamos seguir.',
   'Não é preciso sair de todo treino com um recorde. Hoje você concluiu a sessão; reconheça isso.',
   'As cargas de hoje repetiram as anteriores. A próxima sessão será uma nova oportunidade, sem obrigação de aumentar.',
   'Você não precisa se cobrar por manter a carga. Continue seguindo a ficha e conversando com seu professor.',
   'Hoje teve continuidade, mesmo sem peso a mais. Eu estou com você nessa construção.',
   'O mesmo peso não torna este treino menos digno de reconhecimento. Valorize sua presença e seu cuidado.',
   'Seu registro de hoje está salvo. Para os próximos avanços, vale mais seguir o plano do que apressar o aumento.',
   'Hoje as cargas se mantiveram. Respire, reconheça a sessão concluída e siga com calma para a próxima.'
  ]),
  decreased:Object.freeze([
   'Hoje houve redução de carga. Isso não apaga o que você já construiu; seguimos um treino de cada vez.',
   'Uma carga menor não diminui o valor do seu esforço. Seu treino ficou registrado, e eu sigo com você.',
   'Você concluiu a sessão com menos carga em parte do treino. Não precisa se punir por esse número.',
   'O registro de hoje teve redução de carga. Há espaço para ajustar o ritmo sem abandonar o caminho.',
   'Seu histórico é maior do que um único dia. Uma carga menor hoje não define toda a sua trajetória.',
   'Hoje a carga desceu em parte do treino. Vamos continuar com cuidado e com a orientação do seu professor.',
   'Você não precisa compensar essa redução no próximo treino. Continue respeitando a ficha e seu momento.',
   'Treino concluído, mesmo com uma carga menor. Eu estou aqui para apoiar você, sem cobrança.',
   'A redução de hoje é um registro, não um julgamento sobre você. Vamos seguir com calma.',
   'Menos carga hoje não é motivo para desistir. Converse com seu professor sobre os próximos passos.',
   'Seu esforço merece reconhecimento também nos dias em que a carga diminui. Seguimos juntos.',
   'Hoje houve um ajuste para menos nas cargas. Você pode acolher esse momento sem diminuir suas conquistas.',
   'Um treino com carga menor não resume seu percurso. Continue dando atenção ao que precisa hoje.',
   'O peso mudou para baixo; o seu valor não mudou. Vamos levar cuidado e paciência para a próxima sessão.',
   'Há dias com números diferentes no registro. Hoje a carga diminuiu, e você não precisa se sentir em dívida.',
   'Você terminou o treino com uma redução de carga registrada. Reconheça a sessão sem se comparar com o seu melhor dia.',
   'Hoje não é preciso buscar uma explicação dura para cada quilo a menos. Vale conversar e ajustar o plano.',
   'As cargas podem variar entre sessões. O registro de hoje merece atenção, sem culpa e sem pressa de compensar.',
   'Uma redução não apaga os treinos anteriores. Eu continuo aqui para acompanhar o que vem pela frente.',
   'Hoje você usou menos carga em parte do treino. Continue com atenção ao movimento e às orientações recebidas.',
   'Não transforme a carga de hoje em uma medida do seu compromisso. Seu treino foi concluído.',
   'O próximo treino será uma nova sessão, sem obrigação de recuperar tudo. Vamos um passo de cada vez.',
   'Hoje houve carga menor, e tudo bem reconhecer isso sem culpa. Seu caminho continua aberto.',
   'Você não perdeu sua história porque um número diminuiu. Vamos seguir com paciência e orientação.',
   'Treino registrado. Hoje a carga diminuiu em parte da sessão; eu sigo com você para os próximos passos.'
  ])
 });
 const neutral=Object.freeze({
  first:'Seu treino ficou registrado. Vamos construir essa história juntos, uma sessão de cada vez.',
  mixed:'Treino concluído! Algumas cargas subiram e outras desceram. Seguimos com atenção à execução e à orientação do seu professor.',
  uncomparable:'Treino concluído e registrado. Seu esforço merece reconhecimento, mesmo quando não há cargas comparáveis no histórico.'
 });
 const normalize=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase().replace(/\s+/g,' ');
 function complete(record){return !!record&&record.incomplete===false&&!!record.id&&Number.isFinite(record.startedAt)&&Number.isFinite(record.finishedAt)&&record.finishedAt>=record.startedAt&&Array.isArray(record.exerciseRecords)&&!!record.exerciseRecords.length&&record.exerciseRecords.every(e=>e&&Array.isArray(e.done)&&!!e.done.length&&e.done.every(v=>v===true))}
 function load(value){if(typeof value!=='number'&&typeof value!=='string')return null;if(typeof value==='string'&&!/^\d+(?:[.,]\d+)?$/.test(value.trim()))return null;const n=Number(String(value).replace(',','.'));return Number.isFinite(n)&&n>=0&&n<=1000?n:null}
 function matchingExercise(current,records){
  // IDs identify an exercise within this workout, even after a reorder.
  let matches=current.exerciseId?records.filter(e=>e.exerciseId===current.exerciseId):[];
  if(!matches.length)matches=records.filter(e=>(!e.exerciseId||!current.exerciseId)&&normalize(e.name)===normalize(current.name));
  return matches.length===1?matches[0]:null;
 }
 function compare(record,history=[]){
  if(!complete(record))return {kind:'uncomparable',compared:0};
  const previous=(Array.isArray(history)?history:[]).filter(r=>complete(r)&&r.id===record.id&&r.finishedAt<=record.startedAt&&!(r.startedAt===record.startedAt&&r.finishedAt===record.finishedAt)).sort((a,b)=>b.finishedAt-a.finishedAt)[0];
  if(!previous)return {kind:'first',compared:0};
  let up=0,down=0,same=0;
  for(const e of record.exerciseRecords){
   const old=matchingExercise(e,previous.exerciseRecords);
   // Different set/repetition prescriptions, assisted machines and renamed
   // exercises do not establish the same external-load task.
   if(!old||normalize(e.name)!==normalize(old.name)||/assistid|gravitr?on/.test(normalize(e.name))||e.done.length!==old.done.length||!Array.isArray(e.loads)||!Array.isArray(old.loads))continue;
   const targets=x=>Array.isArray(x.targets)&&x.targets.length===x.done.length?x.targets:Array(x.done.length).fill(x.reps);
   const a=targets(e),b=targets(old);
   for(let i=0;i<e.done.length;i++){
    if(!normalize(a[i])||normalize(a[i])!==normalize(b[i]))continue;
    const x=load(e.loads[i]),y=load(old.loads[i]);if(x===null||y===null)continue;
    if(Math.abs(x-y)<0.000001)same++;else if(x>y)up++;else down++;
   }
  }
  return {kind:up&&down?'mixed':up?'increased':down?'decreased':same?'maintained':'uncomparable',compared:up+down+same};
 }
 function readRotation(value){
  const result={};for(const kind of Object.keys(phrases)){const s=value?.[kind]||{};result[kind]={used:[...new Set((Array.isArray(s.used)?s.used:[]).filter(i=>Number.isInteger(i)&&i>=0&&i<phrases[kind].length))],last:Number.isInteger(s.last)&&s.last>=0&&s.last<phrases[kind].length?s.last:-1}}return result;
 }
 function prepare(record,history,rotation,random=Math.random){
  if(!complete(record))return null;
  const comparison=compare(record,history),next=readRotation(rotation);let index=null;
  if(phrases[comparison.kind]){
   const state=next[comparison.kind],pool=phrases[comparison.kind];if(state.used.length>=pool.length)state.used=[];
   let available=pool.map((_,i)=>i).filter(i=>!state.used.includes(i)&&i!==state.last);
   if(!available.length){state.used=[];available=pool.map((_,i)=>i).filter(i=>i!==state.last)}
   const n=Number(random());index=available[Math.min(available.length-1,Math.max(0,Math.floor((Number.isFinite(n)?n:0)*available.length)))];state.used.push(index);state.last=index;
  }
  return {rotation:next,message:{kind:comparison.kind,index,compared:comparison.compared}};
 }
 function messageFor(record){const m=record?.mascotMessage;if(!m)return null;const pool=Object.hasOwn(phrases,m.kind)?phrases[m.kind]:null;const text=pool&&Number.isInteger(m.index)?pool[m.index]:Object.hasOwn(neutral,m.kind)?neutral[m.kind]:null;return typeof text==='string'?{kind:m.kind,text}:null}
 global.APWorkoutMotivation=Object.freeze({phrases,complete,compare,prepare,readRotation,messageFor});
})(globalThis);
