let googlePending = null, googleAttempt = 0, googleBusy = false;

function googleStatus(message) {
    const status = document.getElementById('apGoogleStatus');
    if (status) { status.textContent = message; status.hidden = !message; }
}

function googleError(error) {
    const messages = {
        'auth/operation-not-allowed': 'O acesso com Google ainda não foi liberado. Entre com e-mail e senha.',
        'auth/popup-closed-by-user': 'Acesso pelo Google cancelado.',
        'auth/cancelled-popup-request': 'Acesso pelo Google cancelado.',
        'auth/popup-blocked': 'Permita a janela de acesso Google no navegador e tente novamente.',
        'auth/unauthorized-domain': 'O acesso Google ainda não foi liberado neste endereço.',
        'auth/account-exists-with-different-credential': 'Entre com o e-mail e a senha que você já usa nesta agenda.',
        'auth/invalid-credential': 'Não foi possível confirmar o acesso Google. Tente novamente.',
        'auth/network-request-failed': 'Não foi possível conectar. Confira sua internet e tente novamente.',
        'native/update-required': 'Instale a nova versão Android do aplicativo para entrar com Google.',
        'native/no-google-account': 'Adicione uma conta Google ao celular e tente novamente.',
        'native/provider-unavailable': 'Confira se o Google Play Services está disponível e atualizado neste celular.',
        'native/google-configuration': 'O acesso Google precisa ser configurado pelo responsável pelo aplicativo.',
        'native/google-sign-in-failed': 'Não foi possível concluir o acesso Google. Tente novamente ou entre com e-mail e senha.',
        'native/timeout': 'O tempo para entrar com Google terminou. Tente novamente.'
    };
    return messages[error?.code] || (String(error?.code || '').startsWith('auth/')
        ? 'Não foi possível concluir o acesso Google. Tente novamente ou entre com e-mail e senha.' : v(error));
}

function googleReceive(result) {
    if (!googlePending || result?.requestId !== googlePending.id || googlePending.attempt !== googleAttempt) return false;
    const pending = googlePending;
    googlePending = null;
    clearTimeout(pending.timer);
    if (typeof result.idToken === 'string' && result.idToken.length > 0 && result.idToken.length <= 65536)
        pending.resolve(result.idToken);
    else pending.reject(Object.assign(Error('Google access failed'), {code: result?.code || 'auth/invalid-credential'}));
    return true;
}

function googleCancel() {
    if (!googleBusy) return;
    googleAttempt++;
    if (googlePending) {
        const pending = googlePending;
        googlePending = null;
        clearTimeout(pending.timer);
        try { window.Android?.cancelGoogleSignIn?.(pending.id); } catch (_) {}
        pending.reject(Object.assign(Error('Google access cancelled'), {code: 'auth/popup-closed-by-user'}));
    }
}

function googleNativeToken(attempt) {
    if (window.Android?.getGoogleSignInVersion?.() !== 1 || typeof window.Android.beginGoogleSignIn !== 'function')
        return Promise.reject(Object.assign(Error('Android update required'), {code: 'native/update-required'}));
    const bytes = new Uint8Array(24);
    window.crypto.getRandomValues(bytes);
    const id = Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
    return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
            if (googlePending?.id !== id) return;
            googlePending = null;
            try { window.Android.cancelGoogleSignIn(id); } catch (_) {}
            reject(Object.assign(Error('Google access timed out'), {code: 'native/timeout'}));
        }, 90000);
        googlePending = {id, attempt, resolve, reject, timer};
        try { window.Android.beginGoogleSignIn(id); }
        catch (error) { googlePending = null; clearTimeout(timer); reject(error); }
    });
}

async function googleLogin() {
    if (u || c || s || googleBusy) return false;
    u = true;
    googleBusy = true;
    const attempt = ++googleAttempt;
    const button = document.getElementById('apGoogleAccess');
    if (button) button.disabled = true;
    googleStatus('Abrindo acesso Google…');
    let outcome = null;
    try {
        await I();
        if (attempt !== googleAttempt) return false;
        await window.APLoginSession.configure(r, document.getElementById('remember')?.checked === true);
        if (attempt !== googleAttempt) return false;
        if (window.Android) {
            const token = await googleNativeToken(attempt);
            if (attempt !== googleAttempt) return false;
            outcome = await r.signInWithCredential(r.auth, r.GoogleAuthProvider.credential(token));
        } else {
            const provider = new r.GoogleAuthProvider();
            provider.setCustomParameters({prompt: 'select_account'});
            outcome = await r.signInWithPopup(r.auth, provider, r.browserPopupRedirectResolver);
        }
        if (attempt !== googleAttempt) {
            if (!s && r.auth.currentUser?.uid === outcome.user.uid) await r.signOut(r.auth);
            return false;
        }
        // Reuse the existing exact UID, professor ownership and student approval checks.
        await N(outcome.user, '');
        if (attempt !== googleAttempt) {
            if (!s && r.auth.currentUser?.uid === outcome.user.uid) await r.signOut(r.auth);
            return false;
        }
        if (s?.uid !== outcome.user.uid) throw Error('Não foi possível abrir esta conta. Tente novamente.');
        googleStatus('');
        document.getElementById('password').value = '';
        return true;
    } catch (error) {
        if (outcome && !s && r.auth.currentUser?.uid === outcome.user.uid) {
            try { await r.signOut(r.auth); } catch (_) {}
        }
        if (attempt === googleAttempt) googleStatus(googleError(error));
        return false;
    } finally {
        if (!s) window.APstartup.finish();
        googleBusy = false;
        u = false;
        if (button) button.disabled = false;
    }
}
