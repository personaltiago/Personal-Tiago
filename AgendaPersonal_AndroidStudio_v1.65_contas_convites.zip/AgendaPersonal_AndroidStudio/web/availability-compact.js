// Seven weekday summaries. Availability still comes from the dated occurrence
// engine; recurring lessons are never inferred from their first saved date.
const compactAvailabilitySelected=new Map();
function compactAvailabilityDate(date,range){
 const busy=availabilitySlotConflicts(date,range.start,range.end),free=freeAttendanceWindows(date,range.start,range.end),usable=free.filter(w=>w.end-w.start>=range.duration);
 return {date,busy,free,usable,kind:busy.length?(usable.length?'partial':'busy'):usable.length?'free':'outside'};
}
function compactAvailabilityIntersection(left,right){
 return mergeAvailabilityIntervals(left.flatMap(a=>right.map(b=>({start:Math.max(a.start,b.start),end:Math.min(a.end,b.end)}))).filter(w=>w.end>w.start));
}
function compactAvailabilityMonth(month,range){
 const period=availabilityMonthRange(month),today=iso(new Date()),historical=month<today.slice(0,7),dates=[];
 if(!period)return {month,range,groups:[],historical,dates};
 const base=parseDate(period.from);
 for(let i=0;i<period.daysCount;i++){const d=new Date(base);d.setDate(base.getDate()+i);const date=iso(d);if(historical||date>=today)dates.push(compactAvailabilityDate(date,range))}
 const groups=[0,1,2,3,4,5,6].map(day=>{
  const rows=dates.filter(r=>parseDate(r.date).getDay()===day);
  let common=rows.length?[{start:timeToMinutes(range.start),end:timeToMinutes(range.end)}]:[];
  for(const row of rows)common=compactAvailabilityIntersection(common,row.free);
  common=common.filter(w=>w.end-w.start>=range.duration);
  const patterns=new Set(rows.map(r=>JSON.stringify(r.free))),varies=patterns.size>1;
  const full=common.length===1&&common[0].start===timeToMinutes(range.start)&&common[0].end===timeToMinutes(range.end);
  const kind=!rows.length?'none':varies?'mixed':full?'free':common.length?'partial':rows.some(r=>r.busy.length)?'busy':'outside';
  const occupied=new Map();for(const row of rows)for(const item of row.busy){const key=item.lesson.id+'|'+item.start+'|'+item.end;occupied.set(key,item)}
  return {day,rows,common,kind,occupied:[...occupied.values()]};
 });
 return {month,range,period,dates,groups,historical};
}
function compactAvailabilityWindowText(w){return minutesToTime(w.start)+'–'+(w.end===1440?'24:00':minutesToTime(w.end))}
function compactAvailabilityCaption(model){
 const title=parseDate(model.month+'-01').toLocaleDateString('pt-BR',{month:'long',year:'numeric'});
 return `<p class="compact-availability-caption" data-availability-month="${model.month}">${hesc(title.charAt(0).toUpperCase()+title.slice(1))} · ${model.range.start}–${model.range.end}</p><p class="compact-availability-help">${model.historical?'Consulta histórica. Datas passadas não permitem agendamento.':'De hoje ao fim do mês. Livre em todas as datas significa que o mesmo horário cabe em todas as próximas ocorrências desse dia.'}</p>`;
}
function compactAvailabilityDateOptions(group,selected){
 return group.rows.map(row=>`<option value="${row.date}"${row.date===selected?' selected':''}>${fmtDate(row.date)} · ${{free:'Livre',partial:'Parcialmente ocupado',busy:'Ocupado',outside:'Sem encaixe'}[row.kind]}</option>`).join('');
}
function compactAvailabilityBlocks(row,range){
 const today=iso(new Date()),now=new Date(),nowMinutes=now.getHours()*60+now.getMinutes();
 const events=[...row.busy.map(item=>({kind:'busy',start:item.start,item})),...row.free.map(window=>({kind:'free',start:window.start,window}))].sort((a,b)=>a.start-b.start);
 const lines=events.map(event=>{
  if(event.kind==='busy'){
   const item=event.item,end=item.end>1440?minutesToTime(item.end-1440)+' do dia seguinte':minutesToTime(item.end),name=lessonParticipant(item.lesson)?.name||'Aluno removido';
   return `<button class="compact-availability-busy" type="button" data-lesson-id="${hesc(item.lesson.id)}" data-class-date="${hesc(item.date)}" onclick="openDashboardOccurrence(this.dataset.lessonId,this.dataset.classDate)"><strong>OCUPADO · ${minutesToTime(item.start)}–${end}</strong><span>${hesc(name)} · ${hesc(statusLabel(item.status))}${item.overnight?' · continuação da aula anterior':''}</span></button>`;
  }
  const w=event.window,bookStart=row.date===today?Math.max(w.start,Math.ceil(nowMinutes/15)*15):w.start,usable=w.end-w.start>=range.duration,canBook=row.date>=today&&w.end-bookStart>=range.duration;
  return `<div class="compact-availability-free${usable?'':' compact-availability-gap'}" data-free-start="${minutesToTime(w.start)}" data-free-end="${minutesToTime(w.end)}"><strong>${usable?'LIVRE':'INTERVALO CURTO'} · ${compactAvailabilityWindowText(w)}</strong><span>${usable?'Cabe uma aula de '+range.duration+' min':'Não comporta uma aula de '+range.duration+' min'}</span>${canBook?`<button class="btn good" type="button" data-date="${row.date}" data-time="${minutesToTime(bookStart)}" data-duration="${range.duration}" onclick="openCompactAvailabilitySlot(this)">Agendar ${minutesToTime(bookStart)}</button>`:''}</div>`;
 }).join('');
 return `<p class="compact-availability-date-title" data-availability-date="${row.date}" data-slot-status="${row.kind}">${fmtDate(row.date)} · ${attendanceDayName(parseDate(row.date).getDay())}${row.date<today?' · Data passada':''}</p>${lines||'<p class="compact-availability-help">Sem atendimento neste intervalo, conforme os limites salvos.</p>'}`;
}
function renderCompactAvailability(model,view){
 const root=document.getElementById(view==='overview'?'automaticAvailabilityWeek':'availabilityResult'),previous=new Set([...root.querySelectorAll('.compact-availability-day[open]')].filter(n=>n.dataset.month===model.month).map(n=>n.dataset.weekday));
 return model.groups.map(group=>{
  const label={free:'LIVRE',partial:'PARCIALMENTE OCUPADO',busy:'OCUPADO',mixed:'VARIA NO MÊS',outside:'SEM ENCAIXE',none:'SEM PRÓXIMAS DATAS'}[group.kind],key=view+'|'+model.month+'|'+group.day;
  let selected=compactAvailabilitySelected.get(key);if(!group.rows.some(r=>r.date===selected))selected=group.rows[0]?.date;
  const free=group.common.length?'Livre em todas as datas: '+group.common.slice(0,2).map(compactAvailabilityWindowText).join(' · ')+(group.common.length>2?' · +'+(group.common.length-2)+' intervalos':''):group.rows.length?(group.kind==='mixed'?'Nenhum horário comum a todas as datas. Confira a data desejada.':group.kind==='busy'?'Há aula no horário consultado.':'Não cabe uma aula neste intervalo.'):'Sem datas restantes deste dia no mês.';
  const names=group.occupied.slice(0,2).map(item=>hesc(lessonParticipant(item.lesson)?.name||'Aluno removido')+' · '+minutesToTime(item.start)+'–'+(item.end>1440?minutesToTime(item.end-1440)+' (+1 dia)':minutesToTime(item.end))).join('; ')+(group.occupied.length>2?' · +'+(group.occupied.length-2)+' aulas':'');
  return `<details class="compact-availability-day" data-weekday="${group.day}" data-month="${model.month}" data-slot-status="${group.kind}"${previous.has(String(group.day))?' open':''} ontoggle="onCompactAvailabilityToggle(this)"><summary><span><strong>${attendanceDayName(group.day)}</strong><span class="compact-availability-status ${group.kind}">${label} · ${model.range.start}–${model.range.end}</span><small class="compact-availability-common${group.common.length?' free':''}">${hesc(free)}</small>${names?'<small class="compact-availability-owners">'+names+'</small>':''}</span>${uiIcon('chevron')}</summary>${group.rows.length?`<div class="compact-availability-body"><p class="compact-availability-help">${group.rows.length} ${group.rows.length===1?'data conferida':'datas conferidas'} no mês. Escolha uma para ver aulas e agendar.</p><label class="field"><span>Conferir data de ${attendanceDayName(group.day)}</span><select data-key="${key}" data-start="${model.range.start}" data-end="${model.range.end}" data-duration="${model.range.duration}" onchange="selectCompactAvailabilityDate(this)">${compactAvailabilityDateOptions(group,selected)}</select></label><div class="compact-availability-selected">${compactAvailabilityBlocks(group.rows.find(r=>r.date===selected),model.range)}</div></div>`:''}</details>`;
 }).join('');
}
function onCompactAvailabilityToggle(card){
 if(!card.isConnected||!card.open)return;
 for(const other of card.parentElement.querySelectorAll(':scope>.compact-availability-day'))if(other!==card)other.open=false;
}
function selectCompactAvailabilityDate(select){
 const range={start:select.dataset.start,end:select.dataset.end,duration:Number(select.dataset.duration)};
 if(!validWorkoutDate(select.value)||!availabilityTimeValid(range.start)||!availabilityTimeValid(range.end))return;
 compactAvailabilitySelected.set(select.dataset.key,select.value);
 select.closest('.compact-availability-body').querySelector('.compact-availability-selected').innerHTML=compactAvailabilityBlocks(compactAvailabilityDate(select.value,range),range);
}
function openCompactAvailabilitySlot(button){
 const date=button.dataset.date,time=button.dataset.time,duration=Number(button.dataset.duration),end=minutesToTime(timeToMinutes(time)+duration),now=new Date();
 if(!validWorkoutDate(date)||!availabilityTimeValid(time)||!Number.isFinite(duration)||duration<=0||date<iso(now)||date===iso(now)&&timeToMinutes(time)<now.getHours()*60+now.getMinutes()||!slotInsideAttendance(date,time,end)||availabilitySlotConflicts(date,time,end).length){toast('Esse horário mudou ou já passou. Confira a disponibilidade novamente.');renderAvailability();return}
 openLessonAt(date,time,duration);
}
function renderAutomaticAvailabilityWeek(){
 const root=document.getElementById('automaticAvailabilityWeek'),month=(automaticAvailabilityWeekAnchor||iso(new Date())).slice(0,7),period=availabilityMonthRange(month),last=parseDate(period.from);last.setDate(period.daysCount);
 document.getElementById('automaticAvailabilityWeekRange').textContent=parseDate(period.from).toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'})+' – '+last.toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit',year:'numeric'});
 document.getElementById('automaticAvailabilityWeekReset').hidden=month===iso(new Date()).slice(0,7);
 const range=automaticAvailabilityRange();document.getElementById('automaticAvailabilityRangeCaption').textContent=range?`${range.start}–${range.end} · aulas de ${range.duration} min`:'Confira o horário da consulta';
 document.getElementById('automaticAvailabilityLimitNotice').hidden=!availabilityLimitsEnabled();
 document.getElementById('automaticAvailabilitySource').textContent=month<iso(new Date()).slice(0,7)?'Consulta histórica; escolha o mês atual para agendar.':'Confere as próximas datas do mês, com repetições, aulas avulsas e cancelamentos.'+(availabilityLimitsEnabled()?' Respeita os limites de atendimento salvos.':'');
 if(!range){document.getElementById('automaticAvailabilityTotals').textContent='';root.innerHTML='<div class="empty"><strong>Confira o horário.</strong>O fim precisa ser depois do início.</div>';return}
 const model=compactAvailabilityMonth(month,range),available=model.groups.filter(g=>g.common.length).length,mixed=model.groups.filter(g=>g.kind==='mixed').length;
 document.getElementById('automaticAvailabilityTotals').textContent=available+' '+(available===1?'dia da semana com horário livre em todas as datas':'dias da semana com horário livre em todas as datas')+(mixed?' · '+mixed+' '+(mixed===1?'varia no mês':'variam no mês'):'');
 root.innerHTML=renderCompactAvailability(model,'overview');root.dataset.weekStart=period.from;
}
