(function(global){
 'use strict';
 const records=new WeakMap(),bound=new WeakSet(),active=new Set(),ns='http://www.w3.org/2000/svg';let serial=0;const gestures=new Set();
 const markOf=node=>node.querySelector('.ap-mascot-mini,.ap-teacher-mascot-mark,.ap-mascot-art');
 async function approved(node,state){
  if(!global.APMascotBear?.supports(state))return null;
  let r=records.get(node);if(r?.kind==='approved'&&preserve(node,state))return r.pending||r;
  cancel(node);const mark=markOf(node);if(!mark)return null;
  r={kind:'approved',mark,state,original:mark.innerHTML,token:1,ready:false,held:false,turn:0,lastHeart:0,hearts:0,timer:0,reduced:false};records.set(node,r);active.add(node);
  r.pending=(async()=>{try{await global.APMascotArt.load();const image=mark.querySelector('image');if(records.get(node)!==r)return null;if(!image)throw Error('image');r.original=mark.innerHTML;const motion=await global.APMascotBear.start(image,state);if(records.get(node)!==r){motion?.dispose();return null}if(!motion)throw Error('bear');r.motion=motion;r.asset=global.APMascotBear.asset(state);r.ready=true;node.dataset.petAffection='true';return r}catch(_){if(records.get(node)===r)cancel(node);return null}finally{r.pending=null}})();return r.pending;
 }
 const heart='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21C9 18.5 3 14.5 3 9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 5.5-6 9.5-9 12Z"/></svg>';
 function cancel(node){
  const r=records.get(node);if(!r)return;clearTimeout(r.timer);clearTimeout(r.hearts);r.motion?.dispose();r.token++;active.delete(node);records.delete(node);
  const mark=markOf(node);delete node.dataset.petAffection;delete node.dataset.petReaction;
  if(mark===r.mark){mark.innerHTML=r.original;global.APMascotHomes?.decorate(node,r.state)}
  node.querySelectorAll('.ap-pet-heart').forEach(n=>n.remove());
 }
 function fade(image,from,to,duration){
  image.querySelectorAll('animate[attributeName="opacity"]').forEach(n=>n.remove());
  const a=image.ownerDocument.createElementNS(ns,'animate');for(const [k,v]of Object.entries({attributeName:'opacity',from,to,dur:duration+'ms',fill:'freeze'}))a.setAttribute(k,v);image.append(a);a.beginElement?.();
 }
 function finish(node,r){
  if(r.kind==='approved'){r.motion?.release();return}
  if(records.get(node)!==r||r.held)return;
  if(!r.ready||r.reduced||r.localMotion||r.poseOnly){cancel(node);return}
  r.finishing=true;
  const old=r.photo.cloneNode(true);old.setAttribute('opacity','0');old.setAttribute('pointer-events','none');old.setAttribute('data-pet-prior','true');r.image.parentNode.append(old);fade(old,0,1,220);fade(r.image,1,0,220);r.timer=setTimeout(()=>cancel(node),230);
 }
 function settle(node,r,delay=1300){clearTimeout(r.timer);if(!r.held)r.timer=setTimeout(()=>finish(node,r),delay)}
 function pulse(node,r){
  if(!r.ready||records.get(node)!==r||!node.isConnected)return;
  const now=Date.now();if(now-r.lastHeart>550){
   r.lastHeart=now;const mark=r.mark,doc=node.ownerDocument,box=mark.getBoundingClientRect(),scene=node.getBoundingClientRect(),p=doc.createElement('span');p.className='ap-pet-heart';p.setAttribute('aria-hidden','true');p.innerHTML=heart;
   p.style.left=(box.left-scene.left+box.width*r.asset.headX-8)+'px';p.style.top=(box.top-scene.top+box.height*(r.asset.headTop+.16))+'px';p.style.setProperty('--pet-heart-drift',((r.turn++%2?1:-1)*10)+'px');
   const older=node.querySelectorAll('.ap-pet-heart');if(older.length>=3)older[0].remove();node.append(p);setTimeout(()=>p.remove(),1050);
  }
  clearTimeout(r.hearts);if(r.held)r.hearts=setTimeout(()=>pulse(node,r),700);
 }
 function articulate(image,r){
  // The displacement field moves the head as a unit and blends through the neck.
  // The lower body, paws, sprite container and habitat have zero displacement.
  const id='ap-pet-neck-'+(++serial),x=Math.round(r.asset.headX*320),neck=r.state.species==='alligator'?190:178;
  const map='<svg xmlns="'+ns+'" width="320" height="320"><defs><linearGradient id="v" x2="0" y2="1"><stop offset="0" stop-color="#800080"/><stop offset="'+((neck-42)/320)+'" stop-color="#800080"/><stop offset="'+(neck/320)+'" stop-color="#808080"/></linearGradient><linearGradient id="h"><stop stop-color="black"/><stop offset=".27" stop-color="white"/><stop offset=".73" stop-color="white"/><stop offset="1" stop-color="black"/></linearGradient><mask id="m"><rect x="'+(x-108)+'" width="216" height="320" fill="url(#h)"/></mask></defs><path fill="#808080" d="M0 0h320v320H0z"/><path fill="url(#v)" mask="url(#m)" d="M0 0h320v320H0z"/></svg>';
  const defs=image.ownerDocument.createElementNS(ns,'defs');defs.innerHTML='<filter id="'+id+'" filterUnits="userSpaceOnUse" x="-12" y="-12" width="344" height="344" color-interpolation-filters="sRGB"><feImage x="0" y="0" width="320" height="320" href="data:image/svg+xml;base64,'+btoa(map)+'" result="neck"/><feDisplacementMap in="SourceGraphic" in2="neck" scale="0" xChannelSelector="R" yChannelSelector="G"><animate attributeName="scale" values="0;8;11;7;0" keyTimes="0;.28;.55;.78;1" dur="1.65s" repeatCount="indefinite" calcMode="spline" keySplines=".3 0 .3 1;.4 0 .6 1;.4 0 .6 1;.3 0 .6 1"/></feDisplacementMap></filter>';
  image.ownerSVGElement.prepend(defs);image.setAttribute('filter','url(#'+id+')');defs.querySelector('animate').beginElement?.();
 }
 async function bearPose(node,state,kind,zone,held=false){
  const prior=records.get(node);
  if(prior?.poseLocal&&prior.kind===(kind==='affection'?'petting':kind)&&preserve(node,state)){
   if(kind==='affection'){prior.held=held;if(held)prior.motion?.hold();settle(node,prior,prior.motion?.duration||2200);pulse(node,prior)}
   else if(kind==='look'&&prior.motion){clearTimeout(prior.timer);prior.timer=setTimeout(()=>finish(node,prior),prior.motion.retarget(zone)+24)}
   return prior.pending||true;
  }
  cancel(node);const mark=markOf(node),image=mark?.querySelector('image'),svg=mark?.querySelector('svg');if(!image||!svg)return false;
  const r={kind:kind==='affection'?'petting':kind,poseLocal:true,localMotion:true,mark,state,original:mark.innerHTML,token:1,held,ready:false,timer:0,hearts:0,lastHeart:0,turn:0,reduced:global.matchMedia?.('(prefers-reduced-motion:reduce)').matches===true};records.set(node,r);active.add(node);
  r.pending=(async()=>{try{const motion=await global.APMascotBearPoses.start(image,state,kind,zone,r.reduced,held);if(records.get(node)!==r||!node.isConnected){motion?.dispose();return false}if(!motion)throw Error('bear pose');r.motion=motion;const size=global.APMascotArt.scale(state),hx=motion.profile.head[0]/320,top=Math.max(0,(motion.profile.head[1]-motion.profile.head[3])/320);r.asset={headX:(1-size)/2+(global.APMascotArt.mirrored(state)?1-hx:hx)*size,headTop:1-size+(top+.16)*size-.16};r.ready=true;node.dataset.petAffection='true';node.dataset.petReaction=kind;
   const message=kind==='affection'?'gostou do carinho.':kind==='look'?'olhou para o ponto tocado no cenário.':kind==='curious'?'inclinou a cabeça com curiosidade.':kind==='ear'?'mexeu a orelhinha.':kind==='nose'?'farejou o toque.':'protestou e fechou a cara.';svg.setAttribute('aria-label',state.name+' '+message);announce(node,state.name+' '+message);if(kind==='affection')pulse(node,r);const settling=kind==='affection'&&held&&!r.held?motion.release():motion.duration;settle(node,r,settling+24);return true;
  }catch(_){if(records.get(node)===r)cancel(node);return false}finally{r.pending=null}})();return r.pending;
 }
 async function react(node,state,held=false){
  if(global.APMascotBear?.supports(state)){const r=await approved(node,state);if(r){r.held=held;r.motion.act('affection',.2,0,held);pulse(node,r);announce(node,state.name+' gostou do carinho.');return true}}
  if(global.APMascotBearPoses?.supports(state))return bearPose(node,state,'affection',null,held);
  const mark=markOf(node);if(!mark||!state?.species||!node.isConnected)return false;
  let r=records.get(node);if(r&&(r.kind!=='petting'||r.finishing)){cancel(node);r=null}if(r&&(r.mark!==mark||r.state.species!==state.species||r.state.xp!==state.xp||r.reduced!==(global.matchMedia?.('(prefers-reduced-motion:reduce)').matches===true)||global.APMascotModel.color(r.state).id!==global.APMascotModel.color(state).id)){cancel(node);r=null}
  if(r){r.held=held;settle(node,r);pulse(node,r);return r.pending||true}
  r={kind:'petting',mark,state,original:mark.innerHTML,token:1,turn:0,timer:0,hearts:0,lastHeart:0,held,ready:false,reduced:global.APMascotBear?.supports(state)||global.matchMedia?.('(prefers-reduced-motion:reduce)').matches===true};records.set(node,r);active.add(node);
  r.pending=(async()=>{try{
   if(!await global.APMascotArt.load())throw Error('art');const asset=global.APMascotArt.affection(state);if(!asset)throw Error('frame');const picture=new Image();picture.src=asset.uri;await picture.decode();
   if(records.get(node)!==r||r.token!==1||!node.isConnected||markOf(node)!==mark){if(records.get(node)===r)cancel(node);return false}
   let image=mark.querySelector('image'),svg=mark.querySelector('svg');if(!image||!svg){mark.innerHTML=global.APMascotArt.renderAffection(state);image=mark.querySelector('image');svg=mark.querySelector('svg')}
   r.photo=image.cloneNode(true);r.image=image;r.asset=asset;image.setAttribute('href',asset.uri);image.removeAttribute('transform');svg.dataset.mascotPose='petting';svg.setAttribute('aria-label',state.name+', recebendo carinho');
   node.dataset.petAffection='true';global.APMascotHomes.decorate(node,state,asset);
   if(!r.reduced){articulate(image,r);const old=r.photo.cloneNode(true);old.setAttribute('pointer-events','none');old.setAttribute('data-pet-prior','true');image.parentNode.append(old);fade(old,1,0,180);fade(image,0,1,180);setTimeout(()=>old.remove(),200)}
   r.ready=true;pulse(node,r);let status=node.querySelector('.ap-pet-touch-status');if(!status){status=node.ownerDocument.createElement('span');status.className='ap-pet-touch-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');node.append(status)}status.textContent=state.name+' gostou do carinho.';settle(node,r);return true;
  }catch(_){if(records.get(node)===r)cancel(node);return false}finally{r.pending=null}})();return r.pending;
 }
 function announce(node,text){let status=node.querySelector('.ap-pet-touch-status');if(!status){status=node.ownerDocument.createElement('span');status.className='ap-pet-touch-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');node.append(status)}status.textContent=text}
 async function respond(node,state,kind,zone){
  if(global.APMascotBear?.supports(state)){const r=await approved(node,state);if(r){r.held=false;clearTimeout(r.hearts);node.querySelectorAll('.ap-pet-heart').forEach(h=>h.remove());const action=kind==='paw'||kind==='tail'?'angry':kind;if(kind==='look'&&zone){const matrix=r.motion.image.getScreenCTM(),q=new DOMPoint(zone.x*320,zone.y*320).matrixTransform(matrix);r.motion.actAtScreen(action,q.x,q.y)}else r.motion.act(action,zone?.x??.3,zone?.y??.1);announce(node,state.name+' '+(action==='angry'?'protestou.':action==='look'?'olhou para o ponto tocado.':'reagiu ao toque.'));return true}}
  if(global.APMascotBearPoses?.supports(state))return bearPose(node,state,kind,zone);
  if(!node.isConnected||!state?.species)return false;const prior=records.get(node);if(prior?.kind===kind&&(prior.localMotion||prior.poseOnly)&&preserve(node,state)){if(kind==='look'&&prior.motion){clearTimeout(prior.timer);prior.timer=setTimeout(()=>finish(node,prior),prior.motion.retarget(zone)+24)}return true}cancel(node);const mark=markOf(node),image=mark?.querySelector('image'),svg=mark?.querySelector('svg');if(!image||!svg)return false;
  const r={kind,mark,state,original:mark.innerHTML,photo:image.cloneNode(true),image,token:1,held:false,ready:false,timer:0,hearts:0,reduced:global.APMascotBear?.supports(state)||global.matchMedia?.('(prefers-reduced-motion:reduce)').matches===true};records.set(node,r);active.add(node);node.dataset.petAffection='true';
  try{
   const protest=kind==='paw'||kind==='tail';let asset=null;
   if(protest){await global.APMascotArt.load();asset=global.APMascotArt.reaction(state);if(!asset)throw Error('frame');const picture=new Image();picture.src=asset.uri;await picture.decode();if(records.get(node)!==r||!node.isConnected)return false;image.setAttribute('href',asset.uri);image.removeAttribute('transform');global.APMascotHomes.decorate(node,state,asset);svg.dataset.mascotPose='reaction'}
   if(records.get(node)!==r)return false;node.dataset.petAffection='true';node.dataset.petReaction=kind;r.ready=true;
   const message=kind==='ear'?'mexeu a orelhinha.':kind==='nose'?'farejou o toque.':kind==='look'?'olhou para o ponto tocado no cenário.':kind==='curious'?'inclinou a cabeça com curiosidade.':kind==='tail'?'protestou ao toque no rabinho.':state.species==='rooster'?'protestou e levantou a asa.':'protestou e levantou a patinha.';announce(node,state.name+' '+message);svg.setAttribute('aria-label',state.name+' '+message);
   if(protest){r.poseOnly=true;r.timer=setTimeout(()=>finish(node,r),global.APMascotBear?.attentionSupports(state)?2800:1050)}
   else{const motion=await(global.APMascotBear?.attentionSupports(state)?global.APMascotBear.attention(image,state,kind,zone,r.reduced):global.APMascotCuriosityMotion.start(image,state,kind,zone,r.reduced));if(records.get(node)!==r){motion?.dispose();return false}if(!motion)throw Error('motion');r.motion=motion;r.localMotion=true;r.timer=setTimeout(()=>finish(node,r),motion.duration+24)}return true;
  }catch(_){if(records.get(node)===r)cancel(node);return false}
 }
 function bind(node,read,allowed=()=>true){
  if(!node)return;if(allowed()&&global.APMascotBear?.supports(read()))approved(node,read());if(bound.has(node))return;bound.add(node);for(const item of gestures)if(!item.node.isConnected)gestures.delete(item);
  let down=null,tap=null,timer=0,epoch=0,last=0,lastTouch=-Infinity,contact=0;
  const clearTap=()=>{clearTimeout(timer);timer=0;tap=null};
  function reset(){epoch++;clearTap();if(down){const d=down;down=null;try{d.mark.releasePointerCapture(d.id)}catch(_){}}const r=records.get(node);if((r?.kind==='petting'||r?.kind==='approved')){r.held=false;clearTimeout(r.hearts);if(r.kind==='approved')r.motion?.release();else settle(node,r,r.poseLocal?r.motion?.release()||650:650)}}
  gestures.add({node,reset});
  node.addEventListener('pointerdown',e=>{
   const type=e.pointerType||'mouse',now=Date.now();if(type==='mouse'&&(e.sourceCapabilities?.firesTouchEvents||now-lastTouch<750))return;if(type==='touch')lastTouch=now;if(e.target.closest('.ap-habitat-house,.ap-mascot-speech,.ap-mascot-home-copy strong,.ap-teacher-mascot-copy strong,a,input,textarea,select,[data-mascot-retry],.ap-feedback-pet-notice,.ap-mascot-phase,.ap-mascot-balance,.ap-mascot-gear,.ap-mascot-home-name,#apMascotReaction')||down||e.isPrimary===false||e.button!==0||!allowed())return;const mark=e.target.closest('.ap-mascot-mini,.ap-teacher-mascot-mark,.ap-mascot-art'),state=read();if(!state?.species||!markOf(node))return;
   const d={id:e.pointerId,type,contact:++contact,x:e.clientX,y:e.clientY,at:Date.now(),mark,state,epoch,stroke:false,last:0};d.hit=mark?global.APMascotHitAreas.hit(node,state,d.x,d.y,type==='touch'?5:0):Promise.resolve(null);down=d;last=Date.now();try{mark?.setPointerCapture(d.id)}catch(_){}
  },{passive:true});
  node.addEventListener('pointermove',e=>{
   const d=down;if(!d||d.id!==e.pointerId||!allowed())return;if(!d.stroke&&Math.hypot(e.clientX-d.x,e.clientY-d.y)>=9){d.stroke=true;clearTap()}
   if(d.stroke&&Date.now()-d.last>=150){d.last=Date.now();d.hit.then(hit=>{if(hit&&down===d&&d.epoch===epoch&&allowed())react(node,read(),true)})}
  },{passive:true});
  node.addEventListener('pointerup',e=>{
   const d=down;if(!d||d.id!==e.pointerId)return;down=null;try{d.mark.releasePointerCapture(d.id)}catch(_){}const upAt=Date.now();last=upAt;
   if(d.stroke){const r=records.get(node);if((r?.kind==='petting'||r?.kind==='approved')){r.held=false;clearTimeout(r.hearts);if(r.kind==='approved')r.motion?.release();else settle(node,r,r.poseLocal?r.motion?.release()||650:650)}return}
   if(upAt-d.at>400||Math.hypot(e.clientX-d.x,e.clientY-d.y)>=9)return;
   d.hit.then(hit=>{if(d.epoch!==epoch||!allowed()||!node.isConnected)return;
    if(!hit){clearTap();const image=node.querySelector('image:not([data-pet-prior])'),matrix=image?.getScreenCTM();if(matrix){let point;try{point=new DOMPoint(d.x,d.y).matrixTransform(matrix.inverse())}catch(_){return}respond(node,read(),'look',{x:point.x/320,y:point.y/320})}return}
    if(tap&&tap.contact!==d.contact&&tap.type===d.type&&tap.part===hit.part&&upAt-tap.at>=0&&upAt-tap.at<=280&&Math.hypot(d.x-tap.x,d.y-tap.y)<=24){clearTap();respond(node,read(),'paw');return}
    clearTap();tap={at:upAt,x:d.x,y:d.y,type:d.type,contact:d.contact,part:hit.part};timer=setTimeout(()=>{tap=null;timer=0;if(d.epoch===epoch&&allowed()&&node.isConnected)respond(node,read(),hit.part==='body'?'curious':hit.part,hit.zone||{x:hit.x,y:hit.y})},285);
   });
  },{passive:true});
  const aborted=e=>{if(down?.id===e.pointerId)reset()};node.addEventListener('pointercancel',aborted,{passive:true});node.addEventListener('lostpointercapture',aborted,{passive:true});
  node.addEventListener('click',e=>{if(e.target.closest('.ap-feedback-pet-notice,[data-mascot-retry]'))return;if(e.target.closest('.ap-habitat-house')){reset();cancel(node);return}if(e.detail===0&&Date.now()-last>350&&e.target.closest('.ap-habitat-open')&&allowed())react(node,read())});
 }
 const cancelAll=()=>{for(const item of gestures){item.reset();if(!item.node.isConnected)gestures.delete(item)}[...active].forEach(cancel)};global.addEventListener('ap-account-changed',cancelAll);global.document.addEventListener('visibilitychange',()=>{if(global.document.hidden)cancelAll()});
 function preserve(node,state){const r=records.get(node);return !!r&&(r.kind!=='approved'||!!r.pending||r.motion?.alive())&&r.mark.isConnected&&r.state.species===state.species&&global.APMascotModel.phase(r.state.xp).id===global.APMascotModel.phase(state.xp).id&&global.APMascotModel.color(r.state).id===global.APMascotModel.color(state).id&&global.APMascotModel.pose(r.state).id===global.APMascotModel.pose(state).id}
 global.APMascotPetting=Object.freeze({gestures:true,bind,react,respond,preserve,cancel,cancelAll});
})(globalThis);
