  function separateIndividualReportPages(d) {
    const original=[...reportContent.children].filter(node=>node.matches('.sheet'));
    const summary=original[0],measures=original[1];
    if(!summary||!measures)return;
    const sections=[...summary.children].filter(node=>node.matches('.report-section'));
    const measureSections=[...measures.children].filter(node=>node.matches('.report-section'));
    if(sections.length<2||measureSections.length!==3)throw new Error('Não foi possível organizar as páginas da avaliação.');
    const create=(kind,label,title,subtitle)=>{
      const sheet=document.createElement('article');sheet.className='sheet individual-sheet individual-'+kind;
      sheet.dataset.individualPage=kind;
      sheet.innerHTML=header(d,label)+'<p class="report-kicker">'+escapeHTML(d.clientName)+' · '+dateLabel(d.date)+'</p><h1 class="report-title">'+title+'</h1>'+(subtitle?'<p class="report-subtitle">'+subtitle+'</p>':'');
      return sheet;
    };
    summary.classList.add('individual-sheet','individual-composition');summary.dataset.individualPage='composition';
    const indicators=create('indicators','INDICADORES','Leitura dos indicadores.','Peso, proporções e referências da avaliação.');
    indicators.appendChild(sections[0]);
    const perimeters=create('perimeters','PERÍMETROS CORPORAIS','Perímetros corporais.','Medidas em centímetros, organizadas por região.');
    perimeters.appendChild(measureSections[0]);
    const foldsPage=create('folds','DOBRAS CUTÂNEAS','As sete dobras cutâneas.','Leitura individual de cada ponto medido, em milímetros.');
    foldsPage.appendChild(measureSections[1]);
    const method=create('method','MÉTODO E REFERÊNCIAS','Método e referências.','Como os resultados desta avaliação foram calculados.');
    method.appendChild(measureSections[2]);
    const pages=[summary,indicators,perimeters,foldsPage,method];
    // Keep any existing comparison summary on its own page as well.
    for(const section of sections.slice(2)){
      const evolution=create('evolution','EVOLUÇÃO','Evolução da avaliação.','Comparação com os registros anteriores.');
      evolution.appendChild(section);pages.push(evolution);
    }
    for(const page of original.slice(2))pages.push(page);
    for(const page of pages)page.querySelectorAll('.sheet-footer').forEach(node=>node.remove());
    for(const [index,page]of pages.entries())page.insertAdjacentHTML('beforeend',footer(d,index+1,pages.length));
    reportContent.replaceChildren(...pages);
  }
