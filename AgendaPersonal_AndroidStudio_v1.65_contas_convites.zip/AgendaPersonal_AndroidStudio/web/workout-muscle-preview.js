(function(global){
 'use strict';
 const labels={glutes:'Glúteos',back:'Costas',quads:'Quadríceps',hamstrings:'Posteriores de coxa',calves:'Panturrilhas',chest:'Peitoral',shoulders:'Ombros',biceps:'Bíceps',triceps:'Tríceps',abs:'Abdômen',adductors:'Adutores',forearms:'Antebraços'};
 const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 function groups(text){
  const s=normalize(text),out=[];
  for(const [key,re]of Object.entries({glutes:/glute|gluteal/,back:/costas|dorsal|dorsais|trapezio|lombar/,quads:/quadriceps|quadricep|anterior(?:es)? (?:da |de )?coxa/,hamstrings:/posterior(?:es)? (?:da |de )?coxa|isquio|femora/,calves:/panturrilh|gastrocnemio|soleo/,chest:/peit(?:o|oral)|pector/,shoulders:/ombro|deltoid/,biceps:/biceps/,triceps:/triceps/,abs:/abdom|core/,adductors:/adutor/,forearms:/antebraco/}))if(re.test(s))out.push(key);
  if(/corpo (?:todo|inteiro)|full.?body/.test(s))return Object.keys(labels);
  if(/superiores/.test(s))out.push('chest','back','shoulders','biceps','triceps');
  if(/inferiores|\bpernas?\b/.test(s)&&!out.some(k=>['glutes','quads','hamstrings','calves','adductors'].includes(k)))out.push('glutes','quads','hamstrings','calves');
  return [...new Set(out)];
 }
 function identify(workout){
  // An explicit day title describes the card. Generic A/B titles fall back to
  // the actual muscle metadata, then to an explicit plan title, never to demos.
  const named=groups(workout?.label||workout?.name);
  if(named.length)return named;
  const prescribed=groups((workout?.exercises||[]).map(e=>e.muscles||'').join(' '));
  return prescribed.length?prescribed:groups(workout?.planName);
 }
 const aliases={back:['upper_back','lats','lower_back'],abs:['abs','obliques']};
 function render(workout){
  const active=identify(workout),mapped=[...new Set(active.flatMap(key=>aliases[key]||[key]))];
  const gender=typeof currentProfileGender==='function'&&currentProfileGender()==='Masculino'?'male':'female';
  const data=global.APWorkoutMuscleArt;
  const rear=active.some(k=>['glutes','back','hamstrings','triceps'].includes(k)),anterior=active.some(k=>['chest','quads','biceps','abs','adductors'].includes(k));
  const views=rear&&anterior?['front','back']:[rear?'back':'front'];
  const title=active.length?'Grupos musculares: '+active.map(k=>labels[k]).join(', '):'Grupo muscular não informado';
  const panels=views.map(side=>{
   const masks=data.masks.filter(m=>m.gender===gender&&m.view===side&&mapped.includes(m.group));
   let crop='60 15 242 520';
   if(masks.length&&active.length<6){
    const x1=Math.min(...masks.map(m=>m.bounds[0])),y1=Math.min(...masks.map(m=>m.bounds[1]));
    const x2=Math.max(...masks.map(m=>m.bounds[0]+m.bounds[2])),y2=Math.max(...masks.map(m=>m.bounds[1]+m.bounds[3]));
    const w=Math.min(330,Math.max(145,(x2-x1)+50)),h=Math.min(520,Math.max(170,(y2-y1)+65));
    crop=[Math.max(0,Math.min(361-w,(x1+x2-w)/2)),Math.max(0,Math.min(542-h,(y1+y2-h)/2)),w,h].join(' ');
   }
   return '<svg viewBox="'+crop+'" aria-hidden="true" focusable="false" data-body-gender="'+gender+'" data-body-side="'+side+'" style="isolation:isolate"><image href="'+data.images[gender+'-'+side]+'" x="0" y="0" width="361.15625" height="541.86667"/>'+masks.map(m=>'<path class="ap-muscle-highlight" data-muscle="'+m.group+'" transform="translate('+m.x+' '+m.y+')" d="'+m.d+'"/>').join('')+'</svg>';
  });
  return '<span class="ap-muscle-preview" role="img" aria-label="'+title+'">'+panels.join('')+'</span>';
 }
 global.APWorkoutMuscles=Object.freeze({identify,render});
})(globalThis);
