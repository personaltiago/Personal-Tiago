(function(global){
 'use strict';
 const labels={glutes:'Glúteos',back:'Costas',quads:'Quadríceps',hamstrings:'Posteriores de coxa',calves:'Panturrilhas',chest:'Peitoral',shoulders:'Ombros',biceps:'Bíceps',triceps:'Tríceps',abs:'Abdômen',adductors:'Adutores',forearms:'Antebraços'};
 const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 function groups(text){
  const s=normalize(text),out=[];
  for(const [key,re]of Object.entries({glutes:/glute|gluteal/,back:/costas|dorsal|dorsais|trapezio|lombar/,quads:/quadriceps|quadricep|anterior(?:es)? (?:da |de )?coxa/,hamstrings:/posterior(?:es)? (?:da |de )?coxa|isquio|femora/,calves:/panturrilh|gastrocnemio|soleo/,chest:/peit(?:o|oral)|pector/,shoulders:/ombro|deltoid/,biceps:/biceps/,triceps:/triceps/,abs:/abdom|core/,adductors:/adutor/,forearms:/antebraco/}))if(re.test(s))out.push(key);
  if(/corpo (?:todo|inteiro)|full.?body/.test(s))return Object.keys(labels);
  if(/superiores/.test(s))out.push('chest','back','shoulders','biceps','triceps');
  if(/inferiores|\bpernas?\b/.test(s)&&!out.some(k=>['glutes','quads','hamstrings','calves','adductors'].includes(k)))out.push('glutes','quads','hamstrings','calves');
  return [...new Set(out)];
 }
 function identify(workout){
  // An explicit day title describes the card. Generic A/B titles fall back to
  // the actual muscle metadata, then to an explicit plan title, never to demos.
  const named=groups(workout?.label||workout?.name);
  if(named.length)return named;
  const prescribed=groups((workout?.exercises||[]).map(e=>e.muscles||'').join(' '));
  return prescribed.length?prescribed:groups(workout?.planName);
 }
 const outline='M53 22L53 27Q49 30 42 31Q34 32 31 38L27 58L24 78L21 92Q20 98 24 99Q27 99 28 94L33 80L37 62L40 49L42 67L40 86Q38 95 39 106L43 135L44 161L42 181Q41 185 47 185L53 184L54 162L56 140L59 111L61 111L64 140L66 162L67 184L73 185Q79 185 78 181L76 161L77 135L81 106Q82 95 80 86L78 67L80 49L83 62L87 80L92 94Q93 99 96 99Q100 98 99 92L96 78L93 58L89 38Q86 32 78 31Q71 30 67 27L67 22';
 const front={
  shoulders:['M42 33Q33 33 32 47L39 49L46 37Z'],
  chest:['M47 35L58 37L58 51Q49 55 42 49L43 40Z'],
  biceps:['M33 50L39 52L35 66L30 65Z'],
  forearms:['M29 68L34 69L29 83L25 89Z'],
  abs:['M53 55L59 55L59 63L52 63Z','M52 66L59 66L59 74L52 74Z','M53 77L59 77L59 86L55 84Z'],
  adductors:['M54 99L59 106L55 126L52 120Z'],
  quads:['M43 99Q46 96 50 99L52 123L50 136L45 133Z'],
  calves:['M46 142L52 141L50 160L47 168L45 158Z']
 };
 const back={
  shoulders:['M42 33Q33 33 32 47L39 49L47 38Z'],
  back:['M54 29L59 32L59 55L46 40Z','M43 44L57 57L57 77L50 85L44 67Z'],
  triceps:['M33 50L39 52L35 66L30 65Z'],
  forearms:['M29 68L34 69L29 83L25 89Z'],
  glutes:['M43 85Q48 82 58 87L59 100Q52 108 42 102Q39 95 43 85Z'],
  hamstrings:['M43 108Q48 110 54 105L53 125L49 136L45 134Z'],
  calves:['M45 141Q49 138 52 142L51 155L47 164L44 157Z']
 };
 function body(side,active){
  let svg='<g class="ap-muscle-body"><ellipse cx="60" cy="14" rx="9" ry="11"/><path d="'+outline+'Z"/></g>';
  for(const [key,paths]of Object.entries(side==='back'?back:front)){
   const cls=active.includes(key)?'ap-muscle-on':'ap-muscle-off';
   const shape=paths.map(d=>'<path d="'+d+'"/>').join('');
   svg+='<g class="'+cls+'" data-muscle="'+key+'">'+shape+'<g transform="translate(120 0) scale(-1 1)">'+shape+'</g></g>';
  }
  svg+='<path class="ap-muscle-detail" d="'+(side==='back'?'M60 32V81M60 88V101':'M60 36V52M46 56L49 78M74 56L71 78')+'"/>';
  return svg;
 }
 function render(workout){
  const active=identify(workout),rear=active.some(k=>['glutes','back','hamstrings','triceps'].includes(k)),anterior=active.some(k=>['chest','quads','biceps','abs','adductors'].includes(k));
  const both=rear&&anterior,side=rear?'back':'front';
  const upper=active.length&&active.every(k=>['chest','back','shoulders','biceps','triceps','forearms','abs'].includes(k));
  const lower=active.length&&active.every(k=>['glutes','quads','hamstrings','calves','adductors'].includes(k));
  const crop=upper?'16 23 88 82':lower?'25 79 70 109':'16 0 88 190';
  const title=active.length?'Grupos musculares: '+active.map(k=>labels[k]).join(', '):'Grupos musculares não informados';
  const panel=(s,x,w)=>'<svg x="'+x+'" y="0" width="'+w+'" height="110" viewBox="'+crop+'">'+body(s,active)+'</svg>';
  return '<span class="ap-muscle-preview" role="img" aria-label="'+title+'"><svg viewBox="0 0 120 110" aria-hidden="true" focusable="false">'+(both?panel('front',0,60)+panel('back',60,60):panel(side,0,120))+'</svg></span>';
 }
 global.APWorkoutMuscles=Object.freeze({identify,render});
})(globalThis);
