(function(){
 'use strict';
 const $=id=>document.getElementById(id),safe=htmlSafe;
 const money=cents=>Number.isSafeInteger(cents)?(cents/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}):'Valor não informado';
 let shownDay='';
 function billing(){
  const c=window.__AP_STUDENT_CONTEXT,a=c?.area;
  if(!a||c.role==='student'&&a.studentUid!==c.storageId||c.role!=='student'&&(c.role!=='preview'||!APaccounts.isTeacher()))return null;
  return APBilling.valid(a.billing)&&a.billing.enabled?a.billing:null;
 }
 function historyMarkup(rows){
  if(!rows.length)return '<p class="pay-empty-history">Nenhum pagamento confirmado pelo professor.</p>';
  return rows.slice(0,payShowHistoryAll?60:6).map(row=>'<article class="ap-billing-history"><div><strong>'+safe(money(row.amountCents))+'</strong><span>Confirmado em '+safe(new Date(row.paidAt).toLocaleDateString('pt-BR'))+'</span>'+(row.dueDate?'<span>Referente a '+safe(payShortDate(row.dueDate))+'</span>':'')+'</div><span class="pay-chip">Pago</span></article>').join('');
 }
 function countdown(b,s){if(s.days===null)return 'O professor ainda não informou a data.';if(s.kind==='overdue')return s.days<0?'Vencido há '+Math.abs(s.days)+' '+(s.days===-1?'dia':'dias'):'Situação informada pelo professor';if(s.days===0)return 'Vencimento hoje';return 'Vence em '+s.days+' '+(s.days===1?'dia':'dias')}
 payRender=function(){
  const screen=$('paymentsScreen');if(!screen)return;const p=prefs();screen.style.setProperty('--pay-accent',p.color||'#f52283');screen.style.setProperty('--pay-scale',({pequena:.92,media:1,grande:1.12}[p.font]||1));screen.classList.toggle('pay-light',p.mode==='claro');
  document.querySelectorAll('#paymentsScreen [data-pay-nav]').forEach(node=>node.innerHTML=node.dataset.payNav==='card'?payI('card'):iconSvg(p.icons||'padrao',node.dataset.payNav));
  const back=screen.querySelector('[data-pay-icon="back"]');if(back)back.innerHTML=payI('back');
  payCloseDialog();const b=billing(),root=$('payContent');shownDay=new Date().toLocaleDateString('en-CA');
  if(!b){root.innerHTML='<section class="pay-box ap-area-empty"><h2>Mensalidade ainda não disponibilizada</h2><p>Os dados aparecerão aqui quando o professor configurar e sincronizar a cobrança.</p></section>';return}
  const s=APBilling.status(b),rows=b.history.slice().sort((a,b)=>b.paidAt.localeCompare(a.paidAt));
  root.innerHTML='<section class="pay-box"><div class="ap-billing-heading"><h2>Mensalidade</h2><span id="apBillingStatus" class="pay-chip '+(s.kind==='overdue'?'overdue':'neutral')+'">'+safe(s.label)+'</span></div><strong id="apBillingAmount" class="ap-billing-amount">'+safe(money(b.amountCents))+'</strong><div class="ap-billing-due"><span>Próximo vencimento</span><strong id="apBillingDue">'+safe(payShortDate(b.dueDate))+'</strong><small id="apBillingCountdown">'+safe(countdown(b,s))+'</small></div>'+(b.startDate?'<p class="ap-billing-note">Início em '+safe(payShortDate(b.startDate))+'</p>':'')+'</section>'+
   '<section class="pay-box"><h2>Pagamento via Pix</h2>'+(b.pixKey?'<p class="ap-billing-note">Chave informada pelo professor</p><div id="apBillingPixKey" class="ap-billing-key">'+safe(b.pixKey)+'</div><button id="apBillingCopyPix" class="pay-main-btn" type="button">'+payI('copy')+'Copiar chave Pix</button><p class="ap-billing-note">Use a chave no aplicativo do seu banco. A baixa aparece após a confirmação do professor.</p>':'<p class="ap-billing-note">O professor ainda não disponibilizou a chave Pix.</p>')+'</section>'+
   '<section class="pay-box"><div class="ap-billing-heading"><h2>Pagamentos confirmados</h2></div>'+historyMarkup(rows)+(rows.length>6?'<button id="apBillingHistoryToggle" class="pay-link" type="button">'+(payShowHistoryAll?'Mostrar menos':'Ver todos')+'</button>':'')+'</section>';
  if($('apBillingCopyPix'))$('apBillingCopyPix').onclick=payPixCopy;
  if($('apBillingHistoryToggle'))$('apBillingHistoryToggle').onclick=()=>{const y=$('payScroll').scrollTop;payShowHistoryAll=!payShowHistoryAll;payRender();$('payScroll').scrollTop=y};
 };
 // Legacy dialogs must also read the current authenticated packet, never the
 // old gender-based payment demo or another account's local plan.
 payGet=function(){const b=billing();return {name:'Mensalidade',amount:b&&b.amountCents!==null?b.amountCents/100:null,nextDue:b?.dueDate||'',start:b?.startDate||'',end:'',pixKey:b?.pixKey||'',history:(b?.history||[]).map(p=>({id:p.id,date:p.paidAt.slice(0,10),amount:p.amountCents===null?null:p.amountCents/100,status:'pago'})),demo:false}};
 payPixOpen=function(){const b=billing();if(!b?.pixKey)return;payDialogOpen('Pagamento via Pix','<p>Chave informada pelo professor:</p><div class="pay-key">'+safe(b.pixKey)+'</div><p>Utilize o aplicativo do seu banco para pagar.</p>','Copiar chave Pix',payPixCopy)};
 payPixCopy=async function(){
  const key=billing()?.pixKey,account=window.__AP_STUDENT_CONTEXT?.storageId;if(!key)return;
  try{
   if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(key);
   else{const input=document.createElement('textarea');input.value=key;input.setAttribute('readonly','');input.style.position='fixed';input.style.opacity='0';document.body.appendChild(input);input.select();const ok=document.execCommand('copy');input.remove();if(!ok)throw Error('copy')}
   if(account!==window.__AP_STUDENT_CONTEXT?.storageId)return;toast('Chave Pix copiada.');
  }catch(_){if(account!==window.__AP_STUDENT_CONTEXT?.storageId)return;const current=billing()?.pixKey;if(current)payDialogOpen('Copiar chave Pix','<p>Toque e segure a chave para copiar:</p><div class="pay-key ap-billing-key">'+safe(current)+'</div>')}
 };
 window.APstudentBilling=Object.freeze({billing,render:payRender});
 window.addEventListener('ap-account-changed',()=>{payCloseDialog();payShowHistoryAll=false;if($('payContent'))$('payContent').textContent=''});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&document.body.dataset.view==='payments')payRender()});
 setInterval(()=>{if(document.body.dataset.view==='payments'&&shownDay!==new Date().toLocaleDateString('en-CA'))payRender()},60000);
})();
