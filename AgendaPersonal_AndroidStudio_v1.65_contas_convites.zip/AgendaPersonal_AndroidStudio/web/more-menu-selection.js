(function(){
 'use strict';
 const menu=document.getElementById('screen-more');if(!menu)return;
 const cards=[...menu.querySelectorAll('button.more-function,button.pro-menu-row')];let selected=null;
 function clear(){if(selected){selected.classList.remove('more-function-primary');selected.setAttribute('aria-pressed','false');selected=null}}
 for(const card of cards){card.setAttribute('aria-pressed','false');card.setAttribute('aria-describedby','apMoreSelectHint')}
 // Capture the first click before the existing navigation, modal or action.
 // The second click follows the original handler exactly once.
 menu.addEventListener('click',event=>{
  const card=event.target.closest('button.more-function,button.pro-menu-row');
  if(!card||!menu.contains(card)||card.disabled||event.button>0)return;
  if(card===selected)return;
  event.preventDefault();event.stopImmediatePropagation();clear();selected=card;
  card.classList.add('more-function-primary');card.setAttribute('aria-pressed','true');
 },true);
 menu.addEventListener('keydown',event=>{if(event.key==='Escape'&&!document.querySelector('.dialog.open'))clear()});
 new MutationObserver(()=>{if(!menu.classList.contains('active'))clear()}).observe(menu,{attributes:true,attributeFilter:['class']});
})();
