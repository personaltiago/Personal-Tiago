(function(){
 'use strict';
 const normalize=normalizedWorkoutVideoUrl;
 normalizedWorkoutVideoUrl=value=>normalize(value)||APExternalVideo.normalize(value);
 window.openWorkoutExternalVideo=function(value){clearWorkoutInlineVideo();if(!APExternalVideo.open(value))toast('Não foi possível abrir o link do vídeo.')};
 let generation=0;
 window.openWorkoutTikTok=async function(value,title,source){
  if(window.Android&&typeof Android.openInlineTikTokVideo!=='function')return toast('Instale o APK 1.117 para assistir ao TikTok dentro da Agenda.',6500);
  const token=String(++generation);if(!source?.isConnected)return;source.dataset.tiktokOpen=token;source.setAttribute('aria-busy','true');
  try{const video=await APTikTok.metadata(value),owner=source.closest('.dialog');if(!source.isConnected||source.dataset.tiktokOpen!==token||owner&&(!owner.classList.contains('open')||owner.inert)||source.id==='workoutVideoPreview'&&normalizedWorkoutVideoUrl(document.getElementById('workoutExerciseVideo').value)!==normalizedWorkoutVideoUrl(value))return;openWorkoutYouTube(video,title,source)}
  catch(e){toast(e.message||'Não foi possível carregar este vídeo. Confira a conexão.',6000)}finally{source.removeAttribute('aria-busy')}
 };
 const thumbnail=workoutVideoThumbnail;
 workoutVideoThumbnail=function(ex,handler,sidePreview=false){
  if(!APExternalVideo.isTikTok(ex.video))return thumbnail.apply(this,arguments);
  return '<button class="workout-thumb'+(sidePreview?' workout-exercise-preview portrait-source':'')+'" type="button" data-tiktok-preview="'+hesc(ex.video)+'" data-exercise-id="'+hesc(ex.id)+'" onclick="'+handler+'(this.dataset.exerciseId,this)" aria-label="Assistir vídeo de '+hesc(ex.name)+'"><img hidden alt="" referrerpolicy="no-referrer"><span>▶ Assistir vídeo</span><small class="tiktok-cover-note">TikTok · Prévia indisponível</small></button>';
 };
 const update=updateWorkoutVideoField;
 updateWorkoutVideoField=function(){
  const raw=String(document.getElementById('workoutExerciseVideo').value||'').trim(),url=normalizedWorkoutVideoUrl(raw),button=document.getElementById('workoutVideoPreview');
  if(!url||workoutYouTubeHost(new URL(url))){button.removeAttribute('aria-label');delete button.dataset.externalPreview;update();if(!raw)document.getElementById('workoutVideoHint').textContent='Cole o link do YouTube ou TikTok para assistir na Agenda.';return}
  document.getElementById('workoutExerciseReusable').parentElement.hidden=workoutExerciseMode==='catalog'||workoutCatalogHasVideo({video:url});
  if(workoutInlineVideo?.source.id==='workoutVideoPreview')clearWorkoutInlineVideo();
  const tiktok=APExternalVideo.isTikTok(url),key='external|'+url;button.hidden=false;delete button.dataset.externalPreview;button.setAttribute('aria-label',tiktok?'Assistir prévia do TikTok':APExternalVideo.action(url));
  if(button.dataset.previewKey!==key){button.dataset.previewKey=key;button.innerHTML=tiktok?'<span class="workout-edit-poster" data-tiktok-preview="'+hesc(url)+'"><img hidden alt="" referrerpolicy="no-referrer"><span>▶</span><small class="tiktok-cover-note">Prévia indisponível</small></span><span class="workout-edit-copy"><strong>Assistir prévia do TikTok</strong><small>O vídeo abre nesta janela da Agenda.</small></span>':'<span class="workout-edit-copy"><strong>'+hesc(APExternalVideo.action(url))+'</strong><small>Vídeo externo</small></span>'}
  document.getElementById('workoutVideoHint').textContent=tiktok?'TikTok reconhecido. Toque na prévia para assistir dentro da Agenda.':'Este link abre fora da Agenda.';
 };
 const preview=previewWorkoutVideo;
 previewWorkoutVideo=function(){const url=normalizedWorkoutVideoUrl(document.getElementById('workoutExerciseVideo').value);if(APExternalVideo.isTikTok(url)){openWorkoutTikTok(url,document.getElementById('workoutExerciseName').value,document.getElementById('workoutVideoPreview'));return}if(url&&!workoutYouTubeHost(new URL(url))){openWorkoutExternalVideo(url);return}return preview.apply(this,arguments)};
 const error=workoutInlineVideoError;
 workoutInlineVideoError=function(key){error(key);if(workoutInlineVideo?.key===key&&workoutInlineVideo.youtube.provider==='tiktok')workoutInlineVideo.status.textContent='Não foi possível iniciar o TikTok. Confira a conexão e tente novamente.'};
})();
