// Fill missing instructions at read time, including older PDF imports. Never
// rewrite a prescription or replace text already supplied for this student.
function withWorkoutGuidance(ex={}){
  const items=workoutCatalogItems(),name=workoutSearchKey(ex.name);
  let template=items.find(item=>item.id===ex.catalogId&&workoutCatalogSameName(ex,item));
  if(!template&&name){
    const matches=items.filter(item=>workoutCatalogSameName(ex,item));
    const app=matches.filter(item=>item.source==='app');
    const candidates=app.length?app:matches.filter(item=>item.source==='mine');
    if(candidates.length===1)template=candidates[0];
  }
  const next={...ex};
  const text=value=>String(value??'').trim();
  if(!text(ex.notes))next.notes=text(ex.sourceNotes)||text(ex.guidance?.execution)||text(ex.description)||text(template?.notes);
  if(!text(ex.observations))next.observations=text(ex.sourceObservations)||text(template?.observations);
  if(template){next.guidanceStatus=ex.guidanceStatus||template.guidanceStatus;next.reference=ex.reference||template.reference}
  return next;
}
