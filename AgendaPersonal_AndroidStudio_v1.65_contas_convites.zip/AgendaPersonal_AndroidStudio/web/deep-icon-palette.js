(function(){
 'use strict';
 const ns='http://www.w3.org/2000/svg',tones=['purple','neutral','good','warn','danger'];
 const defaults={light:'#c29fe1',upper:'#793fa6',mid:'#542187',low:'#3c1760',deep:'#1e0c31'};
 const matte={purple:['#8d58b0','#68358c','#481e69','#301344','#180a24'],neutral:['#8a8a94','#62626c','#45454f','#2c2c34','#16161d'],good:['#69a58d','#397b5f','#215b42','#143d2c','#0b2118'],warn:['#c2a16e','#9b733c','#78521e','#513713','#2b1d0b'],danger:['#c17e8a','#9b4c5c','#752c3b','#501d28','#2b1016']};
 const rgb=value=>/^#[0-9a-f]{6}$/i.test(value)?value.slice(1).match(/../g).map(v=>parseInt(v,16)/255):null;
 const mix=(a,b,f)=>a.map((n,i)=>n+(b[i]-n)*f);
 const channels=new Map();let queued=false;
 function ensure(){
  if(document.getElementById('apDeepPaletteFilters'))return;
  const host=document.createElementNS(ns,'svg');host.id='apDeepPaletteFilters';host.setAttribute('aria-hidden','true');host.setAttribute('data-deep-owned','');host.setAttribute('width','0');host.setAttribute('height','0');host.style.cssText='position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
  const defs=document.createElementNS(ns,'defs');
  for(const finish of ['palette','matte'])for(const tone of tones){
   const filter=document.createElementNS(ns,'filter');filter.id='ap-deep-'+finish+'-'+tone;filter.setAttribute('color-interpolation-filters','sRGB');
   // Keep the approved bitmap's geometry, transparency, shading and highlights.
   // Only its lightness is mapped to the same material colors as vector icons.
   const luminance=document.createElementNS(ns,'feColorMatrix');luminance.setAttribute('type','matrix');luminance.setAttribute('values','.2126 .7152 .0722 0 0 .2126 .7152 .0722 0 0 .2126 .7152 .0722 0 0 0 0 0 1 0');
   const transfer=document.createElementNS(ns,'feComponentTransfer'),functions=[];
   for(const channel of ['R','G','B']){const f=document.createElementNS(ns,'feFunc'+channel);f.setAttribute('type','table');functions.push(f);transfer.append(f)}
   const alpha=document.createElementNS(ns,'feFuncA');alpha.setAttribute('type','identity');transfer.append(alpha);filter.append(luminance,transfer);defs.append(filter);channels.set(finish+'-'+tone,functions);
  }
  host.append(defs);document.body.append(host);
 }
 function refresh(){
  queued=false;const root=document.documentElement;ensure();
  for(const finish of ['palette','matte'])for(const tone of tones){
   const colors={};Object.keys(defaults).forEach((key,i)=>{const value=finish==='matte'?matte[tone][i]:root.style.getPropertyValue('--ac-deep-'+tone+'-'+key).trim();colors[key]=rgb(value)||rgb(defaults[key])});
   // This transfer curve accounts for the dark purple baked into the atlas.
   // Black shadows stay black; midtones follow the selected accent exactly.
   const stops=[[0,[0,0,0]],[.035,colors.deep],[.09,colors.low],[.18,colors.mid],[.30,colors.upper],[.46,colors.light],[.72,mix(colors.light,[1,1,1],.18)],[1,mix(colors.light,[1,1,1],.35)]];
   const table=Array.from({length:33},(_,i)=>{const x=i/32;let n=1;while(n<stops.length-1&&x>stops[n][0])n++;const [a,ca]=stops[n-1],[b,cb]=stops[n];return mix(ca,cb,(x-a)/(b-a))});
   channels.get(finish+'-'+tone).forEach((f,c)=>{const value=table.map(color=>color[c].toFixed(5)).join(' ');if(f.getAttribute('tableValues')!==value)f.setAttribute('tableValues',value)});
  }
 }
 function schedule(){if(!queued){queued=true;requestAnimationFrame(refresh)}}
 function boot(){refresh();new MutationObserver(schedule).observe(document.documentElement,{attributes:true,attributeFilter:['style','data-agenda-design','data-agenda-color-mode']})}
 window.addEventListener('agenda-colors-change',refresh);
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
