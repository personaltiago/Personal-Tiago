(function(){
 'use strict';
 const KEY='agendaPersonalTL_appearance_backgrounds_v1';
 const valid=hex=>typeof hex==='string'&&/^#[\da-f]{6}$/i.test(hex);
 const mode=()=>AgendaColors.palette(AgendaColors.get()).light?'light':'dark';
 function memory(){
  try{const data=JSON.parse(localStorage.getItem(KEY)||'null');return data?.version===1&&data.designs&&typeof data.designs==='object'?data:{version:1,designs:{}}}catch(_){return {version:1,designs:{}}}
 }
 function refresh(){
  const current=mode();document.querySelectorAll('[data-teacher-mode]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.teacherMode===current)));
 }
 function setMode(target){
  if(!['light','dark'].includes(target))return {ok:false,error:'Escolha Claro ou Escuro.'};
  const config=AgendaColors.get(),current=mode(),design=AgendaColors.getDesign();
  if(current===target)return {ok:true,config};
  const cache=memory(),saved=cache.designs[design]||{};
  let background=valid(saved[target])?saved[target]:target==='light'?'#f6f5f9':'#0d0e12';
  // Validate stored backgrounds against the existing palette's light/dark threshold.
  if((AgendaColors.palette({...config,background}).light?'light':'dark')!==target)background=target==='light'?'#f6f5f9':'#0d0e12';
  let previous=null;
  try{previous=localStorage.getItem(KEY);localStorage.setItem(KEY,JSON.stringify({version:1,designs:{...cache.designs,[design]:{...saved,[current]:config.background}}}))}
  catch(_){return {ok:false,error:'Não foi possível salvar o modo. Libere espaço no aparelho e tente novamente.'}}
  const result=AgendaColors.save({...config,id:'custom',name:'Minhas cores',background});
  if(!result.ok){try{if(previous===null)localStorage.removeItem(KEY);else localStorage.setItem(KEY,previous)}catch(_){}return result}
  return result;
 }
 window.chooseTeacherAppearance=function(target){
  const result=setMode(target),status=document.getElementById('teacherAppearanceStatus');
  status.textContent=result.ok?(target==='light'?'Modo claro salvo.':'Modo escuro salvo.'):result.error;status.dataset.error=String(!result.ok);
  if(result.ok){colorPanelDraft={...result.config,id:'custom',name:'Minhas cores'};refreshColorPresetSelection();document.getElementById('colorPanelStatus').textContent=target==='light'?'Modo claro ativo.':'Modo escuro ativo.';document.getElementById('colorPanelStatus').dataset.error='false'}
  refresh();
 };
 window.AgendaAppearance=Object.freeze({setMode,refresh,getMode:mode});
 window.addEventListener('agenda-colors-change',refresh);
 refresh();
})();
