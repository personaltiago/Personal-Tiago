// Runs inside the existing account module; I/r/A/d/s/a/t are its verified bindings.
    function registrationOwner() {
        if (!A() || window.__AP_STUDENT_CONTEXT) throw Error("Entre com a conta do professor para consultar os cadastros.");
        return {
            epoch: d,
            uid: s.uid
        };
    }
    function registrationOwnerUnchanged(owner) {
        if (owner.epoch !== d || owner.uid !== s?.uid || !A() || window.__AP_STUDENT_CONTEXT) throw Error("A conta mudou. Abra os contatos novamente.");
    }
    async function registrationList() {
        await I();
        const owner = registrationOwner();
        const result = await r.getDocs(r.query(r.collection(r.db, "usuarios"), r.where("professorId", "==", a)));
        registrationOwnerUnchanged(owner);
        return result.docs.map(row => ({
            ...row.data(),
            uid: row.id
        })).filter(row => row.perfil === "aluno" && row.professorId === a);
    }
    async function registrationApprove(uid, type) {
        await I();
        const owner = registrationOwner();
        if (!t.uid(uid) || uid === a || ![ "presencial", "online" ].includes(type)) throw Error("Confira o cadastro e o tipo de aluno antes de aprovar.");
        const reference = r.doc(r.db, "usuarios", uid), snapshot = await r.getDoc(reference);
        registrationOwnerUnchanged(owner);
        const profile = snapshot.exists() ? snapshot.data() : null;
        if (!profile || profile.perfil !== "aluno" || profile.professorId !== a) throw Error("Este cadastro não pertence aos alunos deste professor.");
        if (profile.ativo !== true) {
            await r.updateDoc(reference, {
                ativo: true,
                tipoAluno: type,
                aprovadoEm: r.serverTimestamp()
            });
            registrationOwnerUnchanged(owner);
        }
        return {
            uid: uid,
            approved: true
        };
    }
