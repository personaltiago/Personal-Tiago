(function(){
 'use strict';
 if(window.APWorkoutSync||window.__AP_PUBLIC_REGISTER)return;
 const M=APStudentProgressModel,endpoint='https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site';
 const uid=()=>window.__AP_STUDENT_CONTEXT?.role==='student'?window.__AP_STUDENT_CONTEXT.storageId:'',teacher=()=>window.APaccounts?.isTeacher()===true;
 const ackKey=id=>'agenda_progress_sent_v1_'+id,cacheKey=id=>'agenda_progress_teacher_v1_'+APStudentModel.TEACHER+'_'+id;
 let epoch=0,sending=false,timer=0,lastStatus='';const cache=new Map(),reads=new Map();
 const parse=(k,fallback)=>{try{return JSON.parse(localStorage.getItem(k)||'null')||fallback}catch(_){return fallback}};
 function status(message){lastStatus=message;let n=document.getElementById('apWorkoutSyncStatus');const screen=document.getElementById('historyScreen');if(!n&&screen){n=document.createElement('p');n.id='apWorkoutSyncStatus';n.setAttribute('role','status');n.style.cssText='padding:0 16px;font:12px/1.5 Arial,sans-serif;color:inherit;opacity:.8';screen.appendChild(n)}if(n){n.textContent=message;n.hidden=!message}}
 async function post(path,data){const account=uid(),isTeacher=teacher(),ticket=epoch,token=await APaccounts.getPhotoToken();if(ticket!==epoch||account!==uid()||isTeacher!==teacher())throw Error('A conta foi alterada.');const response=await fetch(endpoint+path,{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(data),signal:AbortSignal.timeout(25000)});let result;try{result=await response.json()}catch(_){throw Error('O serviço não respondeu. Tente novamente com conexão.')}if(!response.ok)throw Error(result.error||'Não foi possível sincronizar os treinos.');return result}
 function schedule(){clearTimeout(timer);timer=setTimeout(pump,700)}
 async function pump(){
  const id=uid(),token=epoch;if(!id||sending)return;
  const history=exStore().history,records=(Array.isArray(history)?history:[]).map(M.normalize).filter(Boolean),ack=parse(ackKey(id),{}),pending=records.filter(r=>!ack[M.key(r)]);
  if(!pending.length){status(records.length?'Treinos enviados ao professor.':'');return}
  if(navigator.onLine===false){status('Treinos salvos neste aparelho. Aguardando conexão para enviar ao professor.');return}
  sending=true;status('Enviando os treinos concluídos ao professor…');
  try{
   for(const record of pending.slice(0,10)){
    if(token!==epoch||id!==uid())return;
    const response=await post('/api/student-workout',{workout:record});if(token!==epoch||id!==uid())return;
    if(response.saved!==true||response.uid!==id||response.recordKey!==M.key(record))throw Error('A confirmação do treino não foi recebida.');
    ack[M.key(record)]=true;const retained={};for(const r of records)if(ack[M.key(r)])retained[M.key(r)]=true;localStorage.setItem(ackKey(id),JSON.stringify(retained));
   }
   const more=pending.length>10;status(more?'Enviando os treinos concluídos ao professor…':'Treinos enviados ao professor.');if(more)schedule();
  }catch(_){if(token===epoch&&id===uid())status('Treinos salvos neste aparelho. O envio ao professor será tentado novamente com conexão.')}
  finally{sending=false;if(token!==epoch&&uid())schedule()}
 }
 function records(id){if(!teacher()||!/^[A-Za-z0-9_-]{1,128}$/.test(id||''))return [];if(!cache.has(id)){const saved=parse(cacheKey(id),null);cache.set(id,{records:Array.isArray(saved?.records)?saved.records.map(M.normalize).filter(Boolean):[],at:saved?.at||'',message:''})}return cache.get(id).records.slice()}
 function summary(id){records(id);return teacher()?{at:cache.get(id)?.at||'',message:cache.get(id)?.message||''}:{at:'',message:''}}
 async function refresh(id){
  if(!teacher()||!/^[A-Za-z0-9_-]{1,128}$/.test(id||''))throw Error('O aluno precisa ter uma conta vinculada ao professor.');if(reads.has(id))return reads.get(id);
  const ticket=epoch;records(id);const work=(async()=>{
   if(navigator.onLine===false){cache.get(id).message='Sem conexão. Exibindo os registros já recebidos neste aparelho.';return records(id)}
   try{const merged=new Map(records(id).map(r=>[M.key(r),r]));let cursor=null,pages=0;
    do{const response=await post('/api/student-workouts',{uid:id,cursor});if(ticket!==epoch||!teacher())throw Error('A conta foi alterada.');
     if(response.uid!==id||!Array.isArray(response.workouts)||response.cursor!==null&&typeof response.cursor!=='string')throw Error('O histórico recebido não corresponde ao aluno selecionado.');
     for(const raw of response.workouts){const r=M.normalize(raw);if(r)merged.set(M.key(r),r)}cursor=response.cursor;pages++;if(cursor&&pages>=100)throw Error('Histórico extenso. Atualize novamente para continuar a consulta.');
    }while(cursor);
    if(ticket!==epoch||!teacher())return [];
    const value={records:[...merged.values()].sort((a,b)=>a.finishedAt-b.finishedAt),at:new Date().toISOString(),message:''};cache.set(id,value);
    try{localStorage.setItem(cacheKey(id),JSON.stringify({records:value.records,at:value.at}))}catch(_){value.message='Registros recebidos. Não foi possível manter uma cópia neste aparelho.'}
    return value.records.slice();
   }catch(e){if(ticket===epoch&&teacher())cache.get(id).message='Não foi possível atualizar agora. '+(records(id).length?'Exibindo os registros já recebidos.':'Conecte o aplicativo atualizado do aluno para enviar os treinos.');throw e}
  })();reads.set(id,work);try{return await work}finally{if(reads.get(id)===work)reads.delete(id)}
 }
 const save=exSave;exSave=function(data){const result=save(data);if(result&&uid())schedule();return result};
 window.APWorkoutSync=Object.freeze({pump,schedule,records,refresh,summary,status:()=>lastStatus});
 window.addEventListener('ap-account-changed',()=>{epoch++;clearTimeout(timer);cache.clear();reads.clear();status('')});
 window.addEventListener('ap-student-ready',schedule);window.addEventListener('online',schedule);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule()});setInterval(()=>{if(!document.hidden)schedule()},60000);schedule();
})();
