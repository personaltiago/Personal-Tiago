function renderAlarmStatus(){
 const status=readAlarmStatus(),text=document.getElementById('alarmStatusText'),issue=status?.issue||'';
 if(text){text.textContent=status?(issue||'Permissões e som do lembrete verificados'):'Verificação disponível no aplicativo Android';text.style.color=issue?'var(--amber)':''}
 renderSoundStatus(status||readCustomSoundStatus());
}
