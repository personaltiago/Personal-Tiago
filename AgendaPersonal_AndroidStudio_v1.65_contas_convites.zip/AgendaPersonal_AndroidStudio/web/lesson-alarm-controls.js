function renderAlarmStatus(){
 const status=readAlarmStatus(),text=document.getElementById('alarmStatusText'),issue=status?.issue||'';
 if(text){text.textContent=status?(issue||'Permissões e som do lembrete verificados'):'Verificação disponível no aplicativo Android';text.style.color=issue?'var(--amber)':''}
 const initial=status?(issue||'Permissões e som verificados'):'Abra no aplicativo Android para programar o toque';
 const ending=status?.timerIssue||(status?.timerReady===true?'Permissões e som verificados':status?'Confira o som de fim da aula em Verificar / testar':'Disponível no aplicativo Android');
 document.querySelectorAll('[data-agenda-alarm-status]').forEach(node=>{node.textContent='Antes da aula: '+initial.replace(/[.!]+$/,'')+'. Fim da aula: '+ending.replace(/[.!]+$/,'')+'.';node.dataset.blocked=String(!!issue||!!status?.timerIssue)});
 renderSoundStatus(status||readCustomSoundStatus());
}
