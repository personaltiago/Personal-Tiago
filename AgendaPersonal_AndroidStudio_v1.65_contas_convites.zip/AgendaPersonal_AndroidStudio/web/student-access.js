(function(){
 'use strict';
 if(window.__AP_PUBLIC_REGISTER)return;
 const context=()=>window.__AP_STUDENT_CONTEXT;
 const marker=uid=>'agenda_student_revoked_v1_'+uid;
 let shown=false;
 function accept(area,uid,fromCache){
  if(!area)return null;
  let revoked=false;try{revoked=localStorage.getItem(marker(uid))==='true'}catch(_){}
  if(area.enabled===false){try{localStorage.setItem(marker(uid),'true')}catch(_){}return area}
  if(fromCache&&revoked)return {...area,enabled:false,archived:true,plans:[]};
  if(!fromCache)try{localStorage.removeItem(marker(uid))}catch(_){}
  return area;
 }
 function blocked(){return context()?.role==='student'&&context()?.area?.enabled===false}
 function refresh(){
  const locked=blocked();let box=document.getElementById('apStudentAccessBlocked');
  if(locked&&!box){
   box=document.createElement('section');box.id='apStudentAccessBlocked';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');box.setAttribute('aria-labelledby','apStudentAccessTitle');
   box.style.cssText='position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;padding:24px;background:#09080e;color:#f5f0fa;overflow:auto;font-family:Arial,sans-serif';
   box.innerHTML='<div style="width:100%;max-width:380px"><h1 id="apStudentAccessTitle" tabindex="-1" style="font-size:26px;line-height:1.2;margin:0 0 16px;outline:none">Acesso aos treinos suspenso</h1><p style="font-size:16px;line-height:1.6;color:#c3b9ce;margin:0 0 24px">Fale com seu professor para reativar o acesso. Seus registros de treino foram preservados.</p><button type="button" data-access-action="updates" style="display:block;width:100%;min-height:48px;margin:0 0 12px;border:1px solid #6e557f;border-radius:12px;background:#21172a;color:#f5f0fa;font-size:16px">Atualizações do aplicativo</button><button type="button" data-access-action="logout" style="display:block;width:100%;min-height:48px;border:1px solid #6e557f;border-radius:12px;background:transparent;color:#f5f0fa;font-size:16px">Sair da conta</button></div>';
   box.querySelector('[data-access-action="updates"]').onclick=()=>window.APaccounts.openUpdates();
   box.querySelector('[data-access-action="logout"]').onclick=()=>window.APaccounts.logout();
   document.body.appendChild(box);
  }
  if(box)box.hidden=!locked;
  // Inline display is explicitly reset because the blocking layer uses flex.
  if(box)box.style.display=locked?'flex':'none';
  if(locked&&!shown){
   window.clearWorkoutInlineVideo?.();try{window.Android?.cancelWorkoutRest?.()}catch(_){}
   window.APstudentUI?.reset();route('workouts');box.querySelector('h1').focus({preventScroll:true});
  }else if(!locked&&shown&&context()?.role==='student')route('home');
  shown=locked;
 }
 function canTrain(){return context()?.role!=='student'||context()?.area?.enabled===true}
 for(const name of ['exNewSession','beginExerciseWorkout','openExerciseHub','openExerciseDetail','saveExerciseLoad','toggleExerciseSet','toggleRestTimer','finishExerciseWorkout','confirmExerciseWorkoutFinish']){
  const original=window[name];if(typeof original!=='function')continue;
  window[name]=function(){if(!canTrain()){refresh();return null}return original.apply(this,arguments)};
 }
 window.APStudentAccess=Object.freeze({accept,refresh,blocked});
 window.addEventListener('ap-student-ready',refresh);
 window.addEventListener('ap-account-changed',refresh);
})();
