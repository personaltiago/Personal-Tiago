(function(global){
 'use strict';
 const dayKey=date=>date.getFullYear()+'-'+date.getMonth()+'-'+date.getDate();
 function choose(values,date,account){let seed=0;for(const c of String(account||''))seed=(Math.imul(seed,31)+c.charCodeAt(0))>>>0;const day=Math.floor(Date.UTC(date.getFullYear(),date.getMonth(),date.getDate())/86400000);return values[(day+seed)%values.length]}
 function student(area,store={},date=new Date(),account=''){
  const entries=global.APStudentModel.workouts(area).filter(w=>w.count>0);
  if(!entries.length)return {kind:'waiting',text:'Estou por aqui! Quando seu professor liberar a ficha, seguimos juntos.'};
  // Only a complete, saved execution from this local calendar day counts.
  const completed=(store.history||[]).filter(r=>r.incomplete===false&&Number.isFinite(r.finishedAt)&&r.finishedAt<=date.getTime()&&dayKey(new Date(r.finishedAt))===dayKey(date)&&Array.isArray(r.exerciseRecords)&&r.exerciseRecords.length&&r.exerciseRecords.every(e=>Array.isArray(e.done)&&e.done.length&&e.done.every(v=>v===true))).sort((a,b)=>b.finishedAt-a.finishedAt)[0];
  if(completed){const message=global.APWorkoutMotivation?.messageFor(completed);return {kind:'completed',trend:message?.kind||'',text:message?.text||choose(['Treino de hoje concluído! Seu registro está salvo. Agora valorize também o descanso.','Você concluiu um treino hoje. Gostei de ver sua constância! Uma pausa também faz parte.'],date,account)}};
  if(Object.values(store.active||{}).some(s=>Number.isFinite(s?.startedAt)&&entries.some(w=>w.id===s.id)))return {kind:'active',text:'Seu treino está em andamento. Estou com você: siga a ficha, uma série de cada vez.'};
  const today=entries.find(w=>Number.isInteger(w.weekday)&&w.weekday===date.getDay());
  if(today){const name=String(today.label||'seu treino').slice(0,70);return {kind:'training',text:choose(['Hoje tem '+name+'. Vamos com atenção à execução e no seu ritmo?','Estou com você no treino de hoje. Siga a ficha e valorize cada série.','Um treino de cada vez. Hoje é dia de '+name+'; vamos fazer bem feito.'],date,account)}}
  if(entries.some(w=>!Number.isInteger(w.weekday)||w.weekday<0||w.weekday>6))return {kind:'sequence',text:choose(['Vamos no seu ritmo. Quando for treinar, siga a próxima etapa da sua ficha.','Estou aqui para acompanhar sua constância. Organize o próximo treino conforme sua ficha.'],date,account)};
  return {kind:'rest',text:choose(['Hoje não há treino previsto na sua ficha. Aproveite a pausa: descansar também faz parte.','Sua ficha não tem treino marcado para hoje. Que tal reservar um tempo para descansar?','Hoje a ficha dá espaço ao descanso. Eu continuo aqui; seguimos no próximo treino.'],date,account)};
 }
 function teacher(summary,date=new Date(),account=''){
  if(!summary)return {kind:'waiting',text:'Estou por aqui para acompanhar seu dia. Abra a agenda e vamos por partes.'};
  const total=summary.total||0,done=summary.done||0;
  if(!total)return {kind:'free',text:choose(['Hoje não há aulas ativas na sua agenda. Se puder, reserve um tempo para você.','A agenda está livre hoje. Podemos organizar os próximos dias sem esquecer a sua pausa.'],date,account)};
  if(done===total)return {kind:'completed',text:'Você marcou '+done+(done===1?' aula como realizada':' aulas como realizadas')+' hoje. Dia cumprido na agenda; reserve uma pausa para você.'};
  if(summary.current)return {kind:'current',text:'Há uma aula prevista para agora, às '+summary.current+'. Hoje são '+total+(total===1?' aula':' aulas')+' na agenda. Um horário de cada vez.'};
  if(summary.next)return {kind:'scheduled',text:choose(['Hoje você tem '+total+(total===1?' aula':' aulas')+' na agenda. A próxima é às '+summary.next+'. Vamos organizar um horário de cada vez?','A próxima aula começa às '+summary.next+'. Hoje são '+total+(total===1?' aula':' aulas')+' na agenda; lembre de reservar suas pausas.'],date,account)};
  return {kind:'review',text:'Os horários de hoje já passaram. Confira os registros das aulas e reserve uma pausa para você.'};
 }
 // Keep daily reminders available when the optional pet is disabled.
 function compactMarkup(text){const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));return '<div class="ap-mascot-recados" role="status" aria-live="polite" aria-atomic="true"><strong>Recados do dia</strong><p>'+escape(text)+'</p></div>'}
 function present(node,text,enabled){
  node.hidden=false;node.classList.toggle('ap-recado-only',!enabled);
  let notice=node.querySelector('.ap-mascot-recados');
  if(!enabled){
   node.style.backgroundImage='none';
   if(!notice){node.insertAdjacentHTML('beforeend',compactMarkup(text));notice=node.querySelector('.ap-mascot-recados')}
   const message=notice.querySelector('p');if(message.textContent!==text)message.textContent=text;
  }
  if(notice)notice.hidden=enabled;
 }
 function refresh(){if(document.hidden)return;global.APmascot?.refreshHome();global.APteacherMascot?.refreshCard()}
 global.APMascotMessages=Object.freeze({student,teacher,refresh,compactMarkup,present});
 document.addEventListener('visibilitychange',refresh);
 global.addEventListener('ap-account-changed',refresh);
 setInterval(refresh,60000);
})(globalThis);
