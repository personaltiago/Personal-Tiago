(function(){
 'use strict';
 const uid=value=>/^[A-Za-z0-9_-]{1,128}$/.test(value||'');
 window.APstudentPhotoTargets=function(){return state.students.filter(s=>uid(s.firebaseUid)).map(s=>({uid:s.firebaseUid,revision:typeof s.photoRemoteRevision==='string'?s.photoRemoteRevision:''}))};
 window.APstudentPhotoSyncNotice=function(message){let n=document.getElementById('apTeacherPhotoSyncStatus');if(!n){const list=document.getElementById('studentList');if(!list)return;n=document.createElement('p');n.id='apTeacherPhotoSyncStatus';n.setAttribute('role','status');n.style.cssText='font-size:.8rem;line-height:1.5;color:var(--muted,#b8afc0);margin:0 0 12px';list.before(n)}n.hidden=!message;n.textContent=message};
 window.APapplyStudentPhotos=function(records){
  if(!window.parent?.APaccounts?.isTeacher()||!Array.isArray(records))return false;
  const changes=[];
  for(const record of records){
   if(!uid(record?.uid)||typeof record.revision!=='string'||record.revision.length>100||typeof record.photo!=='string'||record.photo.length>160000||record.photo!==''&&!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(record.photo))continue;
   for(const s of state.students.filter(s=>s.firebaseUid===record.uid))if(s.photoRemoteRevision!==record.revision){changes.push({s,previous:{photoDataUrl:s.photoDataUrl,photoRemoteRevision:s.photoRemoteRevision,photoRemoteAt:s.photoRemoteAt}});s.photoDataUrl=record.photo;s.photoRemoteRevision=record.revision;s.photoRemoteAt=record.updatedAt}
  }
  if(!changes.length)return true;
  try{save();if(typeof renderStudentProfile==='function'&&currentProfileStudentId)renderStudentProfile();return true}
  catch(_){for(const {s,previous}of changes)Object.assign(s,previous);try{renderStudents();if(currentProfileStudentId)renderStudentProfile()}catch(_){}return false}
 };
})();
