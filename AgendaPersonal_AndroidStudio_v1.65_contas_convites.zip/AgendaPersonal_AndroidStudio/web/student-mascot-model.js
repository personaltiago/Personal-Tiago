(function(global){
 'use strict';
 // Virtual rewards only. The same execution document owns the training record
 // and this ledger, so a failed save cannot grant a reward without a workout.
 const legacyCatalog=[
  {id:'fruit',name:'Cestinha de frutas',kind:'food',price:25,copy:'Um lanche para o seu companheiro.'},
  {id:'bowl',name:'Comidinha da casa',kind:'food',price:35,copy:'Sirva uma refeição ao seu mascote.'},
  {id:'ball',name:'Bola de brincar',kind:'toy',price:80,copy:'Um brinquedo para usar sempre.'},
  {id:'band',name:'Faixa esportiva',kind:'head',price:120,copy:'Um detalhe nas cores do seu app.'},
  {id:'shirt',name:'Camiseta de treino',kind:'body',price:180,copy:'Uma camiseta feita para cada fase.'},
  {id:'hoodie',name:'Moletom confortável',kind:'body',price:260,copy:'Para os momentos de descanso.'},
  {id:'home-yard',name:'Quintal com casinha',kind:'home',price:0,copy:'Gramado, cerca de madeira e uma casinha acolhedora.'},
  {id:'home-bamboo',name:'Bambuzal',kind:'home',price:200,copy:'Um refúgio verde entre os bambus.'},
  {id:'home-forest',name:'Floresta',kind:'home',price:300,copy:'Árvores altas e uma clareira tranquila.'},
  {id:'home-lake',name:'Lago das capivaras',kind:'home',price:350,copy:'Água calma e um cantinho à sombra.'},
  {id:'home-cabin',name:'Cabana na serra',kind:'home',price:450,copy:'Madeira, montanhas e luz de fim de tarde.'},
  {id:'home-night',name:'Jardim ao luar',kind:'home',price:500,copy:'Um jardim iluminado pela lua e pelas estrelas.'}
 ];
 // Natural coat designs are specific to each species. A design key selects
 // its separately drawn portraits; null retains the original approved portrait.
 const coat=(id,name,swatch,frame=null)=>Object.freeze({id,name,swatch,frame});
 const coats=Object.freeze({
  wolf:Object.freeze([coat('original','Cinza clássico','#90918f'),coat('black','Negro','#292823',0),coat('white','Branco ártico','#f0eee4',1),coat('sand','Areia','#c8aa76',2),coat('brown','Castanho','#8f5b39',4)]),
  alligator:Object.freeze([coat('original','Verde','#527b37',0),coat('olive','Oliva','#747544',1),coat('sand','Amarelo areia','#c7a351',2),coat('dark','Escuro','#3a403c',3),coat('ivory','Marfim','#e6dcc3',4)]),
  panda:Object.freeze([coat('original','Preto e branco','#b2ada1'),coat('white','Todo branco','#f0eee5',0),coat('black','Todo preto','#302a26',1),coat('brown','Castanho e branco','#8c6550',2),coat('cream','Creme','#e2c99f',3),coat('cinnamon','Canela','#985b37',4)]),
  kitten:Object.freeze([coat('original','Bicolor clássico','#b5a293'),coat('black','Preto','#2d2a29',0),coat('white','Branco','#f0ede6',1),coat('ginger','Laranja tigrado','#c48b4a',2),coat('tabby','Cinza tigrado','#8d8a85',3),coat('calico','Tricolor','#ae835c',4)]),
  capybara:Object.freeze([coat('original','Caramelo','#bc8852'),coat('chocolate','Chocolate','#78533c',1),coat('sand','Areia','#c6ad84',2),coat('ash','Pardo','#8a7e6b',3),coat('ivory','Creme','#ded0ad',4)]),
  rooster:Object.freeze([coat('original','Cobre','#b67537'),coat('white','Branco','#e8e2d5',0),coat('black','Preto','#2c332f',1),coat('barred','Carijó','#8c8b85',3),coat('buff','Dourado','#c8a56b',4)])
 });
 const aliases=Object.freeze({wolf:{red:'brown',blue:'original',gold:'sand',violet:'original'},alligator:{black:'dark',red:'sand',blue:'olive',gold:'sand',violet:'original'},panda:{red:'cinnamon',blue:'original',gold:'cream',violet:'brown'},kitten:{red:'ginger',blue:'tabby',gold:'ginger',violet:'calico'},capybara:{black:'chocolate',red:'chocolate',blue:'ash',gold:'sand',violet:'ivory'},rooster:{red:'original',blue:'barred',gold:'buff',violet:'white'}});
 const colorsFor=species=>Object.hasOwn(coats,species)?coats[species]:[];
 const colorId=(species,id)=>colorsFor(species).some(c=>c.id===id)?id:Object.hasOwn(aliases[species]||{},id)?aliases[species][id]:'original';
 const color=s=>colorsFor(s?.species).find(c=>c.id===colorId(s?.species,s?.colors?.[s?.species]))||coat('original','Original','#b5a293');
 const int=(n,max=100000000)=>Number.isSafeInteger(n)&&n>=0?Math.min(n,max):0;
 const goal=n=>Number.isInteger(n)&&n>=1&&n<=7?n:3;
 const choices=Object.freeze([{id:'capybara',name:'Capivara'},{id:'alligator',name:'Jacaré'},{id:'panda',name:'Panda'},{id:'rooster',name:'Galo'},{id:'kitten',name:'Gato'},{id:'wolf',name:'Lobo'}]);
 const poseSpec=Object.freeze({
  wolf:[['sit','Sentado','Atento, com a cauda junto às patas.'],['rest','Deitado','Descansando com as patas à frente.'],['play','Barriga para cima','À vontade, com as patinhas levantadas.']],
  kitten:[['sit','Sentado','Sentadinho com a cauda junto às patas.'],['rest','Enroladinho','Dormindo aconchegado na própria cauda.'],['play','Barriga para cima','Relaxado, mostrando as almofadinhas.']],
  panda:[['sit','Sentado','Patas para a frente e um descanso tranquilo.'],['rest','De ladinho','Aconchegado, descansando de lado.']],
  capybara:[['sit','Sentada','Tranquila, sentadinha no seu cantinho.'],['rest','Descansando','Deitadinha com as patas recolhidas.'],['play','Espreguiçando','Um alongamento tranquilo para acordar.']],
  alligator:[['sit','Esfinge','Peito erguido e cauda apoiada ao lado.'],['rest','Relaxando','Deitado baixinho, com as patas relaxadas.'],['play','Brincando','De barriga para cima, com a cauda curvada.']],
  rooster:[['sit','Descansando','Asas fechadas e patinhas recolhidas.'],['rest','Asas abertas','Exibindo as penas em um belo alongamento.'],['play','Cantando','Peito erguido e bico aberto para cantar.']]
 });
 const poseItemId=(species,id)=>'pose-'+species+'-'+id;
 const posesFor=species=>Object.hasOwn(poseSpec,species)?[{id:'default',name:'Pose original',copy:'A posição clássica do seu companheiro.',price:0},...poseSpec[species].map(([id,name,copy],i)=>({id,name,copy,price:[80,120,180][i],itemId:poseItemId(species,id)}))]:[];
 const pose=s=>posesFor(s?.species).find(p=>p.id!=='default'&&p.id===s?.poses?.[s.species]&&Array.isArray(s?.owned)&&s.owned.includes(p.itemId))||{id:'default',name:'Pose original',price:0};
 const catalog=Object.freeze([...legacyCatalog,...choices.flatMap(c=>posesFor(c.id).filter(p=>p.id!=='default').map(p=>({id:p.itemId,name:p.name,copy:p.copy,price:p.price,kind:'pose',species:c.id,pose:p.id})))]);
 const dateKey=t=>{const d=new Date(t);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
 function weekKey(t){const d=new Date(t);d.setHours(12,0,0,0);d.setDate(d.getDate()-d.getDay());return dateKey(d)}
 function fresh(weeklyGoal=3){return {schema:1,species:'',name:'Nino',goal:goal(weeklyGoal),xp:0,coins:0,colors:{},poses:{},owned:['home-yard'],food:{fruit:0,bowl:0},equipped:{head:'',body:'',home:'home-yard'},rewards:[],weeks:{},events:[],messageRotation:{}}}
 function read(value,weeklyGoal=3){
  if(!value||value.schema!==1)return fresh(weeklyGoal);
  const s=fresh(value.goal);s.name=String(value.name||'Nino').trim().slice(0,24)||'Nino';s.xp=int(value.xp);s.coins=int(value.coins);
  // Legacy data had no species; keep its capybara until the student chooses.
  s.species=value.species===undefined?'capybara':choices.some(c=>c.id===value.species)||value.species==='capybara'?value.species:'';
  for(const c of choices){const id=colorId(c.id,value.colors?.[c.id]);if(id!=='original')s.colors[c.id]=id}
  const owned=Array.isArray(value.owned)?value.owned:[];
  s.owned=catalog.filter(i=>i.kind!=='food'&&(i.id==='home-yard'||owned.includes(i.id))).map(i=>i.id);
  // Retired artwork is unavailable; retain its purchase record without re-equipping it.
  if(owned.includes('pose-panda-play'))s.owned.push('pose-panda-play');
  for(const c of choices){const p=posesFor(c.id).find(p=>p.id===value.poses?.[c.id]&&p.id!=='default');if(p&&s.owned.includes(p.itemId))s.poses[c.id]=p.id}
  for(const id of ['fruit','bowl'])s.food[id]=int(value.food?.[id],99);
  for(const slot of ['head','body'])s.equipped[slot]=s.owned.includes(value.equipped?.[slot])&&catalog.find(i=>i.id===value.equipped[slot])?.kind===slot?value.equipped[slot]:'';
  s.equipped.home=s.owned.includes(value.equipped?.home)&&catalog.find(i=>i.id===value.equipped.home)?.kind==='home'?value.equipped.home:'home-yard';
  s.rewards=Array.isArray(value.rewards)?value.rewards.filter(r=>r&&typeof r.key==='string'&&typeof r.day==='string'&&typeof r.week==='string'&&Number.isSafeInteger(r.xp)&&r.xp>=0).map(r=>({...r})):[];
  if(value.weeks&&typeof value.weeks==='object')for(const [key,w]of Object.entries(value.weeks)){if(/^\d{4}-\d{2}-\d{2}$/.test(key)&&w&&Number.isInteger(w.goal)&&w.goal>=1&&w.goal<=7)s.weeks[key]={goal:w.goal,count:int(w.count,7)}}
  s.events=Array.isArray(value.events)?value.events.filter(e=>e&&typeof e.text==='string'&&Number.isFinite(e.at)).slice(0,40).map(e=>({text:e.text.slice(0,180),at:e.at})):[];
  for(const kind of ['increased','maintained','decreased']){const r=value.messageRotation?.[kind];if(r)s.messageRotation[kind]={used:[...new Set((Array.isArray(r.used)?r.used:[]).filter(i=>Number.isInteger(i)&&i>=0&&i<25))],last:Number.isInteger(r.last)&&r.last>=0&&r.last<25?r.last:-1}}
  return s;
 }
 function event(s,text,at){s.events.unshift({text,at});s.events=s.events.slice(0,40)}
 function reward(value,record,weeklyGoal=3){
  const s=read(value,weeklyGoal),t=record?.finishedAt,start=record?.startedAt;
  if(!Number.isFinite(t)||!Number.isFinite(start)||!Number.isFinite(new Date(t).getTime())||t<start||record.incomplete!==false||!record.id||!Array.isArray(record.exerciseRecords)||!record.exerciseRecords.length||record.exerciseRecords.some(e=>!e||!Array.isArray(e.done)||!e.done.length||e.done.some(x=>x!==true)))return {state:s,reason:'incomplete',xp:0,coins:0};
  const key=String(record.id)+':'+start,day=dateKey(t),week=weekKey(t);
  if(s.rewards.some(r=>r.key===key))return {state:s,reason:'duplicate',xp:0,coins:0};
  if(s.rewards.some(r=>r.day===day))return {state:s,reason:'day',xp:0,coins:0};
  const w=s.weeks[week]||(s.weeks[week]={goal:s.goal,count:0});
  if(w.count>=w.goal)return {state:s,reason:'week',xp:0,coins:0};
  const xp=Math.floor(300*(w.count+1)/w.goal)-Math.floor(300*w.count/w.goal);w.count++;
  s.xp+=xp;s.coins+=100;s.rewards.push({key,day,week,xp,coins:100});
  event(s,'Treino concluído · +'+xp+' XP · +100 moedas',t);
  return {state:s,reason:'earned',xp,coins:100};
 }
 function change(value,action,id,at=Date.now()){
  const s=read(value),item=catalog.find(i=>i.id===id);
  if(action==='species'){if(!choices.some(c=>c.id===id))return {ok:false,error:'Escolha um dos mascotes disponíveis.'};s.species=id;return {ok:true,state:s,message:choices.find(c=>c.id===id).name+' escolhido. Seu progresso continua.'}}
  if(action==='color'){if(!choices.some(c=>c.id===s.species)||!colorsFor(s.species).some(c=>c.id===id))return {ok:false,error:'Escolha um mascote e uma cor disponível.'};if(id==='original')delete s.colors[s.species];else s.colors[s.species]=id;return {ok:true,state:s,message:color(s).name+' aplicado a '+s.name+'.'}}
  if(action==='pose'){const p=posesFor(s.species).find(p=>p.id===id);if(!p)return {ok:false,error:'Escolha uma pose deste mascote.'};if(id!=='default'&&!s.owned.includes(p.itemId))return {ok:false,error:'Compre esta pose na loja primeiro.'};if(id==='default')delete s.poses[s.species];else s.poses[s.species]=id;return {ok:true,state:s,message:p.name+' aplicada a '+s.name+'.'}}
  if(action==='name'){const name=String(id||'').trim();if(!name||name.length>24)return {ok:false,error:'Escolha um nome de até 24 caracteres.'};s.name=name;return {ok:true,state:s}}
  if(action==='goal'){if(!Number.isInteger(Number(id))||Number(id)<1||Number(id)>7)return {ok:false,error:'Escolha uma meta entre 1 e 7 treinos.'};s.goal=Number(id);return {ok:true,state:s}}
  if(action==='remove'){if(!['head','body'].includes(id))return {ok:false};s.equipped[id]='';return {ok:true,state:s}}
  if(!item)return {ok:false,error:'Item não encontrado.'};
  if(action==='buy'){
   if(item.kind==='pose'&&item.species!==s.species)return {ok:false,error:'Esta pose pertence a outro mascote.'};
   if(item.kind!=='food'&&s.owned.includes(id))return {ok:false,error:item.kind==='home'?'Essa casa já é sua. Você pode aplicá-la sem gastar novamente.':item.kind==='pose'?'Essa pose já é sua. Você pode usá-la sem gastar novamente.':'Esse item já está no seu guarda-roupa.'};
   if(item.kind==='food'&&s.food[id]>=99)return {ok:false,error:'Você já tem 99 unidades deste item.'};
   if(s.coins<item.price)return {ok:false,error:'Você ainda não tem moedas suficientes.'};
   s.coins-=item.price;if(item.kind==='food')s.food[id]++;else s.owned.push(id);
   event(s,item.name+' · −'+item.price+' moedas',at);if(item.kind==='pose'){s.poses[s.species]=item.pose;return {ok:true,state:s,message:item.name+' comprada e aplicada.'}}return {ok:true,state:s,message:item.name+' comprado.'};
  }
  if(action==='use'){
   if(item.kind==='food'){if(!s.food[id])return {ok:false,error:'Compre esse alimento na loja.'};s.food[id]--;event(s,'Serviu '+item.name.toLocaleLowerCase('pt-BR'),at);return {ok:true,state:s,message:s.name+' adorou a comidinha!',reaction:'food'}}
   if(!s.owned.includes(id))return {ok:false,error:'Você ainda não tem esse item.'};
   if(item.kind==='pose')return item.species===s.species?change(s,'pose',item.pose,at):{ok:false,error:'Esta pose pertence a outro mascote.'};
   if(item.kind==='toy')return {ok:true,state:s,message:s.name+' está brincando!',reaction:'play'};
   s.equipped[item.kind]=id;return {ok:true,state:s,message:item.kind==='home'?item.name+' aplicado à casa de '+s.name+'.':item.name+' equipado.'};
  }
  return {ok:false};
 }
 function phase(xp){return xp>=1800?{id:'adult',name:'Adulto',start:1800,end:null}:xp>=600?{id:'teen',name:'Adolescente',start:600,end:1800}:{id:'baby',name:'Filhote',start:0,end:600}}
 global.APMascotModel=Object.freeze({catalog,choices,colorsFor,color,posesFor,pose,fresh,read,reward,change,phase,weekKey,dateKey});
})(globalThis);
