(function(global){
 'use strict';
 // Virtual rewards only. The same execution document owns the training record
 // and this ledger, so a failed save cannot grant a reward without a workout.
 const catalog=Object.freeze([
  {id:'fruit',name:'Cestinha de frutas',kind:'food',price:25,copy:'Um lanche para o seu companheiro.'},
  {id:'bowl',name:'Comidinha da casa',kind:'food',price:35,copy:'Sirva uma refeição ao seu mascote.'},
  {id:'ball',name:'Bola de brincar',kind:'toy',price:80,copy:'Um brinquedo para usar sempre.'},
  {id:'band',name:'Faixa esportiva',kind:'head',price:120,copy:'Um detalhe nas cores do seu app.'},
  {id:'shirt',name:'Camiseta de treino',kind:'body',price:180,copy:'Uma camiseta feita para cada fase.'},
  {id:'hoodie',name:'Moletom confortável',kind:'body',price:260,copy:'Para os momentos de descanso.'}
 ]);
 const int=(n,max=100000000)=>Number.isSafeInteger(n)&&n>=0?Math.min(n,max):0;
 const goal=n=>Number.isInteger(n)&&n>=1&&n<=7?n:3;
 const choices=Object.freeze([{id:'capybara',name:'Capivara'},{id:'alligator',name:'Jacaré roxo'},{id:'panda',name:'Panda'},{id:'rooster',name:'Galo'},{id:'kitten',name:'Gato'},{id:'wolf',name:'Lobo'}]);
 const dateKey=t=>{const d=new Date(t);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
 function weekKey(t){const d=new Date(t);d.setHours(12,0,0,0);d.setDate(d.getDate()-d.getDay());return dateKey(d)}
 function fresh(weeklyGoal=3){return {schema:1,species:'',name:'Nino',goal:goal(weeklyGoal),xp:0,coins:0,owned:[],food:{fruit:0,bowl:0},equipped:{head:'',body:''},rewards:[],weeks:{},events:[],messageRotation:{}}}
 function read(value,weeklyGoal=3){
  if(!value||value.schema!==1)return fresh(weeklyGoal);
  const s=fresh(value.goal);s.name=String(value.name||'Nino').trim().slice(0,24)||'Nino';s.xp=int(value.xp);s.coins=int(value.coins);
  // Legacy data had no species; keep its capybara until the student chooses.
  s.species=value.species===undefined?'capybara':choices.some(c=>c.id===value.species)||value.species==='capybara'?value.species:'';
  const owned=Array.isArray(value.owned)?value.owned:[];
  s.owned=catalog.filter(i=>i.kind!=='food'&&owned.includes(i.id)).map(i=>i.id);
  for(const id of ['fruit','bowl'])s.food[id]=int(value.food?.[id],99);
  for(const slot of ['head','body'])s.equipped[slot]=s.owned.includes(value.equipped?.[slot])&&catalog.find(i=>i.id===value.equipped[slot])?.kind===slot?value.equipped[slot]:'';
  s.rewards=Array.isArray(value.rewards)?value.rewards.filter(r=>r&&typeof r.key==='string'&&typeof r.day==='string'&&typeof r.week==='string'&&Number.isSafeInteger(r.xp)&&r.xp>=0).map(r=>({...r})):[];
  if(value.weeks&&typeof value.weeks==='object')for(const [key,w]of Object.entries(value.weeks)){if(/^\d{4}-\d{2}-\d{2}$/.test(key)&&w&&Number.isInteger(w.goal)&&w.goal>=1&&w.goal<=7)s.weeks[key]={goal:w.goal,count:int(w.count,7)}}
  s.events=Array.isArray(value.events)?value.events.filter(e=>e&&typeof e.text==='string'&&Number.isFinite(e.at)).slice(0,40).map(e=>({text:e.text.slice(0,180),at:e.at})):[];
  for(const kind of ['increased','maintained','decreased']){const r=value.messageRotation?.[kind];if(r)s.messageRotation[kind]={used:[...new Set((Array.isArray(r.used)?r.used:[]).filter(i=>Number.isInteger(i)&&i>=0&&i<25))],last:Number.isInteger(r.last)&&r.last>=0&&r.last<25?r.last:-1}}
  return s;
 }
 function event(s,text,at){s.events.unshift({text,at});s.events=s.events.slice(0,40)}
 function reward(value,record,weeklyGoal=3){
  const s=read(value,weeklyGoal),t=record?.finishedAt,start=record?.startedAt;
  if(!Number.isFinite(t)||!Number.isFinite(start)||!Number.isFinite(new Date(t).getTime())||t<start||record.incomplete!==false||!record.id||!Array.isArray(record.exerciseRecords)||!record.exerciseRecords.length||record.exerciseRecords.some(e=>!e||!Array.isArray(e.done)||!e.done.length||e.done.some(x=>x!==true)))return {state:s,reason:'incomplete',xp:0,coins:0};
  const key=String(record.id)+':'+start,day=dateKey(t),week=weekKey(t);
  if(s.rewards.some(r=>r.key===key))return {state:s,reason:'duplicate',xp:0,coins:0};
  if(s.rewards.some(r=>r.day===day))return {state:s,reason:'day',xp:0,coins:0};
  const w=s.weeks[week]||(s.weeks[week]={goal:s.goal,count:0});
  if(w.count>=w.goal)return {state:s,reason:'week',xp:0,coins:0};
  const xp=Math.floor(300*(w.count+1)/w.goal)-Math.floor(300*w.count/w.goal);w.count++;
  s.xp+=xp;s.coins+=100;s.rewards.push({key,day,week,xp,coins:100});
  event(s,'Treino concluído · +'+xp+' XP · +100 moedas',t);
  return {state:s,reason:'earned',xp,coins:100};
 }
 function change(value,action,id,at=Date.now()){
  const s=read(value),item=catalog.find(i=>i.id===id);
  if(action==='species'){if(!choices.some(c=>c.id===id))return {ok:false,error:'Escolha um dos mascotes disponíveis.'};s.species=id;return {ok:true,state:s,message:choices.find(c=>c.id===id).name+' escolhido. Seu progresso continua.'}}
  if(action==='name'){const name=String(id||'').trim();if(!name||name.length>24)return {ok:false,error:'Escolha um nome de até 24 caracteres.'};s.name=name;return {ok:true,state:s}}
  if(action==='goal'){if(!Number.isInteger(Number(id))||Number(id)<1||Number(id)>7)return {ok:false,error:'Escolha uma meta entre 1 e 7 treinos.'};s.goal=Number(id);return {ok:true,state:s}}
  if(action==='remove'){if(!['head','body'].includes(id))return {ok:false};s.equipped[id]='';return {ok:true,state:s}}
  if(!item)return {ok:false,error:'Item não encontrado.'};
  if(action==='buy'){
   if(item.kind!=='food'&&s.owned.includes(id))return {ok:false,error:'Esse item já está no seu guarda-roupa.'};
   if(item.kind==='food'&&s.food[id]>=99)return {ok:false,error:'Você já tem 99 unidades deste item.'};
   if(s.coins<item.price)return {ok:false,error:'Você ainda não tem moedas suficientes.'};
   s.coins-=item.price;if(item.kind==='food')s.food[id]++;else s.owned.push(id);
   event(s,item.name+' · −'+item.price+' moedas',at);return {ok:true,state:s,message:item.name+' comprado.'};
  }
  if(action==='use'){
   if(item.kind==='food'){if(!s.food[id])return {ok:false,error:'Compre esse alimento na loja.'};s.food[id]--;event(s,'Serviu '+item.name.toLocaleLowerCase('pt-BR'),at);return {ok:true,state:s,message:s.name+' adorou a comidinha!',reaction:'food'}}
   if(!s.owned.includes(id))return {ok:false,error:'Você ainda não tem esse item.'};
   if(item.kind==='toy')return {ok:true,state:s,message:s.name+' está brincando!',reaction:'play'};
   s.equipped[item.kind]=id;return {ok:true,state:s,message:item.name+' equipado.'};
  }
  return {ok:false};
 }
 function phase(xp){return xp>=1800?{id:'adult',name:'Adulto',start:1800,end:null}:xp>=600?{id:'teen',name:'Adolescente',start:600,end:1800}:{id:'baby',name:'Filhote',start:0,end:600}}
 global.APMascotModel=Object.freeze({catalog,choices,fresh,read,reward,change,phase,weekKey,dateKey});
})(globalThis);
