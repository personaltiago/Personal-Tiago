(function(global){
 'use strict';
 // Replaced during the build with the six verified, offline WebP scenes.
 let scenes=/*AP_MASCOT_HOME_ASSETS*/{},hydrated=false;
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 10 9-7 9 7M5 9v12h14V9M9 21v-7h6v7"/></svg>';
 const mouths={kitten:[.51,.34,.28],wolf:[.45,.38,.29],capybara:[.42,.36,.32],panda:[.50,.42,.31],rooster:[.40,.29,.25],alligator:[.55,.32,.37]};
 const mouth=s=>(mouths[s.species]||[.4,.4,.4])[s.xp>=1800?2:s.xp>=600?1:0];
 const observers=new WeakMap();
 function alignSpeech(node){
  const mark=node.querySelector('.ap-teacher-mascot-mark,.ap-mascot-mini'),speech=node.querySelector('.ap-mascot-speech');if(!mark||!speech)return;
  const face=mark.getBoundingClientRect(),bubble=speech.getBoundingClientRect();if(!face.height||!bubble.height)return;
  const ratio=Number(node.style.getPropertyValue('--pet-mouth'))||.4;
  speech.style.setProperty('--bubble-tail-y',Math.max(8,Math.min(bubble.height-18,face.top+face.height*ratio-bubble.top-5))+'px');
 }
 // Full images share the existing local registration payload with the pets.
 // Tiny previews keep first paint immediate and the installed 2 MiB shell limit.
 function hydrate(doc){
  if(hydrated)return true;
  try{const node=doc.getElementById('ap-mascot-home-assets');if(!node)return false;const data=JSON.parse(node.textContent),ids=['yard','bamboo','forest','lake','cabin','night'].map(n=>'home-'+n);
   if(ids.some(id=>!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(data[id]||'')))return false;
   scenes=Object.fromEntries(ids.map(id=>[id,data[id]]));hydrated=true;global.dispatchEvent(new Event('ap-mascot-homes-ready'));return true;
  }catch(_){return false}
 }
 function scene(id){return Object.hasOwn(scenes,id)?scenes[id]:scenes['home-yard']||''}
 function background(s){return 'linear-gradient(180deg,rgba(9,19,19,.23),rgba(9,19,19,.02) 52%,rgba(9,19,19,.2)),url("'+scene(s.equipped?.home)+'")'}
 function decorate(node,s){if(!node)return;node.classList.add('ap-habitat');node.style.backgroundImage=background(s);node.dataset.mascotHome=s.equipped?.home||'home-yard';node.dataset.mascotSpecies=s.species||'none';node.style.setProperty('--pet-mouth',mouth(s));if(global.ResizeObserver&&!observers.has(node)){const observer=new ResizeObserver(()=>alignSpeech(node));observer.observe(node);observers.set(node,observer)}global.requestAnimationFrame?.(()=>alignSpeech(node))}
 global.APMascotHomes=Object.freeze({scene,background,decorate,icon,mouth,hydrate});
})(globalThis);
