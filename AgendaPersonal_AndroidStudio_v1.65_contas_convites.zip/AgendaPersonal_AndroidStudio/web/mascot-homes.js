(function(global){
 'use strict';
 // Replaced during the build with the six verified, offline WebP scenes.
 let scenes=/*AP_MASCOT_HOME_ASSETS*/{},hydrated=false;
 const icon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 10 9-7 9 7M5 9v12h14V9M9 21v-7h6v7"/></svg>';
 const mouths={kitten:[.51,.34,.28],wolf:[.45,.38,.29],capybara:[.42,.36,.32],panda:[.50,.42,.31],rooster:[.40,.29,.25],alligator:[.55,.32,.37]};
 const mouthsX={kitten:[.55,.35,.26],wolf:[.54,.69,.28],capybara:[.43,.27,.80],panda:[.54,.36,.30],rooster:[.57,.29,.23],alligator:[.76,.23,.21]};
 const mouth=s=>{const raw=(mouths[s.species]||[.4,.4,.4])[s.xp>=1800?2:s.xp>=600?1:0],size=global.APMascotArt?.scale?.(s)??1;return 1-size+size*raw};
 const mouthX=s=>{const landmark=global.APMascotArt?.landmarks?.(s);if(landmark){const size=global.APMascotArt.scale(s);return .5+(landmark.headX-.5)*size}const raw=(mouthsX[s.species]||[.5,.5,.5])[s.xp>=1800?2:s.xp>=600?1:0],x=global.APMascotArt?.mirrored?.(s)?1-raw:raw,size=global.APMascotArt?.scale?.(s)??1;return .5+(x-.5)*size};
 const observers=new WeakMap(),pendingAlignment=new WeakSet();
 function queueAlignment(node){
  if(pendingAlignment.has(node))return;
  const view=node.ownerDocument?.defaultView||global;if(!view.requestAnimationFrame)return;
  pendingAlignment.add(node);view.requestAnimationFrame(()=>{pendingAlignment.delete(node);alignSpeech(node)});
 }
 function alignSpeech(node){
  const mark=node.querySelector('.ap-teacher-mascot-mark,.ap-mascot-mini'),speech=node.querySelector('.ap-mascot-speech');if(!mark||!speech)return;
  let face=mark.getBoundingClientRect(),bubble=speech.getBoundingClientRect();const card=node.getBoundingClientRect();if(!face.height||!bubble.height)return;
  const title=node.querySelector('[data-mascot-name],.ap-mascot-home-copy strong'),name=title?.getBoundingClientRect();
  const minTop=name&&name.right>card.left+48?name.bottom-card.top+8:12;
  // Reserve space for the complete message above the full adult portrait.
  // Every growth phase keeps the same floor; only the balloon follows its head.
  const height=Math.ceil(Math.max(220,minTop+bubble.height+10+face.height+32)),size=height+'px';
  if(!node.dataset.petAffection&&node.style.getPropertyValue('--pet-scene-height')!==size)node.style.setProperty('--pet-scene-height',size);
  face=mark.getBoundingClientRect();const portrait=mark.querySelector('image')?.getBoundingClientRect()||face,head=portrait.top+portrait.height*(Number(node.style.getPropertyValue('--pet-head-top'))||.025);
  const x=face.left+face.width*(Number(node.style.getPropertyValue('--pet-mouth-x'))||.5),left=Math.max(12,Math.min(node.clientWidth-bubble.width-12,Math.max(56,x-card.left-36)));
  speech.style.setProperty('--speech-left',left+'px');speech.style.setProperty('--speech-top',Math.max(minTop,head-card.top-node.clientTop-10-bubble.height)+'px');
  bubble=speech.getBoundingClientRect();
  let tail=node.querySelector('.ap-mascot-speech-tail');
  if(!tail){tail=node.ownerDocument.createElementNS('http://www.w3.org/2000/svg','svg');tail.setAttribute('class','ap-mascot-speech-tail');tail.setAttribute('aria-hidden','true');tail.setAttribute('focusable','false');tail.append(node.ownerDocument.createElementNS('http://www.w3.org/2000/svg','path'));node.append(tail)}
  tail.setAttribute('viewBox','0 0 '+node.clientWidth+' '+node.clientHeight);
  const ox=card.left+node.clientLeft,oy=card.top+node.clientTop,radius=Math.min(36,bubble.height/2,bubble.width/2),tx=(node.dataset.mascotPose&&node.dataset.mascotPose!=='default'?x:portrait.right-Math.min(9,portrait.width*.08))-ox,ty=head+Math.min(12,Math.max(8,portrait.height*.08))-oy;
  const bx=Math.max(bubble.left+radius+10,Math.min(bubble.right-radius-10,tx+ox-8))-ox,by=bubble.bottom-oy;
  const n=v=>Math.round(v*100)/100;
  tail.firstElementChild.setAttribute('d','M '+n(bx-8)+' '+n(by-1)+' C '+n(bx-5)+' '+n(by+7)+' '+n(tx+5)+' '+n(ty-5)+' '+n(tx)+' '+n(ty)+' Q '+n(bx+13)+' '+n(by+10)+' '+n(bx+8)+' '+n(by-1));
 }
 // Full images share the existing local registration payload with the pets.
 // Tiny previews keep first paint immediate and the installed 2 MiB shell limit.
 function hydrate(doc){
  if(hydrated)return true;
  try{const node=doc.getElementById('ap-mascot-home-assets');if(!node)return false;const data=JSON.parse(node.textContent),ids=['yard','bamboo','forest','lake','cabin','night'].map(n=>'home-'+n);
   if(ids.some(id=>!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(data[id]||'')))return false;
   scenes=Object.fromEntries(ids.map(id=>[id,data[id]]));hydrated=true;global.dispatchEvent(new Event('ap-mascot-homes-ready'));return true;
  }catch(_){return false}
 }
 function scene(id){return Object.hasOwn(scenes,id)?scenes[id]:scenes['home-yard']||''}
 function background(s){return 'linear-gradient(180deg,rgba(9,19,19,.23),rgba(9,19,19,.02) 52%,rgba(9,19,19,.2)),url("'+scene(s.equipped?.home)+'")'}
 function decorate(node,s,portrait){if(!node)return;node.classList.add('ap-habitat');node.style.backgroundImage=background(s);node.dataset.mascotHome=s.equipped?.home||'home-yard';node.dataset.mascotSpecies=s.species||'none';node.dataset.mascotPhase=global.APMascotModel.phase(s.xp).id;node.dataset.mascotPose=portrait?'petting':global.APMascotModel.pose?.(s)?.id||'default';node.style.setProperty('--pet-head-top',portrait?.headTop??global.APMascotArt?.landmarks?.(s)?.headTop??.025);node.style.setProperty('--pet-mouth',mouth(s));node.style.setProperty('--pet-mouth-x',portrait?.headX != null ? .5+(portrait.headX-.5)*(global.APMascotArt?.scale?.(s)??1) : mouthX(s));if(global.ResizeObserver&&!observers.has(node)){const observer=new ResizeObserver(()=>queueAlignment(node));observer.observe(node);observers.set(node,observer)}queueAlignment(node)}
 global.APMascotHomes=Object.freeze({scene,background,decorate,icon,mouth,mouthX,hydrate});
})(globalThis);
