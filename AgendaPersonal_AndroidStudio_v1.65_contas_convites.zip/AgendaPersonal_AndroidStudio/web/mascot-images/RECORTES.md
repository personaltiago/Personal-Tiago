# Mascotes no cenário

Edição em modo integrado `imagegen` (background-extraction), um recorte individual para cada mascote/fase. O manifesto preserva a soma SHA-256 dos JPEGs de origem para rastreabilidade. Apenas os 18 recortes finais usados pelo aplicativo acompanham o projeto atual; os JPEGs com fundo foram retirados na limpeza 1.12.111.

Os resultados RGBA foram otimizados para WebP de até 512 × 512 com transparência, para exibição em tamanhos de 88 a 240 px. Não há remoção por cor em tempo de execução, filtros que apagam pelo branco nem acesso a serviços externos.

Os 18 arquivos finais seguem o nome `<espécie>-<fase>-cutout.webp`. Espécies: wolf, kitten, capybara, panda, rooster e alligator. Fases: baby, teen e adult.

Prompt para cada edição (o nome entre colchetes identifica a referência correspondente):

Use case: background-extraction. This supplied [species-phase] is the EDIT TARGET, an approved app mascot. Remove only its entire white/ivory background and all floor/shadows, including the empty gaps between the legs and around tail. Return a clean transparent RGBA cutout, preserving this exact animal and its current growth stage: identical pose, body proportions, expression, eyes, fur/feather/scale colors, complete silhouette, full tail, all feet, tiny whiskers and fine edges. Keep the full body at the same position and scale within the square canvas. Do not redesign, recolor, add accessories, change maturity, crop any body part, or make light-colored fur transparent. All empty space and leftover floor must be fully transparent, with no stray white chunks, no colored fringe, no shadow plane, and no text.

O lobo adulto foi preparado primeiro com a mesma orientação de extração: preservar o animal, a pose, as cores, o corpo completo e os pelos, removendo apenas o fundo e o piso para um recorte RGBA transparente.
