function availabilityMonthRange(month){
 if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)||!validWorkoutDate(month+'-01'))return null;
 const start=parseDate(month+'-01'),last=new Date(start);last.setMonth(start.getMonth()+1);last.setDate(0);
 return {month,from:iso(start),daysCount:last.getDate()};
}
function automaticAvailabilityQuery(silent=true){
 const get=id=>document.getElementById(id).value,mode=document.querySelector('.avail-tab.active')?.dataset.availMode||'time';
 const start=get(mode==='time'?'availabilityStart':'availabilityDayStart'),end=get(mode==='time'?'availabilityEnd':'availabilityDayEnd'),range=mode==='time'?availabilityMonthRange(get('availabilityMonth')):null,date=mode==='day'?get('availabilityDate'):'',duration=Number(get('availabilityDuration'));
 let error='';
 if(!availabilityTimeValid(start)||!availabilityTimeValid(end)||timeToMinutes(end)<=timeToMinutes(start))error='Informe um horário final depois do início.';
 else if(mode==='time'?!range:!validWorkoutDate(date))error=mode==='time'?'Escolha um mês válido para a consulta.':'Confira a data da consulta.';
 else if(mode==='day'&&(![30,45,60,90,120].includes(duration)||timeToMinutes(end)-timeToMinutes(start)<duration))error='O intervalo precisa comportar a duração da aula.';
 if(error){if(!silent)toast(error,5000);return {error}}
 return mode==='time'?{mode,start,end,...range}:{mode,date,start,end,duration};
}
function renderAvailabilityMonthCaption(search){
 const caption=parseDate(search.from).toLocaleDateString('pt-BR',{month:'long',year:'numeric'}),title=caption.charAt(0).toUpperCase()+caption.slice(1);
 return `<p class="availability-month-caption" data-availability-month="${search.month}">${hesc(title)} · ${search.daysCount} dias</p>`;
}
