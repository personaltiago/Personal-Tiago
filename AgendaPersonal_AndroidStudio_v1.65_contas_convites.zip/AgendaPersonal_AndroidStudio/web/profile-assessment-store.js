async function readEvaluationWorkspace(){
  const fallback=()=>{
    const raw=localStorage.getItem(EVALUATION_DB_KEY);
    if(!raw)return {clients:[]};
    const stored=JSON.parse(raw);
    if(!stored||!Array.isArray(stored.clients))throw new Error('Histórico de avaliações inválido.');
    return stored;
  };
  const db=await openExistingEvaluationDb();
  let workspace;
  if(db){
    try{
      if(!db.objectStoreNames.contains('records'))throw new Error('Histórico indisponível.');
      workspace=await new Promise((resolve,reject)=>{
        const tx=db.transaction('records','readonly'),req=tx.objectStore('records').get('workspace');
        req.onsuccess=()=>resolve(req.result);
        req.onerror=()=>reject(new Error('Não foi possível ler as avaliações.'));
        tx.onabort=()=>reject(new Error('A leitura das avaliações foi interrompida.'));
      });
    }finally{db.close()}
  }
  // Match the assessment module's fallback without creating, linking or copying records.
  if(workspace==null)workspace=fallback();
  if(!workspace||!Array.isArray(workspace.clients))throw new Error('Histórico de avaliações inválido.');
  return workspace;
}
async function evaluationClientForStudent(s){
  const workspace=await readEvaluationWorkspace();
  const explicit=workspace.clients.filter(client=>client.agendaStudentId===s.id);
  if(explicit.length>1)throw new Error('Há mais de um histórico vinculado. Confira na área de avaliações.');
  return linkedEvaluationClient(workspace.clients,s);
}
