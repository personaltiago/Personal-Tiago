let trainerPhotoDraft='',trainerPhotoSourceDraft='',trainerPhotoCropDraft=null,trainerCropSession=null,trainerPhotoReadId=0;
function updateTrainerPhotoPreview(){
 const photo=document.getElementById('trainerPhotoPreview');
 photo.classList.toggle('trainer-reference-photo',!trainerPhotoDraft);
 photo.innerHTML=trainerPhotoDraft?`<img src="${hesc(trainerPhotoDraft)}" alt="Foto do perfil">`:'';
 document.getElementById('trainerPhotoAdjust').hidden=!trainerPhotoDraft;
}
function resetTrainerPhoto(){trainerPhotoReadId++;trainerPhotoDraft='';trainerPhotoSourceDraft='';trainerPhotoCropDraft=null;updateTrainerPhotoPreview()}
function openTrainerProfile(){
 navigateToScreen('more');const profile=trainerProfile(),stored=state.trainerProfile||{};
 document.getElementById('trainerName').value=profile.name;document.getElementById('trainerSubtitle').value=profile.subtitle;
 document.getElementById('trainerCref').value=profile.cref;
 trainerPhotoDraft=profile.photoDataUrl;trainerPhotoSourceDraft=stored.photoSourceDataUrl||profile.photoDataUrl;trainerPhotoCropDraft=stored.photoCrop||null;
 trainerPhotoReadId++;document.getElementById('trainerPhotoInput').value='';updateTrainerPhotoPreview();openDialog('trainerProfileDialog');
}
function trainerReadImage(source){return new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>image.naturalWidth&&image.naturalHeight?resolve(image):reject(Error('invalid image'));image.onerror=()=>reject(Error('invalid image'));image.src=source})}
function trainerReadFile(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result||''));reader.onerror=()=>reject(Error('read failed'));reader.readAsDataURL(file)})}
function trainerCanvas(width,height){const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;return canvas}
function trainerCropClamp(session){
 const maxRadius=Math.min(session.image.naturalWidth,session.image.naturalHeight)/2;
 session.zoom=Math.max(1,Math.min(5,Number(session.zoom)||1));session.radius=maxRadius/session.zoom;
 session.x=Math.max(session.radius,Math.min(session.image.naturalWidth-session.radius,session.x));
 session.y=Math.max(session.radius,Math.min(session.image.naturalHeight-session.radius,session.y));return session;
}
function drawTrainerCrop(){
 const s=trainerCropSession;if(!s)return;trainerCropClamp(s);
 const canvas=document.getElementById('trainerCropCanvas'),c=canvas.getContext('2d'),W=canvas.width,H=canvas.height;
 const scale=Math.min((W-32)/s.image.naturalWidth,(H-32)/s.image.naturalHeight),w=s.image.naturalWidth*scale,h=s.image.naturalHeight*scale,left=(W-w)/2,top=(H-h)/2;
 s.viewport={scale,left,top};const x=left+s.x*scale,y=top+s.y*scale,r=s.radius*scale;
 c.clearRect(0,0,W,H);c.fillStyle='#08070c';c.fillRect(0,0,W,H);c.drawImage(s.image,left,top,w,h);
 c.save();c.beginPath();c.rect(0,0,W,H);c.arc(x,y,r,0,Math.PI*2,true);c.fillStyle='rgba(5,3,10,.65)';c.fill('evenodd');c.restore();
 c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.strokeStyle='#fff';c.lineWidth=3;c.stroke();
 c.save();c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.clip();c.beginPath();for(const d of [-1/3,1/3]){c.moveTo(x-r,y+r*d);c.lineTo(x+r,y+r*d);c.moveTo(x+r*d,y-r);c.lineTo(x+r*d,y+r)}c.strokeStyle='rgba(255,255,255,.25)';c.lineWidth=1;c.stroke();c.restore();
 document.getElementById('trainerCropZoom').value=String(s.zoom);
 document.getElementById('trainerCropZoomValue').textContent=Number(s.zoom.toFixed(2))+'×';
}
async function startTrainerCrop(source,crop=null){
 const id=++trainerPhotoReadId;
 try{const image=await trainerReadImage(source);if(id!==trainerPhotoReadId||!document.getElementById('trainerProfileDialog').classList.contains('open'))return;
  trainerCropSession={source,image,x:Number.isFinite(crop?.x)?crop.x*image.naturalWidth:image.naturalWidth/2,y:Number.isFinite(crop?.y)?crop.y*image.naturalHeight:image.naturalHeight/2,zoom:crop?.zoom||1,pointer:null};
  openDialog('trainerPhotoCropDialog');drawTrainerCrop();document.getElementById('trainerCropCanvas').focus();
 }catch(_){if(id===trainerPhotoReadId)toast('Não foi possível abrir a foto. Escolha outra imagem.')}
}
function adjustTrainerPhoto(){if(trainerPhotoDraft)startTrainerCrop(trainerPhotoSourceDraft||trainerPhotoDraft,trainerPhotoCropDraft)}
document.getElementById('trainerPhotoInput').onchange=async event=>{
 const file=event.target.files?.[0];event.target.value='';if(!file)return;
 if(!['image/png','image/jpeg','image/webp'].includes(file.type))return toast('Escolha uma foto JPG, PNG ou WebP.');
 if(file.size>8*1024*1024)return toast('Escolha uma foto com até 8 MB.');
 const id=++trainerPhotoReadId;
 try{const raw=await trainerReadFile(file),image=await trainerReadImage(raw);if(id!==trainerPhotoReadId)return;
  const ratio=Math.min(1,1200/Math.max(image.naturalWidth,image.naturalHeight)),canvas=trainerCanvas(Math.max(1,Math.round(image.naturalWidth*ratio)),Math.max(1,Math.round(image.naturalHeight*ratio))),c=canvas.getContext('2d');
  c.fillStyle='#08070c';c.fillRect(0,0,canvas.width,canvas.height);c.drawImage(image,0,0,canvas.width,canvas.height);
  await startTrainerCrop(canvas.toDataURL('image/jpeg',.86));
 }catch(_){if(id===trainerPhotoReadId)toast('Não foi possível abrir a foto. Escolha outra imagem.')}
};
const trainerCropCanvas=document.getElementById('trainerCropCanvas');
function moveTrainerCrop(event){
 const s=trainerCropSession;if(!s||!s.viewport)return;const box=trainerCropCanvas.getBoundingClientRect(),v=s.viewport;
 const x=((event.clientX-box.left)*trainerCropCanvas.width/box.width-v.left)/v.scale,y=((event.clientY-box.top)*trainerCropCanvas.height/box.height-v.top)/v.scale;
 if(event.type==='pointerdown'){s.pointer=event.pointerId;const inside=Math.hypot(x-s.x,y-s.y)<=s.radius;s.offsetX=inside?s.x-x:0;s.offsetY=inside?s.y-y:0;trainerCropCanvas.setPointerCapture(event.pointerId)}
 if(s.pointer!==event.pointerId)return;s.x=x+s.offsetX;s.y=y+s.offsetY;drawTrainerCrop();event.preventDefault();
}
trainerCropCanvas.addEventListener('pointerdown',moveTrainerCrop);trainerCropCanvas.addEventListener('pointermove',moveTrainerCrop);
for(const type of ['pointerup','pointercancel','lostpointercapture'])trainerCropCanvas.addEventListener(type,event=>{if(trainerCropSession?.pointer===event.pointerId)trainerCropSession.pointer=null});
trainerCropCanvas.addEventListener('keydown',event=>{
 const s=trainerCropSession;if(!s||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();
 const step=Math.min(s.image.naturalWidth,s.image.naturalHeight)*(event.shiftKey?.05:.01);
 s.x+=event.key==='ArrowLeft'?-step:event.key==='ArrowRight'?step:0;s.y+=event.key==='ArrowUp'?-step:event.key==='ArrowDown'?step:0;drawTrainerCrop();
});
document.getElementById('trainerCropZoom').addEventListener('input',event=>{if(trainerCropSession){trainerCropSession.zoom=Number(event.target.value);drawTrainerCrop()}});
document.getElementById('trainerCropApply').onclick=()=>{
 const s=trainerCropSession;if(!s)return;trainerCropClamp(s);
 try{const canvas=trainerCanvas(512,512);canvas.getContext('2d').drawImage(s.image,s.x-s.radius,s.y-s.radius,s.radius*2,s.radius*2,0,0,512,512);
  const result=canvas.toDataURL('image/jpeg',.9);trainerPhotoDraft=result;trainerPhotoSourceDraft=s.source;trainerPhotoCropDraft={x:s.x/s.image.naturalWidth,y:s.y/s.image.naturalHeight,zoom:s.zoom};
  updateTrainerPhotoPreview();closeDialog('trainerPhotoCropDialog');trainerCropSession=null;
 }catch(_){toast('Não foi possível recortar a foto. Tente outra imagem.')}
};
document.getElementById('trainerProfileForm').onsubmit=event=>{
 event.preventDefault();const name=document.getElementById('trainerName').value.trim(),subtitle=document.getElementById('trainerSubtitle').value.trim(),cref=document.getElementById('trainerCref').value.trim().replace(/^CREF\s*[:\-]?\s*/i,'').toLocaleUpperCase('pt-BR').slice(0,40);
 if(!name)return toast('Informe seu nome.');
 const previous=state.trainerProfile;state.trainerProfile={...(previous||{}),name,subtitle:subtitle||'Personal Trainer',cref,photoDataUrl:trainerPhotoDraft,photoSourceDataUrl:trainerPhotoSourceDraft,photoCrop:trainerPhotoCropDraft,profileEdited:true};
 try{save();closeDialog('trainerProfileDialog');trainerPhotoReadId++;toast('Perfil atualizado.')}
 catch(e){state.trainerProfile=previous;renderDashboard();toast('Não foi possível salvar o perfil. Verifique o espaço disponível.')}
};
