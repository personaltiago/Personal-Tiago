(function(global){
 'use strict';
 const day=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
 function build(state,year,now=new Date()){
  const months=Array.from({length:12},(_,index)=>({month:index+1,receivedCents:0,expenseCents:0,unknownReceipts:0,unknownExpenses:0,receipts:0,expenses:[]}));
  const today=day(now),seen=new Set();let invalidDates=0;
  for(const p of state.payments||[]){
   if(!p)continue;const key=typeof p.id==='string'?p.id.trim():'';if(key&&seen.has(key))continue;if(key)seen.add(key);
   const at=typeof p.paidAt==='string'?new Date(p.paidAt):new Date(NaN);if(!Number.isFinite(at.getTime())){invalidDates++;continue}
   if(at>now||at.getFullYear()!==year)continue;const row=months[at.getMonth()],value=APBilling.cents(p.amount);row.receipts++;if(value===null)row.unknownReceipts++;else row.receivedCents+=value;
  }
  seen.clear();
  for(const expense of state.financeExpenses||[]){
   if(!expense||expense.deleted===true)continue;const key=String(expense.id||'');if(key&&seen.has(key))continue;if(key)seen.add(key);
   const at=APBilling.date(expense.date);if(!at){invalidDates++;continue}if(Number(at.slice(0,4))!==year)continue;
   const row=months[Number(at.slice(5,7))-1];row.expenses.push(expense);if(at>today)continue;
   if(!Number.isSafeInteger(expense.amountCents)||expense.amountCents<=0||expense.amountCents>100000000)row.unknownExpenses++;else row.expenseCents+=expense.amountCents;
  }
  const total={receivedCents:0,expenseCents:0,unknownReceipts:0,unknownExpenses:0};
  for(const row of months){row.resultCents=row.receivedCents-row.expenseCents;for(const k of Object.keys(total))total[k]+=row[k];row.expenses.sort((a,b)=>b.date.localeCompare(a.date)||String(a.id).localeCompare(String(b.id)))}
  total.resultCents=total.receivedCents-total.expenseCents;total.uncertainDates=invalidDates;for(const row of months)row.uncertainDates=invalidDates;
  return {year,months,total,invalidDates,today};
 }
 function expense(input,previous=null,now=new Date()){
  const description=String(input.description||'').trim();if(!description||description.length>120)throw Error('Informe uma descrição de até 120 caracteres.');
  const date=APBilling.date(input.date);if(!date||date>day(now))throw Error('Informe a data em que a despesa foi paga, até hoje.');
  const amountCents=APBilling.cents(input.amount);if(amountCents===null||amountCents<=0)throw Error('Informe um valor maior que zero, até R$ 1.000.000,00.');
  return {...(previous||{}),description,date,amountCents,updatedAt:now.toISOString(),deleted:false};
 }
 // Persist first: quota errors must never leave an unsaved edit in memory.
 function commit(state,storage,key,record,action){
  const rows=Array.isArray(state.financeExpenses)?state.financeExpenses:[],old=rows.find(e=>e?.id===record.id);
  if(action!=='add'&&!old)throw Error('Essa despesa não existe mais. Atualize a tela.');
  if(action==='add'&&old)throw Error('Essa despesa já foi registrada.');
  const entry=action==='delete'?{...old,deleted:true,updatedAt:record.updatedAt}:record;
  const candidate={...state,financeExpenses:action==='add'?[entry,...rows]:rows.map(e=>e?.id===entry.id?entry:e)};
  storage.setItem(key,JSON.stringify(candidate));state.financeExpenses=candidate.financeExpenses;return entry;
 }
 global.APFinanceResults=Object.freeze({build,expense,commit,day});
})(globalThis);
