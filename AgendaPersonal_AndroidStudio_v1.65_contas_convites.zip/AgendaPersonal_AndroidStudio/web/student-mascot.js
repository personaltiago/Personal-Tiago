(function(){
 'use strict';
 if(window.__AP_PUBLIC_REGISTER)return;
 const M=APMascotModel,$=id=>document.getElementById(id),context=()=>window.APteacherMascot?.context()||window.__AP_STUDENT_CONTEXT;
 const isTeacher=()=>context()?.role==='teacher';
 const readStore=()=>isTeacher()?APteacherMascot.read():exStore();
 const saveStore=store=>isTeacher()?APteacherMascot.save(store):exSave(store);
 const canWrite=()=>['student','teacher'].includes(context()?.role)&&context()?.area?.enabled===true;
 let tab='colors',focusBefore=null,owner='',busy=false,reactionTimer=0,motivationTimer=0;
 const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const coin='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m12 6 2 4 4 2-4 2-2 4-2-4-4-2 4-2z"/></svg>';
 function prescribedGoal(){const days=new Set((context()?.area?.plans||[]).flatMap(p=>p.days||[]).filter(d=>d.exercises?.length&&Number.isInteger(d.weekday)).map(d=>d.weekday));return days.size||3}
 const state=()=>M.read(readStore().mascot,prescribedGoal());
 function art(s,mini=false){return APMascotArt.render(s,mini)}
 function theme(node){if(!node)return;const p=isTeacher()?APteacherMascot.prefs():prefs();if(/^#[0-9a-f]{6}$/i.test(p.color||''))node.style.setProperty('--mascot-accent',p.color);node.classList.toggle('ap-mascot-light',p.mode==='claro')}
 function status(text){const node=$('apMascotStatus');if(node){node.textContent=text||'';node.hidden=!text}}
 function isEnabled(id=context()?.storageId){
  if(!id)return false;
  try{return localStorage.getItem('agenda_pet_visible_v1_'+encodeURIComponent(id))!=='false'}catch(_){return true}
 }
 function visibility(){
  const enabled=isEnabled();
  $('apMascotBody').hidden=!enabled;$('apPetHiddenNote').hidden=enabled;
  for(const id of ['apPetShow','apPetHide']){$(id).disabled=!canWrite();$(id).setAttribute('aria-pressed',String(id===(enabled?'apPetShow':'apPetHide')))}
  if(!enabled)$('apMascotTitle').textContent='Pet';
 }
 function setEnabled(enabled){
  if(!canWrite()||owner!==context()?.storageId)return false;
  try{localStorage.setItem('agenda_pet_visible_v1_'+encodeURIComponent(owner),String(enabled))}
  catch(_){status('Não foi possível salvar sua escolha. Tente novamente.');return false}
  clearTimeout(reactionTimer);delete $('apMascotArt').dataset.reaction;
  if(!enabled)closeMotivation();
  render();home();window.APteacherMascot?.refreshCard();
  status('Preferência salva.');
  return true;
 }
 function home(){
  const host=$('homeScroll');if(!host)return;
  let button=$('apMascotHome');if(!button){button=document.createElement('div');button.id='apMascotHome';button.className='ap-mascot-home';button.addEventListener('click',e=>{if(e.target.closest('[data-mascot-retry]')){APMascotArt.load();return}if(e.target.closest('.ap-habitat-house')){APMascotPetting.cancel(button);open('house')}})}
  // Place it after the greeting, ahead of the workout and all other home cards.
  const header=host.querySelector('.home-header');if(header){if(header.nextElementSibling!==button)header.after(button)}else if(host.firstElementChild!==button)host.prepend(button);
  button.hidden=!window.__AP_STUDENT_CONTEXT||isTeacher();if(button.hidden)return;
  const enabled=isEnabled();theme(button);const s=state(),preview=s.species?s:{...s,species:'capybara'};
  const recado=APMascotMessages.student(context().area,readStore(),new Date(),context().storageId);
  button.dataset.dayType=recado.kind;button.dataset.loadTrend=recado.trend||'';
  if(!enabled){button.classList.remove('ap-habitat');if(!button.classList.contains('ap-recado-only'))button.innerHTML='';APMascotMessages.present(button,recado.text,false);return}
  if(button.dataset.petAffection){if(APMascotPetting.preserve?.(button,preview)){APMascotMessages.present(button,recado.text,true);return}APMascotPetting.cancel(button)}
  if(!APMascotArt.error())APMascotArt.load();APMascotHomes.decorate(button,s);
  button.innerHTML='<button type="button" class="ap-habitat-open"'+(' aria-label="Fazer carinho em '+escape(s.name)+'"')+'><span class="ap-mascot-mini">'+art(preview,true)+'</span><span class="ap-mascot-home-copy"><strong>'+escape(s.name)+'</strong><span class="ap-mascot-speech">'+escape(recado.text)+'</span><small>'+(s.species?M.phase(s.xp).name+' · '+s.coins+' moedas':'Prévia · escolha seu pet')+'</small></span></button><button type="button" class="ap-habitat-house" aria-label="Abrir a loja e personalizar o mascote">'+APMascotHomes.icon+'<span>Casa</span></button>';
  if(APMascotArt.error())button.insertAdjacentHTML('beforeend','<button type="button" class="ap-mascot-home-retry" data-mascot-retry>Tentar carregar o pet</button>');
  APMascotMessages.present(button,recado.text,true);APMascotPetting.bind(button,()=>{const current=state();return current.species?current:{...current,species:'capybara'}},()=>!!context()&&!isTeacher()&&$('apMascot')?.hidden!==false&&isEnabled());
 }
 function render(){
  if(!$('apMascot')||$('apMascot').hidden||!context())return;
  if(isTeacher())APteacherMascot.refreshCard();
  theme($('apMascot'));const s=state(),p=M.phase(s.xp),w=s.weeks[M.weekKey(Date.now())]||{goal:s.goal,count:0};
  $('apMascotChoiceTitle').textContent=s.species?'Trocar mascote':'Escolha seu mascote';
  $('apMascotChoices').innerHTML=M.choices.map(c=>'<button type="button" data-mascot-action="species" data-mascot-item="'+c.id+'" aria-pressed="'+String(s.species===c.id)+'" '+(canWrite()?'':'disabled')+'><span>'+art({...s,species:c.id,name:c.name},true)+'</span><strong>'+escape(c.name)+'</strong><small>'+(s.species===c.id?'Selecionado':'Escolher')+'</small></button>').join('');
  $('apMascotTitle').textContent=s.name;$('apMascotPhase').textContent=p.name;$('apMascotBalance').innerHTML=coin+s.coins+' moedas';APMascotPetting.cancel($('apMascotArt').closest('.ap-mascot-stage'));$('apMascotArt').innerHTML=art(s);
  APMascotHomes.decorate($('apMascotArt').closest('.ap-mascot-stage'),s);APMascotPetting.bind($('apMascotArt').closest('.ap-mascot-stage'),()=>state(),()=>!!context()&&!$('apMascot').hidden&&isEnabled()&&!!(window.APMascotBear?.supports(state())||window.APMascotBear?.attentionSupports(state())));
  $('apMascotHomeName').textContent=M.catalog.find(i=>i.id===s.equipped.home)?.name||'Quintal com casinha';
  const coat=M.color(s);$('apMascotGear').innerHTML='<span>Cor: '+escape(coat.name)+'</span><span>Pose: '+escape(M.pose(s).name)+'</span>';$('apMascotGear').hidden=!s.species;
  $('apMascotImageError').hidden=!APMascotArt.error();
  $('apMascotXP').textContent=s.xp+' XP';$('apMascotEvolutionTitle').textContent=p.end?'Crescendo com você':'Companheiro adulto';
  $('apMascotProgress').max=p.end?p.end-p.start:1;$('apMascotProgress').value=p.end?s.xp-p.start:1;
  $('apMascotEvolutionNote').textContent=p.end?(p.end-s.xp)+' XP para a fase '+(p.id==='baby'?'adolescente.':'adulta.'):'Seu mascote cresceu. Continue colecionando moedas e novas combinações.';
  $('apMascotWeeklyCount').textContent=w.count+' de '+w.goal+' treinos';
  $('apMascotWeeklyNote').textContent=w.count>=w.goal?'Meta cumprida. Seu descanso faz parte da rotina.':'Sua meta completa rende 300 XP, qualquer que seja sua frequência.';
  $('apMascotPreview').hidden=canWrite();$('apMascotName').value=s.name;$('apMascotGoal').value=String(s.goal);
  $('apMascotSettings').querySelectorAll('input,select,button').forEach(n=>n.disabled=!canWrite());
  $('apMascotTeacherTools').hidden=!isTeacher();
  renderTab(s);visibility();
 }
 function renderTab(s=state()){
  $('apMascotTabs').querySelectorAll('[data-mascot-tab]').forEach(b=>{const yes=b.dataset.mascotTab===tab;b.setAttribute('aria-selected',String(yes));b.tabIndex=yes?0:-1});$('apMascotContent').setAttribute('aria-labelledby','apMascotTab-'+tab);
  if(tab==='history'){$('apMascotContent').innerHTML=s.events.length?'<ol class="ap-mascot-log">'+s.events.map(e=>'<li><time>'+escape(new Date(e.at).toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'}))+'</time>'+escape(e.text)+'</li>').join('')+'</ol>':'<div class="ap-mascot-empty">As recompensas e compras aparecerão aqui. Os treinos anteriores à chegada do mascote continuam no seu histórico de treinos.</div>';return}
  if(tab==='colors'){renderColors(s);return}
  if(tab==='house'){renderHouses(s);return}
  if(tab==='shop'){$('apMascotContent').innerHTML=renderPoseShop(s);return}

 }

 function renderPoseShop(s){
  if(!s.species)return '<p class="ap-mascot-section-note">Escolha um mascote acima para ver as poses dele.</p>';
  const selected=M.pose(s).id,can=canWrite();
  return '<h3 class="ap-mascot-shop-heading">Poses do seu mascote</h3><p class="ap-mascot-section-note">Compre uma vez e use com todas as pelagens, nas três fases. As poses compradas ficam guardadas aqui.</p><div class="ap-mascot-grid ap-mascot-pose-shop">'+M.posesFor(s.species).map(p=>{
   const current=p.id===selected,owned=p.id==='default'||s.owned.includes(p.itemId),preview={...s,owned:p.itemId?[...s.owned,p.itemId]:s.owned,poses:{...s.poses,[s.species]:p.id}};
   const label=current?'Em uso':owned?'Usar pose':s.coins<p.price?(p.price-s.coins===1?'Falta 1 moeda':'Faltam '+(p.price-s.coins)+' moedas'):'Comprar · '+p.price+' moedas';
   return '<article class="ap-mascot-item ap-mascot-pose-item" data-pose="'+p.id+'" data-current="'+current+'"><span class="ap-mascot-pose-preview" aria-hidden="true">'+art(preview,true)+'</span><strong>'+escape(p.name)+'</strong><p>'+escape(p.copy)+'</p><small>'+(current?'Pose atual':p.id==='default'?'Já disponível':owned?'Sua pose · sem novo custo':p.price+' moedas')+'</small><button type="button" data-mascot-action="'+(owned?'pose':'buy')+'" data-mascot-item="'+(owned?p.id:p.itemId)+'" aria-label="'+escape(label+': '+p.name)+'" '+(!can||current||!owned&&s.coins<p.price?'disabled':'')+'>'+escape(label)+'</button></article>';
  }).join('')+'</div>';
 }
 function renderColors(s){
  if(!s.species){$('apMascotContent').innerHTML='<p class="ap-mascot-section-note">Escolha seu mascote acima para experimentar as cores.</p>';return}
  const selected=M.color(s).id,can=canWrite();
  $('apMascotContent').innerHTML='<p class="ap-mascot-section-note">Escolha a pelagem do seu bichinho. Cada animal tem seus próprios desenhos, disponíveis nas três fases. Todas as opções são grátis.</p><div class="ap-mascot-grid ap-mascot-colors" role="group" aria-label="Cores do mascote">'+M.colorsFor(s.species).map(c=>{
   const current=c.id===selected,preview={...s,colors:{...s.colors,[s.species]:c.id}};
   return '<button type="button" class="ap-mascot-color" data-mascot-action="color" data-mascot-item="'+c.id+'" aria-pressed="'+current+'" '+(!can?'disabled':'')+'><span class="ap-mascot-color-preview" aria-hidden="true">'+art(preview,true)+'</span><span class="ap-mascot-color-title"><span class="ap-mascot-color-swatch" style="background:'+c.swatch+'" aria-hidden="true"></span>'+escape(c.name)+'</span><small>'+(current?'✓ Em uso':'Usar visual')+'</small></button>';
  }).join('')+'</div>';
 }
 function renderHouses(s){
  const can=canWrite();
  $('apMascotContent').innerHTML='<p class="ap-mascot-section-note">Escolha onde seu mascote vai morar. Compre com as moedas dos treinos e aplique quando quiser. O quintal já é seu.</p><div class="ap-mascot-grid">'+M.catalog.filter(i=>i.kind==='home').map(i=>{
   const owned=s.owned.includes(i.id),current=s.equipped.home===i.id,afford=s.coins>=i.price;
   const label=current?'Em uso':owned?'Aplicar':afford?'Comprar · '+i.price+' moedas':'Faltam '+(i.price-s.coins)+' moedas';
   return '<article class="ap-mascot-item ap-mascot-house-item" data-current="'+current+'"><span class="ap-mascot-house-preview" style="background-image:url(&quot;'+APMascotHomes.scene(i.id)+'&quot;)" aria-hidden="true"></span><strong>'+escape(i.name)+'</strong><p>'+escape(i.copy)+'</p><small>'+(current?'Casa atual':owned?'Sua casa · sem novo custo':i.price+' moedas')+'</small><button type="button" data-mascot-action="'+(owned?'use':'buy')+'" data-mascot-item="'+i.id+'" '+(!can||current||!owned&&!afford?'disabled':'')+'>'+escape(label)+'</button></article>';
  }).join('')+'</div>';
 }
 function open(initialTab='colors'){
  APMascotPetting.cancelAll();
  if(!context()||context().area?.enabled===false)return;
  closeMotivation();
  APMascotArt.load();focusBefore=document.activeElement;owner=context().storageId;tab=initialTab==='clothes'?'colors':['colors','house','shop','history'].includes(initialTab)?initialTab:'colors';$('apMascot').hidden=false;$('apMascotChoice').open=!state().species;status('');$('apMascotReaction').textContent='Seu ritmo. Sua companhia.';render();$('apMascot').querySelector('.ap-mascot-sheet').focus();if(tab==='house')$('apMascotTabs').scrollIntoView({block:'start'});
 }
 function close(restore=true){
  const messageClosed=closeMotivation(),root=$('apMascot');if(!root||root.hidden)return messageClosed;APMascotPetting.cancel($('apMascotArt').closest('.ap-mascot-stage'));root.hidden=true;clearTimeout(reactionTimer);delete $('apMascotArt').dataset.reaction;
  if(restore&&owner===context()?.storageId&&focusBefore?.isConnected)focusBefore.focus();owner='';focusBefore=null;window.APteacherMascot?.leave();queueMicrotask(()=>{if(root.hidden){home();window.APteacherMascot?.refreshCard()}});return true;
 }
 function transact(changes){
  if(!canWrite()||busy||owner!==context()?.storageId)return false;
  busy=true;
  try{
   const focused=document.activeElement,restoreAction=focused?.dataset?.mascotAction,restoreItem=focused?.dataset?.mascotItem;
   const store=readStore();let s=M.read(store.mascot,prescribedGoal()),result;
   for(const [action,id]of changes){result=isTeacher()&&action.startsWith('test-')?APteacherMascot.change(s,action,id):M.change(s,action,id);if(!result.ok){status(result.error||'Não foi possível concluir.');return false}s=result.state}
   if(changes.some(([action,id])=>action==='buy'&&M.catalog.find(i=>i.id===id)?.kind==='home'))result.message+=' Toque em Aplicar para usar.';
   store.mascot=s;if(!saveStore(store)){status('Não foi possível salvar. Seu saldo e seus itens não foram alterados.');return false}
   render();home();status(result.message||'Preferências salvas.');
   if(changes.some(([action])=>action==='species')){$('apMascotChoice').open=false;$('apMascotChoiceTitle').focus()}
   if(restoreAction&&restoreAction!=='species'){const replacement=[...$('apMascotContent').querySelectorAll('[data-mascot-item]')].find(n=>n.dataset.mascotItem===restoreItem&&!n.disabled);(replacement||$('apMascotTab-'+tab)).focus()}
   if(result.reaction){$('apMascotArt').dataset.reaction=result.reaction;$('apMascotReaction').textContent=result.message;clearTimeout(reactionTimer);reactionTimer=setTimeout(()=>{delete $('apMascotArt').dataset.reaction},2200)}
   return true;
  }finally{busy=false}
 }
 function prepareReward(store,record){
  if(!canWrite()||isTeacher())return null;const result=M.reward(store.mascot,record,prescribedGoal());store.mascot=result.state;
  if(!store.history.some(r=>r.id===record.id&&r.startedAt===record.startedAt)){
   const prepared=APWorkoutMotivation.prepare(record,store.history,store.mascot.messageRotation);
   if(prepared){store.mascot.messageRotation=prepared.rotation;record.mascotMessage=prepared.message;result.message=APWorkoutMotivation.messageFor(record)}
  }
  return result;
 }
 function closeMotivation(){clearTimeout(motivationTimer);motivationTimer=0;const root=$('apWorkoutMotivation');if(!root||root.hidden)return false;root.hidden=true;return true}
 function afterReward(result){
  const uid=context()?.storageId;home();closeMotivation();if(!isEnabled()||!result?.message)return;
  motivationTimer=setTimeout(()=>{
   motivationTimer=0;if(!canWrite()||isTeacher()||!isEnabled()||context()?.storageId!==uid||document.body.dataset.view!=='workouts')return;
   const root=$('apWorkoutMotivation'),s=state();theme(root);root.dataset.loadTrend=result.message.kind;
   $('apWorkoutMotivationArt').innerHTML=art(s,true);$('apWorkoutMotivationArt').dataset.mascotPhase=M.phase(s.xp).id;$('apWorkoutMotivationName').textContent=s.species?s.name:'Seu companheiro';$('apWorkoutMotivationText').textContent=result.message.text;
   $('apWorkoutMotivationReward').hidden=result.reason!=='earned';$('apWorkoutMotivationReward').textContent=result.reason==='earned'?'Seu pet ganhou '+result.xp+' XP e 100 moedas.':'';root.hidden=false;
  },100);
 }
 $('apWorkoutMotivationClose').addEventListener('click',closeMotivation);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&closeMotivation()){e.preventDefault();e.stopPropagation()}});
 const originalRoute=route;route=function(...args){closeMotivation();return originalRoute(...args)};
 $('apMascot').addEventListener('click',e=>{
  const visible=e.target.closest('[data-pet-visible]');if(visible&&!visible.disabled){setEnabled(visible.dataset.petVisible==='true');return}
  if(e.target.closest('[data-mascot-retry]')){APMascotArt.load();return}
  if(e.target===$('apMascot')||e.target.closest('[data-mascot-close]')){close();return}
  const button=e.target.closest('[data-mascot-tab],[data-mascot-action]');if(!button||button.disabled)return;
  if(button.dataset.mascotTab){tab=button.dataset.mascotTab;status('');renderTab();return}
  const action=button.dataset.mascotAction,id=button.dataset.mascotItem;transact([[action,id]]);
 });
 $('apMascotSettings').addEventListener('submit',e=>{e.preventDefault();transact([['name',$('apMascotName').value],['goal',$('apMascotGoal').value]])});
 $('apMascot').addEventListener('keydown',e=>{
  if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close();return}
  const target=e.target.closest('[data-mascot-tab]');
  if(target&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const ids=['colors','house','shop','history'];tab=e.key==='Home'?ids[0]:e.key==='End'?ids.at(-1):ids[(ids.indexOf(tab)+(e.key==='ArrowRight'?1:ids.length-1))%ids.length];renderTab();$('apMascotTab-'+tab).focus();return}
  if(e.key==='Tab'){const list=[...$('apMascot').querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),summary,[tabindex="0"]')].filter(n=>n.getClientRects().length);if(!list.length)return;const first=list[0],last=list.at(-1);if(e.shiftKey&&(document.activeElement===first||document.activeElement===$('apMascot').querySelector('.ap-mascot-sheet'))){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
 });
 const originalHome=renderHome;renderHome=function(...args){const result=originalHome(...args);home();return result};
 window.addEventListener('ap-account-changed',()=>{close(false);window.APteacherMascot?.leave();const button=$('apMascotHome');if(button)button.hidden=true});
 window.addEventListener('ap-student-ready',home);
 window.addEventListener('storage',()=>{if(!$('apMascot').hidden){if(owner!==context()?.storageId)close(false);else render()}home()});
 window.addEventListener('ap-mascot-art-ready',()=>{home();render()});
 window.addEventListener('ap-mascot-homes-ready',()=>{home();render()});
 window.addEventListener('ap-mascot-art-error',()=>{home();render()});
 window.APmascot=Object.freeze({open,close,prepareReward,afterReward,art,state,isEnabled,refreshHome:home});
})();
