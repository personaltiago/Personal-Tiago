(function(){
 'use strict';
 if(window.__AP_PUBLIC_REGISTER)return;
 const M=APMascotModel,$=id=>document.getElementById(id),context=()=>window.APteacherMascot?.context()||window.__AP_STUDENT_CONTEXT;
 const isTeacher=()=>context()?.role==='teacher';
 const readStore=()=>isTeacher()?APteacherMascot.read():exStore();
 const saveStore=store=>isTeacher()?APteacherMascot.save(store):exSave(store);
 const canWrite=()=>['student','teacher'].includes(context()?.role)&&context()?.area?.enabled===true;
 let tab='care',focusBefore=null,owner='',busy=false,reactionTimer=0,motivationTimer=0;
 const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const coin='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m12 6 2 4 4 2-4 2-2 4-2-4-4-2 4-2z"/></svg>';
 function prescribedGoal(){const days=new Set((context()?.area?.plans||[]).flatMap(p=>p.days||[]).filter(d=>d.exercises?.length&&Number.isInteger(d.weekday)).map(d=>d.weekday));return days.size||3}
 const state=()=>M.read(readStore().mascot,prescribedGoal());
 function art(s,mini=false){return APMascotArt.render(s,mini)}
 function icon(id){const paths={fruit:'<path d="M19 13c0 5-5 8-7 6-2 2-7-1-7-6 0-4 4-5 7-3 3-2 7-1 7 3Z"/><path d="M12 10V5m0 2c4 0 5-3 5-3-4-1-5 3-5 3Z"/>',bowl:'<path d="M3 11h18c0 7-5 9-9 9s-9-2-9-9ZM6 7h2m3-2h2m3 2h2"/>',ball:'<circle cx="12" cy="12" r="9"/><path d="M4 8q9 0 12 12M8 4q0 9 12 12"/>',band:'<path d="M3 8q9-5 18 0v8q-9-5-18 0ZM5 18l-2 4 6-5"/>',shirt:'<path d="m8 3-6 5 4 5 2-2v11h8V11l2 2 4-5-6-5q-4 4-8 0Z"/>',hoodie:'<path d="M7 6q5-9 10 0l5 4-4 5-2-2v9H8V13l-2 2-4-5Z"/><path d="m7 6 5 5 5-5M10 15h4"/>'};return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(paths[id]||paths.ball)+'</svg>'}
 function theme(node){if(!node)return;const p=isTeacher()?APteacherMascot.prefs():prefs();if(/^#[0-9a-f]{6}$/i.test(p.color||''))node.style.setProperty('--mascot-accent',p.color);node.classList.toggle('ap-mascot-light',p.mode==='claro')}
 function status(text){const node=$('apMascotStatus');if(node){node.textContent=text||'';node.hidden=!text}}
 function isEnabled(id=context()?.storageId){
  if(!id)return false;
  try{return localStorage.getItem('agenda_pet_visible_v1_'+encodeURIComponent(id))!=='false'}catch(_){return true}
 }
 function visibility(){
  const enabled=isEnabled();
  $('apMascotBody').hidden=!enabled;$('apPetHiddenNote').hidden=enabled;
  for(const id of ['apPetShow','apPetHide']){$(id).disabled=!canWrite();$(id).setAttribute('aria-pressed',String(id===(enabled?'apPetShow':'apPetHide')))}
  if(!enabled)$('apMascotTitle').textContent='Pet';
 }
 function setEnabled(enabled){
  if(!canWrite()||owner!==context()?.storageId)return false;
  try{localStorage.setItem('agenda_pet_visible_v1_'+encodeURIComponent(owner),String(enabled))}
  catch(_){status('Não foi possível salvar sua escolha. Tente novamente.');return false}
  clearTimeout(reactionTimer);delete $('apMascotArt').dataset.reaction;
  if(!enabled)closeMotivation();
  render();home();window.APteacherMascot?.refreshCard();
  status('Preferência salva.');
  return true;
 }
 function home(){
  if(window.__AP_STUDENT_CONTEXT)APMascotArt.load();
  const host=$('homeScroll');if(!host)return;
  let button=$('apMascotHome');if(!button){button=document.createElement('button');button.id='apMascotHome';button.type='button';button.className='ap-mascot-home';button.onclick=open;host.appendChild(button)}
  button.hidden=!window.__AP_STUDENT_CONTEXT||!isEnabled()||isTeacher();if(!window.__AP_STUDENT_CONTEXT||isTeacher())return;theme(button);const s=state();
  const recado=APMascotMessages.student(context().area,readStore(),new Date(),context().storageId);
  button.dataset.dayType=recado.kind;
  button.dataset.loadTrend=recado.trend||'';
  button.innerHTML='<span class="ap-mascot-mini">'+art(s,true)+'</span><span class="ap-mascot-home-copy"><strong>'+(s.species?'Seu mascote · '+escape(s.name):'Escolha seu mascote')+'</strong><span class="ap-mascot-speech">'+escape(recado.text)+'</span><small>'+(s.species?M.phase(s.xp).name+' · '+s.coins+' moedas':'Capivara e mais cinco companheiros')+'</small></span><span class="ap-mascot-home-chevron" aria-hidden="true">›</span>';
 }
 function render(){
  if(!$('apMascot')||$('apMascot').hidden||!context())return;
  if(isTeacher())APteacherMascot.refreshCard();
  theme($('apMascot'));const s=state(),p=M.phase(s.xp),w=s.weeks[M.weekKey(Date.now())]||{goal:s.goal,count:0};
  $('apMascotChoiceTitle').textContent=s.species?'Trocar mascote':'Escolha seu mascote';
  $('apMascotChoices').innerHTML=M.choices.map(c=>'<button type="button" data-mascot-action="species" data-mascot-item="'+c.id+'" aria-pressed="'+String(s.species===c.id)+'" '+(canWrite()?'':'disabled')+'><span>'+art({...s,species:c.id,name:c.name},true)+'</span><strong>'+escape(c.name)+'</strong><small>'+(s.species===c.id?'Selecionado':'Escolher')+'</small></button>').join('');
  $('apMascotTitle').textContent=s.name;$('apMascotPhase').textContent=p.name;$('apMascotBalance').innerHTML=coin+s.coins+' moedas';$('apMascotArt').innerHTML=art(s);
  const equipped=Object.values(s.equipped).map(id=>M.catalog.find(i=>i.id===id)).filter(Boolean);$('apMascotGear').innerHTML=equipped.map(i=>'<span data-mascot-equipped="'+i.id+'">'+escape(i.name)+'</span>').join('');$('apMascotGear').hidden=!equipped.length;
  $('apMascotImageError').hidden=!APMascotArt.error();
  $('apMascotXP').textContent=s.xp+' XP';$('apMascotEvolutionTitle').textContent=p.end?'Crescendo com você':'Companheiro adulto';
  $('apMascotProgress').max=p.end?p.end-p.start:1;$('apMascotProgress').value=p.end?s.xp-p.start:1;
  $('apMascotEvolutionNote').textContent=p.end?(p.end-s.xp)+' XP para a fase '+(p.id==='baby'?'adolescente.':'adulta.'):'Seu mascote cresceu. Continue colecionando moedas e novas combinações.';
  $('apMascotWeeklyCount').textContent=w.count+' de '+w.goal+' treinos';
  $('apMascotWeeklyNote').textContent=w.count>=w.goal?'Meta cumprida. Seu descanso faz parte da rotina.':'Sua meta completa rende 300 XP, qualquer que seja sua frequência.';
  $('apMascotPreview').hidden=canWrite();$('apMascotName').value=s.name;$('apMascotGoal').value=String(s.goal);
  $('apMascotSettings').querySelectorAll('input,select,button').forEach(n=>n.disabled=!canWrite());
  $('apMascotTeacherTools').hidden=!isTeacher();
  renderTab(s);visibility();
 }
 function renderTab(s=state()){
  const can=canWrite();$('apMascotTabs').querySelectorAll('[data-mascot-tab]').forEach(b=>{const yes=b.dataset.mascotTab===tab;b.setAttribute('aria-selected',String(yes));b.tabIndex=yes?0:-1});$('apMascotContent').setAttribute('aria-labelledby','apMascotTab-'+tab);
  if(tab==='history'){$('apMascotContent').innerHTML=s.events.length?'<ol class="ap-mascot-log">'+s.events.map(e=>'<li><time>'+escape(new Date(e.at).toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'}))+'</time>'+escape(e.text)+'</li>').join('')+'</ol>':'<div class="ap-mascot-empty">As recompensas e compras aparecerão aqui. Os treinos anteriores à chegada do mascote continuam no seu histórico de treinos.</div>';return}
  let items=M.catalog.filter(i=>tab==='shop'||(tab==='care'?(i.kind==='food'||i.kind==='toy'):(i.kind==='head'||i.kind==='body')&&s.owned.includes(i.id)));
  const note=tab==='shop'?'Troque as moedas dos seus treinos por pequenos cuidados e novas roupas.':tab==='care'?'Seu mascote está bem. Alimente, brinque e aproveite a companhia.':'Seus itens ficam guardados aqui. Os equipados aparecem abaixo do mascote.';
  let content=items.map(i=>{
   const food=i.kind==='food',owned=food?s.food[i.id]>0:s.owned.includes(i.id),equipped=s.equipped[i.kind]===i.id;
   const action=tab==='shop'?'buy':equipped?'remove':'use',id=equipped?i.kind:i.id;
   const label=tab==='shop'?(owned&&!food?'Já comprado':s.coins<i.price?'Faltam '+(i.price-s.coins)+' moedas':'Comprar'):equipped?'Retirar':food?'Servir':i.kind==='toy'?'Brincar':'Equipar';
   const disabled=!can||(tab==='shop'?(s.coins<i.price||owned&&!food):!owned);
   return '<article class="ap-mascot-item"><div class="ap-mascot-item-icon">'+icon(i.id)+'</div><strong>'+escape(i.name)+'</strong><p>'+escape(i.copy)+'</p><small>'+escape(food?(tab==='shop'?i.price+' moedas · ':'')+'Você tem '+s.food[i.id]:tab==='shop'?i.price+' moedas':equipped?'Em uso':'No guarda-roupa')+'</small><button type="button" data-mascot-action="'+action+'" data-mascot-item="'+id+'" '+(disabled?'disabled':'')+'>'+escape(label)+'</button></article>';
  }).join('');
  if(!items.length)content='<div class="ap-mascot-empty">Seu guarda-roupa começa aqui. Conclua os treinos e visite a loja para escolher sua primeira peça.</div>';
  $('apMascotContent').innerHTML='<p class="ap-mascot-section-note">'+note+'</p>'+(items.length?'<div class="ap-mascot-grid">'+content+'</div>':content);
 }
 function open(){
  if(!context()||context().area?.enabled===false)return;
  closeMotivation();
  APMascotArt.load();focusBefore=document.activeElement;owner=context().storageId;tab='care';$('apMascot').hidden=false;$('apMascotChoice').open=!state().species;status('');$('apMascotReaction').textContent='Seu ritmo. Sua companhia.';render();$('apMascot').querySelector('.ap-mascot-sheet').focus();
 }
 function close(restore=true){
  const messageClosed=closeMotivation(),root=$('apMascot');if(!root||root.hidden)return messageClosed;root.hidden=true;clearTimeout(reactionTimer);delete $('apMascotArt').dataset.reaction;
  if(restore&&owner===context()?.storageId&&focusBefore?.isConnected)focusBefore.focus();owner='';focusBefore=null;window.APteacherMascot?.leave();return true;
 }
 function transact(changes){
  if(!canWrite()||busy||owner!==context()?.storageId)return false;
  busy=true;
  try{
   const focused=document.activeElement,restoreAction=focused?.dataset?.mascotAction,restoreItem=focused?.dataset?.mascotItem;
   const store=readStore();let s=M.read(store.mascot,prescribedGoal()),result;
   for(const [action,id]of changes){result=isTeacher()&&action.startsWith('test-')?APteacherMascot.change(s,action,id):M.change(s,action,id);if(!result.ok){status(result.error||'Não foi possível concluir.');return false}s=result.state}
   store.mascot=s;if(!saveStore(store)){status('Não foi possível salvar. Seu saldo e seus itens não foram alterados.');return false}
   render();home();status(result.message||'Preferências salvas.');
   if(changes.some(([action])=>action==='species')){$('apMascotChoice').open=false;$('apMascotChoiceTitle').focus()}
   if(restoreAction&&restoreAction!=='species'){const replacement=[...$('apMascotContent').querySelectorAll('[data-mascot-item]')].find(n=>n.dataset.mascotItem===restoreItem&&!n.disabled);(replacement||$('apMascotTab-'+tab)).focus()}
   if(result.reaction){$('apMascotArt').dataset.reaction=result.reaction;$('apMascotReaction').textContent=result.message;clearTimeout(reactionTimer);reactionTimer=setTimeout(()=>{delete $('apMascotArt').dataset.reaction},2200)}
   return true;
  }finally{busy=false}
 }
 function prepareReward(store,record){
  if(!canWrite()||isTeacher())return null;const result=M.reward(store.mascot,record,prescribedGoal());store.mascot=result.state;
  if(!store.history.some(r=>r.id===record.id&&r.startedAt===record.startedAt)){
   const prepared=APWorkoutMotivation.prepare(record,store.history,store.mascot.messageRotation);
   if(prepared){store.mascot.messageRotation=prepared.rotation;record.mascotMessage=prepared.message;result.message=APWorkoutMotivation.messageFor(record)}
  }
  return result;
 }
 function closeMotivation(){clearTimeout(motivationTimer);motivationTimer=0;const root=$('apWorkoutMotivation');if(!root||root.hidden)return false;root.hidden=true;return true}
 function afterReward(result){
  const uid=context()?.storageId;home();closeMotivation();if(!isEnabled()||!result?.message)return;
  motivationTimer=setTimeout(()=>{
   motivationTimer=0;if(!canWrite()||isTeacher()||!isEnabled()||context()?.storageId!==uid||document.body.dataset.view!=='workouts')return;
   const root=$('apWorkoutMotivation'),s=state();theme(root);root.dataset.loadTrend=result.message.kind;
   $('apWorkoutMotivationArt').innerHTML=art(s,true);$('apWorkoutMotivationName').textContent=s.species?s.name:'Seu companheiro';$('apWorkoutMotivationText').textContent=result.message.text;
   $('apWorkoutMotivationReward').hidden=result.reason!=='earned';$('apWorkoutMotivationReward').textContent=result.reason==='earned'?'Seu pet ganhou '+result.xp+' XP e 100 moedas.':'';root.hidden=false;
  },100);
 }
 $('apWorkoutMotivationClose').addEventListener('click',closeMotivation);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&closeMotivation()){e.preventDefault();e.stopPropagation()}});
 const originalRoute=route;route=function(...args){closeMotivation();return originalRoute(...args)};
 $('apMascot').addEventListener('click',e=>{
  const visible=e.target.closest('[data-pet-visible]');if(visible&&!visible.disabled){setEnabled(visible.dataset.petVisible==='true');return}
  if(e.target.closest('[data-mascot-retry]')){APMascotArt.load();return}
  if(e.target===$('apMascot')||e.target.closest('[data-mascot-close]')){close();return}
  const button=e.target.closest('[data-mascot-tab],[data-mascot-action]');if(!button||button.disabled)return;
  if(button.dataset.mascotTab){tab=button.dataset.mascotTab;status('');renderTab();return}
  const action=button.dataset.mascotAction,id=button.dataset.mascotItem;transact([[action,id]]);
 });
 $('apMascotSettings').addEventListener('submit',e=>{e.preventDefault();transact([['name',$('apMascotName').value],['goal',$('apMascotGoal').value]])});
 $('apMascot').addEventListener('keydown',e=>{
  if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close();return}
  const target=e.target.closest('[data-mascot-tab]');
  if(target&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const ids=['care','clothes','shop','history'];tab=e.key==='Home'?ids[0]:e.key==='End'?ids[3]:ids[(ids.indexOf(tab)+(e.key==='ArrowRight'?1:3))%4];renderTab();$('apMascotTab-'+tab).focus();return}
  if(e.key==='Tab'){const list=[...$('apMascot').querySelectorAll('button:not(:disabled),input:not(:disabled),select:not(:disabled),summary,[tabindex="0"]')].filter(n=>n.getClientRects().length);if(!list.length)return;const first=list[0],last=list.at(-1);if(e.shiftKey&&(document.activeElement===first||document.activeElement===$('apMascot').querySelector('.ap-mascot-sheet'))){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
 });
 const originalHome=renderHome;renderHome=function(...args){const result=originalHome(...args);home();return result};
 window.addEventListener('ap-account-changed',()=>{close(false);window.APteacherMascot?.leave();const button=$('apMascotHome');if(button)button.hidden=true});
 window.addEventListener('ap-student-ready',home);
 window.addEventListener('storage',()=>{if(!$('apMascot').hidden){if(owner!==context()?.storageId)close(false);else render()}home()});
 window.addEventListener('ap-mascot-art-ready',()=>{home();render()});
 window.addEventListener('ap-mascot-art-error',render);
 window.APmascot=Object.freeze({open,close,prepareReward,afterReward,art,state,isEnabled,refreshHome:home});
})();
