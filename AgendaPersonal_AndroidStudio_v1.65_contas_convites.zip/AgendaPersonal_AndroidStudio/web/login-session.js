(function(global){
 'use strict';
 const key='agenda_remember_login_v1';
 function available(name){try{const storage=global[name],probe=key+'_probe';storage.setItem(probe,'1');storage.removeItem(probe);return true}catch(_){return false}}
 function restoreChoice(){try{const box=document.getElementById('remember');if(box)box.checked=localStorage.getItem(key)==='true'}catch(_){}}
 async function configure(sdk,remember){
  if(typeof sdk.setPersistence!=='function')throw Error('Atualize o aplicativo para salvar sua sessão de acesso.');
  const providers=remember?[...(available('localStorage')?[sdk.browserLocalPersistence]:[]),sdk.indexedDBLocalPersistence]:available('sessionStorage')?[sdk.browserSessionPersistence]:[];
  let saved=false;
  for(const provider of providers.filter(Boolean)){try{await sdk.setPersistence(sdk.auth,provider);saved=true;break}catch(_){}}
  if(!saved)throw Error(remember?'Não foi possível manter o acesso salvo neste navegador. Permita o armazenamento do site e tente novamente.':'Não foi possível iniciar uma sessão neste navegador. Permita o armazenamento do site e tente novamente.');
  // Only the preference is ours. Firebase owns the authenticated session;
  // passwords and tokens are never copied into an application login cache.
  try{localStorage.setItem(key,String(remember))}catch(_){}
 }
 global.APLoginSession=Object.freeze({configure,restoreChoice});restoreChoice();
})(globalThis);
