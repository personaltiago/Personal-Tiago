(function(root){
 'use strict';
 const list=v=>Array.isArray(v)?v:[],text=v=>String(v??'').replace(/\r/g,'').trim(),value=v=>text(v)||'Não informado';
 const key=(p,d)=>encodeURIComponent(p).replace(/'/g,'%27')+'~'+encodeURIComponent(d).replace(/'/g,'%27');
 const timestamp=v=>{const n=typeof v==='number'?v:Date.parse(v);return Number.isFinite(n)?n:0};
 const dayKey=v=>{const d=new Date(timestamp(v));return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')};
 const date=v=>{const n=timestamp(v);return n?new Date(n).toLocaleString('pt-BR'):'Data não informada'};
 const load=v=>{const s=text(v);return !s?'Não informada':/^\d+(?:[.,]\d+)?$/.test(s)?s+' kg':s};
 function latest(student,plan,day,ex,executions,phone){
  const candidates=[];
  for(const r of list(executions)){
   if(r?.studentId!==student.id||r.planId!==plan.id||r.dayId!==day.id)continue;
   const entry=list(r.exercises).find(e=>e?.exerciseId===ex.id);if(!entry)continue;
   const at=timestamp(r.finishedAt||r.recordedAt||r.date);candidates.push({entry,source:'Registro do professor',at,day:/^\d{4}-\d{2}-\d{2}$/.test(text(r.date))?text(r.date):dayKey(at),id:text(r.id),kind:'teacher'});
  }
  for(const r of list(phone)){
   if(r?.id!==key(plan.id,day.id)||r.incomplete!==false)continue;
   const entry=list(r.exerciseRecords).find(e=>e?.exerciseId===ex.id);if(!entry)continue;
   candidates.push({entry,source:'Aplicativo do aluno',at:timestamp(r.finishedAt),day:dayKey(r.finishedAt),id:text(r.id),kind:'student'});
  }
  // Select one session per exercise; never fill missing sets from older sessions.
  return candidates.sort((a,b)=>b.day.localeCompare(a.day)||b.at-a.at||a.kind.localeCompare(b.kind)||b.id.localeCompare(a.id))[0]||null;
 }
 function actual(last){
  if(!last)return ['Última realização: sem registro disponível.'];
  const e=last.entry,lines=['Última realização: '+(last.day||date(last.at))+' · '+last.source];
  if(last.kind==='student'){
   const done=list(e.done),loads=list(e.loads),targets=list(e.targets);
   done.forEach((ok,i)=>{if(ok===true)lines.push('  Série '+(i+1)+': carga registrada '+load(loads[i])+'; meta da ficha '+value(targets[i]??e.reps)+'.')});
   lines.push('  O aplicativo confirmou as séries e as cargas. A meta acima não é uma contagem real de repetições ou segundos.');
   return lines;
  }
  const rows=list(e.performedSets).filter(r=>r&&r.done!==false&&Number.isInteger(Number(r.round))&&Number(r.round)>0).slice().sort((a,b)=>Number(a.round)-Number(b.round));
  if(rows.length){
   for(const r of rows){const timed=r.unit==='seconds',n=timed?r.seconds??r.reps:r.reps;lines.push('  Série '+r.round+': '+value(n)+(timed?' s':' repetições')+'; carga '+load(r.load)+'.')}
   lines.push('  Somente as séries presentes nessa última realização são mostradas.');
  }else lines.push('  Registro agregado: '+value(e.sets)+' séries; '+value(e.reps)+(e.unit==='seconds'?' (tempo)':' repetições')+'; carga '+load(e.load)+'. Sem divisão por série.');
  return lines;
 }
 function build({student,plan,executions=[],phoneRecords=[],observations={},prescriptions={},createdAt=Date.now(),phoneStatus=''}){
  if(!student?.id||!plan?.id||plan.studentId!==student.id)throw Error('A ficha não pertence ao aluno selecionado.');
  const days=list(plan.days),lines=['AGENDA PERSONAL — FICHA DE TREINO','Aluno: '+value(student.name),'Ficha: '+value(plan.name),'Objetivo: '+value(plan.goal),'Nível: '+value(plan.level),'Organização: '+(plan.organization==='week'?'Dias da semana':'Sequência de treinos'),'Exportado em: '+date(createdAt),''];
  if(plan.startDate||plan.endDate)lines.push('Período da ficha: '+value(plan.startDate)+' a '+value(plan.endDate));
  if(plan.notes)lines.push('Orientações da ficha: '+text(plan.notes));
  lines.push('','ORDEM DOS DIAS',...days.map((d,i)=>(i+1)+'. '+value(d.name)),'','A prescrição está separada do resultado real. O arquivo usa apenas registros já finalizados; séries em andamento não entram.');
  if(phoneStatus)lines.push(text(phoneStatus));
  for(const [di,day]of days.entries()){
   lines.push('','='.repeat(48),'DIA '+(di+1)+' — '+value(day.name));
   if(plan.organization==='week'&&Number.isInteger(Number(day.weekday))&&Number(day.weekday)>=0&&Number(day.weekday)<=6)lines.push('Dia da semana: '+['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'][Number(day.weekday)]);
   if(day.notes)lines.push('Orientações do dia: '+text(day.notes));
   for(const [ei,ex]of list(day.exercises).entries()){
    const rx=prescriptions[JSON.stringify([day.id,ex.id])]||{},groups=list(day.bisets),group=groups.find(g=>list(g.exerciseIds).includes(ex.id));
    lines.push('','Exercício '+(ei+1)+' — '+value(ex.name),'Prescrição: '+value(rx.sets??ex.sets)+' séries · meta '+value(rx.reps??ex.reps)+' · carga '+load(rx.load??ex.load)+' · intervalo '+value(rx.rest??ex.rest));
    if(ex.muscle)lines.push('Grupo muscular: '+text(ex.muscle));
    if(group){const partner=list(day.exercises).find(e=>e.id===group.exerciseIds.find(id=>id!==ex.id));lines.push('Bi-set: '+(group.exerciseIds[0]===ex.id?'A':'B')+' com '+value(partner?.name)+' · '+value(group.rounds)+' rodadas · descanso após B: '+value(group.restSeconds)+' s.');}
    if(rx.technique||ex.technique?.name)lines.push('Técnica: '+value(rx.technique||ex.technique.name));
    if(rx.rows?.length)for(const r of rx.rows)lines.push('  Meta da série '+r.round+': '+value(r.reps)+'; carga prescrita '+load(r.load)+'; intervalo '+value(r.rest)+'.');
    if(rx.notes||ex.technique?.observations)lines.push('Orientações da técnica: '+text(rx.notes||ex.technique.observations));
    if(ex.notes||ex.guidance?.execution||ex.description)lines.push('Execução: '+text(ex.notes||ex.guidance?.execution||ex.description));
    if(ex.observations)lines.push('Cuidados: '+text(ex.observations));
    const note=observations[JSON.stringify([student.id,plan.id,day.id,ex.id])];if(note?.text)lines.push('Observação deste aluno: '+text(note.text));
    lines.push(...actual(latest(student,plan,day,ex,executions,phoneRecords)));
   }
   if(!list(day.exercises).length)lines.push('Nenhum exercício cadastrado neste dia.');
  }
  if(!days.length)lines.push('A ficha não tem dias cadastrados.');
  return lines.join('\n')+'\n';
 }
 root.APWorkoutExportModel=Object.freeze({build,latest,key});
})(globalThis);
