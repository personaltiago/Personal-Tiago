(function(){
 'use strict';
 if(window.__AP_PUBLIC_REGISTER)return;
 const M=APFeedbackModel,S=APFeedbackSync,$=id=>document.getElementById(id),safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let selected='',owner='',focusBefore=null,observedPet=null,petPosition=null;
 const petObserver=new MutationObserver(records=>{if(records.some(r=>r.type==='attributes')||S.pending().length&&observedPet&&!observedPet.querySelector('.ap-feedback-pet-notice'))decorate()});
 const dialog=document.createElement('dialog');dialog.id='apFeedbackStudent';dialog.className='ap-feedback ap-feedback-student';dialog.setAttribute('aria-labelledby','apFeedbackStudentTitle');
 dialog.innerHTML='<header class="ap-feedback-heading"><div><small>SEU TREINO</small><h2 id="apFeedbackStudentTitle">Como foi hoje?</h2></div><button type="button" data-feedback-close aria-label="Fechar feedback">×</button></header><p class="ap-feedback-intro">Seu professor finalizou o treino presencial. Conte como foi para você.</p><div id="apFeedbackStudentList" class="ap-feedback-session-list"></div><section id="apFeedbackStudentDetail" hidden><h3 id="apFeedbackSessionName"></h3><dl id="apFeedbackStudentTime" class="ap-feedback-times"></dl><section id="apFeedbackTeacherEvaluation" class="ap-feedback-evaluation" hidden></section><form id="apFeedbackForm"><fieldset><label for="apFeedbackIntensity">Intensidade do treino</label><select id="apFeedbackIntensity" required><option value="">Selecione</option>'+M.intensities.map(v=>'<option>'+safe(v)+'</option>').join('')+'</select><label for="apFeedbackComment">Seu comentário <span>(opcional)</span></label><textarea id="apFeedbackComment" rows="5" maxlength="2000" placeholder="Conte como se sentiu durante o treino."></textarea><button type="submit" class="ap-feedback-primary">Enviar feedback</button></fieldset></form><div id="apFeedbackReceipt" class="ap-feedback-receipt" hidden></div><p id="apFeedbackSendStatus" role="status" aria-live="polite"></p></section><footer class="ap-feedback-footer"><span id="apFeedbackStudentStatus" role="status"></span><button type="button" id="apFeedbackStudentRefresh">Atualizar</button></footer>';
 document.body.appendChild(dialog);
 function times(item){return '<div><dt>Início</dt><dd>'+safe(M.stamp(item.startedAt))+'</dd></div><div><dt>Fim</dt><dd>'+safe(M.stamp(item.finishedAt))+'</dd></div><div><dt>Tempo de treino</dt><dd>'+safe(M.duration(item.durationSeconds))+'</dd></div>'}
 function values(){return {intensity:$('apFeedbackIntensity').value,comment:$('apFeedbackComment').value}}
 function remember(){if(owner!==S.uid()||!selected)return;try{S.draft(selected,values())}catch(_){$('apFeedbackSendStatus').textContent='Não foi possível salvar o rascunho neste aparelho.'}}
 function choose(id){remember();selected=id;delete $('apFeedbackForm').dataset.session;render();$('apFeedbackStudentDetail').scrollIntoView({block:'nearest',behavior:'smooth'})}
 function render(){
  if(!dialog.open)return;if(!S.uid()||owner!==S.uid()){close();return}
  const items=S.items(),local=S.local();$('apFeedbackStudentList').innerHTML=items.length?items.slice().sort((a,b)=>Number(!!a.response)-Number(!!b.response)||b.finishedAt-a.finishedAt).map(r=>'<button type="button" data-feedback-session="'+safe(r.id)+'" aria-pressed="'+String(selected===r.id)+'"><span><strong>'+safe(r.dayName)+'</strong><small>'+safe(M.stamp(r.finishedAt))+'</small></span><b>'+(r.response?'Enviado':local.outbox[r.id]?'Aguardando envio':'Dar feedback')+'</b></button>').join(''):'<p class="ap-feedback-empty">Nenhum feedback solicitado. Seus treinos presenciais concluídos pelo professor aparecerão aqui.</p>';
  const item=items.find(r=>r.id===selected);$('apFeedbackStudentDetail').hidden=!item;
  if(item){$('apFeedbackSessionName').textContent=item.dayName+' · '+item.planName;$('apFeedbackStudentTime').innerHTML=times(item);const evaluation=M.evaluation(item),assessment=$('apFeedbackTeacherEvaluation');assessment.hidden=!evaluation;assessment.innerHTML='<strong>Avaliação do professor</strong><p class="ap-feedback-comment">'+safe(evaluation)+'</p>';const form=$('apFeedbackForm'),pending=local.outbox[item.id];
   if(form.dataset.session!==item.id){const draft=local.drafts[item.id]||pending||{};$('apFeedbackIntensity').value=draft.intensity||'';$('apFeedbackComment').value=draft.comment||'';form.dataset.session=item.id}
   form.hidden=!!item.response;form.querySelector('fieldset').disabled=!!pending;
   $('apFeedbackReceipt').hidden=!item.response;
   if(item.response)$('apFeedbackReceipt').innerHTML='<strong>Feedback recebido pelo professor</strong><p>Intensidade: '+safe(item.response.intensity)+'</p><p class="ap-feedback-comment">'+safe(item.response.comment||'Sem comentário.')+'</p>';
   $('apFeedbackSendStatus').textContent=pending?'Resposta salva neste aparelho. Aguardando confirmação de envio ao professor.':item.response?'Recebido em '+M.stamp(item.response.receivedAt)+'.':'';
  }
  const status=S.status();$('apFeedbackStudentStatus').textContent=status.message;$('apFeedbackStudentRefresh').disabled=status.busy;
 }
 function decorate(){
  const count=S.pending().length,pet=$('apMascotHome'),host=$('homeScroll');if(!host)return;
  if(pet&&observedPet!==pet){petObserver.disconnect();observedPet=pet;petObserver.observe(pet,{attributes:true,attributeFilter:['hidden'],childList:true})}
  if(pet&&!petPosition){petPosition=document.createComment('original mascot position');pet.before(petPosition)}
  const hero=host.querySelector('.home-today');if(count&&S.uid()&&pet&&hero)hero.before(pet);else if(petPosition?.isConnected&&pet)petPosition.after(pet);
  if(pet){const wasPending=pet.classList.contains('ap-feedback-pending');pet.classList.toggle('ap-feedback-pending',count>0&&!!S.uid());pet.querySelector('.ap-feedback-pet-notice')?.remove();if(count&&S.uid()){const speech=pet.querySelector('.ap-mascot-speech');if(speech)speech.textContent='Você finalizou seu treino presencial. Conte ao professor como foi.';const note=document.createElement('span');note.className='ap-feedback-pet-notice';note.innerHTML='<strong>Treino concluído · dê seu feedback</strong><span>'+count+' '+(count===1?'resposta pendente':'respostas pendentes')+' · toque aqui</span>';pet.appendChild(note)}else if(wasPending&&S.uid())window.APmascot?.refreshHome()}
  let fallback=$('apFeedbackHome');if(!fallback){fallback=document.createElement('button');fallback.id='apFeedbackHome';fallback.type='button';fallback.className='ap-feedback-home';fallback.onclick=()=>open();host.appendChild(fallback)}
  fallback.hidden=!S.uid()||!count||!!pet&&!pet.hidden;fallback.textContent='Treino concluído · dê seu feedback ('+count+')';
  if(count&&S.uid()&&hero)hero.before(fallback);
  let link=$('apMascotFeedback');const body=$('apMascotBody');if(body&&!link){link=document.createElement('button');link.id='apMascotFeedback';link.type='button';link.className='ap-feedback-home';link.onclick=()=>open();body.prepend(link)}
  if(link){link.hidden=!S.uid();link.textContent=count?'Você concluiu o treino. Dê seu feedback ('+count+')':'Seus feedbacks';link.classList.toggle('ap-feedback-pending',count>0)}
 }
 function open(id=''){
  if(!S.uid())return false;owner=S.uid();focusBefore=document.activeElement;selected=id||S.pending()[0]?.id||S.items()[0]?.id||'';delete $('apFeedbackForm').dataset.session;
  const p=typeof prefs==='function'?prefs():{};dialog.style.setProperty('--fb-accent',p.color||'#b6ff26');dialog.classList.toggle('ap-feedback-light',p.mode==='claro');if(!dialog.open)dialog.showModal();render();dialog.querySelector('[data-feedback-close]').focus();S.refresh();return true;
 }
 function close(){if(!dialog.open)return false;remember();dialog.close();if(owner===S.uid())focusBefore?.focus?.({preventScroll:true});owner='';selected='';return true}
 dialog.querySelector('[data-feedback-close]').onclick=close;dialog.addEventListener('cancel',e=>{e.preventDefault();close()});dialog.addEventListener('click',e=>{const b=e.target.closest('[data-feedback-session]');if(b)choose(b.dataset.feedbackSession)});
 $('apFeedbackForm').oninput=remember;$('apFeedbackForm').onsubmit=e=>{e.preventDefault();if(owner!==S.uid())return close();try{S.submit(selected,values());render()}catch(error){$('apFeedbackSendStatus').textContent=error.message}};
 $('apFeedbackStudentRefresh').onclick=()=>S.refresh();
 document.addEventListener('click',e=>{if(S.pending().length&&S.uid()&&e.target.closest('#apMascotHome')){e.preventDefault();e.stopImmediatePropagation();open()}},true);
 const originalHome=renderHome;renderHome=function(...args){const result=originalHome.apply(this,args);decorate();return result};
 if(typeof back==='function'){const originalBack=back;back=function(...args){if(close())return;return originalBack.apply(this,args)}}
 if(typeof window.handleAgendaSystemBack==='function'){const previousSystemBack=window.handleAgendaSystemBack;window.handleAgendaSystemBack=function(...args){if(close())return true;return previousSystemBack.apply(this,args)}}
 addEventListener('ap-feedback-changed',()=>{decorate();render()});addEventListener('ap-mascot-art-ready',decorate);addEventListener('ap-student-ready',decorate);addEventListener('ap-account-changed',()=>{if(dialog.open)dialog.close();owner='';selected='';$('apFeedbackForm').reset();decorate()});
 window.APFeedbackStudent=Object.freeze({open,close,render,decorate});decorate();
})();
