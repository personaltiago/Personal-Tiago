(function(){
 'use strict';
 const menu=document.getElementById('screen-more');if(!menu)return;
 const groups=[['training','Treinos e avaliações'],['agenda','Agenda'],['students','Alunos e financeiro'],['appearance','Aparência e preferências'],['app','Aplicativo e dados']];
 const routes={
  workouts:['training',0,'weights'],evaluations:['training',1,'evaluation'],pdf:['training',3,'file'],
  today:['agenda',0,'menu-today'],week:['agenda',1,'menu-week'],availability:['agenda',2,'menu-free'],makeup:['agenda',3,'makeup'],
  'students-presencial':['students',0,'users'],'students-online':['students',1,'laptop'],student:['students',2,'student'],finance:['students',5,'wallet'],
  settings:['appearance',2,'settings'],pet:['appearance',3,'pet'],updates:['app',0,'download'],history:['app',3,'clock'],logout:['account',0,'logout']
 };
 const byId={moreWorkoutCatalog:['training',2,'book'],moreSmartwatch:['training',4,'menu-watch'],moreRegistrationLink:['students',3,'menu-link'],moreFollowup:['students',4,'menu-followup'],moreThemeButton:['appearance',0,'palette'],moreLessonSounds:['appearance',1,'menu-alarm'],moreFullBackup:['app',1,'menu-backup'],moreTeacherSync:['app',2,'menu-sync']};
 const copies={moreLessonSounds:['Sons e alertas','Aulas, descanso e despertador.'],moreTeacherSync:['Sincronizar','Atualize a agenda e o visual da conta.']};
 const grids=new Map();let host,logout,scheduled=false;
 function section(id,title){
  const s=document.createElement('section');s.className='more-group ap-more-group';s.dataset.moreGroup=id;s.setAttribute('aria-labelledby','apMoreGroup-'+id);
  const h=document.createElement('div');h.className='more-group-heading';const label=document.createElement('h3');label.id='apMoreGroup-'+id;label.textContent=title;h.append(label);
  const grid=document.createElement('div');grid.className='more-function-grid';s.append(h,grid);grids.set(id,grid);return s;
 }
 function init(){
  if(host)return;host=document.createElement('div');host.id='apMoreOrganized';const first=menu.querySelector('.more-group');if(first)first.before(host);else menu.append(host);
  for(const [id,title]of groups)host.append(section(id,title));logout=section('account','Conta');logout.id='apMoreAccount';menu.append(logout);
 }
 function icon(card,name){
  const holder=card.querySelector('.more-function-icon');if(!holder||card.dataset.apMenuIcon===name)return;
  const drawing=window.APMoreMenuGlyphs?.[name];if(!drawing)return;
  const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('fill','currentColor');svg.setAttribute('stroke','none');svg.setAttribute('aria-hidden','true');svg.dataset.apMenuIcon=name;svg.innerHTML=drawing;
  holder.replaceChildren(svg);card.dataset.apMenuIcon=name;
 }
 function organize(){
  scheduled=false;init();const cards=[...menu.querySelectorAll('button.more-function')].filter(b=>!b.closest('#proMoreMenu')),buckets=new Map([...grids.keys()].map(k=>[k,[]]));
  for(const [index,card]of cards.entries()){
   const spec=byId[card.id]||routes[card.dataset.screen||card.dataset.panelAction]||['app',50+index,null];
   buckets.get(spec[0]).push({card,order:spec[1],index});if(spec[2])icon(card,spec[2]);
   if(!card.dataset.apMenuCopy){
    const copy=copies[card.id]||(card.dataset.screen==='settings'?['Configurações','Preferências e ajustes do aplicativo.']:null);
    if(copy){const title=card.querySelector('.more-function-copy strong'),desc=card.querySelector('.more-function-copy small');if(title)title.textContent=copy[0];if(desc)desc.textContent=copy[1]}
    card.dataset.apMenuCopy='true';
   }
  }
  for(const [key,grid]of grids){
   const list=buckets.get(key).sort((a,b)=>a.order-b.order||a.index-b.index);
   list.forEach(({card},i)=>{if(grid.children[i]!==card)grid.insertBefore(card,grid.children[i]||null)});grid.parentElement.hidden=list.length===0;
  }
  for(const section of [...menu.querySelectorAll('.more-group')])if(!section.classList.contains('ap-more-group')&&!section.querySelector('.more-function'))section.remove();
  if(menu.lastElementChild!==logout)menu.append(logout);
 }
 function queue(){if(!scheduled){scheduled=true;queueMicrotask(organize)}}
 function boot(){organize();new MutationObserver(changes=>{
  if(changes.some(m=>[...m.addedNodes,...m.removedNodes].some(n=>n.nodeType===1&&(n.matches?.('button.more-function')||n.querySelector?.('button.more-function')))))queue();
 }).observe(menu,{childList:true,subtree:true});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
