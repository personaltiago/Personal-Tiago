(function(){
 'use strict';
 const M=APFeedbackModel,$=id=>document.getElementById(id),safe=v=>hesc(String(v??''));
 const api=()=>window.parent?.APFeedbackSync,allowed=()=>window.parent?.APaccounts?.isTeacher()===true&&!window.parent.__AP_STUDENT_CONTEXT&&!window.APBackupRestoring;
 const removed=()=>state.workoutFeedbackDeleted||{};
 const rows=()=>Array.isArray(state.workoutFeedbackRequests)?state.workoutFeedbackRequests.filter(r=>removed()[r.id]!==true):[];
 let busy=false,timer=0,epoch=0,filter='received',query='',status='',openedBy=null,selecting=false,pendingDelete=null;
 const selected=new Set();
 function store(items,deletions=removed()){
  const next=APTeacherSyncModel.cleanFeedback({...state,workoutFeedbackRequests:items,workoutFeedbackDeleted:deletions});
  if(JSON.stringify(next)===JSON.stringify(state))return true;
  try{localStorage.setItem(DB_KEY,JSON.stringify(next));state.workoutFeedbackRequests=next.workoutFeedbackRequests;state.workoutFeedbackDeleted=next.workoutFeedbackDeleted;window.APTeacherSync?.changed();return true}
  catch(_){status='Não foi possível salvar a alteração. Nenhum feedback foi apagado.';return false}
 }
 function deleteRequest(ids){
  if(!allowed())return;
  const wanted=new Set(ids),items=rows().filter(r=>wanted.has(r.id));if(!items.length)return;
  pendingDelete={ids:items.map(r=>r.id),epoch,focus:document.activeElement};
  $('apFeedbackDeleteTitle').textContent=items.length===1?'Apagar este feedback?':'Apagar '+items.length+' feedbacks?';
  $('apFeedbackDeleteSummary').textContent=items.length===1?items[0].studentName+' · '+items[0].dayName:items.length+' feedbacks selecionados serão removidos da sua lista.';
  $('apFeedbackDeletePending').hidden=!items.some(r=>!r.response);
  $('apFeedbackDeleteStatus').textContent='';$('apFeedbackDelete').showModal();$('apFeedbackDeleteCancel').focus();
 }
 function confirmDelete(){
  if(!pendingDelete||!allowed()||pendingDelete.epoch!==epoch)return;
  const ids=new Set(pendingDelete.ids),count=rows().filter(r=>ids.has(r.id)).length;
  const deletions={...removed()};for(const id of ids)deletions[id]=true;
  if(!store(rows().filter(r=>!ids.has(r.id)),deletions)){$('apFeedbackDeleteStatus').textContent=status;return}
  for(const id of ids)selected.delete(id);
  const image=$('apFeedbackImage');if(image?.open&&ids.has(image.dataset.feedbackId))image.close();
  $('apFeedbackDelete').close();status=count===1?'Feedback apagado.':count+' feedbacks apagados.';updateBadge();render();$('apFeedbackTeacherSelect').focus({preventScroll:true});
 }
 function visible(){
  const q=query.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  return rows().filter(r=>(filter==='all'||filter==='received'&&r.response||filter==='waiting'&&!r.response)&&(!q||String(r.studentName+' '+r.dayName).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().includes(q))).slice().sort((a,b)=>(Date.parse(b.response?.receivedAt)||b.finishedAt)-(Date.parse(a.response?.receivedAt)||a.finishedAt));
 }
 function selectionStatus(){
  const items=visible(),ids=new Set(items.map(r=>r.id));for(const id of selected)if(!ids.has(id))selected.delete(id);
  $('apFeedbackTeacherCountVisible').textContent=items.length+' '+(items.length===1?'feedback':'feedbacks');
  $('apFeedbackTeacherSelect').textContent=selecting?'Cancelar seleção':'Selecionar';$('apFeedbackTeacherSelect').disabled=!selecting&&!items.length;
  $('apFeedbackSelection').hidden=!selecting;$('apFeedbackSelectionCount').textContent=selected.size+' '+(selected.size===1?'selecionado':'selecionados');
  $('apFeedbackDeleteSelected').disabled=!selected.size;
  const all=$('apFeedbackSelectAll');all.checked=items.length>0&&selected.size===items.length;all.indeterminate=selected.size>0&&selected.size<items.length;all.disabled=!items.length;
 }

 function merge(item){if(removed()[item.id]===true)return;const old=rows().find(r=>r.id===item.id&&r.uid===item.uid);if(item.source==='online'){const matches=state.students.filter(s=>s.firebaseUid===item.uid);if(matches.length!==1)throw Error('Confira o cadastro vinculado à conta do aluno.');item={...item,studentId:matches[0].id,studentName:matches[0].name||'Aluno'}}if(old&&old.studentId!==item.studentId)throw Error('O feedback não corresponde ao cadastro original.');const student=studentById(item.studentId);if(!student||student.firebaseUid!==item.uid)throw Error('O feedback não corresponde à conta vinculada ao aluno.');const next={...old,...item,status:'sent',error:'',seenAt:old?.seenAt||null};if(old&&JSON.stringify(old)===JSON.stringify(next))return;if(!store([next,...rows().filter(r=>r.id!==item.id)]))throw Error(status)}
 function newRequest(record){const s=studentById(record.studentId),session=M.session(record,s);return session?{...session,professorId:M.TEACHER,durationSeconds:Math.floor((session.finishedAt-session.startedAt)/1000),response:null,status:session.uid?'queued':'unlinked',seenAt:null,error:''}:null}
 const commit=commitWorkoutChange;commitWorkoutChange=function(changes,...args){
  let added=[];if(allowed()&&Array.isArray(changes.workoutExecutions)){const old=new Set((state.workoutExecutions||[]).map(r=>r.id)),known=new Set(rows().map(r=>r.id));added=changes.workoutExecutions.filter(r=>!old.has(r.id)).map(newRequest).filter(r=>r&&!known.has(r.id));added=added.filter(r=>removed()[r.id]!==true);if(added.length)changes={...changes,workoutFeedbackRequests:[...added,...rows()]}}
  const saved=commit.call(this,changes,...args);if(saved&&added.length){updateBadge();schedule()}return saved;
 };
 function schedule(){clearTimeout(timer);if(allowed())timer=setTimeout(()=>refresh(false),800)}
 async function refresh(all=true){
  if(!allowed()||busy||!api())return;const ticket=epoch;busy=true;status=navigator.onLine===false?'Sem conexão. Pedidos e feedbacks salvos neste aparelho.':'Atualizando pedidos e respostas…';render();
  const valid=()=>allowed()&&epoch===ticket;
  try{
   if(navigator.onLine===false)return;
   const queued=rows().filter(r=>r.uid&&r.status!=='sent'&&!r.response);for(const row of queued){if(!valid())return;const student=studentById(row.studentId);if(student?.firebaseUid!==row.uid)continue;
    try{const session=Object.fromEntries(['id','uid','studentId','studentName','planName','dayName','startedAt','finishedAt','teacherEvaluation'].map(k=>[k,row[k]]));const item=await api().create(session);if(!valid())return;merge(item)}catch(e){if(!valid())return;const latest=rows().map(r=>r.id===row.id?{...r,status:'error',error:e.message}:r);if(!store(latest))throw Error(status)}
   }
   const ids=[...new Set(state.students.filter(s=>M.uid(s.firebaseUid)).map(s=>s.firebaseUid))];let failure=false;
   const work=async()=>{while(ids.length&&valid()){const uid=ids.shift();try{const items=await api().inbox(uid);if(!valid())return;for(const item of items){try{merge(item)}catch(_){failure=true}}}catch(_){failure=true}}};await Promise.all(Array.from({length:Math.min(3,ids.length)},work));
   if(valid()){await window.parent.APPhotoSync?.receive();if(!valid())return}if(valid())status=failure?'Alguns feedbacks não puderam ser atualizados. Os registros recebidos foram preservados.':'Atualizado em '+M.stamp(Date.now())+'.';
  }catch(e){if(valid())status=e.message||'Não foi possível atualizar agora.'}
  finally{busy=false;if(valid()){updateBadge();render()}}
 }
 function retry(id){const row=rows().find(r=>r.id===id),student=row&&studentById(row.studentId);if(!row||!student)return;if(!M.uid(student.firebaseUid))return toast('Vincule a conta do aluno no perfil para entregar o pedido.');if(row.uid&&row.uid!==student.firebaseUid)return toast('A conta vinculada mudou. Este pedido foi preservado sem reenvio.');if(store(rows().map(r=>r.id===id?{...r,uid:student.firebaseUid,status:'queued',error:''}:r)))refresh(false)}
 function updateBadge(){const count=rows().filter(r=>r.response&&!r.seenAt).length,n=$('apFeedbackTeacherCount');if(n)n.textContent=count?count+' '+(count===1?'novo':'novos'):'0 novos';$('apFeedbackTeacherEntry')?.classList.toggle('has-unread',count>0)}
 function photo(s){return typeof s?.photoDataUrl==='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(s.photoDataUrl)&&s.photoDataUrl.length<400000?s.photoDataUrl:''}
 function render(){
  const d=$('apFeedbackTeacher');if(!d?.open)return;if(!allowed()){d.close();return}const items=visible();selectionStatus();
  $('apFeedbackTeacherList').innerHTML=items.length?items.map(r=>{const s=studentById(r.studentId),image=photo(s),pending=r.status==='unlinked'?'Aluno sem conta vinculada':r.status==='queued'?'Pedido aguardando envio':r.status==='error'?'Pedido não entregue':'Aguardando a resposta do aluno';return '<article class="ap-feedback-card'+(r.response&&!r.seenAt?' is-new':'')+'" data-feedback-id="'+safe(r.id)+'">'+(selecting?'<label class="ap-feedback-select-row"><input type="checkbox" data-feedback-select="'+safe(r.id)+'"'+(selected.has(r.id)?' checked':'')+'><span>Selecionar feedback<span class="ap-feedback-sr"> de '+safe(r.studentName)+' · '+safe(r.dayName)+'</span></span></label>':'')+'<header><span class="ap-feedback-avatar">'+(image?'<img src="'+safe(image)+'" alt="">':safe(r.studentName.split(/\s+/).map(v=>v[0]).slice(0,2).join('')) )+'</span><div><h3>'+(r.response&&!r.seenAt?'<span class="ap-feedback-unread-dot" aria-label="Novo"></span>':'')+safe(r.studentName)+'</h3><small>'+safe(r.dayName)+'</small></div><span class="ap-feedback-tag">'+(r.source==='online'?'Online':'Presencial')+'</span></header><p class="ap-feedback-meta">'+safe(M.stamp(r.response?.receivedAt||r.finishedAt))+' · '+safe(r.planName)+'</p>'+(M.evaluation(r)?'<section class="ap-feedback-evaluation"><strong>Avaliação do professor</strong><p class="ap-feedback-comment">'+safe(M.evaluation(r))+'</p></section>':'')+(r.response?'<p class="ap-feedback-intensity"><strong>Intensidade:</strong> '+safe(r.response.intensity||'Não informada')+'</p><p class="ap-feedback-comment">'+safe(r.response.comment||'Sem comentário.')+'</p>':'<p class="ap-feedback-comment">'+safe(pending)+'.</p>'+(r.error?'<p class="ap-feedback-meta">'+safe(r.error)+'</p>':''))+'<dl class="ap-feedback-times"><div><dt>Início</dt><dd>'+safe(M.stamp(r.startedAt))+'</dd></div><div><dt>Fim</dt><dd>'+safe(M.stamp(r.finishedAt))+'</dd></div><div><dt>Tempo de treino</dt><dd>'+safe(M.duration(r.durationSeconds))+'</dd></div></dl>'+(r.response?'<div class="ap-feedback-actions"><button type="button" data-feedback-action="image">Preparar imagem</button><button type="button" data-feedback-action="copy">Copiar texto</button>'+(!r.seenAt?'<button type="button" data-feedback-action="read">Marcar como lido</button>':'')+'</div>':'<div class="ap-feedback-actions"><button type="button" data-feedback-action="profile">Perfil do aluno</button>'+(r.status!=='sent'?'<button type="button" data-feedback-action="retry">Tentar envio</button>':'')+'</div>')+'<button type="button" class="ap-feedback-delete-one" data-feedback-action="delete"><svg class="danger" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/></svg>Apagar feedback</button></article>'}).join(''):'<p class="ap-feedback-empty">'+(filter==='waiting'?'Nenhum pedido aguardando resposta. Ao finalizar um treino presencial, o pedido será criado automaticamente.':'Nenhum feedback recebido neste filtro. As respostas dos alunos aparecerão aqui.')+'</p>';
  $('apFeedbackTeacherStatus').textContent=status;$('apFeedbackTeacherRefresh').disabled=busy;for(const b of d.querySelectorAll('[data-feedback-filter]'))b.setAttribute('aria-pressed',String(b.dataset.feedbackFilter===filter));updateBadge();
 }
 function mount(){
  const tabs=document.querySelector('.student-category-tabs'),archived=tabs?.querySelector('[data-student-category="archived"]');if(!tabs||$('apFeedbackTeacherEntry'))return;tabs.classList.add('ap-feedback-tabs');tabs.setAttribute('aria-label','Alunos e feedbacks');
  const b=document.createElement('button');b.id='apFeedbackTeacherEntry';b.type='button';b.setAttribute('aria-haspopup','dialog');b.setAttribute('aria-controls','apFeedbackTeacher');b.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 11a6 6 0 0 1-6 6H5l-3 3v-6a6 6 0 1 1 14-3Z"/><path d="M18 8a6 6 0 0 1 4 6v6l-3-3h-3"/></svg><span>Feedbacks<small id="apFeedbackTeacherCount">0 novos</small></span>';b.onclick=open;tabs.insertBefore(b,archived);
  const d=document.createElement('dialog');d.id='apFeedbackTeacher';d.className='ap-feedback';d.setAttribute('aria-labelledby','apFeedbackTeacherTitle');d.innerHTML='<header class="ap-feedback-heading"><div><small>ACOMPANHAMENTO DOS ALUNOS</small><h2 id="apFeedbackTeacherTitle">Feedbacks dos alunos</h2></div><button type="button" aria-label="Fechar feedbacks">×</button></header><p class="ap-feedback-intro">Feedbacks dos treinos online e presenciais. Confira sua avaliação e a resposta de cada aluno.</p><input id="apFeedbackTeacherSearch" type="search" aria-label="Buscar feedback por aluno ou treino" placeholder="Buscar aluno ou treino"><div class="ap-feedback-filters" role="group" aria-label="Filtrar feedbacks"><button type="button" data-feedback-filter="received" aria-pressed="true">Recebidos</button><button type="button" data-feedback-filter="waiting" aria-pressed="false">Aguardando</button><button type="button" data-feedback-filter="all" aria-pressed="false">Todos</button></div><div class="ap-feedback-tools"><span id="apFeedbackTeacherCountVisible"></span><button type="button" id="apFeedbackTeacherSelect">Selecionar</button></div><section id="apFeedbackSelection" class="ap-feedback-selection" aria-label="Seleção de feedbacks" hidden><label class="ap-feedback-select-row"><input type="checkbox" id="apFeedbackSelectAll"><span>Selecionar todos deste filtro</span></label><div><span id="apFeedbackSelectionCount" role="status"></span><button type="button" id="apFeedbackDeleteSelected" disabled>Apagar selecionados</button></div></section><div id="apFeedbackTeacherList"></div><footer class="ap-feedback-footer"><span id="apFeedbackTeacherStatus" role="status"></span><button type="button" id="apFeedbackTeacherRefresh">Atualizar</button></footer>';document.body.appendChild(d);d.querySelector('header button').onclick=()=>d.close();d.addEventListener('close',()=>openedBy?.focus?.({preventScroll:true}));d.querySelector('[type=search]').oninput=e=>{query=e.target.value;selected.clear();render()};$('apFeedbackTeacherRefresh').onclick=()=>refresh();
  d.onclick=async e=>{const f=e.target.closest('[data-feedback-filter]');if(f){filter=f.dataset.feedbackFilter;selected.clear();render();return}const action=e.target.closest('[data-feedback-action]'),id=action?.closest('[data-feedback-id]')?.dataset.feedbackId,r=rows().find(r=>r.id===id);if(!r||!allowed())return;
   if(action.dataset.feedbackAction==='delete')deleteRequest([id]);
   else if(action.dataset.feedbackAction==='read'){if(store(rows().map(v=>v.id===id?{...v,seenAt:new Date().toISOString()}:v)))render()}
   else if(action.dataset.feedbackAction==='retry')retry(id);
   else if(action.dataset.feedbackAction==='profile'){d.close();openStudentProfile(r.studentId)}
   else if(r.response){try{if(action.dataset.feedbackAction==='image'){const rgb=getComputedStyle(d.querySelector('.ap-feedback-heading small')).color.match(/\d+/g),accent=rgb?.length>=3?'#'+rgb.slice(0,3).map(n=>Number(n).toString(16).padStart(2,'0')).join(''):'#b6ff26';await APFeedbackCard.open(r,{professional:typeof trainerProfile==='function'?trainerProfile().name:'Agenda Personal',photo:photo(studentById(r.studentId)),accent})}else if(action.dataset.feedbackAction==='copy'){if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(M.text(r));else{const n=document.createElement('textarea');n.value=M.text(r);d.appendChild(n);n.select();if(!document.execCommand('copy'))throw Error('Selecione o texto no cartão para copiar.');n.remove()}toast('Texto copiado.')}}catch(error){toast(error.message||'Não foi possível preparar o feedback.')}}
  };
  $('apFeedbackTeacherSelect').onclick=()=>{selecting=!selecting;selected.clear();render()};
  $('apFeedbackSelectAll').onchange=e=>{selected.clear();if(e.target.checked)for(const row of visible())selected.add(row.id);render()};
  $('apFeedbackTeacherList').addEventListener('change',e=>{const input=e.target.closest('[data-feedback-select]');if(!input)return;if(input.checked)selected.add(input.dataset.feedbackSelect);else selected.delete(input.dataset.feedbackSelect);selectionStatus()});
  $('apFeedbackDeleteSelected').onclick=()=>deleteRequest([...selected]);
  const confirm=document.createElement('dialog');confirm.id='apFeedbackDelete';confirm.className='ap-feedback ap-feedback-delete-dialog';confirm.setAttribute('aria-labelledby','apFeedbackDeleteTitle');confirm.setAttribute('aria-describedby','apFeedbackDeleteSummary apFeedbackDeleteExplain');
  confirm.innerHTML='<h2 id="apFeedbackDeleteTitle">Apagar feedback?</h2><p id="apFeedbackDeleteSummary"></p><p id="apFeedbackDeleteExplain">O conteúdo será removido da sua lista. O histórico do treino e o cadastro do aluno serão mantidos. Não é possível desfazer.</p><p id="apFeedbackDeletePending" hidden>Pedidos já enviados continuam disponíveis para resposta no aplicativo do aluno.</p><p id="apFeedbackDeleteStatus" role="alert"></p><div class="ap-feedback-delete-buttons"><button type="button" id="apFeedbackDeleteCancel">Cancelar</button><button type="button" id="apFeedbackDeleteConfirm">Apagar</button></div>';
  document.body.appendChild(confirm);$('apFeedbackDeleteCancel').onclick=()=>confirm.close();$('apFeedbackDeleteConfirm').onclick=confirmDelete;
  confirm.addEventListener('close',()=>{const back=pendingDelete?.focus;pendingDelete=null;if(back?.isConnected)back.focus({preventScroll:true})});
  d.addEventListener('close',()=>{confirm.close();selecting=false;selected.clear()});updateBadge();
 }
 function open(){if(!allowed())return toast('Entre como professor para ver os feedbacks.');mount();openedBy=document.activeElement;const d=$('apFeedbackTeacher');if(!d.open)d.showModal();render();refresh();d.querySelector('header button').focus()}
 const oldRender=renderStudents;renderStudents=function(...args){const result=oldRender.apply(this,args);mount();updateBadge();return result};
 const previousSystemBack=handleAgendaSystemBack;handleAgendaSystemBack=function(...args){for(const id of ['apFeedbackDelete','apFeedbackImage','apFeedbackTeacher']){const d=$(id);if(d?.open){d.close();return true}}return previousSystemBack.apply(this,args)};
 window.parent?.addEventListener('ap-account-changed',()=>{epoch++;pendingDelete=null;selected.clear();selecting=false;clearTimeout(timer);$('apFeedbackDelete')?.close();$('apFeedbackTeacher')?.close();$('apFeedbackImage')?.close();updateBadge();schedule()});addEventListener('online',schedule);document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule()});addEventListener('ap-backup-ready',schedule);setInterval(()=>{if(!document.hidden)refresh($('apFeedbackTeacher')?.open===true)},30000);
 window.APFeedbackTeacher=Object.freeze({open,refresh,retry,rows,render});mount();schedule();
})();
