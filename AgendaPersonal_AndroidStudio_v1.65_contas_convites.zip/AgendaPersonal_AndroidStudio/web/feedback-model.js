(function(global){
 'use strict';
 const TEACHER='R2EmnDVcvMWt7TjPxOP6DjW1VOn1',intensities=['Muito leve','Leve','Moderada','Pouco intensa','Intensa','Muito intensa','Muito, muito intensa','Exaustão máxima'];
 const id=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,160}$/.test(v),uid=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(v),time=v=>typeof v==='number'?v:Date.parse(v||'');
 function session(record,student){
  if(!record||!student||student.studentType!=='presencial'||student.archived===true||!id('fb_'+record.id))return null;
  const startedAt=time(record.startedAt),finishedAt=time(record.finishedAt);
  if(!Number.isSafeInteger(startedAt)||!Number.isSafeInteger(finishedAt)||startedAt<=0||finishedAt<startedAt||finishedAt-startedAt>31*86400000)return null;
  return {id:'fb_'+record.id,uid:uid(student.firebaseUid)?student.firebaseUid:'',studentId:student.id,studentName:String(student.name||'Aluno').slice(0,160),planName:String(record.planName||'Treino').slice(0,160),dayName:String(record.dayName||'Treino presencial').slice(0,160),startedAt,finishedAt,teacherEvaluation:{note:String(record.note||'').trim().slice(0,4000),effort:Number.isInteger(record.effort)&&record.effort>=1&&record.effort<=10?record.effort:null}};
 }
 function normalize(raw,owner){
  const online=raw?.source==='online';
  if(!raw||!id(raw.id)||!uid(raw.uid)||raw.uid!==owner||raw.professorId!==TEACHER||typeof raw.studentId!=='string'||!online&&!raw.studentId||raw.studentId.length>200||typeof raw.studentName!=='string'||raw.studentName.length>160||typeof raw.planName!=='string'||raw.planName.length>160||typeof raw.dayName!=='string'||raw.dayName.length>160||!Number.isSafeInteger(raw.startedAt)||!Number.isSafeInteger(raw.finishedAt)||raw.startedAt<=0||raw.finishedAt<raw.startedAt||raw.finishedAt-raw.startedAt>31*86400000)return null;
  let response=null;const r=raw.response;
  if(r){if((online?typeof r.intensity!=='string'||r.intensity.length>60:!intensities.includes(r.intensity))||typeof r.comment!=='string'||r.comment.length>2000||typeof r.allowPublish!=='boolean'&&r.publicationBasis!=='contract'||!id(r.mutationId)||!Number.isFinite(time(r.receivedAt)))return null;response={intensity:r.intensity,comment:r.comment,...(typeof r.allowPublish==='boolean'?{allowPublish:r.allowPublish}:{}),...(r.publicationBasis==='contract'?{publicationBasis:'contract'}:{}),mutationId:r.mutationId,receivedAt:r.receivedAt}}
  const e=raw.teacherEvaluation;let teacherEvaluation=null;if(e!=null){if(typeof e.note!=='string'||e.note.length>4000||e.effort!==null&&(!Number.isInteger(e.effort)||e.effort<1||e.effort>10))return null;teacherEvaluation={note:e.note,effort:e.effort}}
  if(online&&!response)return null;
  return {id:raw.id,uid:raw.uid,studentId:raw.studentId,studentName:raw.studentName,source:online?'online':'presencial',planName:raw.planName,dayName:raw.dayName,startedAt:raw.startedAt,finishedAt:raw.finishedAt,durationSeconds:Math.floor((raw.finishedAt-raw.startedAt)/1000),professorId:TEACHER,createdAt:String(raw.createdAt||''),teacherEvaluation,response};
 }
 const duration=seconds=>{const n=Math.max(0,Math.floor(Number(seconds)||0));return Math.floor(n/60)+' min '+String(n%60).padStart(2,'0')+' s'};
 const stamp=v=>Number.isFinite(time(v))?new Date(time(v)).toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'}):'—';
 function evaluation(item){const e=item.teacherEvaluation;return e?[e.effort!==null?'Esforço observado: '+e.effort+'/10':'',e.note].filter(Boolean).join('\n'):''}
 function text(item){return item.studentName+'\n'+(item.source==='online'?'Online':'Presencial')+' · '+item.dayName+' · '+item.planName+(evaluation(item)?'\n\nAvaliação do professor:\n'+evaluation(item):'')+'\n\nIntensidade do aluno: '+(item.response?.intensity||'Não informada')+'\nFeedback do aluno: '+(item.response?.comment||'Sem comentário.')+'\n\nInício: '+stamp(item.startedAt)+'\nFim: '+stamp(item.finishedAt)+'\nTempo de treino: '+duration(item.durationSeconds)}
 global.APFeedbackModel=Object.freeze({TEACHER,intensities,session,normalize,duration,stamp,text,evaluation,uid});
})(globalThis);
