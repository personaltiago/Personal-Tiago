(function(){
 'use strict';
 if(window.__AP_PUBLIC_REGISTER)return;
 let active=null,returnTarget=null;
 const uid=()=>window.APaccounts?.isTeacher()===true?window.APaccounts.teacherUid?.():null;
 const portraitKey=id=>'agenda_teacher_mascot_portrait_v2_'+encodeURIComponent(id),portraitMemo=new Map();
 const savedState=id=>APMascotModel.read(JSON.parse(localStorage.getItem('agenda_teacher_mascot_v1_'+encodeURIComponent(id))||'null'));
 function chosenPortrait(id,s){
  if(!s.species)return '';
  const phase=APMascotModel.phase(s.xp).id,coat=APMascotModel.color(s),position=APMascotModel.pose(s).id,loaded=APMascotArt.portrait(s);
  if(loaded){const entry={version:4,uid:id,species:s.species,phase,color:coat.id,pose:position,photo:loaded},memo=portraitMemo.get(id);if(memo?.photo!==loaded||memo?.color!==coat.id||memo?.phase!==phase||memo?.pose!==position){portraitMemo.set(id,entry);try{localStorage.removeItem('agenda_teacher_mascot_portrait_v1_'+encodeURIComponent(id));localStorage.setItem(portraitKey(id),JSON.stringify(entry))}catch(_){}}return loaded}
  try{const p=JSON.parse(localStorage.getItem(portraitKey(id))||'null');if(((p?.version===4&&p.color===coat.id&&p.pose===position)||(position==='default'&&p?.version===3&&p.color===coat.id)||(position==='default'&&p?.version===2&&coat.frame===null))&&p.uid===id&&p.species===s.species&&p.phase===phase&&typeof p.photo==='string'&&p.photo.length<3000000&&/^data:image\/(?:webp|png);base64,[A-Za-z0-9+/=]+$/.test(p.photo))return p.photo}catch(_){}
  return '';
 }
 function paint(mark,s,photo){
  const habitat=mark.closest('[data-pet-affection="true"]');if(habitat){if(APMascotPetting.preserve?.(habitat,s))return;APMascotPetting.cancel(habitat)}
  const current=mark.querySelector('image[data-mascot-photo]'),phase=APMascotModel.phase(s.xp).id;
  if(mark.querySelector('svg')?.dataset.mascotPose===APMascotModel.pose(s).id&&mark.querySelector('svg')?.dataset.mascotColor===APMascotModel.color(s).id&&photo&&current?.getAttribute('href')===photo&&current.dataset.mascotPhoto===s.species&&current.dataset.mascotPhotoPhase===phase&&current.getAttribute('transform')===(APMascotArt.mirrored(s)?'translate(320 0) scale(-1 1)':null)){mark.querySelector('svg')?.setAttribute('aria-label',s.name+', '+APMascotModel.choices.find(c=>c.id===s.species)?.name+', '+APMascotModel.phase(s.xp).name+', '+APMascotModel.color(s).name+', visual 3D');return}
  const html=APMascotArt.render(s,true,photo);if(mark.innerHTML!==html)mark.innerHTML=html;
 }
 // Populate the selected image in srcdoc, before the iframe can paint. The
 // optional portrait cache is account/species/phase scoped, never a pet record.
 const prepare=window.APprepareTeacherDocument;
 window.APprepareTeacherDocument=function(source){
  const doc=prepare.apply(this,arguments),id=uid();if(!id||window.__AP_STUDENT_CONTEXT)return doc;
  try{
   const s=savedState(id),enabled=window.APmascot?.isEnabled('teacher:'+id)!==false,photo=enabled?chosenPortrait(id,s):'',escape=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
   return doc.replace(/(<div\b[^>]*\bid="apTeacherMascotOpen"[^>]*>)([\s\S]*?)(<\/div>)/,(_,start,body,end)=>{
    start=start.replace('class="home-card ap-teacher-mascot"','class="home-card ap-teacher-mascot ap-habitat'+(enabled?'':' ap-recado-only')+'"');
    start=start.replace(/>$/,' data-mascot-species="'+escape(s.species||'none')+'" data-mascot-phase="'+APMascotModel.phase(s.xp).id+'" data-mascot-pose="'+APMascotModel.pose(s).id+'" data-mascot-home="'+escape(s.equipped.home)+'" style="--pet-mouth:'+APMascotHomes.mouth(s)+';background-image:'+escape(enabled?APMascotHomes.background(s):'none')+'">');
    return start+body.replace(/(<span class="ap-teacher-mascot-mark"[^>]*>)[\s\S]*?<\/span>/,(_,mark)=>mark+(enabled?APMascotArt.render(s,true,photo):'')+'</span>').replace(/<strong(?: data-mascot-name)?>(?:Seu mascote)?<\/strong>/,'<strong data-mascot-name>'+escape(s.name)+'</strong>')+(enabled?'':APMascotMessages.compactMarkup('Carregando recados…'))+end;
   });
  }catch(_){return doc}

 };
 const context=()=>active&&!window.__AP_STUDENT_CONTEXT&&uid()===active.uid?active:null;
 const key=()=>{const c=context();if(!c)throw Error('Entre como professor.');return 'agenda_teacher_mascot_v1_'+encodeURIComponent(c.uid)};
 function read(){try{return {mascot:JSON.parse(localStorage.getItem(key())||'null')}}catch(_){return {mascot:null}}}
 function save(store){try{localStorage.setItem(key(),JSON.stringify(store.mascot));return true}catch(_){return false}}
 function prefs(){try{const frame=document.getElementById('apPreviewTeacher').contentWindow,colors=frame.AgendaColors.get();return {color:colors.primary,mode:frame.AgendaAppearance.getMode()==='light'?'claro':'escuro'}}catch(_){return {}}}
 function leave(){active=null;const node=returnTarget;returnTarget=null;if(node?.isConnected)node.focus()}
 function refreshCard(){
  try{
   const id=uid(),frame=document.getElementById('apPreviewTeacher');if(!id||!frame?.contentDocument)return;
   const card=frame.contentDocument.getElementById('apTeacherMascotOpen'),mark=card?.querySelector('.ap-teacher-mascot-mark');if(!card)return;
   const enabled=window.APmascot?.isEnabled('teacher:'+id)!==false;
   APMascotPetting.bind(card,()=>savedState(uid()),()=>!!uid()&&!window.__AP_STUDENT_CONTEXT&&document.getElementById('apMascot')?.hidden!==false&&window.APmascot?.isEnabled('teacher:'+uid())!==false);
   const result=APMascotMessages.teacher(frame.contentWindow.APmascotDaySummary?.(),new Date(),id),message=card.querySelector('#apTeacherMascotMessage');
   if(message){message.textContent=result.text;card.dataset.dayType=result.kind}
   APMascotMessages.present(card,result.text,enabled);if(!enabled||!mark)return;
   const s=savedState(id),title=card.querySelector('strong');if(title)title.textContent=s.name;
   if(!card.dataset.petAffection)APMascotHomes.decorate(card,s);
   paint(mark,s,chosenPortrait(id,s));
  }catch(_){}
 }
 function open(initialTab='colors'){
  const id=uid(),overlay=document.getElementById('apPreviewOverlay'),frame=document.getElementById('apPreviewTeacher');
  if(!id||!overlay?.classList.contains('is-open')||window.__AP_STUDENT_CONTEXT)return false;
  const card=frame?.contentDocument?.getElementById('apTeacherMascotOpen');if(card)APMascotPetting.cancel(card);
  window.APmascot.close(false);
  returnTarget=frame?.contentDocument?.activeElement?.closest('button')||frame?.contentDocument?.getElementById('morePet')||null;
  active={uid:id,storageId:'teacher:'+id,role:'teacher',area:{enabled:true,plans:[]}};
  window.APmascot.open(initialTab);return true;
 }
 function change(value,action,id){
  if(!context())return {ok:false,error:'Entre como professor.'};
  const s=APMascotModel.read(value);
  if(action==='test-workout'){s.coins=Math.min(100000000,s.coins+100);s.xp=Math.min(100000000,s.xp+100);s.events.unshift({at:Date.now(),text:'Teste do professor · +100 moedas · +100 XP'});s.events=s.events.slice(0,40);return {ok:true,state:s,message:'Treino simulado. +100 moedas e +100 XP somente para seu mascote.',reaction:'play'}}
  if(action==='test-phase'){
   const phases={baby:[0,'Filhote'],teen:[600,'Adolescente'],adult:[1800,'Adulto']};if(!Object.hasOwn(phases,id))return {ok:false};
   s.xp=phases[id][0];s.events.unshift({at:Date.now(),text:'Teste da fase '+phases[id][1]});s.events=s.events.slice(0,40);return {ok:true,state:s,message:'Fase '+phases[id][1]+' em teste. Moedas e itens preservados.'};
  }
  return {ok:false};
 }
 window.addEventListener('message',event=>{if(event.data?.kind==='AP_OPEN_TEACHER_MASCOT'&&event.source===document.getElementById('apPreviewTeacher')?.contentWindow)open(event.data.tab==='house'?'house':'colors')});
 window.addEventListener('ap-teacher-ready',()=>{refreshCard();const account=uid();setTimeout(()=>{if(uid()===account&&window.APmascot?.isEnabled('teacher:'+account)!==false)APMascotArt.load()},1500)});
 window.addEventListener('ap-mascot-art-ready',refreshCard);
 window.addEventListener('ap-mascot-homes-ready',refreshCard);
 window.APteacherMascot=Object.freeze({context,read,save,prefs,leave,open,change,refreshCard});
})();
