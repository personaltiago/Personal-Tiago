(function(){
 'use strict';
 if(window.__AP_PUBLIC_REGISTER)return;
 let active=null,returnTarget=null;
 const uid=()=>window.APaccounts?.isTeacher()===true?window.APaccounts.teacherUid?.():null;
 const context=()=>active&&!window.__AP_STUDENT_CONTEXT&&uid()===active.uid?active:null;
 const key=()=>{const c=context();if(!c)throw Error('Entre como professor.');return 'agenda_teacher_mascot_v1_'+encodeURIComponent(c.uid)};
 function read(){try{return {mascot:JSON.parse(localStorage.getItem(key())||'null')}}catch(_){return {mascot:null}}}
 function save(store){try{localStorage.setItem(key(),JSON.stringify(store.mascot));return true}catch(_){return false}}
 function prefs(){try{const frame=document.getElementById('apPreviewTeacher').contentWindow,colors=frame.AgendaColors.get();return {color:colors.primary,mode:frame.AgendaAppearance.getMode()==='light'?'claro':'escuro'}}catch(_){return {}}}
 function leave(){active=null;const node=returnTarget;returnTarget=null;if(node?.isConnected)node.focus()}
 function refreshCard(){
  try{
   const id=uid(),frame=document.getElementById('apPreviewTeacher');if(!id||!frame?.contentDocument)return;
   const card=frame.contentDocument.getElementById('apTeacherMascotOpen'),mark=card?.querySelector('.ap-teacher-mascot-mark');if(!mark)return;
   card.hidden=window.APmascot?.isEnabled('teacher:'+id)===false;
   const stored=JSON.parse(localStorage.getItem('agenda_teacher_mascot_v1_'+encodeURIComponent(id))||'null'),s=APMascotModel.read(stored);
   const result=APMascotMessages.teacher(frame.contentWindow.APmascotDaySummary?.(),new Date(),id),message=card.querySelector('#apTeacherMascotMessage');
   if(message){message.textContent=result.text;card.dataset.dayType=result.kind}
   const title=card.querySelector('strong');if(title)title.textContent=s.species?'Seu mascote · '+s.name:'Seu mascote';
   if(APMascotArt.ready())mark.innerHTML=APMascotArt.render(s.species?s:{...s,species:'capybara'},true);
  }catch(_){}
 }
 function open(){
  const id=uid(),overlay=document.getElementById('apPreviewOverlay'),frame=document.getElementById('apPreviewTeacher');
  if(!id||!overlay?.classList.contains('is-open')||window.__AP_STUDENT_CONTEXT)return false;
  window.APmascot.close(false);
  returnTarget=frame?.contentDocument?.activeElement?.closest('button')||frame?.contentDocument?.getElementById('morePet')||null;
  active={uid:id,storageId:'teacher:'+id,role:'teacher',area:{enabled:true,plans:[]}};
  window.APmascot.open();return true;
 }
 function change(value,action,id){
  if(!context())return {ok:false,error:'Entre como professor.'};
  const s=APMascotModel.read(value);
  if(action==='test-workout'){s.coins=Math.min(100000000,s.coins+100);s.xp=Math.min(100000000,s.xp+100);s.events.unshift({at:Date.now(),text:'Teste do professor · +100 moedas · +100 XP'});s.events=s.events.slice(0,40);return {ok:true,state:s,message:'Treino simulado. +100 moedas e +100 XP somente para seu mascote.',reaction:'play'}}
  if(action==='test-phase'){
   const phases={baby:[0,'Filhote'],teen:[600,'Adolescente'],adult:[1800,'Adulto']};if(!Object.hasOwn(phases,id))return {ok:false};
   s.xp=phases[id][0];s.events.unshift({at:Date.now(),text:'Teste da fase '+phases[id][1]});s.events=s.events.slice(0,40);return {ok:true,state:s,message:'Fase '+phases[id][1]+' em teste. Moedas e itens preservados.'};
  }
  return {ok:false};
 }
 window.addEventListener('message',event=>{if(event.data?.kind==='AP_OPEN_TEACHER_MASCOT'&&event.source===document.getElementById('apPreviewTeacher')?.contentWindow)open()});
 window.addEventListener('ap-teacher-ready',()=>{APMascotArt.load();refreshCard()});
 window.addEventListener('ap-mascot-art-ready',refreshCard);
 window.APteacherMascot=Object.freeze({context,read,save,prefs,leave,open,change,refreshCard});
})();
