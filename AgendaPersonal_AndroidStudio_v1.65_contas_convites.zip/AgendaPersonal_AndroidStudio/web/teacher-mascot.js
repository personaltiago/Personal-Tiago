(function(){
 'use strict';
 if(window.__AP_PUBLIC_REGISTER)return;
 let active=null,returnTarget=null;
 const uid=()=>window.APaccounts?.isTeacher()===true?window.APaccounts.teacherUid?.():null;
 const portraitKey=id=>'agenda_teacher_mascot_portrait_v1_'+encodeURIComponent(id),portraitMemo=new Map();
 const savedState=id=>APMascotModel.read(JSON.parse(localStorage.getItem('agenda_teacher_mascot_v1_'+encodeURIComponent(id))||'null'));
 function chosenPortrait(id,s){
  if(!s.species)return '';
  const phase=APMascotModel.phase(s.xp).id,loaded=APMascotArt.portrait(s);
  if(loaded){const entry={version:1,uid:id,species:s.species,phase,photo:loaded};if(portraitMemo.get(id)!==loaded){portraitMemo.set(id,loaded);try{localStorage.setItem(portraitKey(id),JSON.stringify(entry))}catch(_){}}return loaded}
  try{const p=JSON.parse(localStorage.getItem(portraitKey(id))||'null');if(p?.version===1&&p.uid===id&&p.species===s.species&&p.phase===phase&&typeof p.photo==='string'&&p.photo.length<1000000&&/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(p.photo))return p.photo}catch(_){}
  return '';
 }
 function paint(mark,s,photo){
  const current=mark.querySelector('image[data-mascot-photo]'),phase=APMascotModel.phase(s.xp).id;
  if(photo&&current?.getAttribute('href')===photo&&current.dataset.mascotPhoto===s.species&&current.dataset.mascotPhotoPhase===phase){mark.querySelector('svg')?.setAttribute('aria-label',s.name+', '+APMascotModel.choices.find(c=>c.id===s.species)?.name+', '+APMascotModel.phase(s.xp).name+', visual 3D');return}
  const html=APMascotArt.render(s,true,photo);if(mark.innerHTML!==html)mark.innerHTML=html;
 }
 // Populate the selected image in srcdoc, before the iframe can paint. The
 // optional portrait cache is account/species/phase scoped, never a pet record.
 const prepare=window.APprepareTeacherDocument;
 window.APprepareTeacherDocument=function(source){
  const doc=prepare.apply(this,arguments),id=uid();if(!id||window.__AP_STUDENT_CONTEXT)return doc;
  try{const s=savedState(id),photo=chosenPortrait(id,s),escape=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));return doc.replace(/(<button\b[^>]*\bid="apTeacherMascotOpen"[^>]*>)([\s\S]*?)(<\/button>)/,(_,open,body,end)=>(window.APmascot?.isEnabled('teacher:'+id)===false?open.replace(/>$/,' hidden>'):open)+body.replace(/(<span class="ap-teacher-mascot-mark"[^>]*>)[\s\S]*?<\/span>/,(_,start)=>start+APMascotArt.render(s,true,photo)+'</span>').replace('<strong>Seu mascote</strong>','<strong>'+escape(s.species?'Seu mascote · '+s.name:'Seu mascote')+'</strong>')+end)}catch(_){return doc}
 };
 const context=()=>active&&!window.__AP_STUDENT_CONTEXT&&uid()===active.uid?active:null;
 const key=()=>{const c=context();if(!c)throw Error('Entre como professor.');return 'agenda_teacher_mascot_v1_'+encodeURIComponent(c.uid)};
 function read(){try{return {mascot:JSON.parse(localStorage.getItem(key())||'null')}}catch(_){return {mascot:null}}}
 function save(store){try{localStorage.setItem(key(),JSON.stringify(store.mascot));return true}catch(_){return false}}
 function prefs(){try{const frame=document.getElementById('apPreviewTeacher').contentWindow,colors=frame.AgendaColors.get();return {color:colors.primary,mode:frame.AgendaAppearance.getMode()==='light'?'claro':'escuro'}}catch(_){return {}}}
 function leave(){active=null;const node=returnTarget;returnTarget=null;if(node?.isConnected)node.focus()}
 function refreshCard(){
  try{
   const id=uid(),frame=document.getElementById('apPreviewTeacher');if(!id||!frame?.contentDocument)return;
   const card=frame.contentDocument.getElementById('apTeacherMascotOpen'),mark=card?.querySelector('.ap-teacher-mascot-mark');if(!mark)return;
   card.hidden=window.APmascot?.isEnabled('teacher:'+id)===false;
   const s=savedState(id);
   const result=APMascotMessages.teacher(frame.contentWindow.APmascotDaySummary?.(),new Date(),id),message=card.querySelector('#apTeacherMascotMessage');
   if(message){message.textContent=result.text;card.dataset.dayType=result.kind}
   const title=card.querySelector('strong');if(title)title.textContent=s.species?'Seu mascote · '+s.name:'Seu mascote';
   paint(mark,s,chosenPortrait(id,s));
  }catch(_){}
 }
 function open(){
  const id=uid(),overlay=document.getElementById('apPreviewOverlay'),frame=document.getElementById('apPreviewTeacher');
  if(!id||!overlay?.classList.contains('is-open')||window.__AP_STUDENT_CONTEXT)return false;
  window.APmascot.close(false);
  returnTarget=frame?.contentDocument?.activeElement?.closest('button')||frame?.contentDocument?.getElementById('morePet')||null;
  active={uid:id,storageId:'teacher:'+id,role:'teacher',area:{enabled:true,plans:[]}};
  window.APmascot.open();return true;
 }
 function change(value,action,id){
  if(!context())return {ok:false,error:'Entre como professor.'};
  const s=APMascotModel.read(value);
  if(action==='test-workout'){s.coins=Math.min(100000000,s.coins+100);s.xp=Math.min(100000000,s.xp+100);s.events.unshift({at:Date.now(),text:'Teste do professor · +100 moedas · +100 XP'});s.events=s.events.slice(0,40);return {ok:true,state:s,message:'Treino simulado. +100 moedas e +100 XP somente para seu mascote.',reaction:'play'}}
  if(action==='test-phase'){
   const phases={baby:[0,'Filhote'],teen:[600,'Adolescente'],adult:[1800,'Adulto']};if(!Object.hasOwn(phases,id))return {ok:false};
   s.xp=phases[id][0];s.events.unshift({at:Date.now(),text:'Teste da fase '+phases[id][1]});s.events=s.events.slice(0,40);return {ok:true,state:s,message:'Fase '+phases[id][1]+' em teste. Moedas e itens preservados.'};
  }
  return {ok:false};
 }
 window.addEventListener('message',event=>{if(event.data?.kind==='AP_OPEN_TEACHER_MASCOT'&&event.source===document.getElementById('apPreviewTeacher')?.contentWindow)open()});
 window.addEventListener('ap-teacher-ready',()=>{refreshCard();const account=uid();setTimeout(()=>{if(uid()===account&&window.APmascot?.isEnabled('teacher:'+account)!==false)APMascotArt.load()},1500)});
 window.addEventListener('ap-mascot-art-ready',refreshCard);
 window.APteacherMascot=Object.freeze({context,read,save,prefs,leave,open,change,refreshCard});
})();
