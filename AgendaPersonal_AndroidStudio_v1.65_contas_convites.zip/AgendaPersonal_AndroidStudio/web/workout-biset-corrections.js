  // These helpers run inside the existing A/B journal closure.
  function correctionValues(p,day,g,j){
    const draft=state.workoutDrafts[workoutDraftKey(p.id,day.id)],values={...draft.values};
    for(const [i,part]of ['A','B'].entries()){
      const exId=g.exerciseIds[i],done=j.rounds.flatMap(r=>r[part]?[r[part]]:[]),last=done.at(-1);
      values[exId]={...values[exId],done:done.length>0,sets:String(done.length),reps:last?String(last.reps):'',load:last?.load||''};
    }
    return values;
  }
  function correctRecordedBisetInput(input,p,day,g,j,index,part,field){
    if(field==='reps'&&!integer(Number(input.value),1,999))return;
    const value=field==='load'?workoutSeriesRecordedLoad(input.value).slice(0,60):Number(input.value),rounds=j.rounds.map(r=>({...r}));
    rounds[index][part]={...rounds[index][part],[field]:value};const next={...j,rounds},drafts=draftWithJournal(p,day,g,next,correctionValues(p,day,g,next));
    try{localStorage.setItem(DB_KEY,JSON.stringify({...state,workoutDrafts:drafts}));state.workoutDrafts=drafts}
    catch(_){input.value=field==='load'?String(j.rounds[index][part].load).replace(/\s*kg\s*$/i,''):j.rounds[index][part].reps;toast('Não foi possível salvar a correção. O registro anterior foi mantido.',5500)}
  }
  window.reopenWorkoutBisetSeries=function(input){
    const {p,day,g}=guideContext(),part=input.dataset.seriesPart,index=Number(input.dataset.seriesRound)-1;
    if(!p||!day||!g||g.id!==input.dataset.seriesGroup||workoutPlanArchived(p)||!workoutRunning(p,day)||!['A','B'].includes(part)||!integer(index,0,g.rounds-1)){input.checked=true;return}
    const j=journal(p,day,g),record=j.rounds[index]?.[part];if(!record){input.checked=false;return}
    const later=j.rounds.reduce((count,r,i)=>count+(i>index?Number(!!r.A)+Number(!!r.B):i===index&&part==='A'?Number(!!r.B):0),0);
    if(later&&!confirm('Reabrir esta série e desmarcar '+(later===1?'a série seguinte':'as '+later+' séries seguintes')+' da dupla?\n\nAs cargas e repetições serão mantidas para conferir e marcar novamente, seguindo A → B.')){input.checked=true;return}
    const entries=JSON.parse(JSON.stringify(j.entries||{}));
    for(let i=index;i<j.rounds.length;i++)for(const letter of ['A','B']){
      if(i===index&&part==='B'&&letter==='A')continue;const old=j.rounds[i]?.[letter];if(!old)continue;
      entries[i]={...entries[i],[letter]:{...entries[i]?.[letter],reps:String(old.reps),load:old.load}};
    }
    const rounds=j.rounds.slice(0,index+(part==='B'?1:0)).map(r=>({...r}));if(part==='B')delete rounds[index].B;
    const next={...j,rounds,entries,pending:{},restAfter:null,restUntil:0,restId:''},changes={workoutDrafts:draftWithJournal(p,day,g,next,correctionValues(p,day,g,next))};
    const rest=state.workoutRest,cancel=rest?.planId===p.id&&rest.dayId===day.id&&rest.bisetId===g.id;if(cancel)changes.workoutRest=null;
    if(!commitWorkoutChange(changes,'',false)){input.checked=true;return}if(cancel)cancelNativeWorkoutRest();
    const sheet=document.querySelector('#workoutBisetDialog .sheet'),top=sheet?.scrollTop||0;renderWorkoutDay();renderGuide();if(sheet)sheet.scrollTop=top;updateWorkoutProgress();toast('Série reaberta. Cargas e repetições mantidas.');
  };
