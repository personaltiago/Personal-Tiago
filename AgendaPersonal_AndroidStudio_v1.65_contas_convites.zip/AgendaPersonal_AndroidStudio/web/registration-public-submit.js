import {initializeApp} from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js';
import {getAuth,createUserWithEmailAndPassword,signInWithEmailAndPassword,updateProfile} from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js';
import {getFirestore,doc,getDoc,setDoc,updateDoc,serverTimestamp} from 'https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js';
const app=initializeApp({apiKey:'AIzaSyCiu1dqqya8vI3DLTWChz6IoW8wWRg0mtE',authDomain:'agenda-personal-bdb58.firebaseapp.com',projectId:'agenda-personal-bdb58',storageBucket:'agenda-personal-bdb58.firebasestorage.app',messagingSenderId:'1044097605904'});
const auth=getAuth(app),db=getFirestore(app),professorId='R2EmnDVcvMWt7TjPxOP6DjW1VOn1';
const $=id=>document.getElementById(id),form=$('form'),status=$('status'),submit=$('submit');let busy=false;
function message(text,type){status.textContent=text;status.className='status show '+type}
$('nascimento').max=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10);
$('whatsapp').addEventListener('input',e=>{let n=e.target.value.replace(/\D/g,'').slice(0,11);e.target.value=n.length>10?`(${n.slice(0,2)}) ${n.slice(2,7)}-${n.slice(7)}`:n.length>6?`(${n.slice(0,2)}) ${n.slice(2,6)}-${n.slice(6)}`:n.length>2?`(${n.slice(0,2)}) ${n.slice(2)}`:n});
form.addEventListener('submit',async e=>{
 e.preventDefault();if(busy)return;status.className='status';
 const nome=$('nome').value.trim(),email=$('email').value.trim().toLowerCase(),whatsapp=$('whatsapp').value.trim(),nascimento=$('nascimento').value,genero=$('genero').value,senha=$('senha').value;
 if(senha!==$('confirmar').value){message('As senhas não são iguais.','error');return}
 if(whatsapp.replace(/\D/g,'').length<10){message('Digite um WhatsApp válido com DDD.','error');return}
 let fotoCadastro='';try{fotoCadastro=window.APRegistrationPhoto.value()}catch(error){message(error.message,'error');return}
 busy=true;submit.disabled=true;submit.textContent='Enviando…';
 try{
  let user=auth.currentUser;
  if(!user||String(user.email||'').toLowerCase()!==email){try{user=(await createUserWithEmailAndPassword(auth,email,senha)).user}catch(error){if(error.code!=='auth/email-already-in-use')throw error;user=(await signInWithEmailAndPassword(auth,email,senha)).user}}
  if(user.uid===professorId)throw Error('Use o e-mail do aluno para solicitar cadastro.');
  const ref=doc(db,'usuarios',user.uid),prior=await getDoc(ref);let approved=false;
  if(prior.exists()){
   const current=prior.data();if(current.professorId!==professorId||current.perfil!=='aluno')throw Error('Esta conta já possui outro cadastro. Fale com o professor.');
   approved=current.ativo===true;if(fotoCadastro&&!approved)await updateDoc(ref,{fotoCadastro});
  }else{
   const data={nome,email,whatsapp,nascimento,genero,perfil:'aluno',ativo:false,professorId,criadoEm:serverTimestamp()};if(fotoCadastro)data.fotoCadastro=fotoCadastro;
   await setDoc(ref,data);try{await updateProfile(user,{displayName:nome})}catch(_){}
  }
  form.style.display='none';$('done').style.display='block';if(approved){$('done').querySelector('h2').textContent='Seu cadastro já foi aprovado.';$('done').querySelector('p').textContent='Entre no aplicativo com seu e-mail e sua senha.'}
 }catch(error){
  const readable={'auth/invalid-credential':'Esse e-mail já tem cadastro. Confira a senha e tente novamente.','auth/invalid-email':'Digite um e-mail válido.','auth/weak-password':'A senha precisa ter pelo menos 6 caracteres.','auth/operation-not-allowed':'O cadastro por e-mail ainda não está habilitado.','permission-denied':fotoCadastro?'O cadastro com foto precisa ser liberado nas permissões do formulário pelo professor. Sua foto foi mantida para tentar novamente.':'O formulário ainda não tem permissão para receber este cadastro. Avise o professor.'};
  message(readable[error.code]||error.message||'Não foi possível enviar agora. Confira sua internet e tente novamente.','error');
 }finally{busy=false;submit.disabled=false;submit.textContent='Enviar cadastro'}
});
