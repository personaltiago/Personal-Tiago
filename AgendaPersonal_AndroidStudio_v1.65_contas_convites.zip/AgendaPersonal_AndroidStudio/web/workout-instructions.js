(function(){
'use strict';
const visibility=new Map();let serial=0;
function identity(exercise){const plan=currentWorkoutPlan(),day=currentWorkoutDay();return JSON.stringify([plan?.studentId,plan?.id,day?.id,exercise])}
function apply(button,box,expanded,key){visibility.set(key,expanded);button.setAttribute('aria-expanded',String(expanded));box.hidden=!expanded;}
function decorate(){
 const root=document.getElementById('workoutDayContent');if(!root||workoutExercisesOrdering)return;
 for(const card of root.querySelectorAll('.workout-exercise[data-exercise-id]')){
  const reader=card.querySelector('details[data-exercise-id]'),body=card.querySelector('.workout-exercise-body');if(!reader||!body)continue;
  const completed=card.classList.contains('is-completed');if(!completed)reader.open=true;
  if(card.querySelector('.ap-instruction-toggle'))continue;
  const summary=reader.querySelector(':scope > summary');if(summary){summary.tabIndex=-1;summary.addEventListener('click',event=>event.preventDefault());}reader.classList.add('ap-instruction-reader');
  const notes=[...body.querySelectorAll(':scope > .workout-note,:scope > .workout-reference-note,:scope > .wt-prescription > p')];
  if(!notes.length)continue;
  const box=document.createElement('div');box.className='ap-instruction-copy';box.id='apExerciseInstructions'+(++serial);notes.forEach(note=>box.append(note));body.append(box);
  const button=document.createElement('button');button.type='button';button.className='ap-instruction-toggle';button.innerHTML='<span>Instruções</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';button.setAttribute('aria-controls',box.id);button.setAttribute('aria-label','Instruções de '+(summary?.querySelector('strong')?.textContent||'exercício'));
  const key=identity(card.dataset.exerciseId);apply(button,box,visibility.get(key)??true,key);button.onclick=()=>apply(button,box,button.getAttribute('aria-expanded')!=='true',key);reader.insertBefore(button,body);
 }
 for(const part of root.querySelectorAll('.biset-part')){
  const notes=part.querySelector('details.workout-guidance');if(!notes)continue;notes.classList.add('ap-biset-instructions');const label=notes.querySelector('summary');if(label)label.textContent='Instruções';const heading=part.querySelector('.ws-biset-video-heading');if(heading)heading.after(notes);
  for(const p of part.querySelectorAll('.wt-prescription > p'))notes.append(p);
 }
 for(const [name,label] of [['expandWorkoutExercises','Mostrar instruções'],['collapseWorkoutExercises','Ocultar instruções']]){const button=root.querySelector('[onclick="'+name+'()"]');if(button){button.textContent=label;button.classList.add('ap-instruction-bulk')}}
}
function all(expanded){decorate();const root=document.getElementById('workoutDayContent');for(const button of root.querySelectorAll('.ap-instruction-toggle')){const box=document.getElementById(button.getAttribute('aria-controls')),card=button.closest('.workout-exercise');if(box&&card)apply(button,box,expanded,identity(card.dataset.exerciseId))}root.querySelectorAll('details.workout-guidance').forEach(node=>node.open=expanded);}
const render=renderWorkoutDay;renderWorkoutDay=function(...args){const result=render(...args);decorate();return result};
const completion=updateWorkoutExerciseCompletion;updateWorkoutExerciseCompletion=function(...args){const result=completion(...args);decorate();return result};
window.expandWorkoutExercises=()=>all(true);window.collapseWorkoutExercises=()=>all(false);
decorate();
})();
