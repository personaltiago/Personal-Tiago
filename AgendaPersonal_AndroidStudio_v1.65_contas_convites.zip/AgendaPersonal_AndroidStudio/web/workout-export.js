(function(){
 'use strict';
 let busy=false;
 const account=()=>window.APaccounts||window.parent?.APaccounts;
 const sync=()=>window.APWorkoutSync||window.parent?.APWorkoutSync;
 const current=(sid,pid,uid)=>account()?.isTeacher()===true&&account()?.teacherUid?.()===uid&&currentWorkoutPlan()?.id===pid&&currentWorkoutPlan()?.studentId===sid&&workoutStudentId===sid;
 function prescriptions(plan){
  const out={};for(const day of plan.days||[])for(const original of day.exercises||[]){
   const group=window.workoutBisetGroups?.(day).find(g=>g.exerciseIds.includes(original.id)),ex=group?window.workoutBisetExercisePrescription(day,group,original):original,tech=window.workoutTechniquePrescription?.(ex),count=group?.rounds||tech?.rows.reduce((n,r)=>n+r.sets,0)||Number(ex.sets);
   const rows=Number.isInteger(count)&&count>0&&count<=100?Array.from({length:count},(_,i)=>{const r=window.workoutTechniqueRoundPrescription?.(ex,i+1,count);return {round:i+1,reps:r?.reps??ex.reps,load:r?.load??ex.load,rest:group?(group.exerciseIds[0]===ex.id?'Sem pausa':group.restSeconds+' s'):r?.restSeconds!==undefined?r.restSeconds+' s':ex.rest}}):[];
   out[JSON.stringify([day.id,original.id])]={sets:Number.isInteger(count)&&count>0?count:ex.sets,reps:ex.reps,load:ex.load,rest:group?(group.exerciseIds[0]===ex.id?'Sem pausa':group.restSeconds+' s'):ex.rest,technique:tech?.name,notes:tech?.observations,rows};
  }return out;
 }
 window.downloadSelectedWorkout=async function(button){
  if(busy)return;
  const p=currentWorkoutPlan(),s=studentById(p?.studentId),uid=account()?.teacherUid?.();
  if(!p||!s||!uid||!current(s.id,p.id,uid))return toast('Entre como professor e selecione a ficha do aluno.');
  const selectedUid=s.firebaseUid||'';busy=true;button?.setAttribute('aria-busy','true');if(button)button.disabled=true;
  try{
   toast('Preparando a ficha para download…');
   let phoneStatus='Registros do aplicativo: aluno sem conta vinculada.',phone=[];const source=sync();
   if(selectedUid&&source){
    try{await source.refresh(selectedUid);phoneStatus='Registros do aplicativo: '+(source.summary(selectedUid)?.message||'consulta concluída.')}
    catch(_){phoneStatus='Registros do aplicativo: não foi possível consultar agora. Foram usados somente os registros já recebidos neste aparelho.'}
    phone=source.records(selectedUid);
   }else if(selectedUid)phoneStatus='Registros do aplicativo: consulta indisponível neste aparelho.';
   if(!current(s.id,p.id,uid)||(studentById(s.id)?.firebaseUid||'')!==selectedUid)throw Error('A seleção ou a conta mudou. Abra a ficha desejada e tente novamente.');
   const plan=JSON.parse(JSON.stringify(currentWorkoutPlan())),student=studentById(s.id);
   const text=APWorkoutExportModel.build({student,plan,executions:state.workoutExecutions,phoneRecords:phone,observations:state.workoutExerciseNotes,prescriptions:prescriptions(plan),phoneStatus});
   const slug=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9_-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,35)||'Treino';
   const now=new Date(),localDate=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-');
   const filename='Treino_'+slug(student.name)+'_'+slug(plan.name)+'_'+localDate+'.txt',bytes=new TextEncoder().encode('\uFEFF'+text);
   if(window.Android&&typeof Android.saveBase64File==='function'){
    const result=Android.saveBase64File(filename,'text/plain',workoutImportBytesToBase64(bytes));if(result===false)throw Error('Não foi possível solicitar o salvamento.');
    toast('Arquivo preparado. Aguarde a confirmação do Android em Downloads/Agenda Personal.');
   }else{const url=URL.createObjectURL(new Blob([bytes],{type:'text/plain;charset=utf-8'})),link=document.createElement('a');link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);toast('Ficha TXT preparada para download.');}
  }catch(e){toast(e.message||'Não foi possível exportar a ficha.',7500)}
  finally{busy=false;button?.removeAttribute('aria-busy');if(button)button.disabled=false;}
 };
})();
