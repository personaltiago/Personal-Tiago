(function(){
'use strict';
let dismissed='',position=null,dragging=null;
try{const saved=JSON.parse(sessionStorage.getItem('ap_rest_floating_position_v1')||'null');if(Number.isFinite(saved?.x)&&Number.isFinite(saved?.y))position=saved}catch(_){}
function savePosition(){try{if(position)sessionStorage.setItem('ap_rest_floating_position_v1',JSON.stringify(position))}catch(_){}}
const widget=document.createElement('aside');widget.id='apRestFloating';widget.className='ap-rest-float';widget.setAttribute('aria-label','Intervalo em andamento');widget.hidden=true;
widget.innerHTML='<button class="ap-rest-grip" type="button" aria-label="Arrastar cronômetro. Use também as setas do teclado."><svg viewBox="0 0 18 24" aria-hidden="true"><path d="M5 5h.01M12 5h.01M5 12h.01M12 12h.01M5 19h.01M12 19h.01" stroke-width="3.5"/></svg></button><button class="ap-rest-open" type="button" aria-label="Abrir intervalo"><span class="ap-rest-copy"><small>INTERVALO</small><strong></strong></span><span class="ap-rest-time" role="timer"></span></button><button class="ap-rest-close" type="button" aria-label="Ocultar contagem sem encerrar o intervalo">×</button>';
document.body.append(widget);
const grip=widget.querySelector('.ap-rest-grip'),name=widget.querySelector('strong'),clock=widget.querySelector('.ap-rest-time');
function native(){try{return window.Android||window.parent?.Android}catch(_){return null}}
function key(rest){return rest?rest.id+'|'+rest.endAt:''}
function overlayStatus(){try{return JSON.parse(native()?.getTimerOverlayStatus?.()||'{}')}catch(_){return {}}}
function move(x,y){const box=widget.getBoundingClientRect(),width=box.width||286,height=box.height||64;position={x:Math.max(8,Math.min(x,Math.max(8,innerWidth-width-8))),y:Math.max(8,Math.min(y,Math.max(8,innerHeight-height-8)))};widget.style.left=position.x+'px';widget.style.top=position.y+'px';widget.style.bottom='auto'}
function refresh(){
 const rest=state.workoutRest,remaining=rest?Math.max(0,Math.ceil((rest.endAt-Date.now())/1000)):0;
 const minimized=document.getElementById('workoutRestFloat');if(minimized)minimized.hidden=!remaining;
 const status=overlayStatus(),nativeVisible=status.showing===true&&status.kind==='workout-rest',nativeDismissed=status.dismissed===true;
 widget.hidden=!remaining||dismissed===key(rest)||document.getElementById('workoutRestDialog')?.classList.contains('open')||nativeVisible||nativeDismissed;
 if(!remaining)return;
 name.textContent=rest.exercise;name.title=rest.student+' · '+rest.exercise;clock.textContent=Math.floor(remaining/60)+':'+String(remaining%60).padStart(2,'0');
 if(position&&!widget.hidden)move(position.x,position.y);
}
window.floatWorkoutRest=function(){
 const rest=state.workoutRest;if(!rest||rest.endAt<=Date.now())return toast('Inicie o intervalo primeiro.');
 dismissed='';closeDialog('workoutRestDialog');
 const api=native();if(rest.native&&!window.APTimerCompatibility?.legacy()&&typeof api?.showWorkoutRestOverlay==='function')api.showWorkoutRestOverlay();
 refresh();
};
const saveRest=saveWorkoutRest;
saveWorkoutRest=function(...args){
 const before=key(state.workoutRest),result=saveRest(...args),rest=state.workoutRest;
 if(rest&&key(rest)!==before&&rest.endAt>Date.now()){
  dismissed='';closeDialog('workoutRestDialog');refresh();
 }
 return result;
};
widget.querySelector('.ap-rest-open').onclick=()=>resumeWorkoutRest();
widget.querySelector('.ap-rest-close').onclick=()=>{dismissed=key(state.workoutRest);refresh()};
grip.addEventListener('pointerdown',event=>{if(event.button!==0)return;const box=widget.getBoundingClientRect();dragging={id:event.pointerId,x:event.clientX,y:event.clientY,left:box.left,top:box.top};grip.setPointerCapture(event.pointerId);event.preventDefault()});
grip.addEventListener('pointermove',event=>{if(!dragging||event.pointerId!==dragging.id)return;move(dragging.left+event.clientX-dragging.x,dragging.top+event.clientY-dragging.y)});
for(const type of ['pointerup','pointercancel','lostpointercapture'])grip.addEventListener(type,()=>{dragging=null;savePosition()});
grip.addEventListener('keydown',event=>{const delta={ArrowLeft:[-12,0],ArrowRight:[12,0],ArrowUp:[0,-12],ArrowDown:[0,12]}[event.key];if(!delta)return;event.preventDefault();const box=widget.getBoundingClientRect();move(box.left+delta[0],box.top+delta[1]);savePosition()});
window.addEventListener('resize',()=>{if(position)move(position.x,position.y)});
const close=closeDialog;closeDialog=function(...args){const result=close(...args);refresh();return result};
const update=updateWorkoutSessionLabels;updateWorkoutSessionLabels=function(){update();refresh()};
// The existing interval owns its deadline, alarm and completion sound. This view only observes it.
refresh();setInterval(refresh,1000);
})();
