(function(){
 'use strict';
 const training=[
  name=>'Hoje tem '+name+'. Faça cada série com atenção.',
  name=>name+' hoje: foco na execução, no seu ritmo.',
  ()=>'Seu compromisso de hoje é com você. Bom treino!',
  ()=>'Constância se constrói um treino de cada vez.',
  ()=>'Comece com foco e valorize cada etapa do seu treino.',
  ()=>'Hoje é dia de avançar na sua rotina, sem pressa.'
 ];
 const rest=[
  'Hoje é dia de descanso. Retome no próximo treino programado.',
  'Seu dia de descanso também merece espaço na rotina.',
  'Uma pausa no treino, sem perder o rumo.',
  'Hoje, respeite a pausa prevista na sua agenda.',
  'Dia de descanso: desacelere e recarregue as energias.',
  'Descanse hoje. A constância também inclui as pausas.'
 ];
 const sequence=[
  'Um treino de cada vez. Siga sua ficha e valorize a constância.',
  'No seu próximo treino, concentre-se em fazer bem cada série.',
  'Seu ritmo, seu compromisso. Siga a sequência da sua ficha.',
  'Cada treino conta. Continue construindo sua rotina.'
 ];
 function dateKey(date){return date.getFullYear()+'-'+(date.getMonth()+1)+'-'+date.getDate()}
 function message(area,date=new Date(),account=''){
  const entries=APStudentModel.workouts(area).filter(w=>w.count>0);
  if(!entries.length)return {kind:'waiting',text:'Sua ficha aparecerá aqui assim que for disponibilizada.'};
  let seed=0;for(const c of String(account))seed=(Math.imul(seed,31)+c.charCodeAt(0))>>>0;
  const day=Math.floor(Date.UTC(date.getFullYear(),date.getMonth(),date.getDate())/86400000),index=day+seed;
  const today=entries.find(w=>Number.isInteger(w.weekday)&&w.weekday===date.getDay());
  if(today){const name=String(today.label||'seu treino').trim().slice(0,70);return {kind:'training',text:training[index%training.length](name)}}
  // Sequence-based prescriptions do not define rest days. Do not infer them
  // from a Saturday or a missing weekday in the student's preferences.
  if(entries.some(w=>!Number.isInteger(w.weekday)||w.weekday<0||w.weekday>6))return {kind:'sequence',text:sequence[index%sequence.length]};
  return {kind:'rest',text:rest[index%rest.length]};
 }
 let shownDate='';
 function render(){
  const node=document.getElementById('apHomeDailyMessage');if(!node)return;
  const context=window.__AP_STUDENT_CONTEXT;if(!context){node.textContent='';delete node.dataset.dayType;return}
  const now=new Date(),result=message(context.area,now,context.storageId);node.textContent=result.text;node.dataset.dayType=result.kind;shownDate=dateKey(now);
 }
 const home=renderHome;renderHome=function(...args){const result=home(...args);render();return result};
 window.APdailyMessage=Object.freeze({message,render});
 window.addEventListener('ap-student-ready',render);window.addEventListener('ap-account-changed',render);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&document.body.dataset.view==='home')render()});
 setInterval(()=>{if(document.body.dataset.view==='home'&&shownDate!==dateKey(new Date()))render()},60000);
})();
