(function(global){
'use strict';
function packet(workout,role,person){
 if(!workout||!['teacher','student'].includes(role)||!workout.id)throw Error('Escolha um treino válido.');
 const exercises=(workout.exercises||[]).map(e=>({id:String(e.id||''),name:String(e.name||''),pair:e.pair||'',pairOwner:!!e.pairOwner,rows:(e.rows||[]).map(r=>({reps:String(r.reps||'—'),load:r.load==null?'':String(r.load),rest:Number(r.rest)}))}));
 if(!exercises.length||exercises.length>80||exercises.some(e=>!e.id||!e.name||!e.rows.length||e.rows.length>30))throw Error('No relógio, use até 80 exercícios e de 1 a 30 séries por exercício.');
 const steps=[],used=new Set();
 for(let i=0;i<exercises.length;i++){
  if(used.has(i))continue;const e=exercises[i];
  if(e.pair){
   const pair=exercises.map((x,j)=>({x,j})).filter(({x})=>x.pair===e.pair),a=pair.find(({x})=>x.pairOwner),b=pair.find(({x})=>!x.pairOwner);
   if(pair.length!==2||!a||!b||a.x.rows.length!==b.x.rows.length)throw Error('Confira as rodadas do bi-set antes de enviar.');
   for(let n=0;n<a.x.rows.length;n++){steps.push({e:a.j,set:n,rest:0});steps.push({e:b.j,set:n,rest:rest(b.x.rows[n].rest)});}used.add(a.j);used.add(b.j);
  }else{for(let n=0;n<e.rows.length;n++)steps.push({e:i,set:n,rest:rest(e.rows[n].rest)});used.add(i);}
 }
 return {v:1,workoutId:String(workout.id),label:String(workout.label||workout.name||'Treino').slice(0,200),role,person:String(person||'Aluno').slice(0,120),exercises,steps};
}
function rest(value){if(!Number.isInteger(value)||value<0||value>1800)throw Error('Confira os intervalos: use de 0 a 1800 segundos.');return value;}
global.APWatchModel=Object.freeze({packet});
})(globalThis);
