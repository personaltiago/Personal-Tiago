(function(){
 'use strict';
 const root=document.documentElement;let pending=true,node,timer,message='Abrindo Agenda Personal…',failed=false;
 function mount(){if(!pending||node)return;node=document.createElement('section');node.id='apStartup';node.setAttribute('role','status');node.setAttribute('aria-live','polite');node.innerHTML='<img src="__AP_STARTUP_LOGO__" width="112" height="112" alt="Agenda Personal" decoding="async"><p></p><button type="button" hidden>Tentar abrir novamente</button>';node.querySelector('button').onclick=()=>location.reload();document.body.appendChild(node);paint()}
 function paint(){if(node){node.dataset.error=String(failed);node.querySelector('p').textContent=message;node.querySelector('button').hidden=!failed}}
 function fail(text){if(!pending)return;failed=true;message=text||'Não foi possível confirmar seu acesso. Confira a conexão e tente novamente.';paint()}
 function begin(){pending=true;failed=false;message='Abrindo Agenda Personal…';root.setAttribute('data-ap-startup','pending');clearTimeout(timer);timer=setTimeout(()=>fail('A abertura está demorando. Confira a conexão e tente novamente.'),20000);if(['interactive','complete'].includes(document.readyState))mount();paint()}
 function finish(){pending=false;clearTimeout(timer);root.removeAttribute('data-ap-startup');node?.remove();node=null}
 window.APstartup=Object.freeze({begin,finish,fail});
 if(new URL(location.href).searchParams.get('cadastro')==='1'){pending=false;return}
 document.addEventListener('DOMContentLoaded',mount,{once:true});window.addEventListener('ap-teacher-ready',finish);begin();
})();
