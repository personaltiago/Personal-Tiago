(function(global){
 'use strict';
 const text=(value,max=160)=>String(value??'').trim().slice(0,max);
 const numeric=value=>{if(typeof value!=='number'&&typeof value!=='string'||typeof value==='string'&&!/^\d+(?:[.,]\d+)?$/.test(value.trim()))return null;const n=Number(String(value).replace(',','.'));return Number.isFinite(n)&&n>=0&&n<=1000?n:null};
 const key=r=>JSON.stringify([r.id,r.startedAt,r.finishedAt]);
 function normalize(record){
  if(!record||record.incomplete!==false||!text(record.id)||!Number.isFinite(record.startedAt)||!Number.isFinite(record.finishedAt)||record.startedAt<0||record.finishedAt<record.startedAt||record.finishedAt-record.startedAt>31*86400000||!Array.isArray(record.exerciseRecords)||!record.exerciseRecords.length||record.exerciseRecords.length>80)return null;
  const exerciseRecords=[];
  for(const e of record.exerciseRecords){
   if(!e||!text(e.name)||!Array.isArray(e.done)||!e.done.length||e.done.length>30||e.done.some(v=>v!==true))return null;
   const sets=e.done.length;
   exerciseRecords.push({exerciseId:text(e.exerciseId),name:text(e.name),sets,reps:text(e.reps,40),targets:Array.from({length:sets},(_,i)=>text(e.targets?.[i]??e.reps,40)),loads:Array.from({length:sets},(_,i)=>numeric(e.loads?.[i])),done:Array(sets).fill(true)});
  }
  return {id:text(record.id),startedAt:record.startedAt,finishedAt:record.finishedAt,durationMs:record.finishedAt-record.startedAt,workoutName:text(record.workoutName||record.workoutSnapshot?.label),intensity:text(record.intensity,60),comment:text(record.comment,1000),incomplete:false,exerciseRecords};
 }
 function groups(records,from=-Infinity){
  const map=new Map();
  for(const raw of records){const r=normalize(raw);if(!r||r.finishedAt<from)continue;
   r.exerciseRecords.forEach((e,i)=>{const name=text(e.name).normalize('NFKC').toLocaleLowerCase('pt-BR'),id=JSON.stringify([r.id,e.exerciseId||name,e.exerciseId?'':i,name]);if(!map.has(id))map.set(id,{key:id,name:e.name,workoutName:r.workoutName||r.id,entries:[],sets:0});const group=map.get(id);group.name=e.name;group.sets=Math.max(group.sets,e.sets);group.entries.push({when:r.finishedAt,exercise:e,record:r})});
  }
  const result=[...map.values()];for(const g of result)g.entries.sort((a,b)=>a.when-b.when||key(a.record).localeCompare(key(b.record)));return result.sort((a,b)=>a.name.localeCompare(b.name,'pt-BR')||a.workoutName.localeCompare(b.workoutName,'pt-BR'));
 }
 function points(group,metric='load',series=0){return (group?.entries||[]).flatMap(entry=>{const e=entry.exercise;let value=null;if(metric==='reps'){if(e.targets.every(r=>/^\d+$/.test(r)))value=e.targets.reduce((sum,r)=>sum+Number(r),0)}else value=e.loads[series]??null;return value===null?[]:[{when:entry.when,value,record:entry.record}]})}
 global.APStudentProgressModel=Object.freeze({normalize,key,groups,points,numeric});
})(globalThis);
