(function(){
'use strict';
// Presentation order follows scheduled occurrences, never the stored student order.
function scheduled(now){
 const date=iso(now),previous=new Date(now);previous.setDate(previous.getDate()-1);
 const byStudent=new Map();
 for(const item of occurrences(previous,2)){
  const lesson=item.lesson,student=studentById(lesson.studentId);
  if(!student||student.archived===true||student.studentType!=='presencial'||dashboardLessonMode(item)==='online'||['cancelada','realizada'].includes(item.status))continue;
  if(!/^\d{2}:\d{2}$/.test(lesson.time||''))continue;
  const [hour,minute]=lesson.time.split(':').map(Number),duration=Number(lesson.duration||60);
  if(hour>23||minute>59||!Number.isFinite(duration)||duration<=0||duration>1440)continue;
  const start=parseDate(item.date);start.setHours(hour,minute,0,0);
  const end=new Date(start.getTime()+duration*60000),active=start<=now&&now<end;
  if(!active&&(item.date!==date||start<=now))continue;
  const entry={item,start,end,active,rank:active?0:1},old=byStudent.get(student.id);
  if(!old||entry.rank<old.rank||entry.rank===old.rank&&start<old.start)byStudent.set(student.id,entry);
 }
 return byStudent;
}
function label(entry){
 const finish=entry.end.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
 return (entry.active?'Horário da aula agora':'Hoje')+' · '+entry.item.lesson.time+'–'+finish;
}
function updateList(root,entries,workout){
 if(!root)return;
 const rows=[...root.children].filter(row=>workout?row.querySelector('.workout-student-choice[data-student-id]'):row.matches('.student[data-student-id]'));
 const ranked=rows.map((row,index)=>{
  const choice=workout?row.querySelector('.workout-student-choice'):row,id=choice.dataset.studentId,entry=entries.get(id);
  if(row.dataset.apLessonBaseOrder===undefined)row.dataset.apLessonBaseOrder=String(index);
  row.classList.toggle('ap-lesson-current',!!entry?.active);
  let badge=row.querySelector('.ap-student-lesson-time');
  if(entry){
   if(!badge){badge=document.createElement('span');badge.className='ap-student-lesson-time';(workout?choice.querySelector('.copy'):row.querySelector('.student-info')).append(badge);}
   const text=label(entry);if(badge.textContent!==text)badge.textContent=text;
   badge.classList.toggle('is-current',entry.active);
  }else if(badge)badge.remove();
  return {row,entry,base:Number(row.dataset.apLessonBaseOrder)};
 });
 ranked.sort((a,b)=>(a.entry?.rank??2)-(b.entry?.rank??2)||(a.entry&&b.entry?a.entry.start-b.entry.start:0)||a.base-b.base);
 if(ranked.some(({row},i)=>row!==rows[i])){
  const focused=document.activeElement;
  for(const {row} of ranked)root.append(row);
  if(focused&&root.contains(focused)&&document.activeElement!==focused)focused.focus({preventScroll:true});
 }
}
function refresh(){
 const entries=scheduled(new Date());
 if(!studentsArchiveView&&!studentsPendingView&&studentViewType==='presencial')updateList(document.getElementById('studentList'),entries,false);
 updateList(document.getElementById('workoutStudentList'),entries,true);
}
const students=renderStudents;renderStudents=function(...args){const result=students(...args);refresh();return result};
const workouts=renderWorkouts;renderWorkouts=function(...args){const result=workouts(...args);refresh();return result};
setInterval(()=>{if(!document.hidden&&['students','workouts'].includes(currentScreen))refresh()},1000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});
window.addEventListener('focus',refresh);window.addEventListener('pageshow',refresh);
refresh();
})();
