(function(global){
 'use strict';
 const text=(v,max=160)=>String(v??'').trim().slice(0,max);
 function date(v){if(!/^\d{4}-\d{2}-\d{2}$/.test(v||''))return '';const [y,m,d]=v.split('-').map(Number),at=new Date(y,m-1,d);return at.getFullYear()===y&&at.getMonth()===m-1&&at.getDate()===d?v:''}
 function cents(value){
  if(typeof value==='number')return Number.isFinite(value)&&value>=0&&value<=1000000?Math.round(value*100):null;
  let raw=String(value??'').trim().replace(/^R\$\s*/,'').replace(/\s/g,'');if(!raw)return null;
  if(raw.includes(',')){if(!/^(?:\d+|\d{1,3}(?:\.\d{3})+),\d{1,2}$/.test(raw))return null;raw=raw.replace(/\./g,'').replace(',','.')}
  else if(/^\d{1,3}(?:\.\d{3})+$/.test(raw))raw=raw.replace(/\./g,'');
  else if(!/^\d+(?:\.\d{1,2})?$/.test(raw))return null;
  const n=Number(raw);return Number.isFinite(n)&&n>=0&&n<=1000000?Math.round(n*100):null;
 }
 function timestamp(v){const n=Date.parse(v);return typeof v==='string'&&Number.isFinite(n)?new Date(n).toISOString():''}
 function make(state,student,pixKey=''){
  if(!student||!state.students?.some(s=>s.id===student.id))throw Error('Aluno não encontrado.');
  if(student.financeEnabled!==true)return {enabled:false};
  const history=(state.payments||[]).filter(p=>p?.studentId===student.id&&timestamp(p.paidAt)).map(p=>({id:text(p.id),dueDate:date(p.dueDate),paidAt:timestamp(p.paidAt),amountCents:cents(p.amount),...(p.settlesMonthlyFee===false?{settlesMonthlyFee:false}:{})})).sort((a,b)=>b.paidAt.localeCompare(a.paidAt)).slice(0,60);
  return {enabled:true,amountCents:cents(student.monthlyValue),dueDate:date(student.dueDate),startDate:date(student.startDate),manualOverdue:student.paymentOverdue===true&&student.overdueDueDate===student.dueDate,pixKey:text(pixKey,140),history};
 }
 function valid(value){
  if(!value||typeof value.enabled!=='boolean')return false;if(!value.enabled)return true;
  const money=n=>n===null||Number.isSafeInteger(n)&&n>=0&&n<=100000000;
  return money(value.amountCents)&&typeof value.dueDate==='string'&&(value.dueDate===''||date(value.dueDate)===value.dueDate)&&typeof value.startDate==='string'&&(value.startDate===''||date(value.startDate)===value.startDate)&&typeof value.manualOverdue==='boolean'&&typeof value.pixKey==='string'&&value.pixKey.length<=140&&Array.isArray(value.history)&&value.history.length<=60&&value.history.every(p=>p&&typeof p.id==='string'&&p.id.length<=160&&typeof p.dueDate==='string'&&(p.dueDate===''||date(p.dueDate)===p.dueDate)&&!!timestamp(p.paidAt)&&money(p.amountCents)&&(p.settlesMonthlyFee===undefined||typeof p.settlesMonthlyFee==='boolean'));
 }
 function status(billing,now=new Date()){
  const due=date(billing?.dueDate);if(!due)return {kind:'unset',label:'Vencimento a definir',days:null};
  const [y,m,d]=due.split('-').map(Number),today=Date.UTC(now.getFullYear(),now.getMonth(),now.getDate()),days=Math.round((Date.UTC(y,m-1,d)-today)/86400000);
  if(days<0||billing.manualOverdue)return {kind:'overdue',label:'Em atraso',days};
  return days===0?{kind:'today',label:'Vence hoje',days}:{kind:'upcoming',label:'A vencer',days};
 }
 global.APBilling=Object.freeze({make,valid,cents,date,status});
})(globalThis);
