(function(){
'use strict';
const storageKey='ap_workout_return_v1';
let routes={};
try{const saved=JSON.parse(sessionStorage.getItem(storageKey)||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))routes=saved}catch(_){}
function remember(plan,day){
 routes={...routes,[plan.studentId]:{planId:plan.id,dayId:day.id}};
 try{sessionStorage.setItem(storageKey,JSON.stringify(routes))}catch(_){}
}
const openDay=openWorkoutDay;
openWorkoutDay=function(...args){
 const result=openDay(...args),plan=currentWorkoutPlan(),day=currentWorkoutDay();
 if(plan&&day&&plan.studentId===workoutStudentId&&!workoutPlanArchived(plan)&&document.getElementById('workoutDayDialog')?.classList.contains('open'))remember(plan,day);
 return result;
};
window.openActiveWorkoutShortcut=function(){
 const studentId=workoutStudentId;
 if(!studentById(studentId))return;
 const plans=state.workoutPlans.filter(plan=>plan.studentId===studentId&&!workoutPlanArchived(plan));
 const days=plans.flatMap(plan=>(plan.days||[]).map(day=>({plan,day})));
 const previous=routes[studentId];
 const remembered=days.find(item=>item.plan.id===previous?.planId&&item.day.id===previous?.dayId);
 const running=days.filter(item=>workoutRunning(item.plan,item.day));
 running.sort((a,b)=>Number(state.workoutDrafts[workoutDraftKey(b.plan.id,b.day.id)]?.startedAt||0)-Number(state.workoutDrafts[workoutDraftKey(a.plan.id,a.day.id)]?.startedAt||0));
 const target=running.find(item=>item===remembered)||running[0]||remembered;
 // Keep the ordinary collection switch available for internal calls. Only the
 // visible Ativas button takes this shortcut; navigation never starts a workout.
 showWorkoutPlanCollection('active');
 const selected=currentWorkoutPlan();
 const single=!target&&selected?.days?.length===1?{plan:selected,day:selected.days[0]}:null;
 const destination=target||single;
 if(destination){selectWorkoutPlan(destination.plan.id);openWorkoutDay(destination.day.id);return}
 const section=document.getElementById('workoutDaysList')?.closest('.workout-sheet-trainings');
 section?.scrollIntoView({block:'start',behavior:'auto'});
 const heading=document.getElementById('workoutSheetTrainingsTitle');
 if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true})}
};
})();
