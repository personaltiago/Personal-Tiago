(function(){
 'use strict';
 // Reuse the agenda's recurrence and occurrence-status rules, including
 // cancellations and individual changes to a weekly lesson.
 window.APmascotDaySummary=function(now=new Date()){
  const entries=occurrences(now,1).filter(e=>e.status!=='cancelada');
  const minutes=now.getHours()*60+now.getMinutes();
  const at=e=>{const m=/^(\d{2}):(\d{2})$/.exec(e.lesson.time||'');return m?Number(m[1])*60+Number(m[2]):NaN};
  const pending=entries.filter(e=>e.status!=='realizada');
  const current=pending.find(e=>at(e)<=minutes&&at(e)+Number(e.lesson.duration||0)>minutes);
  const next=pending.find(e=>at(e)>minutes);
  return {total:entries.length,done:entries.filter(e=>e.status==='realizada').length,current:current?.lesson.time||'',next:next?.lesson.time||''};
 };
 const original=renderToday;renderToday=function(...args){const result=original(...args);window.parent.APteacherMascot?.refreshCard();return result};
 window.parent.APteacherMascot?.refreshCard();
})();
