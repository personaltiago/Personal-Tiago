// Numbered, exercise-by-exercise PDF format. Keep the legacy MFit parser intact.
function workoutImportNumberedPdf(pages){
  const lines=pages.flatMap(page=>page.map(workoutImportText)).filter(line=>line&&!/^LOTUS PERSONAL\s*[•·/].*MFIT PREMIUM(?:\s+P[áa]gina\s+\d+)?$/i.test(line)&&!/^P[áa]gina\s+\d+$/i.test(line));
  const prescription=/^S[eé]ries\s+e\s+repeti[cç][oõ]es\s*:/i;
  if(!lines.some(line=>prescription.test(line)))return null;
  const heading=/^TREINO\s+([A-Z])\s*(?:\/|[–—-])\s*(SEGUNDA(?:-FEIRA)?|TER[CÇ]A(?:-FEIRA)?|QUARTA(?:-FEIRA)?|QUINTA(?:-FEIRA)?|SEXTA(?:-FEIRA)?|S[ÁA]BADO|DOMINGO)\s*$/i;
  const numbered=/^(\d{1,2})[.)]?\s+(.+)$/;
  const dayMarkers=[];lines.forEach((line,index)=>{const m=line.match(heading);if(m)dayMarkers.push({index,code:m[1].toUpperCase(),weekday:['domingo','segunda','terca','quarta','quinta','sexta','sabado'].indexOf(workoutImportNorm(m[2]).split(' ')[0])})});
  if(!dayMarkers.length)throw new Error('Não reconheci os títulos deste modelo de PDF. Use TREINO A / SEGUNDA-FEIRA e confira a divisão antes de importar.');
  const footerStart=lines.findIndex((line,index)=>index>dayMarkers[0].index&&/^Aplica[cç][aã]o,?\s+registro\s+e\s+auditoria$/i.test(line));
  const endOfWorkouts=footerStart<0?lines.length:footerStart,days=[];
  const expected=lines.filter(line=>prescription.test(line)).length;
  for(let di=0;di<dayMarkers.length;di++){
    const marker=dayMarkers[di],end=Math.min(dayMarkers[di+1]?.index??endOfWorkouts,endOfWorkouts),body=lines.slice(marker.index+1,end);
    if(end<=marker.index)throw new Error('Há um título de treino após o encerramento da ficha. Revise o PDF.');
    const starts=[];body.forEach((line,index)=>{if(numbered.test(line))starts.push(index)});
    if(!starts.length)throw new Error('O treino '+marker.code+' não tem exercícios numerados reconhecíveis.');
    const title=body[0]&&!/^(Aquecimento|Dica|Mobilidade)\s*:/i.test(body[0])&&!numbered.test(body[0])?body[0]:'';
    const dayNotes=body.slice(title?1:0,starts[0]),exercises=[];
    for(let ei=0;ei<starts.length;ei++){
      const start=starts[ei],block=body.slice(start+1,starts[ei+1]??body.length),match=body[start].match(numbered),ordinal=Number(match[1]);
      if(ordinal!==ei+1)throw new Error('A numeração do treino '+marker.code+' está incompleta ou repetida. Confira todos os exercícios antes de importar.');
      const si=block.findIndex(line=>prescription.test(line));
      if(si<0||block.filter(line=>prescription.test(line)).length!==1)throw new Error('Não reconheci as séries do exercício '+match[2]+'. A importação foi interrompida para não perder itens.');
      const name=workoutImportText([match[2],...block.slice(0,si)].join(' '));
      // A prescription may wrap onto a second PDF line before the instruction labels.
      const firstInstruction=block.findIndex((line,index)=>index>si&&/^(Como fazer|Observa[cç][oõ]es?|Observa[cç][aã]o|Alongamento)\s*:/i.test(line));
      const raw=block.slice(si,firstInstruction<0?si+1:firstInstruction).join(' '),rx=raw.match(/^S[eé]ries\s+e\s+repeti[cç][oõ]es\s*:\s*(\d+)\s*[×x]\s*([^|]+?)(?:\s*\|\s*(?:DESCANSO|INTERVALO)\s*:\s*([^|]+))?(?:\s*\|\s*CARGA\s*:\s*(.+))?$/i);
      if(!rx)throw new Error('Séries/repetições não reconhecidas em '+name+'. Revise este campo no PDF.');
      const values={notes:[],observations:[]};let field='';
      for(const line of block.slice(firstInstruction<0?block.length:firstInstruction)){
        let m;if((m=line.match(/^Como fazer\s*:\s*(.*)$/i))){field='notes';if(m[1])values[field].push(m[1])}
        else if((m=line.match(/^Observa(?:[cç][aã]o|[cç][oõ]es)\s*:\s*(.*)$/i))){field='observations';if(m[1])values[field].push(m[1])}
        else if(/^Alongamento\s*:/i.test(line)){field='day';dayNotes.push(line)}
        else if(field==='day')dayNotes.push(line);
        else if(field)values[field].push(line);
      }
      const catalog=workoutImportCatalogMatches(name),rest=workoutImportText(rx[3]||''),warnings=[];
      if(!rest)warnings.push('Intervalo não informado no PDF.');
      exercises.push(workoutImportResolveExercise({importId:id(),name,sets:rx[1],reps:workoutImportText(rx[2]),rest:/^\d+$/.test(rest)?rest+'s':rest,load:workoutImportText(rx[4]||''),sourceNotes:workoutImportText(values.notes.join(' ')),sourceObservations:workoutImportText(values.observations.join(' ')),sourceInstructionName:'',structuralWarnings:warnings,alternative:false,ambiguous:catalog.ambiguous,suggestions:catalog.suggestions.map(item=>({id:item.id,name:item.name,muscle:item.muscle||'',category:item.category||''}))},catalog.match));
    }
    if(days.some(day=>day.code===marker.code))throw new Error('O treino '+marker.code+' está repetido. Revise a divisão da ficha.');
    days.push({importId:id(),code:marker.code,name:'Treino '+marker.code+(title?' — '+title:''),title,weekday:marker.weekday,notes:dayNotes.join('\n'),exercises});
  }
  const recognized=days.reduce((n,day)=>n+day.exercises.length,0);
  if(recognized!==expected)throw new Error('O PDF contém '+expected+' blocos de exercícios, mas apenas '+recognized+' foram reconhecidos. Revise a ficha antes de importar.');
  const cover=lines.slice(0,dayMarkers[0].index),profile=workoutImportParseProfile(pages),coverTitle=cover.findIndex(line=>/^FICHA DE TREINAMENTO\b/i.test(line));
  // The student's name precedes the cover title; the brand is never a student.
  profile.name=coverTitle>0&&!/[:\d•/]/.test(cover[coverTitle-1])?cover[coverTitle-1]:'';
  const demographic=cover.join(' ').match(/\b(Feminino|Masculino)\s*[·•]\s*(\d{1,3})\s*anos\s*[·•]\s*([\d.,]+)\s*kg\s*[·•]\s*([\d.,]+)\s*cm/i);
  if(demographic){profile.sex=workoutImportNorm(demographic[1]);profile.age=demographic[2];profile.weight=demographic[3].replace(',','.');profile.height=demographic[4].replace(',','.')}
  return{profile,days,organization:'week',notes:[...cover.filter(line=>line!==profile.name),...lines.slice(endOfWorkouts)].join('\n'),format:'numbered-exercises'};
}
