# Cenários do mascote — conteúdo 1.12.103

Seis fundos criados com a ferramenta integrada image_gen, modo de geração stylized-concept. Os animais aprovados permanecem intactos. O adulto do lobo é espelhado apenas no elemento SVG image; filhote e adolescente já olham para o balão.

## Prompt comum final

Landscape background for an existing mobile pet companion card, 3:2. Premium soft semi-realistic 3D environment rendering, believable natural materials, tasteful detail and depth, gentle light, subtle painterly warmth, elegant rather than toy-like, no hard polygon shapes. Camera looking gently downward from low height into garden, horizon around 55 percent from top. Leave lower left third as clear level foreground grass for a separately composited standing pet. Upper right two thirds should be calm low-detail background; a speech bubble will be placed separately. Balance interesting environment details around edges and lower right. No animals, people, text, UI, border, logo, watermark or speech bubble. Rich but restrained greens and warm natural colors, soft ambient shadows. Consistent lens, quality, scale and realistic 3D style across the six assets.

## Complementos por imagem

- yard.webp: welcoming backyard, crafted timber doghouse in lower right, cedar boards and slate roof, pale wooden fence, short grass and sparse stepping stones.
- bamboo.webp: peaceful layered bamboo grove, textured stems at sides, distant mist, moss and short grass clearing.
- forest.webp: forest clearing, mature trees at sides, layered forest, soft sun rays, fern details and mossy grass foreground.
- lake.webp: calm blue-green lake, reeds at right edge, rounded shore stones, grassy foreground bank and distant trees.
- cabin.webp: small timber mountain cabin at lower right, slate pitched roof, pines, distant mountains and grassy foreground.
- night.webp: moonlit garden, moon at upper left, distant navy trees, warm lanterns along path at right, flowers and soft grass, readable navy-teal twilight.

## Integração

Arquivos finais locais em web/mascot-homes/*.webp, 960 × 640, WebP qualidade 80. O manifesto registra SHA-256 e dimensões. tools/mascot_home_assets.cjs verifica os arquivos e embute prévias leves no módulo e as imagens completas no cadastro local durante a preparação das quatro telas. Os fundos completos são hidratados junto da biblioteca de retratos; a página inicial permanece abaixo do limite nativo de 2 MiB. Nada depende de download externo; os cenários acompanham o JSON de atualização para Android e navegador/iPhone. O código de moedas, propriedade, preços, nomes e seleção das casas não foi alterado.
