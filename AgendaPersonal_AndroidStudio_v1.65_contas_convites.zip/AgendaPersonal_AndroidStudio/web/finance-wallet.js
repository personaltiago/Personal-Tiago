(function(){
 'use strict';
 const el=id=>document.getElementById(id),money=APFinanceWallet.money;
 // Use the same BRL parser in totals, student cards and collection messages.
 moneyText=function(value){const cents=APBilling.cents(value);return cents===null?'':money(cents)};
 function render(){
  const data=APFinanceWallet.build(state),count=data.rows.length;
  el('financeWalletForecast').textContent=money(data.forecastCents);
  el('financeWalletBasis').textContent=data.pricedCount+' '+(data.pricedCount===1?'mensalidade somada':'mensalidades somadas');
  el('financeWalletReceived').textContent=money(data.receivedCents);
  el('financeWalletReceipts').textContent=data.receivedCount+' '+(data.receivedCount===1?'pagamento confirmado':'pagamentos confirmados');
  el('financeWalletCount').textContent=count+' '+(count===1?'aluno':'alunos');
  el('financeWalletMissing').hidden=!data.missingCount;
  el('financeWalletMissing').textContent=data.missingCount+' '+(data.missingCount===1?'aluno sem valor válido. Defina a mensalidade abaixo para incluir na soma.':'alunos sem valor válido. Defina as mensalidades abaixo para incluir na soma.');
  el('financeWalletUnknownReceipts').hidden=!data.unknownReceipts;
  el('financeWalletUnknownReceipts').textContent=data.unknownReceipts+' '+(data.unknownReceipts===1?'pagamento sem valor registrado ficou fora da soma recebida.':'pagamentos sem valor registrado ficaram fora da soma recebida.');
  el('financeWalletRows').innerHTML=data.rows.length?data.rows.map(row=>'<div class="finance-wallet-row"><div class="finance-wallet-student"><strong>'+hesc(row.name)+'</strong><small>'+hesc(studentTypeLabel(row.type)||'Tipo não definido')+(row.dueDate?' · Próx. vencimento '+fmtDate(row.dueDate):' · Sem vencimento')+'</small></div><div class="finance-wallet-value"><strong>'+hesc(row.amountCents===null?'Não informado':money(row.amountCents))+'</strong><button type="button" data-wallet-student="'+hesc(row.id)+'" aria-label="Editar mensalidade de '+hesc(row.name)+'">'+(row.amountCents===null?'Definir valor':'Editar')+'</button></div></div>').join(''):'<p class="finance-wallet-empty">Nenhuma mensalidade ativa neste mês. Configure o valor mensal no cadastro do aluno.</p>';
 }
 el('financeWalletRows').addEventListener('click',event=>{const button=event.target.closest('[data-wallet-student]');if(button&&studentById(button.dataset.walletStudent))openEditStudent(button.dataset.walletStudent)});
 const previous=renderFinance;
 renderFinance=function(){const result=previous.apply(this,arguments);render();return result};
 window.renderFinanceWallet=render;
 render();
})();
