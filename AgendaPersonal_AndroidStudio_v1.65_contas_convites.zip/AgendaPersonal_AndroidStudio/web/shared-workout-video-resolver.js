// Resolve shared demonstrations without changing a student's prescription.
// Old/PDF/manual exercises may predate the catalog link. Match full normalized
// names/declared aliases only; ambiguous variants must keep their own selection.
function workoutExerciseVideoUrl(ex){
  const own=normalizedWorkoutVideoUrl(ex?.video);if(own)return own;
  if(!ex)return '';
  const items=workoutCatalogItems(),name=workoutSearchKey(ex.name);
  const linked=items.find(item=>item.id===ex.catalogId);
  if(linked&&(!name||workoutCatalogSameName(ex,linked))){
    const video=normalizedWorkoutVideoUrl(linked.video);if(video)return video;
    // An intentionally cleared app entry must not resurrect an old copy.
    if(linked.source==='app'&&Object.prototype.hasOwnProperty.call(state.exerciseCatalogOverrides[linked.id]||{},'video'))return '';
  }
  if(!name)return '';
  const matches=items.filter(item=>workoutCatalogSameName(ex,item));
  const app=matches.filter(item=>item.source==='app');
  if(app.length>1)return '';
  if(app.length===1){
    const video=normalizedWorkoutVideoUrl(app[0].video);if(video)return video;
    if(Object.prototype.hasOwnProperty.call(state.exerciseCatalogOverrides[app[0].id]||{},'video'))return '';
  }
  const custom=matches.filter(item=>item.source==='mine');
  return custom.length===1?normalizedWorkoutVideoUrl(custom[0].video):'';
}
