(function(){
 'use strict';
 const key='agendaPersonalTL_icon_finish_v1',root=document.documentElement;
 const read=()=>{try{const v=JSON.parse(localStorage.getItem(key)||'null');return v?.version===1&&v.id==='matte'?'matte':'theme'}catch(_){return 'theme'}};
 let selected=read();
 function apply(){root.dataset.agendaIconFinish=selected;document.querySelectorAll('[data-icon-finish]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.iconFinish===selected)))}
 function announce(){window.dispatchEvent(new CustomEvent('agenda-colors-change',{detail:{config:window.AgendaColors?.get(),design:window.AgendaColors?.getDesign(),iconFinish:selected}}))}
 window.AgendaIconFinish=Object.freeze({key,get:()=>selected,set(id){
  if(!['theme','matte'].includes(id))return {ok:false,error:'Escolha um dos acabamentos disponíveis.'};
  try{localStorage.setItem(key,JSON.stringify({version:1,id}))}catch(_){return {ok:false,error:'Não foi possível salvar os ícones. Libere espaço no aparelho e tente novamente.'}}
  selected=id;apply();announce();return {ok:true};
 }});
 apply();
 window.addEventListener('storage',event=>{if(event.key===key||event.key===null){selected=read();apply();announce()}});
 document.addEventListener('DOMContentLoaded',()=>{
  apply();document.querySelectorAll('[data-icon-finish]').forEach(button=>button.addEventListener('click',()=>{
   const result=AgendaIconFinish.set(button.dataset.iconFinish),status=document.getElementById('iconFinishStatus');
   if(status){status.textContent=result.ok?(selected==='matte'?'Ícones foscos salvos. O roxo escuro é mantido em Claro e Escuro.':'Ícones do tema restaurados.'):result.error;status.dataset.error=String(!result.ok)}
  }));
 },{once:true});
})();
