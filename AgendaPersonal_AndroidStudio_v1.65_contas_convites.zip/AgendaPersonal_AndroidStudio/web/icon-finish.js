(function(){
 'use strict';
 const key='agendaPersonalTL_icon_finish_v1',root=document.documentElement;
 const read=()=>{try{const v=JSON.parse(localStorage.getItem(key)||'null');return v?.version===1?{id:v.id==='matte'?'matte':'theme',...(Object.hasOwn(v,'cards')?{cards:v.cards==='colored'?'colored':'theme'}:{})}:{id:'theme'}}catch(_){return {id:'theme'}}};
 let preference=read(),selected=preference.id;
 const cards=()=>preference.cards==='colored'?'colored':'theme';
 function apply(){
  root.dataset.agendaIconFinish=selected;root.dataset.agendaCardStyle=cards();
  document.querySelectorAll('[data-icon-finish]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.iconFinish===selected)));
  document.querySelectorAll('[data-card-style]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.cardStyle===cards())));
  const hint=document.getElementById('apMoreSelectHint');if(hint)hint.textContent=cards()==='colored'?'Toque uma vez para selecionar e outra vez para abrir.':'Toque uma vez para destacar e outra vez para abrir.';
 }
 function announce(){window.dispatchEvent(new CustomEvent('agenda-colors-change',{detail:{config:window.AgendaColors?.get(),design:window.AgendaColors?.getDesign(),iconFinish:selected,cardStyle:cards()}}))}
 function persist(next){
  try{localStorage.setItem(key,JSON.stringify({version:1,...next}))}catch(_){return {ok:false,error:'Não foi possível salvar a aparência. Libere espaço no aparelho e tente novamente.'}}
  preference=next;selected=next.id;apply();announce();return {ok:true};
 }
 window.AgendaIconFinish=Object.freeze({key,get:()=>selected,getCards:cards,setCards(id){
  if(!['theme','colored'].includes(id))return {ok:false,error:'Escolha uma das opções de cartões.'};
  return persist({...preference,cards:id});
 },set(id){
  if(!['theme','matte'].includes(id))return {ok:false,error:'Escolha um dos acabamentos disponíveis.'};
  return persist({...preference,id});
 }});
 apply();
 window.addEventListener('storage',event=>{if(event.key===key||event.key===null){preference=read();selected=preference.id;apply();announce()}});
 document.addEventListener('DOMContentLoaded',()=>{
  apply();document.querySelectorAll('[data-icon-finish]').forEach(button=>button.addEventListener('click',()=>{
   const result=AgendaIconFinish.set(button.dataset.iconFinish),status=document.getElementById('iconFinishStatus');
   if(status){status.textContent=result.ok?(selected==='matte'?'Ícones foscos salvos. O acabamento acompanha a cor escolhida.':'Ícones do tema restaurados.'):result.error;status.dataset.error=String(!result.ok)}
  }));
  document.querySelectorAll('[data-card-style]').forEach(button=>button.addEventListener('click',()=>{
   const result=AgendaIconFinish.setCards(button.dataset.cardStyle),status=document.getElementById('cardStyleStatus');
   if(status){status.textContent=result.ok?(cards()==='colored'?'Os cartões do aplicativo usam a cor escolhida.':'Fundo dos cartões restaurado para o tema.'):result.error;status.dataset.error=String(!result.ok)}
  }));
 },{once:true});
})();
