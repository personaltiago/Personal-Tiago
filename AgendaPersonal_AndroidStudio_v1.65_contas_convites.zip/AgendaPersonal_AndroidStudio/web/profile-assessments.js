let profileAssessmentRead=0;
function profileAssessmentValue(value,unit=''){
  if(value===null||value===undefined||String(value).trim()===''||!Number.isFinite(Number(value)))return '—';
  return profileNumber(Number(value))+unit;
}
function profileAssessmentComposition(record,client){
  const data=record.data||{},keys=['triceps','subscapular','suprailiac','pectoral','midaxillary','abdominal','thigh'];
  if(keys.some(key=>data.folds?.[key]==null||String(data.folds[key]).trim()===''))return null;
  const weight=data.weight==null||String(data.weight).trim()===''?undefined:data.weight;
  return profileBodyComposition({...data,weight,equation:data.equation||client.equation});
}
function profileAssessmentActions(){
  return '<div class="profile-assessment-actions"><button class="btn primary" type="button" data-profile-assessment-new>Nova avaliação</button><button class="btn ghost" type="button" data-profile-assessment-history>Ver histórico</button></div>';
}
async function loadProfileEvaluationResults(sid){
  const token=++profileAssessmentRead;
  const box=document.getElementById('profileEvaluationResults'),count=document.getElementById('profileEvaluationCount'),s=studentById(sid);
  if(!s||!box||!count)return;
  box.className='profile-loading';box.textContent='Carregando o histórico de avaliações…';count.textContent='';
  let client;
  try{client=await evaluationClientForStudent(s)}catch(problem){
    if(token!==profileAssessmentRead||currentProfileStudentId!==sid)return;
    box.className='profile-empty-eval';count.textContent='';
    box.innerHTML='<strong>Não foi possível consultar as avaliações.</strong><p>Abra o histórico para conferir os registros salvos.</p><button class="btn ghost" type="button" data-profile-assessment-history>Ver histórico</button><button class="btn ghost" type="button" data-profile-assessment-retry>Tentar novamente</button>';
    bindProfileAssessmentActions(box,sid);return;
  }
  if(token!==profileAssessmentRead||currentProfileStudentId!==sid)return;
  const assessments=(Array.isArray(client?.assessments)?client.assessments:[]).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(b.createdAt||'').localeCompare(String(a.createdAt||'')));
  count.textContent=assessments.length+' '+(assessments.length===1?'avaliação salva':'avaliações salvas');
  box.className='profile-assessment-content';
  if(!assessments.length){
    box.innerHTML=profileAssessmentActions()+'<p class="profile-empty-eval">Nenhuma avaliação vinculada a este aluno.</p>';
    bindProfileAssessmentActions(box,sid);return;
  }
  const latest=assessments[0],data=latest.data||{},comp=profileAssessmentComposition(latest,client);
  const metrics=[['Última avaliação',latest.date?fmtDate(latest.date):'—'],['Peso',profileAssessmentValue(data.weight,' kg')],['Gordura estimada',profileAssessmentValue(comp?.bodyFat,'%')],['Massa magra estimada',profileAssessmentValue(comp?.leanMass,' kg')],['Cintura',profileAssessmentValue(data.circumference?.waist,' cm')],['Soma das 7 dobras',profileAssessmentValue(comp?.sum,' mm')]];
  box.innerHTML=profileAssessmentActions()+'<div class="profile-metrics">'+metrics.map(([label,value])=>'<div class="profile-metric"><span>'+hesc(label)+'</span><strong>'+hesc(value)+'</strong></div>').join('')+'</div><div class="profile-assessment-list" aria-label="Avaliações salvas">'+assessments.map((record,index)=>{
    const result=profileAssessmentComposition(record,client),values=['Peso: '+profileAssessmentValue(record.data?.weight,' kg')];
    if(result)values.push('Gordura estimada: '+profileAssessmentValue(result.bodyFat,'%'));
    return '<article class="profile-assessment-record"><div><strong>'+hesc(record.date?fmtDate(record.date):'Data não informada')+'</strong>'+(index===0?'<small>Mais recente</small>':'')+'<p>'+hesc(values.join(' · '))+'</p></div><button class="btn ghost" type="button" data-profile-assessment-id="'+hesc(record.id)+'">Ver avaliação</button></article>';
  }).join('')+'</div>';
  bindProfileAssessmentActions(box,sid);
}
function bindProfileAssessmentActions(box,sid){
  box.querySelector('[data-profile-assessment-new]')?.addEventListener('click',()=>openEvaluations(sid));
  box.querySelector('[data-profile-assessment-history]')?.addEventListener('click',()=>openEvaluations(sid,'history'));
  box.querySelector('[data-profile-assessment-retry]')?.addEventListener('click',()=>loadProfileEvaluationResults(sid));
  for(const button of box.querySelectorAll('[data-profile-assessment-id]'))button.addEventListener('click',()=>openEvaluations(sid,'history',button.dataset.profileAssessmentId));
}
