(function(root){
 'use strict';
 const MAX=86400;
 function isTimed(raw){
  const s=String(raw||'').trim().toLowerCase();
  return /^(?:\d+(?:[.,]\d+)?\s*(?:[-–]\s*\d+(?:[.,]\d+)?\s*)?)(?:s|seg(?:undo)?s?\.?|min(?:uto)?s?\.?)$/.test(s)||/^\d{1,2}:\d{2}(?::\d{2})?$/.test(s)||/^\d+\s*min\s*\d+\s*s$/.test(s);
 }
 const valid=(n,timed)=>Number.isInteger(Number(n))&&Number(n)>=1&&Number(n)<=(timed?MAX:999);
 const secondsText=n=>String(n)+' s';
 const rowText=r=>r?.unit==='seconds'?(valid(r.seconds??r.reps,true)?secondsText(Number(r.seconds??r.reps)):'—'):(valid(r?.reps,false)?String(Number(r.reps)):'—');
 function clockFor(plan,day){
  const draft=plan&&day?state.workoutDrafts[workoutDraftKey(plan.id,day.id)]:null,c=draft?.seriesClock;
  return c&&c.studentId===plan.studentId&&c.planId===plan.id&&c.dayId===day.id&&c.sessionId===draft.sessionId&&draft.active!==false&&Number.isFinite(c.startedAt)&&c.startedAt>0?c:null;
 }
 const elapsed=c=>Math.min(MAX,Math.max(0,Math.floor((Date.now()-c.startedAt)/1000)));
 const matches=(c,ex,round,group='',part='')=>c?.exerciseId===ex&&c.round===Number(round)&&c.groupId===group&&c.part===part;
 function active(){
  for(const plan of state.workoutPlans||[])for(const day of plan.days||[]){const clock=clockFor(plan,day);if(clock&&!workoutPlanArchived(plan)&&workoutRunning(plan,day))return {plan,day,clock}}
  return null;
 }
 function button(ex,row,options,attrs){
  const plan=options.plan||currentWorkoutPlan(),day=options.day||currentWorkoutDay(),clock=plan&&day?clockFor(plan,day):null;
  const running=matches(clock,ex.id,row.round,options.groupId||'',options.part||''),n=running?elapsed(clock):row.done?Number(row.reps)||0:0;
  const enabled=options.interactive===true&&!row.done&&(!options.groupId||row.current===true),action=running?'Parar':row.done?'Feito':'Iniciar';
  return `<button type="button" class="ws-time-button${running?' is-running':''}" ${attrs} data-time-clock="true" data-clock-plan="${hesc(plan?.id||'')}" data-clock-day="${hesc(day?.id||'')}" data-clock-name="${hesc(ex.name)}" data-clock-target="${hesc(row.targetReps)}" onclick="APTimedSeries.toggle(this)" aria-label="${hesc(action+' cronômetro de '+ex.name+', série '+row.round)}" aria-pressed="${running}"${enabled?'':' disabled'}><span data-clock-value>${secondsText(n)}</span></button><small class="ws-time-action" data-clock-action>${action}</small>`;
 }
 function tick(){
  for(const b of document.querySelectorAll('[data-time-clock]')){
   const plan=state.workoutPlans.find(p=>p.id===b.dataset.clockPlan),day=plan?.days.find(d=>d.id===b.dataset.clockDay),clock=clockFor(plan,day);
   const running=matches(clock,b.dataset.seriesExercise,b.dataset.seriesRound,b.dataset.seriesGroup||'',b.dataset.seriesPart||'');
   b.classList.toggle('is-running',running);b.setAttribute('aria-pressed',String(running));
   if(running){b.querySelector('[data-clock-value]').textContent=secondsText(elapsed(clock));b.nextElementSibling.textContent='Parar';b.setAttribute('aria-label','Parar cronômetro de '+b.dataset.clockName+', série '+b.dataset.seriesRound)}
  }
 }
 function toggle(b){
  const plan=currentWorkoutPlan(),day=currentWorkoutDay(),round=Number(b.dataset.seriesRound),ex=day?.exercises.find(e=>e.id===b.dataset.seriesExercise);
  if(!plan||!day||plan.id!==b.dataset.clockPlan||day.id!==b.dataset.clockDay||!ex||!Number.isInteger(round)||!workoutRunning(plan,day)||workoutPlanArchived(plan)||!isTimed(b.dataset.clockTarget))return;
  const row=b.closest('.ws-set-row'),check=row?.querySelector('input[type=checkbox]'),field=row?.querySelector('[data-series-field="reps"]');
  if(!check||!field||check.disabled||check.checked)return;
  const key=workoutDraftKey(plan.id,day.id),draft=state.workoutDrafts[key],clock=clockFor(plan,day),group=b.dataset.seriesGroup||'',part=b.dataset.seriesPart||'';
  if(matches(clock,ex.id,round,group,part)){
   const seconds=elapsed(clock);if(seconds<1)return toast('Aguarde pelo menos 1 segundo para registrar a série.');
   field.value=String(seconds);check.checked=true;completeWorkoutSeriesCheck(check);tick();return;
  }
  if(active())return toast('Pare o cronômetro da série em andamento antes de iniciar outra.');
  if(state.workoutRest?.endAt>Date.now())return toast('Aguarde o descanso terminar antes de iniciar esta série.');
  const next={token:id(),studentId:plan.studentId,planId:plan.id,dayId:day.id,exerciseId:ex.id,round,groupId:group,part,sessionId:draft.sessionId,startedAt:Date.now()};
  if(commitWorkoutChange({workoutDrafts:{...state.workoutDrafts,[key]:{...draft,seriesClock:next}}},'',false))tick();
 }
 root.APTimedSeries=Object.freeze({isTimed,valid,secondsText,rowText,clockFor,button,toggle,tick});
 setInterval(tick,200);document.addEventListener('visibilitychange',tick);
})(window);
