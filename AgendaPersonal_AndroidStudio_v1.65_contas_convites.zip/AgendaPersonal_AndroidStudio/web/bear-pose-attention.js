(function(g){'use strict';
// Calibrated against the two adult black bear portraits in the reported videos.
// Affection is delegated verbatim to the existing, approved renderer.
const prior=g.APMascotBearPoses,ns='http://www.w3.org/2000/svg',clamp=(v,a=-1,b=1)=>Math.max(a,Math.min(b,v)),mix=(a,b,t)=>a+(b-a)*t,smooth=(a,b,v)=>{v=clamp((v-a)/(b-a),0,1);return v*v*(3-2*v)};
const sessions=new WeakMap(),facePictures=new Map(),eye=(center,iris,radius,white,travel,outline)=>({center,iris,radius,white,travel,outline});let faceAssets={};
function configureFaces(items){faceAssets=Object.fromEntries(Object.entries(items||{}).filter(([pose,v])=>Object.hasOwn(eyes,pose)&&/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(v?.uri||'')&&Array.isArray(v.offset)&&v.offset.length===2&&v.offset.every(n=>Number.isFinite(n)&&Math.abs(n)<=12)))}
async function facePhoto(entry){if(!entry)return null;if(!facePictures.has(entry.uri))facePictures.set(entry.uri,(async()=>{const i=new g.Image();i.src=entry.uri;await i.decode();return i})());return facePictures.get(entry.uri)}
const eyes={
 default:[
  eye([89.4,79.5],[91.3,79.5],[8.5,9.0],[82.3,77.2],[2.8,2.2],[[79.3,78.0],[80.2,73.5],[83.8,69.9],[88.5,68.7],[93.2,69.7],[97.3,73.7],[99.0,79.5],[97.8,84.6],[93.6,88.1],[88.7,89.0],[83.3,87.0],[80.4,83.0]]),
  eye([137.8,90.6],[135.9,88.6],[6.9,8.0],[141.7,96.0],[2.3,1.9],[[129.1,88.6],[130.0,83.8],[133.3,80.7],[136.8,80.4],[140.6,82.0],[143.9,86.1],[146.0,91.0],[145.3,96.3],[142.5,99.8],[138.4,101.0],[134.3,98.8],[130.7,94.6]])
 ],
 rest:[
  eye([187.8,123.2],[190.0,121.0],[8.4,10.1],[180.8,124.4],[2.8,2.2],[[177.7,120.3],[179.4,115.4],[183.8,112.4],[188.2,112.2],[193.3,114.2],[197.2,118.7],[198.9,124.2],[197.8,129.1],[193.8,132.9],[188.8,134.3],[183.6,132.2],[179.3,127.3]]),
  eye([240.1,141.6],[242.0,139.0],[8.2,10.3],[232.1,143.1],[2.6,2.1],[[229.7,138.0],[230.7,132.2],[234.7,127.9],[239.4,127.6],[244.0,130.1],[247.9,135.0],[249.1,141.0],[247.8,147.0],[243.5,151.9],[238.8,153.0],[234.0,150.1],[231.1,144.6]])
 ]
};
const supports=s=>s?.species==='panda'&&g.APMascotModel.phase(s.xp).id==='adult'&&g.APMascotModel.color(s).id==='black'&&Object.hasOwn(eyes,g.APMascotModel.pose(s).id);
const durations={look:3000,curious:2500,ear:1350,nose:1550,paw:2650,tail:2650,angry:2650};
function values(p,kind,t,aim={x:0,y:0,ear:0},reduced=false){
 const end=(durations[kind]||2500)/1000,enter=smooth(0,.22,t),leave=1-smooth(end-.55,end,t),e=enter*leave,v={angle:0,nod:0,ear:0,sniff:0,gx:0,gy:0,focus:0,grump:0,ear0:0,ear1:0};
 if(kind==='look'||kind==='curious'){
  v.focus=smooth(0,.16,t)*leave;v.gx=aim.x*v.focus;v.gy=aim.y*v.focus;
  const follow=smooth(.13,.58,t)*leave,tilt=p.pose==='default'?.044:.027;
  v.angle=tilt*(kind==='curious'?(aim.x>=0?1:-1):aim.x*.65)*follow;v.nod=-(p.pose==='default'?1.5:.85)*follow;
 }
 if(kind==='ear'){
  const pulse=Math.sin(Math.max(0,t-.035)*16)*Math.exp(-t*3.1)*enter*leave;
  v['ear'+(aim.ear||0)]=5.5*pulse;v.focus=e;v.gx=aim.x*.45*e;v.gy=-.28*e;
 }
 if(kind==='nose'){v.sniff=2.1*Math.sin(t*12)*Math.exp(-t*2.1)*enter*leave;v.nod=-.65*e;v.focus=e;v.gy=.24*e;}
 if(['paw','tail','angry'].includes(kind)){
  v.grump=e;
 }
 if(reduced){v.angle=v.nod=v.ear0=v.ear1=v.sniff=0;}
 return v;
}
function project(x,y,p,v){
 const q=prior.project(x,y,p,v);let w=1;
 // The cheek rests against this forepaw. Keep that contact and its support fixed.
 if(p.pose==='rest')w=smooth(.88,1.30,Math.hypot((x-275)/35,(y-205)/57));
 let xx=x+(q[0]-x)*w,yy=y+(q[1]-y)*w;
 for(let i=0;i<p.ears.length;i++){const e=p.ears[i],k=v['ear'+i]||0,fall=Math.exp(-(((x-e.x*320)/18)**2)-((y-e.y*320)/18)**2);yy+=k*fall*prior.weight(x,y,p)*w;}
 return[xx,yy];
}
function grid(n){const points=[],indices=[];for(let y=0;y<=n;y++)for(let x=0;x<=n;x++)points.push(x*320/n,y*320/n);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const a=y*(n+1)+x;indices.push(a,a+n+1,a+1,a+1,a+n+1,a+n+2)}return{points:new Float32Array(points),indices:new Uint16Array(indices)}}
const mesh=grid(32),small=grid(16),num=v=>Number(v).toFixed(4),vec=v=>'vec2('+v.map(num).join(',')+')';
function fragment(p){
 const aperture=p.eyes.map((e,i)=>'float mask'+i+'(vec2 p){float d=100.;'+e.outline.map((a,j)=>'d=min(d,edge(p,'+vec(a)+','+vec(e.outline[(j+1)%e.outline.length])+'));').join('')+'return smoothstep(.18,.75,d);}').join('');
 const calls=p.eyes.map((e,i)=>'color=globe(color,p,mask'+i+'(p),'+[e.center,e.iris,e.radius,e.white,e.travel].map(vec).join(',')+');color=lid(color,p,'+vec(e.center)+','+vec([e.radius[0]+2,e.radius[1]+1])+','+(i?'-.36':'.36')+');').join('');
 return `precision highp float;uniform sampler2D original;uniform sampler2D faceReaction;uniform float hasFace;uniform vec2 faceOffset;uniform vec2 gaze;uniform float focus;uniform float grump;varying vec2 uv;
 float edge(vec2 p,vec2 a,vec2 b){vec2 q=b-a;return(q.x*(p.y-a.y)-q.y*(p.x-a.x))/length(q);}
 ${aperture}
 vec4 globe(vec4 base,vec2 p,float mask,vec2 center,vec2 iris,vec2 radius,vec2 whiteAt,vec2 travel){
  if(focus<.0001||mask<.0001)return base;
  vec2 goal=mix(iris,center+gaze*travel,focus),d=(p-goal)/(radius*1.12);
  float inside=1.-smoothstep(.93,1.025,length(d));
  vec3 pupil=texture2D(original,(iris+d*radius)/320.).rgb,white=texture2D(original,whiteAt/320.).rgb;
  vec2 sphere=(p-center)/(radius+vec2(3.));white*=.78+.12*sqrt(max(0.,1.-dot(sphere,sphere)*.60));
  base.rgb=mix(base.rgb,mix(white,pupil,inside),mask*smoothstep(0.,.08,focus));return base;
 }
 vec4 lid(vec4 base,vec2 p,vec2 center,vec2 radius,float slope){
  if(grump<.0001||hasFace>.5)return base;float x=(p.x-center.x)/radius.x;if(abs(x)>.99)return base;
  float h=sqrt(max(0.,1.-x*x))*radius.y,top=center.y-h,bottom=center.y+h;
  float closed=top+(bottom-top)*(.27+slope*x*.32)*grump;
  float cover=(1.-smoothstep(closed-.65,closed+.65,p.y))*smoothstep(top-7.,top-2.,p.y)*(1.-smoothstep(.82,1.,abs(x)))*smoothstep(0.,.14,grump);
  vec2 from=vec2(p.x,top+(p.y-closed));vec4 fur=texture2D(original,from/320.);base.rgb=mix(base.rgb,fur.rgb,cover);return base;
 }
 void main(){vec2 p=uv*320.;vec4 color=texture2D(original,uv);${calls}
 if(hasFace>.5&&grump>.0001){float mask=1.-smoothstep(.72,1.02,length((p-${vec(p.head.slice(0,2))})/${vec(p.head.slice(2,4))}));${p.pose==='rest'?'mask*=smoothstep(.88,1.30,length((p-vec2(275.,205.))/vec2(35.,57.)));':''}vec4 face=texture2D(faceReaction,(p+faceOffset)/320.);mask*=smoothstep(.80,.99,face.a);color.rgb=mix(color.rgb,face.rgb,mask*grump);}
 gl_FragColor=color;}`;
}
function gpu(c,photo,p,reaction){const gl=c.getContext('webgl',{alpha:true,premultipliedAlpha:true,antialias:false,preserveDrawingBuffer:true,depth:false,stencil:false});if(!gl)return null;let program;const buffers=[],shaders=[],textures=[];
 const dispose=()=>{textures.forEach(t=>gl.deleteTexture(t));buffers.forEach(b=>gl.deleteBuffer(b));shaders.forEach(s=>gl.deleteShader(s));if(program)gl.deleteProgram(program);gl.getExtension('WEBGL_lose_context')?.loseContext()};
 try{
  const shader=(kind,code)=>{const s=gl.createShader(kind);shaders.push(s);gl.shaderSource(s,code);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error('bear attention shader');return s};
  program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,'attribute vec2 p;attribute vec2 q;varying vec2 uv;void main(){uv=p/320.;gl_Position=vec4(q.x/160.-1.,1.-q.y/160.,0.,1.);}'));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fragment(p)));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('bear attention program');gl.useProgram(program);
  const attribute=(name,data,usage)=>{const b=gl.createBuffer();buffers.push(b);gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,data,usage);const a=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);return b};
  attribute('p',mesh.points,gl.STATIC_DRAW);const moving=attribute('q',mesh.points,gl.DYNAMIC_DRAW),index=gl.createBuffer();buffers.push(index);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,index);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,mesh.indices,gl.STATIC_DRAW);
  for(const [i,picture]of [photo,reaction||photo].entries()){const texture=gl.createTexture();textures.push(texture);gl.activeTexture(gl.TEXTURE0+i);gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,picture);gl.uniform1i(gl.getUniformLocation(program,i?'faceReaction':'original'),i)}gl.uniform1f(gl.getUniformLocation(program,'hasFace'),reaction?1:0);gl.uniform2f(gl.getUniformLocation(program,'faceOffset'),...p.faceOffset);
  const gaze=gl.getUniformLocation(program,'gaze'),focus=gl.getUniformLocation(program,'focus'),grump=gl.getUniformLocation(program,'grump'),points=new Float32Array(mesh.points.length);gl.clearColor(0,0,0,0);
  return{kind:'webgl',dispose,draw(v){if(gl.isContextLost())throw Error('bear attention context');for(let i=0;i<points.length;i+=2){const q=project(mesh.points[i],mesh.points[i+1],p,v);points[i]=q[0];points[i+1]=q[1]}gl.viewport(0,0,c.width,c.height);gl.bindBuffer(gl.ARRAY_BUFFER,moving);gl.bufferSubData(gl.ARRAY_BUFFER,0,points);gl.uniform2f(gaze,v.gx,v.gy);gl.uniform1f(focus,v.focus);gl.uniform1f(grump,v.grump);gl.clear(gl.COLOR_BUFFER_BIT);gl.drawElements(gl.TRIANGLES,mesh.indices.length,gl.UNSIGNED_SHORT,0)}};
 }catch(_){dispose();return null;}
}
const makeCanvas=doc=>{const c=doc.createElement('canvas');c.width=c.height=320;return c};
function cpu(c,photo,p,doc,reaction){const ctx=c.getContext('2d');if(!ctx)return null;const surface=makeCanvas(doc),s=surface.getContext('2d'),source=makeCanvas(doc);source.getContext('2d').drawImage(photo,0,0,320,320);const pixels=source.getContext('2d').getImageData(0,0,320,320),{points,indices}=small;
 const samplePixels=(data,x,y)=>{x=clamp(x,0,319);y=clamp(y,0,319);const a=Math.floor(x),b=Math.floor(y),u=x-a,v=y-b,out=[];for(let k=0;k<4;k++)out.push(mix(mix(data[(b*320+a)*4+k],data[(b*320+Math.min(a+1,319))*4+k],u),mix(data[(Math.min(b+1,319)*320+a)*4+k],data[(Math.min(b+1,319)*320+Math.min(a+1,319))*4+k],u),v));return out};
 const sample=(x,y)=>samplePixels(pixels.data,x,y),faceWeights=new Float32Array(320*320),faceRGB=new Uint8ClampedArray(320*320*4);
 if(reaction){const c=makeCanvas(doc);c.getContext('2d').drawImage(reaction,0,0,320,320);const data=c.getContext('2d').getImageData(0,0,320,320).data,[cx,cy,rx,ry]=p.head;
  for(let y=Math.max(0,Math.floor(cy-ry));y<Math.min(320,cy+ry*1.03);y++)for(let x=Math.max(0,Math.floor(cx-rx*1.03));x<Math.min(320,cx+rx*1.03);x++){const at=y*320+x,face=samplePixels(data,x+p.faceOffset[0],y+p.faceOffset[1]);let w=1-smooth(.72,1.02,Math.hypot((x-cx)/rx,(y-cy)/ry));if(p.pose==='rest')w*=smooth(.88,1.30,Math.hypot((x-275)/35,(y-205)/57));faceWeights[at]=w*smooth(.80,.99,face[3]/255);for(let k=0;k<3;k++)faceRGB[at*4+k]=face[k]}
 }
 function face(v){const copy=new ImageData(new Uint8ClampedArray(pixels.data),320,320);
  p.eyes.forEach((e,index)=>{const [cx,cy]=e.center,[rx,ry]=e.radius;
   for(let y=Math.floor(cy-ry-9);y<=Math.ceil(cy+ry+3);y++)for(let x=Math.floor(cx-rx-4);x<=Math.ceil(cx+rx+4);x++){
    if(x<0||y<0||x>=320||y>=320)continue;const at=(y*320+x)*4,b=Array.from(copy.data.slice(at,at+4));let d=100;
    for(let j=0;j<e.outline.length;j++){const a=e.outline[j],z=e.outline[(j+1)%e.outline.length],dx=z[0]-a[0],dy=z[1]-a[1];d=Math.min(d,(dx*(y-a[1])-dy*(x-a[0]))/Math.hypot(dx,dy))}
    const mask=smooth(.18,.75,d)*smooth(0,.08,v.focus);
    if(mask){const gx=mix(e.iris[0],cx+v.gx*e.travel[0],v.focus),gy=mix(e.iris[1],cy+v.gy*e.travel[1],v.focus),dx=(x-gx)/(rx*1.12),dy=(y-gy)/(ry*1.12),inside=1-smooth(.93,1.025,Math.hypot(dx,dy)),iris=sample(e.iris[0]+dx*rx,e.iris[1]+dy*ry),white=sample(...e.white),shade=.78+.12*Math.sqrt(Math.max(0,1-(((x-cx)/(rx+3))**2+((y-cy)/(ry+3))**2)*.6));for(let k=0;k<3;k++)b[k]=mix(b[k],mix(white[k]*shade,iris[k],inside),mask)}
    const nx=(x-cx)/(rx+2);if(!reaction&&v.grump&&Math.abs(nx)<.99){const h=Math.sqrt(Math.max(0,1-nx*nx))*(ry+1),top=cy-h,closed=top+2*h*(.27+(index?-.36:.36)*nx*.32)*v.grump,cover=(1-smooth(closed-.65,closed+.65,y))*smooth(top-7,top-2,y)*(1-smooth(.82,1,Math.abs(nx)))*smooth(0,.14,v.grump),fur=sample(x,top+y-closed);for(let k=0;k<3;k++)b[k]=mix(b[k],fur[k],cover)}
    for(let k=0;k<3;k++)copy.data[at+k]=b[k];
   }
  });if(reaction&&v.grump)for(let at=0;at<faceWeights.length;at++){const w=faceWeights[at]*v.grump;if(w)for(let k=0;k<3;k++)copy.data[at*4+k]=mix(copy.data[at*4+k],faceRGB[at*4+k],w)}s.putImageData(copy,0,0);
 }
 return{kind:'canvas',dispose(){c.width=0},draw(v){face(v);ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,c.width,c.height);ctx.scale(c.width/320,c.height/320);const moved=[];for(let j=0;j<points.length;j+=2)moved.push(project(points[j],points[j+1],p,v));
  for(let j=0;j<indices.length;j+=3){const ids=[indices[j],indices[j+1],indices[j+2]],src=ids.map(i=>[points[i*2],points[i*2+1]]),dst=ids.map(i=>moved[i]),[a,b,d]=src,[e,f,h]=dst,det=(b[0]-a[0])*(d[1]-a[1])-(d[0]-a[0])*(b[1]-a[1]),A=((f[0]-e[0])*(d[1]-a[1])-(h[0]-e[0])*(b[1]-a[1]))/det,B=((f[1]-e[1])*(d[1]-a[1])-(h[1]-e[1])*(b[1]-a[1]))/det,C=((h[0]-e[0])*(b[0]-a[0])-(f[0]-e[0])*(d[0]-a[0]))/det,D=((h[1]-e[1])*(b[0]-a[0])-(f[1]-e[1])*(d[0]-a[0]))/det;ctx.save();ctx.beginPath();const x=(e[0]+f[0]+h[0])/3,y=(e[1]+f[1]+h[1])/3;dst.forEach(([a,b],i)=>{const distance=Math.hypot(a-x,b-y)||1;ctx[i?'lineTo':'moveTo'](a+(a-x)/distance*.25,b+(b-y)/distance*.25)});ctx.closePath();ctx.clip();ctx.transform(A,B,C,D,e[0]-A*a[0]-C*a[1],e[1]-B*a[0]-D*a[1]);ctx.drawImage(surface,0,0);ctx.restore()}
 }};
}
async function start(image,state,kind,zone,reduced=false,held=false){
 if(kind==='affection'||!supports(state)||!Object.hasOwn(durations,kind))return prior.start(image,state,kind,zone,reduced,held);
 const p={...prior.profile(state)};p.eyes=eyes[p.pose];const photo=new g.Image();photo.src=image.getAttribute('href');await photo.decode();const entry=['paw','tail','angry'].includes(kind)?faceAssets[p.pose]:null,reaction=await facePhoto(entry);p.faceOffset=entry?.offset||[0,0];if(!image.isConnected)return null;
 const doc=image.ownerDocument,holder=doc.createElementNS(ns,'foreignObject');for(const[k,v]of Object.entries({x:0,y:0,width:320,height:320,'pointer-events':'none'}))holder.setAttribute(k,v);if(image.hasAttribute('transform'))holder.setAttribute('transform',image.getAttribute('transform'));holder.dataset.petLocalMotion=kind;holder.dataset.bearPose=p.pose;holder.dataset.bearAttention='145';
 if(reaction)holder.dataset.bearFaceOnly='146';const fresh=()=>{const c=doc.createElementNS('http://www.w3.org/1999/xhtml','canvas');c.width=c.height=640;c.style.cssText='display:block;width:320px;height:320px;pointer-events:none';holder.replaceChildren(c);return c};let c=fresh(),renderer=gpu(c,photo,p,reaction);if(!renderer){c=fresh();renderer=cpu(c,photo,p,doc,reaction)}if(!renderer)return null;holder.dataset.petRenderer=renderer.kind;
 let dead=false,raf=0,last=0,began=g.performance.now(),change=began,from=null,current=null;
 const target=point=>{point=point||{x:.65,y:.25};const ear=p.ears.reduce((best,e,i)=>Math.hypot(point.x-e.x,point.y-e.y)<Math.hypot(point.x-p.ears[best].x,point.y-p.ears[best].y)?i:best,0);return{x:clamp((point.x*320-p.head[0])/110),y:kind==='curious'?-.24:clamp((point.y*320-p.head[1])/100),ear}};let aim=target(zone);
 const sample=at=>{const v=values(p,kind,(at-began)/1000,aim,reduced);if(from){const t=smooth(0,160,at-change);for(const k of Object.keys(v))v[k]=mix(from[k],v[k],t);if(t===1)from=null}return v};
 function draw(at){current=sample(at);try{renderer.draw(current)}catch(_){renderer.dispose();c=fresh();renderer=cpu(c,photo,p,doc,reaction);if(renderer){holder.dataset.petRenderer='canvas';renderer.draw(current)}else dispose()}}
 function tick(at){if(dead)return;if(!image.isConnected||!holder.isConnected){dispose();return}if(!doc.hidden&&at-last>=(renderer.kind==='canvas'?60:30)){draw(at);last=at}raf=g.requestAnimationFrame(tick)}
 const opacity=image.getAttribute('opacity');function dispose(){if(dead)return;dead=true;sessions.delete(image);g.cancelAnimationFrame(raf);renderer?.dispose();holder.remove();if(opacity===null)image.removeAttribute('opacity');else image.setAttribute('opacity',opacity)}
 function retarget(point){const at=g.performance.now();from=sample(at);change=at;aim=target(point);began=at;return durations[kind]}
 image.after(holder);image.setAttribute('opacity','0');draw(began+(reduced?600:0));if(!reduced)raf=g.requestAnimationFrame(tick);
 const control={duration:durations[kind],root:holder,profile:p,retarget,dispose,alive:()=>!dead,state:()=>current,project:(x,y)=>project(x,y,p,current||values(p,'idle',0)),draw(ms){g.cancelAnimationFrame(raf);draw(began+ms)}};sessions.set(image,control);return control;
}
g.APMascotBearPoseAttention=Object.freeze({supports,values,project,eyes,start,configureFaces,legacy:prior.start,get:image=>sessions.get(image)});
g.APMascotBearPoses=Object.freeze({...prior,start});
})(globalThis);
