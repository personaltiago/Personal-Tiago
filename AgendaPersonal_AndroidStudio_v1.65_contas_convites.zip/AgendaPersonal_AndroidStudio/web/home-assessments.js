(function(){
 'use strict';
 const number=v=>typeof v==='number'&&Number.isFinite(v);
 const fmt=v=>v.toLocaleString('pt-BR',{maximumFractionDigits:1});
 function dateKey(value){
  const m=/^(\d{2})\/(\d{2})\/(\d{4})$/.exec(String(value||''));if(!m)return null;
  const day=Number(m[1]),month=Number(m[2]),year=Number(m[3]),d=new Date(year,month-1,day);
  return d.getFullYear()===year&&d.getMonth()===month-1&&d.getDate()===day?d.getTime():null;
 }
 function summary(records){
  const list=(Array.isArray(records)?records:[]).filter(r=>r&&dateKey(r.date)!==null).slice().sort((a,b)=>dateKey(a.date)-dateKey(b.date));
  const latest=list.at(-1),previous=list.filter(r=>latest&&dateKey(r.date)<dateKey(latest.date)).at(-1);
  if(!latest)return {date:'',previousDate:'',metrics:[]};
  const metrics=[['weight','Peso','kg'],['imc','IMC',''],['fat','% Gordura','%']].map(([key,label,unit])=>{
   const value=latest[key],valid=number(value)&&value>0&&(key!=='fat'||value<=100);
   const prior=previous?.[key],priorValid=number(prior)&&prior>0&&(key!=='fat'||prior<=100);
   return {label,unit,value:valid?value:null,delta:valid&&priorValid?value-prior:null,deltaUnit:key==='fat'?'p.p.':unit};
  });
  return {date:latest.date,previousDate:previous?.date||'',metrics};
 }
 function empty(message='Sem avaliações registradas'){
  const grid=document.getElementById('apHomeAssessmentSummary'),note=document.getElementById('apHomeAssessmentEmpty'),date=document.getElementById('apHomeAssessmentDate');
  if(grid){grid.textContent='';grid.hidden=true}if(note){note.textContent=message;note.hidden=false}if(date){date.textContent='';date.hidden=true}
 }
 function render(){
  if(!window.__AP_STUDENT_CONTEXT){empty();return}
  let result;try{result=summary(assReadData())}catch(_){empty('Não foi possível consultar as avaliações.');return}
  if(!result.date){empty();return}
  const grid=document.getElementById('apHomeAssessmentSummary'),note=document.getElementById('apHomeAssessmentEmpty'),date=document.getElementById('apHomeAssessmentDate');if(!grid)return;
  grid.textContent='';grid.hidden=false;note.hidden=true;date.hidden=false;
  date.textContent='Avaliação de '+result.date+(result.previousDate?' · Comparada com '+result.previousDate:' · Primeira avaliação');
  for(const metric of result.metrics){
   const card=document.createElement('div'),label=document.createElement('span'),value=document.createElement('strong');label.textContent=metric.label;
   value.textContent=metric.value===null?'—':fmt(metric.value)+(metric.unit==='%'?'%':'');
   if(metric.value!==null&&metric.unit==='kg'){const unit=document.createElement('small');unit.textContent=' kg';value.appendChild(unit)}
   card.append(label,value);
   if(metric.delta!==null){const delta=document.createElement('em'),rounded=Math.round(metric.delta*10)/10;delta.textContent=(rounded>0?'+':rounded<0?'−':'')+fmt(Math.abs(rounded))+(metric.deltaUnit?' '+metric.deltaUnit:'');card.appendChild(delta)}
   grid.appendChild(card);
  }
 }
 const home=renderHome;renderHome=function(...args){const result=home(...args);render();return result};
 window.addEventListener('ap-account-changed',()=>empty());
 window.APHomeAssessments=Object.freeze({summary,render});
})();
