(function(global){
 'use strict';
 const fold=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const trim=s=>String(s||'').replace(/[\u0000-\u001f]/g,' ').trim();
 function one(values){const unique=[...new Set(values)];return unique.length===1?unique[0]:null}
 function moneyIn(line){
  const explicit=String(line).match(/R\$\s*[\d.,]+/gi)||[];
  if(explicit.length)return explicit.map(APBilling.cents).filter(v=>v!==null);
  const out=[],re=/(^|[^\d.,])((?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d{2}|\.\d{2}))(?=$|[^\d.,])/g;let m;
  while((m=re.exec(line))) {const n=APBilling.cents(m[2]);if(n!==null)out.push(n)}return out;
 }
 function datesIn(line){
  const dates=[],add=(y,m,d)=>{const v=y+'-'+String(m).padStart(2,'0')+'-'+String(d).padStart(2,'0');if(APBilling.date(v))dates.push(v)};let m;
  const numeric=/\b(\d{2})[/.\-](\d{2})[/.\-](20\d{2})\b/g;
  while((m=numeric.exec(line)))add(m[3],m[2],m[1]);
  const months=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
  const textual=/\b(\d{1,2})\s+(?:de\s+)?(janeiro|jan|fevereiro|fev|marco|mar|abril|abr|maio|mai|junho|jun|julho|jul|agosto|ago|setembro|set|outubro|out|novembro|nov|dezembro|dez)\.?\s+(?:de\s+)?(20\d{2})\b/g;
  while((m=textual.exec(fold(line))))add(m[3],months.indexOf(m[2].slice(0,3))+1,m[1]);
  return dates;
 }
 function parse(text){
  const lines=String(text||'').slice(0,40000).split(/\r?\n/).map(trim).filter(Boolean),amounts=[],dates=[];let payer='',inPayer=false;
  for(let i=0;i<lines.length;i++){
   const raw=lines[i],line=fold(raw),next=lines[i+1]||'';
   const amountLabel=line.match(/^(valor(?:\s+(?:total da transferencia|total do pagamento|total|pago|recebido|transferido|da transferencia|do pagamento|do pix))?|total)(?=\s*(?:[:\-]|r\$|\d|$))\s*[:\-]?\s*/);
   if(amountLabel){const tail=raw.slice(amountLabel[0].length),values=moneyIn(tail||next);if(!values.length&&/^\s*(?:R\$\s*)?\d+(?:[.,]\d{1,2})?\s*$/.test(tail||next)){const n=APBilling.cents(tail||next);if(n!==null)values.push(n)}for(const n of values)amounts.push({n,score:/total|pago|recebido|transferido|transferencia/.test(amountLabel[1])?2:1})}
   const dateLabel=/^(?:data(?: do pagamento| da transferencia| do pix)?|realizado em|efetivado em|recebido em|pago em)\b/.test(line);
   for(const d of datesIn(raw+(dateLabel?' '+next:'')))dates.push({d,score:dateLabel?2:1});
   if(/^(?:dados (?:de quem recebeu|do recebedor|do favorecido)|quem recebeu|recebedor|favorecido|beneficiario|destino|para)\b/.test(line))inPayer=false;
   const direct=line.match(/^(nome do pagador|nome do remetente|pagador|remetente|enviado por|pago por|quem pagou|origem|de)(?=\s|[:\-]|$)\s*[:\-]?\s*/);
   if(direct){inPayer=true;const value=trim(raw.slice(direct[0].length));if(value&&!/^nome\b|^cpf\b|^cnpj\b|^banco\b/.test(fold(value))&&/[a-z]/i.test(fold(value)))payer=value.slice(0,160);continue}
   if(/^(?:dados (?:de quem pagou|do pagador|do remetente)|quem pagou)\b/.test(line)){inPayer=true;continue}
   if(inPayer&&!payer){const name=line.match(/^(nome(?: completo)?)\s*[:\-]?\s*/);if(name){const value=trim(raw.slice(name[0].length)||next);if(value&&/[a-z]/i.test(fold(value)))payer=value.slice(0,160)}}
  }
  let value=null,date='';
  if(amounts.length){const score=Math.max(...amounts.map(v=>v.score));value=one(amounts.filter(v=>v.score===score).map(v=>v.n))}
  else value=one(lines.filter(l=>/R\$/.test(l)&&!/(tarifa|saldo|limite|juros)/.test(fold(l))).flatMap(moneyIn));
  if(dates.length){const score=Math.max(...dates.map(v=>v.score));date=one(dates.filter(v=>v.score===score).map(v=>v.d))||''}
  const joined=lines.join('\n'),ids=joined.match(/\b[ED]\d{8}\d{8}[a-z0-9]{15}\b/gi)||[];
  return {payer,amountCents:value,paymentDate:date,transactionId:one(ids.map(v=>v.toUpperCase()))||'',suspicious:/\b(?:agendad[oa]|cancelad[oa]|devolvid[oa]|recusad[oa]|nao efetivad[oa]|em processamento)\b/.test(fold(joined)),text:joined};
 }
 const tx=value=>trim(value).replace(/\s+/g,'').toUpperCase();
 function duplicate(state,hash,transactionId){
  const tid=tx(transactionId),rows=[...(Array.isArray(state.financeReceiptLedger)?state.financeReceiptLedger:[]),...(state.payments||[]).map(p=>p.receipt).filter(Boolean)];
  return rows.some(r=>r.hash===hash||tid&&tx(r.transactionId)===tid);
 }
 function validate(fields,student,state,attachment,now=new Date()){
  if(!student||student.financeEnabled!==true||!APBilling.date(student.dueDate))throw Error('Configure o financeiro e o vencimento deste aluno.');
  if(student.dueDate!==fields.dueDate)throw Error('O vencimento mudou durante a conferência. Feche e abra o comprovante novamente.');
  if(!attachment||!/^[a-f0-9]{64}$/.test(attachment.hash))throw Error('Anexe o comprovante antes de confirmar.');
  const payer=trim(fields.payer),amountCents=APBilling.cents(fields.amount),date=APBilling.date(fields.paymentDate),transactionId=tx(fields.transactionId);
  if(payer.length<2||payer.length>160)throw Error('Confira e informe o nome do pagador.');
  if(amountCents===null||amountCents<=0)throw Error('Informe o valor recebido, maior que zero.');
  const today=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0')+'-'+String(now.getDate()).padStart(2,'0');
  if(!date||date>today)throw Error('Confira a data. Um recebimento não pode ter data futura.');
  if(transactionId&&!/^[A-Z0-9-]{16,80}$/.test(transactionId))throw Error('Confira o identificador do Pix ou deixe o campo vazio se não estiver legível.');
  if(!fields.confirmPayer||!fields.confirmAmount||!fields.confirmDate)throw Error('Confirme o vínculo com o aluno, o valor e a data antes de registrar.');
  if(!['settle','receipt'].includes(fields.mode))throw Error('Escolha como registrar o pagamento.');
  const expected=APBilling.cents(student.monthlyValue);
  if(fields.mode==='settle'&&expected!==amountCents&&!fields.confirmDifference)throw Error('O valor é diferente da mensalidade. Confirme que ele quita este vencimento ou escolha somente registrar o recebimento.');
  if(duplicate(state,attachment.hash,transactionId))throw Error('Este comprovante ou identificador Pix já foi registrado. Nenhuma nova baixa foi feita.');
  const [y,m,d]=date.split('-').map(Number);
  return {payer,amountCents,paymentDate:date,paidAt:new Date(y,m-1,d).toISOString(),transactionId,settlesMonthlyFee:fields.mode==='settle',differenceAccepted:fields.mode==='settle'&&expected!==amountCents};
 }
 global.APPixReceipt=Object.freeze({parse,validate,duplicate,tx});
})(globalThis);
