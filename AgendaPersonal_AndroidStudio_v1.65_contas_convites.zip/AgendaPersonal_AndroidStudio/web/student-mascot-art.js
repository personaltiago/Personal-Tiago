(function(global){
 'use strict';
 // Transparent mascot cutouts are packaged inside a local HTML asset.
 // Their alpha is retained throughout loading, caching and SVG rendering.
 let images=null,coats=null,poses=null,affectionImages=null,reactionImages=null,pending=null,failed=false;
 const safe=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function load(){
  if(images)return true;if(pending)return pending;failed=false;
  pending=(async()=>{
   try{
    const source=typeof global.APdecodeSource==='function'?await global.APdecodeSource('ap-embedded-registration'):await (await fetch(new URL('cadastro.html',document.baseURI))).text();
    const doc=new DOMParser().parseFromString(source,'text/html'),node=doc.getElementById('ap-mascot-image-assets');
    global.APMascotHomes?.hydrate(doc);
    for(const packed of doc.querySelectorAll?.('[data-ap-gzip]')||[]){const raw=Uint8Array.from(atob(packed.textContent),c=>c.charCodeAt(0));packed.textContent=await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'))).text();packed.removeAttribute('data-ap-gzip')}
    const runtime=doc.getElementById('ap-mascot-gesture-runtime');if(runtime&&!global.APMascotPetting?.gestures){const script=document.createElement('script');script.textContent=JSON.parse(runtime.textContent);document.head.append(script);script.remove()}
    const bearNode=doc.getElementById('ap-approved-bear-assets');if(bearNode)global.APMascotBear?.configure(JSON.parse(bearNode.textContent));
    const faceNode=doc.getElementById('ap-bear-face-reaction-assets');if(faceNode)global.APMascotBearPoseAttention?.configureFaces(JSON.parse(faceNode.textContent));
    if(!node)throw Error('Mascot images missing');const data=JSON.parse(node.textContent),coatNode=doc.getElementById('ap-mascot-coat-assets');if(!coatNode)throw Error('Natural coats missing');const natural=JSON.parse(coatNode.textContent),poseNode=doc.getElementById('ap-mascot-pose-assets');if(!poseNode)throw Error('Pose images missing');const positions=JSON.parse(poseNode.textContent),affectionNode=doc.getElementById('ap-mascot-affection-assets'),cuddles=affectionNode?JSON.parse(affectionNode.textContent):{};
    const portraits=APMascotModel.choices.flatMap(c=>['baby','teen','adult'].map(p=>data[c.id]?.[p]));
    if(portraits.some(uri=>!/^data:image\/(?:webp|png);base64,[A-Za-z0-9+/=]+$/.test(uri||'')))throw Error('Invalid mascot image');
    // Validate locally one at a time, keeping mobile decode memory bounded.
    for(const uri of portraits)await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>img.naturalWidth>=256&&img.naturalWidth<=2048&&img.naturalHeight>=256&&img.naturalHeight<=2048?resolve():reject(Error('Invalid dimensions'));img.onerror=reject;img.src=uri});
    for(const c of APMascotModel.choices)for(const design of (APMascotModel.colorsFor?.(c.id)||[{frame:0}]).filter(v=>v.frame!==null))for(const phase of ['baby','teen','adult']){const uri=natural[c.id]?.[design.frame]?.[phase];if(!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(uri||''))throw Error('Invalid natural coat');await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>img.naturalWidth>=256&&img.naturalWidth<=2048&&img.naturalHeight>=256&&img.naturalHeight<=2048?resolve():reject(Error('Invalid coat dimensions'));img.onerror=reject;img.src=uri})}
    for(const c of APMascotModel.choices)for(const p of (APMascotModel.posesFor?.(c.id)||[]).filter(p=>p.id!=='default'))for(const design of APMascotModel.colorsFor(c.id))for(const phase of ['baby','teen','adult']){const v=positions[c.id]?.[p.id]?.[design.id]?.[phase];if(!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(v?.uri||'')||!Number.isFinite(v.headTop)||v.headTop<0||v.headTop>1||!Number.isFinite(v.headX)||v.headX<0||v.headX>1)throw Error('Invalid pose artwork')}
    if(affectionNode)for(const c of APMascotModel.choices)for(const color of APMascotModel.colorsFor(c.id))for(const phase of ['baby','teen','adult'])if(!/^data:image\/webp;base64,[A-Za-z0-9+/=]+$/.test(cuddles[c.id]?.[color.id]?.[phase]?.uri||''))throw Error('Invalid affection frame');
    const reactionNode=doc.getElementById('ap-mascot-reaction-assets');reactionImages=reactionNode?JSON.parse(reactionNode.textContent):{};
    images=data;coats=natural;poses=positions;affectionImages=cuddles;global.dispatchEvent(new Event('ap-mascot-art-ready'));return true;
   }catch(_){failed=true;global.dispatchEvent(new Event('ap-mascot-art-error'));return false}
   finally{pending=null}
  })();return pending;
 }
 const poseData=s=>global.APMascotBear?.supports(s)?{headTop:.08,headX:.60}:poses?.[s.species]?.[global.APMascotModel.pose?.(s)?.id]?.[selectedColor(s).id]?.[APMascotModel.phase(s.xp).id]||null;
 const portrait=s=>global.APMascotBear?.portrait(s)||(global.APMascotModel.pose?.(s)?.id&&APMascotModel.pose(s).id!=='default'?poseData(s)?.uri||'':selectedColor(s).frame!==null?coats?.[s.species]?.[selectedColor(s).frame]?.[APMascotModel.phase(s.xp).id]||'':images?.[s.species]?.[APMascotModel.phase(s.xp).id]||'');
 const scale=s=>({baby:.7,teen:.85,adult:1})[APMascotModel.phase(s.xp).id];
 const turns={kitten:['teen','adult'],wolf:['adult'],capybara:['baby','teen'],panda:['teen','adult'],rooster:['teen','adult'],alligator:['teen','adult']};
 const selectedColor=s=>global.APMascotModel.color?.(s)||{id:'original',name:'Original',frame:null};
 const mirrored=s=>!global.APMascotBear?.supports(s)&&(global.APMascotModel.pose?.(s)?.id||'default')==='default'&&turns[s.species]?.includes(APMascotModel.phase(s.xp).id)===true;
 function affection(s){return global.APMascotBear?.asset(s)||affectionImages?.[s.species]?.[selectedColor(s).id]?.[APMascotModel.phase(s.xp).id]||null}
 function reaction(s){return reactionImages?.[s.species]?.[selectedColor(s).id]?.[APMascotModel.phase(s.xp).id]||null}
 function render(s,mini=false,earlyPhoto='',petting=false){
  const choice=APMascotModel.choices.find(c=>c.id===s.species),phase=APMascotModel.phase(s.xp).id;
  const palette=selectedColor(s),position=petting?{id:'petting',name:'Carinho'}:global.APMascotModel.pose?.(s)||{id:'default',name:'Pose original'};
  const label=choice?s.name+', '+choice.name+', '+APMascotModel.phase(s.xp).name+', '+palette.name+', '+position.name+', visual 3D':'Escolha seu companheiro de treino',photo=petting?affection(s)?.uri||'':portrait(s)||(/^data:image\/(?:webp|png);base64,[A-Za-z0-9+/=]+$/.test(earlyPhoto)?earlyPhoto:'');
  // These are separately drawn natural coats, not a tint on the original.
  // Whole isolated sprites retain paws, ears and tail in every phase.
  const orientation=!petting&&mirrored(s)?' transform="translate(320 0) scale(-1 1)"':'';
  const content=photo?'<image data-mascot-photo="'+safe(s.species)+'" data-mascot-photo-phase="'+phase+'"'+orientation+' width="320" height="320" href="'+photo+'" preserveAspectRatio="xMidYMid meet"/>':choice?'<text x="160" y="162" text-anchor="middle" fill="currentColor" font-size="16">'+(failed?'Imagem indisponível':'Carregando…')+'</text>':'<g fill="currentColor" opacity=".3"><ellipse cx="160" cy="185" rx="32" ry="26"/><ellipse cx="119" cy="149" rx="13" ry="18"/><ellipse cx="147" cy="126" rx="12" ry="17"/><ellipse cx="177" cy="126" rx="12" ry="17"/><ellipse cx="203" cy="149" rx="13" ry="18"/></g>';
  // Keep the adult canvas unchanged; younger pets grow from the same floor.
  const size=scale(s),space=320-320*size,scaled=size===1?content:'<g transform="translate('+(space/2)+' '+space+') scale('+size+')">'+content+'</g>';
  return '<svg viewBox="0 0 320 320" role="img" aria-label="'+safe(label)+'" data-mascot-species="'+safe(s.species||'none')+'" data-mascot-phase="'+phase+'" data-mascot-color="'+palette.id+'" data-mascot-pose="'+position.id+'" data-mascot-style="3d-reference">'+scaled+'</svg>';
 }
 global.APMascotArt=Object.freeze({load,render,portrait,scale,mirrored,affection,reaction,renderAffection:s=>render(s,true,'',true),landmarks:poseData,ready:()=>!!images,error:()=>failed});
})(globalThis);
