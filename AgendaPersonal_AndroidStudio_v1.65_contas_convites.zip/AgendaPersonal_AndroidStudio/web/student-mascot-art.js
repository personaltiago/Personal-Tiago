(function(global){
 'use strict';
 // The approved JPEG bytes are packaged inside an existing local HTML asset.
 // They are displayed without redrawing, cropping or image manipulation.
 let images=null,pending=null,failed=false;
 const safe=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function load(){
  if(images)return true;if(pending)return pending;failed=false;
  pending=(async()=>{
   try{
    const source=typeof global.APdecodeSource==='function'?await global.APdecodeSource('ap-embedded-registration'):await (await fetch(new URL('cadastro.html',document.baseURI))).text();
    const doc=new DOMParser().parseFromString(source,'text/html'),node=doc.getElementById('ap-mascot-image-assets');
    if(!node)throw Error('Mascot images missing');const data=JSON.parse(node.textContent);
    const portraits=APMascotModel.choices.flatMap(c=>['baby','teen','adult'].map(p=>data[c.id]?.[p]));
    if(portraits.some(uri=>!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(uri||'')))throw Error('Invalid mascot image');
    // Validate locally one at a time, keeping mobile decode memory bounded.
    for(const uri of portraits)await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>img.naturalWidth===1536&&img.naturalHeight===1536?resolve():reject(Error('Invalid dimensions'));img.onerror=reject;img.src=uri});
    images=data;global.dispatchEvent(new Event('ap-mascot-art-ready'));return true;
   }catch(_){failed=true;global.dispatchEvent(new Event('ap-mascot-art-error'));return false}
   finally{pending=null}
  })();return pending;
 }
 const portrait=s=>images?.[s.species]?.[APMascotModel.phase(s.xp).id]||'';
 function render(s,mini=false,earlyPhoto=''){
  const choice=APMascotModel.choices.find(c=>c.id===s.species),phase=APMascotModel.phase(s.xp).id;
  const label=choice?s.name+', '+choice.name+', '+APMascotModel.phase(s.xp).name+', visual 3D':'Escolha seu companheiro de treino',photo=portrait(s)||(/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(earlyPhoto)?earlyPhoto:'');
  const content=photo?'<image data-mascot-photo="'+safe(s.species)+'" data-mascot-photo-phase="'+phase+'" width="320" height="320" href="'+photo+'" preserveAspectRatio="xMidYMid meet"/>':choice?'<rect width="320" height="320" rx="18" fill="#faf6f1"/><text x="160" y="162" text-anchor="middle" fill="#665c60" font-size="16">'+(failed?'Imagem indisponível':'Carregando…')+'</text>':'<g fill="currentColor" opacity=".3"><ellipse cx="160" cy="185" rx="32" ry="26"/><ellipse cx="119" cy="149" rx="13" ry="18"/><ellipse cx="147" cy="126" rx="12" ry="17"/><ellipse cx="177" cy="126" rx="12" ry="17"/><ellipse cx="203" cy="149" rx="13" ry="18"/></g>';
  return '<svg viewBox="0 0 320 320" role="img" aria-label="'+safe(label)+'" data-mascot-species="'+safe(s.species||'none')+'" data-mascot-phase="'+phase+'" data-mascot-style="3d-reference">'+content+'</svg>';
 }
 global.APMascotArt=Object.freeze({load,render,portrait,ready:()=>!!images,error:()=>failed});
})(globalThis);
