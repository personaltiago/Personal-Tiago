function studentArchiveSyncHtml(student){
 const api=window.parent?.APaccounts,area=(api?.knownAreas?.()||[]).find(a=>a.studentUid===student.firebaseUid),status=student.firebaseUid?api?.status(student.firebaseUid):null;
 const confirmed=area?.enabled===false&&status?.state==='sent';
 const text=!student.firebaseUid?'Cadastro e fichas preservados. Este aluno não tem uma conta vinculada.':confirmed?'Bloqueio enviado. O app do aluno aplica a suspensão ao sincronizar.':status?.state==='error'?'Bloqueio ainda não confirmado. '+status.message:'Bloqueio aguardando envio. Conecte o app do professor à internet.';
 return '<div class="student-archive-sync" role="status"><span>'+hesc(text)+'</span>'+(student.firebaseUid&&!confirmed?'<button class="btn" type="button" onclick="retryStudentArchive(this.closest(\'[data-student-id]\').dataset.studentId)">Tentar sincronizar</button>':'')+'</div>';
}
function toggleStudentArchive(sid){
 const student=studentById(sid);if(!student)return false;
 const archived=student.archived===true;
 if(!confirm((archived?'Reativar ':'Arquivar ')+student.name+'?\n\n'+(archived?'O aluno volta à lista '+(student.studentType==='online'?'Online':'Presencial')+' e recebe acesso às fichas ativas após sincronizar.':'O aluno sai das listas ativas e seus treinos serão bloqueados no aplicativo ao sincronizar.')+'\n\nCadastro, fichas, avaliações, cargas e histórico de pagamentos serão mantidos.'))return false;
 const next={...student,archived:!archived,archivedAt:archived?'':new Date().toISOString(),archiveReason:archived?'':'manual',archiveDueDate:''};
 if(archived){next.workoutInactive=false;next.reactivatedAt=new Date().toISOString()}
 if(!commitWorkoutChange({students:state.students.map(s=>s.id===sid?next:s)},(archived?'Aluno reativado · ':'Aluno arquivado · ')+student.name))return false;
 if(currentProfileStudentId===sid)renderStudentProfile();
 showScreen(archived?(studentTypeLabel(next.studentType)?'students-'+next.studentType:'students-unassigned'):'students-archived');
 toast(archived?'Aluno reativado. A liberação dos treinos será sincronizada.':'Aluno arquivado. O bloqueio será sincronizado.');
 return true;
}
function retryStudentArchive(sid){const s=studentById(sid);if(!s)return;window.parent?.APaccounts?.retry(s.firebaseUid);renderAll()}
const archiveAreaStatusBefore=window.APupdateAreaStatus;
window.APupdateAreaStatus=function(uid){if(archiveAreaStatusBefore)archiveAreaStatusBefore(uid);if(currentScreen==='students')renderStudents()};
