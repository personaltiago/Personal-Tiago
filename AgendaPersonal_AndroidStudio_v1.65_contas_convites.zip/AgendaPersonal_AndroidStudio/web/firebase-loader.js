(function(){
 'use strict';let loading;
 function install(source){return new Promise((resolve,reject)=>{
  const url=URL.createObjectURL(new Blob([source],{type:'text/javascript'})),tag=document.createElement('script');
  const cleanup=()=>{URL.revokeObjectURL(url);tag.remove()};tag.src=url;
  tag.onload=()=>{cleanup();window.APFirebaseLocal?resolve(window.APFirebaseLocal):reject(Error('AP-SDK-INIT'))};tag.onerror=()=>{cleanup();reject(Error('AP-SDK-LOAD'))};document.head.appendChild(tag);
 })}
 async function local(){
  const packed=document.getElementById('ap-firebase-packed');if(!packed||typeof DecompressionStream!=='function')throw Error('AP-SDK-FALLBACK');
  const raw=Uint8Array.from(atob(packed.textContent.trim()),c=>c.charCodeAt(0)),stream=new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'));
  return install(await new Response(stream).text());
 }
 window.APloadFirebase=function(){
  if(loading)return loading;
  loading=local().then(sdk=>[sdk.app,sdk.auth,sdk.store]).catch(()=>Promise.all([
   import('https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js'),
   import('https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js'),
   import('https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js')
  ])).catch(error=>{loading=null;throw error});return loading;
 };
})();
