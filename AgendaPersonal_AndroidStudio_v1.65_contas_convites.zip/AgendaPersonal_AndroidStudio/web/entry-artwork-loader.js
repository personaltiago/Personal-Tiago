(function(){
 'use strict';let pending;
 const image=document.querySelector('[data-ap-lazy-image="gender"]');if(!image)return;
 function load(){
  if(image.hasAttribute('src'))return Promise.resolve();if(pending)return pending;
  pending=(async()=>{
   const source=await window.APdecodeSource('ap-embedded-registration'),match=source.match(/<script id="ap-entry-artwork" type="application\/json">([\s\S]*?)<\/script>/);
   if(!match)throw Error('AP-ART-MISSING');const data=JSON.parse(match[1]);if(!/^data:image\/(?:png|jpeg);base64,/.test(data.gender||''))throw Error('AP-ART-INVALID');
   image.decoding='async';image.src=data.gender;
  })().catch(error=>{pending=null;image.dataset.loadError=error.message;throw error});return pending;
 }
 const check=()=>{if(document.body.dataset.view==='gender')load().catch(()=>{})};
 if(typeof MutationObserver==='function')new MutationObserver(check).observe(document.body,{attributes:true,attributeFilter:['data-view']});
 check();
 if(typeof IntersectionObserver==='function'){
  const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting))load().then(()=>observer.disconnect()).catch(()=>{})});observer.observe(image);
 }else{
  const check=()=>{if(image.getClientRects().length)load().catch(()=>{})};
  new MutationObserver(check).observe(document.body,{attributes:true,attributeFilter:['data-view']});check();
 }
})();
