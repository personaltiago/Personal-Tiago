// Weekday order is presentation only. Every result retains its queried date,
// conflict calculation and scheduling target, including across month/year changes.
function availabilitySundayStart(value=iso(new Date())){
 const date=parseDate(value);date.setDate(date.getDate()-date.getDay());return date;
}
function renderAvailabilityCalendar(rows,renderRow){
 const ordered=[...rows].sort((a,b)=>a.d.getDay()-b.d.getDay()||a.ds.localeCompare(b.ds));
 if(ordered.length<=7)return ordered.map(renderRow).join('');
 return [0,1,2,3,4,5,6].map(day=>{
  const dates=ordered.filter(row=>row.d.getDay()===day);
  if(!dates.length)return '';
  return `<section class="availability-weekday-group" data-availability-weekday="${day}" aria-labelledby="availabilityWeekday${day}"><h3 id="availabilityWeekday${day}">${attendanceDayName(day)}</h3>${dates.map(row=>renderRow({...row,grouped:true})).join('')}</section>`;
 }).join('');
}
