(function(){
 'use strict';
 const key='agendaPersonalTL_teacher_text_v1',sizes={normal:1,large:1.125,xlarge:1.25},root=document.documentElement;
 function read(){try{const v=JSON.parse(localStorage.getItem(key)||'null');return v?.version===1&&Object.hasOwn(sizes,v.id)?v.id:'normal'}catch(_){return 'normal'}}
 let selected=read();
 function apply(){
  root.dataset.teacherTextSize=selected;root.style.setProperty('--ap-ts',sizes[selected]);
  document.querySelectorAll('[data-teacher-text]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.teacherText===selected)));
  window.dispatchEvent(new Event('resize'));
 }
 window.APTeacherText=Object.freeze({key,get:()=>selected,scale:()=>sizes[selected],set(id){
  if(!Object.hasOwn(sizes,id))return {ok:false,error:'Escolha um dos tamanhos disponíveis.'};
  try{localStorage.setItem(key,JSON.stringify({version:1,id}))}catch(_){return {ok:false,error:'Não foi possível salvar o tamanho. Libere espaço no aparelho e tente novamente.'}}
  selected=id;apply();return {ok:true};
 }});
 apply();
 addEventListener('storage',event=>{if(event.key===key||event.key===null){selected=read();apply()}});
 document.addEventListener('DOMContentLoaded',()=>{
  apply();document.querySelectorAll('[data-teacher-text]').forEach(button=>button.addEventListener('click',()=>{
   const result=APTeacherText.set(button.dataset.teacherText),status=document.getElementById('teacherTextStatus');
   status.textContent=result.ok?'Tamanho salvo: '+button.textContent.trim()+'.':result.error;status.dataset.error=String(!result.ok);
  }));
 },{once:true});
})();
