(function(){
 'use strict';
 const accounts=()=>window.APaccounts||window.parent?.APaccounts,context=()=>window.__AP_STUDENT_CONTEXT||window.parent?.__AP_STUDENT_CONTEXT;
 const owner=()=>context()?.role==='student'?context().storageId:accounts()?.isTeacher()===true?accounts().teacherUid?.()||'':'';
 const teacher=()=>accounts()?.isTeacher()===true&&!context();
 const key=uid=>'agenda_watch_history_v1_'+uid;
 function normalized(raw){
  const r={token:String(raw?.token||''),owner:String(raw?.owner||''),role:raw?.role,person:String(raw?.person||'').slice(0,120),label:String(raw?.label||'Treino').slice(0,200),startedAt:Number(raw?.startedAt),finishedAt:Number(raw?.finishedAt),durationMs:Number(raw?.durationMs),completed:Number(raw?.completed),total:Number(raw?.total)};
  if(!/^[A-Za-z0-9_-]{1,160}$/.test(r.token)||!r.owner||!['student','teacher'].includes(r.role)||![r.startedAt,r.finishedAt,r.durationMs,r.completed,r.total].every(Number.isSafeInteger)||r.startedAt<=0||r.finishedAt<r.startedAt||r.finishedAt>Date.now()+300000||r.durationMs<0||r.durationMs>86400000||r.total<1||r.total>2400||r.completed<0||r.completed>r.total)throw Error('Este resumo não tem uma identificação válida para inclusão.');
  return r;
 }
 function records(){
  if(teacher())return Array.isArray(state.watchWorkoutResults)?state.watchWorkoutResults:[];
  if(context()?.role!=='student')return [];try{const list=JSON.parse(localStorage.getItem(key(owner()))||'[]');return Array.isArray(list)?list:[]}catch(_){return []}
 }
 function available(nativeRows=[]){let saved=[];try{saved=JSON.parse(localStorage.getItem('agenda_watch_pending_v1_'+owner())||'[]')}catch(_){}return [...new Map([...saved.filter(r=>r?.owner===owner()),...nativeRows.filter(r=>r&&(!r.owner||r.owner===owner()))].map(r=>[r.token||JSON.stringify([r.role,r.person,r.label,r.startedAt,r.finishedAt]),r])).values()]}
 function include(raw,studentId=''){
  const r=normalized(raw),uid=owner();if(!uid||r.owner!==uid||r.role!==(teacher()?'teacher':'student'))throw Error('O resultado não pertence a esta conta.');
  if(teacher()&&!state.students.some(s=>s.id===studentId))throw Error('Selecione o aluno deste treino.');
  const sid=teacher()?studentId:context().area?.studentId||context().storageId,list=records(),previous=list.find(v=>v.token===r.token&&v.owner===uid);
  if(previous){if(previous.studentId!==sid)throw Error('Este treino já está vinculado a outro aluno.');return false}
  const next=[{...r,studentId:sid,source:'smartwatch'},...list];
  if(teacher()){if(!commitWorkoutChange({watchWorkoutResults:next},'Resumo do smartwatch incluído no histórico',false))throw Error('Não foi possível salvar o resumo.')}
  else localStorage.setItem(key(uid),JSON.stringify(next));
  dispatchEvent(new Event('ap-watch-history-changed'));return true;
 }
 function controls(card,raw,role){
  let r;try{r=normalized(raw)}catch(_){return}if(r.owner!==owner())return;
  const current=records().find(v=>v.token===r.token&&v.owner===r.owner);
  if(current){const text=document.createElement('p');text.textContent='Incluído no histórico'+(teacher()?' · '+(state.students.find(s=>s.id===current.studentId)?.name||'Aluno arquivado'):'')+'.';card.append(text);return}
  let select;if(role==='teacher'){
   const label=document.createElement('label');label.textContent='Aluno deste treino';select=document.createElement('select');const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Selecione para vincular';select.append(placeholder);
   for(const s of state.students){const option=document.createElement('option');option.value=s.id;option.textContent=s.name+' · '+(s.studentType==='online'?'Online':'Presencial')+' · '+String(s.id).slice(-6);select.append(option)}label.append(select);card.append(label);
  }
  const button=document.createElement('button'),status=document.createElement('p');button.type='button';button.textContent='Incluir no histórico';status.setAttribute('role','status');button.onclick=()=>{try{const added=include(r,select?.value);status.textContent=added?'Resumo incluído. Cargas e repetições não foram inventadas.':'Este resumo já está no histórico.';button.disabled=true;if(select)select.disabled=true}catch(e){status.textContent=e.message}};card.append(button,status);
 }
 function timeline(studentId,phone=[],from=-Infinity,agenda=[]){
  const rows=[];
  for(const r of phone){const t=Number(r.finishedAt);if(Number.isFinite(t)&&t>=from)rows.push({key:'phone:'+JSON.stringify([r.id,r.startedAt,r.finishedAt]),time:t,label:r.workoutName||r.id||'Treino',source:'Aplicativo do aluno',detail:r.incomplete===false?'Concluído':'Registro parcial',duration:Number(r.durationMs)||Math.max(0,t-Number(r.startedAt))})}
  for(const r of agenda){const t=Date.parse(r.finishedAt||r.recordedAt||r.date);if(!Number.isFinite(t)||t<from)continue;const complete=window.APStudentFollowupModel?.fullyCompleted(r)===true;rows.push({key:'teacher:'+r.id,time:t,label:r.dayName||r.planName||'Treino',source:'Registro do professor',detail:complete?'Todas as séries confirmadas':'Registro parcial ou sem detalhamento completo',duration:Number(r.durationSeconds)*1000||0})}
  for(const raw of records()){try{const r=normalized(raw);if(r.owner!==owner()||raw.studentId!==studentId||r.finishedAt<from)continue;rows.push({key:'watch:'+r.owner+':'+r.token,time:r.finishedAt,label:r.label,source:'Smartwatch',detail:r.completed+'/'+r.total+' séries confirmadas'+(r.completed<r.total?' · parcial':' · concluído'),duration:r.durationMs})}catch(_){}}
  return [...new Map(rows.map(r=>[r.key,r])).values()].sort((a,b)=>b.time-a.time);
 }
 function render(target,rows,role){
  if(!target)return;target.replaceChildren();target.className='ap-unified-history';const heading=document.createElement('div');heading.className='ap-unified-history-heading';const title=document.createElement('h4');title.textContent='Histórico de sessões';heading.append(title);
  if(role==='student'){const close=document.createElement('button');close.type='button';close.className='ap-unified-history-close';close.textContent='×';close.setAttribute('aria-label','Fechar aviso do smartwatch');close.title='Fechar aviso do smartwatch';close.onclick=()=>{target.hidden=true};heading.append(close)}
  const note=document.createElement('p');note.textContent='Agenda, aplicativo e resumos do relógio, identificados pela origem. Resumos do smartwatch confirmam séries e tempo; não medem carga ou repetições.';if(role==='student')note.textContent+=' Os resumos do relógio incluídos aqui ficam neste aparelho; não são enviados automaticamente ao professor.';const button=document.createElement('button');button.type='button';button.className='btn';button.textContent='Resultados do smartwatch';button.onclick=()=>APWatchUI.results(role);target.append(heading,note,button);
  if(!rows.length){const p=document.createElement('p');p.textContent='Nenhuma sessão disponível neste período.';target.append(p)}
  for(const r of rows){const article=document.createElement('article'),name=document.createElement('strong'),meta=document.createElement('p'),detail=document.createElement('p');name.textContent=r.label;meta.textContent=r.source+' · '+new Date(r.time).toLocaleString('pt-BR');detail.textContent=r.detail+' · '+Math.floor(r.duration/60000)+' min';article.append(name,meta,detail);target.append(article)}
 }
 function renderTeacher(studentId,phone,from,target){if(!teacher())return;render(target,timeline(studentId,phone,from,(state.workoutExecutions||[]).filter(r=>r.studentId===studentId)),'teacher')}
 function renderStudent(){if(context()?.role!=='student')return;const screen=document.getElementById('historyScreen');if(!screen)return;let box=document.getElementById('apStudentUnifiedHistory');if(!box){box=document.createElement('section');box.id='apStudentUnifiedHistory';screen.append(box)}const period=document.getElementById('evPeriod')?.value||'all',date=new Date();if(period!=='all'){date.setMonth(date.getMonth()-Number(period.replace('m','')));date.setHours(0,0,0,0)}render(box,timeline(context().area?.studentId||context().storageId,exStore()?.history||[],period==='all'?-Infinity:date.getTime()),'student')}
 if(typeof renderHistory==='function'&&typeof exStore==='function'){const before=renderHistory;renderHistory=function(...args){const r=before(...args);renderStudent();return r}}
 addEventListener('ap-watch-history-changed',()=>{if(teacher())window.APTeacherProgress?.render?.();else renderStudent()});
 try{(window.parent||window).addEventListener('ap-account-changed',()=>document.getElementById('apStudentUnifiedHistory')?.remove())}catch(_){}
 window.APWatchHistory=Object.freeze({include,records,available,controls,timeline,normalized,renderTeacher,renderStudent});
})();
