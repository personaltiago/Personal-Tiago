(function(){
 'use strict';
 const prefix='agenda_student_notifications_v1_',limit=80;
 const uid=()=>window.__AP_STUDENT_CONTEXT?.role==='student'?window.__AP_STUDENT_CONTEXT.storageId:'';
 let owner='',state=null,focusBefore=null;
 const $=id=>document.getElementById(id);
 function load(){
  const id=uid();if(!id){owner='';state=null;return null}if(owner===id&&state)return state;
  owner=id;try{const saved=JSON.parse(localStorage.getItem(prefix+id)||'null');if(saved?.schema===1&&Array.isArray(saved.items)){state=saved;state.items=state.items.filter(n=>n&&typeof n.id==='string'&&['workout','app-available','app-installed'].includes(n.kind)&&typeof n.title==='string'&&typeof n.body==='string'&&Number.isFinite(n.at)).slice(0,limit);return state}}catch(_){}
  return state={schema:1,items:[],serial:0,lastWorkout:null,lastInstalled:0,lastOffered:0};
 }
 function save(next){
  const id=uid();if(!id||id!==owner)return false;
  try{localStorage.setItem(prefix+id,JSON.stringify(next));state=next;refresh();return true}catch(_){toast('Não foi possível salvar os avisos neste aparelho.');return false}
 }
 const copy=()=>JSON.parse(JSON.stringify(load()));
 function add(next,item){next.items=next.items.filter(n=>n.id!==item.id);next.items.unshift({...item,at:Date.now(),read:false});next.items=next.items.slice(0,limit)}
 function fingerprint(area){
  const stable=v=>Array.isArray(v)?v.map(stable):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):v;
  const text=JSON.stringify(stable(area?{studentId:area.studentId,enabled:area.enabled,plans:area.plans}:null));
  // A local change detector, not an integrity or authorization check.
  let a=2166136261,b=0x9e3779b9;for(let i=0;i<text.length;i++){a=Math.imul(a^text.charCodeAt(i),16777619);b=Math.imul(b^text.charCodeAt(i),2246822519)}
  return (a>>>0).toString(16)+':'+(b>>>0).toString(16)+':'+text.length;
 }
 function receiveWorkout(area,fromCache=false){
  if(!uid()||fromCache||area&&(area.studentUid!==uid()||area.professorId!==APStudentModel.TEACHER))return;
  const current=load(),hash=fingerprint(area);if(current.lastWorkout===hash)return;
  const next=copy(),hadPrevious=next.lastWorkout!==null,hasWorkout=area?.enabled&&area.plans?.some(p=>p.days?.some(d=>d.exercises?.length));
  next.lastWorkout=hash;
  if(hadPrevious||hasWorkout){
   next.serial=(Number(next.serial)||0)+1;
   add(next,{id:'workout:'+next.serial,kind:'workout',title:hadPrevious?'Treino atualizado pelo professor':'Seu treino está disponível',body:hasWorkout?'Confira as alterações na sua ficha de treino.':'O professor alterou a disponibilidade da sua ficha.'});
  }
  save(next);
 }
 function receiveUpdate(info){
  if(!uid()||!info||!Number.isSafeInteger(info.installedSequence)||info.installedSequence<1)return;
  const current=load(),next=copy(),installed=info.installedSequence,version=String(info.installedVersion||'').slice(0,40),release=info.manifest;
  if(next.lastInstalled&&installed>next.lastInstalled)add(next,{id:'app:'+installed,kind:'app-installed',sequence:installed,title:'Aplicativo atualizado',body:'Versão '+version+' instalada.'});
  next.lastInstalled=Math.max(next.lastInstalled||0,installed);
  for(const item of next.items)if(item.kind==='app-available'&&item.sequence<=installed){item.read=true;item.resolved=true}
  if(release?.available===true&&Number.isSafeInteger(release.sequence)&&release.sequence>installed&&release.sequence>(next.lastOffered||0)){
   next.lastOffered=release.sequence;
   add(next,{id:'app:'+release.sequence,kind:'app-available',sequence:release.sequence,title:'Atualização do aplicativo disponível',body:'Versão '+String(release.version||'').slice(0,40)+' pronta para baixar.'});
  }
  if(JSON.stringify(next)!==JSON.stringify(current))save(next);else refresh();
 }
 function unread(){return load()?.items.filter(n=>!n.read).length||0}
 function refresh(){
  const count=unread(),badge=$('apStudentNotificationCount'),bell=$('apStudentNotificationBell');
  if(badge){badge.hidden=count===0;badge.textContent=count>99?'99+':String(count)}
  if(bell)bell.setAttribute('aria-label',count?'Notificações, '+count+' não '+(count===1?'lida':'lidas'):'Notificações');
  if($('apStudentNotifications')&&!$('apStudentNotifications').hidden)render();
 }
 function mark(id){const next=copy();if(!next)return;for(const item of next.items)if(item.id===id)item.read=true;save(next)}
 function markAll(){const next=copy();if(!next)return;for(const item of next.items)item.read=true;save(next)}
 function action(item){
  if(!uid())return;mark(item.id);
  if(item.kind==='workout'){close();route('workouts')}
  else if(item.kind==='app-available'&&!item.resolved){close();APaccounts.openUpdates()}
 }
 function render(){
  const root=$('apStudentNotificationList'),current=load();if(!root)return;root.textContent='';
  const count=current?.items.filter(n=>!n.read).length||0,markButton=$('apStudentNotificationsRead');markButton.disabled=!count;
  $('apStudentNotificationsSummary').textContent=count?count+' '+(count===1?'notificação não lida':'notificações não lidas'):current?.items.length?'Todos os avisos foram lidos':'Atualizações do aplicativo e dos seus treinos';
  if(!current?.items.length){const empty=document.createElement('p');empty.className='ap-notif-empty';empty.textContent='Nenhuma notificação por enquanto.';root.appendChild(empty);return}
  for(const item of current.items){
   const card=document.createElement('article');card.className='ap-notif-item'+(item.read?'':' is-unread');
   const title=document.createElement('h3'),body=document.createElement('p'),date=document.createElement('time');title.textContent=item.title;body.textContent=item.resolved?'Essa versão já foi instalada.':item.body;date.dateTime=new Date(item.at).toISOString();date.textContent=new Date(item.at).toLocaleString('pt-BR',{dateStyle:'short',timeStyle:'short'});card.append(title,body,date);
   const actionable=item.kind==='workout'||item.kind==='app-available'&&!item.resolved;
   if(actionable||!item.read){const button=document.createElement('button');button.type='button';button.className='ap-notif-action';button.textContent=item.kind==='workout'?'Ver treino':item.kind==='app-available'&&!item.resolved?'Baixar atualização':'Marcar como lida';button.onclick=()=>action(item);card.appendChild(button)}
   root.appendChild(card);
  }
 }
 function open(){
  if(!uid())return false;ready();focusBefore=document.activeElement;
  const modal=$('apStudentNotifications');modal.style.setProperty('--notif-accent',prefs().color||'#f52283');modal.hidden=false;render();$('apStudentNotificationsClose').focus({preventScroll:true});return true;
 }
 function close(){const modal=$('apStudentNotifications');if(!modal||modal.hidden)return false;modal.hidden=true;focusBefore?.focus?.({preventScroll:true});return true}
 function ready(){
  if(!uid()){refresh();return}
  const current=load(),area=window.__AP_STUDENT_CONTEXT.area;
  if(current.lastWorkout===null&&area?.studentUid===uid()){const next=copy();next.lastWorkout=fingerprint(area);save(next)}
  try{if(window.Android?.getUpdateStatus)receiveUpdate(JSON.parse(Android.getUpdateStatus()))}catch(_){}refresh();
 }
 window.APnotifications=Object.freeze({open,close,receiveWorkout,receiveUpdate,unread,ready});
 const home=renderHome;renderHome=function(...args){const result=home(...args);refresh();return result};
 window.addEventListener('ap-student-ready',ready);
 window.addEventListener('ap-account-changed',()=>{close();owner='';state=null;refresh()});
 window.addEventListener('ap-update-status',event=>receiveUpdate(event.detail));
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)ready()});
 document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&close()){event.preventDefault();return}
  const modal=$('apStudentNotifications');if(event.key!=='Tab'||!modal||modal.hidden)return;
  const buttons=Array.from(modal.querySelectorAll('button:not(:disabled)')),first=buttons[0],last=buttons.at(-1);
  if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus()}
  else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus()}
 });
 const modal=$('apStudentNotifications');modal.addEventListener('click',event=>{if(event.target===modal)close()});
 $('apStudentNotificationsClose').onclick=close;$('apStudentNotificationsRead').onclick=markAll;
})();
