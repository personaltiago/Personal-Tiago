function workoutImportResolveExercise(ex,catalog){
  // Preserve each PDF field; fill only absent fields from the resolved catalog
  // exercise. Persist the result as part of this prescription, not a live link.
  const comparison=workoutImportInstructionComparison(ex.name,ex.sourceInstructionName);
  const sourceNotes=workoutImportText(ex.sourceNotes??ex.notes),sourceObservations=workoutImportText(ex.sourceObservations??ex.observations);
  ex.sourceNotes=sourceNotes;ex.sourceObservations=sourceObservations;
  ex.notes=sourceNotes;ex.observations=sourceObservations;
  ex.warnings=[...(ex.structuralWarnings||[])];ex.notices=[];
  ex.catalogName=catalog?.name||'';
  ex.instructionName=ex.sourceInstructionName||ex.name;
  ex.instructionResolution='source';ex.guidanceResolvedFromCatalog=false;
  if(catalog){
    ex.catalogId=catalog.id;ex.muscle=catalog.muscle||'';ex.category=catalog.category||'';ex.video=catalog.video||'';
  }else{
    ex.catalogId='';ex.muscle='';ex.category='';ex.video='';
    if(ex.ambiguous)ex.warnings.push('Há mais de uma correspondência no catálogo. Escolha o exercício correto na galeria.');
  }
  const catalogNotes=catalog?workoutImportText(catalog.notes):'',catalogObservations=catalog?workoutImportText(catalog.observations):'';
  if(!sourceNotes)ex.notes=catalogNotes;
  if(!sourceObservations)ex.observations=catalogObservations;
  ex.notesOrigin=sourceNotes?'pdf':ex.notes?'catalog':'missing';
  ex.observationsOrigin=sourceObservations?'pdf':ex.observations?'catalog':'missing';
  ex.guidanceResolvedFromCatalog=ex.notesOrigin==='catalog'||ex.observationsOrigin==='catalog';
  ex.instructionResolution=ex.guidanceResolvedFromCatalog?(sourceNotes||sourceObservations?'mixed':'catalog'):'source';
  if(comparison==='conflict')ex.warnings.push(`O exercício “${ex.name}” e o título das instruções “${ex.sourceInstructionName}” divergem. O texto do PDF foi preservado. Confira antes de confirmar a importação; vincular um vídeo não corrige essa divergência.`);
  if(sourceNotes)ex.notices.push('Como fazer: texto do PDF preservado, sem substituição pelo catálogo.');
  else ex.notices.push(ex.notes?'Como fazer: preenchido pelo catálogo porque o campo não foi reconhecido no PDF.':'Como fazer: não informado no PDF nem disponível no exercício vinculado do catálogo.');
  if(!sourceObservations)ex.notices.push(ex.observations?'Observações: preenchidas pelo catálogo porque o campo não foi reconhecido no PDF.':'Observações: não informadas no PDF nem disponíveis no exercício vinculado do catálogo.');
  return ex;
}
