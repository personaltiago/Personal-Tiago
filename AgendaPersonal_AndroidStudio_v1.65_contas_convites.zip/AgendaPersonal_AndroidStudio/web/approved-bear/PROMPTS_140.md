# Expressões de protesto — 1.12.140

Método: ferramenta integrada de geração/edição de imagens (modo de edição com referência local e fundo transparente). Uma chamada separada para cada pelagem: Original, Todo branco, Castanho e branco, Creme e Canela.

Referências: `web/mascot-reactions/panda-{original,white,brown,cream,cinnamon}-adult.webp` da versão 1.12.139. Os novos PNGs de origem e seus hashes estão identificados em `expressions-140.json`. O aplicativo utiliza as conversões WebP de 240 × 240 registradas no manifesto de reações.

Prompt comum, normalizado:

> Edit this exact transparent seated bear/panda game sprite. Change ONLY the facial expression into a clear mild angry protest: lower the inner ends of both eyebrows into a firm V, slightly narrow the eyes while looking at the viewer, fully close the mouth with a small DOWNturned pout, no smile or tongue. Keep cute character identity and same existing coat COLORS AND PATCH PATTERNS, head silhouette/size, ear placement, nose, lighting, realistic furry 3D style, same seated pose and exactly the same raised paw and all four paws/pads. Do not move, stretch or enlarge the head or body. Position and scale must match source in square image, full feet uncut, true transparent background. No text, symbols, heart, clothes, background or new objects. It is an expression frame, not a redesign.

Na chamada Canela, o mesmo pedido foi formulado explicitando pelagem cinnamon, focinho creme e almofadinhas; a instrução adicional foi: “The raised paw must stay perfectly still.”

Nenhuma chamada alterou os sprites de carinho.
