(function(global){
 'use strict';
 const MAX=50*1024*1024,CONTROL='agenda-full-backup-control-v1';
 const specs=[['tiago-lima-avaliacoes-v1','records',null],['agendaPersonalWorkoutDocs_v1','documents','id'],['agendaPersonalPixReceipts_v1','receipts','key'],['agenda_personal_relatorios_pdf_v1','pdfs','id']];
 const bad=new Set(['__proto__','constructor','prototype']);
 function bytes64(bytes){let s='';for(let i=0;i<bytes.length;i+=32768)s+=String.fromCharCode(...bytes.subarray(i,i+32768));return btoa(s)}
 function from64(s){if(typeof s!=='string'||s.length>MAX*1.4||!/^[A-Za-z0-9+/]*={0,2}$/.test(s))throw Error('Anexo inválido.');return Uint8Array.from(atob(s),c=>c.charCodeAt(0))}
 async function pack(v,depth=0){
  if(depth>60)throw Error('Dados muito complexos para o backup.');
  if(v===null||['string','boolean'].includes(typeof v)||typeof v==='number'&&Number.isFinite(v))return v;
  if(v===undefined)return {t:'undefined'};
  if(v instanceof Blob)return {t:'blob',mime:v.type,v:bytes64(new Uint8Array(await v.arrayBuffer()))};
  if(v instanceof ArrayBuffer||ArrayBuffer.isView(v))return {t:'bytes',kind:v instanceof ArrayBuffer?'ArrayBuffer':v.constructor.name,v:bytes64(new Uint8Array(v instanceof ArrayBuffer?v:v.buffer,v.byteOffset||0,v.byteLength))};
  if(v instanceof Date)return {t:'date',v:v.toISOString()};
  if(Array.isArray(v))return {t:'array',v:await Promise.all(v.map(x=>pack(x,depth+1)))};
  if(v&&typeof v==='object'){const entries=[];for(const [k,value]of Object.entries(v)){if(bad.has(k))throw Error('Campo inválido no backup.');entries.push([k,await pack(value,depth+1)])}return {t:'object',v:entries}}
  throw Error('O backup contém um tipo de dado não suportado.');
 }
 function unpack(v,depth=0){
  if(depth>60)throw Error('Dados inválidos.');if(v===null||['string','boolean'].includes(typeof v)||typeof v==='number'&&Number.isFinite(v))return v;
  if(!v||typeof v!=='object')throw Error('Dados inválidos.');
  if(v.t==='undefined')return undefined;
  if(v.t==='blob')return new Blob([from64(v.v)],{type:String(v.mime||'')});
  if(v.t==='bytes'){const b=from64(v.v);if(v.kind==='ArrayBuffer')return b.buffer;const kinds={Uint8Array,Int8Array,Uint16Array,Int16Array,Uint32Array,Int32Array,Float32Array,Float64Array};const Type=kinds[v.kind];if(!Type)throw Error('Anexo inválido.');return new Type(b.buffer)}
  if(v.t==='date'){const d=new Date(v.v);if(!Number.isFinite(d.getTime()))throw Error('Data inválida.');return d}
  if(v.t==='array'&&Array.isArray(v.v))return v.v.map(x=>unpack(x,depth+1));
  if(v.t==='object'&&Array.isArray(v.v)){const result={};for(const pair of v.v){if(!Array.isArray(pair)||pair.length!==2||typeof pair[0]!=='string'||bad.has(pair[0])||Object.hasOwn(result,pair[0]))throw Error('Campo inválido.');result[pair[0]]=unpack(pair[1],depth+1)}return result}
  throw Error('Formato inválido.');
 }
 async function digest(text){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))].map(b=>b.toString(16).padStart(2,'0')).join('')}
 function open(name,store,keyPath,existing=false){return new Promise((resolve,reject)=>{
  const request=indexedDB.open(name),timer=setTimeout(()=>reject(Error('O armazenamento está ocupado. Feche outras abas.')),10000);let missing=false;
  request.onupgradeneeded=()=>{if(existing){missing=true;request.transaction.abort()}else request.result.createObjectStore(store,keyPath?{keyPath}:undefined)};
  request.onsuccess=()=>{clearTimeout(timer);resolve(request.result)};request.onerror=()=>{clearTimeout(timer);missing?resolve(null):reject(Error('Não foi possível abrir '+name))};request.onblocked=()=>{clearTimeout(timer);reject(Error('Feche outras abas antes de continuar.'))};
 })}
 async function dbRead(spec){const [name,store,keyPath]=spec,db=await open(name,store,keyPath,true);if(!db)return {name,store,keyPath,rows:[]};
  try{return await new Promise((resolve,reject)=>{if(!db.objectStoreNames.contains(store))return reject(Error('Armazenamento incompatível: '+name));const tx=db.transaction(store),s=tx.objectStore(store),keys=s.getAllKeys(),values=s.getAll();tx.oncomplete=()=>resolve({name,store,keyPath:s.keyPath,rows:values.result.map((value,i)=>({key:keys.result[i],value}))});tx.onerror=tx.onabort=()=>reject(Error('Falha ao ler os anexos.'))})}finally{db.close()}
 }
 async function dbWrite(data){const db=await open(data.name,data.store,data.keyPath);try{await new Promise((resolve,reject)=>{
  if(!db.objectStoreNames.contains(data.store))return reject(Error('Armazenamento incompatível.'));const tx=db.transaction(data.store,'readwrite'),s=tx.objectStore(data.store);
  if(JSON.stringify(s.keyPath)!==JSON.stringify(data.keyPath)){tx.abort();return reject(Error('Estrutura de anexos incompatível.'))}
  tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(Error('Não foi possível gravar os anexos.'));s.clear();for(const r of data.rows)s.keyPath?s.put(r.value):s.put(r.value,r.key);
 })}finally{db.close()}}
 async function journal(value,read=false){const db=await open(CONTROL,'restore',null);try{return await new Promise((resolve,reject)=>{const tx=db.transaction('restore',read?'readonly':'readwrite'),s=tx.objectStore('restore'),q=read?s.get('pending'):value?s.put(value,'pending'):s.delete('pending');tx.oncomplete=()=>resolve(q.result);tx.onerror=tx.onabort=()=>reject(Error('Não foi possível guardar a recuperação do backup.'))})}finally{db.close()}}
 const keys=owner=>{
  const prefs=Object.values(global.APTeacherSyncPreferences?.keys||{});
  return k=>k==='agendaPersonalTL_v1'||k==='tiago-lima-avaliacoes-v1'||prefs.includes(k)||k.startsWith('agenda_progress_teacher_v1_'+owner+'_')||k==='agenda_watch_history_v1_'+owner||k==='agenda_watch_pending_v1_'+owner;
 };
 function local(owner){const match=keys(owner),result={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(match(k))result[k]=localStorage.getItem(k)}return result}
 function writeLocal(data,owner){const match=keys(owner);for(const k of Object.keys(local(owner)))if(!Object.hasOwn(data,k))localStorage.removeItem(k);for(const [k,v]of Object.entries(data)){if(!match(k)||typeof v!=='string')throw Error('Chave fora do backup.');localStorage.setItem(k,v)}}
 async function capture(owner){const values=local(owner);if(!values.agendaPersonalTL_v1&&typeof state!=='undefined')values.agendaPersonalTL_v1=JSON.stringify(state);return {owner,local:values,databases:await Promise.all(specs.map(dbRead))}}
 function validate(data,owner){
  if(!data||data.owner!==owner||!data.local||!Array.isArray(data.databases)||data.databases.length!==specs.length)throw Error('Este backup não pertence à conta do professor conectada.');
  const match=keys(owner);for(const [k,v]of Object.entries(data.local))if(!match(k)||typeof v!=='string')throw Error('O arquivo contém uma chave não permitida.');
  const agenda=JSON.parse(data.local.agendaPersonalTL_v1||'null');if(!agenda||!Array.isArray(agenda.students)||!Array.isArray(agenda.workoutPlans))throw Error('O arquivo não contém uma agenda válida.');
  for(let i=0;i<specs.length;i++){const d=data.databases[i],[name,store]=specs[i];if(d.name!==name||d.store!==store||![null,'id','key'].includes(d.keyPath)||!Array.isArray(d.rows)||d.rows.length>50000)throw Error('Anexos incompatíveis.');if(d.rows.some(r=>!r||!Object.hasOwn(r,'key')||!Object.hasOwn(r,'value')))throw Error('Anexo incompleto.')}
  if(Object.values(agenda.workoutDrafts||{}).some(d=>d?.active===true)||Number(agenda.workoutRest?.endAt)>Date.now())throw Error('Finalize ou pare o treino ativo antes de criar ou restaurar um backup.');
  return agenda;
 }
 async function create(owner){const data=await capture(owner);validate(data,owner);try{const native=global.Android||global.parent?.Android,rows=native?.getWatchStatus?JSON.parse(native.getWatchStatus()).results||[]:[],prior=JSON.parse(data.local['agenda_watch_pending_v1_'+owner]||'[]'),all=[...prior,...rows].filter(r=>r.owner===owner);if(all.length)data.local['agenda_watch_pending_v1_'+owner]=JSON.stringify([...new Map(all.map(r=>[r.token,r])).values()])}catch(_){}const payload=await pack(data),body=JSON.stringify(payload);if(new TextEncoder().encode(body).length>MAX)throw Error('O conjunto excede 50 MB. Nenhum anexo foi omitido.');const file={format:1,appId:'com.tiagolima.agendapersonal.backup',owner,createdAt:new Date().toISOString(),payload};return {...file,sha256:await digest(JSON.stringify(file))}}
 async function prepare(text,owner){if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX+10000)throw Error('Arquivo maior que 50 MB.');const file=JSON.parse(text);if(file.format!==1||file.appId!=='com.tiagolima.agendapersonal.backup'||file.owner!==owner||await digest(JSON.stringify({format:file.format,appId:file.appId,owner:file.owner,createdAt:file.createdAt,payload:file.payload}))!==file.sha256)throw Error('Backup inválido, alterado ou de outra conta.');const data=unpack(file.payload),agenda=validate(data,owner),assessments=data.databases[0].rows.find(r=>r.key==='workspace')?.value||JSON.parse(data.local['tiago-lima-avaliacoes-v1']||'{"clients":[]}');if(!assessments||!Array.isArray(assessments.clients))throw Error('O histórico de avaliações do backup é inválido.');return {data,createdAt:file.createdAt,summary:{students:agenda.students.length,workouts:(agenda.workoutExecutions||[]).length,documents:data.databases[1].rows.length,receipts:data.databases[2].rows.length,assessmentClients:assessments.clients.length,pdfs:data.databases[3].rows.length}}}
 async function apply(data){for(const db of data.databases)await dbWrite(db);writeLocal(data.local,data.owner)}
 async function restore(prepared,owner,guard=()=>true){validate(prepared.data,owner);if(!guard())throw Error('A conta mudou.');const before=await capture(owner);if(!guard())throw Error('A conta mudou.');await journal({before});
  try{await apply(prepared.data);if(!guard())throw Error('A conta mudou.');await journal(null)}catch(error){try{await apply(before);await journal(null)}catch(_){throw Error('A restauração foi interrompida. Reabra o app para recuperar os dados anteriores.')}throw error}
 }
 async function recover(){const pending=await journal(null,true);if(pending?.before){await apply(pending.before);await journal(null);return true}return false}
 async function locked(task,recovery=false){if(!global.navigator?.locks)return task();return navigator.locks.request('agenda-full-backup-v1',{ifAvailable:true},lock=>{if(!lock){if(recovery)return false;throw Error('Outra janela está usando o backup. Aguarde e tente novamente.')}return task()})}
 global.APFullBackupCore=Object.freeze({create:owner=>locked(()=>create(owner)),prepare,restore:(...args)=>locked(()=>restore(...args)),recover:()=>locked(recover,true),bytes64,pack,unpack,capture});
})(globalThis);
