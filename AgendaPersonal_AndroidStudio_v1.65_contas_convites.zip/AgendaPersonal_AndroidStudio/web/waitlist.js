(function(){
 'use strict';
 const M=APWaitlistModel,$=id=>document.getElementById(id);
 let selected='',offers=[],offerEntry='',offerKey='',busy=false;
 const queue=()=>M.ordered(state.waitlist),active=()=>queue().filter(r=>!r.studentId||state.students.some(s=>s.id===r.studentId&&s.studentType==='presencial'&&s.archived!==true));
 const day=date=>parseDate(date).getDay(),stamp=()=>new Date().toISOString();
 function dateText(date){return attendanceDayName(day(date))+', '+fmtDate(date)}
 function label(slot){return dateText(slot.date)+' · '+slot.time+'–'+M.time(M.minutes(slot.time)+slot.duration)+' · '+slot.duration+' min'}
 function status(text){$('wlStatus').textContent=text}
 function saveQueue(next){
  try{
   const raw=localStorage.getItem(DB_KEY),current=raw?JSON.parse(raw):state;
   if(!current||typeof current!=='object'||Array.isArray(current))throw Error('storage');
   if(JSON.stringify(current.waitlist||[])!==JSON.stringify(state.waitlist||[])){
    state.waitlist=Array.isArray(current.waitlist)?current.waitlist:[];renderWaitlist();status('A fila mudou em outra janela. Confira a ordem antes de tentar novamente.');return false;
   }
   localStorage.setItem(DB_KEY,JSON.stringify({...current,waitlist:next}));
  }catch(_){status('Não foi possível salvar a lista de espera. Seus dados foram mantidos. Verifique o espaço do aparelho e tente novamente.');return false}
  state.waitlist=next;renderWaitlist();window.APTeacherSync?.changed();return true;
 }
 function context(){
  const now=new Date(),today=iso(now),range=automaticAvailabilityRange()||automaticAvailabilityDefaults(),windows=[];
  for(let i=0;i<30;i++){const d=new Date(now);d.setDate(now.getDate()+i);const date=iso(d);for(const w of freeAttendanceWindows(date,range.start,range.end))windows.push({...w,date,day:d.getDay()})}
  return {now,today,range,windows,slots:M.opportunities(active(),windows,today,now.getHours()*60+now.getMinutes())};
 }
 function validSlot(slot,duration=slot?.duration){
  if(!slot||!validWorkoutDate(slot.date)||!M.durations.includes(Number(duration)))return false;
  const now=new Date(),range=automaticAvailabilityRange()||automaticAvailabilityDefaults(),start=M.minutes(slot.time),end=M.time(start+Number(duration));
  return start>=M.minutes(range.start)&&start+Number(duration)<=M.minutes(range.end)&&slot.date>=iso(now)&&Number.isFinite(start)&&start+Number(duration)<1440&&!(slot.date===iso(now)&&start<=now.getHours()*60+now.getMinutes())&&slotInsideAttendance(slot.date,slot.time,end)&&availabilitySlotConflicts(slot.date,slot.time,end).length===0;
 }
 function currentCandidates(slot){return slot?M.candidates(active(),slot,day(slot.date)):[]}
 window.renderWaitlist=function(){
  if(!$('wlQueue'))return;
  const model=context(),rows=queue();offers=model.slots;
  const previous=offers.find(s=>M.key(s)===selected),old=selected.split('|');
  if(!previous&&old.length===3){const slot={date:old[0],time:old[1],duration:Number(old[2])};if(validSlot(slot)&&currentCandidates(slot).length)offers.push(slot)}
  offers.sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)||a.duration-b.duration);
  if(!offers.some(s=>M.key(s)===selected))selected=offers[0]?M.key(offers[0]):'';
  $('wlSlot').innerHTML=offers.length?offers.map(s=>'<option value="'+hesc(M.key(s))+'"'+(M.key(s)===selected?' selected':'')+'>'+hesc(label(s))+'</option>').join(''):'<option value="">Nenhuma vaga compatível neste período</option>';
  $('wlSlot').disabled=!offers.length;
  $('wlRange').textContent='Consulta de '+fmtDate(model.today)+' a '+fmtDate(iso(new Date(model.now.getFullYear(),model.now.getMonth(),model.now.getDate()+29)))+', das '+model.range.start+' às '+model.range.end+'.';
  $('wlScope').textContent=availabilityLimitsEnabled()?'Respeita os limites de atendimento, aulas avulsas, repetições e cancelamentos da agenda.':'Sem limites de atendimento definidos. Usa o intervalo de Horários livres; confira seus horários de trabalho antes de oferecer a vaga.';
  $('wlCount').textContent=rows.length+' '+(rows.length===1?'pessoa':'pessoas');
  $('wlQueue').innerHTML=rows.length?rows.map((r,i)=>{
   const eligible=active().some(x=>x.id===r.id),days=(r.days||[]).map(d=>longDays[d]?.split('-')[0]||'').join(', ');
   return '<li class="wl-entry"><strong><span class="wl-order">'+(i+1)+'º</span>'+hesc(r.name)+'</strong><small>'+hesc(r.phone)+' · '+hesc(days)+' · '+hesc(r.start)+'–'+hesc(r.end)+' · '+Number(r.duration)+' min</small>'+(eligible?'':'<small>Cadastro vinculado arquivado ou fora da modalidade presencial. Edite para revisar.</small>')+'<div class="wl-actions"><button class="btn" type="button" data-wl-edit="'+hesc(r.id)+'">Editar</button><button class="btn" type="button" data-wl-remove="'+hesc(r.id)+'">Retirar da fila</button></div></li>';
  }).join(''):'<li class="wl-empty">Nenhuma pessoa na lista de espera. Adicione um nome e WhatsApp para começar.</li>';
  renderOffer();
  document.querySelectorAll('[data-waitlist-count]').forEach(el=>el.textContent=rows.length?String(rows.length):'');
 };
 function renderOffer(){
  const slot=offers.find(s=>M.key(s)===selected),person=currentCandidates(slot)[0],position=person?queue().findIndex(r=>r.id===person.id)+1:0;
  const old=$('wlMessage'),draft=old&&old.dataset.entry===person?.id&&old.dataset.slot===selected?old.value:null;
  offerEntry=person?.id||'';offerKey=selected;
  if(!person){$('wlOffer').innerHTML='<p class="wl-empty">'+(queue().length?'Nenhum aluno compatível com esta vaga. A fila continua na mesma ordem.':'Adicione pessoas à fila para encontrar um encaixe.')+'</p>';return}
  const message=draft??M.message(person,slot,dateText(slot.date));
  $('wlOffer').innerHTML='<div class="wl-offer"><h4>É a vez de '+hesc(person.name)+'</h4><p class="wl-help">'+position+'º na fila geral · primeira pessoa compatível com este horário.</p><label for="wlMessage">Mensagem para o WhatsApp</label><textarea id="wlMessage" maxlength="2000" data-entry="'+hesc(person.id)+'" data-slot="'+hesc(selected)+'">'+hesc(message)+'</textarea><div class="wl-actions"><button class="btn primary" type="button" id="wlWhatsApp">Abrir WhatsApp</button><button class="btn" type="button" id="wlDecline">Não pode este horário</button></div><p class="wl-help">Confira e envie a mensagem no WhatsApp. Abrir a conversa não reserva a vaga nem retira a pessoa da fila. Após combinar o atendimento, agende a aula e retire o nome da lista.</p></div>';
  $('wlWhatsApp').onclick=openContact;$('wlDecline').onclick=decline;
 }
 window.selectWaitlistSlot=function(value){selected=value;offerKey='';renderOffer()};
 window.openWaitlist=function(){showScreen('waitlist');renderWaitlist()};
 window.openWaitlistEditor=function(entryId=''){
  const row=entryId?queue().find(r=>r.id===entryId):null;if(entryId&&!row)return;
  $('wlForm').reset();$('wlEditId').value=row?.id||'';$('wlFormError').textContent='';
  $('wlEditorTitle').textContent=row?'Editar pessoa na fila':'Adicionar à lista de espera';
  $('wlStudent').innerHTML='<option value="">Digitar nome e WhatsApp</option>'+state.students.filter(s=>s.studentType==='presencial'&&s.archived!==true).map(s=>'<option value="'+hesc(s.id)+'">'+hesc(s.name)+'</option>').join('');
  $('wlStudent').value=row?.studentId||'';$('wlName').value=row?.name||'';$('wlPhone').value=row?.phone||'';$('wlStart').value=row?.start||'06:00';$('wlEnd').value=row?.end||'22:00';$('wlDuration').value=String(row?.duration||60);
  $('wlDays').innerHTML=[0,1,2,3,4,5,6].map(d=>'<label><input type="checkbox" name="wlDay" value="'+d+'"'+(!row||row.days?.includes(d)?' checked':'')+'>'+hesc(days[d])+'</label>').join('');
  openDialog('waitlistEditor');$('wlName').focus();
 };
 window.chooseWaitlistStudent=function(sid){const s=studentById(sid);if(s&&s.studentType==='presencial'&&s.archived!==true){$('wlName').value=s.name;$('wlPhone').value=s.phone||''}};
 function refreshIfStale(){
  try{const stored=JSON.parse(localStorage.getItem(DB_KEY)||'null'),raw=stored?normalizeState(stored):null;if(raw&&['students','lessons','occurrenceStatus','weeklyAvailability','availabilityMode','waitlist'].some(k=>JSON.stringify(raw[k]??null)!==JSON.stringify(state[k]??null))){for(const k of Object.keys(state))delete state[k];Object.assign(state,raw);renderAll();status('A agenda mudou. Confira a vaga e a próxima pessoa antes de continuar.');return true}}catch(_){status('Não foi possível conferir os dados salvos. Feche e abra a agenda antes de continuar.');return true}return false;
 }
 function target(){
  if(refreshIfStale())return null;
  const slot=offers.find(s=>M.key(s)===selected),person=currentCandidates(slot)[0];
  if(!person||person.id!==offerEntry||selected!==offerKey||!validSlot(slot,person.duration)){renderWaitlist();status('A vaga ou a ordem da fila mudou. Confira novamente antes de chamar.');return null}
  return {slot,person};
 }
 function openContact(){
  const value=target();if(!value)return;const text=$('wlMessage').value.trim(),number=M.phone(value.person.phone);if(!number||!text){status('Confira o WhatsApp e a mensagem antes de abrir a conversa.');return}
  try{if(typeof window.Android?.openWhatsAppMessage==='function'){Android.openWhatsAppMessage(number,text);status('Conversa aberta. Envie a mensagem no WhatsApp; a pessoa permanece na fila.');return}
   const opened=window.open('https://wa.me/'+number+'?text='+encodeURIComponent(text),'_blank');if(!opened){status('O navegador bloqueou a conversa. Permita abrir o WhatsApp e tente novamente.');return}status('Conversa aberta. Envie a mensagem no WhatsApp; a pessoa permanece na fila.');
  }catch(_){status('Não foi possível abrir o WhatsApp. Tente novamente. A pessoa permanece na fila.')}
 }
 function decline(){const value=target();if(!value)return;const key=value.slot.date+'|'+value.slot.time,next=state.waitlist.map(r=>r.id===value.person.id?{...r,declinedSlots:[...new Set([...(r.declinedSlots||[]),key])],updatedAt:stamp()}:r);if(saveQueue(next))status(value.person.name+' não recebe esta vaga. A posição nas outras oportunidades foi mantida.')}
 $('wlForm').onsubmit=function(event){
  event.preventDefault();if(busy)return;busy=true;
  try{
   const entryId=$('wlEditId').value,previous=entryId?queue().find(r=>r.id===entryId):null;if(entryId&&!previous)throw Error('Essa pessoa já saiu da fila. Confira a lista.');
   const sid=$('wlStudent').value;if(sid&&!state.students.some(s=>s.id===sid&&s.studentType==='presencial'&&s.archived!==true))throw Error('Escolha um aluno presencial ativo ou digite os dados sem vínculo.');
   const row=M.entry({name:$('wlName').value,phone:$('wlPhone').value,studentId:sid,start:$('wlStart').value,end:$('wlEnd').value,duration:$('wlDuration').value,days:[...$('wlDays').querySelectorAll('input:checked')].map(n=>Number(n.value))},previous,new Date(Math.max(Date.now(),...queue().map(r=>(Date.parse(r.createdAt)||0)+1))).toISOString(),id());
   if(queue().some(r=>r.id!==row.id&&M.phone(r.phone)===row.phone))throw Error('Esse WhatsApp já está na lista de espera. Edite o cadastro existente.');
   const next=previous?state.waitlist.map(r=>r.id===row.id?row:r):[...(state.waitlist||[]),row];
   if(!saveQueue(next)){$('wlFormError').textContent=$('wlStatus').textContent;return}closeDialog('waitlistEditor');status(previous?'Cadastro atualizado. A posição na fila foi mantida.':'Pessoa adicionada ao fim da fila.');
  }catch(error){$('wlFormError').textContent=error.message||'Não foi possível salvar.'}finally{busy=false}
 };
 $('wlQueue').onclick=function(event){
  const edit=event.target.closest('[data-wl-edit]');if(edit){openWaitlistEditor(edit.dataset.wlEdit);return}
  const remove=event.target.closest('[data-wl-remove]');if(!remove)return;
  const row=queue().find(r=>r.id===remove.dataset.wlRemove);if(!row)return;
  if(!confirm('Retirar '+row.name+' da lista de espera?'))return;
  if(saveQueue(state.waitlist.map(r=>r.id===row.id?{...r,status:'completed',removedAt:stamp(),updatedAt:stamp()}:r)))status(row.name+' foi retirado da fila.');
 };
 const originalRender=renderAll;renderAll=function(...args){const result=originalRender.apply(this,args);renderWaitlist();return result};
 const originalShow=showScreen;showScreen=function(...args){const result=originalShow.apply(this,args);if(['waitlist','today','week','availability'].includes(args[0]))renderWaitlist();return result};
 addEventListener('storage',event=>{if(event.key===DB_KEY&&!$('waitlistEditor').classList.contains('open'))refreshIfStale()});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!$('waitlistEditor').classList.contains('open')){if(!refreshIfStale())renderWaitlist()}});
 setInterval(()=>{if(!document.hidden&&currentScreen!=='waitlist'&&!$('waitlistEditor').classList.contains('open'))renderWaitlist()},60000);
 renderWaitlist();
})();
