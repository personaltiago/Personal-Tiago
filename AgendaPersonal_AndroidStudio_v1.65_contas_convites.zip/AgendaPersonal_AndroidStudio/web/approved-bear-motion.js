(function(global){
'use strict';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n)),smooth=(a,b,n)=>{n=clamp((n-a)/(b-a));return n*n*(3-2*n)};
function relief(p,q,rig,amount=1){
 const ex=(p[0]-135)/65,ey=(p[1]-75)/61;
 const edge=clamp(1-ex*ex-ey*ey),z=28*edge*edge*(3-2*edge)+9*Math.exp(-(((p[0]-145)/19)**2)-((p[1]-82)/14)**2)-8;
 if(Math.abs(rig[0])+Math.abs(rig[1])<1e-6)return{point:q.slice(),depth:z*amount};
 const a=rig[0]*amount,b=rig[1]*amount,x=q[0]-135,y=q[1]-105;
 const xx=Math.cos(a)*x+Math.sin(a)*z,zz=-Math.sin(a)*x+Math.cos(a)*z;
 const yy=Math.cos(b)*y-Math.sin(b)*zz,depth=Math.sin(b)*y+Math.cos(b)*zz;
 const k=(350-z)/(350-depth);
 return {point:[135+xx*k,105+yy*k],depth:depth*amount};
}
const glsl=`vec2 relief(vec2 p,vec2 q,vec2 rig,float h,out float depth,out float lighting){
vec2 e=(p-vec2(135.,75.))/vec2(65.,61.);float edge=clamp(1.-dot(e,e),0.,1.),z=28.*edge*edge*(3.-2.*edge)+9.*exp(-pow((p.x-145.)/19.,2.)-pow((p.y-82.)/14.,2.))-8.;
if(abs(rig.x)+abs(rig.y)<.000001){depth=z*h;lighting=1.;return q;}
float a=rig.x*h,b=rig.y*h,ca=cos(a),sa=sin(a),cb=cos(b),sb=sin(b);vec3 v=vec3(q-vec2(135.,105.),z);v=vec3(ca*v.x+sa*v.z,v.y,-sa*v.x+ca*v.z);v=vec3(v.x,cb*v.y-sb*v.z,sb*v.y+cb*v.z);float k=(350.-z)/(350.-v.z);depth=v.z*h;
float muzzle=exp(-pow((p.x-145.)/19.,2.)-pow((p.y-82.)/14.,2.));vec2 slope=336.*edge*(1.-edge)*(p-vec2(135.,75.))/vec2(4225.,3721.)+18.*muzzle*(p-vec2(145.,82.))/vec2(361.,196.);vec3 n=normalize(vec3(slope,1.)),n0=n;n=vec3(ca*n.x+sa*n.z,n.y,-sa*n.x+ca*n.z);n=vec3(n.x,cb*n.y-sb*n.z,sb*n.y+cb*n.z);vec3 light=normalize(vec3(-.4,-.65,.7));lighting=1.+.09*(dot(n,light)-dot(n0,light))*h;
return vec2(135.,105.)+v.xy*k;}`;
global.APMascotBearDepth=Object.freeze({relief,glsl,smooth});
})(globalThis);

(function(g){'use strict';
// Approved R14: aligned poses and bounded eye movement. Anger keeps the original arms.
const mounted=new WeakMap(),instances=new Set();let art=null,decoded=null;
const supports=s=>s?.species==='panda'&&g.APMascotModel.phase(s.xp).id==='adult'&&g.APMascotModel.color(s).id==='black'&&g.APMascotModel.pose(s).id==='sit';
function configure(v){art=v;decoded=null}
function grid(){const ref=[],indices=[];for(let y=0;y<=60;y++)for(let x=0;x<=60;x++)ref.push(x*4,y*4);for(let y=0;y<60;y++)for(let x=0;x<60;x++){let a=y*61+x;indices.push(a,a+61,a+1,a+1,a+61,a+62)}return{ref,affection:ref,paw:ref,indices}}
async function images(){return decoded||(decoded=Promise.all(Object.entries(art).map(async([k,src])=>{const i=new Image();i.src=src;await i.decode();return[k,i]})).then(Object.fromEntries).catch(e=>{decoded=null;throw e}))}
async function start(image,state,attention=false){if(attention?!g.APMascotBearAttention.supports(state):!supports(state)||!art)return null;let photos;if(attention){const i=new Image();i.src=image.getAttribute('href');await i.decode();photos=Object.fromEntries(['original','affection','paw','angry'].map(k=>[k,i]))}else photos=await images();if(!image.isConnected)return null;
const document=image.ownerDocument,host=image.closest('.ap-habitat'),ns='http://www.w3.org/2000/svg',holder=document.createElementNS(ns,'foreignObject');
for(const[k,v]of Object.entries({x:0,y:0,width:320,height:320,'pointer-events':'none'}))holder.setAttribute(k,v);holder.dataset.approvedBear=attention?'R14-attention':'R14';const canvas=document.createElementNS('http://www.w3.org/1999/xhtml','canvas');canvas.style.cssText='display:block;width:320px;height:320px;pointer-events:none';canvas.width=canvas.height=640;holder.append(canvas);
const mesh=grid(),gl=canvas.getContext('webgl',{alpha:true,premultipliedAlpha:true,antialias:false,preserveDrawingBuffer:true});if(!gl)return null;
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),smooth=x=>{x=clamp(x);return x*x*(3-2*x)},mix=(a,b,t)=>a+(b-a)*t;
try{
const feet=`float fixedHead(vec2 p){return smoothstep(78.,90.,p.x)*(1.-smoothstep(118.,132.,p.y));}
float poseSupport(vec2 p){vec2 d=p-vec2(92.,207.);vec2 q=vec2(.921061*d.x-.389418*d.y,.389418*d.x+.921061*d.y);float l=length(q/vec2(25.,31.)),r=length((p-vec2(204.,192.))/vec2(30.,31.));return (1.-smoothstep(198.,201.,p.y))*smoothstep(.97,1.06,l)*smoothstep(.97,1.06,r);}
float support(vec2 p){float a=length((p-vec2(92.,205.))/vec2(34.,34.)),b=length((p-vec2(204.,192.))/vec2(33.,32.));return (1.-smoothstep(157.,192.,p.y))*smoothstep(1.,1.26,a)*smoothstep(1.,1.26,b);}`;
const vertex=`attribute vec2 p;attribute vec2 aff;attribute vec2 paw;uniform vec2 weights;uniform vec4 motion;uniform vec2 detail;uniform float clock;uniform vec2 rig;varying float lighting;varying vec2 uv;varying vec2 affUV;varying vec2 pawUV;${feet}${g.APMascotBearDepth.glsl}
void main(){float free=support(p);vec2 q=p+((aff-p)*weights.x+(paw-p)*weights.y*.4)*free;
float chest=exp(-pow((p.x-122.)/64.,2.)-pow((p.y-139.)/42.,2.));chest*=1.-weights.y*fixedHead(p);float breath=sin(clock*1.58)*.7+(sin(clock*3.16+.6)-sin(.6))*.1;
q.x+=(p.x-122.)*.0033*breath*chest*free;q.y-=.34*breath*chest*free;
float h=(1.-smoothstep(102.,143.,p.y))*(1.-smoothstep(75.,102.,abs(p.x-135.)))*free*(1.-weights.y),depth=0.;q=relief(p,q,rig*(1.-.4*weights.x-.2*weights.y),h,depth,lighting);float a=motion.x*h;vec2 d=q-vec2(135.,130.);q=vec2(cos(a)*d.x-sin(a)*d.y,sin(a)*d.x+cos(a)*d.y)+vec2(135.,130.);q+=motion.yz*h;
float el=exp(-pow((p.x-99.)/18.,2.)-pow((p.y-34.)/18.,2.)),er=exp(-pow((p.x-184.)/16.,2.)-pow((p.y-49.)/17.,2.));q.y+=motion.w*(el-.75*er)*(1.-weights.y);q.x+=motion.w*.35*(el+er)*(1.-weights.y);
float nose=exp(-pow((p.x-145.)/15.,2.)-pow((p.y-82.)/11.,2.));q.y+=detail.x*nose*(1.-weights.y);
gl_Position=vec4(q.x/120.-1.,1.-q.y/120.,-depth/400.,1.);uv=p/240.;affUV=aff/240.;pawUV=paw/240.;}`;
const approvedFragment=`precision highp float;uniform sampler2D original;uniform sampler2D affection;uniform sampler2D reaction;uniform vec2 weights;uniform vec2 gaze;uniform float blink;uniform float anger;uniform float eyeFocus;uniform sampler2D grumpy;varying float lighting;varying vec2 uv;varying vec2 affUV;varying vec2 pawUV;${feet}
vec2 looking(vec2 p,vec2 a,vec2 b){vec2 d=(p-a)/vec2(12.,10.),e=(p-b)/vec2(10.,10.);float w=max(1.-smoothstep(.15,1.,length(d)),1.-smoothstep(.15,1.,length(e)));return (p-gaze*w*.85)/240.;}
float edgeDistance(vec2 p,vec2 a,vec2 b){vec2 d=b-a;return (d.x*(p.y-a.y)-d.y*(p.x-a.x))/length(d);}
float aperture0(vec2 p){float d=100.;d=min(d,edgeDistance(p,vec2(112.7,69.9),vec2(114.0,66.6)));d=min(d,edgeDistance(p,vec2(114.0,66.6),vec2(117.4,63.3)));d=min(d,edgeDistance(p,vec2(117.4,63.3),vec2(122.3,60.8)));d=min(d,edgeDistance(p,vec2(122.3,60.8),vec2(126.2,60.6)));d=min(d,edgeDistance(p,vec2(126.2,60.6),vec2(129.7,62.4)));d=min(d,edgeDistance(p,vec2(129.7,62.4),vec2(132.0,65.7)));d=min(d,edgeDistance(p,vec2(132.0,65.7),vec2(132.3,69.3)));d=min(d,edgeDistance(p,vec2(132.3,69.3),vec2(130.7,72.7)));d=min(d,edgeDistance(p,vec2(130.7,72.7),vec2(127.2,75.4)));d=min(d,edgeDistance(p,vec2(127.2,75.4),vec2(122.3,76.7)));d=min(d,edgeDistance(p,vec2(122.3,76.7),vec2(117.6,75.7)));d=min(d,edgeDistance(p,vec2(117.6,75.7),vec2(114.2,73.6)));d=min(d,edgeDistance(p,vec2(114.2,73.6),vec2(112.7,71.4)));d=min(d,edgeDistance(p,vec2(112.7,71.4),vec2(112.7,69.9)));return smoothstep(.05,.5,d);}
float aperture1(vec2 p){float d=100.;d=min(d,edgeDistance(p,vec2(152.5,79.0),vec2(154.1,75.6)));d=min(d,edgeDistance(p,vec2(154.1,75.6),vec2(157.6,72.6)));d=min(d,edgeDistance(p,vec2(157.6,72.6),vec2(160.5,72.2)));d=min(d,edgeDistance(p,vec2(160.5,72.2),vec2(162.3,72.3)));d=min(d,edgeDistance(p,vec2(162.3,72.3),vec2(164.02,72.7)));d=min(d,edgeDistance(p,vec2(164.02,72.7),vec2(165.93,73.9)));d=min(d,edgeDistance(p,vec2(165.93,73.9),vec2(167.46,75.4)));d=min(d,edgeDistance(p,vec2(167.46,75.4),vec2(168.42,77.1)));d=min(d,edgeDistance(p,vec2(168.42,77.1),vec2(169.15,79.0)));d=min(d,edgeDistance(p,vec2(169.15,79.0),vec2(169.6,81.0)));d=min(d,edgeDistance(p,vec2(169.6,81.0),vec2(169.6,82.8)));d=min(d,edgeDistance(p,vec2(169.6,82.8),vec2(169.25,84.5)));d=min(d,edgeDistance(p,vec2(169.25,84.5),vec2(168.9,85.3)));d=min(d,edgeDistance(p,vec2(168.9,85.3),vec2(168.15,86.9)));d=min(d,edgeDistance(p,vec2(168.15,86.9),vec2(167.5,87.6)));d=min(d,edgeDistance(p,vec2(167.5,87.6),vec2(166.6,88.6)));d=min(d,edgeDistance(p,vec2(166.6,88.6),vec2(165.75,89.0)));d=min(d,edgeDistance(p,vec2(165.75,89.0),vec2(164.98,89.2)));d=min(d,edgeDistance(p,vec2(164.98,89.2),vec2(162.1,89.2)));d=min(d,edgeDistance(p,vec2(162.1,89.2),vec2(160.0,88.4)));d=min(d,edgeDistance(p,vec2(160.0,88.4),vec2(158.7,88.1)));d=min(d,edgeDistance(p,vec2(158.7,88.1),vec2(155.8,85.3)));d=min(d,edgeDistance(p,vec2(155.8,85.3),vec2(153.6,82.4)));d=min(d,edgeDistance(p,vec2(153.6,82.4),vec2(152.5,79.0)));return smoothstep(-.2,.15,d);}
vec4 directedEye(vec4 base,vec2 p,vec2 c,vec2 r,vec2 ic,vec2 ir,vec2 whiteAt){
// Fixed eyelid aperture; translate only the painted iris/pupil within the globe.
if(eyeFocus<.0001)return base;
float mask=c.x<140.?aperture0(p):aperture1(p);if(mask<.0001)return base;
vec2 center=c.x<140.?vec2(122.5,69.):vec2(160.8,80.6);
vec2 irisCenter=c.x<140.?vec2(126.,69.5):vec2(159.4,80.3);
vec2 irisRadius=c.x<140.?vec2(7.6,7.5):vec2(6.6,7.3);
// The farther eye is narrower: cap its travel independently.
vec2 travel=c.x<140.?vec2(3.5,2.6):vec2(2.,1.7);
vec2 desired=center+gaze*travel;
// Travel back to the original iris center instead of dissolving between two pupils.
vec2 goal=mix(irisCenter,desired,eyeFocus);
vec2 displayRadius=c.x<140.?irisRadius:vec2(7.7,8.7);
vec2 compression=c.x<140.?vec2(.07,.045):vec2(.03,.025);
vec2 projectedRadius=displayRadius*(vec2(1.)-abs(gaze)*compression*eyeFocus);
vec2 d=(p-goal)/projectedRadius;
float inside=1.-smoothstep(.94,1.025,length(d));
// Keep the approved brown iris texture. The aperture now covers the actual sclera edge.
vec2 sampleRadius=irisRadius;
vec4 pupil=texture2D(original,(irisCenter+d*sampleRadius)/240.);
vec2 sampleAt=c.x<140.?vec2(114.8,70.):vec2(167.1,82.5);
vec4 white=texture2D(original,sampleAt/240.);
vec2 sphere=(p-center)/(c.x<140.?vec2(11.,8.5):vec2(8.5,10.));
white.rgb*=.80+.20*sqrt(max(0.,1.-dot(sphere,sphere)*.65));
// Soft lid shadow and mild foreshortening belong to the eyeball, never the fur.
pupil.rgb*=1.-.035*eyeFocus*abs(gaze.y)*(1.-smoothstep(-.9,-.1,sphere.y));
vec4 result=mix(white,pupil,inside);return mix(base,result,mask*smoothstep(0.,.025,eyeFocus));}
vec4 eye(vec4 color,vec2 p,vec2 c,vec2 r,vec2 cc,vec2 cr){
if(blink<.0001)return color;
vec2 center=c.x<140.?vec2(122.5,69.):vec2(160.8,80.6),radius=c.x<140.?vec2(15.,12.):vec2(12.,13.);
vec2 d=(p-center)/radius;float zone=1.-smoothstep(.78,1.1,length(d));
// Use the aligned closed-eye artwork through a rapid, soft exposure change.
// Never flatten the eye texture or cut a rectangular slit through the face.
float closure=smoothstep(.42,.68,blink);vec4 closed=texture2D(affection,uv);
return mix(color,closed,closure*zone);}

void main(){vec2 p=uv*240.;vec4 a=texture2D(original,uv);a=directedEye(a,p,vec2(125.,66.5),vec2(12.2,8.5),vec2(127.5,66.),vec2(8.5,8.5),vec2(116.,67.));a=directedEye(a,p,vec2(163.,77.5),vec2(9.,10.2),vec2(161.,77.),vec2(7.4,9.),vec2(168.,81.));a=eye(a,p,vec2(125.,66.5),vec2(17.,13.),vec2(122.,69.),vec2(17.,12.));a=eye(a,p,vec2(163.,77.5),vec2(14.,13.),vec2(161.,81.),vec2(14.,12.));vec4 b=texture2D(affection,affUV),c=texture2D(reaction,looking(pawUV*240.,vec2(125.,66.5),vec2(163.,77.5)));// A pose changes the arm and torso; the visible head keeps its original artwork.
float keepHead=smoothstep(92.,101.,p.x)*(1.-smoothstep(118.,132.,p.y));
c=mix(c,a,keepHead);vec2 w=vec2(weights.x*support(p),weights.y*poseSupport(p));vec4 color=a*(1.-w.x-w.y)+b*w.x+c*w.y;float face=1.-smoothstep(.88,1.06,length((p-vec2(144.,82.))/vec2(45.,40.)));vec4 grump=texture2D(grumpy,uv);color.rgb=mix(color.rgb,grump.rgb,anger*face*smoothstep(.8,.99,grump.a));if(color.a<.004)discard;color.rgb*=lighting;gl_FragColor=color;}`;
const fragment=attention?g.APMascotBearAttention.fragment(state):approvedFragment;
const gpuShaders=[],gpuBuffers=[],gpuTextures=[];function shader(type,src){const s=gl.createShader(type);gpuShaders.push(s);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vertex));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fragment));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('Shader link');gl.useProgram(program);
for(const[name,data]of [['p',mesh.ref],['aff',mesh.affection],['paw',mesh.paw]]){const b=gl.createBuffer();gpuBuffers.push(b);gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);const loc=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0)}
const buffer=gl.createBuffer();gpuBuffers.push(buffer);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,buffer);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(mesh.indices),gl.STATIC_DRAW);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);
for(const[i,k]of ['original','affection','paw','angry'].entries()){const t=gl.createTexture();gpuTextures.push(t);gl.activeTexture(gl.TEXTURE0+i);gl.bindTexture(gl.TEXTURE_2D,t);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);const upload=document.createElement('canvas');upload.width=upload.height=512;const uploadCtx=upload.getContext('2d');uploadCtx.imageSmoothingEnabled=true;uploadCtx.imageSmoothingQuality='high';uploadCtx.drawImage(photos[k],0,0,512,512);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,upload);gl.generateMipmap(gl.TEXTURE_2D);gl.uniform1i(gl.getUniformLocation(program,k==='paw'?'reaction':k==='angry'?'grumpy':k),i)}
const u=Object.fromEntries(['weights','motion','detail','clock','gaze','blink','rig','anger','eyeFocus'].map(k=>[k,gl.getUniformLocation(program,k)]));gl.clearColor(0,0,0,0);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.clearDepth(1);
class Spring{constructor(w){this.w=w;this.x=0;this.v=0}step(target,dt){const a=this.x-target,b=this.v+this.w*a,e=Math.exp(-this.w*dt);this.x=target+(a+b*dt)*e;this.v=(this.v-this.w*b*dt)*e;return this.x}reset(){this.x=this.v=0}}
const springs=Object.fromEntries([['focus',26],['angry',13],['aff',14],['paw',14],['angle',8],['x',8],['y',8],['ear',12],['gx',20],['gy',20],['yaw',8.5],['pitch',8.5],['nose',13],['wave',12]].map(([k,w])=>[k,new Spring(w)]));
const labels={angry:'Ei! Assim não…',idle:'Respiração e atenção ao redor',curious:'Curioso com o seu toque',nose:'Farejando o toque',ear:'Sentiu o toque na orelha',affection:'Acompanhando o carinho',paw:'Uma patinha para você',look:'Olhando onde você tocou'};
const reduced=g.matchMedia('(prefers-reduced-motion: reduce)');let clock=0,previous=0,kind='idle',began=0,aim={x:0,y:0},held=false,paused=false,demo=false,origin=performance.now(),lastDemo=-1,lastState=null,strokeStrength=0,targetScreen=null,anticipation=null;
function act(k,x=.65,y=.25,hold=false){if(!labels[k])return false;const elapsed=Math.max(0,(g.performance.now()-loopOrigin)/1000);if(elapsed>clock)clock=previous=elapsed;anticipation=null;targetScreen=null;kind=k;if(k==='angry')for(const name of ['aff','paw','angle','x','y','ear','yaw','pitch','nose','wave'])springs[name].reset();began=clock;aim={x:clamp(x,-1,1),y:clamp(y,-1,1)};held=hold;if(reduced.matches)redraw();return true}
function release(){if(kind==='affection'&&held){held=false;began=clock-1.4}}
function reset(t=0){clock=previous=t;kind='idle';began=t;held=false;lastDemo=-1;strokeStrength=0;for(const s of Object.values(springs))s.reset();lastState=null;targetScreen=null;anticipation=null}
const durations={curious:2.7,nose:1.6,ear:1.8,affection:2.6,paw:2.9,angry:2.8,look:3.2};
function draw(time){if(time<previous)reset(time);clock=time;const dt=clamp(time-previous,0,.1);previous=time;strokeStrength*=Math.exp(-dt*4);
if(targetScreen&&(kind==='look'||kind==='curious'))aim=aimAtScreen(targetScreen.x,targetScreen.y);

const age=time-began,duration=durations[kind]||Infinity,fixed=paused||reduced.matches;
if(!held&&age>duration){kind='idle';aim={x:0,y:0};}
const decay=held?1:kind==='idle'?0:1-smooth((age-duration+.75)/.75),target={focus:0,angry:0,aff:0,paw:0,angle:Math.sin(time*.52)*.003,x:0,y:-.12*Math.sin(time*1.58),ear:0,gx:0,gy:0,yaw:0,pitch:0,nose:0,wave:0};
if(kind==='curious'){target.angle=aim.x*.025*decay*smooth((age-.06)/.2);target.ear=.14*decay;}
if(kind==='ear'){target.ear=(aim.x>0?-.95:.95)*Math.sin(Math.min(age,1)*Math.PI)*decay;target.angle=aim.x*.012*decay;target.gx=aim.x*.6;target.gy=-.45*decay;target.yaw=aim.x*.05*decay;target.pitch=.045*decay;}
if(kind==='nose'){target.nose=.48*Math.sin(age*9)*Math.exp(-age*1.2);target.y-=.30*decay;target.gx=0;target.gy=.28;target.pitch=-.015*decay;}
if(kind==='look'){target.angle=aim.x*.025*decay*smooth((age-.06)/.2);}
if(kind==='affection'){target.aff=decay;target.angle=(.008*Math.sin(age*1.45)*(.45+.55*strokeStrength)+aim.x*.009)*decay;target.y=-.18*Math.sin(age*1.58);target.pitch=.055*decay;target.yaw=aim.x*.04*decay;target.ear=.22*decay;}
if(kind==='paw'){target.paw=decay;target.angle=0;target.y=0;target.gx=.2;target.gy=.1;}
if(kind==='angry'){target.paw=0;target.angry=decay;target.angle=0;target.y=0;}
if(kind==='curious'||kind==='look'){target.focus=1;target.gx=aim.x*.95*decay;target.gy=-aim.y*.95*decay;}
if(attention&&(kind==='ear'||kind==='nose'))target.focus=1;
if(anticipation){const a=aimAtScreen(anticipation.x,anticipation.y);target.focus=1;target.gx=a.x*.8;target.gy=-a.y*.8;}
for(const at of [3.35,11.2,18.5]){let d=(time%22)-at;if(d>0&&d<.7&&kind==='idle')target.ear+=.5*Math.sin(d/.7*Math.PI*2)*Math.sin(d/.7*Math.PI)}
springs.gx.w=springs.gy.w=(kind==='look'||kind==='curious'||anticipation)?36:20;
const v={};for(const[k,s]of Object.entries(springs))v[k]=fixed?0:s.step(target[k],dt);v.aff=clamp(v.aff);v.paw=clamp(v.paw);if(v.aff+v.paw>1){const sum=v.aff+v.paw;v.aff/=sum;v.paw/=sum}
if(reduced.matches&&kind==='angry'){v.angry=decay;v.paw=v.aff=0;}
let blink=0;if(!fixed){for(const at of [1.7,5.25,5.62,10.8,17.9,21.2]){const a=(time%22)-at;if(a>=0&&a<.24)blink=Math.max(blink,Math.sin(a/.24*Math.PI))}}
if(attention){blink=0}blink*=1-v.angry;
if(!fixed&&v.aff>.001)blink=Math.max(blink,smooth(v.aff/.36));
gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.uniform2f(u.rig,v.yaw,v.pitch);gl.uniform2f(u.weights,v.aff,v.paw);gl.uniform4f(u.motion,v.angle,v.x,v.y,v.ear);gl.uniform2f(u.detail,v.nose,v.wave);gl.uniform1f(u.clock,fixed?0:time);gl.uniform2f(u.gaze,v.gx,v.gy);gl.uniform1f(u.blink,blink);gl.uniform1f(u.anger,v.angry);gl.uniform1f(u.eyeFocus,v.focus);gl.drawElements(gl.TRIANGLES,mesh.indices.length,gl.UNSIGNED_SHORT,0);
lastState={kind,held,blink,eyeFocus:v.focus,anger:v.angry,weights:[v.aff,v.paw],motion:[v.angle,v.x,v.y,v.ear],gaze:[v.gx,v.gy],rig:[v.yaw,v.pitch],detail:[v.nose,v.wave],age};return lastState;
}

const masks={};for(const[k,im]of Object.entries(photos)){const c=document.createElement('canvas');c.width=c.height=240;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(im,0,0,240,240);masks[k]=ctx.getImageData(0,0,240,240).data}
function supportAt(x,y){const a=Math.hypot((x-92)/34,(y-205)/34),b=Math.hypot((x-204)/33,(y-192)/32);return(1-smooth((y-157)/35))*smooth((a-1)/.26)*smooth((b-1)/.26)}
function poseSupportAt(x,y){const dx=x-92,dy=y-207,l=Math.hypot((.921061*dx-.389418*dy)/25,(.389418*dx+.921061*dy)/31),r=Math.hypot((x-204)/30,(y-192)/31);return(1-smooth((y-198)/3))*smooth((l-.97)/.09)*smooth((r-.97)/.09)}
function atGrid(data,x,y){const sx=clamp(x/4,0,60),sy=clamp(y/4,0,60),ix=Math.min(59,Math.floor(sx)),iy=Math.min(59,Math.floor(sy)),a=(iy*61+ix)*2,fx=sx-ix,fy=sy-iy;return[0,1].map(k=>mix(mix(data[a+k],data[a+2+k],fx),mix(data[a+122+k],data[a+124+k],fx),fy))}
function project(p,s=lastState){
const w=s?.weights||[0,0],m=s?.motion||[0,0,0,0],de=s?.detail||[0,0],rig=s?.rig||[0,0],free=supportAt(...p),af=atGrid(mesh.affection,...p),pa=atGrid(mesh.paw,...p);let q=[p[0]+((af[0]-p[0])*w[0]+(pa[0]-p[0])*w[1]*.4)*free,p[1]+((af[1]-p[1])*w[0]+(pa[1]-p[1])*w[1]*.4)*free];
const headKeep=smooth((p[0]-78)/12)*(1-smooth((p[1]-118)/14)),chest=Math.exp(-(((p[0]-122)/64)**2)-((p[1]-139)/42)**2)*(1-w[1]*headKeep),t=paused||reduced.matches?0:clock,breath=Math.sin(t*1.58)*.7+(Math.sin(t*3.16+.6)-Math.sin(.6))*.1;q[0]+=(p[0]-122)*.0033*breath*chest*free;q[1]-=.34*breath*chest*free;
const h=(1-smooth((p[1]-102)/41))*(1-smooth((Math.abs(p[0]-135)-75)/27))*free*(1-w[1]);q=g.APMascotBearDepth.relief(p,q,rig.map(v=>v*(1-.4*w[0]-.2*w[1])),h).point;let a=m[0]*h,dx=q[0]-135,dy=q[1]-130;q=[135+Math.cos(a)*dx-Math.sin(a)*dy+m[1]*h,130+Math.sin(a)*dx+Math.cos(a)*dy+m[2]*h];
const el=Math.exp(-(((p[0]-99)/18)**2)-((p[1]-34)/18)**2),er=Math.exp(-(((p[0]-184)/16)**2)-((p[1]-49)/17)**2);q[1]+=m[3]*(el-.75*er)*(1-w[1]);q[0]+=m[3]*.35*(el+er)*(1-w[1]);q[1]+=de[0]*Math.exp(-(((p[0]-145)/15)**2)-((p[1]-82)/11)**2)*(1-w[1]);return q;
}
function aimAtScreen(clientX,clientY){const r=canvas.getBoundingClientRect(),c=project([144,72]),cx=r.left+(c[0])/240*r.width,cy=r.top+c[1]/240*r.height;return{x:clamp((clientX-cx)/(r.width*.36),-1,1),y:clamp((cy-clientY)/(r.height*.28),-1,1)}}
function actAtScreen(kind,x,y){const a=aimAtScreen(x,y);act(kind,a.x,a.y);targetScreen={x,y}}
function hit(ev){const r=canvas.getBoundingClientRect(),sx=(ev.clientX-r.left)/r.width,sy=(ev.clientY-r.top)/r.height;if(sx<0||sx>=1||sy<0||sy>=1)return null;const x=sx*240,y=sy*240,w=lastState?.weights||[0,0],a=w[0],p=w[1];let ref=[x,y];for(let i=0;i<6;i++){const q=project(ref);ref=[ref[0]-(q[0]-x),ref[1]-(q[1]-y)];}const sample=(m,q)=>{const xx=Math.round(q[0]),yy=Math.round(q[1]);return xx>=0&&xx<240&&yy>=0&&yy<240?m[(yy*240+xx)*4+3]:0};const free=supportAt(...ref),poseFree=poseSupportAt(...ref),keepHead=smooth((ref[0]-92)/9)*(1-smooth((ref[1]-118)/14)),pawAlpha=mix(sample(masks.paw,atGrid(mesh.paw,...ref)),sample(masks.original,ref),keepHead),alpha=sample(masks.original,ref)*(1-a*free-p*poseFree)+sample(masks.affection,atGrid(mesh.affection,...ref))*a*free+pawAlpha*p*poseFree;if(alpha<40)return null;const inside=(c,rx,ry)=>((x-c[0])/rx)**2+((y-c[1])/ry)**2<=1;const part=inside(project([145,82]),14,12)?'nose':inside(project([99,31]),19,24)||inside(project([184,49]),17,23)?'ear':'body';return{part,zone:attention?{x:ref[0]/240,y:ref[1]/240}:aimAtScreen(ev.clientX,ev.clientY),x:ref[0]/240,y:ref[1]/240}}


image.after(holder);const oldOpacity=image.getAttribute('opacity');image.setAttribute('opacity','0');let dead=false,raf=0,lastFrame=0;const loopOrigin=performance.now();
function dispose(){if(dead)return;dead=true;g.cancelAnimationFrame(raf);observer.disconnect();reduced.removeEventListener?.('change',redraw);canvas.removeEventListener('webglcontextlost',lost);holder.remove();if(oldOpacity===null)image.removeAttribute('opacity');else image.setAttribute('opacity',oldOpacity);for(const t of gpuTextures)gl.deleteTexture(t);for(const b of gpuBuffers)gl.deleteBuffer(b);gl.deleteProgram(program);for(const s of gpuShaders)gl.deleteShader(s);gl.getExtension('WEBGL_lose_context')?.loseContext();instances.delete(api);if(mounted.get(host)===api)mounted.delete(host)}
function redraw(){if(!dead){gl.viewport(0,0,canvas.width,canvas.height);draw(clock)}}
const observer=new g.ResizeObserver(()=>{const b=canvas.getBoundingClientRect(),size=Math.max(1,Math.min(1024,Math.round(b.width*Math.min(g.devicePixelRatio||1,2))));if(size!==canvas.width)canvas.width=canvas.height=size;redraw()});observer.observe(canvas);
const lost=e=>{e.preventDefault();dispose()};canvas.addEventListener('webglcontextlost',lost);reduced.addEventListener?.('change',redraw);
function tick(stamp){if(dead)return;if(!image.isConnected||!holder.isConnected){dispose();return}if(!g.document.hidden&&!document.hidden&&canvas.getBoundingClientRect().width>0&&(!reduced.matches||lastFrame===0||kind==='angry')&&stamp-lastFrame>=(kind==='idle'?32:15)){draw(Math.max(clock,(g.performance.now()-loopOrigin)/1000));lastFrame=stamp}raf=g.requestAnimationFrame(tick)}
const api={canvas,holder,image,alive:()=>!dead,state:()=>lastState,project,hit:(x,y)=>hit({clientX:x,clientY:y}),act,release,actAtScreen,aimAtScreen,dispose,draw};mounted.set(host,api);instances.add(api);redraw();raf=g.requestAnimationFrame(tick);return api;
}catch(_){holder.remove();gl.getExtension('WEBGL_lose_context')?.loseContext();return null}}

async function attention(image,state,kind,zone,reduced){const actor=await start(image,state,true);if(!actor)return null;
 const duration=(kind==='look'?3200:kind==='curious'?2700:kind==='ear'?1800:1600)+450;
 function aim(point){const p=point||{x:.75,y:.25},matrix=image.getScreenCTM();if(!matrix)return duration;const q=new DOMPoint(p.x*320,p.y*320).matrixTransform(matrix);actor.actAtScreen(kind,q.x,q.y);return duration}
 actor.holder.dataset.petLocalMotion=kind;actor.holder.dataset.petRenderer='approved-eyes';aim(zone);
 return {duration,root:actor.holder,actor,retarget:aim,dispose:actor.dispose};
}
g.APMascotBear=Object.freeze({supports,attentionSupports:s=>g.APMascotBearAttention.supports(s),attention,configure,start,portrait:s=>supports(s)?art?.original:null,asset:s=>supports(s)&&art?{uri:art.affection,headX:.60,headTop:.08}:null,get:n=>mounted.get(n),hit(n,x,y){return mounted.get(n)?.hit(x,y)},cancelAll(){for(const i of [...instances])i.dispose()}});
})(globalThis);
