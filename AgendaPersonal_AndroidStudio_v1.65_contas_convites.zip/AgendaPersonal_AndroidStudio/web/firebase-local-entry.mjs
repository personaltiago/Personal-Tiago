// Firebase 10.12.5, matching the existing persisted sessions and database keys.
import {initializeApp,getApps} from 'firebase/app';
import {initializeAuth,indexedDBLocalPersistence,browserLocalPersistence,browserSessionPersistence,setPersistence,onAuthStateChanged,signInWithEmailAndPassword,signOut,sendPasswordResetEmail,GoogleAuthProvider,signInWithCredential,signInWithPopup,browserPopupRedirectResolver} from 'firebase/auth';
import {getFirestore,doc,getDoc,onSnapshot,serverTimestamp,setDoc,collection,query,where,getDocs,updateDoc} from 'firebase/firestore';
function getAuth(app){
 // Restore the existing session without an OAuth iframe at cold start.
 // The browser popup resolver is supplied only after an explicit Google click.
 const original=globalThis.fetch,started=Date.now();let restoring=true;
 const bounded=function(input,options){
  const url=typeof input==='string'?input:input?.url||String(input);
  if(!restoring||!/^https:\/\/(?:identitytoolkit\.googleapis\.com\/v1\/accounts:lookup|securetoken\.googleapis\.com\/v1\/token)\?/.test(url))return original.call(this,input,options);
  // Only the initial read is bounded. Firebase itself decides whether a stored
  // authenticated session can remain available after a network failure.
  const controller=new AbortController(),signal=options?.signal;
  const abort=()=>controller.abort();if(signal?.aborted)abort();else signal?.addEventListener('abort',abort,{once:true});
  const timer=setTimeout(abort,Math.max(1,3000-(Date.now()-started)));
  return original.call(this,input,{...options,signal:controller.signal}).finally(()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort)});
 };
 globalThis.fetch=bounded;
 let auth;
 try{auth=initializeAuth(app,{persistence:[browserLocalPersistence,indexedDBLocalPersistence,browserSessionPersistence]})}
 catch(error){restoring=false;if(globalThis.fetch===bounded)globalThis.fetch=original;throw error}
 const done=()=>{restoring=false;if(globalThis.fetch===bounded)globalThis.fetch=original};
 auth.authStateReady().then(done,done);return auth;
}
window.APFirebaseLocal=Object.freeze({app:{initializeApp,getApps},auth:{getAuth,setPersistence,indexedDBLocalPersistence,browserLocalPersistence,browserSessionPersistence,onAuthStateChanged,signInWithEmailAndPassword,signOut,sendPasswordResetEmail,GoogleAuthProvider,signInWithCredential,signInWithPopup,browserPopupRedirectResolver},store:{getFirestore,doc,getDoc,onSnapshot,serverTimestamp,setDoc,collection,query,where,getDocs,updateDoc}});
