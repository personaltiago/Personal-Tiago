// Firebase 10.12.5, matching the existing persisted sessions and database keys.
import {initializeApp,getApps} from 'firebase/app';
import {initializeAuth,indexedDBLocalPersistence,browserLocalPersistence,browserSessionPersistence,onAuthStateChanged,signInWithEmailAndPassword,signOut,sendPasswordResetEmail} from 'firebase/auth';
import {getFirestore,doc,getDoc,onSnapshot,serverTimestamp,setDoc} from 'firebase/firestore';
function getAuth(app){
 // Email/password only: no OAuth popup/redirect iframe during a cold start.
 const original=globalThis.fetch,started=Date.now();let restoring=true;
 const bounded=function(input,options){
  const url=typeof input==='string'?input:input?.url||String(input);
  if(!restoring||!/^https:\/\/(?:identitytoolkit\.googleapis\.com\/v1\/accounts:lookup|securetoken\.googleapis\.com\/v1\/token)\?/.test(url))return original.call(this,input,options);
  // Only the initial read is bounded. Firebase itself decides whether a stored
  // authenticated session can remain available after a network failure.
  const controller=new AbortController(),signal=options?.signal;
  const abort=()=>controller.abort();if(signal?.aborted)abort();else signal?.addEventListener('abort',abort,{once:true});
  const timer=setTimeout(abort,Math.max(1,3000-(Date.now()-started)));
  return original.call(this,input,{...options,signal:controller.signal}).finally(()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort)});
 };
 globalThis.fetch=bounded;
 let auth;
 try{auth=initializeAuth(app,{persistence:[indexedDBLocalPersistence,browserLocalPersistence,browserSessionPersistence]})}
 catch(error){restoring=false;if(globalThis.fetch===bounded)globalThis.fetch=original;throw error}
 const done=()=>{restoring=false;if(globalThis.fetch===bounded)globalThis.fetch=original};
 auth.authStateReady().then(done,done);return auth;
}
window.APFirebaseLocal=Object.freeze({app:{initializeApp,getApps},auth:{getAuth,onAuthStateChanged,signInWithEmailAndPassword,signOut,sendPasswordResetEmail},store:{getFirestore,doc,getDoc,onSnapshot,serverTimestamp,setDoc}});
