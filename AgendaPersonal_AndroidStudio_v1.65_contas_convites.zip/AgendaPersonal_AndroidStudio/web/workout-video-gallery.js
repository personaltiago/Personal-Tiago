// Shared video links belong to the catalog; each student's prescription stays
// on the day exercise. Match exact normalized names/aliases, never substrings.
function workoutGalleryVideoTarget(ex,items=workoutCatalogItems()){
 const linked=items.find(item=>item.id===ex.catalogId&&workoutCatalogSameName(ex,item));
 if(linked?.source==='app')return linked;
 const app=items.filter(item=>item.source==='app'&&workoutCatalogSameName(ex,item));
 if(app.length===1)return app[0];
 if(linked)return linked;
 const mine=items.filter(item=>item.source==='mine'&&workoutCatalogSameName(ex,item));
 return mine.length===1?mine[0]:null;
}
function workoutGalleryNewVideoItem(ex){return {...ex,id:id(),source:'mine',muscles:[ex.muscle||''].filter(Boolean)}}
function workoutGalleryVideoChanges(ex){
 const target=workoutGalleryVideoTarget({...ex,catalogId:document.getElementById('workoutExerciseCatalogId').value});
 let catalog=state.exerciseCatalog,overrides=state.exerciseCatalogOverrides,selected;
 if(target?.source==='app'){
  selected=target.id;overrides={...overrides,[selected]:{...overrides[selected],video:ex.video}};
 }else if(target){
  selected=target.id;catalog=catalog.map(item=>item.id===selected?{...item,video:ex.video}:item);
 }else{
  const item=workoutGalleryNewVideoItem(ex);selected=item.id;catalog=[...catalog,item];
 }
 const favorite=document.getElementById('workoutExerciseFavorite').checked;
 const favorites=favorite?[...new Set([...state.exerciseFavorites,selected])]:state.exerciseFavorites.filter(key=>key!==selected);
 return {catalogId:selected,changes:{exerciseCatalog:catalog,exerciseCatalogOverrides:overrides,exerciseFavorites:favorites}};
}
function recoverWorkoutGalleryVideos(){
 if(state.exerciseVideoGalleryMigration===1)return;
 const items=workoutCatalogItems(),groups=new Map();
 for(const plan of state.workoutPlans)for(const day of plan.days)for(const ex of day.exercises){
  if(!workoutCatalogHasVideo(ex))continue;
  const target=workoutGalleryVideoTarget(ex,items);
  const key=target?'id:'+target.id:'name:'+JSON.stringify([workoutSearchKey(ex.name),ex.muscle||'',ex.category||'']);
  if(!groups.has(key))groups.set(key,{target,ex,videos:new Map()});
  const video=normalizedWorkoutVideoUrl(ex.video),youtube=workoutYouTubeVideo(video);
  groups.get(key).videos.set(youtube?youtube.videoId+':'+youtube.startSeconds:video,video);
 }
 let catalog=state.exerciseCatalog,overrides=state.exerciseCatalogOverrides,count=0;
 for(const group of groups.values()){
  // Existing gallery choices win during recovery. Conflicting old links are
  // left alone; an explicit future save chooses the desired demonstration.
  if(group.videos.size!==1||group.target&&workoutCatalogHasVideo(group.target))continue;
  const video=group.videos.values().next().value,target=group.target;
  if(target?.source==='app'&&Object.prototype.hasOwnProperty.call(overrides[target.id]||{},'video'))continue;
  if(target?.source==='app')overrides={...overrides,[target.id]:{...overrides[target.id],video}};
  else if(target)catalog=catalog.map(item=>item.id===target.id?{...item,video}:item);
  else catalog=[...catalog,workoutGalleryNewVideoItem({...group.ex,video})];
  count++;
 }
 return commitWorkoutChange({exerciseCatalog:catalog,exerciseCatalogOverrides:overrides,exerciseVideoGalleryMigration:1},count?'Vídeos dos treinos recuperados na galeria · '+count:'',false);
}
