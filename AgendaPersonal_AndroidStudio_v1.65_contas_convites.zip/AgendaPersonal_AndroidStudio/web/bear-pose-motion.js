(function(g){'use strict';
// Pose-local bear rig. The R14 seated black adult remains in its approved engine.
const ns='http://www.w3.org/2000/svg',clamp=(n,a=-1,b=1)=>Math.max(a,Math.min(b,n)),smooth=(a,b,n)=>{n=clamp((n-a)/(b-a),0,1);return n*n*(3-2*n)},mix=(a,b,t)=>a+(b-a)*t;
const data=g.APMascotBearPoseProfiles,styles={default:{tilt:.024,nod:1.1,ear:.65,sniff:.60,recoil:1.15},sit:{tilt:.030,nod:1.35,ear:.75,sniff:.55,recoil:.95},rest:{tilt:.018,nod:.75,ear:.50,sniff:.40,recoil:.55}};
function profile(s){const pose=g.APMascotModel.pose(s).id,age=g.APMascotModel.phase(s.xp).id,color=g.APMascotModel.color(s).id,v=data.poses[pose+':'+age+':'+color];if(!v)return null;return{pose,age,color,eyes:[v.slice(0,4),v.slice(4,8)],nose:v.slice(8,10),mouth:v.slice(10,12),head:v.slice(12,17),style:styles[pose],ears:g.APMascotHitAreas.zones(s).filter(z=>z.part==='ear')}}
const supports=s=>s?.species==='panda'&&!g.APMascotBear?.supports(s)&&!!profile(s);
const protectedPaws={default:[],sit:[[123,231,47,31],[232,231,45,31]],rest:[[101,213,58,41],[268,240,41,56]]};
function weight(x,y,p){const[cx,cy,rx,ry,neck]=p.head;let w=(1-smooth(.80,1.2,Math.abs((x-cx)/rx)))*(1-smooth(cy+ry*.20,neck,y));for(const[a,b,c,d]of protectedPaws[p.pose])w*=smooth(.95,1.24,Math.hypot((x-a)/c,(y-b)/d));return w}
function project(x,y,p,v){const[cx,cy,,,neck]=p.head,w=weight(x,y,p),a=v.angle*w,dx=x-cx,dy=y-neck;if(w===0)return[x,y];let xx=cx+dx*Math.cos(a)-dy*Math.sin(a),yy=neck+dx*Math.sin(a)+dy*Math.cos(a)+v.nod*w;
 // Ears are local to the head and are never tied to a limb.
 const ears=p.ears;
 for(let i=0;i<ears.length;i++){const e=ears[i],f=Math.exp(-(((x-e.x*320)/22)**2)-((y-e.y*320)/21)**2)*w;yy+=v.ear*f*(i?-.65:1)}
 const n=Math.exp(-(((x-p.nose[0])/17)**2)-((y-p.nose[1])/12)**2)*w;yy+=v.sniff*n;return[xx,yy]}
const durations={affection:2200,look:3000,curious:2500,ear:1450,nose:1550,paw:2350,tail:2350,angry:2350};
function values(p,kind,t,aim={x:0,y:0},held=false,reduced=false){const age=Math.max(0,t),duration=durations[kind]||2200,end=duration/1000,enter=smooth(0,.25,age),leave=held?1:1-smooth(end-.5,end,age),e=enter*leave,st=p.style,protest=['paw','tail','angry'].includes(kind),v={angle:0,nod:0,ear:0,sniff:0,gx:0,gy:0,aff:0,angry:0};
 if(kind==='look'||kind==='curious'){const head=smooth(.11,.52,age)*leave;v.gx=aim.x*smooth(0,.11,age)*leave;v.gy=aim.y*smooth(0,.11,age)*leave;v.angle=st.tilt*(kind==='curious'?(aim.x>=0?1:-1):aim.x*.55)*head;v.nod=-st.nod*.24*head;}
 if(kind==='affection'){v.aff=e;v.angle=st.tilt*.30*Math.sin(age*1.7)*e;v.nod=-st.nod*.60*e+Math.sin(age*1.9)*st.nod*.12*e;v.ear=st.ear*.15*e;}
 if(kind==='ear'){v.ear=st.ear*Math.sin(age*10)*Math.exp(-age*3)*enter*leave;v.gx=aim.x*.6*e;v.gy=-.35*e;v.angle=st.tilt*.3*e;}
 if(kind==='nose'){v.sniff=st.sniff*Math.sin(age*11)*Math.exp(-age*2)*enter*leave;v.nod=-st.nod*.25*e;v.gy=.20*e;}
 if(protest){v.angry=e;}
 if(reduced){v.angle=v.nod=v.ear=v.sniff=v.gx=v.gy=0;v.aff=kind==='affection'?1:0;v.angry=protest?1:0}return v}
function grid(n){const points=[],indices=[];for(let y=0;y<=n;y++)for(let x=0;x<=n;x++)points.push(x*320/n,y*320/n);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const a=y*(n+1)+x;indices.push(a,a+n+1,a+1,a+1,a+n+1,a+n+2)}return{points:new Float32Array(points),indices:new Uint16Array(indices)}}
const mesh=grid(40),fallbackMesh=grid(16);
async function photo(uri){const i=new g.Image();i.src=uri;await i.decode();return i}
function canvas(doc){const c=doc.createElement('canvas');c.width=c.height=320;return c}
function filled(doc,original,holes){
 const out=canvas(doc),ctx=out.getContext('2d');ctx.drawImage(original,0,0,320,320);const pixels=ctx.getImageData(0,0,320,320),source=pixels.data;
 for(const[x,y,rx,ry]of holes){const x0=Math.max(1,Math.floor(x-rx-2)),y0=Math.max(1,Math.floor(y-ry-2)),x1=Math.min(319,Math.ceil(x+rx+2)),y1=Math.min(319,Math.ceil(y+ry+2)),w=x1-x0,h=y1-y0,mask=new Uint8Array(w*h),field=new Float32Array(w*h*3),next=new Float32Array(w*h*3),mean=[0,0,0];let count=0;
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){const d=Math.hypot((x0+i-x)/rx,(y0+j-y)/ry),a=j*w+i,b=((y0+j)*320+x0+i)*4;mask[a]=d<1?1:0;for(let k=0;k<3;k++){field[a*3+k]=source[b+k];if(d>=1&&d<1.2){mean[k]+=source[b+k]}}if(d>=1&&d<1.2)count++}
  for(let i=0;i<mask.length;i++)if(mask[i])for(let k=0;k<3;k++)field[i*3+k]=mean[k]/Math.max(1,count);
  for(let turn=0;turn<90;turn++){next.set(field);for(let j=1;j<h-1;j++)for(let i=1;i<w-1;i++){const a=j*w+i;if(!mask[a])continue;for(let k=0;k<3;k++)next[a*3+k]=(field[(a-1)*3+k]+field[(a+1)*3+k]+field[(a-w)*3+k]+field[(a+w)*3+k])*.25}field.set(next)}
  for(let j=0;j<h;j++)for(let i=0;i<w;i++){const a=j*w+i;if(!mask[a])continue;const b=((y0+j)*320+x0+i)*4,t=1-smooth(.84,1,Math.hypot((x0+i-x)/rx,(y0+j-y)/ry));for(let k=0;k<3;k++)source[b+k]=mix(source[b+k],field[a*3+k],t)}
 }ctx.putImageData(pixels,0,0);return out;
}
function emotion(doc,original,p,kind){
 const holes=p.eyes.map(([x,y,rx,ry])=>[x,y,rx*1.08,ry*1.08]),closed=filled(doc,original,holes),out=canvas(doc),ctx=out.getContext('2d');ctx.drawImage(kind==='affection'?closed:original,0,0,320,320);ctx.lineCap='round';ctx.lineJoin='round';
 function line(draw,width=1.8){ctx.beginPath();draw(ctx);ctx.strokeStyle='#241d1c';ctx.lineWidth=width;ctx.shadowBlur=.8;ctx.shadowColor='#08060460';ctx.stroke();ctx.shadowBlur=0}
 if(kind==='affection'){for(const[x,y,rx,ry]of p.eyes)line(c=>{c.moveTo(x-rx*.66,y+ry*.05);c.quadraticCurveTo(x,y-ry*.28,x+rx*.66,y+ry*.05)},Math.max(1.6,rx*.13))}
 else{
  p.eyes.forEach(([x,y,rx,ry],i)=>{const slope=i?-.40:.40,left=y-ry*.38-slope*ry,right=y-ry*.38+slope*ry;ctx.save();ctx.beginPath();ctx.moveTo(x-rx*1.6,y-ry*1.7);ctx.lineTo(x+rx*1.6,y-ry*1.7);ctx.lineTo(x+rx*1.6,right);ctx.quadraticCurveTo(x,y-ry*.25,x-rx*1.6,left);ctx.closePath();ctx.clip();ctx.drawImage(closed,0,0);ctx.restore();line(c=>{c.moveTo(x-rx*1.1,left);c.quadraticCurveTo(x,y-ry*.25,x+rx*1.1,right)},Math.max(2,rx*.17))});
  const[mx,my]=p.mouth,rx=Math.max(17,p.eyes[0][2]*1.55),ry=Math.max(12,p.eyes[0][3]*.87),mouth=filled(doc,original,[[mx,my+1,rx,ry]]);ctx.save();ctx.beginPath();ctx.ellipse(mx,my+1,rx,ry,0,0,Math.PI*2);ctx.clip();ctx.drawImage(mouth,0,0);ctx.restore();line(c=>{c.moveTo(mx-rx*.55,my+3);c.quadraticCurveTo(mx,my-7,mx+rx*.55,my+3)},1.7);
 }
 return out;
}
function gpu(c,textures,p){const gl=c.getContext('webgl',{alpha:true,premultipliedAlpha:true,antialias:false,preserveDrawingBuffer:true,depth:false,stencil:false});if(!gl)return null;const shaders=[],buffers=[],photos=[];let program;
 const dispose=()=>{for(const t of photos)gl.deleteTexture(t);for(const b of buffers)gl.deleteBuffer(b);if(program)gl.deleteProgram(program);for(const s of shaders)gl.deleteShader(s);gl.getExtension('WEBGL_lose_context')?.loseContext()};
 try{const shader=(kind,src)=>{const s=gl.createShader(kind);shaders.push(s);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error('bear shader');return s};
  program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,'attribute vec2 p;attribute vec2 q;varying vec2 uv;void main(){uv=p/320.;gl_Position=vec4(q.x/160.-1.,1.-q.y/160.,0.,1.);}'));
  gl.attachShader(program,shader(gl.FRAGMENT_SHADER,`precision highp float;uniform sampler2D original;uniform sampler2D affection;uniform sampler2D angry;uniform vec2 emotion;uniform vec2 gaze;uniform vec4 eye0;uniform vec4 eye1;varying vec2 uv;
  void main(){vec2 p=uv*320.,look=vec2(0.);float a=1.-smoothstep(.28,1.,length((p-eye0.xy)/eye0.zw)),b=1.-smoothstep(.28,1.,length((p-eye1.xy)/eye1.zw));look=gaze*vec2(1.5,1.05)*max(a,b);vec4 color=texture2D(original,(p-look)/320.);color=mix(color,texture2D(affection,uv),emotion.x);color=mix(color,texture2D(angry,uv),emotion.y);gl_FragColor=color;}`));
  gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('bear program');gl.useProgram(program);
  function attribute(name,array,usage){const b=gl.createBuffer();buffers.push(b);gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,array,usage);const a=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);return b}
  attribute('p',mesh.points,gl.STATIC_DRAW);const moving=attribute('q',mesh.points,gl.DYNAMIC_DRAW),index=gl.createBuffer();buffers.push(index);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,index);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,mesh.indices,gl.STATIC_DRAW);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);
  for(let i=0;i<textures.length;i++){const t=gl.createTexture();photos.push(t);gl.activeTexture(gl.TEXTURE0+i);gl.bindTexture(gl.TEXTURE_2D,t);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,textures[i]);gl.uniform1i(gl.getUniformLocation(program,['original','affection','angry'][i]),i)}
  for(let i=0;i<2;i++)gl.uniform4f(gl.getUniformLocation(program,'eye'+i),...p.eyes[i]);const u=gl.getUniformLocation(program,'emotion'),gaze=gl.getUniformLocation(program,'gaze'),points=new Float32Array(mesh.points.length);gl.clearColor(0,0,0,0);
  return{kind:'webgl',dispose,draw(v){if(gl.isContextLost())throw Error('bear context');for(let i=0;i<points.length;i+=2){const q=project(mesh.points[i],mesh.points[i+1],p,v);points[i]=q[0];points[i+1]=q[1]}gl.viewport(0,0,c.width,c.height);gl.bindBuffer(gl.ARRAY_BUFFER,moving);gl.bufferSubData(gl.ARRAY_BUFFER,0,points);gl.uniform2f(u,v.aff,v.angry);gl.uniform2f(gaze,v.gx,v.gy);gl.clear(gl.COLOR_BUFFER_BIT);gl.drawElements(gl.TRIANGLES,mesh.indices.length,gl.UNSIGNED_SHORT,0)}};
 }catch(error){c.parentNode?.setAttribute('data-pet-gpu-fallback',String(error.message).slice(0,180));dispose();return null}}
function cpu(c,textures,p,doc){const ctx=c.getContext('2d'),surface=canvas(doc),s=surface.getContext('2d'),{points,indices}=fallbackMesh;if(!ctx)return null;const base=canvas(doc);base.getContext('2d').drawImage(textures[0],0,0);const pixels=base.getContext('2d').getImageData(0,0,320,320);
 return{kind:'canvas',dispose(){c.width=0},draw(v){s.clearRect(0,0,320,320);s.drawImage(base,0,0);if(v.gx||v.gy){const copy=new ImageData(new Uint8ClampedArray(pixels.data),320,320);for(const[x,y,rx,ry]of p.eyes)for(let j=Math.max(0,Math.floor(y-ry));j<Math.min(320,y+ry);j++)for(let i=Math.max(0,Math.floor(x-rx));i<Math.min(320,x+rx);i++){const w=1-smooth(.28,1,Math.hypot((i-x)/rx,(j-y)/ry)),xx=clamp(Math.round(i-v.gx*1.5*w),0,319),yy=clamp(Math.round(j-v.gy*1.05*w),0,319),a=(j*320+i)*4,b=(yy*320+xx)*4;for(let k=0;k<4;k++)copy.data[a+k]=pixels.data[b+k]}s.putImageData(copy,0,0)}for(const[i,alpha]of [[1,v.aff],[2,v.angry]]){s.globalAlpha=alpha;s.drawImage(textures[i],0,0)}s.globalAlpha=1;
  ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,c.width,c.height);ctx.scale(c.width/320,c.height/320);const moved=[];for(let i=0;i<points.length;i+=2)moved.push(project(points[i],points[i+1],p,v));for(let i=0;i<indices.length;i+=3){const ids=[indices[i],indices[i+1],indices[i+2]],src=ids.map(j=>[points[j*2],points[j*2+1]]),dst=ids.map(j=>moved[j]),[a,b,d]=src,[e,f,h]=dst,det=(b[0]-a[0])*(d[1]-a[1])-(d[0]-a[0])*(b[1]-a[1]),A=((f[0]-e[0])*(d[1]-a[1])-(h[0]-e[0])*(b[1]-a[1]))/det,B=((f[1]-e[1])*(d[1]-a[1])-(h[1]-e[1])*(b[1]-a[1]))/det,C=((h[0]-e[0])*(b[0]-a[0])-(f[0]-e[0])*(d[0]-a[0]))/det,D=((h[1]-e[1])*(b[0]-a[0])-(f[1]-e[1])*(d[0]-a[0]))/det;ctx.save();ctx.beginPath();const cx=(e[0]+f[0]+h[0])/3,cy=(e[1]+f[1]+h[1])/3;dst.forEach(([x,y],j)=>{const dist=Math.hypot(x-cx,y-cy)||1;ctx[j?'lineTo':'moveTo'](x+(x-cx)/dist*.25,y+(y-cy)/dist*.25)});ctx.closePath();ctx.clip();ctx.transform(A,B,C,D,e[0]-A*a[0]-C*a[1],e[1]-B*a[0]-D*a[1]);ctx.drawImage(surface,0,0);ctx.restore()}}}}
async function start(image,state,kind,zone,reduced=false,hold=false){const p=profile(state);if(!p||!supports(state))return null;const original=await photo(image.getAttribute('href'));if(!image.isConnected)return null;
 const doc=image.ownerDocument,base=canvas(doc);base.getContext('2d').drawImage(original,0,0,320,320);const textures=[base,kind==='affection'?emotion(doc,original,p,'affection'):base,['paw','tail','angry'].includes(kind)?emotion(doc,original,p,'angry'):base];
 const holder=doc.createElementNS(ns,'foreignObject');for(const[k,v]of Object.entries({x:0,y:0,width:320,height:320,'pointer-events':'none'}))holder.setAttribute(k,v);if(image.hasAttribute('transform'))holder.setAttribute('transform',image.getAttribute('transform'));holder.dataset.petLocalMotion=kind;holder.dataset.bearPose=p.pose;
 const fresh=()=>{const c=doc.createElementNS('http://www.w3.org/1999/xhtml','canvas');c.width=c.height=640;c.style.cssText='display:block;width:320px;height:320px;pointer-events:none';holder.replaceChildren(c);return c};let c=fresh(),renderer=gpu(c,textures,p);if(!renderer){c=fresh();renderer=cpu(c,textures,p,doc)}if(!renderer)return null;holder.dataset.petRenderer=renderer.kind;
 let raf=0,dead=false,began=g.performance.now(),held=kind==='affection'&&hold,last=0,aim={x:0,y:0},from=null,change=began,lastValue=null;const zero=values(p,'idle',0),opacity=image.getAttribute('opacity');
 function target(point){point=point||{x:p.nose[0]/320+.25,y:p.nose[1]/320-.25};return{x:clamp((point.x*320-p.nose[0])/115),y:clamp((point.y*320-p.nose[1])/100)}}
 function sample(at){let v=values(p,kind,(at-began)/1000,aim,held,reduced);if(from){const t=smooth(0,140,at-change);for(const k of Object.keys(v))v[k]=mix(from[k],v[k],t);if(t===1)from=null}return v}
 function draw(at){lastValue=sample(at);try{renderer.draw(lastValue)}catch(_){renderer.dispose();c=fresh();renderer=cpu(c,textures,p,doc);if(renderer){holder.dataset.petRenderer='canvas';renderer.draw(lastValue)}else dispose()}}
 function tick(at){if(dead)return;if(!image.isConnected||!holder.isConnected){dispose();return}if(!doc.hidden&&at-last>=(renderer.kind==='canvas'?60:30)){draw(at);last=at}raf=g.requestAnimationFrame(tick)}
 function retarget(point){const at=g.performance.now();from=sample(at);change=at;aim=target(point);began=at;return durations[kind]||2200}
 function release(){const at=g.performance.now();from=sample(at);change=at;held=false;began=at-((durations[kind]||2200)-500);return 550}
 function dispose(){if(dead)return;dead=true;g.cancelAnimationFrame(raf);renderer?.dispose();holder.remove();if(opacity===null)image.removeAttribute('opacity');else image.setAttribute('opacity',opacity)}
 aim=target(zone);image.after(holder);image.setAttribute('opacity','0');draw(began);if(!reduced)raf=g.requestAnimationFrame(tick);
 return{duration:durations[kind]||2200,root:holder,profile:p,retarget,hold(){const at=g.performance.now();from=sample(at);change=at;held=true},release,dispose,alive:()=>!dead,state:()=>lastValue,project:(x,y)=>project(x,y,p,lastValue||zero),draw(ms){g.cancelAnimationFrame(raf);draw(began+ms)}};
}
g.APMascotBearPoses=Object.freeze({supports,profile,values,project,weight,start,styles});
})(globalThis);
