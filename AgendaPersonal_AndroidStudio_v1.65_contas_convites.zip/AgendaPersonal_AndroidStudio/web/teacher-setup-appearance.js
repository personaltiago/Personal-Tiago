const SETUP_THEME='agendaPersonalTL_theme_v1',SETUP_DESIGN='agendaPersonalTL_design_v1',SETUP_BACKGROUNDS='agendaPersonalTL_appearance_backgrounds_v1';
const SETUP_FINISH='agendaPersonalTL_icon_finish_v1';
function loadSetupFinish(){const saved=setupJSON(SETUP_FINISH);return saved?.version===1&&saved.id==='matte'?'matte':'theme'}
let setupFinish=loadSetupFinish();
function loadSetupCards(){const saved=setupJSON(SETUP_FINISH);return saved?.version===1&&saved.cards==='colored'?'colored':'theme'}
let setupCards=loadSetupCards();
const SETUP_TEXT='agendaPersonalTL_teacher_text_v1',setupTextSizes={normal:1,large:1.125,xlarge:1.25};
function loadSetupText(){const saved=setupJSON(SETUP_TEXT);return saved?.version===1&&Object.hasOwn(setupTextSizes,saved.id)?saved.id:'normal'}
let setupText=loadSetupText();
const setupDesigns={atual:'current',neon:'neon-tl',metal:'metal-tl',performance:'pro-tl',deep:'deep-tl'};
const setupProperties={'neon-tl':'neonColors','metal-tl':'metalColors','pro-tl':'proColors','deep-tl':'deepColors'};
function setupJSON(key){try{return JSON.parse(localStorage.getItem(key)||'null')}catch(_){return null}}
function setupValid(p){return p&&[p.primary,p.secondary,p.background].every(isHex)}
function readConfig(){
 const cfg=readBrandConfig();if(!cfg)return cfg;
 const design=setupJSON(SETUP_DESIGN),theme=setupJSON(SETUP_THEME);
 const active=design?.version===1&&Object.values(setupDesigns).includes(design.id)?design.id:'current';
 const colors=active==='current'?theme:design[setupProperties[active]];
 return setupValid(colors)?{...cfg,main:colors.primary,support:colors.secondary,bg:colors.background,design:Object.keys(setupDesigns).find(k=>setupDesigns[k]===active)||'atual'}:cfg;
}
function loadSetupBackgrounds(){const data=setupJSON(SETUP_BACKGROUNDS);return data?.version===1&&data.designs&&typeof data.designs==='object'?data:{version:1,designs:{}}}
let setupBackgrounds=loadSetupBackgrounds();
function setupLuminance(hex){return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255).reduce((sum,n,i)=>sum+[.2126,.7152,.0722][i]*(n<=.04045?n/12.92:((n+.055)/1.055)**2.4),0)}
function setupMode(){return setupLuminance(currentConfig.bg)>.35?'light':'dark'}
function setupAccent(background=setupMode()==='light'?'#efe8f6':'#30223c'){
 const light=setupLuminance(background)>.35;let color=currentConfig.main;
 const contrast=(a,b)=>(Math.max(setupLuminance(a),setupLuminance(b))+.05)/(Math.min(setupLuminance(a),setupLuminance(b))+.05);
 for(let i=0;i<36&&contrast(color,background)<4.75;i++){color='#'+[1,3,5].map(j=>Math.round(parseInt(color.slice(j,j+2),16)*.9+(light?0:255)*.1).toString(16).padStart(2,'0')).join('')}
 return color;
}
function refreshSetupAppearance(){
 const mode=setupMode();root.dataset.appearance=mode;root.style.colorScheme=mode;root.style.setProperty('--aps-action',setupAccent('#ffffff'));
 root.querySelectorAll('[data-setup-mode]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.setupMode===mode)));
 root.querySelectorAll('[data-setup-finish]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.setupFinish===setupFinish)));
 root.querySelectorAll('[data-setup-cards]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.setupCards===setupCards)));
 root.style.setProperty('--ap-ts',setupTextSizes[setupText]);
 root.querySelectorAll('[data-setup-text]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.setupText===setupText)));
}
function chooseSetupMode(target){
 const current=setupMode();if(current===target)return;
 const design=setupDesigns[currentConfig.design]||'current',saved=setupBackgrounds.designs[design]||{};
 setupBackgrounds.designs[design]={...saved,[current]:currentConfig.bg};
 let next=saved[target];if(!isHex(next)||(setupLuminance(next)>.35?'light':'dark')!==target)next=target==='light'?'#f6f5f9':'#0d0e12';
 currentConfig.bg=next;updateInputs();preview();$('apsStatus').textContent=target==='light'?'Modo claro selecionado. Salve para aplicar.':'Modo escuro selecionado. Salve para aplicar.';
}
function persistSetupAppearance(){
 const design=setupDesigns[currentConfig.design]||'current',oldDesign=setupJSON(SETUP_DESIGN)||{};
 const palette={version:1,id:'custom',name:'Minha marca',primary:currentConfig.main,secondary:currentConfig.support,background:currentConfig.bg};
 const nextDesign={...oldDesign,version:1,id:design};if(design!=='current')nextDesign[setupProperties[design]]=palette;
 const finish={version:1,id:setupFinish};if(setupCards==='colored'||Object.hasOwn(setupJSON(SETUP_FINISH)||{},'cards'))finish.cards=setupCards;
 const writes=[[SETUP_THEME,design==='current'?palette:setupJSON(SETUP_THEME)],[SETUP_DESIGN,nextDesign],[SETUP_BACKGROUNDS,setupBackgrounds],[SETUP_FINISH,finish],[SETUP_TEXT,{version:1,id:setupText}],[KEY,currentConfig]].filter(([,v])=>v!==null);
 const previous=writes.map(([key])=>[key,localStorage.getItem(key)]);
 try{for(const [key,value]of writes)localStorage.setItem(key,JSON.stringify(value))}
 catch(error){for(const [key,value]of previous){try{if(value===null)localStorage.removeItem(key);else localStorage.setItem(key,value)}catch(_){}}throw error}
}
root.querySelectorAll('[data-setup-mode]').forEach(button=>button.addEventListener('click',()=>chooseSetupMode(button.dataset.setupMode)));
root.querySelectorAll('[data-setup-finish]').forEach(button=>button.addEventListener('click',()=>{setupFinish=button.dataset.setupFinish;refreshSetupAppearance();$('apsStatus').textContent='Acabamento dos ícones selecionado. Salve para aplicar.'}));
root.querySelectorAll('[data-setup-cards]').forEach(button=>button.addEventListener('click',()=>{setupCards=button.dataset.setupCards;refreshSetupAppearance();$('apsStatus').textContent='Cor dos cartões selecionada. Salve para aplicar.'}));
root.querySelectorAll('[data-setup-text]').forEach(button=>button.addEventListener('click',()=>{setupText=button.dataset.setupText;refreshSetupAppearance();$('apsStatus').textContent='Tamanho das letras selecionado. Salve para aplicar.'}));
