(function(){
'use strict';
// Older Android bridges start both wide system overlays as a side effect of
// scheduling an alarm. Their API has no independent hide operation. Keep those
// countdowns in the page; bridges with compact-window support keep native alarms.
function legacy(){
 if(!window.Android)return false;
 try{return typeof JSON.parse(window.Android.getTimerOverlayStatus()).dismissed!=='boolean'}catch(_){return true}
}
function start(method,payload){
 if(legacy())return false;
 try{const api=window.Android;return typeof api?.[method]==='function'&&api[method](payload)===true}catch(_){return false}
}
function migrate(state,key){
 if(!legacy())return;
 const api=window.Android;let changed=false;
 // Cancel even an orphaned rest left by the previous page. Do not clear the
 // saved rest, its deadline, the workout draft, or any completed sets.
 try{if(api.cancelWorkoutRest()!==false&&state.workoutRest?.native){state.workoutRest={...state.workoutRest,native:false};changed=true}}catch(_){}
 const timers={...state.lessonTimers};
 for(const [id,timer] of Object.entries(timers)){
  if(!timer)continue;
  try{if(typeof api.cancelLessonTimer!=='function')continue;api.cancelLessonTimer(timer.lessonId,timer.date);if(timer.native){timers[id]={...timer,native:false};changed=true}}catch(_){}
 }
 if(!changed)return;
 state.lessonTimers=timers;
 // If storage is full, retain the same in-memory countdown and retry migration
 // on the next load. Never delete or replace the user's database on failure.
 try{localStorage.setItem(key,JSON.stringify(state))}catch(_){}
}
window.APTimerCompatibility=Object.freeze({legacy,migrate,startLessonTimer:payload=>start('startLessonTimer',payload),startWorkoutRest:payload=>start('startWorkoutRest',payload)});
})();
