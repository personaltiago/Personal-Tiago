(function(global){
 'use strict';
 // A monthly-fee forecast and cash received are separate measures. Do not
 // subtract one from the other: receipts may settle a different month's fee.
 function build(state,now=new Date()){
  const month=now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0');
  const rows=(state.students||[]).filter(s=>s&&s.archived!==true&&s.financeEnabled===true&&(!APBilling.date(s.startDate)||s.startDate.slice(0,7)<=month)).map(s=>({
   id:String(s.id),name:String(s.name||'Aluno'),type:s.studentType,amountCents:APBilling.cents(s.monthlyValue),dueDate:APBilling.date(s.dueDate)
  })).sort((a,b)=>a.name.localeCompare(b.name,'pt-BR')||a.id.localeCompare(b.id));
  let forecastCents=0,pricedCount=0,receivedCents=0,receivedCount=0,unknownReceipts=0;
  for(const row of rows)if(row.amountCents!==null){forecastCents+=row.amountCents;pricedCount++}
  const seen=new Set();
  for(const p of state.payments||[]){
   if(!p||typeof p.paidAt!=='string')continue;
   const at=new Date(p.paidAt);
   if(!Number.isFinite(at.getTime())||at>now||at.getFullYear()!==now.getFullYear()||at.getMonth()!==now.getMonth())continue;
   const key=typeof p.id==='string'?p.id.trim():'';if(key&&seen.has(key))continue;if(key)seen.add(key);
   receivedCount++;const value=APBilling.cents(p.amount);
   if(value===null)unknownReceipts++;else receivedCents+=value;
  }
  return {month,rows,forecastCents,pricedCount,missingCount:rows.length-pricedCount,receivedCents,receivedCount,unknownReceipts};
 }
 const money=cents=>(cents/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
 global.APFinanceWallet=Object.freeze({build,money});
})(globalThis);
