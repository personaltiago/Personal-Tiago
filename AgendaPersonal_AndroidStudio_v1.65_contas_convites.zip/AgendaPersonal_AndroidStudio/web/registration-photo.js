(function(){
 'use strict';
 const el=id=>document.getElementById(id),canvas=el('registrationPhotoCrop');
 let photo='',working=false,ticket=0,saved=null,draft=null,drag=null;
 const say=(text,error=false)=>{const n=el('registrationPhotoStatus');n.textContent=text;n.dataset.error=String(error)};
 const clamp=(n,min,max)=>Math.min(max,Math.max(min,n));
 function constrain(){if(!draft)return;const side=Math.min(draft.image.naturalWidth,draft.image.naturalHeight)/draft.zoom;draft.x=clamp(draft.x,side/2,draft.image.naturalWidth-side/2);draft.y=clamp(draft.y,side/2,draft.image.naturalHeight-side/2)}
 function paint(target=canvas,mask=true){
  if(!draft)return;constrain();const g=target.getContext('2d'),size=target.width,side=Math.min(draft.image.naturalWidth,draft.image.naturalHeight)/draft.zoom;
  g.fillStyle='#15151d';g.fillRect(0,0,size,size);g.drawImage(draft.image,draft.x-side/2,draft.y-side/2,side,side,0,0,size,size);
  if(mask){g.save();g.fillStyle='rgba(0,0,0,.65)';g.beginPath();g.rect(0,0,size,size);g.arc(size/2,size/2,size/2-2,0,2*Math.PI,true);g.fill('evenodd');g.strokeStyle='#f1c2dd';g.lineWidth=2;g.beginPath();g.arc(size/2,size/2,size/2-2,0,Math.PI*2);g.stroke();g.restore()}
 }
 function render(){
  const image=el('registrationPhotoPreview');image.hidden=!photo;if(photo)image.src=photo;else image.removeAttribute('src');
  el('registrationPhotoPlaceholder').hidden=!!photo;image.parentElement.hidden=!!draft;
  el('registrationPhotoRemove').hidden=!photo;el('registrationPhotoAdjust').hidden=!photo||!saved||!!draft;
  el('registrationPhotoEditor').hidden=!draft;
  if(draft){el('registrationPhotoZoom').value=String(draft.zoom);el('registrationPhotoZoomValue').textContent=draft.zoom.toFixed(2).replace(/0+$/,'').replace(/\.$/,'')+'×';paint()}
 }
 function openCrop(value){draft={...value};drag=null;render();say('Arraste a foto dentro do círculo e ajuste o zoom. Depois toque em Usar este recorte.');canvas.focus({preventScroll:true});el('registrationPhotoEditor').scrollIntoView({block:'nearest',behavior:'smooth'})}
 async function choose(file){
  if(!file)return;const token=++ticket;working=false;
  if(file.size>8*1024*1024){say('Escolha uma foto de até 8 MB.',true);return}
  if(!/^image\/(jpeg|png|webp)$/i.test(file.type)){say('Escolha uma foto JPG, PNG ou WebP.',true);return}
  working=true;say('Preparando sua foto…');let url='';
  try{
   url=URL.createObjectURL(file);const image=new Image();await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=reject;image.src=url});
   if(token!==ticket)return;if(!image.naturalWidth||!image.naturalHeight)throw Error();
   openCrop({image,x:image.naturalWidth/2,y:image.naturalHeight/2,zoom:1});
  }catch(_){if(token===ticket)say('Não foi possível abrir essa foto. Escolha outra imagem.',true)}
  finally{if(url)URL.revokeObjectURL(url);if(token===ticket)working=false}
 }
 canvas.addEventListener('pointerdown',event=>{
  if(!draft||drag||event.button>0)return;event.preventDefault();drag={id:event.pointerId,x:event.clientX,y:event.clientY};try{canvas.setPointerCapture(event.pointerId)}catch(_){}
 });
 canvas.addEventListener('pointermove',event=>{
  if(!draft||drag?.id!==event.pointerId)return;event.preventDefault();const side=Math.min(draft.image.naturalWidth,draft.image.naturalHeight)/draft.zoom,ratio=side/canvas.getBoundingClientRect().width;
  draft.x-=(event.clientX-drag.x)*ratio;draft.y-=(event.clientY-drag.y)*ratio;drag.x=event.clientX;drag.y=event.clientY;paint();
 });
 for(const name of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(name,event=>{if(drag?.id===event.pointerId)drag=null});
 canvas.addEventListener('keydown',event=>{
  if(!draft||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();const step=Math.min(draft.image.naturalWidth,draft.image.naturalHeight)/draft.zoom/30;
  if(event.key==='ArrowLeft')draft.x+=step;if(event.key==='ArrowRight')draft.x-=step;if(event.key==='ArrowUp')draft.y+=step;if(event.key==='ArrowDown')draft.y-=step;paint();
 });
 el('registrationPhotoZoom').oninput=event=>{if(!draft)return;draft.zoom=clamp(Number(event.target.value)||1,1,4);render()};
 el('registrationPhotoApply').onclick=()=>{
  if(!draft||working)return;
  try{
   const output=document.createElement('canvas');output.width=output.height=320;paint(output,false);let compressed='';
   for(const quality of [.82,.65,.45]){compressed=output.toDataURL('image/jpeg',quality);if(compressed.length<=120000)break}
   if(compressed.length>120000||!/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(compressed))throw Error();
   photo=compressed;saved={...draft};draft=null;drag=null;render();say('Foto pronta para enviar com seu cadastro.');el('registrationPhotoAdjust').focus({preventScroll:true});
  }catch(_){say('Não foi possível preparar esse recorte. Tente outra foto.',true)}
 };
 el('registrationPhotoCancel').onclick=()=>{draft=null;drag=null;render();say(photo?'A foto anterior foi mantida.':'Recorte cancelado. Você pode escolher outra foto ou continuar sem foto.');el('registrationPhotoGallery').focus({preventScroll:true})};
 el('registrationPhotoAdjust').onclick=()=>{if(saved)openCrop(saved)};
 for(const [button,input]of [['registrationPhotoGallery','registrationPhotoFile'],['registrationPhotoCamera','registrationPhotoCameraFile']]){
  el(button).onclick=()=>{const n=el(input);n.value='';n.click()};el(input).onchange=e=>choose(e.target.files?.[0]);
 }
 el('registrationPhotoRemove').onclick=()=>{ticket++;working=false;photo='';saved=null;draft=null;drag=null;render();say('Foto removida. Você pode continuar sem foto.')};
 window.APRegistrationPhoto=Object.freeze({value(){if(working)throw Error('Aguarde a preparação da foto antes de enviar.');if(draft)throw Error('Confirme o recorte da foto ou toque em Cancelar antes de enviar.');return photo}});render();
})();
