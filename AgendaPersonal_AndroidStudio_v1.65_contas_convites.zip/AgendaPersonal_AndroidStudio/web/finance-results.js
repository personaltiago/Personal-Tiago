(function(){
 'use strict';
 const M=APFinanceResults,el=id=>document.getElementById(id),money=APFinanceWallet.money,months=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
 const initial=new Date();let year=initial.getFullYear(),month=initial.getMonth()+1,editing=null;
 const safe=v=>hesc(String(v??''));
 const cards=(row,period)=>'<div><span>Recebido '+period+'</span><strong class="fr-income">'+money(row.receivedCents)+'</strong></div><div><span>Despesas '+period+'</span><strong class="fr-cost">'+money(row.expenseCents)+'</strong></div><div><span>'+(row.resultCents<0?'Prejuízo':'Lucro')+' '+period+((row.unknownReceipts||row.unknownExpenses||row.uncertainDates)?' · parcial':'')+'</span><strong class="'+(row.resultCents<0?'fr-cost':'fr-profit')+'">'+money(row.resultCents)+'</strong></div>';
 function render(){
  const now=new Date(),years=new Set([now.getFullYear(),year]);for(const p of state.payments||[]){const d=new Date(p?.paidAt);if(Number.isFinite(d.getTime()))years.add(d.getFullYear())}for(const e of state.financeExpenses||[])if(M.day(new Date(e?.date+'T12:00:00'))===e?.date)years.add(Number(e.date.slice(0,4)));
  el('frYear').innerHTML=[...years].sort((a,b)=>b-a).map(y=>'<option value="'+y+'"'+(y===year?' selected':'')+'>'+y+'</option>').join('');
  el('frMonth').innerHTML=months.map((m,i)=>'<option value="'+(i+1)+'"'+(month===i+1?' selected':'')+'>'+m+'</option>').join('');
  const data=M.build(state,year,now),row=data.months[month-1];el('frMonthCards').innerHTML=cards(row,'no mês');el('frYearCards').innerHTML=cards(data.total,'no ano');
  const warnings=[];if(data.total.unknownReceipts)warnings.push(data.total.unknownReceipts+' pagamento(s) sem valor válido');if(data.total.unknownExpenses)warnings.push(data.total.unknownExpenses+' despesa(s) sem valor válido');if(data.invalidDates)warnings.push(data.invalidDates+' registro(s) sem data válida');
  el('frWarning').hidden=!warnings.length;el('frWarning').textContent=warnings.length?'Resultado parcial: '+warnings.join('; ')+'. Esses registros ficaram fora das somas.':'';
  const max=Math.max(1,...data.months.flatMap(m=>[m.receivedCents,m.expenseCents]));
  el('frChart').innerHTML=data.months.map((m,i)=>'<button type="button" class="fr-chart-month" data-fr-month="'+m.month+'" aria-pressed="'+(month===m.month)+'" aria-label="'+months[i]+': recebido '+money(m.receivedCents)+', despesas '+money(m.expenseCents)+', resultado '+money(m.resultCents)+'"><span class="fr-bars" aria-hidden="true"><i class="fr-income-bar" style="height:'+100*m.receivedCents/max+'%"></i><i class="fr-cost-bar" style="height:'+100*m.expenseCents/max+'%"></i></span><span>'+months[i].slice(0,3)+'</span></button>').join('');
  el('frTableCaption').textContent='Recebido, despesas e resultado de '+year;
  el('frTable').innerHTML=data.months.map((m,i)=>'<tr><th scope="row">'+months[i]+((m.unknownReceipts||m.unknownExpenses||m.uncertainDates)?' *':'')+'</th><td>'+money(m.receivedCents)+'</td><td>'+money(m.expenseCents)+'</td><td>'+money(m.resultCents)+'</td></tr>').join('');
  el('frExpenses').innerHTML=row.expenses.length?row.expenses.map(e=>'<div class="fr-expense"><div><strong>'+safe(e.description||'Despesa sem descrição')+'</strong><small>'+safe(e.date.split('-').reverse().join('/'))+(e.date>data.today?' · Data futura, fora do resultado':'')+'</small></div><strong>'+safe(Number.isSafeInteger(e.amountCents)?money(e.amountCents):'Valor inválido')+'</strong><div class="fr-actions"><button type="button" data-fr-edit="'+safe(e.id)+'">Editar</button><button type="button" data-fr-delete="'+safe(e.id)+'">Excluir</button></div></div>').join(''):'<p class="fr-note">Nenhuma despesa registrada em '+months[month-1].toLowerCase()+' de '+year+'.</p>';
 }
 function open(expense=null){editing=expense?{...expense}:null;el('frDialogTitle').textContent=expense?'Editar despesa':'Nova despesa';el('frDescription').value=expense?.description||'';el('frAmount').value=expense&&Number.isSafeInteger(expense.amountCents)?(expense.amountCents/100).toFixed(2).replace('.',','):'';el('frDate').max=M.day(new Date());el('frDate').value=expense?.date||el('frDate').max;el('frError').textContent='';el('frDialog').showModal()}
 function changed(){renderFinance();window.APTeacherSync?.changed()}
 el('frYear').onchange=()=>{year=Number(el('frYear').value);render()};el('frMonth').onchange=()=>{month=Number(el('frMonth').value);render()};
 el('frChart').onclick=event=>{const b=event.target.closest('[data-fr-month]');if(b){month=Number(b.dataset.frMonth);render()}};
 el('frAdd').onclick=()=>open();for(const name of ['frClose','frCancel'])el(name).onclick=()=>el('frDialog').close();
 el('frForm').onsubmit=event=>{event.preventDefault();try{
  const current=editing?(state.financeExpenses||[]).find(e=>e.id===editing.id):null;
  if(editing&&(!current||current.deleted||JSON.stringify(current)!==JSON.stringify(editing)))throw Error('A despesa mudou em outro lugar. Feche e abra a edição novamente.');
  const entry={...M.expense({description:el('frDescription').value,amount:el('frAmount').value,date:el('frDate').value},current),id:current?.id||id()};
  M.commit(state,localStorage,DB_KEY,entry,current?'edit':'add');year=Number(entry.date.slice(0,4));month=Number(entry.date.slice(5,7));el('frDialog').close();changed();
 }catch(error){el('frError').textContent=/quota|storage|space/i.test(error.name+' '+error.message)?'Não foi possível salvar. Libere espaço no aparelho e tente novamente.':error.message}};
 el('frExpenses').onclick=event=>{const edit=event.target.closest('[data-fr-edit]'),remove=event.target.closest('[data-fr-delete]');if(!edit&&!remove)return;const entry=(state.financeExpenses||[]).find(e=>e.id===(edit?edit.dataset.frEdit:remove.dataset.frDelete)&&!e.deleted);if(!entry)return;if(edit)return open(entry);if(!confirm('Excluir a despesa “'+entry.description+'”?'))return;try{M.commit(state,localStorage,DB_KEY,{id:entry.id,updatedAt:new Date().toISOString()},'delete');changed()}catch(_){alert('Não foi possível excluir. A despesa foi mantida; tente novamente.')}};
 const previous=renderFinance;renderFinance=function(){const result=previous.apply(this,arguments);render();return result};render();
})();
