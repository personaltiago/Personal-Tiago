let setupCrop=null,setupImageEpoch=0,setupCropFocus=null,setupCropSiblings=[];
const setupCropDialog=$('apsImageCrop'),setupCropCanvas=$('apsCropCanvas'),setupCropPointers=new Map();
function setupCropImage(source){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>img.naturalWidth&&img.naturalHeight?resolve(img):reject(Error('invalid image'));img.onerror=()=>reject(Error('invalid image'));img.src=source})}
function setupCropCanvasOf(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return c}
function setupCropMinimum(){return setupCrop?.kind==='logo' ? .25 : 1}
function setupCropGeometry(){
 const s=setupCrop,w=s.image.naturalWidth,h=s.image.naturalHeight;
 s.zoom=Math.max(setupCropMinimum(),Math.min(8,Number(s.zoom)||1));
 const base=s.kind==='photo'?Math.max(512/w,512/h):Math.min(512/w,512/h),scale=base*s.zoom,half=256/scale;
 if(s.kind==='photo'){s.x=Math.max(half,Math.min(w-half,s.x));s.y=Math.max(half,Math.min(h-half,s.y))}
 else{s.x=Math.max(0,Math.min(w,s.x));s.y=Math.max(0,Math.min(h,s.y))}
 return {w,h,scale,half};
}
function setupCropFrame(c){c.beginPath();if(setupCrop.kind==='photo')c.arc(300,300,256,0,Math.PI*2);else c.roundRect(44,44,512,512,58)}
function setupCropDraw(){
 if(!setupCrop)return;const s=setupCrop,g=setupCropGeometry(),c=setupCropCanvas.getContext('2d');
 c.clearRect(0,0,600,600);for(let y=0;y<600;y+=20)for(let x=0;x<600;x+=20){c.fillStyle=(x+y)%40?'#24242b':'#1a1a21';c.fillRect(x,y,20,20)}
 c.drawImage(s.image,300-s.x*g.scale,300-s.y*g.scale,g.w*g.scale,g.h*g.scale);
 c.save();setupCropFrame(c);c.clip();c.strokeStyle='#ffffff35';c.lineWidth=1;for(const d of [-1,1]){c.beginPath();c.moveTo(44,300+d*256/3);c.lineTo(556,300+d*256/3);c.moveTo(300+d*256/3,44);c.lineTo(300+d*256/3,556);c.stroke()}c.restore();
 c.save();setupCropFrame(c);c.rect(600,0,-600,600);c.fillStyle='#050409b8';c.fill('evenodd');c.restore();setupCropFrame(c);c.strokeStyle='#fff';c.lineWidth=3;c.stroke();
 $('apsCropZoom').min=String(setupCropMinimum());$('apsCropZoom').value=String(s.zoom);$('apsCropZoomValue').textContent=s.zoom.toFixed(2).replace(/0$/,'').replace(/\.0$/,'')+'×';
}
function setupCropClose(){
 setupImageEpoch++;setupCrop=null;setupCropPointers.clear();setupCropDialog.hidden=true;
 for(const [el,inert]of setupCropSiblings)el.inert=inert;setupCropSiblings=[];
 if(setupCropFocus?.isConnected&&!root.hidden)setupCropFocus.focus({preventScroll:true});setupCropFocus=null;
}
window.APcloseTeacherImageCrop=function(){if(setupCropDialog.hidden)return false;setupCropClose();return true};
async function setupCropOpen(source,kind,crop=null,epoch=++setupImageEpoch){
 try{const image=await setupCropImage(source);if(epoch!==setupImageEpoch||root.hidden)return;
  setupCrop={source,image,kind,zoom:crop?.zoom||1,x:Number.isFinite(crop?.x)?crop.x*image.naturalWidth:image.naturalWidth/2,y:Number.isFinite(crop?.y)?crop.y*image.naturalHeight:image.naturalHeight/2};
  setupCropFocus=document.activeElement;setupCropSiblings=[...root.children].filter(el=>el!==setupCropDialog).map(el=>[el,el.inert]);for(const [el]of setupCropSiblings)el.inert=true;
  $('apsCropTitle').textContent=kind==='photo'?'Enquadrar foto do profissional':'Enquadrar logotipo';$('apsCropError').textContent='';setupCropDialog.hidden=false;setupCropDraw();setupCropCanvas.focus({preventScroll:true});
 }catch(_){if(epoch===setupImageEpoch)$('apsStatus').textContent='Não foi possível abrir essa imagem. Tente JPG, PNG ou WebP.'}
}
async function processFile(file,kind){
 if(!file)return;const epoch=++setupImageEpoch;
 if(!/^image\//.test(file.type)){$('apsStatus').textContent='Escolha uma imagem válida.';return}
 if(file.size>50*1024*1024){$('apsStatus').textContent='Imagem acima de 50 MB. Escolha uma menor.';return}
 $('apsStatus').textContent='Preparando imagem…';let url='';
 try{
  url=URL.createObjectURL(file);const image=await setupCropImage(url);if(epoch!==setupImageEpoch||root.hidden)return;
  const ratio=Math.min(1,1200/Math.max(image.naturalWidth,image.naturalHeight)),c=setupCropCanvasOf(Math.max(1,Math.round(image.naturalWidth*ratio)),Math.max(1,Math.round(image.naturalHeight*ratio))),ctx=c.getContext('2d');
  if(kind==='photo'){ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height)}ctx.drawImage(image,0,0,c.width,c.height);
  let source=c.toDataURL(kind==='logo'?'image/png':'image/jpeg',.88);if(source.length>850000)source=c.toDataURL('image/webp',.9);
  await setupCropOpen(source,kind,null,epoch);if(epoch===setupImageEpoch)$('apsStatus').textContent='Ajuste a imagem e confirme o enquadramento.';
 }catch(_){if(epoch===setupImageEpoch)$('apsStatus').textContent='Não foi possível abrir essa imagem. Tente JPG, PNG ou WebP.'}
 finally{if(url)URL.revokeObjectURL(url)}
}
function setupImageRefresh(){for(const kind of ['photo','logo'])$('apsAdjust'+(kind==='photo'?'Photo':'Logo')).hidden=!currentConfig[kind]}
function setupImageRemove(kind){setupImageEpoch++;currentConfig[kind]='';if(currentConfig.imageEdits)delete currentConfig.imageEdits[kind];preview()}
root.querySelectorAll('[data-aps-adjust]').forEach(button=>button.onclick=()=>{const kind=button.dataset.apsAdjust,edit=currentConfig.imageEdits?.[kind];setupCropOpen(edit?.source||currentConfig[kind],kind,edit?.crop)});
for(const id of ['apsCropClose','apsCropCancel'])$(id).onclick=setupCropClose;
$('apsCropReset').onclick=()=>{if(setupCrop){setupCrop.zoom=1;setupCrop.x=setupCrop.image.naturalWidth/2;setupCrop.y=setupCrop.image.naturalHeight/2;setupCropDraw()}};
$('apsCropZoom').oninput=event=>{if(setupCrop){setupCrop.zoom=Number(event.target.value);setupCropDraw()}};
$('apsCropApply').onclick=()=>{
 if(!setupCrop)return;try{const s=setupCrop,g=setupCropGeometry(),c=setupCropCanvasOf(512,512),ctx=c.getContext('2d');
  if(s.kind==='photo'){ctx.fillStyle='#fff';ctx.fillRect(0,0,512,512)}
  // Match the fixed frame exactly, preserving the original image proportions.
  const scale=256/g.half;ctx.drawImage(s.image,256-s.x*scale,256-s.y*scale,g.w*scale,g.h*scale);
  const result=c.toDataURL(s.kind==='logo'?'image/png':'image/jpeg',.9);if(result.length>850000)throw Error('large');
  currentConfig[s.kind]=result;currentConfig.imageEdits={...(currentConfig.imageEdits||{}),[s.kind]:{source:s.source,crop:{zoom:s.zoom,x:s.x/g.w,y:s.y/g.h}}};
  preview();setupCropClose();$('apsStatus').textContent='Enquadramento aplicado. Confirme em “Salvar e abrir painel” para guardar.';
 }catch(_){$('apsCropError').textContent='Não foi possível preparar esse recorte. Reduza o zoom ou escolha uma imagem menor.'}
};
function setupCropPoint(event){const b=setupCropCanvas.getBoundingClientRect();return {x:(event.clientX-b.left)*600/b.width,y:(event.clientY-b.top)*600/b.height}}
setupCropCanvas.onpointerdown=event=>{if(!setupCrop)return;setupCropPointers.set(event.pointerId,setupCropPoint(event));setupCropCanvas.setPointerCapture(event.pointerId);event.preventDefault()};
setupCropCanvas.onpointermove=event=>{
 if(!setupCrop||!setupCropPointers.has(event.pointerId))return;event.preventDefault();const old=[...setupCropPointers.values()],before=setupCropGeometry(),point=setupCropPoint(event);setupCropPointers.set(event.pointerId,point);const next=[...setupCropPointers.values()];
 if(old.length===1){setupCrop.x-=(next[0].x-old[0].x)/before.scale;setupCrop.y-=(next[0].y-old[0].y)/before.scale}
 else{
  const center=a=>({x:(a[0].x+a[1].x)/2,y:(a[0].y+a[1].y)/2}),distance=a=>Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y),a=center(old),b=center(next),d=distance(old);
  const ix=setupCrop.x+(a.x-300)/before.scale,iy=setupCrop.y+(a.y-300)/before.scale;
  if(d>0)setupCrop.zoom*=distance(next)/d;const after=setupCropGeometry();setupCrop.x=ix-(b.x-300)/after.scale;setupCrop.y=iy-(b.y-300)/after.scale;
 }
 setupCropDraw();
};
for(const type of ['pointerup','pointercancel','lostpointercapture'])setupCropCanvas.addEventListener(type,event=>setupCropPointers.delete(event.pointerId));
setupCropCanvas.addEventListener('wheel',event=>{if(!setupCrop)return;event.preventDefault();setupCrop.zoom*=Math.exp(-event.deltaY*.001);setupCropDraw()},{passive:false});
setupCropCanvas.onkeydown=event=>{if(!setupCrop||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();const delta=(event.shiftKey?24:6)/setupCropGeometry().scale;setupCrop.x+=(event.key==='ArrowLeft'?1:event.key==='ArrowRight'?-1:0)*delta;setupCrop.y+=(event.key==='ArrowUp'?1:event.key==='ArrowDown'?-1:0)*delta;setupCropDraw()};
setupCropDialog.onkeydown=event=>{
 if(event.key==='Escape'){event.preventDefault();event.stopPropagation();setupCropClose();return}
 if(event.key!=='Tab')return;const controls=[...setupCropDialog.querySelectorAll('button,input,canvas')].filter(el=>!el.disabled),first=controls[0],last=controls.at(-1);
 if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus()}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus()}
};
