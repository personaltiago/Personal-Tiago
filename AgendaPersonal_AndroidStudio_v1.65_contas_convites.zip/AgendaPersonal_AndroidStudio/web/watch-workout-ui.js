(function(){
'use strict';
const bridge=()=>{try{return window.Android||window.parent?.Android}catch(_){return null}};
let dialog,timer;
function message(text){if(typeof toast==='function')toast(text);else alert(text);}
function send(workout,role,person){
 try{
  const api=bridge();if(!api?.sendWatchWorkout)throw Error('Instale a nova versão do Agenda Personal no celular e a versão Wear OS no relógio.');
  const p=APWatchModel.packet(workout,role,person);
  const result=JSON.parse(api.sendWatchWorkout(JSON.stringify(p)));message(result.message||'Não foi possível enviar.');
 }catch(error){message(error.message)}
}
function close(){clearInterval(timer);dialog?.remove();dialog=null;}
function results(role){
 close();const api=bridge();if(!api?.getWatchStatus&&!window.APWatchHistory?.available([]).length){message('Os resultados do relógio estarão disponíveis no novo APK para Android.');return;}
 dialog=document.createElement('dialog');dialog.className='ap-watch-dialog';dialog.setAttribute('aria-label','Resultados do relógio');
 const title=document.createElement('h2');title.textContent='Relógio · Wear OS';dialog.append(title);
 const status=document.createElement('p');status.setAttribute('role','status');dialog.append(status);
 const list=document.createElement('div');dialog.append(list);
 const hint=document.createElement('p');hint.textContent='Resumo das séries marcadas no relógio. As cargas e repetições exibidas durante o treino são a prescrição; o relógio não mede esses valores. Você pode incluir o resumo no histórico, preservando a origem Smartwatch.';hint.className='ap-watch-help';dialog.append(hint);
 const connection=document.createElement('button');connection.type='button';connection.textContent='Conexão do smartwatch';connection.onclick=()=>setup(role);dialog.append(connection);
 const done=document.createElement('button');done.type='button';done.textContent='Fechar';done.onclick=close;dialog.append(done);dialog.addEventListener('cancel',e=>{e.preventDefault();close()});document.body.append(dialog);dialog.showModal();
 let signature='';
 function refresh(){try{const data=api?.getWatchStatus?JSON.parse(api.getWatchStatus()):{results:[],message:'Resumos recuperados do backup.'};status.textContent=data.message||'';const rows=(window.APWatchHistory?.available(data.results||[])||data.results||[]).filter(r=>r.role===role),next=JSON.stringify(rows);if(next===signature)return;signature=next;list.replaceChildren();if(!rows.length){const p=document.createElement('p');p.textContent='Nenhum treino recebido do relógio nesta conta.';list.append(p);}for(const r of rows){const card=document.createElement('article');const strong=document.createElement('strong');strong.textContent=r.label+' · '+r.person;card.append(strong);const p=document.createElement('p');p.textContent=new Date(r.finishedAt).toLocaleString('pt-BR')+' · '+r.completed+'/'+r.total+' séries · '+Math.floor(r.durationMs/60000)+' min'+(r.completed<r.total?' · parcial':' · concluído');card.append(p);window.APWatchHistory?.controls(card,r,role);list.append(card);}}catch(_){status.textContent='Não foi possível consultar o relógio.'}}
 refresh();timer=setInterval(refresh,2500);
}

function setup(role='teacher'){
 close();const api=bridge();
 dialog=document.createElement('dialog');dialog.id='apWatchSetup';dialog.className='ap-watch-dialog';dialog.setAttribute('aria-labelledby','apWatchSetupTitle');
 dialog.innerHTML='<header class="ap-watch-setup-heading"><h2 id="apWatchSetupTitle" tabindex="-1">Smartwatch</h2><button type="button" data-watch-top-close aria-label="Fechar conexão do smartwatch">×</button></header><p class="ap-watch-help">Conecte um relógio Wear OS 3 ou superior ao celular e instale Agenda Personal nos dois aparelhos.</p><section class="ap-watch-connection"><strong>Conexão</strong><p data-connection-status role="status" aria-live="polite">Consultando relógio…</p><p data-watch-app-status></p></section><h3>Parear / configurar relógio</h3><p>O pareamento inicial é feito no aplicativo oficial do fabricante. Depois, volte aqui para conferir a conexão.</p><label for="apWatchVendor">Aplicativo de conexão</label><select id="apWatchVendor"><option value="samsung">Galaxy Wearable · Samsung</option><option value="google">Wear OS by Google</option><option value="other">Outro fabricante · ajustes Bluetooth</option></select><p class="ap-watch-help">Use o aplicativo indicado pelo seu modelo. Os ajustes Bluetooth, sozinhos, não substituem a configuração do fabricante.</p><button type="button" data-watch-pair>Abrir conexão do relógio</button><p data-watch-setup-help class="ap-watch-help" role="status"></p><section class="ap-watch-requirements"><h3>Antes de enviar um treino</h3><p>Relógios apenas “compatíveis com Android” não estão confirmados. Este recurso requer Wear OS; modelos que usam MActive Pro ou Pubu Wear não têm suporte confirmado.</p><p>Com os dois aplicativos instalados, abra o treino e toque no ícone de smartwatch ao lado do título. O recebimento só é confirmado quando o relógio responder.</p></section><div class="ap-watch-actions"><button type="button" data-watch-refresh>Verificar conexão</button><button type="button" data-watch-results>Resultados do relógio</button><button type="button" data-watch-close>Fechar</button></div>';
 const panel=dialog;
 panel.querySelector('[data-watch-pair]').onclick=()=>{
  if(typeof api?.openWatchPairing==='function')api.openWatchPairing(panel.querySelector('#apWatchVendor').value);
  else panel.querySelector('[data-watch-setup-help]').textContent='Atualize o aplicativo do celular para a versão 1.151. Enquanto isso, abra o aplicativo oficial do fabricante pelo celular.';
 };
 panel.querySelector('[data-watch-top-close]').onclick=close;panel.querySelector('[data-watch-close]').onclick=close;panel.querySelector('[data-watch-results]').onclick=()=>results(role);
 function refresh(){
  const status=panel.querySelector('[data-connection-status]'),app=panel.querySelector('[data-watch-app-status]');
  try{
   if(typeof api?.getWatchStatus!=='function')throw Error('Atualize o aplicativo do celular para usar o smartwatch.');
   const data=JSON.parse(api.getWatchStatus()),c=data.connection;
   if(!c){status.textContent='Atualize o aplicativo do celular para 1.151 para consultar a conexão.';app.textContent='';return;}
   if(c.state==='unavailable'){status.textContent='Conexão Wear OS indisponível. Confira o relógio e o Google Play Services.';app.textContent='';return;}
   if(c.state!=='checked'){status.textContent='Consultando relógio…';app.textContent='';return;}
   const nodes=Array.isArray(c.nodes)?c.nodes:[];
   status.textContent=nodes.length?'Conectado ao celular: '+nodes.map(n=>String(n.name||'Relógio')).join(', '):'Nenhum relógio Wear OS conectado neste momento.';
   const ready=nodes.some(n=>Array.isArray(c.appNodes)&&c.appNodes.includes(n.id));
   app.textContent=ready?'Agenda Personal detectado no relógio.':nodes.length?'Agenda Personal ainda não confirmado no relógio. Instale e abra Agenda Personal 1.151 ou superior no relógio.':'';
  }catch(error){status.textContent=error.message||'Não foi possível consultar a conexão.';app.textContent='';}
 }
 panel.querySelector('[data-watch-refresh]').onclick=refresh;panel.addEventListener('cancel',event=>{event.preventDefault();close()});document.body.append(panel);panel.showModal();panel.querySelector('h2').focus({preventScroll:true});panel.scrollTop=0;refresh();timer=setInterval(refresh,2500);
}

window.APWatchUI=Object.freeze({send,results,setup,close});
window.addEventListener('pagehide',close);window.addEventListener('ap-account-changed',close);
})();
