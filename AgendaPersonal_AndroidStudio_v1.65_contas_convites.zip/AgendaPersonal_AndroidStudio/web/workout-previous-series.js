(function(root){
  'use strict';
  // Read completed sessions only. Current drafts and prescribed ranges are not results.
  function read(state,plan,day,exercise){
    if(!plan||!day||!exercise)return null;
    const records=(Array.isArray(state.workoutExecutions)?state.workoutExecutions:[])
      .filter(r=>r&&r.studentId===plan.studentId&&r.planId===plan.id&&r.dayId===day.id&&Array.isArray(r.exercises)&&r.exercises.some(e=>e?.exerciseId===exercise.id))
      .slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||String(b.finishedAt||b.recordedAt||'').localeCompare(String(a.finishedAt||a.recordedAt||''))||String(b.id||'').localeCompare(String(a.id||'')));
    const record=records[0];if(!record)return null;
    const entry=record.exercises.find(e=>e?.exerciseId===exercise.id),values=Object.create(null),units=Object.create(null);
    for(const row of Array.isArray(entry.performedSets)?entry.performedSets:[]){
      const timed=row?.unit==='seconds'||root.APTimedSeries?.isTimed(row?.prescribedReps)===true,round=Number(row?.round),reps=Number(timed?row.seconds??row.reps:row?.reps);
      if(row&&row.done!==false&&Number.isInteger(round)&&round>=1&&round<=100&&Number.isInteger(reps)&&reps>=1&&reps<=(timed?86400:999)){values[round]=reps;units[round]=timed?'seconds':'reps';}
    }
    // Missing rounds in a partial session remain blank; never mix two sessions.
    return {date:String(record.date||''),recordId:record.id,values,units};
  }
  root.APWorkoutPreviousSeries=Object.freeze({read});
})(window);
