(function(){
 'use strict';
 const el=id=>document.getElementById(id),model=APPixReceipt,money=APFinanceWallet.money,MAX=8*1024*1024;
 let draft=null,serial=0,view=null,shown=12;const pending=new Map();
 const today=()=>iso(new Date());
 function guard(){try{return window.parent!==window?window.parent.APaccounts?.isTeacher()===true:!window.APaccounts||APaccounts.isTeacher()===true}catch(_){return false}}
 const scope=()=>DB_KEY+'|'+(window.agendaRegistration?.teacher||'local');
 const alive=d=>draft===d&&el('financeReceiptDialog').classList.contains('open')&&guard()&&d.scope===scope();
 function error(message){el('receiptError').textContent=message||'';el('receiptError').hidden=!message}
 function resetChecks(){for(const id of ['receiptConfirmPayer','receiptConfirmAmount','receiptConfirmDate','receiptConfirmDifference'])el(id).checked=false}
 function release(d){if(d?.url)URL.revokeObjectURL(d.url);if(d?.key){const job=pending.get(d.key);if(job){clearTimeout(job.timer);pending.delete(d.key);job.reject(Error('Leitura encerrada'))}}}
 function database(){return new Promise((resolve,reject)=>{const request=indexedDB.open('agendaPersonalPixReceipts_v1',1);request.onupgradeneeded=()=>request.result.createObjectStore('receipts',{keyPath:'key'});request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(Error('Não foi possível abrir o armazenamento de comprovantes.'));request.onblocked=()=>reject(Error('Feche outra janela do aplicativo e tente novamente.'))})}
 async function store(action,documentId,value){
  if(!guard())throw Error('Entre com a conta do professor.');const db=await database();
  try{return await new Promise((resolve,reject)=>{const tx=db.transaction('receipts',action==='get'?'readonly':'readwrite'),object=tx.objectStore('receipts'),key=scope()+'|'+documentId;let result;
   const request=action==='get'?object.get(key):action==='delete'?object.delete(key):object.put({...value,key});request.onsuccess=()=>{result=request.result};tx.oncomplete=()=>resolve(result);tx.onabort=tx.onerror=()=>reject(Error('Não foi possível guardar o comprovante. Libere espaço e tente novamente.'));
  })}finally{db.close()}
 }
 async function hash(bytes){if(!crypto.subtle)throw Error('Abra o aplicativo ou um endereço HTTPS para anexar comprovantes.');const digest=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(digest)].map(n=>n.toString(16).padStart(2,'0')).join('')}
 function mime(bytes){if(bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff)return'image/jpeg';if(bytes[0]===0x89&&String.fromCharCode(...bytes.slice(1,4))==='PNG')return'image/png';if(String.fromCharCode(...bytes.slice(0,5))==='%PDF-')return'application/pdf';if(String.fromCharCode(...bytes.slice(0,4))==='RIFF'&&String.fromCharCode(...bytes.slice(8,12))==='WEBP')return'image/webp';return''}
 function enabled(d,value){if(!alive(d))return;el('receiptFields').disabled=!value;el('receiptSubmit').disabled=!value;el('receiptManual').hidden=value;}
 function difference(){
  const d=draft;if(!d)return;const student=studentById(d.studentId),amount=APBilling.cents(el('receiptAmount').value),expected=APBilling.cents(student?.monthlyValue),different=el('receiptMode').value==='settle'&&amount!==null&&amount!==expected;
  el('receiptDifference').hidden=!different;el('receiptDifferenceText').textContent=expected===null?'Este aluno está sem valor mensal informado. Confirme se o valor recebido quita este vencimento.':'Valor cadastrado: '+money(expected)+'. Valor recebido: '+(amount===null?'a definir':money(amount))+'.';
  el('receiptSubmit').textContent=el('receiptMode').value==='settle'?'Confirmar e dar baixa':'Confirmar recebimento';
 }
 function identityWarnings(){
  if(!draft)return;const student=studentById(draft.studentId),payer=el('receiptPayer').value.trim(),date=APBilling.date(el('receiptPaymentDate').value),key=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
  el('receiptPayerWarning').hidden=!payer||key(payer)===key(student?.name);el('receiptPayerWarning').textContent='O nome do pagador é diferente. A baixa será para '+(student?.name||'o aluno selecionado')+'. Confirme o vínculo abaixo.';
  let note='';if(date>today())note='A data está no futuro. Corrija antes de confirmar.';else if(date&&student?.startDate&&date<student.startDate)note='A data é anterior ao início do aluno. Confira se este pagamento pertence a ele.';else if(date&&date.slice(0,7)!==draft.dueDate.slice(0,7))note='O pagamento é de outro mês em relação ao vencimento. Confira a referência antes de confirmar.';
  el('receiptDateWarning').hidden=!note;el('receiptDateWarning').textContent=note;el('receiptPaymentDate').max=today();
 }
 function apply(d,text,method){
  if(!alive(d))return;const fields=model.parse(text);d.readMethod=method;d.reading=false;
  el('receiptPayer').value=fields.payer;el('receiptAmount').value=fields.amountCents===null?'':(fields.amountCents/100).toFixed(2).replace('.',',');el('receiptPaymentDate').value=fields.paymentDate;el('receiptTransactionId').value=fields.transactionId;
  el('receiptSuspicious').hidden=!fields.suspicious;el('receiptExtractedText').textContent=fields.text;el('receiptReadText').hidden=!fields.text;resetChecks();enabled(d,true);difference();
  identityWarnings();el('receiptReadStatus').textContent=fields.text?'Leitura concluída. Confira nome, valor e data; corrija o que estiver diferente ou vazio.':'Não foi possível identificar os dados. Preencha nome, valor e data manualmente.';
 }
 window.financeReceiptRead=function(key,result){const job=pending.get(key);if(!job)return;pending.delete(key);clearTimeout(job.timer);result?.error?job.reject(Error(result.error)):job.resolve(result)};
 function nativeRead(d){
  if(typeof window.Android?.readPixReceipt!=='function')return Promise.reject(Error('Para ler imagens automaticamente, instale o APK 1.120. Você pode preencher os dados manualmente.'));
  return new Promise((resolve,reject)=>{const key='pix_'+(crypto.randomUUID?.()||id())+'_'+(++serial);d.key=key;const timer=setTimeout(()=>{pending.delete(key);reject(Error('A leitura demorou. Confira e preencha os dados manualmente.'))},45000);pending.set(key,{resolve,reject,timer});
   try{if(!Android.readPixReceipt(key,d.mime,workoutImportBytesToBase64(d.bytes))){clearTimeout(timer);pending.delete(key);reject(Error('A leitura está ocupada ou indisponível. Preencha manualmente e confira o comprovante.'))}}catch(e){clearTimeout(timer);pending.delete(key);reject(e)}
  });
 }
 async function pdfText(d){
  const pdfjs=await workoutPdfReader(),task=pdfjs.getDocument({data:d.bytes.slice(),useSystemFonts:true,isEvalSupported:false,useWasm:false});let pdf;
  try{pdf=await task.promise;if(pdf.numPages>3)throw Error('A leitura automática aceita até três páginas.');const pages=[];for(let n=1;n<=pdf.numPages;n++){if(!alive(d))throw Error('Leitura encerrada');const page=await pdf.getPage(n);pages.push(workoutImportPageLines(await page.getTextContent()).join('\n'))}return pages.join('\n')}
  finally{try{if(pdf)await pdf.destroy();else await task.destroy()}catch(_){}}
 }
 async function choose(file){
  const d=draft;if(!d||d.saving||!alive(d)||!file)return;release(d);const token=++serial;d.token=token;d.attachment=null;d.bytes=null;d.reading=true;d.key='';enabled(d,false);resetChecks();error('');el('receiptPreview').hidden=true;el('receiptReadText').hidden=true;el('receiptSuspicious').hidden=true;el('receiptManual').hidden=true;el('receiptReadStatus').textContent='Preparando o comprovante…';
  for(const id of ['receiptPayer','receiptAmount','receiptPaymentDate','receiptTransactionId'])el(id).value='';
  try{
   if(!file.size||file.size>MAX)throw Error('Escolha uma imagem ou PDF de até 8 MB.');const bytes=new Uint8Array(await file.arrayBuffer());if(!alive(d)||d.token!==token)return;
   const kind=mime(bytes);if(!kind)throw Error('Formato não aceito. Use JPG, PNG, WebP ou PDF.');const digest=await hash(bytes);if(!alive(d)||d.token!==token)return;if(model.duplicate(state,digest,''))throw Error('Este arquivo já foi utilizado em um pagamento. Nenhuma baixa foi feita.');
   d.bytes=bytes;d.mime=kind;d.attachment={documentId:'pix-'+digest+'-'+id(),hash:digest,name:String(file.name||'comprovante').replace(/[\u0000-\u001f]/g,'').slice(0,160),size:bytes.length,mime:kind};d.url=URL.createObjectURL(new Blob([bytes],{type:kind}));
   if(kind!=='application/pdf'){await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>image.naturalWidth*image.naturalHeight<=40000000?resolve():reject(Error('A imagem é grande demais. Use uma foto menor.'));image.onerror=()=>reject(Error('A imagem está inválida ou danificada. Escolha outro arquivo.'));image.src=d.url});if(!alive(d)||d.token!==token)return}
   el('receiptPreview').hidden=false;el('receiptFileName').textContent=d.attachment.name;el('receiptImage').hidden=kind==='application/pdf';el('receiptOpenPdf').hidden=kind!=='application/pdf';if(kind!=='application/pdf')el('receiptImage').src=d.url;
   el('receiptReadStatus').textContent='Lendo nome, valor e data…';el('receiptManual').hidden=false;
   let text='';if(kind==='application/pdf')try{text=await pdfText(d)}catch(_){}
   if(!alive(d)||d.token!==token)return;const parsed=model.parse(text);
   if(parsed.payer&&parsed.amountCents!==null&&parsed.paymentDate){apply(d,text,'pdf-text');return}
   try{const result=await nativeRead(d);if(alive(d)&&d.token===token)apply(d,result.text||text,result.method||'native-ocr')}
   catch(problem){if(!alive(d)||d.token!==token)return;apply(d,text,text?'pdf-text':'manual');el('receiptReadStatus').textContent=problem.message||'Preencha os dados manualmente e confira o comprovante.'}
  }catch(problem){if(!alive(d)||d.token!==token)return;d.reading=false;el('receiptManual').hidden=true;error(problem.message||'Não foi possível abrir o arquivo.');el('receiptReadStatus').textContent='Escolha outro comprovante para continuar.'}
 }
 window.openFinanceReceipt=function(studentId){
  if(!guard())return toast('Entre com a conta do professor.');const student=studentById(studentId);if(!student?.financeEnabled||!APBilling.date(student.dueDate))return toast('Configure o financeiro e o vencimento deste aluno primeiro.');
  if(draft?.saving)return toast('Aguarde o registro do pagamento.');release(draft);el('financeReceiptForm').reset();error('');
  draft={studentId,scope:scope(),dueDate:student.dueDate,token:++serial,attachment:null,saving:false,reading:false,readMethod:'manual'};el('receiptPayerWarning').hidden=true;el('receiptDateWarning').hidden=true;
  el('receiptStudentName').textContent=student.name;el('receiptDueReference').textContent='Referência: '+fmtDate(student.dueDate)+' · Mensalidade: '+(moneyText(student.monthlyValue)||'valor não informado');el('receiptPayerConfirmation').textContent='Conferi que este crédito pertence a '+student.name+', mesmo que o pagador tenha outro nome.';
  el('receiptPaymentDate').max=today();el('receiptPreview').hidden=true;el('receiptReadText').hidden=true;el('receiptSuspicious').hidden=true;el('receiptDifference').hidden=true;el('receiptReadStatus').textContent='Anexe o comprovante para começar.';el('receiptFile').disabled=false;el('receiptManual').hidden=true;el('receiptFields').disabled=true;el('receiptSubmit').disabled=true;el('receiptSubmit').textContent='Confirmar e dar baixa';openDialog('financeReceiptDialog');
 };
 function fields(d){return {dueDate:d.dueDate,payer:el('receiptPayer').value,amount:el('receiptAmount').value,paymentDate:el('receiptPaymentDate').value,transactionId:el('receiptTransactionId').value,mode:el('receiptMode').value,confirmPayer:el('receiptConfirmPayer').checked,confirmAmount:el('receiptConfirmAmount').checked,confirmDate:el('receiptConfirmDate').checked,confirmDifference:el('receiptConfirmDifference').checked}}
 async function confirm(event){
  event.preventDefault();const d=draft;if(!d||!alive(d)||d.saving||d.reading)return;error('');let stored=false,committed=false,paymentId='';
  try{
   const student=studentById(d.studentId),checked=model.validate(fields(d),student,state,d.attachment),recordedAt=new Date().toISOString();paymentId=id();
   d.saving=true;el('receiptFile').disabled=true;el('receiptFields').disabled=true;el('receiptSubmit').disabled=true;el('receiptSubmit').textContent='Salvando…';
   const receipt={...d.attachment,payer:checked.payer,paymentDate:checked.paymentDate,transactionId:checked.transactionId,readMethod:d.readMethod,confirmedAt:recordedAt,confirmedPayer:true,confirmedAmount:true,confirmedDate:true,differenceAccepted:checked.differenceAccepted};
   await store('put',receipt.documentId,{blob:new Blob([d.bytes],{type:d.mime}),receipt,createdAt:recordedAt});stored=true;
   if(!alive(d))throw Error('A conferência foi encerrada. Nenhum pagamento foi registrado.');
   // Revalidate after the asynchronous file write, before the single durable financial write.
   model.validate(fields(d),studentById(d.studentId),state,d.attachment);
   const saved=JSON.parse(localStorage.getItem(DB_KEY)||'{}'),latest=saved.students?.find(s=>s.id===d.studentId);
   if(model.duplicate(saved,d.attachment.hash,checked.transactionId))throw Error('Este comprovante ou Pix já foi registrado em outra janela.');
   if(!latest||latest.dueDate!==d.dueDate||APBilling.cents(latest.monthlyValue)!==APBilling.cents(student.monthlyValue)||JSON.stringify(saved.payments||[])!==JSON.stringify(state.payments)||JSON.stringify(saved.financeReceiptLedger||[])!==JSON.stringify(state.financeReceiptLedger||[]))throw Error('O financeiro mudou em outra janela. Reabra o aplicativo e confira o pagamento novamente.');
   const payment={id:paymentId,studentId:student.id,studentName:student.name,dueDate:d.dueDate,paidAt:checked.paidAt,paidDatePrecision:'date',recordedAt,amount:(checked.amountCents/100).toFixed(2).replace('.',','),method:'pix',settlesMonthlyFee:checked.settlesMonthlyFee,receipt};
   const changes=checked.settlesMonthlyFee?{lastPaidAt:checked.paidAt,dueDate:addMonthsSafe(d.dueDate,1),paymentOverdue:false,overdueDueDate:'',overdueMarkedAt:''}:{};
   const ledger=[...(Array.isArray(state.financeReceiptLedger)?state.financeReceiptLedger:[]),{hash:receipt.hash,transactionId:receipt.transactionId,paymentId,studentId:student.id,documentId:receipt.documentId,recordedAt}];
   const result=commitFinanceChange(student,changes,'Pix conferido · '+student.name+' · '+money(checked.amountCents)+(checked.settlesMonthlyFee?' · mensalidade quitada':' · recebimento sem quitar'),payment,ledger);
   if(result===null)throw Error('Não foi possível salvar o pagamento. A baixa não foi feita.');committed=true;d.saving=false;closeDialog('financeReceiptDialog');
   toast(checked.settlesMonthlyFee?'Comprovante salvo, pagamento registrado e vencimento atualizado.':'Comprovante e recebimento salvos. O vencimento continua em aberto.',6500);
   if(result==='error')alarmFeedback('error','','');
  }catch(problem){
   if(stored&&!committed&&paymentId)try{committed=JSON.parse(localStorage.getItem(DB_KEY)||'{}').payments?.some(p=>p.id===paymentId)===true}catch(_){}
   if(committed){d.saving=false;closeDialog('financeReceiptDialog');toast('O pagamento e o comprovante foram salvos. Reabra o Financeiro para atualizar a tela.',6500);return}
   if(stored)try{await store('delete',d.attachment.documentId)}catch(_){}if(alive(d)){d.saving=false;el('receiptFile').disabled=false;enabled(d,!!d.attachment);difference();error(problem.message||'Não foi possível registrar o pagamento.')}}
 }
 async function exportFile(record,download){
  if(!guard()||!record?.blob)return;const {blob,receipt}=record;
  if(window.Android){const base64=workoutImportBytesToBase64(new Uint8Array(await blob.arrayBuffer()));if(download&&typeof Android.saveBase64File==='function'){Android.saveBase64File(receipt.name,receipt.mime,base64);return}if(!download&&typeof Android.openBase64File==='function'&&Android.openBase64File(receipt.name,receipt.mime,base64))return}
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=receipt.name||'comprovante';a.rel='noopener';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
 }
 window.viewFinanceReceipt=async function(paymentId){
  if(!guard())return;const payment=state.payments.find(p=>p.id===paymentId),receipt=payment?.receipt;if(!receipt)return toast('Comprovante não encontrado.');if(view?.url)URL.revokeObjectURL(view.url);const token=++serial;view={token,record:null};
  el('receiptViewInfo').innerHTML=[['Aluno',payment.studentName||'Aluno'],['Quem pagou',receipt.payer],['Valor recebido',money(APBilling.cents(payment.amount)||0)],['Data do pagamento',receipt.paymentDate?fmtDate(receipt.paymentDate):'—'],['Referência',payment.dueDate?fmtDate(payment.dueDate):'—'],['Registro',payment.settlesMonthlyFee===false?'Recebimento sem quitar o vencimento':'Mensalidade quitada'],['Identificador Pix',receipt.transactionId||'Não identificado'],['Arquivo',receipt.name]].map(([label,value])=>'<p><strong>'+hesc(label)+'</strong><br>'+hesc(value)+'</p>').join('');
  el('receiptViewImage').hidden=true;el('receiptViewOpen').disabled=true;el('receiptViewSave').disabled=true;el('receiptViewStatus').textContent='Abrindo comprovante…';openDialog('financeReceiptViewDialog');
  try{const record=await store('get',receipt.documentId);if(view?.token!==token||!el('financeReceiptViewDialog').classList.contains('open')||!guard())return;if(!record?.blob)throw Error('O arquivo não está disponível neste aparelho. Os dados do pagamento continuam salvos.');view.record=record;if(receipt.mime.startsWith('image/')){view.url=URL.createObjectURL(record.blob);el('receiptViewImage').src=view.url;el('receiptViewImage').hidden=false}el('receiptViewStatus').textContent='Comprovante original guardado neste aparelho. Salve uma cópia para manter seu backup.';el('receiptViewOpen').disabled=false;el('receiptViewSave').disabled=false}
  catch(problem){if(view?.token===token)el('receiptViewStatus').textContent=problem.message||'Não foi possível abrir o comprovante.'}
 };
 function renderHistory(){
  const all=[...state.payments].sort((a,b)=>String(b.recordedAt||b.paidAt).localeCompare(String(a.recordedAt||a.paidAt)));
  el('paymentsCount').textContent=all.length+' '+(all.length===1?'registro':'registros');
  el('paymentHistory').innerHTML=all.length?all.slice(0,shown).map(p=>{const receipt=p.receipt,value=APBilling.cents(p.amount);return '<article class="payment-row receipt-payment-row"><div><strong>'+hesc(p.studentName||studentById(p.studentId)?.name||'Aluno')+'</strong><strong>'+hesc(value===null?'Valor não informado':money(value))+'</strong><small>Recebido em '+hesc(new Date(p.paidAt).toLocaleDateString('pt-BR'))+(p.dueDate?' · Referência '+hesc(fmtDate(p.dueDate)):'')+'</small>'+(p.settlesMonthlyFee===false?'<small>Recebimento sem quitar o vencimento</small>':'')+(receipt?'<small>Pix · Pagador: '+hesc(receipt.payer)+'</small>':'')+'</div>'+(receipt?'<button class="btn" type="button" data-view-receipt="'+hesc(p.id)+'">Ver comprovante</button>':'')+'</article>'}).join(''):'<div class="empty"><strong>Nenhum pagamento marcado.</strong>Os recebimentos confirmados aparecem aqui.</div>';
  el('receiptShowMore').hidden=all.length<=shown;
 }
 const more=document.createElement('button');more.id='receiptShowMore';more.className='btn';more.type='button';more.textContent='Mostrar mais pagamentos';el('paymentHistory').after(more);more.onclick=()=>{shown+=12;renderHistory()};
 el('paymentHistory').addEventListener('click',event=>{const button=event.target.closest('[data-view-receipt]');if(button)viewFinanceReceipt(button.dataset.viewReceipt)});
 el('receiptFile').onchange=event=>choose(event.target.files[0]);el('financeReceiptForm').onsubmit=confirm;
 el('receiptPayer').oninput=()=>{el('receiptConfirmPayer').checked=false;identityWarnings()};el('receiptPaymentDate').oninput=()=>{el('receiptConfirmDate').checked=false;identityWarnings()};el('receiptPaymentDate').onfocus=identityWarnings;el('receiptTransactionId').oninput=()=>{el('receiptConfirmPayer').checked=false};
 el('receiptAmount').oninput=()=>{el('receiptConfirmAmount').checked=false;el('receiptConfirmDifference').checked=false;difference()};el('receiptMode').onchange=()=>{el('receiptConfirmDifference').checked=false;difference()};
 el('receiptManual').onclick=()=>{const d=draft;if(!d?.attachment||!alive(d))return;d.token=++serial;release({...d,url:''});d.key='';d.reading=false;d.readMethod='manual';enabled(d,true);el('receiptReadStatus').textContent='Confira o comprovante e preencha nome, valor e data manualmente.'};
 el('receiptOpenPdf').onclick=()=>{if(draft?.attachment)exportFile({blob:new Blob([draft.bytes],{type:draft.mime}),receipt:draft.attachment},false).catch(()=>toast('Não foi possível abrir o arquivo.'))};
 el('receiptViewOpen').onclick=()=>exportFile(view?.record,false).catch(()=>toast('Não foi possível abrir o arquivo.'));el('receiptViewSave').onclick=()=>exportFile(view?.record,true).catch(()=>toast('Não foi possível salvar a cópia.'));
 for(const modal of ['financeReceiptDialog','financeReceiptViewDialog'])el(modal).querySelectorAll('[data-close]').forEach(button=>button.onclick=()=>closeDialog(button.dataset.close));
 const closeBefore=closeDialog;closeDialog=function(id){if(draft?.saving&&dialogStack.some(e=>e.id===id)&&dialogStack.findIndex(e=>e.id===id)<=dialogStack.findIndex(e=>e.id==='financeReceiptDialog'))return toast('Aguarde o registro do pagamento.');const result=closeBefore.apply(this,arguments);if(draft&&!el('financeReceiptDialog').classList.contains('open')){release(draft);draft=null;el('receiptImage').removeAttribute('src')}if(view&&!el('financeReceiptViewDialog').classList.contains('open')){if(view.url)URL.revokeObjectURL(view.url);view=null;el('receiptViewImage').removeAttribute('src')}return result};
 const financeBefore=renderFinance;renderFinance=function(){const result=financeBefore.apply(this,arguments);renderHistory();return result};
 window.addEventListener('pagehide',()=>{release(draft);if(view?.url)URL.revokeObjectURL(view.url)});
 renderHistory();
})();
