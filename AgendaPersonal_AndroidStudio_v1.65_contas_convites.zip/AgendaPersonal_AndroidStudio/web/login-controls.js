(function(){
 'use strict';
 const field=document.getElementById('password'),button=document.getElementById('apPasswordVisibility');
 if(!field||!button)return;
 const updates=document.getElementById('apLoginUpdates');
 if(updates&&window.Android?.openUpdates)updates.hidden=false;
 const eye='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';
 const hiddenEye='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 3 18 18M10.6 5.1 12 5c6.5 0 10 7 10 7a19 19 0 0 1-3 3.8M6.3 6.3A20 20 0 0 0 2 12s3.5 7 10 7a12 12 0 0 0 5.7-1.5M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>';
 function apply(visible){
  field.type=visible?'text':'password';button.innerHTML=visible?hiddenEye:eye;
  button.setAttribute('aria-pressed',String(visible));
  button.setAttribute('aria-label',visible?'Ocultar senha':'Mostrar senha');
  button.title=visible?'Ocultar senha':'Mostrar senha';
 }
 window.APresetLoginPasswordVisibility=function(){apply(false)};
 window.APtoggleLoginPassword=function(){
  const start=field.selectionStart,end=field.selectionEnd;apply(field.type==='password');
  field.focus({preventScroll:true});
  try{if(start!==null&&end!==null)field.setSelectionRange(start,end)}catch(_){}
 };
 button.addEventListener('click',window.APtoggleLoginPassword);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)apply(false)});
 apply(false);
})();
