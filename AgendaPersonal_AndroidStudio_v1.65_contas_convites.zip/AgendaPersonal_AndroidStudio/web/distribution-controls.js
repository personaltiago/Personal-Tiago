(function(){
 'use strict';
 const SERVICE='https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site';
 const MAX=24*1024*1024,names=['index.html','professor.html','avaliacoes.html','cadastro.html'];
 let publishing=false,selected=null,focusBefore=null,selectionEpoch=0;
 const $=id=>document.getElementById(id);
 function status(message,kind='info'){const node=$('apPublishStatus');if(node){node.hidden=!message;node.textContent=message;node.dataset.kind=kind}}
 function validate(bundle){
  if(!bundle||bundle.format!==1||bundle.appId!=='com.tiagolima.agendapersonal'||bundle.bridgeVersion!==3||bundle.dataSchema!==4||!Number.isSafeInteger(bundle.sequence)||bundle.sequence<99||bundle.sequence>2147483647||!/^\d+\.\d+\.\d+$/.test(bundle.version||'')||Object.keys(bundle.files||{}).length!==4||names.some(n=>typeof bundle.files[n]!=='string'||!bundle.files[n].toLowerCase().includes('</html>')||n!=='cadastro.html'&&!bundle.files[n].includes('data-agenda-ready')||bundle.files[n].includes('window.__agendaNativeReleaseToken=')))throw Error('Escolha uma atualização compatível da Agenda Personal.');
  return bundle;
 }
 function canInstall(){try{return !window.__AP_STUDENT_CONTEXT||window.__AP_STUDENT_CONTEXT.role!=='student'||Object.keys(exStore().active).length===0}catch(_){return false}}
 function refreshNotice(){
  if(!window.Android?.getUpdateStatus)return;
  try{
   const state=JSON.parse(Android.getUpdateStatus()),release=state.manifest,newer=release?.available&&release.sequence>state.installedSequence;
   let card=$('apUpdateNotice'),root=$('homeScroll');
   if(!card&&root){card=document.createElement('button');card.id='apUpdateNotice';card.type='button';card.className='ap-update-notice';card.onclick=()=>APaccounts.openUpdates();root.prepend(card)}
   if(card){card.hidden=!newer;card.textContent=newer?'Nova versão '+release.version+' disponível · Atualizar':''}
   const option=$('apProfileUpdates');if(option){option.dataset.available=String(!!newer);const note=option.querySelector('small');if(note)note.textContent=newer?'Nova versão '+release.version+' disponível':'Verifique e instale novidades do aplicativo'}
  }catch(_){}
 }
 function closePublisher(){
  if(publishing){status('Aguarde o envio terminar.');return false}
  const modal=$('apUpdatePublisher');if(modal)modal.hidden=true;selected=null;selectionEpoch++;focusBefore?.focus();return true;
 }
 function openPublisher(){
  if(!APaccounts.isTeacher()){toast('Entre como professor para publicar atualizações.');return false}
  if(!window.Android?.getPublishableUpdate){toast('Instale o APK 1.70 para publicar e distribuir pelo aplicativo.');return false}
  let modal=$('apUpdatePublisher');
  if(!modal){
   modal=document.createElement('div');modal.id='apUpdatePublisher';modal.className='ap-update-publisher';
   modal.innerHTML='<section class="ap-publish-sheet" role="dialog" aria-modal="true" aria-labelledby="apPublishTitle"><header><div><small>CONTA DO PROFESSOR</small><h2 id="apPublishTitle">Atualizações para os alunos</h2></div><button id="apPublishClose" type="button" aria-label="Fechar">×</button></header><p class="ap-publish-description">Publique uma versão uma única vez. Os alunos recebem o aviso e atualizam pelo próprio aplicativo.</p><div class="ap-publish-source"><button id="apPublishCurrent" type="button">Usar a versão deste aparelho</button><span>ou escolha uma atualização recebida</span><label class="ap-publish-file">Escolher arquivo .agenda.json<input id="apPublishFile" type="file" accept=".json,application/json"></label></div><p id="apPublishSelected" hidden></p><label class="ap-publish-label" for="apPublishNotes">O que mudou nesta versão?</label><textarea id="apPublishNotes" maxlength="1200" rows="3" placeholder="Descreva as melhorias que os alunos vão receber."></textarea><p id="apPublishStatus" role="status" aria-live="polite" hidden></p><button id="apPublishSend" type="button" disabled>Publicar para os alunos</button><p class="ap-publish-footnote">Publicar disponibiliza o programa. Os dados das contas e os registros dos treinos ficam em cada aparelho.</p></section>';
   document.body.appendChild(modal);
   $('apPublishClose').onclick=closePublisher;$('apPublishCurrent').onclick=useCurrent;
   $('apPublishFile').addEventListener('change',event=>chooseFile(event.target.files?.[0]));
   $('apPublishSend').onclick=publish;
   modal.addEventListener('click',event=>{if(event.target===modal)closePublisher()});
  }
  if(publishing)return false;
  focusBefore=document.activeElement;selected=null;selectionEpoch++;$('apPublishSend').disabled=true;$('apPublishSelected').hidden=true;$('apPublishFile').value='';$('apPublishNotes').value='';status('');modal.hidden=false;$('apPublishCurrent').focus();return true;
 }
 function setSelection(text){
  if(new TextEncoder().encode(text).byteLength>MAX)throw Error('O pacote ultrapassa 24 MB.');
  const bundle=validate(JSON.parse(text));selected={text,bundle};
  $('apPublishSelected').textContent='Versão '+bundle.version+' · '+(new TextEncoder().encode(text).byteLength/1048576).toFixed(1)+' MB';$('apPublishSelected').hidden=false;$('apPublishSend').disabled=false;status('Revise a versão e as novidades antes de publicar.');
 }
 async function useCurrent(){
  if(publishing||!APaccounts.isTeacher())return;
  const token=++selectionEpoch;status('Preparando a versão deste aparelho…');await new Promise(resolve=>setTimeout(resolve,30));
  if(token!==selectionEpoch)return;
  try{setSelection(Android.getPublishableUpdate())}catch(_){selected=null;$('apPublishSend').disabled=true;status('Não foi possível preparar esta versão. Escolha o arquivo de atualização.','error')}
 }
 async function chooseFile(file){
  if(publishing||!APaccounts.isTeacher()||!file)return;
  const token=++selectionEpoch;selected=null;$('apPublishSend').disabled=true;
  try{if(file.size>MAX)throw Error('O pacote ultrapassa 24 MB.');const text=await file.text();if(token===selectionEpoch)setSelection(text)}catch(error){if(token===selectionEpoch)status(error.message||'O arquivo está incompleto.','error')}
 }
 async function publish(){
  if(publishing||!selected)return false;
  if(!APaccounts.isTeacher()){status('Entre como professor para publicar.','error');return false}
  publishing=true;for(const id of ['apPublishCurrent','apPublishFile','apPublishSend','apPublishNotes'])$(id).disabled=true;
  const chosen=selected;status('Enviando e publicando a atualização…');
  try{
   const token=await APaccounts.getPublicationToken();
   const response=await fetch(SERVICE+'/api/publish',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token,'X-Release-Notes':encodeURIComponent($('apPublishNotes').value.trim())},body:chosen.text,signal:AbortSignal.timeout(90000)});
   const result=await response.json();if(!response.ok||!result.published)throw Error(result.error||'Não foi possível publicar.');
   status('Versão '+result.manifest.version+' publicada. Os alunos poderão atualizar pelo aplicativo.','success');
   if(window.Android?.applyPublishedUpdate&&canInstall())Android.applyPublishedUpdate(JSON.stringify(result.manifest));
   return true;
  }catch(error){status(error.name==='TimeoutError'?'O envio demorou. Consulte a versão publicada antes de tentar novamente.':error.message||'Confira a conexão e tente novamente.','error');return false}
  finally{publishing=false;for(const id of ['apPublishCurrent','apPublishFile','apPublishSend','apPublishNotes'])$(id).disabled=false}
 }
 window.APupdates=Object.freeze({openPublisher,closePublisher,refreshNotice,canInstall});
 window.addEventListener('ap-account-changed',()=>{if(!APaccounts.isTeacher()&&!publishing){const modal=$('apUpdatePublisher');if(modal)modal.hidden=true;selected=null}refreshNotice()});
 window.addEventListener('online',refreshNotice);
 refreshNotice();
})();
