(function(){
 'use strict';
 const SERVICE='https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site';
 const bridge=()=>window.Android||window.APWebPlatform;
 const MAX=24*1024*1024,names=['index.html','professor.html','avaliacoes.html','cadastro.html'];
 let publishing=false,selected=null,focusBefore=null,selectionEpoch=0;
 const $=id=>document.getElementById(id);
 function status(message,kind='info'){const node=$('apPublishStatus');if(node){node.hidden=!message;node.textContent=message;node.dataset.kind=kind}}
 function resetProgress(){const box=$('apPublishProgress');if(box){box.hidden=true;delete box.dataset.state;$('apPublishProgressBar').value=0;$('apPublishProgressPercent').textContent='0%'}}
 function progress(phase,loaded,total,seconds=null){
  const box=$('apPublishProgress');if(!box)return;const appeared=box.hidden;box.hidden=false;box.dataset.state=phase;if(appeared)box.scrollIntoView?.({block:'nearest'});
  const percent=total>0?Math.min(100,Math.floor(loaded/total*100)):0,mb=n=>(n/1048576).toLocaleString('pt-BR',{minimumFractionDigits:1,maximumFractionDigits:1});
  $('apPublishProgressTitle').textContent=phase==='confirming'?'Confirmando publicação':phase==='done'?'Publicação concluída':phase==='error'?'Publicação não confirmada':phase==='authorizing'?'Preparando envio':'Enviando arquivo';
  const bar=$('apPublishProgressBar');if(phase==='authorizing'||!total){bar.removeAttribute('value');$('apPublishProgressPercent').textContent='—'}else{bar.value=percent;$('apPublishProgressPercent').textContent=percent+'% do envio'}
  $('apPublishProgressDetails').textContent=total>0?mb(Math.min(loaded,total))+' de '+mb(total)+' MB':phase==='authorizing'?'Confirmando sua sessão…':'Medindo os dados enviados…';
  let eta=phase==='confirming'?'Arquivo enviado. Aguardando a confirmação do servidor.':phase==='done'?'Mesma versão confirmada para Android, iPhone e navegador.':phase==='error'?'Confira a mensagem abaixo.':phase==='authorizing'?'O contador começa quando o envio iniciar.':'Calculando tempo restante…';
  if(phase==='uploading'&&Number.isFinite(seconds)&&seconds>0){const rounded=Math.max(1,Math.ceil(seconds)),time=rounded<60?rounded+' s':Math.ceil(rounded/60)+' min';eta='Estimativa: cerca de '+time+' restantes.'}
  $('apPublishProgressEta').textContent=eta;
 }
 function upload(chosen,token){return new Promise((resolve,reject)=>{
  const xhr=new XMLHttpRequest(),total=new TextEncoder().encode(chosen.text).byteLength;let loaded=0,started=Date.now(),lastTime=started,lastLoaded=0,speed=0;
  xhr.open('POST',SERVICE+'/api/publish');xhr.timeout=600000;xhr.setRequestHeader('Content-Type','application/json');xhr.setRequestHeader('Authorization','Bearer '+token);xhr.setRequestHeader('X-Release-Notes',encodeURIComponent($('apPublishNotes').value.trim()));
  function update(event){if(!event.lengthComputable){progress('uploading',0,0);return}const now=Date.now(),dt=(now-lastTime)/1000;loaded=Math.min(event.loaded,event.total);if(dt>=.25){const measured=Math.max(0,loaded-lastLoaded)/dt;speed=speed?speed*.65+measured*.35:measured;lastTime=now;lastLoaded=loaded}const seconds=now-started>=1000&&speed>0?(event.total-loaded)/speed:null;progress(loaded>=event.total?'confirming':'uploading',loaded,event.total,seconds)}
  xhr.upload.addEventListener('progress',update);xhr.upload.addEventListener('load',()=>{loaded=total;progress('confirming',total,total);status('Arquivo enviado. Confirmando publicação…')});
  const fail=message=>{progress('error',loaded,total);reject(Error(message))};
  xhr.onload=()=>{let result;try{result=JSON.parse(xhr.responseText)}catch(_){fail('O servidor não confirmou a publicação. Consulte a versão disponível antes de reenviar.');return}if(xhr.status<200||xhr.status>=300||!result.published||!result.manifest){fail(result.error||'Não foi possível publicar.');return}resolve(result)};
  xhr.onerror=()=>fail('A conexão foi interrompida. Consulte a versão publicada antes de tentar novamente.');xhr.ontimeout=()=>fail('O envio demorou. Consulte a versão publicada antes de tentar novamente.');xhr.onabort=()=>fail('O envio foi interrompido. Consulte a versão publicada.');
  progress('uploading',0,total);started=lastTime=Date.now();xhr.send(chosen.text);
 })}
 async function verifyPublication(chosen,result){
  const bytes=new TextEncoder().encode(chosen.text),hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),n=>n.toString(16).padStart(2,'0')).join('');
  const matches=m=>m?.available===true&&m.version===chosen.bundle.version&&m.sequence===chosen.bundle.sequence&&m.size===bytes.length&&m.sha256===hash;
  if(!matches(result.manifest))throw Error('O servidor confirmou um arquivo diferente. Consulte a publicação antes de reenviar.');
  const response=await fetch(SERVICE+'/api/manifest?verify='+Date.now(),{cache:'no-store',signal:globalThis.AbortSignal?.timeout?.(20000)});
  if(!response.ok||!matches(await response.json()))throw Error('O arquivo foi enviado, mas a versão disponível para Android e iPhone ainda não foi confirmada. Consulte a publicação antes de reenviar.');
  return result.manifest;
 }
 function validate(bundle){
  // Keep the runtime marker out of this source literal: the page itself is
  // shipped inside the bundle and must also pass the original APK 1.70 check.
  const nativeMarker='window.__agendaNativeReleaseToken'+'=';
  if(!bundle||bundle.format!==1||bundle.appId!=='com.tiagolima.agendapersonal'||bundle.bridgeVersion!==3||bundle.dataSchema!==4||!Number.isSafeInteger(bundle.sequence)||bundle.sequence<99||bundle.sequence>2147483647||!/^\d+\.\d+\.\d+$/.test(bundle.version||'')||Object.keys(bundle.files||{}).length!==4||names.some(n=>typeof bundle.files[n]!=='string'||!bundle.files[n].toLowerCase().includes('</html>')||n!=='cadastro.html'&&!bundle.files[n].includes('data-agenda-ready')||bundle.files[n].includes(nativeMarker)))throw Error('Escolha uma atualização compatível da Agenda Personal.');
  return bundle;
 }
 function canInstall(){try{const frame=document.getElementById('apPreviewTeacher'),teacher=frame?.contentWindow;if(frame?.getClientRects?.()?.length&&teacher?.APFeedbackTeacher?.canUpdate?.()===false)return false;return !window.__AP_STUDENT_CONTEXT||window.__AP_STUDENT_CONTEXT.role!=='student'||Object.keys(exStore().active).length===0}catch(_){return false}}
 function refreshNotice(){
  if(!bridge()?.getUpdateStatus)return;
  try{
   const state=JSON.parse(bridge().getUpdateStatus()),release=state.manifest,newer=release?.available&&release.sequence>state.installedSequence;
   window.dispatchEvent(new CustomEvent('ap-update-status',{detail:state}));
   let card=$('apUpdateNotice'),root=$('homeScroll');
   const student=window.__AP_STUDENT_CONTEXT?.role==='student';
   if(!card&&root&&!student){card=document.createElement('button');card.id='apUpdateNotice';card.type='button';card.className='ap-update-notice';card.onclick=()=>APaccounts.openUpdates();root.prepend(card)}
   if(card){card.hidden=student||!newer;card.textContent=newer?'Nova versão '+release.version+' disponível · Atualizar':''}
   const option=$('apProfileUpdates');if(option){option.dataset.available=String(!!newer);const note=option.querySelector('small');if(note)note.textContent=newer?'Nova versão '+release.version+' disponível':'Verifique e instale novidades do aplicativo'}
  }catch(_){}
 }
 function closePublisher(){
  if(publishing){status('Aguarde o envio terminar.');return false}
  const modal=$('apUpdatePublisher');if(modal)modal.hidden=true;selected=null;selectionEpoch++;focusBefore?.focus();return true;
 }
 function openPublisher(){
  if(!APaccounts.isTeacher()){toast('Entre como professor para publicar atualizações.');return false}
  if(!bridge()?.getPublishableUpdate){toast('Instale o APK 1.70 para publicar e distribuir pelo aplicativo.');return false}
  let modal=$('apUpdatePublisher');
  if(!modal){
   modal=document.createElement('div');modal.id='apUpdatePublisher';modal.className='ap-update-publisher';
   modal.innerHTML='<section class="ap-publish-sheet" role="dialog" aria-modal="true" aria-labelledby="apPublishTitle"><header><div><small>CONTA DO PROFESSOR</small><h2 id="apPublishTitle">Central de atualizações</h2></div><button id="apPublishClose" type="button" aria-label="Fechar">×</button></header><p class="ap-publish-description">Este aparelho publica a mesma versão para professor e alunos, no Android, no iPhone e no navegador. No iPhone, a instalação acontece quando não há treino ou edição em andamento.</p><p class="ap-publish-description"><a href="https://agenda-personal-distribuicao.silvanaoliveira1411.chatgpt.site/app/" target="_blank" rel="noopener noreferrer">Abrir o aplicativo no iPhone ou navegador ↗</a></p><div class="ap-publish-source"><button id="apPublishCurrent" type="button">Usar a versão deste aparelho</button><span>ou escolha uma atualização recebida</span><label class="ap-publish-file">Escolher arquivo .agenda.json<input id="apPublishFile" type="file" accept=".json,application/json"></label></div><p id="apPublishSelected" hidden></p><label class="ap-publish-label" for="apPublishNotes">O que mudou nesta versão?</label><textarea id="apPublishNotes" maxlength="1200" rows="3" placeholder="Descreva as melhorias que os alunos vão receber."></textarea><div id="apPublishProgress" class="ap-publish-progress" hidden><div class="ap-publish-progress-top"><strong id="apPublishProgressTitle">Enviando arquivo</strong><output id="apPublishProgressPercent">0% do envio</output></div><progress id="apPublishProgressBar" max="100" value="0" aria-label="Porcentagem do envio do arquivo"></progress><p id="apPublishProgressDetails"></p><p id="apPublishProgressEta"></p></div><p id="apPublishStatus" role="status" aria-live="polite" hidden></p><button id="apPublishSend" type="button" disabled>Publicar para Android e iPhone</button><p class="ap-publish-footnote">A publicação só termina quando o servidor confirma. Fotos e fichas são sincronizadas entre as contas vinculadas.</p></section>';
   document.body.appendChild(modal);
   $('apPublishClose').onclick=closePublisher;$('apPublishCurrent').onclick=useCurrent;
   $('apPublishFile').addEventListener('change',event=>chooseFile(event.target.files?.[0]));
   $('apPublishSend').onclick=publish;
   modal.addEventListener('click',event=>{if(event.target===modal)closePublisher()});
  }
  if(publishing)return false;
  focusBefore=document.activeElement;selected=null;selectionEpoch++;$('apPublishSend').disabled=true;$('apPublishSelected').hidden=true;$('apPublishFile').value='';$('apPublishNotes').value='';status('');resetProgress();modal.hidden=false;$('apPublishCurrent').focus({preventScroll:true});const sheet=modal.querySelector('.ap-publish-sheet');if(sheet)sheet.scrollTop=0;return true;
 }
 function setSelection(text){
  if(new TextEncoder().encode(text).byteLength>MAX)throw Error('O pacote ultrapassa 24 MB.');
  const bundle=validate(JSON.parse(text));selected={text,bundle};resetProgress();
  $('apPublishSelected').textContent='Versão '+bundle.version+' · '+(new TextEncoder().encode(text).byteLength/1048576).toFixed(1)+' MB';$('apPublishSelected').hidden=false;$('apPublishSend').disabled=false;status('Revise a versão e as novidades antes de publicar.');
 }
 async function useCurrent(){
  if(publishing||!APaccounts.isTeacher())return;
  const token=++selectionEpoch;status('Preparando a versão deste aparelho…');await new Promise(resolve=>setTimeout(resolve,30));
  if(token!==selectionEpoch)return;
  try{setSelection(bridge().getPublishableUpdate())}catch(_){selected=null;$('apPublishSend').disabled=true;status('Não foi possível preparar esta versão. Escolha o arquivo de atualização.','error')}
 }
 async function chooseFile(file){
  if(publishing||!APaccounts.isTeacher()||!file)return;
  const token=++selectionEpoch;selected=null;$('apPublishSend').disabled=true;resetProgress();
  try{if(file.size>MAX)throw Error('O pacote ultrapassa 24 MB.');const text=await file.text();if(token===selectionEpoch)setSelection(text)}catch(error){if(token===selectionEpoch)status(error.message||'O arquivo está incompleto.','error')}
 }
 async function publish(){
  if(publishing||!selected)return false;
  if(!APaccounts.isTeacher()){status('Entre como professor para publicar.','error');return false}
  publishing=true;for(const id of ['apPublishCurrent','apPublishFile','apPublishSend','apPublishNotes'])$(id).disabled=true;
  const chosen=selected;status('Preparando envio…');progress('authorizing',0,0);
  try{
   const token=await APaccounts.getPublicationToken();
   if(!APaccounts.isTeacher())throw Error('Entre como professor para publicar.');
   const result=await upload(chosen,token);
   await verifyPublication(chosen,result);
   progress('done',new TextEncoder().encode(chosen.text).byteLength,new TextEncoder().encode(chosen.text).byteLength);
   status('Versão '+result.manifest.version+' confirmada para professor e alunos no Android, iPhone e navegador. Aparelhos precisam estar conectados para receber.','success');
   window.dispatchEvent(new Event('ap-central-sync'));
   if(bridge()?.applyPublishedUpdate&&canInstall())bridge().applyPublishedUpdate(JSON.stringify(result.manifest));
   return true;
  }catch(error){const size=new TextEncoder().encode(chosen.text).byteLength;progress('error',$('apPublishProgress')?.dataset.state==='authorizing'?0:size,size);status(error.message||'Confira a conexão e tente novamente.','error');return false}
  finally{publishing=false;for(const id of ['apPublishCurrent','apPublishFile','apPublishSend','apPublishNotes'])$(id).disabled=false}
 }
 window.APupdates=Object.freeze({openPublisher,closePublisher,refreshNotice,canInstall});
 window.addEventListener('ap-account-changed',()=>{if(!APaccounts.isTeacher()&&!publishing){const modal=$('apUpdatePublisher');if(modal)modal.hidden=true;selected=null}refreshNotice()});
 window.addEventListener('online',refreshNotice);
 refreshNotice();
})();
