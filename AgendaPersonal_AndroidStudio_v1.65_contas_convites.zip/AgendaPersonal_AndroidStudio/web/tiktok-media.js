(function(){
 'use strict';
 const cache=new Map(),pending=new Map();let serial=0;
 const valid=id=>/^[0-9]{15,22}$/.test(id||'');
 function id(url){try{return new URL(url).pathname.match(/^\/(?:@[^/]+\/video\/|player\/v1\/)([0-9]{15,22})\/?$/)?.[1]||''}catch(_){return ''}}
 function finish(key,data){const job=pending.get(key);if(job){pending.delete(key);clearTimeout(job.timer);job.done(data)}else try{document.getElementById('apPreviewTeacher')?.contentWindow.workoutTikTokMetadata?.(key,data)}catch(_){}}
 window.workoutTikTokMetadata=finish;
 async function load(url){
  const fallback={videoId:id(url),url,thumbnail:''};let data;
  try{
   if(window.Android){
    if(typeof Android.requestTikTokVideo!=='function')throw Error('Instale o APK 1.117 para a prévia do TikTok.');
    data=await new Promise((resolve,reject)=>{const key='tt_'+Date.now()+'_'+(++serial),timer=setTimeout(()=>{pending.delete(key);reject(Error('A prévia demorou a carregar. Tente novamente.'))},30000);pending.set(key,{timer,done:resolve});try{if(!Android.requestTikTokVideo(JSON.stringify({key,url}))){clearTimeout(timer);pending.delete(key);reject(Error('Não foi possível consultar este vídeo.'))}}catch(e){clearTimeout(timer);pending.delete(key);reject(e)}});
   }else{
    const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),15000);try{const r=await fetch('https://www.tiktok.com/oembed?url='+encodeURIComponent(url),{signal:abort.signal,credentials:'omit'});if(!r.ok)throw Error();const m=await r.json();data={videoId:id(url)||String(m.html||'').match(/data-video-id=["']([0-9]{15,22})/)?.[1],url,thumbnail:m.thumbnail_url}}finally{clearTimeout(timer)}
   }
   if(!data||!valid(data.videoId))throw Error(data?.error||'Confira o link do vídeo.');
   const image=APExternalVideo.normalize(data.thumbnail);return {provider:'tiktok',videoId:data.videoId,startSeconds:0,portrait:true,url,thumbnail:image.startsWith('https://')?image:''};
  }catch(e){if(valid(fallback.videoId))return {...fallback,provider:'tiktok',startSeconds:0,portrait:true};throw e}
 }
 function metadata(value){let url=APExternalVideo.normalize(value);if(!APExternalVideo.isTikTok(url))return Promise.reject(Error('Link do TikTok inválido.'));url=url.replace(/^http:/,'https:');const old=cache.get(url);if(old&&old.until>Date.now())return old.promise;const promise=load(url).catch(e=>{cache.delete(url);throw e});cache.set(url,{until:Date.now()+600000,promise});if(cache.size>64)cache.delete(cache.keys().next().value);return promise}
 function paint(node){const url=node.dataset.tiktokPreview;if(!url||node.dataset.tiktokState)return;node.dataset.tiktokState='loading';metadata(url).then(m=>{if(!node.isConnected||node.dataset.tiktokPreview!==url)return;node.dataset.tiktokState=m.thumbnail?'ready':'unavailable';const img=node.querySelector('img');if(img&&m.thumbnail){img.src=m.thumbnail;img.hidden=false;img.onerror=()=>{img.hidden=true;node.dataset.tiktokState='unavailable'}}}).catch(()=>{if(node.isConnected&&node.dataset.tiktokPreview===url)node.dataset.tiktokState='unavailable'})}
 const observer=typeof IntersectionObserver==='function'?new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){observer.unobserve(e.target);paint(e.target)}}),{rootMargin:'80px'}):null;
 let queued=false;function scan(){queued=false;document.querySelectorAll('[data-tiktok-preview]:not([data-tiktok-state])').forEach(n=>observer?observer.observe(n):paint(n))}
 function schedule(){if(!queued){queued=true;requestAnimationFrame(scan)}}
 function boot(){scan();if(typeof MutationObserver==='function')new MutationObserver(schedule).observe(document.body,{subtree:true,childList:true})}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
 window.addEventListener('message',e=>{if(e.origin==='https://www.tiktok.com'&&e.data?.['x-tiktok-player']===true&&e.data.type==='onPlayerReady')for(const f of document.querySelectorAll('iframe'))if(f.contentWindow===e.source&&f.src.startsWith('https://www.tiktok.com/player/v1/'))f.contentWindow.postMessage({type:'mute','x-tiktok-player':true},e.origin)});
 window.APTikTok={metadata,id,valid,scan:schedule,frameUrl:videoId=>'https://www.tiktok.com/player/v1/'+videoId+'?autoplay=0&controls=1&description=0&music_info=0&muted=0'};
})();
