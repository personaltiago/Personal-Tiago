(function(g){'use strict';
 const ns='http://www.w3.org/2000/svg';
 function region(state,kind,zone){
  if(kind==='ear'&&zone)return {x:zone.x,y:zone.y,rx:.105,ry:.14};
  const zones=g.APMascotHitAreas.zones(state),nose=zones.find(z=>z.part==='nose'),ears=zones.filter(z=>z.part==='ear');
  if(!nose)return null;
  const baby=state.xp<600;
  if(state.species==='alligator')return {x:nose.x+(nose.x<.5?.12:-.12),y:nose.y-.06,rx:.30,ry:baby?.24:.22,left:g.APMascotModel.pose(state).id==='play'?.52:null};
  if(state.species==='rooster')return {x:nose.x+(nose.x<.5?.06:-.06),y:nose.y-(baby?.08:.055),rx:baby?.31:.21,ry:baby?.30:.25};
  const xs=[nose.x,...ears.map(z=>z.x)],top=Math.min(...ears.map(z=>z.y))-.075,bottom=nose.y+.15,left=Math.min(...xs)-.16,right=Math.max(...xs)+.16;
  return {x:(left+right)/2,y:(top+bottom)/2,rx:Math.min(.39,(right-left)*.565),ry:Math.min(.37,(bottom-top)*.56)};
 }
 const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)};
 function project(x,y,r,a,dy){const cx=r.x*320,cy=r.y*320,rx=r.rx*320,ry=r.ry*320,neck=Math.min(cy+ry,256),end=Math.min(cy+ry*.95,256),w=Math.min(1,(end-Math.min(cy+ry*.45,end-20))/(ry*.9))*(1-smooth(.95,1.3,Math.abs((x-cx)/rx)))*(1-smooth(Math.min(cy+ry*.45,end-20),end,y))*(r.left==null?1:.45*smooth(r.left*320,r.left*320+32,x)),q=a*w,c=Math.cos(q),s=Math.sin(q),px=x-cx,py=y-neck;return [cx+px*c-py*s,neck+px*s+py*c+dy*w]}
 function mesh(n=48){const points=[],indices=[];for(let y=0;y<=n;y++)for(let x=0;x<=n;x++)points.push(x*320/n,y*320/n);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const a=y*(n+1)+x,b=a+1,c=a+n+1,d=c+1;indices.push(a,c,b,b,c,d)}return {points:new Float32Array(points),indices:new Uint16Array(indices)}}
 const grid=mesh();
 function gpu(canvas,photo,r){
  const gl=canvas.getContext('webgl',{alpha:true,premultipliedAlpha:true,antialias:false,preserveDrawingBuffer:true,depth:false,stencil:false});if(!gl)return null;
  const shaders=[],buffers=[];let program,texture;
  const dispose=()=>{if(texture)gl.deleteTexture(texture);for(const b of buffers)gl.deleteBuffer(b);if(program)gl.deleteProgram(program);for(const s of shaders)gl.deleteShader(s);gl.getExtension('WEBGL_lose_context')?.loseContext()};
  try{
   function shader(type,source){const s=gl.createShader(type);shaders.push(s);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error('shader');return s}
   program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,`attribute vec2 p;uniform vec4 h;uniform vec2 m;uniform float edge;varying vec2 uv;void main(){float neck=min(h.y+h.w,256.),end=min(h.y+h.w*.95,256.);float w=min(1.,(end-min(h.y+h.w*.45,end-20.))/(h.w*.9))*(1.-smoothstep(.95,1.3,abs((p.x-h.x)/h.z)))*(1.-smoothstep(min(h.y+h.w*.45,end-20.),end,p.y));if(edge>=0.)w*=.45*smoothstep(edge,edge+32.,p.x);float a=m.x*w,c=cos(a),s=sin(a);vec2 q=p-vec2(h.x,neck);vec2 v=vec2(c*q.x-s*q.y,s*q.x+c*q.y)+vec2(h.x,neck+m.y*w);gl_Position=vec4((v.x+16.)/176.-1.,1.-(v.y+16.)/176.,0.,1.);uv=p/320.;}`));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,'precision mediump float;uniform sampler2D photo;varying vec2 uv;void main(){gl_FragColor=texture2D(photo,uv);}'));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('program');gl.useProgram(program);
   const vertices=gl.createBuffer(),indices=gl.createBuffer();buffers.push(vertices,indices);gl.bindBuffer(gl.ARRAY_BUFFER,vertices);gl.bufferData(gl.ARRAY_BUFFER,grid.points,gl.STATIC_DRAW);const pos=gl.getAttribLocation(program,'p');gl.enableVertexAttribArray(pos);gl.vertexAttribPointer(pos,2,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,indices);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,grid.indices,gl.STATIC_DRAW);
   texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,photo);gl.uniform4f(gl.getUniformLocation(program,'h'),r.x*320,r.y*320,r.rx*320,r.ry*320);gl.uniform1f(gl.getUniformLocation(program,'edge'),r.left==null?-1:r.left*320);const motion=gl.getUniformLocation(program,'m');gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(0,0,0,0);
   return {kind:'webgl',draw(a,dy){if(gl.isContextLost())throw Error('context');gl.clear(gl.COLOR_BUFFER_BIT);gl.uniform2f(motion,a,dy);gl.drawElements(gl.TRIANGLES,grid.indices.length,gl.UNSIGNED_SHORT,0)},dispose};
  }catch(_){dispose();return null}
 }
 function cpu(canvas,photo,r){
  const ctx=canvas.getContext('2d'),{points,indices}=mesh(20),scale=canvas.width/352;if(!ctx)return null;
  return {kind:'canvas',dispose(){canvas.width=0},draw(a,dy){ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.scale(scale,scale);ctx.translate(16,16);const moved=[];for(let i=0;i<points.length;i+=2)moved.push(project(points[i],points[i+1],r,a,dy));for(let i=0;i<indices.length;i+=3){const ids=[indices[i],indices[i+1],indices[i+2]],src=ids.map(j=>[points[j*2],points[j*2+1]]),dst=ids.map(j=>moved[j]),[u,v,w]=src,[p,q,t]=dst,det=(v[0]-u[0])*(w[1]-u[1])-(w[0]-u[0])*(v[1]-u[1]),A=((q[0]-p[0])*(w[1]-u[1])-(t[0]-p[0])*(v[1]-u[1]))/det,B=((q[1]-p[1])*(w[1]-u[1])-(t[1]-p[1])*(v[1]-u[1]))/det,C=((t[0]-p[0])*(v[0]-u[0])-(q[0]-p[0])*(w[0]-u[0]))/det,D=((t[1]-p[1])*(v[0]-u[0])-(q[1]-p[1])*(w[0]-u[0]))/det;ctx.save();ctx.beginPath();const cx=(p[0]+q[0]+t[0])/3,cy=(p[1]+q[1]+t[1])/3;for(let j=0;j<3;j++){const x=dst[j][0],y=dst[j][1],d=Math.hypot(x-cx,y-cy)||1;ctx[j?'lineTo':'moveTo'](x+(x-cx)/d*.3,y+(y-cy)/d*.3)}ctx.closePath();ctx.clip();ctx.transform(A,B,C,D,p[0]-A*u[0]-C*u[1],p[1]-B*u[0]-D*u[1]);ctx.drawImage(photo,0,0,320,320);ctx.restore()}}};
 }
 async function start(image,state,kind,zone,reduced){
  const r=region(state,kind,zone);if(!r)return null;const photo=new g.Image();photo.src=image.getAttribute('href');await photo.decode();if(!image.isConnected)return null;
  const doc=image.ownerDocument,root=doc.createElementNS(ns,'g'),holder=doc.createElementNS(ns,'foreignObject');root.dataset.petLocalMotion=kind;root.setAttribute('pointer-events','none');if(image.hasAttribute('transform'))root.setAttribute('transform',image.getAttribute('transform'));for(const [k,v]of Object.entries({x:-16,y:-16,width:352,height:352}))holder.setAttribute(k,v);root.append(holder);
  let canvas,renderer,raf=0,dead=false,lastFrame=-Infinity;const newCanvas=()=>{const c=doc.createElementNS('http://www.w3.org/1999/xhtml','canvas');c.width=c.height=704;c.style.cssText='display:block;width:352px;height:352px;pointer-events:none';holder.replaceChildren(c);return c};canvas=newCanvas();renderer=gpu(canvas,photo,r);if(!renderer){canvas=newCanvas();renderer=cpu(canvas,photo,r)}if(!renderer)return null;root.dataset.petRenderer=renderer.kind;
  const direction=(zone?.x??g.APMascotHitAreas.zones(state).find(z=>z.part==='nose').x)>=r.x?1:-1,duration=kind==='look'?1700:kind==='curious'?1320:kind==='ear'?800:960,zero={a:0,y:0},now=()=>g.performance.now();let began=now(),from=zero,to=zero;
  const clamp=n=>Math.max(-1,Math.min(1,n)),target=point=>kind==='look'?{a:clamp((point.x-r.x)/.6)*.075,y:clamp((point.y-r.y)/.55)*2}:{a:direction*(kind==='ear'?.045:kind==='nose'?.02:.075),y:kind==='ear'?0:-1.6};
  function sample(at){if(reduced)return to;const t=Math.max(0,Math.min(1,(at-began)/duration)),enter=smooth(0,.28,t),leave=1-smooth(.68,1,t);return {a:(from.a+(to.a-from.a)*enter)*leave,y:(from.y+(to.y-from.y)*enter)*leave}}
  function draw(at){if(!renderer)return;const value=sample(at);try{renderer.draw(value.a,value.y)}catch(_){renderer?.dispose();canvas=newCanvas();renderer=cpu(canvas,photo,r);if(renderer){root.dataset.petRenderer=renderer.kind;renderer.draw(value.a,value.y)}}}
  function loop(){if(dead||!root.isConnected)return;const at=now();if(renderer?.kind!=='canvas'||at-lastFrame>=32){draw(at);lastFrame=at}raf=g.requestAnimationFrame(loop)}
  function aim(point,continuing=false){const at=now();from=continuing?sample(at):zero;to=target(point||{x:r.x,y:r.y-.55});began=at;draw(at);return reduced?1050:duration}
  aim(zone);image.parentNode.insertBefore(root,image.nextSibling);image.setAttribute('opacity','0');if(!reduced)raf=g.requestAnimationFrame(loop);
  return {duration:reduced?1050:duration,root,region:r,retarget:point=>aim(point,true),dispose(){dead=true;g.cancelAnimationFrame(raf);renderer?.dispose();root.remove()}};
 }
 g.APMascotCuriosityMotion=Object.freeze({start,region,project});
})(globalThis);
