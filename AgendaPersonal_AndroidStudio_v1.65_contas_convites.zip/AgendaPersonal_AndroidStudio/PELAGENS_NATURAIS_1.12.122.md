# Pelagens naturais · conteúdo 1.12.122 / sequência 228

A aba Cores agora mostra desenhos próprios de cada espécie, com pelagens, manchas, escamas e penas redesenhadas. O filtro genérico azul/vermelho/violeta foi retirado. Cada opção possui imagens próprias nas três fases, preservando o estilo dos mascotes.

| Animal | Opções |
|---|---|
| Lobo | Cinza clássico, Negro, Branco ártico, Areia, Castanho |
| Jacaré | Verde, Oliva, Amarelo areia, Escuro, Marfim |
| Panda | Preto e branco, Todo branco, Todo preto, Castanho e branco, Creme, Canela |
| Gato | Bicolor clássico, Preto, Branco, Laranja tigrado, Cinza tigrado, Tricolor |
| Capivara | Caramelo, Chocolate, Areia, Pardo, Creme |
| Galo | Cobre, Branco, Preto, Carijó, Dourado |

São 32 opções no total. Além dos retratos clássicos preservados, há 81 novas imagens transparentes otimizadas, com olhos/focinhos/bicos/patas naturalmente coloridos e detalhes de pelo, escamas ou penas. Os animais aparecem inteiros; cada retrato é isolado para não mostrar pedaços de outra opção. O jacaré padrão passa a ser verde. Branco e preto nos pandas substituem as manchas da pelagem, em vez de tingir tudo com um filtro.

A escolha continua gratuita e salva separadamente por espécie no mesmo campo colors. Cores antigas são interpretadas como o visual natural correspondente: por exemplo, lobo vermelho vira castanho, lobo dourado vira areia, jacaré azul vira oliva e panda dourado vira creme. Identificadores inválidos não podem selecionar imagens de outra espécie. A leitura não sobrescreve os dados; a escolha canônica é gravada pela próxima ação normal de salvar.

XP, moedas, nome, meta, recompensas, registros de treino, casa, alimentos, brinquedos e itens antigos permanecem preservados. O cache derivado do professor agora confere espécie, fase e pelagem para não mostrar uma imagem antiga como se fosse outra. Falha ao salvar conserva a seleção e os registros anteriores. Os adultos permanecem 18% maiores, com o balão aprovado acima da cabeça. Filhotes e adolescentes mantêm o tamanho anterior.

Aplicação normal: AgendaPersonal-1.12.122.agenda.json. Código completo no nome padrão AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip. Base Android 1.157, sequência 228, bridge 3 e esquema de dados 4; sem necessidade de nova função nativa.

Verificações locais em Chromium: renderização real das opções nas três fases, imagens sem filtros de cor, pixels distintos e recortes transparentes, branco/preto com luminosidades distintas, troca/salvamento/recarga por espécie, conta isolada, rollback de gravação, 320/390/480 px nos temas claro/escuro, tamanho adulto e balão completos. Regressões de aluno/professor e backup completo. Autenticação e rede simuladas; não houve teste em aparelho físico nem publicação externa nesta entrega.

As especificações de geração e a origem dos desenhos estão em web/mascot-coats/PROMPTS.md. As imagens foram criadas com a ferramenta integrada de geração de imagens, usando os retratos de cada fase como referência.
