# Abertura com logo pequeno — Android 1.160

A versão 1.159 foi compilada e instalada, mas o logo inicial continuou grande.
O recurso antigo definia um filho de 112dp dentro de uma camada de 288dp.
Esse tamanho nominal não correspondia ao desenho final do Android.

## Causa e correção

O Android desenha primeiro o ícone em um cache de 108dp. Para um recurso
não adaptativo, amplia os limites do primeiro plano em 1,5 vez e depois
escala o cache para o ícone final de 192dp. O filho de tamanho absoluto
era cortado nesse cache e ampliado novamente, ficando muito maior que
os 112dp do painel nativo.

launch_splash_icon.xml agora usa margens proporcionais de 30,555556%
em cada lado, sem filho com largura/altura fixa. Na área de primeiro
plano de 288dp, isso reserva 112dp para o desenho, sujeito ao arredondamento
de pixels físicos. O painel nativo continua com 112dp e usa o mesmo PNG.
O callback de saída continua removendo o splash sem animação de escala.

Referências da renderização (AOSP):
- https://android.googlesource.com/platform/frameworks/base/+/f68c80b4e9dbdb1e5bf6620f437c3d9f865eb047/libs/WindowManager/Shell/src/com/android/wm/shell/startingsurface/SplashscreenIconDrawableFactory.java — AdaptiveForegroundDrawable e ImmobileIconDrawable.
- https://android.googlesource.com/platform/frameworks/base/+/f68c80b4e9dbdb1e5bf6620f437c3d9f865eb047/libs/WindowManager/Shell/src/com/android/wm/shell/startingsurface/SplashscreenContentDrawer.java — seleção do tamanho final sem fundo do ícone.
- https://developer.android.com/develop/ui/views/launch/splash-screen

## Verificação

LaunchDrawableTest carrega o XML compilado com o carregador de recursos
Android e desenha com Canvas nativo via Robolectric. Reproduz a etapa de
cache/escala do AOSP e compara os limites dos pixels desenhados com um
ImageView nativo de 112dp. Testa Android 12 e 15, em nove densidades.
Uma regressão também recria o recurso antigo e exige que ele seja detectado
como grande demais. A tolerância máxima é de 3dp, correspondente ao
arredondamento do cache e das margens em pixels físicos.

Comando: gradle :app:testDebugUnitTest --tests com.tiagolima.agendapersonal.LaunchDrawableTest
Referências e estrutura: python3 tests/verify_launch_size.py

O movimento inicial da janela ao sair do launcher pertence ao sistema.
O teste de Canvas cobre a imagem do splash e a passagem ao painel nativo;
o comportamento completo no celular ainda exige conferir o novo APK.

Este ajuste exige um novo APK com a assinatura existente. A publicação
de conteúdo 1.12.167 e os dados do usuário continuam sob o controle do
UpdateManager; uma base antiga não substitui conteúdo instalado mais novo.
