# Logo constante durante a abertura

O logo da janela inicial, do painel nativo de carregamento e da tela web deve
ter 112 dp/CSS px. O desenho usado pelas três etapas é o mesmo PNG original.
O ícone adaptativo do launcher permanece separado dessa apresentação.

Em Android 12+, o contêiner de splash mantém 288 dp, conforme o contrato do
sistema; a arte interna fica em 112 dp, centralizada. A saída do splash não
aplica uma segunda animação de escala. A animação de entrada do launcher é
controlada pelo Android.

Verificação de fontes e recursos: `python3 tests/verify_launch_size.py`.

Este ajuste modifica recursos e código nativos. Exige gerar um novo APK com
a mesma assinatura e um versionCode maior pelo fluxo de compilação existente.
Não é uma nova atualização .agenda.json. A publicação de conteúdo 1.12.167
permanece vigente. Nenhum APK foi compilado ou instalado por este ajuste.

Referência: https://developer.android.com/develop/ui/views/launch/splash-screen
