# Logo estável na abertura — Android 1.161

## Diagnóstico do vídeo

No vídeo 1000047412.mp4, analisado a 20 quadros por segundo, a arte visível
fica com aproximadamente 160–161 pixels de largura nas etapas já abertas.
Por volta de 1,45 s, seu centro vertical muda de aproximadamente 636,5 para
655,5 pixels. O defeito restante é principalmente um salto de posição na
passagem do splash do sistema para a área útil do aplicativo. Mais adiante,
a tela web também arredondava os cantos do PNG de forma diferente.

A versão 1.160 já corrige a escala do recurso do sistema com margens
proporcionais de 30,555556%: o primeiro plano de 288dp reserva 112dp para
a arte, sujeito ao arredondamento em pixels físicos. Esse recurso continua
igual nesta versão.

## Correção 1.161

LaunchLoadingLayout mantém o logo no centro da janela completa, levando
em conta a posição real da área útil. Move apenas a arte: o fundo continua
cobrindo a área de conteúdo e os controles de erro/repetição mantêm o fluxo
normal. Não depende de uma altura fixa da barra de status ou de navegação.

O MainActivity mede a geometria da WebView na thread da interface e publica
uma cópia imutável pela ponte Android. NativeLaunch aplica essa posição ao
logo da tela de abertura web, em unidades relativas ao viewport. A imagem
fica com os mesmos 112px e o mesmo contorno original. A atualização também
acompanha alterações do tamanho da janela e de suas margens.

O código de apresentação é inserido pelo APK ao servir a página local.
Assim, alcança o conteúdo atualizado já instalado, inclusive 1.12.167,
sem editar o arquivo ativo, as versões de conteúdo, a conta ou os dados.
A confirmação de abertura e a recuperação do UpdateManager continuam
usando os mesmos tokens e condições.

## Validação

- LaunchDrawableTest: renderização do recurso de splash em Canvas Android
  nativo, Android 12/15 e nove densidades; detecta a ampliação do recurso
  antigo. Quatro casos de teste, sem falhas.
- LaunchLayoutTest: hierarquia Android anexada à janela, sete combinações
  de tamanho/insets, Android 12/15. O centro nativo e a posição fornecida à
  tela web coincidem com o centro da janela. Inclui restauração do fluxo de
  erro e retorno ao carregamento. Dois casos de teste, sem falhas.
- tests/verify_launch_browser.cjs: Chromium real com o CSS e o código de
  apresentação do projeto, sete combinações de viewport/insets/densidade.
  Confere posição física, 112px, contorno, atualização por evento e botão
  de repetição. Também reproduz o deslocamento anterior sem a correção.
- Os testes de atualização/recuperação exigem a presença exata da nova
  apresentação e comparam os demais bytes da página com o conteúdo salvo.

Comandos:
- gradle :app:testDebugUnitTest --tests '*Launch*Test'
- python3 tests/verify_native_updates.py
- python3 tests/verify_recovery_updates.py
- python3 tests/verify_launch_size.py
- node tests/verify_launch_browser.cjs (requer Playwright; opcionalmente use
  PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH para um Chromium já instalado)

A compilação local de QA não usa a chave de distribuição. O GitHub Actions
existente gera o APK final com a assinatura já configurada no repositório.
A abertura completa no aparelho deve ser conferida com o APK 1.161.
O movimento da janela ao sair do launcher é controlado pelo Android.

Referências:
- https://developer.android.com/reference/android/view/View#getLocationInWindow(int[])
- https://developer.android.com/develop/ui/views/launch/splash-screen
- https://android.googlesource.com/platform/frameworks/base/+/f68c80b4e9dbdb1e5bf6620f437c3d9f865eb047/libs/WindowManager/Shell/src/com/android/wm/shell/startingsurface/SplashscreenIconDrawableFactory.java
