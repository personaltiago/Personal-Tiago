# Validação física pendente

Os testes automáticos usam Chromium, identidades sintéticas e funções Android simuladas. Esta lista não registra aprovação física. Execute com dados de teste, em um celular do professor, outro do aluno e um smartwatch Wear OS compatível.

| Verificação | Procedimento | Resultado esperado | Estado |
| --- | --- | --- | --- |
| Sessão | Fechar e reabrir o app; depois sair explicitamente | A sessão válida reabre o início. Após Sair, exige login | Pendente |
| Sem internet | Desconectar o aluno, concluir treino, fechar/reabrir e reconectar | Registro local preservado; envio confirmado uma vez ao professor | Pendente |
| Professor e aluno | Conferir o registro recebido no perfil e na central | Aluno correto, séries completas e valores corretos | Pendente |
| Parcial | Professor salvar uma de três séries | Registro aparece, mas não conta como treino concluído | Pendente |
| Intervalo | Iniciar, minimizar, arrastar, bloquear a tela e esperar | Contagem mantém prazo; aviso ocorre conforme permissões do Android | Pendente |
| Correções | Editar carga marcada e desmarcar; encerrar e reabrir outro treino | Valores corrigidos no histórico; observação do aluno preservada | Pendente |
| Backup | Criar arquivo com uma foto, PDF e comprovante; conferir Downloads | Arquivo existe e pode ser selecionado para conferência | Pendente |
| Restauração | Usar um aparelho de teste da mesma conta; restaurar o arquivo conferido | Dados e anexos recuperados; senha não copiada; login da conta preservado | Pendente |
| Relógio | Enviar, desconectar Bluetooth, executar e reconectar | Treino recebido continua no pulso; resumo retorna ao celular | Pendente |
| Histórico do relógio | Vincular resumo ao aluno correto e tentar repetir inclusão | Origem identificada e uma única entrada, sem cargas inventadas | Pendente |

Os resumos importados no aplicativo do aluno são locais. Não há nova publicação automática desses resumos ao professor pelo serviço remoto nesta entrega. No professor, os resumos vinculados são guardados junto à agenda da conta.

## Feedbacks online e presenciais — pendente em aparelhos reais

- Finalizar uma sessão do professor com aluno vinculado, conferir o aviso no pet no aparelho do aluno e enviar resposta.
- Repetir com telefone sem internet, fechar/reabrir e reconectar; conferir um único pedido e uma única resposta.
- Ocultar o pet e conferir o acesso alternativo. Testar o gesto Voltar sem perder o rascunho.
- Receber no professor com a sessão correta; conferir nome, foto, início, fim, duração e intensidade.
- Conferir a avaliação final do professor no aluno; responder e verificar ambos os textos no cartão. Preparar e salvar/compartilhar imagem pela ponte Android real, sem autorização adicional por feedback.

Atualização 1.12.93: conferir em contas reais o feedback online na central, foto no cartão e avaliação final do professor no pedido presencial; não há autorização adicional por feedback. Política contratual configurada a pedido do proprietário.

## Mascote na abertura — 1.12.94

- Escolher lobo, fechar o app completamente e reabrir: conferir que não aparece capivara durante a abertura.
- Repetir com outro mascote, em cada fase e após atualizar o app: a escolha, o nome, XP, moedas e itens devem permanecer.
- Reabrir após o retrato ter carregado uma vez, com internet desligada: conferir a imagem escolhida.
- Sem cópia local válida, a área aguarda o retrato escolhido sem apresentar outro animal.
- Testes de navegador aprovados; execução em aparelho físico pendente.
