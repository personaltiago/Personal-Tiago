# Balão acima da cabeça — modelo aprovado — 1.12.119

Aplica o modelo escolhido na prévia: balão compacto acima da cabeça, próximo ao animal, com uma ponta curta e curva direcionada ao pet. A cena reserva altura para o texto completo e mantém a posição dos pés entre as fases. O balão acompanha a cabeça do filhote e do adolescente. O nome, o botão Casa e os detalhes do aluno permanecem separados.

Preserva a orientação dos seis animais e as escalas de 70%, 85% e 100%. Substitui o antigo cálculo da ponta horizontal; não altera mensagens, registros, XP, moedas ou itens.

Conteúdo 1.12.119, sequência 225, base Android 1.157. Atualização normal.
