# Cores dos mascotes · conteúdo 1.12.120 / sequência 226

A aba Cores substitui Roupas no aluno e no professor. Cada um dos seis animais tem Original, Preto, Vermelho, Azul, Dourado e Violeta. A lista mostra o próprio bichinho em cada cor. Todas as cores são gratuitas; Aplicar muda o retrato no painel, na casa e no recado de treino concluído.

A escolha fica salva por espécie dentro do mesmo registro do mascote, no campo colors. Trocar de animal recupera sua cor anterior. Original retira a coloração. Registros antigos continuam com as imagens originais até escolher uma cor. Nome, XP, moedas, meta, recompensas, histórico, casa, alimentos, brinquedos e roupas anteriormente compradas/equipadas são preservados. Roupas deixam de ser oferecidas na interface e na loja; seus dados antigos permanecem no modelo.

A coloração usa uma paleta de sombras e luzes aplicada somente ao retrato em SVG, com alfa preservado, sem novas cópias dos 18 arquivos de imagem. Assim também muda os tons neutros do panda. Mantém proporções de crescimento de 70%, 85% e 100%, orientação de cada retrato e o balão aprovado acima da cabeça. A invalidação do retrato em cache do professor inclui a cor. A seleção é salva apenas se a gravação for concluída; falha de armazenamento mantém a cor e o progresso anteriores.

## Aplicação

Atualização normal pelo arquivo AgendaPersonal-1.12.120.agenda.json. Código completo no nome padrão AgendaPersonal_AndroidStudio_v1.65_contas_convites.zip. Não exige nova função nativa; base Android continua 1.157. O ZIP prepara as quatro telas na compilação.

## Verificações

verify_student_mascot_model.cjs: seleções gratuitas e reversíveis nas seis espécies, leitura de registros antigos, validação de cores, progresso e inventário preservados.

verify_mascot_colors.cjs: interações reais na interface de aluno/professor, seis espécies × três fases × seis cores; troca por espécie e recarga; atualização do retrato em cache; falha ao salvar; contas isoladas; teclado e telas de 320, 390 e 480 px nos temas claro/escuro. Rasterização das 108 combinações confirma diferenças visuais de cor e preservação da transparência, incluindo panda.

Regressões: renderização transparente, casas, escolhas de espécie, fluxos de aluno/professor, balão aprovado, crescimento e backup completo com cores por espécie. Testes locais em Chromium, autenticação e rede simuladas; sem teste em aparelho físico ou publicação externa nesta entrega.
