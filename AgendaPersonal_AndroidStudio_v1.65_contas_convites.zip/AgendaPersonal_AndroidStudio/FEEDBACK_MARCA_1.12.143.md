# Marca do feedback — 1.12.143 / sequência 249

O nome do professor foi substituído pelo monograma TL pequeno no cartão de feedback: 54 × 52 px na imagem de 1080 px, na mesma posição do nome anterior. O desenho tem quatro componentes vetoriais e espaços transparentes; não contém a textura, placa, borda ou fundo da imagem de referência.

O símbolo é preenchido com o mesmo tom usado nos títulos e na linha superior do cartão, obtido da cor atual do aplicativo ao preparar a imagem. A prévia, o PNG salvo e o PNG compartilhado usam o mesmo Canvas. Imagens já exportadas são arquivos estáticos; novas imagens acompanham o tema atual.

Verificação no navegador: verde e roxo, pixels de cor idênticos, espaços transparentes, nome ausente, cartão em 1080 px, textos longos, salvar e compartilhar usando os bytes da prévia. Os registros, solicitações e respostas dos feedbacks não foram alterados. O conteúdo 1.12.142, inclusive os gestos do urso, foi preservado.
