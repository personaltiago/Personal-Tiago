# Bravo somente no rosto — 1.12.146 / sequência 252

A reação de bravo não levanta a pata. O urso adulto preto sentado mantém os braços do retrato original; o gesto não seleciona mais a textura da pata levantada. As outras poses do urso não recebem o recuo ou a inclinação da cabeça durante o protesto.

Nas duas poses adultas pretas mostradas nos vídeos — quatro patas e de lado — a expressão agora usa desenhos próprios de rosto bravo, com sobrancelhas franzidas, olhar firme e boca fechada. A composição aproveita somente a região facial dessas texturas; o corpo e as patas vêm integralmente do retrato original. A pata que apoia o rosto na pose de lado está protegida pela mesma máscara. As imagens, suas referências, prompts, hashes e alinhamentos ficam em `web/bear-face-reactions/`.

O carinho com corações e os demais gestos continuam nos caminhos existentes. A alteração de postura do motor R14 ocorre somente na entrada em bravo; a opção de reduzir movimento também mostra a expressão facial estática. As demais fases e pelagens conservam seus desenhos de rosto e recebem o protesto sem deslocamento da cabeça. A pose de barriga para cima continua removida.

Conferência em Chromium local: telas de professor e aluno, modos WebGL e Canvas, mais de 300 mil pixels fora do rosto comparados por pose, patas imóveis, volta ao neutro, toque real de carinho e preservação dos dados. Autenticação simulada e rede externa bloqueada. Não houve teste físico em Android/iPhone nesta execução.

Atualização de conteúdo, Android 1.158, bridgeVersion 3 e dataSchema 4. O `.agenda.json` é o arquivo para subir no aplicativo. A criação do arquivo não publica uma versão no servidor.
