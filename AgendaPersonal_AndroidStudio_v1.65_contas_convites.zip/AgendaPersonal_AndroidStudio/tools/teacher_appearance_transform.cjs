'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const panel='<section id="colorPresetPanel" role="tabpanel" aria-labelledby="colorPresetTab">';assert.ok(doc.includes(panel));
 const mode='<section class="teacher-appearance" aria-labelledby="teacherAppearanceTitle"><div class="color-panel-intro"><h4 id="teacherAppearanceTitle">Modo de exibição</h4><p>Escolha o fundo do painel. Suas cores de destaque são mantidas.</p></div><div class="teacher-appearance-options" role="group" aria-label="Modo de exibição do professor"><button type="button" data-teacher-mode="light" aria-pressed="false" onclick="chooseTeacherAppearance(\'light\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.4 1.4m11.2 11.2L19 19M5 19l1.4-1.4M17.6 6.4 19 5"/></svg><span><strong>Claro</strong><small>Fundo claro</small></span><span class="teacher-appearance-check" aria-hidden="true">✓</span></button><button type="button" data-teacher-mode="dark" aria-pressed="false" onclick="chooseTeacherAppearance(\'dark\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.8 14A9 9 0 0 1 10 3.2 9 9 0 1 0 20.8 14Z"/></svg><span><strong>Escuro</strong><small>Modo noturno</small></span><span class="teacher-appearance-check" aria-hidden="true">✓</span></button></div><p id="teacherAppearanceStatus" class="teacher-appearance-status" role="status" aria-live="polite"></p></section>';
 doc=doc.replace(panel,panel+mode);
 const presetSave='const result=AgendaColors.save(preset);';assert.ok(doc.includes(presetSave));
 doc=doc.replace(presetSave,'const result=AgendaColors.save({...preset,id:"custom",background:AgendaColors.get().background});');
 const selected='const selected=AgendaColors.get().id;';assert.ok(doc.includes(selected));doc=doc.replace(selected,'const current=AgendaColors.get();const selected=AgendaColors.presets.find(p=>p.primary===current.primary&&p.secondary===current.secondary)?.id;');
 const start='function openColorPanel(){';assert.ok(doc.includes(start));doc=doc.replace(start,start+'\n window.AgendaAppearance?.refresh();');
 const old='Cada tema guarda suas próprias cores.';assert.ok(doc.includes(old));doc=doc.replace(old,'Cada tema guarda suas próprias cores e seu modo claro ou escuro.');
 const css=fs.readFileSync(path.resolve(__dirname,'../web/teacher-appearance.css'),'utf8'),js=fs.readFileSync(path.resolve(__dirname,'../web/teacher-appearance.js'),'utf8');
 doc=doc.replace('</head>','<style id="ap-teacher-appearance-css">'+css+'</style></head>');
 return doc.replace('</body>','<script id="ap-teacher-appearance">'+js+'</script></body>');
};
