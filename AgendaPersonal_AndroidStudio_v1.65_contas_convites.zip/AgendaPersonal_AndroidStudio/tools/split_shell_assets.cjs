'use strict';
// Mechanical packaging transformation. The original reference HTML is kept unchanged.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const assets=path.resolve(__dirname,'../app/src/main/assets');
let html=fs.readFileSync(process.argv[2],'utf8');
html=html.replace(/<head>/i,`<head><script id="ap-legacy-storage-bootstrap">(function(){if(!window.Android||location.protocol!=='file:')return;try{var data={};for(var i=0;i<localStorage.length;i++){var key=localStorage.key(i);if(/^(agenda|tiago|ap_)/i.test(key))data[key]=localStorage.getItem(key)}Android.captureLegacyStorage(JSON.stringify(data))}catch(error){Android.bootFailed('AP-MIGRATION-STORAGE')}})();</script>`);
function replaceScript(id,body){const re=new RegExp('(<script id="'+id+'"[^>]*>)[\\s\\S]*?(<\\/script>)');assert.ok(re.test(html),'Missing '+id);html=html.replace(re,(_,open,close)=>open+body+close)}
for(const [id,file]of [['ap-embedded-professor','professor.html'],['ap-embedded-assessments','avaliacoes.html'],['ap-embedded-registration','cadastro.html']]){
 const re=new RegExp('<script id="'+id+'"[^>]*>([\\s\\S]*?)<\\/script>'),match=html.match(re);assert.ok(match,id);
 let doc=Buffer.from(match[1].trim(),'base64').toString('utf8');assert.ok(doc.includes('</html>'),file);
 if(file==='professor.html'){
  doc=doc.replace("u.search='';u.hash='';return registrationUrl(u.toString())", "if(u.hostname==='appassets.androidplatform.net')return '';u.search='';u.hash='';return registrationUrl(u.toString())");
  doc=doc.replace("function currentUrl(){return registrationUrl(state.registrationLink?.url)||publishedPageUrl()}", "function currentUrl(){const stored=registrationUrl(state.registrationLink?.url);return stored&&!stored.includes('appassets.androidplatform.net')?stored:publishedPageUrl()||registrationUrl('https://personaltiago.github.io/Personal-Tiago/cadastro-aluno.html')}");
  doc=doc.replace("el('registrationUrlSetting').value=state.registrationLink?.url||publishedPageUrl();", "el('registrationUrlSetting').value=currentUrl();");
  doc=doc.replace("{ativo:true,aprovadoEm:sdk.serverTimestamp()}","{ativo:true,tipoAluno:type,aprovadoEm:sdk.serverTimestamp()}");
 }
 fs.writeFileSync(path.join(assets,file),doc);
 html=html.replace(re,'<script id="'+id+'" type="application/octet-stream" data-asset="'+file+'"></script>');
}
replaceScript('ap-single-navigation',`
(function(){
'use strict';
const overlay=document.getElementById('apPreviewOverlay'),teacher=document.getElementById('apPreviewTeacher'),assess=document.getElementById('apPreviewAssess'),heading=document.getElementById('apPreviewName'),back=document.getElementById('apPreviewBack');
const status=document.createElement('p');status.id='apPreviewLoadStatus';status.setAttribute('role','status');status.style.cssText='padding:12px 18px;margin:0;background:#17121e;color:#eee';status.hidden=true;overlay.insertBefore(status,teacher);
let isTeacherReady=false,showing='',generation=0;const cache=new Map();
async function decodeSource(id){
 const node=document.getElementById(id),asset=node.dataset.asset;if(cache.has(id))return cache.get(id);
 let doc;if(asset){if(!/^(professor|avaliacoes|cadastro)\\.html$/.test(asset))throw Error('AP-ASSET-NAME');const response=await fetch(new URL(asset,document.baseURI));if(!response.ok)throw Error('AP-ASSET-'+response.status);doc=await response.text()}
 else{const chars=atob(node.textContent.trim()),bytes=Uint8Array.from(chars,c=>c.charCodeAt(0));doc=new TextDecoder('utf-8').decode(bytes)}
 if(!doc.includes('</html>'))throw Error('AP-ASSET-HTML');cache.set(id,doc);return doc;
}
function updateBar(){const active=showing==='assess';heading.textContent=active?'Avaliações corporais — Professor':'Painel do professor';back.textContent=active?'← Professor':'← Entrada';teacher.style.display=active?'none':'block';assess.style.display=active?'block':'none'}
function showError(error){status.hidden=false;status.textContent='Não foi possível abrir esta tela. Volte e tente novamente. Código: '+error.message}
window.APdecodeSource=decodeSource;
window.APopenTeacher=async function(){
 overlay.classList.add('is-open');showing='teacher';updateBar();if(isTeacherReady&&teacher.hasAttribute('srcdoc'))return;
 const token=++generation;status.hidden=false;status.textContent='Abrindo painel do professor…';
 try{const doc=await decodeSource('ap-embedded-professor');if(token!==generation||!overlay.classList.contains('is-open')||!window.APaccounts?.isTeacher())return;teacher.srcdoc=window.APprepareTeacherDocument(doc);isTeacherReady=true}catch(error){isTeacherReady=false;showError(error)}
};
async function openAssess(query){
 if(!overlay.classList.contains('is-open'))return;const token=++generation;status.hidden=false;status.textContent='Abrindo avaliações…';
 try{let doc=await decodeSource('ap-embedded-assessments');if(token!==generation||!overlay.classList.contains('is-open'))return;
 const init='<scr'+'ipt>window.__agendaTestQuery='+JSON.stringify(query?('?'+query):'').replace(/</g,'\\\\u003c')+';</scr'+'ipt>';doc=doc.replace(/<head([^>]*)>/i,m=>m+init);assess.srcdoc=doc;showing='assess';updateBar()}catch(error){showError(error)}
}
function returnToTeacher(){generation++;showing='teacher';status.hidden=true;updateBar()}
function returnToEntry(){generation++;overlay.classList.remove('is-open');showing='';status.hidden=true;assess.removeAttribute('srcdoc')}
window.syncNativeAlarms=function(){try{if(teacher.hasAttribute('srcdoc'))teacher.contentWindow.syncNativeAlarms?.()}catch(_){}};
window.clearWorkoutInlineVideo=function(){try{teacher.contentWindow.clearWorkoutInlineVideo?.()}catch(_){}};
window.workoutInlineVideoError=function(key){try{teacher.contentWindow.workoutInlineVideoError?.(key)}catch(_){}};
window.handleAgendaSystemBack=function(){
 const setup=document.getElementById('apTeacherSetup');if(setup&&!setup.hidden){setup.hidden=true;return true}
 if(overlay.classList.contains('is-open')){const frame=showing==='assess'?assess:teacher;try{const handler=frame.contentWindow.handleAgendaSystemBack;if(typeof handler==='function'&&handler()!==false)return true}catch(_){return true}returnToEntry();return true}
 for(const id of ['exFinishModal','profileEditor','profilePhotoDialog','bgDialog','homeModal','tpThemeOverlay','tpProfileOverlay']){const dialog=document.getElementById(id);if(dialog&&!dialog.hidden){dialog.hidden=true;return true}}
 if(document.getElementById('apStudentPreviewBar')&&!document.getElementById('apStudentPreviewBar').hidden){window.APaccounts.closePreview();return true}
 if(['landing','home'].includes(document.body.dataset.view))return false;agendaBack();return true;
};
for(const frame of [teacher,assess])frame.addEventListener('load',()=>{if(!frame.hasAttribute('srcdoc'))return;try{if(frame.contentWindow.__agendaBootFailed)throw Error('AP-INNER-BOOT');if(frame===teacher&&typeof frame.contentWindow.openRegistrationLink!=='function')throw Error('AP-PROF-INIT');status.hidden=true;window.dispatchEvent(new Event('ap-teacher-ready'))}catch(error){showError(error)}});
back.addEventListener('click',()=>showing==='assess'?returnToTeacher():returnToEntry());
window.addEventListener('message',evt=>{if(evt.source!==teacher.contentWindow&&evt.source!==assess.contentWindow)return;const data=evt.data;if(data?.kind==='AP_OPEN_PROFESSOR_BRAND'&&evt.source===teacher.contentWindow){window.APeditTeacherBrand?.();return}if(data?.kind!=='AP_PREVIEW_ROUTE')return;if(data.screen==='assess'&&evt.source===teacher.contentWindow)openAssess(data.query||'');else if(data.screen==='teacher'&&evt.source===assess.contentWindow)returnToTeacher()});
})();
`);
replaceScript('ap-registration-router',`
(async function(){
 if(!window.__AP_PUBLIC_REGISTER)return;
 try{const source=await window.APdecodeSource('ap-embedded-registration'),root=document.createElement('div'),frame=document.createElement('iframe');root.id='apPublicRegistrationRoot';frame.id='apPublicRegistrationFrame';frame.title='Cadastro de aluno';frame.srcdoc=source;root.appendChild(frame);document.body.appendChild(root)}catch(error){document.documentElement.removeAttribute('data-ap-public-registration');document.body.textContent='Não foi possível abrir o cadastro. Código: '+error.message}
})();
`);
// Keep the production database and assessment linkage. Branding must not hide students.
html=html.replace("catch(e){\nvar m=Object.create(null);var fallback=", "catch(e){\nif(window.Android){window.__agendaRestoreFailed=true;Android.bootFailed('AP-STORAGE');return}\nvar m=Object.create(null);var fallback=");
html=html.replace(/ doc=doc\.replace\("const DB_KEY='agendaPersonalTL_v1';", "const DB_KEY='agendaPersonalTL_TESTE_brand_159';"\);\n/, '');
html=html.replace(/ doc=doc\.replace\("const KEY='agendaPersonalTL_theme_v1';", "const KEY='agendaPersonalTL_TESTE_theme_159';"\);\n/, '');
html=html.replace(/ doc=doc\.replace\("const DESIGN_KEY='agendaPersonalTL_design_v1';", "const DESIGN_KEY='agendaPersonalTL_TESTE_design_159';"\);\n/, '');
html=html.replaceAll('agendaPersonalTL_TESTE_theme_159','agendaPersonalTL_theme_v1').replaceAll('agendaPersonalTL_TESTE_design_159','agendaPersonalTL_design_v1');
const oldRefresh=/function refreshIframe\(\)\{[^\n]+\}/;
assert.ok(oldRefresh.test(html));html=html.replace(oldRefresh,`async function refreshIframe(){const frame=$('apPreviewTeacher');if($('apPreviewOverlay')?.classList.contains('is-open')&&frame){try{const source=await window.APdecodeSource('ap-embedded-professor');if($('apPreviewOverlay').classList.contains('is-open'))frame.srcdoc=window.APprepareTeacherDocument(source)}catch(error){$('apsStatus').textContent='Não foi possível reabrir o painel. '+error.message}}}`);
// Wait for the real iframe readiness, rather than guessing that 700ms is enough.
html=html.replace("if(!open())setTimeout(open,700);", "if(!open())window.addEventListener('ap-teacher-ready',open,{once:true});");
// Native student video playback uses the isolated player WebView, not an untrusted
// YouTube frame in the main WebView that owns the Android data/notification bridge.
html=html.replace('if(video){const media=', 'if(video){if(window.Android?.openYouTubeVideo){try{if(Android.openYouTubeVideo(JSON.stringify({videoId:video,startSeconds:0,title:e.name})))return}catch(_){toast("Não foi possível iniciar o vídeo.");return}}const media=');
html=html.replace("if(e?.video)window.open(e.video,'_blank','noopener,noreferrer');else toast", "if(e?.video){if(window.Android?.openExternal)Android.openExternal(e.video);else window.open(e.video,'_blank','noopener,noreferrer')}else toast");
// Convert embedded-page video coordinates into the top WebView viewport.
const brandReturn=' return doc;\n};';assert.ok(html.includes(brandReturn));
html=html.replace(brandReturn,` doc=doc.replace('</body>','<scr'+'ipt>(function(){if(typeof workoutInlineBounds!=="function"||window.parent===window)return;const original=workoutInlineBounds;workoutInlineBounds=function(video){const b=original(video);try{const r=window.frameElement.getBoundingClientRect();b.left+=r.left;b.top+=r.top;b.clipTop+=r.top;b.clipBottom+=r.top;b.viewportWidth=window.parent.innerWidth;b.viewportHeight=window.parent.innerHeight;b.visible=b.visible&&r.width>0&&r.height>0}catch(e){b.visible=false}return b}})();</scr'+'ipt></body>');\n return doc;\n};`);
assert.equal(html.includes('agendaPersonalTL_TESTE_brand_159'),false);
assert.ok(Buffer.byteLength(html)<2*1024*1024,'Entry page is still too large');
fs.writeFileSync(path.join(assets,'index.html'),html);
console.log('Pages extracted; entry HTML:',Buffer.byteLength(html),'bytes.');
