'use strict';
// Mechanical packaging transformation. The original reference HTML is kept unchanged.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const assets=path.resolve(__dirname,'../app/src/main/assets');
let html=fs.readFileSync(process.argv[2],'utf8');
html=html.replace(/<head>/i,`<head><script id="ap-legacy-storage-bootstrap">(function(){if(!window.Android||location.protocol!=='file:')return;try{var data={};for(var i=0;i<localStorage.length;i++){var key=localStorage.key(i);if(/^(agenda|tiago|ap_)/i.test(key))data[key]=localStorage.getItem(key)}Android.captureLegacyStorage(JSON.stringify(data))}catch(error){Android.bootFailed('AP-MIGRATION-STORAGE')}})();</script>`);
function replaceScript(id,body){const re=new RegExp('(<script id="'+id+'"[^>]*>)[\\s\\S]*?(<\\/script>)');assert.ok(re.test(html),'Missing '+id);html=html.replace(re,(_,open,close)=>open+body+close)}
for(const [id,file]of [['ap-embedded-professor','professor.html'],['ap-embedded-assessments','avaliacoes.html'],['ap-embedded-registration','cadastro.html']]){
 const re=new RegExp('<script id="'+id+'"[^>]*>([\\s\\S]*?)<\\/script>'),match=html.match(re);assert.ok(match,id);
 let doc=Buffer.from(match[1].trim(),'base64').toString('utf8');assert.ok(doc.includes('</html>'),file);
 if(file==='professor.html'){
  doc=require('./finance_countdown_transform.cjs')(doc);
  doc=require('./student_video_transform.cjs').teacher(doc);
  doc=require('./workout_video_gallery_transform.cjs')(doc);
  doc=require('./student_billing_transform.cjs').teacher(doc);
  doc=require('./student_identity_transform.cjs').trainerPacket(doc);
  doc=require('./trainer_profile_transform.cjs')(doc);
  doc=doc.replace('</body>','<script id="ap-teacher-photo-sync">'+fs.readFileSync(path.resolve(__dirname,'../web/teacher-photo-sync.js'),'utf8')+'</script></body>');
  doc=doc.replace("u.search='';u.hash='';return registrationUrl(u.toString())", "if(u.hostname==='appassets.androidplatform.net')return '';u.search='';u.hash='';return registrationUrl(u.toString())");
  doc=doc.replace("function currentUrl(){return registrationUrl(state.registrationLink?.url)||publishedPageUrl()}", "function currentUrl(){const stored=registrationUrl(state.registrationLink?.url);return stored&&!stored.includes('appassets.androidplatform.net')?stored:publishedPageUrl()||registrationUrl('https://personaltiago.github.io/Personal-Tiago/cadastro-aluno.html')}");
  doc=doc.replace("el('registrationUrlSetting').value=state.registrationLink?.url||publishedPageUrl();", "el('registrationUrlSetting').value=currentUrl();");
  doc=doc.replace("{ativo:true,aprovadoEm:sdk.serverTimestamp()}","{ativo:true,tipoAluno:type,aprovadoEm:sdk.serverTimestamp()}");
  const options=/<section class="more-group" aria-labelledby="moreOptionsTitle">[\s\S]*?<\/section>/;
  assert.ok(options.test(doc),'Missing teacher options grid');
  const chevron='<span class="more-chevron"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></span>';
  const logoutCard='<button id="moreAccountLogout" class="more-function more-function-compact" type="button" data-panel-action="logout"><span class="more-function-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 3H4v18h5M10 12h10m-4-4 4 4-4 4"/></svg></span><span class="more-function-copy"><strong>Sair da conta</strong><small>Encerre a sessão neste aparelho.</small></span>'+chevron+'</button>';
  doc=doc.replace(options,section=>section.replace('</div></section>',logoutCard+'</div></section>'));
  assert.ok(doc.includes('id="moreAccountLogout"'));
  const oldAction="else if(action==='updates')openAppUpdates();";
  assert.ok(doc.includes(oldAction));
  doc=doc.replace(oldAction,"else if(action==='logout')requestAccountLogout();\n  else if(action==='brand')requestAccountBrand();\n  "+oldAction);
  const updatesFunction='function openAppUpdates(){';assert.ok(doc.includes(updatesFunction));
  doc=doc.replace(updatesFunction,`function requestAccountLogout(){if(window.parent!==window){window.parent.postMessage({kind:'AP_ACCOUNT_ACTION',action:'logout'},'*');return}window.APaccounts?.logout()}
function requestAccountBrand(){if(window.parent!==window)window.parent.postMessage({kind:'AP_OPEN_PROFESSOR_BRAND'},'*')}
`+updatesFunction);
  // Keep the existing metal/depth renderer so the new exit icon follows the
  // same purple material and theme controls as its neighboring cards.
  const exitShape='logout:\'<path d="M4 2h8v3H7v14h5v3H4z"/><path d="m15 7 6 5-6 5v-3H9v-4h6z"/>\',';
  doc=doc.replace('const solid={\n','const solid={\n  '+exitShape+'\n');
  doc=doc.replace('const solid={...{\n','const solid={...{\n  '+exitShape+'\n');
  doc=doc.replace("if(p?.matches('.more-function[data-panel-action=\"updates\"]'))return 'download';","if(p?.matches('.more-function[data-panel-action=\"logout\"]'))return 'logout';\n  if(p?.matches('.more-function[data-panel-action=\"updates\"]'))return 'download';");
  doc=doc.replace("updates:'download'};","updates:'download',logout:'logout'};");
  const settingsRow='<button type="button" class="pro-menu-row" data-screen="settings">';
  assert.ok(doc.includes(settingsRow));
  doc=doc.replace(settingsRow,'<button type="button" class="pro-menu-row" data-panel-action="brand"><span class="pro-menu-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="7" r="3.5"/><path d="M5 21v-2a7 7 0 0 1 14 0v2z"/></svg></span><span>Personalizar nome, foto e logo</span>'+chevron+'</button>'+settingsRow);
 }
 fs.writeFileSync(path.join(assets,file),doc);
 html=html.replace(re,'<script id="'+id+'" type="application/octet-stream" data-asset="'+file+'"></script>');
}
replaceScript('ap-single-navigation',`
(function(){
'use strict';
const overlay=document.getElementById('apPreviewOverlay'),teacher=document.getElementById('apPreviewTeacher'),assess=document.getElementById('apPreviewAssess'),heading=document.getElementById('apPreviewName'),back=document.getElementById('apPreviewBack');
const status=document.createElement('p');status.id='apPreviewLoadStatus';status.setAttribute('role','status');status.style.cssText='padding:12px 18px;margin:0;background:#17121e;color:#eee';status.hidden=true;overlay.insertBefore(status,teacher);
let isTeacherReady=false,showing='',generation=0;const cache=new Map();
async function decodeSource(id){
 const node=document.getElementById(id),asset=node.dataset.asset;if(cache.has(id))return cache.get(id);
 let doc;if(asset){if(!/^(professor|avaliacoes|cadastro)\\.html$/.test(asset))throw Error('AP-ASSET-NAME');const response=await fetch(new URL(asset,document.baseURI));if(!response.ok)throw Error('AP-ASSET-'+response.status);doc=await response.text()}
 else{const chars=atob(node.textContent.trim()),bytes=Uint8Array.from(chars,c=>c.charCodeAt(0));doc=new TextDecoder('utf-8').decode(bytes)}
 if(!doc.includes('</html>'))throw Error('AP-ASSET-HTML');cache.set(id,doc);return doc;
}
function updateBar(){const active=showing==='assess';heading.textContent=active?'Avaliações corporais — Professor':'Painel do professor';back.textContent=active?'← Professor':'← Entrada';teacher.style.display=active?'none':'block';assess.style.display=active?'block':'none'}
function showError(error){status.hidden=false;status.textContent='Não foi possível abrir esta tela. Volte e tente novamente. Código: '+error.message}
window.APdecodeSource=decodeSource;
window.APopenTeacher=async function(){
 overlay.classList.add('is-open');showing='teacher';updateBar();if(isTeacherReady&&teacher.hasAttribute('srcdoc'))return;
 const token=++generation;status.hidden=false;status.textContent='Abrindo painel do professor…';
 try{const doc=await decodeSource('ap-embedded-professor');if(token!==generation||!overlay.classList.contains('is-open')||!window.APaccounts?.isTeacher())return;teacher.srcdoc=window.APprepareTeacherDocument(doc);isTeacherReady=true}catch(error){isTeacherReady=false;showError(error)}
};
async function openAssess(query){
 if(!overlay.classList.contains('is-open'))return;const token=++generation;status.hidden=false;status.textContent='Abrindo avaliações…';
 try{let doc=await decodeSource('ap-embedded-assessments');if(token!==generation||!overlay.classList.contains('is-open'))return;
 const init='<scr'+'ipt>window.__agendaTestQuery='+JSON.stringify(query?('?'+query):'').replace(/</g,'\\\\u003c')+';</scr'+'ipt>';doc=doc.replace(/<head([^>]*)>/i,m=>m+init);assess.srcdoc=doc;showing='assess';updateBar()}catch(error){showError(error)}
}
function returnToTeacher(){generation++;showing='teacher';status.hidden=true;updateBar()}
function returnToEntry(){generation++;overlay.classList.remove('is-open');showing='';status.hidden=true;assess.removeAttribute('srcdoc')}
window.syncNativeAlarms=function(){try{if(teacher.hasAttribute('srcdoc'))teacher.contentWindow.syncNativeAlarms?.()}catch(_){}};
window.clearWorkoutInlineVideo=function(){try{teacher.contentWindow.clearWorkoutInlineVideo?.()}catch(_){}};
window.workoutInlineVideoError=function(key){try{teacher.contentWindow.workoutInlineVideoError?.(key)}catch(_){}};
window.handleAgendaSystemBack=function(){
 const publisher=document.getElementById('apUpdatePublisher');if(publisher&&!publisher.hidden){window.APupdates.closePublisher();return true}
 const menu=document.getElementById('apTeacherMoreMenu');if(menu&&!menu.hidden){menu.hidden=true;document.getElementById('apTeacherMoreToggle').setAttribute('aria-expanded','false');return true}
 const setup=document.getElementById('apTeacherSetup');if(setup&&!setup.hidden){setup.hidden=true;return true}
 if(overlay.classList.contains('is-open')){const frame=showing==='assess'?assess:teacher;try{const handler=frame.contentWindow.handleAgendaSystemBack;if(typeof handler==='function'&&handler()!==false)return true}catch(_){return true}returnToEntry();return true}
 for(const id of ['exFinishModal','profileEditor','profilePhotoDialog','bgDialog','homeModal','tpThemeOverlay','tpProfileOverlay']){const dialog=document.getElementById(id);if(dialog&&!dialog.hidden){dialog.hidden=true;return true}}
 if(document.getElementById('apStudentPreviewBar')&&!document.getElementById('apStudentPreviewBar').hidden){window.APaccounts.closePreview();return true}
 if(['landing','home'].includes(document.body.dataset.view))return false;agendaBack();return true;
};
for(const frame of [teacher,assess])frame.addEventListener('load',()=>{if(!frame.hasAttribute('srcdoc'))return;try{if(frame.contentWindow.__agendaBootFailed)throw Error('AP-INNER-BOOT');if(frame===teacher&&typeof frame.contentWindow.openRegistrationLink!=='function')throw Error('AP-PROF-INIT');status.hidden=true;window.dispatchEvent(new Event('ap-teacher-ready'))}catch(error){showError(error)}});
back.addEventListener('click',()=>showing==='assess'?returnToTeacher():returnToEntry());
window.addEventListener('message',evt=>{if(evt.source!==teacher.contentWindow&&evt.source!==assess.contentWindow)return;const data=evt.data;if(data?.kind==='AP_ACCOUNT_ACTION'&&evt.source===teacher.contentWindow){if(data.action==='logout'&&window.APaccounts?.isTeacher())window.APaccounts.logout();return}if(data?.kind==='AP_OPEN_PROFESSOR_BRAND'&&evt.source===teacher.contentWindow){window.APeditTeacherBrand?.();return}if(data?.kind!=='AP_PREVIEW_ROUTE')return;if(data.screen==='assess'&&evt.source===teacher.contentWindow)openAssess(data.query||'');else if(data.screen==='teacher'&&evt.source===assess.contentWindow)returnToTeacher()});
})();
`);
replaceScript('ap-registration-router',`
(async function(){
 if(!window.__AP_PUBLIC_REGISTER)return;
 try{const source=await window.APdecodeSource('ap-embedded-registration'),root=document.createElement('div'),frame=document.createElement('iframe');root.id='apPublicRegistrationRoot';frame.id='apPublicRegistrationFrame';frame.title='Cadastro de aluno';frame.srcdoc=source;root.appendChild(frame);document.body.appendChild(root)}catch(error){document.documentElement.removeAttribute('data-ap-public-registration');document.body.textContent='Não foi possível abrir o cadastro. Código: '+error.message}
})();
`);
// Keep the production database and assessment linkage. Branding must not hide students.
html=html.replace("catch(e){\nvar m=Object.create(null);var fallback=", "catch(e){\nif(window.Android){window.__agendaRestoreFailed=true;Android.bootFailed('AP-STORAGE');return}\nvar m=Object.create(null);var fallback=");
html=html.replace(/ doc=doc\.replace\("const DB_KEY='agendaPersonalTL_v1';", "const DB_KEY='agendaPersonalTL_TESTE_brand_159';"\);\n/, '');
html=html.replace(/ doc=doc\.replace\("const KEY='agendaPersonalTL_theme_v1';", "const KEY='agendaPersonalTL_TESTE_theme_159';"\);\n/, '');
html=html.replace(/ doc=doc\.replace\("const DESIGN_KEY='agendaPersonalTL_design_v1';", "const DESIGN_KEY='agendaPersonalTL_TESTE_design_159';"\);\n/, '');
html=html.replaceAll('agendaPersonalTL_TESTE_theme_159','agendaPersonalTL_theme_v1').replaceAll('agendaPersonalTL_TESTE_design_159','agendaPersonalTL_design_v1');
// Branding seeds a profile once; an explicitly saved profile must survive reopening.
const profileSeed='if(p){state.trainerProfile={name:p.name,subtitle:p.description,photoDataUrl:p.photo||""};';
assert.ok(html.includes(profileSeed));
html=html.replace(profileSeed,'if(p&&!state.trainerProfile?.profileEdited){state.trainerProfile={...(state.trainerProfile||{}),name:p.name,subtitle:p.description,photoDataUrl:p.photo||""};');
const oldRefresh=/function refreshIframe\(\)\{[^\n]+\}/;
assert.ok(oldRefresh.test(html));html=html.replace(oldRefresh,`async function refreshIframe(){const frame=$('apPreviewTeacher');if($('apPreviewOverlay')?.classList.contains('is-open')&&frame){try{const source=await window.APdecodeSource('ap-embedded-professor');if($('apPreviewOverlay').classList.contains('is-open'))frame.srcdoc=window.APprepareTeacherDocument(source)}catch(error){$('apsStatus').textContent='Não foi possível reabrir o painel. '+error.message}}}`);
// Wait for the real iframe readiness, rather than guessing that 700ms is enough.
html=html.replace("if(!open())setTimeout(open,700);", "if(!open())window.addEventListener('ap-teacher-ready',open,{once:true});");
// Native student video playback uses the isolated player WebView, not an untrusted
// YouTube frame in the main WebView that owns the Android data/notification bridge.
html=require('./student_video_transform.cjs').student(html);
html=html.replace('if(video){const media=', 'if(video){if(window.Android?.openYouTubeVideo){try{if(Android.openYouTubeVideo(JSON.stringify({videoId:video,startSeconds:0,title:e.name})))return}catch(_){toast("Não foi possível iniciar o vídeo.");return}}const media=');
html=html.replace("if(e?.video)window.open(e.video,'_blank','noopener,noreferrer');else toast", "if(e?.video){if(window.Android?.openExternal)Android.openExternal(e.video);else window.open(e.video,'_blank','noopener,noreferrer')}else toast");
// Convert embedded-page video coordinates into the top WebView viewport.
const brandReturn=' return doc;\n};';assert.ok(html.includes(brandReturn));
html=html.replace(brandReturn,` doc=doc.replace('</body>','<scr'+'ipt>(function(){if(typeof workoutInlineBounds!=="function"||window.parent===window)return;const original=workoutInlineBounds;workoutInlineBounds=function(video){const b=original(video);try{const r=window.frameElement.getBoundingClientRect();b.left+=r.left;b.top+=r.top;b.clipTop+=r.top;b.clipBottom+=r.top;b.viewportWidth=window.parent.innerWidth;b.viewportHeight=window.parent.innerHeight;b.visible=b.visible&&r.width>0&&r.height>0}catch(e){b.visible=false}return b}})();</scr'+'ipt></body>');\n return doc;\n};`);
// A normal exercise has one [exercise, series] tuple per round. The old nested
// tuple was mistaken for a bi-set and looked up a nonexistent exercise "0,0".
const soloOrder="Array.from({length:e.sets},(_,round)=>[[index,round]])";
assert.ok(html.includes(soloOrder));html=html.replace(soloOrder,"Array.from({length:e.sets},(_,round)=>[index,round])");
// Account actions belong in the profile/menu, never over the student's tabs.
html=html.replace(/<style id="ap-session-actions-css">[\s\S]*?<\/style>/,'');
html=html.replace(/<div id="apSessionActions"[^>]*>[\s\S]*?<\/div>/,'');
const profileSettings='<button type="button" class="profile-option" onclick="profileSettings()">';
assert.ok(html.includes(profileSettings));
html=html.replace(profileSettings,'<button id="apProfileUpdates" type="button" class="profile-option" onclick="APaccounts.openUpdates()"><span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m-4-4 4 4 4-4M4 16v5h16v-5"/></svg></span><div><strong>Atualizações</strong><small>Verifique e instale novidades do aplicativo</small></div><span class="profile-chevron" data-profile-icon="chevron"></span></button>'+profileSettings);
const moreWrap=html.match(/<div id="apTeacherMoreWrap">[\s\S]*?<\/div><\/div>/);
assert.ok(moreWrap,'Teacher account menu missing');
let menu=moreWrap[0];
const teacherActions=[['Alunos e convites','openRegistrations'],['Atualizações','openUpdates'],['Sair da conta','logout']].map(([label,action])=>'<button type="button" onclick="document.getElementById(\'apTeacherMoreMenu\').hidden=true;document.getElementById(\'apTeacherMoreToggle\').setAttribute(\'aria-expanded\',\'false\');APaccounts.'+action+'()">'+label+'</button>').join('');
menu=menu.replace('</div></div>',teacherActions+'</div></div>');
html=html.replace(moreWrap[0],'');
html=html.replace(/(<div id="apPreviewTop">[^\n]*?)<\/div>/,(_,top)=>top+menu+'</div>');
html=html.replace('</head>',`<style id="ap-account-navigation-css">
#apPreviewOverlay #apPreviewTop{display:none!important}#apPreviewName{min-width:0;flex:1}#apPreviewTop #apEditBrand{display:none}
#apPreviewTop #apTeacherMoreWrap{display:block!important;position:relative;right:auto;bottom:auto;margin-left:auto;flex:0 0 auto}
#apTeacherMoreMenu{top:calc(100% + 8px);bottom:auto;max-width:calc(100vw - 24px);min-width:210px;z-index:20}
#apPreviewTop #apTeacherMoreMenu button{min-height:44px;border-radius:0;background:transparent;border:0;font:400 14px Arial,sans-serif;padding:12px;text-align:left}
#apPreviewTop #apTeacherMoreMenu button+button{border-top:1px solid #40364b}
body[data-ap-preview="true"] #profileScreen [onclick="profileLogout()"]{display:none}
.student-home .home-next-workout{height:auto;min-height:70px;padding-top:10px;padding-bottom:10px}
.home-next-text{min-width:0;flex:1}.home-next-text strong{display:block;white-space:normal;overflow-wrap:anywhere;line-height:1.35}
.home-next-text>span{flex-wrap:wrap;row-gap:6px}.home-chevron{flex-shrink:0}
</style></head>`);
// Production login controls. Remove the unused demo handler and its credentials.
const demoLogin=/el\('form'\)\.addEventListener\('submit',e=>\{[\s\S]*?\n\}\);\nfunction selectGender/;
assert.ok(demoLogin.test(html));html=html.replace(demoLogin,'function selectGender');
const demoTip=/<p class="tip">Acesso de teste:[\s\S]*?<\/p>/;
assert.ok(demoTip.test(html));html=html.replace(demoTip,'');
html=html.replace('onclick="toast(\'Recuperação de senha será ativada com Firebase.\')"','id="apPasswordReset" onclick="APaccounts.resetPassword()"');
const passwordInput='<input id="password" type="password" autocomplete="current-password" placeholder="Sua senha" required>';
assert.ok(html.includes(passwordInput));html=html.replace(passwordInput,'<div class="ap-password-control">'+passwordInput+'<button id="apPasswordVisibility" class="ap-password-visibility" type="button" aria-label="Mostrar senha" aria-controls="password" aria-pressed="false"></button></div>');
html=html.replace('<section class="login" id="login"><button class="back" onclick="back()">← Voltar</button>','<section class="login" id="login"><div class="ap-login-header"><button class="back" onclick="back()">← Voltar</button><button id="apLoginUpdates" class="link" type="button" onclick="APaccounts.openUpdates()" hidden>Atualizações</button></div>');
const accountStatus='<p id="apAccountStatus" role="status" hidden></p>';assert.ok(html.includes(accountStatus));
html=html.replace(accountStatus,'');
html=html.replace('<button class="primary" type="submit">Entrar →</button></form>','<button class="primary" type="submit">Entrar →</button><p id="apAccountStatus" role="status" aria-live="polite" aria-atomic="true" hidden></p></form>');
assert.ok(html.includes('aria-live="polite" aria-atomic="true"'));
html=html.replace('</head>',`<style id="ap-login-controls-css">
.ap-password-control{display:flex;align-items:center;gap:8px}.ap-password-control input{min-width:0;flex:1}
.ap-login-header{display:flex;align-items:center;justify-content:space-between;gap:14px}.ap-login-header .link{padding:8px 0;min-height:40px;font-size:13px}
.ap-password-visibility{display:grid;place-items:center;flex:0 0 44px;width:44px;height:44px;margin:-8px -8px -8px 0;padding:10px;border:0;border-radius:10px;background:transparent;color:#ccc5d4;touch-action:manipulation}
.ap-password-visibility svg{display:block;width:23px;height:23px}.ap-password-visibility:focus-visible{outline:2px solid #f33c87;outline-offset:2px}.ap-password-visibility[aria-pressed="true"]{color:#ff91bc}
#login #apAccountStatus{position:static;inset:auto;z-index:auto;width:100%;box-sizing:border-box;margin:16px 0 0;padding:13px 14px;border:1px solid #8b435f;border-radius:12px;background:#301623;color:#ffd2e1;font-size:14px;line-height:1.5;overflow-wrap:anywhere}
#login #apAccountStatus[data-kind="info"]{border-color:#574763;background:#201726;color:#e1d5ec}#login #apAccountStatus[data-kind="success"]{border-color:#3d7257;background:#15291e;color:#c3efcf}#login #apAccountStatus[hidden]{display:none!important}
#apPasswordReset:disabled{opacity:.55;cursor:wait}
@media(max-width:370px){#login .row{gap:10px;flex-wrap:wrap}}
</style></head>`);
html=html.replace('let sdk=null,loading=null,identity=null,epoch=0,loginBusy=false,pumping=false', 'let sdk=null,loading=null,identity=null,epoch=0,loginBusy=false,resetBusy=false,resetAvailableAt=0,pumping=false');
const oldNotice="function notice(message){const element=document.getElementById('apAccountStatus');if(element){element.textContent=message;element.hidden=!message}}";
assert.ok(html.includes(oldNotice));html=html.replace(oldNotice,"function notice(message,kind='error'){const element=document.getElementById('apAccountStatus');if(element){element.textContent=message;element.hidden=!message;element.dataset.kind=kind}if(message&&!identity&&document.body.dataset.view==='landing')route('login')}");
html=html.replace('function clear(){epoch++;stop();', 'function clear(){window.APresetLoginPasswordVisibility?.();epoch++;stop();');
html=html.replace("function showLogin(type){current=type;", "function showLogin(type){window.APresetLoginPasswordVisibility?.();const status=el('apAccountStatus');if(status){status.hidden=true;status.textContent=''}current=type;");
html=html.replace("agendaNavTrack(view);\n  document.body.dataset.view=view;", "agendaNavTrack(view);\n  if(view!=='login')window.APresetLoginPasswordVisibility?.();\n  document.body.dataset.view=view;");
html=html.replace('if(loginBusy)return;if(!user)', 'if(loginBusy||resetBusy)return;if(!user)');
html=html.replace('event.stopImmediatePropagation();if(loginBusy)return;', 'event.stopImmediatePropagation();if(loginBusy||resetBusy)return;');
html=html.replace("notice('Entrando…');", "notice('Entrando…','info');");
const resetFunction=`
 async function resetPassword(){
  if(resetBusy||loginBusy)return false;
  const input=document.getElementById('email'),email=input.value.trim().toLowerCase(),button=document.getElementById('apPasswordReset');
  if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)){notice('Preencha seu e-mail acima para recuperar a senha.');input.focus();return false}
  if(Date.now()<resetAvailableAt){notice('Aguarde um minuto antes de solicitar outro e-mail.','info');return false}
  resetBusy=true;if(button)button.disabled=true;notice('Solicitando recuperação de senha…','info');
  try{await ensure();await sdk.sendPasswordResetEmail(sdk.auth,email);resetAvailableAt=Date.now()+60000;notice('Se houver uma conta com esse e-mail, você receberá as instruções para criar uma nova senha. Confira também a pasta de spam.','success');return true}
  catch(error){if(error?.code==='auth/user-not-found'){resetAvailableAt=Date.now()+60000;notice('Se houver uma conta com esse e-mail, você receberá as instruções para criar uma nova senha. Confira também a pasta de spam.','success');return true}notice(errorText(error));return false}
  finally{resetBusy=false;if(button)button.disabled=false}
 }
`;
html=html.replace(' async function logout(){',resetFunction+' async function logout(){');
html=html.replace('Object.freeze({login,logout,openRegistrations', 'Object.freeze({login,logout,resetPassword,openRegistrations');
const controls=fs.readFileSync(path.resolve(__dirname,'../web/login-controls.js'),'utf8');
html=html.replace('</body></html>','<script id="ap-login-controls">'+controls+'</script></body></html>');
// Central publication uses a fresh Firebase ID token from the teacher account.
html=html.replace('function clear(){window.APresetLoginPasswordVisibility?.();',"function clear(){window.Android?.setUpdateAccount?.('');window.APresetLoginPasswordVisibility?.();");
html=html.replace('identity=null;preview=null;',"identity=null;window.dispatchEvent(new Event('ap-account-changed'));preview=null;");
html=html.replace("document.body.dataset.apAccount='teacher';notice('');", "document.body.dataset.apAccount='teacher';window.Android?.setUpdateAccount?.(user.uid);window.dispatchEvent(new Event('ap-account-changed'));notice('');");
html=html.replace("document.body.dataset.apAccount='student';notice('');", "document.body.dataset.apAccount='student';window.Android?.setUpdateAccount?.(user.uid);window.dispatchEvent(new Event('ap-account-changed'));notice('');");
html=html.replace(' async function resetPassword(){'," async function getPublicationToken(){await ensure();if(!teacher())throw Error('Entre como professor para publicar.');return sdk.auth.currentUser.getIdToken(true)}\n async function resetPassword(){");
html=html.replace('Object.freeze({login,logout,resetPassword,', 'Object.freeze({login,logout,resetPassword,getPublicationToken,');
const distribution=fs.readFileSync(path.resolve(__dirname,'../web/distribution-controls.js'),'utf8');
html=html.replace('</head>','<style id="ap-distribution-progress-css">'+fs.readFileSync(path.resolve(__dirname,'../web/distribution-progress.css'),'utf8')+'</style></head>');
html=html.replace('</body></html>','<script id="ap-distribution-controls">'+distribution+'</script></body></html>');
html=html.replace('</head>',`<style id="ap-distribution-css">
.ap-update-notice{display:block;width:100%;margin:0 0 16px;padding:14px 16px;text-align:left;white-space:normal;border:1px solid #775186;border-radius:12px;background:#21172c;color:#f2d8fd;font:600 14px/1.45 system-ui}.ap-update-notice[hidden]{display:none!important}
.ap-update-publisher[hidden]{display:none!important}.ap-update-publisher{position:fixed;inset:0;z-index:2147483600;display:flex;justify-content:center;align-items:center;padding:18px;background:#050409dc;overflow-y:auto;color:#f5eff8;font:14px/1.5 system-ui}
.ap-publish-sheet{width:100%;max-width:480px;max-height:calc(100dvh - 36px);overflow:auto;padding:24px;border:1px solid #57415f;border-radius:20px;background:#17111e;box-shadow:0 20px 60px #0008}
.ap-publish-sheet header{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.ap-publish-sheet header small{font-size:10px;letter-spacing:.12em;color:#ce99c9}.ap-publish-sheet h2{margin:5px 0 0;font-size:22px;line-height:1.25}.ap-publish-sheet header button{flex-shrink:0;width:40px;height:40px;border:1px solid #624c6b;border-radius:10px;color:#eee;background:transparent;font-size:24px}
.ap-publish-description{margin:18px 0;color:#c8bbcf}.ap-publish-source{padding:16px;border:1px solid #43334d;border-radius:12px;display:grid;gap:12px;text-align:center}.ap-publish-source>span{font-size:12px;color:#b8a9c0}.ap-publish-source button,.ap-publish-file{display:block;padding:12px;border:1px solid #6a4f75;border-radius:10px;background:#261b30;color:#f0dff7;font:600 14px system-ui;cursor:pointer}.ap-publish-file input{display:block;width:100%;margin-top:10px;font:12px system-ui;color:#cfc1d7}.ap-publish-label{display:block;margin:20px 0 8px;font-weight:600}.ap-publish-sheet textarea{display:block;width:100%;box-sizing:border-box;resize:vertical;min-height:90px;border:1px solid #6a4f75;border-radius:10px;padding:12px;background:#100c15;color:#f4eaf8;font:14px/1.5 system-ui}.ap-publish-sheet button:disabled{opacity:.55}
#apPublishSend{width:100%;min-height:48px;margin-top:16px;padding:12px;border:1px solid #dd5595;border-radius:12px;background:#9c3166;color:#fff;font:700 14px system-ui}#apPublishStatus{margin:16px 0 0;padding:12px;border:1px solid #624c6b;border-radius:10px;overflow-wrap:anywhere}#apPublishStatus[data-kind="error"]{color:#ffc3d6;border-color:#a95872}#apPublishStatus[data-kind="success"]{color:#c7ebda;border-color:#548c70}.ap-publish-footnote{margin:16px 0 0;color:#b6a5bf;font-size:12px;line-height:1.5}#apPublishSelected{color:#ead4f4;font-weight:600}
</style></head>`);
html=html.replaceAll("email:'aluno@teste.com'", "email:''");
html=require('./student_identity_transform.cjs').trainerPacket(html);
html=require('./student_identity_transform.cjs').studentIdentity(html);
html=html.replace("return APstudentStorage.getItem(profilePhotoKey())||context()?.area?.profile?.photo||''", "if(APstudentStorage.getItem(profilePhotoKey()+'_removed_v1')==='true')return '';return APstudentStorage.getItem(profilePhotoKey())||context()?.area?.profile?.photo||''");
const photoToken=' async function getPhotoToken(){await ensure();if(!identity||sdk.auth.currentUser?.uid!==identity.uid||identity.role!=="teacher"&&(identity.role!=="student"||window.__AP_STUDENT_CONTEXT?.storageId!==identity.uid))throw Error("Entre novamente na sua conta.");return sdk.auth.currentUser.getIdToken(false)}\n';
html=html.replace(' async function getPublicationToken(){',photoToken+' async function getPublicationToken(){');
html=html.replace('Object.freeze({login,logout,resetPassword,getPublicationToken,','Object.freeze({login,logout,resetPassword,getPublicationToken,getPhotoToken,');
html=html.replace('window.APstudentUI.activate();',"window.APstudentUI.activate();window.dispatchEvent(new Event('ap-student-ready'));");
html=html.replace('<p id="profileDemoInfo"','<p id="apStudentPhotoSyncStatus" class="ap-photo-sync-status" role="status" hidden></p><p id="profileDemoInfo"');
html=html.replace('<h3 id="photoModalTitle">Sua foto de perfil</h3>','<h3 id="photoModalTitle">Sua foto de perfil</h3><p id="apStudentPhotoModalStatus" class="ap-photo-sync-status" role="status" hidden></p>');
html=html.replace('</body></html>','<script id="ap-photo-sync">'+fs.readFileSync(path.resolve(__dirname,'../web/photo-sync.js'),'utf8')+'</script></body></html>');
html=html.replace('</head>','<style>.ap-photo-sync-status{font:12px/1.5 Arial,sans-serif;opacity:.8;margin:10px 0 16px;overflow-wrap:anywhere}.ap-photo-sync-status[hidden]{display:none!important}</style></head>');
assert.ok(html.includes('id="ap-login-controls"')&&html.includes('async function resetPassword()'));
assert.equal(html.includes('Acesso de teste:'),false);assert.equal(html.includes('aluno@teste.com'),false);
assert.equal(html.includes('agendaPersonalTL_TESTE_brand_159'),false);
html=require('./home_assessments_transform.cjs')(html);
const studentSyncedStatus="area?'Treino atualizado pelo professor.':'Aguardando o professor disponibilizar seu treino.'";
assert.ok(html.includes(studentSyncedStatus),'Student sync success message');
html=html.replace(studentSyncedStatus,"area?'':'Aguardando o professor disponibilizar seu treino.'");
html=require('./student_notifications_transform.cjs')(html);
html=require('./home_daily_message_transform.cjs')(html);
html=require('./student_billing_transform.cjs').student(html);
html=require('./workout_muscle_preview_transform.cjs')(html);
assert.ok(Buffer.byteLength(html)<2*1024*1024,'Entry page is still too large');
fs.writeFileSync(path.join(assets,'index.html'),html);
console.log('Pages extracted; entry HTML:',Buffer.byteLength(html),'bytes.');
