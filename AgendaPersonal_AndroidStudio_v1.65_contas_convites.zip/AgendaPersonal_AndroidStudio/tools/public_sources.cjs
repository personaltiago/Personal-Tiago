'use strict';
// Public hosting copies are generated from the same sources as the native app.
const fs=require('node:fs'),path=require('node:path');
const names=['teacher-sync.js','teacher-sync-model.js','teacher-sync-preferences.js','teacher-sync.css'];
function sync(root=path.resolve(__dirname,'..')){
 for(const name of names){const source=fs.readFileSync(path.join(root,'web',name)),target=path.join(root,'web/web-app',name);if(!fs.existsSync(target)||!source.equals(fs.readFileSync(target)))fs.writeFileSync(target,source)}
}
module.exports={names,sync};
