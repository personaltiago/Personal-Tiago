"""Inspect the compiled APK itself, not merely its filename or ZIP integrity."""
from pathlib import Path
import json
import hashlib
import argparse
import os
import re
import shutil
import subprocess
from zipfile import ZipFile


def locate_aapt(sdk):
    candidates = list((Path(sdk)/'build-tools').glob('*/aapt'))
    candidates.sort(key=lambda p: tuple(int(v) for v in re.findall(r'\d+', p.parent.name)), reverse=True)
    return next((p for p in candidates if os.access(p, os.X_OK)), None)


def verify(apk, sdk, release, expected_code, expected_assets=None):
    aapt = locate_aapt(sdk)
    if not aapt:
        raise RuntimeError('O SDK não tem aapt. Instale Android SDK Build-Tools antes de gerar o APK.')
    badging = subprocess.run([str(aapt), 'dump', 'badging', str(apk)], check=True, text=True, stdout=subprocess.PIPE).stdout
    package = re.search(r"^package: name='([^']+)' versionCode='(\d+)' versionName='([^']+)'", badging, re.M)
    if not package or package.groups() != (release['applicationId'], str(expected_code), release['androidVersion']):
        raise RuntimeError('O APK compilado não corresponde ao aplicativo/versão esperado. Nenhum APK foi publicado na pasta principal.')
    manifest = subprocess.run([str(aapt), 'dump', 'xmltree', str(apk), 'AndroidManifest.xml'], check=True, text=True, stdout=subprocess.PIPE).stdout
    if 'android.permission.SYSTEM_ALERT_WINDOW' not in manifest or 'LessonTimerOverlayService' not in manifest:
        raise RuntimeError('O manifesto do APK está sem a permissão ou o serviço de cronômetro flutuante.')
    with ZipFile(apk) as archive:
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise RuntimeError('O APK tem entradas duplicadas. Nenhum APK foi disponibilizado.')
        if archive.testzip() is not None:
            raise RuntimeError('O APK compilado está corrompido.')
        expected_assets = Path(expected_assets) if expected_assets else Path(__file__).resolve().parents[1]/'app/src/main/assets'
        try:
            identity = json.loads(archive.read('assets/agenda-build.json'))
            expected = json.loads((expected_assets/'agenda-build.json').read_text())
        except (KeyError, OSError, ValueError) as error:
            raise RuntimeError('O APK está sem a identificação verificável do conteúdo atual.') from error
        versions = {'format': 1, 'applicationId': release['applicationId'], 'androidVersion': release['androidVersion'], 'versionCode': expected_code, 'contentVersion': release['contentVersion'], 'sequence': release['sequence']}
        if not isinstance(identity, dict) or identity != expected or any(identity.get(k) != v for k, v in versions.items()):
            raise RuntimeError('O conteúdo dentro do APK não corresponde à atualização atual. Nenhum APK foi disponibilizado.')
        release_file = expected_assets.parents[3]/'release.json'
        if identity.get('sourceSha256') != hashlib.sha256(release_file.read_bytes()).hexdigest():
            raise RuntimeError('O APK foi preparado com uma identificação de fontes diferente da atual.')
        names = [n+'.html' for n in ['index', 'professor', 'avaliacoes', 'cadastro']]
        if not isinstance(identity.get('files'), dict) or set(identity['files']) != set(names):
            raise RuntimeError('A identificação do APK não contém as quatro telas esperadas.')
        for page in ['index', 'professor', 'avaliacoes', 'cadastro']:
            name = page+'.html'
            try:
                actual = archive.read('assets/'+name)
                wanted = (expected_assets/name).read_bytes()
            except (KeyError, OSError) as error:
                raise RuntimeError('Tela ausente no APK: '+page) from error
            if b'</html>' not in actual:
                raise RuntimeError('Tela incompleta no APK: '+page)
            if actual != wanted or hashlib.sha256(actual).hexdigest() != identity['files'][name]:
                raise RuntimeError('O APK contém uma tela diferente da atualização atual: '+page+'. Nenhum APK foi disponibilizado.')
        teacher = archive.read('assets/professor.html')
        for token in [b'id="financeResults"', b'ap-finance-results-model', b'APIconMaterial', b'ap-compact-week-agenda', b'showLessonTimerOverlay']:
            if token not in teacher:
                raise RuntimeError('O APK está sem uma das atualizações de financeiro, semana ou cronômetro.')
        if not any(b'LessonTimerOverlayService' in archive.read(n) for n in archive.namelist() if re.fullmatch(r'classes\d*\.dex', n)):
            raise RuntimeError('O APK está sem o serviço nativo do cronômetro flutuante.')
    signer = Path(aapt).with_name('apksigner')
    if signer.is_file() and os.access(signer, os.X_OK):
        subprocess.run([str(signer), 'verify', str(apk)], check=True)
    return package.group(3)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Conferir identidade e conteúdo real do APK gerado.')
    parser.add_argument('apk', type=Path)
    parser.add_argument('--sdk', default=os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT'))
    args = parser.parse_args()
    try:
        if not args.sdk:
            raise RuntimeError('Configure ANDROID_HOME para conferir o APK.')
        root = Path(__file__).resolve().parents[1]
        release = json.loads((root/'release.json').read_text())
        code = int(os.environ.get('ANDROID_VERSION_CODE', release['versionCode']))
        verify(args.apk, args.sdk, release, code, root/'app/src/main/assets')
        print('APK conferido: Android '+release['androidVersion']+' / conteúdo '+release['contentVersion']+' / sequência '+str(release['sequence'])+'.')
    except (RuntimeError, OSError, ValueError, KeyError, subprocess.CalledProcessError) as error:
        parser.exit(1, 'CONFERÊNCIA INTERROMPIDA: '+str(error)+'\n')
