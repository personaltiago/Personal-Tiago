"""Inspect the compiled APK itself, not merely its filename or ZIP integrity."""
from pathlib import Path
import json
import os
import re
import shutil
import subprocess
from zipfile import ZipFile


def locate_aapt(sdk):
    candidates = list((Path(sdk)/'build-tools').glob('*/aapt'))
    candidates.sort(key=lambda p: tuple(int(v) for v in re.findall(r'\d+', p.parent.name)), reverse=True)
    return next((p for p in candidates if os.access(p, os.X_OK)), None)


def verify(apk, sdk, release, expected_code):
    aapt = locate_aapt(sdk)
    if not aapt:
        raise RuntimeError('O SDK não tem aapt. Instale Android SDK Build-Tools antes de gerar o APK.')
    badging = subprocess.run([str(aapt), 'dump', 'badging', str(apk)], check=True, text=True, stdout=subprocess.PIPE).stdout
    package = re.search(r"^package: name='([^']+)' versionCode='(\d+)' versionName='([^']+)'", badging, re.M)
    if not package or package.groups() != (release['applicationId'], str(expected_code), release['androidVersion']):
        raise RuntimeError('O APK compilado não corresponde ao aplicativo/versão esperado. Nenhum APK foi publicado na pasta principal.')
    manifest = subprocess.run([str(aapt), 'dump', 'xmltree', str(apk), 'AndroidManifest.xml'], check=True, text=True, stdout=subprocess.PIPE).stdout
    if 'android.permission.SYSTEM_ALERT_WINDOW' not in manifest or 'LessonTimerOverlayService' not in manifest:
        raise RuntimeError('O manifesto do APK está sem a permissão ou o serviço de cronômetro flutuante.')
    with ZipFile(apk) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('O APK compilado está corrompido.')
        for page in ['index', 'professor', 'avaliacoes', 'cadastro']:
            if b'</html>' not in archive.read('assets/'+page+'.html'):
                raise RuntimeError('Tela incompleta no APK: '+page)
        teacher = archive.read('assets/professor.html')
        for token in [b'id="financeResults"', b'ap-finance-results-model', b'APIconMaterial', b'ap-compact-week-agenda', b'showLessonTimerOverlay']:
            if token not in teacher:
                raise RuntimeError('O APK está sem uma das atualizações de financeiro, semana ou cronômetro.')
        if not any(b'LessonTimerOverlayService' in archive.read(n) for n in archive.namelist() if re.fullmatch(r'classes\d*\.dex', n)):
            raise RuntimeError('O APK está sem o serviço nativo do cronômetro flutuante.')
    signer = Path(aapt).with_name('apksigner')
    if signer.is_file() and os.access(signer, os.X_OK):
        subprocess.run([str(signer), 'verify', str(apk)], check=True)
    return package.group(3)
