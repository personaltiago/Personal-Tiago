'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=n=>fs.readFileSync(path.resolve(__dirname,'../web/'+n),'utf8');
function replace(doc,from,to){assert.ok(doc.includes(from),'Workout correction anchor: '+from.slice(0,100));return doc.replace(from,to)}
function patchScript(doc,marker,patch){const start=doc.indexOf('<script '+marker),a=doc.indexOf('>',start)+1,b=doc.indexOf('</script>',a);assert.ok(start>=0&&a>start&&b>a,marker);return doc.slice(0,a)+patch(doc.slice(a,b))+doc.slice(b)}
module.exports=function(doc){
 doc=patchScript(doc,'data-agenda-workout-series',s=>{
  s=replace(s,'editable=interactive&&!row.done','editable=interactive');
  s=replace(s,"${interactive&&current?'':' disabled'}","${interactive&&(current||row.done)?'':' disabled'}");
  s=s.replaceAll('oninput="saveWorkoutSeriesInput(this)"','oninput="saveWorkoutSeriesInput(this)" onblur="APWorkoutCorrections.validateInput(this)"');
  s=replace(s,"if(!ctx||ctx.row.done||!['load','reps'].includes(field))return;","if(!ctx||!['load','reps'].includes(field))return;\n    if(ctx.row.done&&field==='reps'&&(!Number.isInteger(Number(input.value))||Number(input.value)<1||Number(input.value)>999))return;");
  s=replace(s,'[field]:String(input.value).slice(0,60)};','[field]:ctx.row.done?(field===\'load\'?workoutSeriesRecordedLoad(input.value).slice(0,60):Number(input.value)):String(input.value).slice(0,60)};');
  s=replace(s,'if(ctx.row.done){input.checked=true;return;}',`if(ctx.row.done){
      const value=state.workoutDrafts[workoutDraftKey(ctx.plan.id,ctx.day.id)].values?.[ctx.ex.id],series={...value?.series};
      series[ctx.round]={...series[ctx.round],done:false};delete series[ctx.round].completedAt;
      if(!persist(ctx,series)){input.checked=true;return;}
      const sheet=document.querySelector('#workoutDayDialog .sheet'),top=sheet?.scrollTop||0;renderWorkoutDay();if(sheet)sheet.scrollTop=top;updateWorkoutProgress();return;
    }`);
  s=replace(s,"if(input.dataset.seriesGroup){\n      if(!input.dataset.bisetCurrent)return;","if(input.dataset.seriesGroup){\n      if(!input.checked){reopenWorkoutBisetSeries(input);return;}\n      if(!input.dataset.bisetCurrent)return;");
  return s;
 });
 doc=patchScript(doc,'data-agenda-bisets',s=>{
  s=replace(s,'const status=phase(p,day,g),j=status.j;if(j.rounds[index]?.[letter])return;','const status=phase(p,day,g),j=status.j;if(j.rounds[index]?.[letter])return correctRecordedBisetInput(input,p,day,g,j,index,letter,field);');
  s=replace(s,'  window.saveWorkoutBisetPending=function(field,value){',read('workout-biset-corrections.js')+'\n  window.saveWorkoutBisetPending=function(field,value){');
  s=replace(s,"document.getElementById('workoutBisetStatus').textContent=part==='A'", "window.APWorkoutCorrections?.decorateGuide(p,day);\n    document.getElementById('workoutBisetStatus').textContent=part==='A'");
  return s;
 });
 return doc.replace('</head>','<style id="ap-workout-corrections-css">'+read('workout-corrections.css')+'</style></head>').replace('</body>','<script id="ap-workout-corrections">'+read('workout-corrections.js')+'</script></body>');
};
