'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const root=path.resolve(__dirname,'../web/mascot-images'),manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8')),images={};
 for(const [species,phases]of Object.entries(manifest)){
  images[species]={};
  for(const phase of ['baby','teen','adult']){
   const item=phases[phase];assert.ok(item,'Missing phase '+species+' '+phase);
   assert.ok(['image/webp','image/png'].includes(item.mime),'Transparent image format required');
   const bytes=fs.readFileSync(path.join(root,item.file));assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex'),item.sha256,'Approved image unchanged: '+species+' '+phase);
   images[species][phase]='data:'+item.mime+';base64,'+bytes.toString('base64');
  }
 }
 assert.equal(Object.keys(images).length,6);
 const coatRoot=path.resolve(__dirname,'../web/mascot-coats'),coatsManifest=JSON.parse(fs.readFileSync(path.join(coatRoot,'manifest.json'),'utf8')),coats={};
 for(const species of Object.keys(images)){
  const item=coatsManifest[species];assert.ok(item&&Object.keys(item.variants).length>=4,'All natural coat drawings required: '+species);coats[species]={};
  for(const [variant,phases]of Object.entries(item.variants)){
   assert.ok(/^[0-4]$/.test(variant));coats[species][variant]={};
   for(const phase of ['baby','teen','adult']){const entry=phases[phase];assert.ok(entry,'Natural growth phase required');assert.equal(path.basename(entry.file),entry.file);const bytes=fs.readFileSync(path.join(coatRoot,entry.file));assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex'),entry.sha256,'Natural coat integrity: '+species+' '+variant+' '+phase);coats[species][variant][phase]='data:image/webp;base64,'+bytes.toString('base64');}
  }
 }


 const poseRoot=path.resolve(__dirname,'../web/mascot-poses'),poseManifest=JSON.parse(fs.readFileSync(path.join(poseRoot,'manifest.json'),'utf8')),poses={};
 for(const [species,items]of Object.entries(poseManifest)){
  poses[species]={};assert.deepEqual(Object.keys(items).sort(),species==='panda'?['rest','sit']:['play','rest','sit'],'Available poses must match the species catalog');
  for(const [pose,designs]of Object.entries(items)){poses[species][pose]={};for(const [color,phases]of Object.entries(designs)){poses[species][pose][color]={};for(const phase of ['baby','teen','adult']){const entry=phases[phase];assert.ok(entry,'Pose phase required');assert.equal(path.basename(entry.file),entry.file);const bytes=fs.readFileSync(path.join(poseRoot,entry.file));assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex'),entry.sha256,'Pose integrity: '+entry.file);poses[species][pose][color][phase]={uri:'data:image/webp;base64,'+bytes.toString('base64'),headTop:entry.headTop,headX:entry.headX};}}}
 }
 const affectionRoot=path.resolve(__dirname,'../web/mascot-affection'),affectionManifest=JSON.parse(fs.readFileSync(path.join(affectionRoot,'manifest.json'),'utf8')),affection={};
 for(const [species,colors]of Object.entries(affectionManifest)){affection[species]={};for(const [color,phases]of Object.entries(colors)){affection[species][color]={};for(const phase of ['baby','teen','adult']){const entry=phases[phase],bytes=fs.readFileSync(path.join(affectionRoot,entry.file));assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex'),entry.sha256,'Affection frame integrity');affection[species][color][phase]={uri:'data:image/webp;base64,'+bytes.toString('base64'),headX:entry.headX,headTop:entry.headTop};}}}
 const reactionRoot=path.resolve(__dirname,'../web/mascot-reactions'),reactionManifest=JSON.parse(fs.readFileSync(path.join(reactionRoot,'manifest.json'),'utf8')),reactions={};
 for(const [species,colors]of Object.entries(reactionManifest)){reactions[species]={};for(const [color,phases]of Object.entries(colors)){reactions[species][color]={};for(const phase of ['baby','teen','adult']){const entry=phases[phase],bytes=fs.readFileSync(path.join(reactionRoot,entry.file));assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex'),entry.sha256,'Reaction artwork integrity');reactions[species][color][phase]={uri:'data:image/webp;base64,'+bytes.toString('base64'),headX:entry.headX,headTop:entry.headTop};}}}
 const runtime=require('terser').minify_sync(fs.readFileSync(path.resolve(__dirname,'../web/approved-bear-attention.js'),'utf8')+fs.readFileSync(path.resolve(__dirname,'../web/approved-bear-motion.js'),'utf8')+fs.readFileSync(path.resolve(__dirname,'../web/mascot-hit-areas.js'),'utf8')+fs.readFileSync(path.resolve(__dirname,'../web/mascot-curiosity-motion.js'),'utf8')+'window.APMascotBearPoseProfiles='+fs.readFileSync(path.resolve(__dirname,'../web/bear-pose-landmarks.json'),'utf8')+';'+fs.readFileSync(path.resolve(__dirname,'../web/bear-pose-motion.js'),'utf8')+fs.readFileSync(path.resolve(__dirname,'../web/bear-pose-attention.js'),'utf8')+fs.readFileSync(path.resolve(__dirname,'../web/mascot-petting.js'),'utf8'),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
 const bearManifest=JSON.parse(fs.readFileSync(path.resolve(__dirname,'../web/approved-bear/manifest.json'),'utf8'));
 const bear=Object.fromEntries(['original','affection','paw','angry'].map(k=>{const entry=bearManifest.textures[k],bytes=fs.readFileSync(path.resolve(__dirname,'../web/approved-bear/'+entry.file));assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex'),entry.sha256,'Approved bear integrity: '+k);return[k,'data:image/webp;base64,'+bytes.toString('base64')]}));
 const faceRoot=path.resolve(__dirname,'../web/bear-face-reactions'),faceManifest=JSON.parse(fs.readFileSync(path.join(faceRoot,'manifest.json'),'utf8')),faces={};
 for(const [pose,entry]of Object.entries(faceManifest)){assert.ok(['default','rest'].includes(pose));assert.equal(path.basename(entry.file),entry.file);assert.ok(entry.offset.length===2&&entry.offset.every(n=>Number.isFinite(n)&&Math.abs(n)<=12));const bytes=fs.readFileSync(path.join(faceRoot,entry.file));assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex'),entry.sha256,'Face reaction integrity: '+pose);faces[pose]={uri:'data:image/webp;base64,'+bytes.toString('base64'),offset:entry.offset};}
 const packed=value=>require('node:zlib').gzipSync(JSON.stringify(value),{level:9}).toString('base64');
 return doc.replace('</body>','<script type="application/json" id="ap-approved-bear-assets">'+JSON.stringify(bear)+'</script><script type="application/json" id="ap-bear-face-reaction-assets">'+JSON.stringify(faces)+'</script>'+'<script type="application/json" id="ap-mascot-gesture-runtime">'+JSON.stringify(runtime).replace(/</g,'\\u003c')+'</script><script type="application/json" id="ap-mascot-reaction-assets">'+JSON.stringify(reactions)+'</script>'+ '<script type="application/json" id="ap-mascot-affection-assets" data-ap-gzip>'+packed(affection)+'</script><script type="application/json" id="ap-mascot-image-assets">'+JSON.stringify(images)+'</script><script type="application/json" id="ap-mascot-coat-assets">'+JSON.stringify(coats)+'</script><script type="application/json" id="ap-mascot-pose-assets" data-ap-gzip>'+packed(poses)+'</script><script type="application/json" id="ap-mascot-home-assets">'+JSON.stringify(require('./mascot_home_assets.cjs').assets())+'</script></body>');
};
