'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const root=path.resolve(__dirname,'../web/mascot-images'),manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8')),images={};
 for(const [species,phases]of Object.entries(manifest)){
  images[species]={};
  for(const phase of ['baby','teen','adult']){
   const item=phases[phase];assert.ok(item,'Missing phase '+species+' '+phase);
   assert.ok(['image/webp','image/png'].includes(item.mime),'Transparent image format required');
   const bytes=fs.readFileSync(path.join(root,item.file));assert.equal(require('node:crypto').createHash('sha256').update(bytes).digest('hex'),item.sha256,'Approved image unchanged: '+species+' '+phase);
   images[species][phase]='data:'+item.mime+';base64,'+bytes.toString('base64');
  }
 }
 assert.equal(Object.keys(images).length,6);
 return doc.replace('</body>','<script type="application/json" id="ap-mascot-image-assets">'+JSON.stringify(images)+'</script><script type="application/json" id="ap-mascot-home-assets">'+JSON.stringify(require('./mascot_home_assets.cjs').assets())+'</script></body>');
};
