'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
module.exports=function(doc){
 doc=require('./compact_artwork_transform.cjs')(doc);
 assert.ok(doc.includes('data-agenda-deep-icons'),'Expected the approved depth icon renderer.');
 const read=file=>fs.readFileSync(path.resolve(__dirname,'../web/'+file),'utf8');
 // The finish is independent of the screen design, colors and light/dark mode.
 // Resolve it before any of the existing icon renderers starts.
 const initial=minify_sync(read('icon-finish.js'),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
 doc=doc.replace('<head>','<head><script id="ap-icon-finish">'+initial+'</script>');
 const deepActive="(document.documentElement.dataset.agendaDesign==='deep-tl'||document.documentElement.dataset.agendaIconFinish==='matte')";
 let count=0;
 doc=doc.replace(/<script (data-agenda-deep-(?:icons|presentation))([^>]*)>([\s\S]*?)<\/script>/g,(_,tag,attrs,body)=>{
  count++;body=body.replaceAll("document.documentElement.dataset.agendaDesign==='deep-tl'",deepActive).replaceAll("document.documentElement.dataset.agendaDesign!=='deep-tl'",'!'+deepActive);
  // Samples of the icon finish use the same renderer and material as the UI.
  if(tag==='data-agenda-deep-icons'){
   body=body.replace("[data-agenda-metal-demo]'))return;","[data-agenda-metal-demo],[data-icon-finish=\"theme\"]'))return;");
   const preview="document.querySelectorAll('[data-agenda-deep-demo] svg:not([data-deep-decorated])').forEach(svg=>decorate(svg,true));";
   assert.ok(body.includes(preview));body=body.replace(preview,preview+"\n  document.querySelectorAll('[data-matte-preview] svg:not([data-deep-decorated])').forEach(svg=>decorate(svg,true));");
  }
  return '<script '+tag+attrs+'>'+body+'</script>';
 });
 assert.equal(count,2,'Expected both depth renderer and text-icon presentation.');
 const metal="active=document.documentElement.dataset.agendaDesign==='metal-tl';";assert.ok(doc.includes(metal));
 doc=doc.replace(metal,"active=document.documentElement.dataset.agendaDesign==='metal-tl'&&document.documentElement.dataset.agendaIconFinish!=='matte';");
 // Performance Pro hides home fills for its outline icons only.
 doc=doc.replace(/html\[data-agenda-design="pro-tl"\] ([^{}]*svg[^{}]*\{[^{}]*fill:none!important[^{}]*\})/g,'html[data-agenda-design="pro-tl"]:not([data-agenda-icon-finish="matte"]) $1');
 if(doc.includes('id="colorPanelScroll"')){
  const sample='<svg viewBox="0 0 25 25" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 10h18m-13 4h1m6 0h1m-8 4h1m6 0h1"/></svg>';
  const button=(id,title,help)=>'<button type="button" data-icon-finish="'+id+'" aria-pressed="false"><span class="icon-finish-sample" '+(id==='matte'?'data-matte-preview':'')+'>'+sample+'</span><span class="icon-finish-copy"><strong>'+title+'</strong><small>'+help+'</small></span><span class="icon-finish-check" aria-hidden="true">✓</span></button>';
  const options='<section class="icon-finish-options" aria-labelledby="iconFinishTitle"><div class="color-panel-intro"><h4 id="iconFinishTitle">Acabamento dos ícones</h4><p>Escolha só os ícones. As cores e o fundo do aplicativo são mantidos.</p></div><div class="icon-finish-choices" role="group" aria-label="Acabamento dos ícones">'+button('theme','Ícones do tema','Usar o estilo do tema')+button('matte','Ícones foscos','Fosco na cor escolhida')+'</div><p id="iconFinishStatus" role="status" aria-live="polite"></p></section>';
  const cards='<section class="icon-finish-options" aria-labelledby="cardStyleTitle"><div class="color-panel-intro"><h4 id="cardStyleTitle">Cor dos cartões</h4><p>Escolha o fundo dos cartões do aplicativo.</p></div><div class="icon-finish-choices" role="group" aria-label="Cor dos cartões"><button type="button" data-card-style="theme" aria-pressed="false"><span class="icon-finish-copy"><strong>Fundo do tema</strong><small>Destacar só o cartão selecionado</small></span><span class="icon-finish-check" aria-hidden="true">✓</span></button><button type="button" data-card-style="colored" aria-pressed="false"><span class="icon-finish-copy"><strong>Todos os cartões coloridos</strong><small>Usar a cor escolhida em todos</small></span><span class="icon-finish-check" aria-hidden="true">✓</span></button></div><p id="cardStyleStatus" role="status" aria-live="polite"></p></section>';
  doc=doc.replace('<div class="color-panel-scroll" id="colorPanelScroll">','<div class="color-panel-scroll" id="colorPanelScroll">'+options+cards);
 }
 const js=minify_sync(read('icon-material-model.js')+';'+read('deep-icon-palette.js'),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
 const ending=/<\/body>(\s*<\/html>\s*)$/i;assert.ok(ending.test(doc),'Expected the document closing body, outside PDF templates.');
 return doc.replace('</head>','<style id="ap-deep-icon-palette-css">'+read('deep-icon-palette.css')+read('icon-finish.css')+'</style></head>').replace(ending,(_,tail)=>'<style id="ap-colored-cards-css">'+require('./colored_cards_styles.cjs')()+'</style><script id="ap-deep-icon-palette">'+js+'</script></body>'+tail);
};
