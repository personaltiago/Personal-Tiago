'use strict';
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'web/tiktok-player-page.html'),'utf8');
const literal=html.split(/(?<=\n)/).filter(Boolean).map(line=>JSON.stringify(line)).join('\n   + ');
fs.writeFileSync(path.join(root,'app/src/main/java/com/tiagolima/agendapersonal/TikTokPlayerPage.java'),`package com.tiagolima.agendapersonal;
/** TikTok's official iframe in an unprivileged native WebView. */
final class TikTokPlayerPage {
 private TikTokPlayerPage() {}
 static String html(String videoId) {
  if (!TikTokVideoResolver.validId(videoId)) throw new IllegalArgumentException("Vídeo inválido");
  return (${literal}).replace("__VIDEO_ID__",videoId);
 }
}
`);
