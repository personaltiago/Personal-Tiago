'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const panel='<aside class="agenda-alarm-panel"><div><strong>Despertador das aulas</strong><p data-agenda-alarm-status role="status">Verificando avisos…</p></div><div class="agenda-alarm-actions"><button class="btn ghost" type="button" onclick="showScreen(\'settings\')">Sons e alertas</button><button class="btn ghost" type="button" onclick="openAlarmSettings()">Verificar / testar</button></div></aside>';
 let panels=0;doc=doc.replace(/(<section id="screen-(?:today|week)"[\s\S]*?)(<div class="agenda-toolbar">)/g,(_,prefix,heading)=>{panels++;return prefix+panel+heading});assert.equal(panels,2);
 const old='<div class="agenda-lesson-extra-actions"><button class="btn timer" type="button" onclick="openWorkoutForLesson(${lid},${date})"';assert.equal(doc.split(old).length-1,1);
 const start='${timer?\'\':`<button class="btn timer agenda-start-lesson" type="button" onclick="startLessonTimer(${lid},${date})"${st===\'cancelada\'||st===\'realizada\'?\' disabled\':\'\'}>${uiIcon(\'clock\')}<span>Iniciar aula · ${hesc(l.duration||60)} min</span></button>`}';
 doc=doc.replace(old,'<div class="agenda-lesson-extra-actions">'+start+'<button class="btn timer" type="button" onclick="openWorkoutForLesson(${lid},${date})"');
 const begin=doc.indexOf('function renderAlarmStatus(){'),end=doc.indexOf('function openAlarmSettings(){',begin);assert.ok(begin>=0&&end>begin);
 doc=doc.slice(0,begin)+fs.readFileSync(path.resolve(__dirname,'../web/lesson-alarm-controls.js'),'utf8')+'\n'+doc.slice(end);
 const sound="status?.lessonName||'Padrão do celular'",timerSound="status?.timerName||'Padrão do celular'";assert.ok(doc.includes(sound)&&doc.includes(timerSound));
 doc=doc.replace(sound,"status?.lessonSoundName||status?.lessonName||'Padrão do celular'").replace(timerSound,"status?.timerSoundName||status?.timerName||'Padrão do celular'");
 const screen='  currentScreen=screen;';assert.equal(doc.split(screen).length-1,1);doc=doc.replace(screen,screen+"\n  if(['today','week','settings'].includes(screen)){syncNativeAlarms();renderAlarmStatus()}");
 const more='<button id="moreAccountLogout"';assert.ok(doc.includes(more));doc=doc.replace(more,'<button class="more-function more-function-compact" type="button" onclick="showScreen(\'settings\')"><span class="more-function-copy"><strong>Sons e alertas das aulas</strong><small>Antes da aula, cronômetro e teste do toque.</small></span></button>'+more);
 doc=doc.replace('Áudio do despertador</strong>','Som antes da aula</strong>').replace('Áudio do fim da aula</strong>','Som do fim da aula</strong>');
 return doc.replace('</head>','<style id="ap-lesson-alarm-controls-css">'+fs.readFileSync(path.resolve(__dirname,'../web/lesson-alarm-controls.css'),'utf8')+'</style></head>');
};
