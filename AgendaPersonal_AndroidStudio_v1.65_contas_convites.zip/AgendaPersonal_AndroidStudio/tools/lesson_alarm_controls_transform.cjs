'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const old='<div class="agenda-lesson-extra-actions"><button class="btn timer" type="button" onclick="openWorkoutForLesson(${lid},${date})"';assert.equal(doc.split(old).length-1,1);
 const start='${timer?\'\':`<button class="btn timer agenda-start-lesson" type="button" onclick="startLessonTimer(${lid},${date})"${st===\'cancelada\'||st===\'realizada\'?\' disabled\':\'\'}>${uiIcon(\'clock\')}<span>Iniciar aula · ${hesc(l.duration||60)} min</span></button>`}';
 doc=doc.replace(old,'<div class="agenda-lesson-extra-actions">'+start+'<button class="btn timer" type="button" onclick="openWorkoutForLesson(${lid},${date})"');
 const begin=doc.indexOf('function renderAlarmStatus(){'),end=doc.indexOf('function openAlarmSettings(){',begin);assert.ok(begin>=0&&end>begin);
 doc=doc.slice(0,begin)+fs.readFileSync(path.resolve(__dirname,'../web/lesson-alarm-controls.js'),'utf8')+'\n'+doc.slice(end);
 const sound="status?.lessonName||'Padrão do celular'",timerSound="status?.timerName||'Padrão do celular'";assert.ok(doc.includes(sound)&&doc.includes(timerSound));
 doc=doc.replace(sound,"status?.lessonSoundName||status?.lessonName||'Padrão do celular'").replace(timerSound,"status?.timerSoundName||status?.timerName||'Padrão do celular'");
 const screen='  currentScreen=screen;';assert.equal(doc.split(screen).length-1,1);doc=doc.replace(screen,screen+"\n  if(['today','week','settings'].includes(screen)){syncNativeAlarms();renderAlarmStatus()}");
 const more='<button id="moreAccountLogout"';assert.ok(doc.includes(more));doc=doc.replace(more,'<button id="moreLessonSounds" class="more-function more-function-compact" type="button" aria-label="Sons e alertas das aulas" onclick="openLessonSoundSettings()"><span class="more-function-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" data-sound-music="true" aria-hidden="true"><path d="M9 17V5l12-3v12M9 9l12-3"/><ellipse cx="6" cy="17" rx="3" ry="3"/><ellipse cx="18" cy="14" rx="3" ry="3"/></svg></span><span class="more-function-copy"><strong>Despertador</strong><small>Toques das aulas e do descanso.</small></span><span class="more-chevron"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></span></button>'+more);
 const proSettings='<button type="button" class="pro-menu-row" data-screen="settings">';assert.ok(doc.includes(proSettings));
 doc=doc.replace(proSettings,'<button id="moreProLessonSounds" type="button" class="pro-menu-row" onclick="openLessonSoundSettings()"><span class="pro-menu-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" data-sound-music="true" aria-hidden="true"><path d="M9 17V5l12-3v12M9 9l12-3"/><ellipse cx="6" cy="17" rx="3" ry="3"/><ellipse cx="18" cy="14" rx="3" ry="3"/></svg></span><span>Sons e alertas das aulas</span><svg class="pro-menu-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></button>'+proSettings);
 const musicSolid='<path d="M8 4.5 21 1.3v13.2a3.5 3.5 0 1 1-2.5-3.35V6.1l-8 2v9.4A3.5 3.5 0 1 1 8 14.15Z"/>';
 const solidMaps=/const solid=\{(\.\.\.\{)?\n/g;let musicMaps=0;doc=doc.replace(solidMaps,(head)=>{musicMaps++;return head+"  music:"+JSON.stringify(musicSolid)+",\n"});assert.equal(musicMaps,2);
 const iconModels=' function model(svg){';assert.equal(doc.split(iconModels).length-1,2);doc=doc.replaceAll(iconModels,iconModels+"\n  if(svg.hasAttribute('data-sound-music'))return 'music';");
 const deepLayer='  object.append(depth,rim,face);layer.append(object);svg.replaceChildren(defs,layer);';assert.equal(doc.split(deepLayer).length-1,1);
 doc=doc.replace(deepLayer,`  if(name==='music'&&svg.hasAttribute('data-sound-music')){
   defs.innerHTML+=\`<linearGradient id="\${id}-music-frame" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#f0edf5"/><stop offset=".23" stop-color="#8e8a99"/><stop offset=".48" stop-color="#29272f"/><stop offset=".75" stop-color="#c3becd"/><stop offset="1" stop-color="#514d5b"/></linearGradient>\`;
   const frame=document.createElementNS(ns,'g');frame.innerHTML=\`<path d="M12 .7 22 6.4v11.2L12 23.3 2 17.6V6.4Z" fill="url(#\${id}-music-frame)" stroke="#302d38" stroke-width=".25"/><path d="M12 2.1 20.8 7.1v9.8L12 21.9l-8.8-5V7.1Z" fill="var(--dp-deep,#1e0c31)" stroke="#5f596b" stroke-width=".4"/><path d="M12 3.1 19.9 7.6v8.8L12 20.9l-7.9-4.5V7.6Z" fill="#111016" stroke="var(--dp-low,#3c1760)" stroke-width=".45"/>\`;
   layer.append(frame);object.setAttribute('transform','translate(4.2 4.6) scale(.65)');
  }
`+deepLayer);

 doc=doc.replace('Áudio do despertador</strong>','Som antes da aula</strong>').replace('Áudio do fim da aula</strong>','Som do fim da aula</strong>');
 return doc.replace('</head>','<style id="ap-lesson-alarm-controls-css">'+fs.readFileSync(path.resolve(__dirname,'../web/lesson-alarm-controls.css'),'utf8')+'</style></head>');
};
