'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const [version,sequenceText,destination,notesFile]=process.argv.slice(2),sequence=Number(sequenceText);
if(!/^\d+\.\d+\.\d+$/.test(version||'')||!Number.isSafeInteger(sequence)||sequence<=96||!destination||!notesFile)throw Error('Uso: node tools/build_web_update.cjs VERSAO SEQUENCIA arquivo.agenda.json descricao.txt');
const notes=fs.readFileSync(path.resolve(notesFile),'utf8').trim();
if(!notes||notes.length>4000)throw Error('A descrição precisa informar as alterações reais, com até 4.000 caracteres.');
const assets=path.resolve(__dirname,'../app/src/main/assets'),files={};
for(const name of ['index.html','professor.html','avaliacoes.html','cadastro.html'])files[name]=fs.readFileSync(path.join(assets,name),'utf8');
// Validate the actual shipped pages against the original publisher/server
// contract, including literals embedded inside the entry page itself.
for(const [name,html] of Object.entries(files)){
 if(!html.toLowerCase().includes('</html>')||name!=='cadastro.html'&&!html.includes('data-agenda-ready'))throw Error('Tela incompatível: '+name);
 if(html.includes('window.__agendaNativeReleaseToken'+'='))throw Error('Marcador de execução presente no pacote: '+name+'. O publicador antigo recusaria este arquivo.');
}
const text=JSON.stringify({format:1,appId:'com.tiagolima.agendapersonal',bridgeVersion:3,dataSchema:4,version,sequence,notes,files});
if(Buffer.byteLength(text)>24*1024*1024)throw Error('Pacote excede o limite de atualização.');
fs.writeFileSync(destination,text);console.log(JSON.stringify({version,sequence,size:Buffer.byteLength(text),sha256:crypto.createHash('sha256').update(text).digest('hex')}));
