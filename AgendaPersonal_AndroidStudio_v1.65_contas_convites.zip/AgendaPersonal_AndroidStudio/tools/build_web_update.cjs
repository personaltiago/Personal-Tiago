'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const [version,sequenceText,destination]=process.argv.slice(2),sequence=Number(sequenceText);
if(!/^\d+\.\d+\.\d+$/.test(version||'')||!Number.isSafeInteger(sequence)||sequence<=96||!destination)throw Error('Uso: node tools/build_web_update.cjs 1.11.91 97 /caminho/arquivo.agenda.json');
const assets=path.resolve(__dirname,'../app/src/main/assets'),files={};
for(const name of ['index.html','professor.html','avaliacoes.html','cadastro.html'])files[name]=fs.readFileSync(path.join(assets,name),'utf8');
const text=JSON.stringify({format:1,appId:'com.tiagolima.agendapersonal',bridgeVersion:3,dataSchema:4,version,sequence,files});
if(Buffer.byteLength(text)>24*1024*1024)throw Error('Pacote excede o limite de atualização.');
fs.writeFileSync(destination,text);console.log(JSON.stringify({version,sequence,size:Buffer.byteLength(text),sha256:crypto.createHash('sha256').update(text).digest('hex')}));
