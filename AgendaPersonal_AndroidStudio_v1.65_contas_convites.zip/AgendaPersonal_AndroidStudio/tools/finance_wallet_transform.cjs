'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=name=>fs.readFileSync(path.resolve(__dirname,'../web/'+name),'utf8');
module.exports=function(doc){
 const zero="s.monthlyValue||''";assert.ok(doc.includes(zero),'Missing monthly value normalization');
 doc=doc.split(zero).join("s.monthlyValue??''");
 const anchor='<div class="finance-summary">';assert.ok(doc.includes(anchor),'Missing financial summary');
 const wallet='<section id="financeWallet" aria-labelledby="financeWalletTitle"><h3 id="financeWalletTitle">Carteira do mês</h3><div><span class="finance-wallet-label">Previsão de mensalidades</span><strong id="financeWalletForecast">R$ 0,00</strong><small id="financeWalletBasis"></small></div><div class="finance-wallet-received"><div><span class="finance-wallet-label">Recebido no mês</span><small id="financeWalletReceipts"></small></div><strong id="financeWalletReceived">R$ 0,00</strong></div><p class="finance-wallet-note">Previsão: uma mensalidade por aluno ativo com financeiro habilitado. Recebido: pagamentos marcados como pagos neste mês, inclusive de meses anteriores.</p><p id="financeWalletMissing" class="finance-wallet-warning" hidden></p><p id="financeWalletUnknownReceipts" class="finance-wallet-warning" hidden></p><details id="financeWalletDetails"><summary><span>Valores por aluno</span><span><b id="financeWalletCount"></b><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></span></summary><div id="financeWalletRows"></div></details></section>';
 doc=doc.replace(anchor,wallet+anchor).replace('</head>','<style id="ap-finance-wallet-css">'+read('finance-wallet.css')+'</style></head>');
 return doc.replace('</body>','<script id="ap-finance-wallet-model">'+read('finance-wallet-model.js')+'</script><script id="ap-finance-wallet">'+read('finance-wallet.js')+'</script></body>');
};
