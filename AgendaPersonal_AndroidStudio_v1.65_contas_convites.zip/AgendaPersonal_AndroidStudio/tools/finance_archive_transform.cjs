'use strict';
const assert=require('node:assert/strict');
module.exports=function(doc){
 const begin=doc.indexOf('function markPaymentOverdue(sid){'),end=doc.indexOf('function clearPaymentOverdue(sid){',begin);
 assert.ok(begin>=0&&end>begin,'Finance overdue action');
 doc=doc.slice(0,begin)+`function markPaymentOverdue(sid){
  const s=studentById(sid);if(!s||!s.financeEnabled||!s.dueDate)return toast('Configure o vencimento desse aluno primeiro.');
  if(financeStatus(s).kind==='overdue'&&s.archived===true){setFinanceView('overdue');return}
  if(!confirm('Marcar a mensalidade de '+s.name+' em atraso e arquivar o aluno?\\n\\nEle sairá das listas ativas e seus treinos serão bloqueados no app ao sincronizar. As fichas, cargas e históricos serão preservados.\\n\\nPara liberar os treinos novamente, use Reativar aluno na aba Arquivados.'))return;
  const at=new Date().toISOString(),archive=s.archived===true?{}:{archived:true,archivedAt:at,archiveReason:'payment-overdue',archiveDueDate:s.dueDate};
  // One durable write: financial status and archive either both commit or neither does.
  const result=commitFinanceChange(s,{paymentOverdue:true,overdueDueDate:s.dueDate,overdueMarkedAt:at,...archive},'Mensalidade em atraso e aluno arquivado · '+s.name+' · vencimento '+fmtDate(s.dueDate));
  if(result===null)return;
  setFinanceView('overdue');revealFinanceStudent(sid);
  toast('Atraso registrado e aluno arquivado. O bloqueio dos treinos será sincronizado.');
  if(result==='error')alarmFeedback(result,'','');
}
`+doc.slice(end);
 const action="const statusAction=f.kind!=='overdue'?";assert.ok(doc.includes(action),'Finance card status actions');
 const original=doc.match(/const statusAction=f\.kind!==\x27overdue\x27\?[^\n]+;/)?.[0];assert.ok(original);
 const extra="s.archived!==true?`<button class=\"btn danger\" type=\"button\" onclick=\"markPaymentOverdue(this.closest('[data-student-id]').dataset.studentId)\">${uiIcon('alert')}Arquivar por atraso</button>`:";
 doc=doc.replace(original,original.replace(':f.manual?',':'+extra+'f.manual?'));
 const note="${f.manual?'<small class=\"finance-manual-note\">Atraso marcado por você</small>':''}";assert.ok(doc.includes(note));
 doc=doc.replace(note,note+"${s.archived===true?'<small class=\"finance-manual-note\">Aluno arquivado · acesso aos treinos suspenso após sincronizar. Reative na aba Arquivados.</small>':''}");
 const clear="else toast('Marcação retirada. Aluno voltou para Em dia.');";assert.ok(doc.includes(clear));
 doc=doc.replace(clear,"else toast(s.archived===true?'Marcação de atraso retirada. O aluno continua arquivado; reative na aba Arquivados.':'Marcação retirada. Aluno voltou para Em dia.');");
 return doc;
};
