'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {minify_sync}=require('terser');
module.exports=function(html){
 const read=file=>fs.readFileSync(path.resolve(__dirname,'../web/'+file),'utf8');
 const script=file=>{const result=minify_sync(read(file),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}});assert.ok(result.code);return result.code};
 // Keep the existing 2 MiB update contract. This isolated IIFE has a public
 // object API; minification preserves property names and all stored data.
 const store='return{active:v.active||{},history:v.history||[]}';assert.equal(html.split(store).length-1,1);
 html=html.replace(store,'return{active:v.active||{},history:v.history||[],mascot:v.mascot||null}');
 const finish="store.history.unshift(record);delete store.active[exActiveId];if(!exSave(store))return;";assert.equal(html.split(finish).length-1,1);
 html=html.replace(finish,"const mascotReward=window.APmascot.prepareReward(store,record);"+finish);
 const finished="el('exFinishModal').hidden=true;wsTab='done';route('workouts');toast('Treino finalizado. Seu registro foi salvo neste aparelho.');";assert.equal(html.split(finished).length-1,1);
 html=html.replace(finished,finished+'window.APmascot.afterReward(mascotReward);');
 const back="if(window.APnotifications?.close())return true;";assert.ok(html.includes(back));
 html=html.replace(back,"if(window.APmascot?.close())return true;\n "+back);
 for(const id of ['ap-prof-setup-script','ap-student-ui','ap-student-inline-video','ap-external-video-links','ap-student-billing','ap-student-model','ap-photo-sync','ap-student-notifications','ap-home-assessments','ap-home-daily-message','ap-single-navigation','ap-workout-muscle-preview','ap-student-identity-controls','ap-billing-model','ap-student-access','ap-login-controls']){
  const scriptTag=new RegExp('<script id="'+id+'">([\\s\\S]*?)<\\/script>');assert.ok(scriptTag.test(html));
  html=html.replace(scriptTag,(_,code)=>'<script id="'+id+'">'+minify_sync(code,{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code+'</script>');
 }
 html=html.replace('</head>','<style id="ap-student-mascot-css">'+read('student-mascot.css')+read('mascot-daily-message.css')+'</style></head>');
 return html.replace('</body></html>',read('student-mascot.html')+'<script id="ap-workout-motivation">'+script('workout-motivation.js')+'</script><script id="ap-student-mascot-model">'+script('student-mascot-model.js')+'</script><script id="ap-student-mascot-art">'+script('student-mascot-art.js')+'</script><script id="ap-mascot-daily-message">'+script('mascot-daily-message.js')+'</script><script id="ap-teacher-mascot">'+script('teacher-mascot.js')+'</script><script id="ap-student-mascot">'+script('student-mascot.js')+'</script></body></html>');
};
