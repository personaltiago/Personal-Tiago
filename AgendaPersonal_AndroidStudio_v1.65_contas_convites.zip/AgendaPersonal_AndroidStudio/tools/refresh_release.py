"""Explicitly regenerate, or verify, the complete inventory of reviewed release sources."""
from pathlib import Path
import hashlib
import json
import sys
from release_files import source_files

ROOT = Path(__file__).resolve().parents[1]

def main():
    path = ROOT / 'release.json'
    release = json.loads(path.read_text())
    hashes = {name: hashlib.sha256(source.read_bytes()).hexdigest() for name, source in source_files(ROOT) if name != 'release.json'}
    if '--check' in sys.argv:
        if hashes != release['sourceHashes']:
            raise ValueError('As fontes e o inventário da versão divergem. Revise antes de gerar o pacote.')
    else:
        release['sourceHashes'] = hashes
        path.write_text(json.dumps(release, indent=2, ensure_ascii=False) + '\n')
    print(f'Inventário completo conferido: {len(hashes)} arquivos.')

if __name__ == '__main__':
    main()
