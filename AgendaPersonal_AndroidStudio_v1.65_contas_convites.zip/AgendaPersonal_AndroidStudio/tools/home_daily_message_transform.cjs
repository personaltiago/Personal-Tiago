'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const welcome=/<div class="home-welcome"><h1>[\s\S]*?<\/h1><p>[\s\S]*?<\/p><\/div>/;assert.ok(welcome.test(doc));
 doc=doc.replace(welcome,old=>old.replace(/<p>[\s\S]*?<\/p>/,'<p id="apHomeDailyMessage"></p>'));
 const old="if(description)description.textContent=w?'Seu treino foi organizado pelo professor.':'Seu cadastro está aprovado. Seu professor ainda vai disponibilizar a ficha.';";assert.ok(doc.includes(old));
 doc=doc.replace(old,"if(description)description.textContent='';");
 doc=doc.replace('</head>','<style id="ap-home-daily-message-css">.student-home .home-header{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:8px;row-gap:8px;align-items:center}.student-home .home-welcome{display:contents}.student-home .home-welcome h1{grid-column:1;grid-row:1;white-space:normal;overflow-wrap:anywhere;min-width:0;margin-bottom:0}.student-home .home-actions{grid-column:2;grid-row:1}.student-home #apHomeDailyMessage{grid-column:1 / -1;grid-row:2;white-space:normal;overflow-wrap:anywhere;line-height:1.5;margin:0}</style></head>');
 return doc.replace('</body></html>','<script id="ap-home-daily-message">'+fs.readFileSync(path.resolve(__dirname,'../web/home-daily-message.js'),'utf8')+'</script></body></html>');
};
