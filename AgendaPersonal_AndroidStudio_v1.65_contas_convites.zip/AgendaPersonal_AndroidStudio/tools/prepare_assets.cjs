'use strict';
// Recreate generated pages from the complete, versioned sources in the small ZIP.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),pages=['index.html','professor.html','avaliacoes.html','cadastro.html'],assets=path.join(root,'app/src/main/assets'),receipt=path.join(root,'.agenda-assets-build.json'),identityFile=path.join(assets,'agenda-build.json');
const hash=data=>crypto.createHash('sha256').update(data).digest('hex');
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).filter(e=>e.name!=='__pycache__'&&!e.name.endsWith('.pyc')).sort((a,b)=>a.name.localeCompare(b.name,'en')).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):e.isFile()?[path.join(dir,e.name)]:[])}
function identity(files){const bytes=fs.readFileSync(path.join(root,'release.json')),r=JSON.parse(bytes),versionCode=Number(process.env.ANDROID_VERSION_CODE||r.versionCode);if(!Number.isSafeInteger(versionCode)||versionCode<r.versionCode||versionCode>2100000000)throw Error('ANDROID_VERSION_CODE inválido.');return {format:1,applicationId:r.applicationId,androidVersion:r.androidVersion,versionCode,contentVersion:r.contentVersion,sequence:r.sequence,sourceSha256:hash(bytes),files}}
function fingerprint(){const h=crypto.createHash('sha256');h.update(String(identity({}).versionCode));h.update('\0');for(const f of ['release.json','package.json','package-lock.json',...['web','tools'].flatMap(d=>walk(path.join(root,d)).map(f=>path.relative(root,f)))].sort()){h.update(f.replaceAll(path.sep,'/'));h.update('\0');h.update(fs.readFileSync(path.join(root,f)));h.update('\0')}return h.digest('hex')}
function run(command,args){const result=spawnSync(command,args,{cwd:root,stdio:'inherit',shell:process.platform==='win32'&&command==='npm',env:{...process.env,PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD:'1'}});if(result.error)throw result.error;if(result.status!==0)throw Error('Falha ao preparar as telas. A compilação foi interrompida.');}
function main(){
 require('./public_sources.cjs').sync(root);
 // Interrupted editor writes must not survive a successful cached build.
 for(const entry of fs.readdirSync(assets))if(/^\.(?:index|professor|avaliacoes|cadastro)\.html\.[A-Za-z0-9_-]+$/.test(entry))fs.unlinkSync(path.join(assets,entry));
 const source=fingerprint();
 try{const saved=JSON.parse(fs.readFileSync(receipt,'utf8'));if(saved.source===source&&pages.every(n=>saved.files[n]===hash(fs.readFileSync(path.join(assets,n))))&&fs.readFileSync(identityFile,'utf8')===JSON.stringify(identity(saved.files))){console.log('Telas e identificação do conteúdo conferidas.');return}}catch(_){}
 const lock=JSON.parse(fs.readFileSync(path.join(root,'package-lock.json'),'utf8'));
 const depsReady=['terser','clean-css'].every(name=>{try{return JSON.parse(fs.readFileSync(path.join(root,'node_modules',name,'package.json'),'utf8')).version===lock.packages['node_modules/'+name].version}catch(_){return false}});
 if(!depsReady){console.log('Preparando as dependências fixadas do projeto…');run('npm',['ci','--no-audit','--no-fund']);}
 run(process.execPath,['tools/split_shell_assets.cjs']);
 const files={};for(const name of pages){const data=fs.readFileSync(path.join(assets,name));if(!data.includes(Buffer.from('</html>')))throw Error('Tela gerada incompleta: '+name);files[name]=hash(data);}
 fs.writeFileSync(identityFile+'.partial',JSON.stringify(identity(files)));fs.renameSync(identityFile+'.partial',identityFile);
 const temporary=receipt+'.partial';fs.writeFileSync(temporary,JSON.stringify({source,files}));fs.renameSync(temporary,receipt);console.log('Quatro telas preparadas e conferidas para o APK.');
}
try{main()}catch(error){console.error(error.message);process.exitCode=1}
