'use strict';
// The native distribution uses the exact consolidated web release.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),pages=['index.html','professor.html','avaliacoes.html','cadastro.html'];
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function main(){
 const releaseBytes=fs.readFileSync(path.join(root,'release.json'));
 const release=JSON.parse(releaseBytes),raw=fs.readFileSync(path.join(root,'web/native-release.agenda.json'));
 if(release.sourceHashes?.['web/native-release.agenda.json']!==hash(raw))throw Error('O conteúdo consolidado diverge da versão revisada. A compilação foi interrompida.');
 const bundle=JSON.parse(raw.toString('utf8'));
 if(bundle.format!==1||bundle.appId!==release.applicationId||bundle.bridgeVersion!==3||bundle.dataSchema!==4||bundle.version!==release.contentVersion||bundle.sequence!==release.sequence||Object.keys(bundle.files||{}).sort().join('|')!==[...pages].sort().join('|'))throw Error('A identificação do conteúdo não corresponde ao APK.');
 const versionCode=Number(process.env.ANDROID_VERSION_CODE||release.versionCode);
 if(!Number.isSafeInteger(versionCode)||versionCode<release.versionCode||versionCode>2100000000)throw Error('ANDROID_VERSION_CODE inválido.');
 const files={};
 for(const name of pages){
  const html=bundle.files[name];
  if(typeof html!=='string'||!html.toLowerCase().includes('</html>')||name!=='cadastro.html'&&!html.includes('data-agenda-ready'))throw Error('Tela consolidada inválida: '+name);
  files[name]=hash(Buffer.from(html,'utf8'));
 }
 const assets=path.join(root,'app/src/main/assets');fs.mkdirSync(assets,{recursive:true});
 for(const name of fs.readdirSync(assets))if(/^\.(?:index|professor|avaliacoes|cadastro)\.html\.[A-Za-z0-9_-]+$/.test(name))fs.unlinkSync(path.join(assets,name));
 for(const name of pages){const temporary=path.join(assets,'.'+name+'.consolidated');fs.writeFileSync(temporary,bundle.files[name]);fs.renameSync(temporary,path.join(assets,name));}
 const identity={format:1,applicationId:release.applicationId,androidVersion:release.androidVersion,versionCode,contentVersion:release.contentVersion,sequence:release.sequence,sourceSha256:hash(releaseBytes),files};
 const identityFile=path.join(assets,'agenda-build.json');fs.writeFileSync(identityFile+'.partial',JSON.stringify(identity));fs.renameSync(identityFile+'.partial',identityFile);
 console.log('Conteúdo '+bundle.version+' preservado integralmente nas quatro telas do Android '+release.androidVersion+'.');
}
try{main()}catch(error){console.error('PREPARAÇÃO INTERROMPIDA: '+error.message);process.exitCode=1;}
