'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=name=>fs.readFileSync(path.resolve(__dirname,'../web/'+name),'utf8');
module.exports=function(doc){
 const build='  function buildReport(d, history = []) {';assert.ok(doc.includes(build));
 doc=doc.replace(build,read('individual-report-pages.js')+'\n'+build);
 const finish="reportContent.innerHTML = page1 + page2 + (hasHistoryPages ? evolutionPage(d, history, historyPageNo, total) + evolutionPosterPage(d, history, posterPageNo, total) : '') + contextPage + photoPage;";
 assert.ok(doc.includes(finish));doc=doc.replace(finish,finish+'\n    separateIndividualReportPages(d);');
 const style=doc.indexOf('<style id="pdf-page-layout-source"'),end=doc.indexOf('</style>',style);assert.ok(style>=0&&end>style);
 return doc.slice(0,end)+'\n'+read('individual-report-pages.css')+'\n'+doc.slice(end);
};
