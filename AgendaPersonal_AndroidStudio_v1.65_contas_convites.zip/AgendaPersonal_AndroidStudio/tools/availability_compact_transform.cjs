'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=name=>fs.readFileSync(path.resolve(__dirname,'../web/'+name),'utf8');
module.exports=function(doc){
 const a=doc.indexOf('function renderAutomaticAvailabilityWeek(){'),b=doc.indexOf('function onAvailabilityLimitsToggle(',a);
 assert.ok(a>=0&&b>a,'Compact availability overview anchor');
 doc=doc.slice(0,a)+read('availability-compact.js')+'\n'+doc.slice(b);
 const start=doc.indexOf('function renderAvailability(){'),mode=doc.indexOf("  if(search.mode==='time'){",start),end=doc.indexOf('  const {date,start,end,duration}=search,slots=',mode);
 assert.ok(start>=0&&mode>start&&end>mode,'Compact availability query anchor');
 doc=doc.slice(0,mode)+`  if(search.mode==='time'){
    const range={start:search.start,end:search.end,duration:timeToMinutes(search.end)-timeToMinutes(search.start)},model=compactAvailabilityMonth(search.month,range);
    el.innerHTML=compactAvailabilityCaption(model)+renderCompactAvailability(model,'query');return;
  }
`+doc.slice(end);
 doc=doc.replaceAll('>Meu mês<','>Por dia da semana<').replace('Atualizada pelas aulas já cadastradas.','Consulte de domingo a sábado, usando as aulas da sua agenda.');
 doc=doc.replace('id="automaticAvailabilityRangeSettings" class="automatic-availability-range"','id="automaticAvailabilityRangeSettings" class="automatic-availability-range" open');
 doc=doc.replace('<span>Mostrar das</span>','<span>Consultar das</span>').replace('<span>Duração da nova aula</span>','<span>Duração da aula</span>');
 doc=doc.replace('hidden>Esta semana</button>','hidden>Mês atual</button>');
 doc=doc.replace('Mês atual completo</strong>','Próximas datas do mês atual</strong>');
 doc=doc.replace('[1,2,3,4,5,6,0].map(weeklyAvailabilityDayHtml)','[0,1,2,3,4,5,6].map(weeklyAvailabilityDayHtml)');
 return doc.replace('</head>','<style id="ap-availability-compact-css">'+read('availability-compact.css')+'</style></head>');
};
