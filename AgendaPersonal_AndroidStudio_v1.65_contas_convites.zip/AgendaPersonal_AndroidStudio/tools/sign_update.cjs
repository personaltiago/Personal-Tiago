'use strict';

const {createHash} = require('node:crypto');
const {spawnSync} = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

function packageDigest(update) {
  const digest = createHash('sha256');
  digest.update('Agenda Personal update v1\n');
  function string(value) {
    const bytes = Buffer.from(value, 'utf8');
    if (bytes.toString('utf8') !== value) throw Error('Texto inválido no pacote.');
    const length = Buffer.alloc(4);
    length.writeUInt32BE(bytes.length);
    digest.update('s').update(length).update(bytes);
  }
  function append(value, depth) {
    if (depth > 64) throw Error('Metadados complexos demais.');
    if (Array.isArray(value)) {
      digest.update('[');
      for (const item of value) append(item, depth + 1);
      digest.update(']');
    } else if (value === null) {
      digest.update('n');
    } else if (typeof value === 'object') {
      digest.update('{');
      for (const key of Object.keys(value).sort()) {
        if (depth === 0 && key === 'agendaSignature') continue;
        string(key);
        append(value[key], depth + 1);
      }
      digest.update('}');
    } else if (typeof value === 'string') {
      string(value);
    } else if (typeof value === 'boolean') {
      digest.update(value ? 't' : 'f');
    } else if (Number.isSafeInteger(value)) {
      digest.update('#' + value + ';');
    } else {
      throw Error('Número inválido no pacote.');
    }
  }
  append(update, 0);
  return digest.digest();
}

function main() {
  const [source, target] = process.argv.slice(2);
  if (!source || !target || path.resolve(source) === path.resolve(target))
    throw Error('Use node tools/sign_update.cjs origem.agenda.json destino.agenda.json.');
  const limit = 32 * 1024 * 1024;
  if (fs.statSync(source).size > limit) throw Error('O arquivo ultrapassa o limite de 24 MiB.');
  const update = JSON.parse(fs.readFileSync(source, 'utf8'));
  if (update?.appId !== 'com.tiagolima.agendapersonal' ||
      ![1, 'agenda-patch/1', 'agenda-patch/2'].includes(update.format))
    throw Error('Escolha um pacote de atualização do Agenda Personal.');
  const signer = spawnSync('java', [path.join(__dirname, 'SignAgendaUpdate.java')], {
    input: packageDigest(update), encoding: 'utf8'
  });
  if (signer.status !== 0) throw Error('Falha ao assinar com a chave Android configurada.');
  update.agendaSignature = signer.stdout.trim();
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(update.agendaSignature))
    throw Error('O assinador retornou um resultado inválido.');
  const output = JSON.stringify(update);
  if (Buffer.byteLength(output) > limit) throw Error('O pacote assinado ultrapassa o limite de 24 MiB.');
  fs.writeFileSync(target, output, {flag:'wx'});
}

module.exports = {packageDigest};
if (require.main === module) {
  try { main(); } catch (failure) {
    console.error(failure.message);
    process.exitCode = 1;
  }
}
