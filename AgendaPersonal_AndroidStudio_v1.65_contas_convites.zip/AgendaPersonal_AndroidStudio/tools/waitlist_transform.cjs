'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
module.exports=function(doc){
 const read=f=>fs.readFileSync(path.resolve(__dirname,'../web/'+f),'utf8');
 const blank='financeExpenses:[],lessonTimers:{}';assert.ok(doc.includes(blank));doc=doc.replace(blank,'financeExpenses:[],waitlist:[],lessonTimers:{}');
 const normal='  d.workoutRest=';assert.ok(doc.includes(normal));doc=doc.replace(normal,'  d.waitlist=Array.isArray(d.waitlist)?d.waitlist:[];\n'+normal);
 const nav="['today','week','availability'].includes(screen)?'week'";assert.ok(doc.includes(nav));doc=doc.replace(nav,"['today','week','availability','waitlist'].includes(screen)?'week'");
 const drawing='<circle cx="7.5" cy="5.8" r="3.3"/><path d="M1.8 20v-3.5a5.7 5.7 0 0 1 9.5-4.3 7.5 7.5 0 0 0-.3 7.8Z"/><path fill-rule="evenodd" d="M17 9.8a6.2 6.2 0 1 1 0 12.4 6.2 6.2 0 0 1 0-12.4Zm0 2.1a4.1 4.1 0 1 0 0 8.2 4.1 4.1 0 0 0 0-8.2Z"/><path d="M16.1 13h1.8v2.5l1.8 1.1-.9 1.5-2.7-1.6Z"/>';
 const tools='<div class="agenda-tools-row">',button='<button type="button" class="btn wl-open" onclick="openWaitlist()"><span class="wl-shortcut-icon" aria-hidden="true"><svg data-waitlist-icon viewBox="0 0 24 24" fill="currentColor">'+drawing+'</svg></span><span class="wl-shortcut-label">Lista de espera</span><span class="wl-shortcut-count" data-waitlist-count></span></button>';
 assert.equal(doc.split(tools).length-1,2);doc=doc.replaceAll(tools,'<div class="agenda-tools-row wl-agenda-tools">'+button);
 // Use the existing depth renderer so matte icons follow the selected hue.
 const model=' function model(svg){';assert.equal(doc.split(model).length-1,2);
 doc=doc.replaceAll(model,' solid.waitlist='+JSON.stringify(drawing)+';\n'+model+'\n  if(svg.hasAttribute("data-waitlist-icon"))return "waitlist";');
 const screen='<section id="screen-availability"';assert.ok(doc.includes(screen));doc=doc.replace(screen,read('waitlist.html')+screen);
 const ending=/<\/body>(\s*<\/html>\s*)$/i;assert.ok(ending.test(doc));
 const js=f=>minify_sync(read(f),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
 doc=doc.replace('<head>','<head><script id="ap-waitlist-model">'+js('waitlist-model.js')+'</script>');
 return doc.replace(ending,(_,tail)=>'<style id="ap-waitlist-css">'+read('waitlist.css')+'</style><script id="ap-waitlist">'+js('waitlist.js')+'</script></body>'+tail);
};
