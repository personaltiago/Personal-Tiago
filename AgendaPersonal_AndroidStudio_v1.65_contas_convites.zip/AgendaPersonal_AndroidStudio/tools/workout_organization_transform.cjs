'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const start=doc.indexOf(' renderWorkouts=function(){'),end=doc.indexOf(' openExerciseHub=function(id)',start);
 assert.ok(start>=0&&end>start,'Expected production student workout renderer');
 doc=doc.slice(0,start)+fs.readFileSync(path.resolve(__dirname,'../web/workout-organization.js'),'utf8')+'\n'+doc.slice(end);
 const old="wsMode=context().area?.plans.some(p=>p.organization==='week')?'days':'letters';";
 assert.equal(doc.split(old).length-1,1);
 doc=doc.replace(old,"const savedMode=APstudentStorage.getItem(modeStorageKey());wsMode=['days','letters'].includes(savedMode)?savedMode:context().area?.plans.some(p=>p.organization==='week')?'days':'letters';");
 const weekday='weekday:Number.isInteger(Number(d.weekday))?Number(d.weekday):null';
 assert.equal(doc.split(weekday).length-1,1);
 doc=doc.replace(weekday,"weekday:d.weekday!==null&&d.weekday!==undefined&&d.weekday!==''&&Number.isInteger(Number(d.weekday))&&Number(d.weekday)>=0&&Number(d.weekday)<=6?Number(d.weekday):null");
 const anchor='<script id="ap-student-ui">';assert.ok(doc.includes(anchor));
 const art=fs.readFileSync(path.resolve(__dirname,'../web/workout-muscle-art-data.js'),'utf8');
 const muscles=fs.readFileSync(path.resolve(__dirname,'../web/workout-muscle-preview.js'),'utf8');
 doc=doc.replace(anchor,'<script id="ap-workout-muscle-preview">'+art+'\n'+muscles+'</script>'+anchor);
 return doc.replace('</head>','<style id="ap-workout-organization-css">'+fs.readFileSync(path.resolve(__dirname,'../web/workout-organization.css'),'utf8')+'</style></head>');
};
