'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const start=doc.indexOf(' renderWorkouts=function(){'),end=doc.indexOf(' openExerciseHub=function(id)',start);
 assert.ok(start>=0&&end>start,'Expected production student workout renderer');
 doc=doc.slice(0,start)+fs.readFileSync(path.resolve(__dirname,'../web/workout-organization.js'),'utf8')+'\n'+doc.slice(end);
 const old="wsMode=context().area?.plans.some(p=>p.organization==='week')?'days':'letters';";
 assert.equal(doc.split(old).length-1,1);
 doc=doc.replace(old,"const savedMode=APstudentStorage.getItem(modeStorageKey());wsMode=['days','letters'].includes(savedMode)?savedMode:context().area?.plans.some(p=>p.organization==='week')?'days':'letters';");
 const weekday='weekday:Number.isInteger(Number(d.weekday))?Number(d.weekday):null';
 assert.equal(doc.split(weekday).length-1,1);
 doc=doc.replace(weekday,"weekday:d.weekday!==null&&d.weekday!==undefined&&d.weekday!==''&&Number.isInteger(Number(d.weekday))&&Number(d.weekday)>=0&&Number(d.weekday)<=6?Number(d.weekday):null");
 const anchor='<script id="ap-student-ui">';assert.ok(doc.includes(anchor));
 let art=fs.readFileSync(path.resolve(__dirname,'../web/workout-muscle-art-data.js'),'utf8');
 // Preserve the artwork and its licence. Subpixel path precision was taking
 // 35 KiB in the update entry; 0.05 source pixels is below display resolution.
 const assignment='window.APWorkoutMuscleArt=',at=art.indexOf(assignment);
 assert.ok(at>=0);
 const data=JSON.parse(art.slice(at+assignment.length).trim().replace(/;$/,''));
 for(const mask of data.masks){
  mask.d=mask.d.replace(/-?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?/g,(n,offset,source)=>{
   const rounded=Math.round(Number(n)*10)/10;
   // SVG allows adjacent numbers separated only by '-' or a second dot.
   // Preserve those token boundaries when rounding -0.00001 or .49999.
   const token=rounded===0&&n.startsWith('-')?'-0':String(rounded);
   return offset>0&&/[\d.]/.test(source[offset-1])&&!token.startsWith('-')?' '+token:token;
  });
  for(const key of ['x','y'])mask[key]=Math.round(mask[key]*100)/100;
  mask.bounds=mask.bounds.map(n=>Math.round(n*100)/100);
 }
 art=art.slice(0,at)+assignment+JSON.stringify(data)+';';
 const muscles=fs.readFileSync(path.resolve(__dirname,'../web/workout-muscle-preview.js'),'utf8');
 doc=doc.replace(anchor,'<script id="ap-workout-muscle-preview">'+art+'\n'+muscles+'</script>'+anchor);
 return doc.replace('</head>','<style id="ap-workout-organization-css">'+fs.readFileSync(path.resolve(__dirname,'../web/workout-organization.css'),'utf8')+'</style></head>');
};
