'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=n=>fs.readFileSync(path.join(__dirname,'../web',n),'utf8');
const watchIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="6" width="14" height="12" rx="3"/><path d="m8 6 1-4h6l1 4m-8 12 1 4h6l1-4m-4-9v3l2 1m5-3h1"/></svg>';
const sendButton='<button type="button" class="ap-watch-send-icon" aria-label="Enviar treino ao smartwatch" title="Enviar treino ao smartwatch">'+watchIcon+'</button>';
const common=()=>'<style>'+read('watch-workout.css')+read('watch-history.css')+'</style><script id="ap-watch-model">'+read('watch-workout-model.js')+'</script><script id="ap-watch-ui">'+read('watch-workout-ui.js')+'</script><script id="ap-watch-history">'+read('watch-history.js')+'</script>';
exports.teacher=function(html){
 const hook=`<script id="ap-watch-teacher">(function(){
 const menu=document.getElementById('screen-more'),anchor=document.getElementById('morePet');
 if(menu&&anchor?.parentElement&&!document.getElementById('moreSmartwatch')){
  const card=document.createElement('button');card.id='moreSmartwatch';card.type='button';card.className=anchor.className.replace(/more-function-primary/g,'').trim();card.setAttribute('aria-pressed','false');card.setAttribute('aria-describedby','apMoreSelectHint');card.setAttribute('aria-haspopup','dialog');card.setAttribute('aria-controls','apWatchSetup');
  card.innerHTML='<span class="more-function-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="6" width="14" height="12" rx="3"/><path d="m8 6 1-4h6l1 4m-8 12 1 4h6l1-4m-4-9v3l2 1m5-3h1"/></svg></span><span class="more-function-copy"><strong>Smartwatch</strong><small>Conexão e treinos no relógio.</small></span><span class="more-chevron"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></span>';
  card.onclick=()=>APWatchUI.setup('teacher');anchor.parentElement.prepend(card);
 }
 const original=workoutSessionHtml;
 workoutSessionHtml=function(plan,day,running){
  const content=original(plan,day,running),heading=running?'Treino em andamento':'Visualização do treino';
  return content.replace('<strong>'+heading+'</strong>','<div class="ap-watch-session-heading"><strong>'+heading+'</strong>'+${JSON.stringify(sendButton.replace('<button ', '<button onclick="APsendTeacherWatchWorkout()" '))}+'</div>');
 };
 window.APsendTeacherWatchWorkout=function(){
  try{
   if(window.parent?.APaccounts?.isTeacher()!==true)throw Error('Entre com a conta do professor.');
   const plan=currentWorkoutPlan(),day=currentWorkoutDay(),student=studentById(plan?.studentId);
   if(!plan||!day||!student||workoutPlanArchived(plan))throw Error('Escolha uma ficha ativa e um aluno.');
   if(workoutRunning(plan,day))throw Error('Encerre a execução no celular antes de iniciar outra no relógio.');
   const area=APStudentModel.makeArea(state,student,{visible:p=>p.id===plan.id,groups:window.workoutBisetGroups,shared:window.workoutBisetExercisePrescription,prescription:window.workoutTechniqueRoundPrescription});
   const workout=APStudentModel.workouts(area).find(w=>w.planId===plan.id&&w.dayId===day.id);
   APWatchUI.send(workout,'teacher',student.name);
  }catch(error){toast(error.message)}
 };
})();</script>`;
 assert.ok(html.includes('function workoutSessionHtml('));return html.replace('</body>',common()+hook+'</body>');
};
exports.entry=function(html){
 const clear="function clear(){window.Android?.setUpdateAccount?.('');";
 assert.ok(html.includes(clear),'Wear account cleanup hook');
 html=html.replace(clear,"function clear(preserveWatch=false){if(!preserveWatch)window.Android?.setWatchAccount?.('');window.Android?.setUpdateAccount?.('');");
 assert.ok(html.includes('window.APstartup.begin();clear();'),'Wear activation hook');
 html=html.replace('window.APstartup.begin();clear();','window.APstartup.begin();clear(true);');
 html=html.replaceAll('window.Android?.setUpdateAccount?.(user.uid);','window.Android?.setUpdateAccount?.(user.uid);window.Android?.setWatchAccount?.(user.uid);');
 html=html.replace("if(!user){if(identity)clear();", "if(!user){window.Android?.setWatchAccount?.('');if(identity)clear();");

 const anchor='window.APstudentUI=Object.freeze({activate,repaint,reset,status:banner});';
 assert.ok(html.includes(anchor),'Student watch adapter anchor');
 const hook=`
 const watchRender=renderExerciseApp;
 renderExerciseApp=function(){
  watchRender();
  const title=document.querySelector('#exerciseScreen .ex-header-title');if(!title)return;
  title.querySelector('.ap-watch-send-icon')?.remove();title.classList.remove('ap-watch-title');
  if(context()?.role!=='student')return;
  const template=document.createElement('template');template.innerHTML=${JSON.stringify(sendButton)};
  const button=template.content.firstElementChild;
  button.onclick=()=>{
   if(context()?.role!=='student'||context()?.storageId!==APaccounts.context()?.storageId)return toast('Entre na sua conta de aluno.');
   if(exGetSession())return toast('Encerre a execução no celular antes de iniciar outra no relógio.');
   APWatchUI.send(workout(exActiveId),'student',context().profile.name);
  };
  title.classList.add('ap-watch-title');title.append(button);
 };
 `;
 html=html.replace(anchor,hook+anchor);
 return html.replace('</body></html>',common()+'</body></html>');
};
