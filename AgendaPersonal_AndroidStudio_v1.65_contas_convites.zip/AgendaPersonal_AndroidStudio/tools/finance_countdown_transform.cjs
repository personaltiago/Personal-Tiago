'use strict';
const assert=require('node:assert/strict');
module.exports=function(doc){
 const anchor="document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshAgendaState()});";
 assert.ok(doc.includes(anchor),'Missing teacher resume handler');
 // Count calendar days, refresh at the next local midnight, and catch up after
 // the WebView has been suspended. The existing clock remains a fallback.
 return doc.replace(anchor,`let financeMidnightTimer;
function scheduleFinanceCountdown(){
 clearTimeout(financeMidnightTimer);
 const now=new Date(),next=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1);
 financeMidnightTimer=setTimeout(()=>{updateClock();scheduleFinanceCountdown()},Math.max(1,next.getTime()-now.getTime()+50));
}
function resumeFinanceCountdown(){updateClock();scheduleFinanceCountdown()}
scheduleFinanceCountdown();
window.addEventListener?.('focus',resumeFinanceCountdown);
window.addEventListener?.('pageshow',resumeFinanceCountdown);
document.addEventListener('visibilitychange',()=>{if(!document.hidden){refreshAgendaState();resumeFinanceCountdown()}});`);
};
