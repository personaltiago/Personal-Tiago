'use strict';
// Mechanical PNG conversion only. Never redraw, crop, recolor or distort the approved artwork.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),res=path.join(root,'app/src/main/res');
const source=path.join(root,'branding/app-icon-original.png');
function convert(args){const r=spawnSync('convert',args,{encoding:'utf8'});if(r.error)throw r.error;if(r.status!==0)throw Error(r.stderr)}
const densities=[['mdpi',1],['hdpi',1.5],['xhdpi',2],['xxhdpi',3],['xxxhdpi',4]];
for(const [name,scale]of densities){
 const dir=path.join(res,'mipmap-'+name);fs.mkdirSync(dir,{recursive:true});
 const legacy=Math.round(48*scale),layer=Math.round(108*scale),art=Math.round(64*scale);
 convert([source,'-colorspace','sRGB','-filter','Lanczos','-resize',legacy+'x'+legacy,'-strip','PNG24:'+path.join(dir,'ic_launcher.png')]);
 convert([source,'-colorspace','sRGB','-filter','Lanczos','-resize',art+'x'+art,'-alpha','set','-background','none','-gravity','center','-extent',layer+'x'+layer,'-strip','PNG32:'+path.join(dir,'ic_launcher_foreground.png')]);
}
const xml='<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/launcher_background" />\n    <foreground android:drawable="@mipmap/ic_launcher_foreground" />\n</adaptive-icon>\n';
const any=path.join(res,'mipmap-anydpi-v26');fs.mkdirSync(any,{recursive:true});
for(const name of ['ic_launcher','ic_launcher_round'])fs.writeFileSync(path.join(any,name+'.xml'),xml);
fs.writeFileSync(path.join(res,'values/launcher_colors.xml'),'<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="launcher_background">#080B04</color>\n</resources>\n');
convert([source,'-colorspace','sRGB','-filter','Lanczos','-resize','512x512','-strip','PNG24:'+path.join(res,'drawable-nodpi/app_icon.png')]);
console.log('Launcher icons generated in five densities; adaptive foreground 64dp centered in a 108dp layer.');
