'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
const read=n=>fs.readFileSync(path.resolve(__dirname,'../web/'+n),'utf8');
exports.teacher=function(doc){assert.ok(doc.includes("const DB_KEY='agendaPersonalTL_v1';"));const js=['teacher-sync-model.js','teacher-sync-preferences.js','teacher-sync.js'].map(n=>minify_sync(read(n),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code).join(';');return doc.replace('</head>','<style id="ap-teacher-sync-core-style">'+read('teacher-sync.css')+'</style></head>').replace('</body>','<script id="ap-teacher-sync-core">'+js+'</script></body>')};
exports.assessment=function(doc){
 const start=doc.indexOf('  async function writeState(state) {'),end=doc.indexOf('  function findAssessment(',start);assert.ok(start>=0&&end>start);let part=doc.slice(start,end);assert.ok(part.includes('transaction.oncomplete = () => resolve();'));part=part.replace('localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); return;','localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); assessmentCloudSaved(); return;').replace('transaction.oncomplete = () => resolve();','transaction.oncomplete = () => { assessmentCloudSaved(); resolve(); };');
 const notify="  function assessmentCloudSaved(){try{window.parent.document.getElementById('apPreviewTeacher')?.contentWindow.APTeacherSync?.changed();window.parent.document.getElementById('apPreviewTeacher')?.contentWindow.APStudentFollowup?.refresh()}catch(_){}}\n";
 return doc.slice(0,start)+notify+part+doc.slice(end);
};
