'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=n=>fs.readFileSync(path.join(__dirname,'../web',n),'utf8');
function replace(s,a,b){assert.ok(s.includes(a),'Timed series anchor: '+a.slice(0,110));return s.replace(a,b)}
function script(doc,marker,patch){const start=doc.indexOf('<script '+marker),a=doc.indexOf('>',start)+1,b=doc.indexOf('</script>',a);assert.ok(start>=0&&b>a,marker);return doc.slice(0,a)+patch(doc.slice(a,b))+doc.slice(b)}
module.exports=function(doc){
 doc=script(doc,'data-agenda-workout-series',s=>{
  s=replace(s,'const attrs=rowAttributes(ex,row,options);','const attrs=rowAttributes(ex,row,options),timed=window.APTimedSeries?.isTimed(row.targetReps)===true;');
  s=replace(s,'<span role="columnheader">Repetições</span>','<span role="columnheader">${rows.every(r=>window.APTimedSeries?.isTimed(r.targetReps))?\'Tempo (s)\':rows.some(r=>window.APTimedSeries?.isTimed(r.targetReps))?\'Rep. / tempo\':\'Repetições\'}</span>');
  s=replace(s,"const lastReps=previous?.values[row.round],lastLabel=lastReps===undefined?'Sem repetições registradas para esta série no último treino':lastReps+' repetições no último treino'+(previous.date?' · '+workoutDateLabel(previous.date):'');", "const lastReps=previous?.values[row.round],lastTimed=previous?.units?.[row.round]==='seconds',lastDisplay=lastReps===undefined?'—':lastTimed?lastReps+' s':lastReps,lastLabel=lastReps===undefined?'Sem resultado registrado para esta série no último treino':lastReps+(lastTimed?' segundos':' repetições')+' no último treino'+(previous.date?' · '+workoutDateLabel(previous.date):'');");
  s=replace(s,"${lastReps===undefined?'—':lastReps}",'${lastDisplay}');
  s=replace(s,'<div role="cell"><input ${currentIds?\'id="workoutBisetReps"','<div role="cell"${timed?\' class="ws-time-cell"\':\'\'}><input ${currentIds?\'id="workoutBisetReps"');
  s=replace(s,'class="ws-set-input" aria-label="Repetições feitas','class="ws-set-input${timed?\' ws-timed-value\':\'\'}" aria-label="${timed?\'Segundos realizados\':\'Repetições feitas\'}');
  s=replace(s,'type="number" inputmode="numeric" min="1" max="999"','type="${timed?\'hidden\':\'number\'}" inputmode="numeric" min="1" max="${timed?86400:999}"');
  s=replace(s,'<small class="ws-set-target">Meta:','${timed?APTimedSeries.button(ex,row,options,attrs):\'\'}<small class="ws-set-target">Meta:');
  s=replace(s,"if(!Number.isInteger(reps)||reps<1||reps>999){input.checked=false;toast('Informe as repetições realizadas nesta série, de 1 a 999.');", "const timed=window.APTimedSeries?.isTimed(ctx.row.targetReps)===true;\n    if(!Number.isInteger(reps)||reps<1||reps>(timed?86400:999)){input.checked=false;toast(timed?'Use o cronômetro para registrar os segundos realizados.':'Informe as repetições realizadas nesta série, de 1 a 999.');");
  s=replace(s,'series[ctx.round]={round:ctx.round,done:true,reps,load,','series[ctx.round]={round:ctx.round,done:true,reps,...(timed?{unit:\'seconds\',seconds:reps}:{}),load,');
  s=replace(s,'{...draft,values:{...draft.values,[ex.id]:value}}','{...draft,seriesClock:draft.seriesClock?.exerciseId===ex.id&&series[draft.seriesClock.round]?.done?null:draft.seriesClock,values:{...draft.values,[ex.id]:value}}');
  s=replace(s,"reps:String(last.reps),load:last.load", "reps:last.unit==='seconds'?last.seconds+' s':String(last.reps),...(last.unit==='seconds'?{unit:'seconds'}:{}),load:last.load");
  s=replace(s,'<th>Repetições</th><th>Carga</th>','<th>Repetições / tempo</th><th>Carga</th>');
  s=replace(s,'<td>${row.reps}</td>','<td>${window.APTimedSeries?APTimedSeries.rowText(row):row.reps}</td>');
  s=replace(s,"['Série','Repetições feitas','Carga usada']","['Série','Repetições / tempo','Carga usada']");
  s=replace(s,'String(row.reps),row.load',"(window.APTimedSeries?APTimedSeries.rowText(row):String(row.reps)),row.load");
  return s;
 });
 doc=script(doc,'data-agenda-bisets',s=>{
  s=s.replaceAll('integer(r.A.reps,1,999)',"integer(r.A.reps,1,r.A.unit==='seconds'?86400:999)").replaceAll('integer(r.B.reps,1,999)',"integer(r.B.reps,1,r.B.unit==='seconds'?86400:999)");
  s=replace(s,"const ex=groupExercise(day,g,day.exercises.find(ex=>ex.id===g.exerciseIds[part==='A'?0:1])),performed=", "const ex=groupExercise(day,g,day.exercises.find(ex=>ex.id===g.exerciseIds[part==='A'?0:1])),performed=");
  s=replace(s,"if(load.length>60||!integer(reps,1,999))return toast('Informe as repetições feitas, de 1 a 999, e a carga usada.');", "const timedEx=groupExercise(day,g,day.exercises.find(e=>e.id===g.exerciseIds[part==='A'?0:1])),timed=window.APTimedSeries?.isTimed(workoutTechniqueRoundPrescription(timedEx,index+1,g.rounds)?.reps||timedEx.reps)===true;\n    if(load.length>60||!integer(reps,1,timed?86400:999))return toast(timed?'Use o cronômetro para registrar os segundos realizados.':'Informe as repetições feitas, de 1 a 999, e a carga usada.');");
  s=replace(s,'performed={reps,load,completedAt:','performed={reps,...(timed?{unit:\'seconds\',seconds:reps}:{}),load,completedAt:');
  s=replace(s,"const changes={workoutDrafts:draftWithJournal(p,day,g,next,values)};if(rest)","const updatedDrafts=draftWithJournal(p,day,g,next,values);if(updatedDrafts[key].seriesClock?.exerciseId===ex.id)updatedDrafts[key]={...updatedDrafts[key],seriesClock:null};\n    const changes={workoutDrafts:updatedDrafts};if(rest)");
  s=replace(s,'sets:String(performedSets.length),reps:String(last.reps),load:last.load',"sets:String(performedSets.length),reps:last.unit==='seconds'?last.seconds+' s':String(last.reps),...(last.unit==='seconds'?{unit:'seconds'}:{}),load:last.load");
  s=replace(s,'`${set.reps} rep. · ${set.load',"`${set.unit==='seconds'?set.seconds+' s':set.reps+' rep.'} · ${set.load");
  return s;
 });
 doc=replace(doc,'values:restart?{}:old?.values||{},','seriesClock:restart?null:old?.seriesClock||null,values:restart?{}:old?.values||{},');
 doc=replace(doc,'...state.workoutDrafts[key],values:{}}','...state.workoutDrafts[key],seriesClock:null,values:{}}');
 doc=replace(doc,'values:{},bisets:{}}','values:{},bisets:{},seriesClock:null}');
 doc=replace(doc,'<th scope="col">Rep.</th>','<th scope="col">${exercises.some(ex=>ex.unit===\'seconds\'||ex.performedSets?.some(r=>r.unit===\'seconds\'))?\'Rep. / tempo\':\'Rep.\'}</th>');
 doc=replace(doc,"pdf.table(['Exercício','Séries','Rep.','Carga',","pdf.table(['Exercício','Séries',exercises.some(ex=>ex.unit==='seconds'||ex.performedSets?.some(r=>r.unit==='seconds'))?'Rep. /\\ntempo':'Rep.','Carga',");
 doc=replace(doc,'aria-label="Repetições realizadas no último treino"','aria-label="Resultado da última realização"');
 doc=replace(doc,'function openWorkoutExecution(){','function openWorkoutExecution(){\n  if(window.APTimedSeries?.clockFor(currentWorkoutPlan(),currentWorkoutDay()))return toast(\'Pare o cronômetro da série antes de finalizar o treino.\');');
 doc=replace(doc,"const key=workoutDraftKey(p.id,day.id),draft=state.workoutDrafts[key],token=document.getElementById('workoutExecutionSessionId').value;","if(window.APTimedSeries?.clockFor(p,day))return toast('Pare o cronômetro da série antes de finalizar o treino.');\n  const key=workoutDraftKey(p.id,day.id),draft=state.workoutDrafts[key],token=document.getElementById('workoutExecutionSessionId').value;");
 doc=replace(doc,'<script id="ap-workout-previous-series">','<script id="ap-workout-timed-series">'+read('workout-timed-series.js')+'</script><script id="ap-workout-previous-series">');
 return doc.replace('</head>','<style id="ap-workout-timed-series-css">'+read('workout-timed-series.css')+'</style></head>');
};
