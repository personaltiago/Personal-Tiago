'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
module.exports=function(doc){
 const anchor='<div class="home-quick-grid">';assert.equal(doc.split(anchor).length,2);
 const card='<div id="apTeacherMascotOpen" class="home-card ap-teacher-mascot"><button type="button" class="ap-habitat-open" aria-label="Fazer carinho no mascote"><span class="ap-teacher-mascot-mark" aria-hidden="true"></span><span class="ap-teacher-mascot-copy"><strong data-mascot-name></strong><span class="ap-mascot-speech" id="apTeacherMascotMessage">Estou por aqui para acompanhar seu dia.</span></span></button><button type="button" class="ap-habitat-house" aria-label="Abrir a loja e personalizar o mascote" onclick="window.parent.postMessage({kind:\'AP_OPEN_TEACHER_MASCOT\',tab:\'house\'},\'*\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 10 9-7 9 7M5 9v12h14V9M9 21v-7h6v7"/></svg><span>Casa</span></button></div>';

 doc=doc.replace(anchor,card+anchor);
 const css='.ap-teacher-mascot{display:flex;align-items:center;gap:14px;width:100%;margin:0 0 16px;text-align:left;color:inherit;cursor:pointer;font:inherit}.ap-teacher-mascot-mark{width:54px;height:54px;flex:0 0 54px;padding:7px;background:var(--surface);border-radius:14px;color:var(--primary)}.ap-teacher-mascot-mark svg{display:block;width:100%;height:100%}.ap-teacher-mascot>span:nth-child(2){flex:1;min-width:0}.ap-teacher-mascot strong{display:block;font-size:16px}.ap-teacher-mascot small{display:block;font-size:13px;line-height:1.5;margin-top:3px}.ap-teacher-mascot>span:last-child{font-size:26px}';
 // The authenticated parent supplies the selected portrait before first paint.
 // A fixed animal here would flash before the account's choice is restored.
 doc=doc.replace(/(<span class="ap-teacher-mascot-mark"[^>]*>)[\s\S]*?<\/span>/,(_,open)=>open+'</span>');
 doc=doc.replace('</body>','<script id="ap-teacher-mascot-day">'+fs.readFileSync(path.resolve(__dirname,'../web/teacher-mascot-day.js'),'utf8')+'</script></body>');
 return doc.replace('</head>','<style id="ap-teacher-mascot-card-css">'+css+fs.readFileSync(path.resolve(__dirname,'../web/mascot-daily-message.css'),'utf8')+'.ap-teacher-mascot-mark{padding:0!important;overflow:hidden;background:#faf6f1!important}.ap-teacher-mascot-mark img,.ap-teacher-mascot-mark svg{display:block;width:100%;height:100%;object-fit:contain}'+fs.readFileSync(path.resolve(__dirname,'../web/mascot-homes.css'),'utf8')+fs.readFileSync(path.resolve(__dirname,'../web/mascot-petting.css'),'utf8')+'</style></head>');
};
