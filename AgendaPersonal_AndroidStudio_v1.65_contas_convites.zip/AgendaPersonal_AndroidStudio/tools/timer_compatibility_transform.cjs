'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const replace=(from,to,count=1)=>{assert.equal(doc.split(from).length-1,count,'Timer compatibility anchor: '+from.slice(0,90));doc=doc.replaceAll(from,to)};
 replace('const state=load();','const state=load();window.APTimerCompatibility.migrate(state,DB_KEY);');
 replace('Object.assign(state,load());renderAll();','Object.assign(state,load());window.APTimerCompatibility.migrate(state,DB_KEY);renderAll();');
 replace('native=Android.startLessonTimer(JSON.stringify(', 'native=window.APTimerCompatibility.startLessonTimer(JSON.stringify(');
 replace('rest.native=Android.startWorkoutRest(JSON.stringify(', 'rest.native=window.APTimerCompatibility.startWorkoutRest(JSON.stringify(',2);
 replace("return timer.native===true?'Despertador de fim da aula programado.':window.Android?", "return timer.native===true?'Despertador de fim da aula programado.':window.APTimerCompatibility.legacy()?'Contagem no aplicativo. Mantenha-o aberto para ouvir o aviso de fim.':window.Android?");
 replace('retry.hidden=!window.Android||timer.native===true', 'retry.hidden=window.APTimerCompatibility.legacy()||!window.Android||timer.native===true');
 replace("r.native?'Aviso do intervalo programado no Android.':window.Android?", "r.native?'Aviso do intervalo programado no Android.':window.APTimerCompatibility.legacy()?'Contagem no aplicativo. Mantenha-o aberto para ouvir o aviso.':window.Android?");
 replace("window.Android?'Contagem iniciada sem despertador confirmado.", "window.APTimerCompatibility.legacy()?'Contagem iniciada no aplicativo. Mantenha-o aberto para ouvir o aviso.':window.Android?'Contagem iniciada sem despertador confirmado.");
 replace("window.Android?'Treino iniciado e contagem ativada.", "window.APTimerCompatibility.legacy()?'Treino iniciado. Contagem no aplicativo; mantenha-o aberto para ouvir o aviso.':window.Android?'Treino iniciado e contagem ativada.");
 replace("result.native?'Despertador programado para o fim da contagem.':'Não foi possível", "result.native?'Despertador programado para o fim da contagem.':window.APTimerCompatibility.legacy()?'Contagem ativa no aplicativo. Mantenha-o aberto para ouvir o aviso.':'Não foi possível");
 const helper=fs.readFileSync(path.join(__dirname,'../web/timer-compatibility.js'),'utf8');
 return doc.replace('<head>','<head><script id="ap-timer-compatibility">'+helper+'</script>');
};
