'use strict';
const assert=require('node:assert/strict');
module.exports=function(doc){
 // The reused timer is cloned to attach the student ID. Object identity cannot
 // indicate reuse; otherwise stopping a preview cancels an independent lesson.
 const before="const timer=!restart&&existing&&Number(existing.endAt)>Date.now()?{...existing,studentId:plan.studentId}:";
 const after="const reusedExisting=!!(!restart&&existing&&Number(existing.endAt)>Date.now());\n  const timer=reusedExisting?{...existing,studentId:plan.studentId}:";
 assert.equal(doc.split(before).length,2,'workout timer reuse condition');
 assert.equal(doc.split('reusedExisting:!restart&&timer===existing').length,2,'workout timer reuse flag');
 return doc.replace(before,after).replace('reusedExisting:!restart&&timer===existing','reusedExisting');
};
