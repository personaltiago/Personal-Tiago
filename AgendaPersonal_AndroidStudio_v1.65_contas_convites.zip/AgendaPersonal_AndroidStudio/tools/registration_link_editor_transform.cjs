'use strict';
const assert=require('node:assert/strict');
module.exports=function(doc){
 const greeting="encodeURIComponent('Olá! Preencha seu cadastro na Agenda Personal: '+url)";
 assert.equal(doc.split(greeting).length-1,1,'Registration WhatsApp message missing or ambiguous');
 doc=doc.replace(greeting,'encodeURIComponent(url)');
 const editor=/<details class="registration-config" id="registrationConfig">[\s\S]*?<\/details>/;
 assert.ok(editor.test(doc),'Registration link settings missing');
 doc=doc.replace(editor,`<button id="registrationEdit" class="btn registration-edit-link" type="button" aria-expanded="false" aria-controls="registrationConfig" onclick="editRegistrationLink()">Alterar link</button>
      <section class="registration-config" id="registrationConfig" aria-labelledby="registrationEditTitle" hidden><h4 id="registrationEditTitle">Alterar link de cadastro</h4><form id="registrationUrlForm"><label class="field full"><span>Novo endereço do formulário</span><input id="registrationUrlSetting" type="url" inputmode="url" placeholder="https://seu-site.com/cadastro.html" required autocomplete="url" autocapitalize="none" spellcheck="false" aria-describedby="registrationEditHelp"></label><p id="registrationEditHelp" class="registration-settings-message">Cole o endereço completo da página de cadastro. Depois de salvar, ele será usado para copiar e enviar pelo WhatsApp.</p><div class="registration-editor-actions"><button id="registrationSave" class="btn primary" type="submit">Salvar link</button><button id="registrationCancel" class="btn" type="button" onclick="cancelRegistrationLinkEdit()">Cancelar</button></div></form></section>`);
 const old="el('registrationConfig').open=!url;";assert.ok(doc.includes(old));
 doc=doc.replace(old,"el('registrationConfig').hidden=Boolean(url);el('registrationEdit').setAttribute('aria-expanded',String(!url));");
 const start='  function saveUrl(event){';assert.ok(doc.includes(start));
 doc=doc.replace(start,`  function editLink(){
    el('registrationUrlSetting').value=currentUrl();el('registrationConfig').hidden=false;el('registrationEdit').setAttribute('aria-expanded','true');say('');
    el('registrationUrlSetting').focus();el('registrationUrlSetting').select();el('registrationConfig').scrollIntoView({block:'nearest',behavior:'smooth'});
  }
  function cancelEdit(){renderLink();say('');el('registrationEdit').focus()}
`+start);
 const exports='window.openRegistrationLink=open;';assert.ok(doc.includes(exports));doc=doc.replace(exports,'window.editRegistrationLink=editLink;window.cancelRegistrationLinkEdit=cancelEdit;'+exports);
 const css=`#registrationConfig[hidden]{display:none!important}.registration-edit-link{display:block;width:100%;min-height:48px;margin-top:18px;color:var(--ac-accent,var(--purple));font-weight:700}.registration-config{padding:16px;margin-top:12px;border:1px solid var(--ac-line,var(--line));border-radius:14px;background:var(--ac-field,var(--panel))}.registration-config h4{margin:0 0 14px;font-size:1rem;color:var(--ac-text,var(--text))}.registration-editor-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:14px}.registration-editor-actions .btn{width:100%;min-height:46px}.registration-config .registration-settings-message{color:var(--ac-muted,var(--muted));line-height:1.5}#registrationUrlSetting{min-width:0;width:100%}@media(max-width:350px){.registration-config{padding:12px}.registration-editor-actions{gap:8px}}`;
 return doc.replace('</head>','<style id="ap-registration-link-editor-css">'+css+'</style></head>');
};
