'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(html){
 const pattern=/(<script id="ap-student-accounts"[^>]*>)([\s\S]*?)(<\/script>)/;
 assert.ok(pattern.test(html),'Missing account module');
 html=html.replace(pattern,(_,open,code,close)=>{
  assert.equal(code.split('window.APaccounts=Object.freeze({').length,2,'Account API changed');
  assert.equal(code.split('async function D(){').length,2,'Logout function changed');
  assert.ok(code.includes('async function I()')&&code.includes('async function N('),'Account session functions changed');
  const service=fs.readFileSync(path.resolve(__dirname,'../web/google-login.js'),'utf8');
  code=code.replace('window.APaccounts=Object.freeze({',service+'window.APaccounts=Object.freeze({googleLogin:googleLogin,receiveGoogleCredential:googleReceive,');
  code=code.replace('async function D(){','async function D(){googleCancel();try{window.Android?.clearGoogleCredentialState?.()}catch(_){}');
  return open+code+close;
 });
 const obsolete='<button class="google" onclick="toast(\'Acesso Google será ativado na integração com o Firebase.\')"><span class="g">G</span> Entrar com o Google</button>';
 const button='<button id="apGoogleAccess" class="google" type="button" onclick="APaccounts.googleLogin()"><span class="g" aria-hidden="true">G</span> Entrar com o Google</button><p id="apGoogleStatus" class="google-status" role="status" aria-live="polite" hidden></p>';
 if(html.includes(obsolete))html=html.replace(obsolete,button);
 else{
  const anchor='</section><section class="login" id="login">';
  assert.equal(html.split(anchor).length,2,'Landing page changed');
  html=html.replace(anchor,'<div class="divider">ou</div>'+button+anchor);
 }
 html=html.replace('</head>','<style id="ap-google-login-css">.google:disabled{opacity:.65}.google-status{margin:12px 4px 0;font-size:14px;line-height:1.5;color:#eee}.google-status[hidden]{display:none}</style></head>');
 assert.ok(!html.includes('Acesso Google será ativado na integração com o Firebase.'));
 return html;
};
