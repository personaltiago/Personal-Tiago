'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=f=>fs.readFileSync(path.join(__dirname,'../web',f),'utf8');
module.exports=function(doc){
 const anchor='<section class="workout-plan-selector"><h4>Ficha selecionada</h4>';
 assert.ok(doc.includes(anchor),'Selected workout export position');
 const button='<button type="button" class="btn ap-workout-download" onclick="downloadSelectedWorkout(this)" aria-label="Baixar ficha completa em TXT" title="Baixar ficha completa em TXT"><svg data-ap-menu-icon="download" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/></svg></button>';
 doc=doc.replace(anchor,anchor+button).replace('</head>','<style id="ap-workout-export-css">'+read('workout-export.css')+'</style></head>');
 return doc.replace('</body>','<script id="ap-workout-export-model">'+read('workout-export-model.js')+'</script><script id="ap-workout-export">'+read('workout-export.js')+'</script></body>');
};
