'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 for(const kind of ['lesson','timer']){
  const pattern=new RegExp('(<button class="sound-button"[^>]*onclick="chooseCustomSound\\(\''+kind+'\'\\)"[\\s\\S]*?<\\/button>)');
  assert.equal((doc.match(pattern)||[]).length,2,'Expected sound choice '+kind);
  doc=doc.replace(pattern,'<section class="sound-choice-group"><div class="sound-preview-row">$1<button class="btn sound-preview-button" type="button" data-sound-preview="'+kind+'" aria-pressed="false" onclick="toggleSoundPreview(\''+kind+'\')">▶ Ouvir</button></div><div class="sound-source-actions"><button class="btn" type="button" data-phone-ringtone="'+kind+'" onclick="choosePhoneAlarmRingtone(\''+kind+'\')">Toques do celular</button><button class="btn" type="button" data-audio-file="'+kind+'" onclick="chooseCustomSound(\''+kind+'\')">Escolher áudio</button></div></section>');
 }
 const screen='  currentScreen=screen;';assert.equal(doc.split(screen).length-1,1);doc=doc.replace(screen,screen+"\n  if(screen!=='settings'&&typeof stopSoundPreview==='function')stopSoundPreview();");
 const choose="function chooseCustomSound(kind){";assert.ok(doc.includes(choose));doc=doc.replace(choose,choose+'\n  stopSoundPreview();');
 doc=doc.replace('</head>',`<style id="ap-sound-preview-css">.sound-choice-group{min-width:0}.sound-preview-row{display:flex;align-items:stretch;gap:10px;min-width:0}.sound-preview-row .sound-button{flex:1;min-width:0;overflow-wrap:anywhere}.sound-preview-button{flex:0 0 92px;min-height:48px;align-self:center;white-space:nowrap}.sound-preview-button[aria-pressed="true"]{border-color:var(--purple);color:var(--purple)}.sound-source-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.sound-source-actions .btn{flex:1 1 120px;min-height:44px;font-size:13px;white-space:normal}.sound-preview-help{color:var(--muted);font-size:13px;margin:10px 0 0;line-height:1.5}@media(max-width:350px){.sound-preview-row{flex-wrap:wrap}.sound-preview-row .sound-button{flex-basis:100%}.sound-preview-button{flex:1}}</style></head>`);
 const input='<input id="lessonSoundInput"';assert.ok(doc.includes(input));doc=doc.replace(input,'<p class="sound-preview-help">Ouça o som escolhido por até 15 segundos. Toque novamente para parar.</p>'+input);
 return doc.replace('</body>','<script id="ap-sound-preview-js">'+fs.readFileSync(path.resolve(__dirname,'../web/sound-preview.js'),'utf8')+'</script></body>');
};
