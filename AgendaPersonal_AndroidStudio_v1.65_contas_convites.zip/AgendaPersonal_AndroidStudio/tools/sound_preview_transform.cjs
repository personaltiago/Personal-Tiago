'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const tools='<div class="sound-tools">';assert.ok(doc.includes(tools));
 doc=doc.replace(tools,tools+'<button class="sound-button" type="button" onclick="chooseCustomSound(\'rest\')"><strong>Som do descanso do treino</strong><span id="restSoundLabel">Padrão do celular</span></button>');
 const timerInput='<input id="timerSoundInput"';assert.ok(doc.includes(timerInput));
 doc=doc.replace(timerInput,'<input id="restSoundInput" class="sound-input" type="file" accept="audio/*">\n      '+timerInput);
 doc=doc.replace('Personalize o despertador e os áudios das aulas.','Personalize os sons das aulas e do descanso do treino.');
 for(const kind of ['rest','lesson','timer']){
  const pattern=new RegExp('(<button class="sound-button"[^>]*onclick="chooseCustomSound\\(\''+kind+'\'\\)"[\\s\\S]*?<\\/button>)');
  assert.equal((doc.match(pattern)||[]).length,2,'Expected sound choice '+kind);
  doc=doc.replace(pattern,'<section class="sound-choice-group"><div class="sound-preview-row">$1<button class="btn sound-preview-button" type="button" data-sound-preview="'+kind+'" aria-pressed="false" onclick="toggleSoundPreview(\''+kind+'\')">▶ Ouvir</button></div><div class="sound-source-actions"><button class="btn" type="button" data-phone-ringtone="'+kind+'" onclick="choosePhoneAlarmRingtone(\''+kind+'\')">Toques do celular</button><button class="btn" type="button" data-audio-file="'+kind+'" onclick="chooseCustomSound(\''+kind+'\')">Escolher áudio</button></div>'+(kind==='rest'?'<p class="sound-preview-help">Aviso ao terminar o intervalo entre séries e exercícios.</p>':'')+'</section>');
 }
 const screen='  currentScreen=screen;';assert.equal(doc.split(screen).length-1,1);doc=doc.replace(screen,screen+"\n  if(screen!=='settings'&&typeof stopSoundPreview==='function')stopSoundPreview();");
 const choose="function chooseCustomSound(kind){";assert.ok(doc.includes(choose));doc=doc.replace(choose,choose+'\n  stopSoundPreview();if(!ensureRestSoundSupport(kind))return;');
 const inputLookup="document.getElementById(kind==='timer'?'timerSoundInput':'lessonSoundInput')";assert.equal(doc.split(inputLookup).length-1,2);doc=doc.split(inputLookup).join("document.getElementById(kind+'SoundInput')");
 const bindings="bindSoundInput('lesson');bindSoundInput('timer');renderSoundStatus();";assert.ok(doc.includes(bindings));doc=doc.replace(bindings,"bindSoundInput('rest');"+bindings);
 const label="  if(timer)timer.textContent=status?.timerSoundName||status?.timerName||'Padrão do celular';";assert.ok(doc.includes(label));
 doc=doc.replace(label,label+"\n  const rest=document.getElementById('restSoundLabel');if(rest)rest.textContent=status?.restSoundName||status?.restName||'Padrão do celular';");
 const success="toast(kind==='timer'?'Áudio do fim da aula salvo.':'Áudio do despertador salvo.',4200);";assert.ok(doc.includes(success));doc=doc.replace(success,"toast(kind==='rest'?'Áudio do descanso do treino salvo.':kind==='timer'?'Áudio do fim da aula salvo.':'Áudio do despertador salvo.',4200);");
 doc=doc.replace('</head>',`<style id="ap-sound-preview-css">.sound-choice-group{min-width:0}.sound-preview-row{display:flex;align-items:stretch;gap:10px;min-width:0}.sound-preview-row .sound-button{flex:1;min-width:0;overflow-wrap:anywhere}.sound-preview-button{flex:0 0 92px;min-height:48px;align-self:center;white-space:nowrap}.sound-preview-button[aria-pressed="true"]{border-color:var(--purple);color:var(--purple)}.sound-source-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.sound-source-actions .btn{flex:1 1 120px;min-height:44px;font-size:13px;white-space:normal}.sound-preview-help{color:var(--muted);font-size:13px;margin:10px 0 0;line-height:1.5}@media(max-width:350px){.sound-preview-row{flex-wrap:wrap}.sound-preview-row .sound-button{flex-basis:100%}.sound-preview-button{flex:1}}</style></head>`);
 const input='<input id="lessonSoundInput"';assert.ok(doc.includes(input));doc=doc.replace(input,'<p class="sound-preview-help">Ouça o som escolhido por até 15 segundos. Toque novamente para parar.</p>'+input);
 return doc.replace('</body>','<script id="ap-sound-preview-js">'+fs.readFileSync(path.resolve(__dirname,'../web/sound-preview.js'),'utf8')+'</script></body>');
};
