'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const begin=doc.indexOf('function workoutImportResolveExercise(ex,catalog){'),end=doc.indexOf('function workoutImportField(',begin);
 assert.ok(begin>=0&&end>begin,'Expected PDF instruction resolver');
 doc=doc.slice(0,begin)+fs.readFileSync(path.resolve(__dirname,'../web/pdf-instruction-priority.js'),'utf8')+'\n'+doc.slice(end);
 const guidanceStart=doc.indexOf('function withWorkoutGuidance(ex={}){'),guidanceEnd=doc.indexOf('function workoutGuidanceHint(',guidanceStart);
 assert.ok(guidanceStart>=0&&guidanceEnd>guidanceStart,'Expected existing exercise guidance resolver');
 doc=doc.slice(0,guidanceStart)+fs.readFileSync(path.resolve(__dirname,'../web/workout-guidance-resolver.js'),'utf8')+'\n'+doc.slice(guidanceEnd);
 const packet='const ex=g&&helpers.shared?helpers.shared(d,g,raw):raw;';
 assert.equal(doc.split(packet).length-1,1,'Teacher packet instruction resolver');
 doc=doc.replace(packet,'const ex=withWorkoutGuidance(g&&helpers.shared?helpers.shared(d,g,raw):raw);');
 const saved="instructionResolution:ex.instructionResolution||'source',guidanceResolvedFromCatalog:!!ex.guidanceResolvedFromCatalog";
 assert.equal(doc.split(saved).length-1,1);
 doc=doc.replace(saved,"instructionResolution:ex.instructionResolution||'source',guidanceVersion:1,guidanceResolvedFromCatalog:!!ex.guidanceResolvedFromCatalog,notesOrigin:ex.notesOrigin||'missing',observationsOrigin:ex.observationsOrigin||'missing'");
 return doc;
};
