'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const begin=doc.indexOf('function workoutImportResolveExercise(ex,catalog){'),end=doc.indexOf('function workoutImportField(',begin);
 assert.ok(begin>=0&&end>begin,'Expected PDF instruction resolver');
 doc=doc.slice(0,begin)+fs.readFileSync(path.resolve(__dirname,'../web/pdf-instruction-priority.js'),'utf8')+'\n'+doc.slice(end);
 const guard='function withWorkoutGuidance(ex={}){\n  if(ex.guidanceVersion!=null)return ex;';
 assert.equal(doc.split(guard).length-1,1);
 doc=doc.replace(guard,'function withWorkoutGuidance(ex={}){\n  if(ex.sourceDocumentId||ex.guidanceVersion!=null)return ex;');
 const saved="instructionResolution:ex.instructionResolution||'source',guidanceResolvedFromCatalog:!!ex.guidanceResolvedFromCatalog";
 assert.equal(doc.split(saved).length-1,1);
 doc=doc.replace(saved,"instructionResolution:ex.instructionResolution||'source',guidanceVersion:1,guidanceResolvedFromCatalog:!!ex.guidanceResolvedFromCatalog,notesOrigin:ex.notesOrigin||'missing',observationsOrigin:ex.observationsOrigin||'missing'");
 return doc;
};
