'use strict';
// Existing unit tests exercise the teacher engine; it now lives in professor.html.
const fs=require('node:fs'),path=require('node:path');
const directory=path.resolve(__dirname,'../tests');
for(const name of fs.readdirSync(directory)){
 if(!name.endsWith('.cjs'))continue;
 const file=path.join(directory,name),source=fs.readFileSync(file,'utf8');
 let next=source.replaceAll('assets/index.html','assets/professor.html');
 if(name==='verify_student_identity.cjs')next=next.replace("path.join(assets, 'index.html')","path.join(assets, 'professor.html')");
 if(next!==source)fs.writeFileSync(file,next);
}
