'use strict';
// Migrate only the historical teacher tests. Account/student tests must retain
// index.html, which is the application shell rather than the teacher engine.
const fs=require('node:fs'),path=require('node:path');
const names=['verify_alarm_access.cjs','verify_dialog_navigation.cjs','verify_lesson_edit.cjs','verify_agenda.cjs','verify_availability.cjs','verify_bisets.cjs','verify_catalog_import.cjs','verify_reordering.cjs','verify_series.cjs','verify_technique_flow.cjs','verify_techniques.cjs','verify_workout_features.cjs','verify_workout_pdf_review.cjs','verify_workouts.cjs','verify_youtube.cjs'];
for(const name of names){
 const file=path.resolve(__dirname,'../tests',name);if(!fs.existsSync(file))continue;
 const source=fs.readFileSync(file,'utf8'),next=source.replaceAll('/index.html','/professor.html');
 if(next!==source)fs.writeFileSync(file,next);
}
