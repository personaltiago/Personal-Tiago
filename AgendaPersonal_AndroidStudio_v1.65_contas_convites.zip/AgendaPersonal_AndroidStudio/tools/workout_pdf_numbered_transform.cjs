'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const replace=(a,b)=>{assert.equal(doc.split(a).length-1,1,a.slice(0,90));doc=doc.replace(a,b)};
 replace('async function workoutImportReadPdf(file){',fs.readFileSync(path.resolve(__dirname,'../web/workout-pdf-numbered.js'),'utf8')+'\nasync function workoutImportReadPdf(file){');
 replace('const profile=workoutImportParseProfile(pages),days=workoutImportParseDays(pages);','const numbered=workoutImportNumberedPdf(pages),profile=numbered?.profile||workoutImportParseProfile(pages),days=numbered?.days||workoutImportParseDays(pages);');
 replace("/^S[eé]ries\\s*:/i.test(workoutImportText(line))).length,recognized=days.reduce", "/^S[eé]ries(?:\\s+e\\s+repeti[cç][oõ]es)?\\s*:/i.test(workoutImportText(line))).length,recognized=days.reduce");
 replace('return{file,fileBytes:original,profile,days,pages};',"return{file,fileBytes:original,profile,days,pages,organization:numbered?.organization||'sequence',notes:numbered?.notes||'',format:numbered?.format||'mfit'};");
 replace("weekday:(index+1)%7,notes:'',sourceDocumentId:documentRecord.id", "weekday:Number.isInteger(day.weekday)?day.weekday:(index+1)%7,notes:day.notes||'',sourceDocumentId:documentRecord.id");
 replace("currentLevel:p.currentLevel||'',organization:'sequence',notes:'',archived:false", "currentLevel:p.currentLevel||'',organization:data.organization||'sequence',notes:data.notes||'',archived:false");
 return doc;
};
