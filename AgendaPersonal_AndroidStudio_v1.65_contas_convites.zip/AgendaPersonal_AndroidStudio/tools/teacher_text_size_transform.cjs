'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
const read=n=>fs.readFileSync(path.resolve(__dirname,'../web/'+n),'utf8');
// Scale explicit sizes once. Relative em/% and inheritance follow their parent;
// the root stays at its original size, so rem values never multiply twice.
function scaleCSS(css){return css.replace(/([^{}]+)\{([^{}]*)\}/g,(block,selector,body)=>{
 if(selector.trim().split(',').some(s=>/^(?:html|:root)$/.test(s.trim())))return block;
 return selector+'{'+body.replace(/(font-size\s*:\s*)([^;}]+)/g,(decl,start,value)=>{
  const important=value.match(/\s*!important\s*$/)?.[0]||'',size=value.replace(/\s*!important\s*$/,'').trim();
  if(size.includes('--ap-ts')||!/(?:px|rem|vw|vh)\b/.test(size))return decl;
  return start+'calc(('+size+') * var(--ap-ts,1))'+important;
 }).replace(/(\bfont\s*:\s*)([^;}]+)/g,(decl,start,value)=>start+value.replace(/(\d*\.?\d+)(px|rem)\b/,(size)=>'calc('+size+' * var(--ap-ts,1))'))+'}';
 })}
exports.scaleCSS=scaleCSS;
exports.page=function(doc){
 const script=minify_sync(read('teacher-text-size.js'),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
 doc=doc.replace('<head>','<head><script id="ap-teacher-text-size">'+script+'</script>');
 if(doc.includes('id="screen-settings"')){
  const heading='<div class="module-heading"><div><h2>Configurações</h2><p>Personalize os sons das aulas e do descanso do treino.</p></div></div>';assert.ok(doc.includes(heading));
  const options='<section class="teacher-text-setting" aria-labelledby="teacherTextTitle"><h3 id="teacherTextTitle">Tamanho das letras</h3><p>Ajuste a leitura das telas do professor. A escolha fica salva neste aparelho.</p><div class="teacher-text-options" role="group" aria-label="Tamanho das letras do professor">'+[['normal','Normal'],['large','Grande'],['xlarge','Extra grande']].map(([id,label])=>'<button type="button" data-teacher-text="'+id+'" aria-pressed="false">'+label+'</button>').join('')+'</div><p id="teacherTextStatus" role="status" aria-live="polite"></p></section>';
  doc=doc.replace(heading,heading.replace('Personalize os sons das aulas e do descanso do treino.','Ajuste a leitura, os sons das aulas e o descanso do treino.')+options);
  const threshold='parseFloat(getComputedStyle(document.documentElement).fontSize)>=20';assert.ok(doc.includes(threshold));doc=doc.replace(threshold,'parseFloat(getComputedStyle(document.documentElement).fontSize)*(window.APTeacherText?.scale()||1)>=20');
 }
 doc=doc.replace('</head>','<style id="ap-teacher-text-size-css">'+read('teacher-text-size.css')+'</style></head>');
 return doc.replace(/(<style[^>]*>)([\s\S]*?)(<\/style>)/g,(_,a,css,b)=>a+scaleCSS(css)+b);
};
exports.entry=function(html){return html.replace(/(<style[^>]*>)([\s\S]*?)(<\/style>)/g,(tag,a,css,b)=>css.includes('#apTeacherSetup')?a+scaleCSS(css)+b:tag)};
