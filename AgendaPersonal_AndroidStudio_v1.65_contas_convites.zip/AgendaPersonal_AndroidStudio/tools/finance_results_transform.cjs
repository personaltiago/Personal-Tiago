'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=n=>fs.readFileSync(path.resolve(__dirname,'../web/'+n),'utf8');
module.exports=function(doc){
 const marker='<section id="financeWallet"';assert.ok(doc.includes(marker),'Missing finance wallet');doc=doc.replace(marker,read('finance-results.html')+marker);
 const blank='history:[],payments:[],lessonTimers:';assert.ok(doc.includes(blank),'Missing blank state');doc=doc.replace(blank,'history:[],payments:[],financeExpenses:[],lessonTimers:');
 const normalize='d.payments=Array.isArray(d.payments)?d.payments:[];';assert.ok(doc.includes(normalize),'Missing payment normalization');doc=doc.replace(normalize,normalize+'d.financeExpenses=Array.isArray(d.financeExpenses)?d.financeExpenses:[];');
 return doc.replace('</head>','<style id="ap-finance-results-css">'+read('finance-results.css')+'</style></head>').replace('</body>','<script id="ap-finance-results-model">'+read('finance-results-model.js')+'</script><script id="ap-finance-results">'+read('finance-results.js')+'</script></body>');
};
