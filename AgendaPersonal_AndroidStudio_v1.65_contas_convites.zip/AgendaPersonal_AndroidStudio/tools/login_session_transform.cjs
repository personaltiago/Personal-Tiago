'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
module.exports=function(html){
 const login='try{await ensure();const result=await sdk.signInWithEmailAndPassword(sdk.auth,email,password);';
 assert.equal(html.split(login).length,2,'Single production login');
 html=html.replace(login,"try{await ensure();await window.APLoginSession.configure(sdk,document.getElementById('remember').checked===true);const result=await sdk.signInWithEmailAndPassword(sdk.auth,email,password);");
 const callback='if(user.uid!==identity?.uid)activate(user).catch(e=>{clear();notice(errorText(e));window.APstartup.finish()})';
 assert.equal(html.split(callback).length,2,'Session restore callback');html=html.replace(callback,'if(user.uid!==identity?.uid)restoreSession(user)');
 html=html.replace('if(identity)clear();window.APstartup.finish();return}if(user.uid', 'if(identity||restoringUid)clear();window.APstartup.finish();return}if(user.uid');
 const anchor=' async function activate(user,requested=\'\'){';assert.equal(html.split(anchor).length,2,'Account activation');
 html=html.replace(anchor,` let restoringUid='';
 async function restoreSession(user=sdk?.auth.currentUser){
  if(!user||loginBusy||resetBusy||identity?.uid===user.uid||restoringUid===user.uid)return;
  restoringUid=user.uid;const expected=epoch+1;
  try{await activate(user)}catch(error){if(epoch===expected&&sdk?.auth.currentUser?.uid===user.uid){clear();notice(errorText(error));window.APstartup.finish()}}
  finally{if(restoringUid===user.uid)restoringUid=''}
 }
 window.addEventListener('online',()=>restoreSession());
 window.addEventListener('pageshow',()=>restoreSession());
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)restoreSession()});
`+anchor);
 const source=fs.readFileSync(path.join(__dirname,'../web/login-session.js'),'utf8'),code=minify_sync(source,{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
 assert.ok(code);return html.replace('<script id="ap-student-accounts">','<script id="ap-login-session">'+code+'</script><script id="ap-student-accounts">');
};
