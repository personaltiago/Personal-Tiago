'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
module.exports=function(doc){
 let count=0;
 doc=doc.replace(/(<button\b[^>]*class=")([^"]*)("[^>]*>)/g,(tag,before,classes,after)=>{
  if(!classes.split(/\s+/).includes('more-function'))return tag;
  count++;return before+classes.split(/\s+/).filter(c=>c!=='more-function-primary').join(' ')+after;
 });
 assert.ok(count>=20,'Expected the full More menu.');
 const group='<div id="proMoreMenu"';assert.ok(doc.includes(group));
 doc=doc.replace(group,'<p id="apMoreSelectHint" class="ap-more-selection-help">Toque uma vez para destacar e outra vez para abrir.</p>'+group);
 const read=file=>fs.readFileSync(path.resolve(__dirname,'../web/'+file),'utf8');
 const script=minify_sync(read('more-menu-selection.js'),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
 const end=/<\/body>(\s*<\/html>\s*)$/i;assert.ok(end.test(doc));
 return doc.replace('</head>','<style id="ap-more-menu-selection-css">'+read('more-menu-selection.css')+'</style></head>').replace(end,(_,tail)=>'<script id="ap-more-menu-selection">'+script+'</script></body>'+tail);
};
