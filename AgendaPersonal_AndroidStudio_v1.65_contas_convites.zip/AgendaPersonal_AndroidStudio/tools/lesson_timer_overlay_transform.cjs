'use strict';
const assert=require('node:assert/strict');
module.exports=function(doc){
 const anchor='<button class="btn ghost lesson-timer-stop"';
 assert.equal(doc.split(anchor).length,2,'one lesson countdown template');
 const button='<button class="btn timer lesson-timer-float" type="button" onclick="showFloatingLessonTimer()"${typeof window.Android?.showLessonTimerOverlay!==\'function\'||timer.native!==true||Number(timer.endAt)<=Date.now()?\' hidden\':\'\'}>${uiIcon(\'clock\')}Mostrar no alto da tela</button>';
 doc=doc.replace(anchor,button+anchor);
 const fn='function cancelNativeLessonTimer(timer){';
 assert.equal(doc.split(fn).length,2);
 doc=doc.replace(fn,`function showFloatingLessonTimer(){
  if(typeof window.Android?.showLessonTimerOverlay==='function')Android.showLessonTimerOverlay();
  else toast('A faixa sobre outros aplicativos está disponível no Android 1.144 ou posterior.');
}\n`+fn);
 const retry="if(retry)retry.hidden=!window.Android||timer.native===true||Number(timer.endAt)<=Date.now();";
 assert.equal(doc.split(retry).length,2);
 doc=doc.replace(retry,retry+"\n    const floating=el.querySelector('.lesson-timer-float');if(floating)floating.hidden=typeof window.Android?.showLessonTimerOverlay!=='function'||timer.native!==true||Number(timer.endAt)<=Date.now();");
 return doc;
};
