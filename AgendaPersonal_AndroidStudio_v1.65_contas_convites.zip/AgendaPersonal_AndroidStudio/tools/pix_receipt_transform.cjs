'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=name=>fs.readFileSync(path.resolve(__dirname,'../web/'+name),'utf8');
function replace(doc,from,to){assert.ok(doc.includes(from),'Receipt anchor missing: '+from.slice(0,80));return doc.replace(from,to)}
module.exports=function(doc){
 doc=replace(doc,'function commitFinanceChange(student,changes,historyText,payment=null){','function commitFinanceChange(student,changes,historyText,payment=null,receiptLedger=null){');
 doc=replace(doc,'payments:payment?[payment,...state.payments]:state.payments};','payments:payment?[payment,...state.payments]:state.payments,...(receiptLedger?{financeReceiptLedger:receiptLedger}:{})};');
 doc=replace(doc,'Object.assign(student,changes);state.history=candidate.history;state.payments=candidate.payments;','Object.assign(student,changes);state.history=candidate.history;state.payments=candidate.payments;if(receiptLedger)state.financeReceiptLedger=receiptLedger;');
 const paid='<button class="btn good" type="button" onclick="markPaymentPaid(this.closest(\'[data-student-id]\').dataset.studentId)">';
 doc=replace(doc,paid,'<button class="btn finance-receipt-action" type="button" onclick="openFinanceReceipt(this.closest(\'[data-student-id]\').dataset.studentId)">${uiIcon(\'addLesson\')}Anexar comprovante</button>'+paid);
 doc=replace(doc,'state.payments=state.payments.filter(p=>p.studentId!==sid);','state.payments=state.payments.filter(p=>p.studentId!==sid||p.receipt);');
 doc=replace(doc,'Excluir ${s.name}, as aulas e os treinos vinculados a esse aluno?','Excluir ${s.name}, as aulas e os treinos vinculados a esse aluno?\\n\\nPagamentos com comprovante serão mantidos no Financeiro.');
 doc=doc.replace('</head>','<style id="ap-pix-receipt-css">'+read('pix-receipt.css')+'</style></head>');
 return doc.replace('</body>',read('pix-receipt-dialogs.html')+'<script id="ap-pix-receipt-model">'+read('pix-receipt-model.js')+'</script><script id="ap-pix-receipt">'+read('pix-receipt.js')+'</script></body>');
};
