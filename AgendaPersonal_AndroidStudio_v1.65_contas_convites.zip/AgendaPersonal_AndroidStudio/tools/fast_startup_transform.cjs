'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),zlib=require('node:zlib'),crypto=require('node:crypto'),{minify_sync}=require('terser');
const root=path.resolve(__dirname,'..'),read=f=>fs.readFileSync(path.join(root,f),'utf8'),script=f=>minify_sync(read('web/'+f),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
exports.entry=function(html,assets){
 const sdk=fs.readFileSync(path.join(root,'web/vendor/firebase-local.iife.js')),metadata=JSON.parse(read('web/vendor/firebase-local.json'));
 assert.equal(metadata.firebase,'10.12.5');assert.equal(crypto.createHash('sha256').update(sdk).digest('hex'),metadata.sha256);
 const imports="const [a,b,c]=await Promise.all([import(SDK_BASE+'firebase-app.js'),import(SDK_BASE+'firebase-auth.js'),import(SDK_BASE+'firebase-firestore.js')]);";
 assert.ok(html.includes(imports));html=html.replace(imports,'const [a,b,c]=await window.APloadFirebase();');
 html=html.replace('<head>','<head><script id="ap-firebase-packed" type="application/octet-stream">'+zlib.gzipSync(sdk,{level:9}).toString('base64')+'</script><script id="ap-firebase-loader">'+script('firebase-loader.js')+'</script>');
 // Preserve the exact artwork bytes. A gender-choice illustration is needed
 // only on its own screen, not while restoring the professor's session.
 const image=/<img class="gender-art"([^>]*?)src="(data:image\/[^"<>]+)"([^>]*)>/;
 const match=html.match(image);assert.ok(match,'Gender-choice artwork');
 html=html.replace(image,'<img class="gender-art"$1data-ap-lazy-image="gender" width="865" height="1536"$3>');
 const registration=path.join(assets,'cadastro.html');let doc=fs.readFileSync(registration,'utf8');assert.ok(!doc.includes('id="ap-entry-artwork"'));
 doc=doc.replace('</body>','<script id="ap-entry-artwork" type="application/json">'+JSON.stringify({gender:match[2]}).replace(/</g,'\\u003c')+'</script></body>');fs.writeFileSync(registration,doc);
 return html.replace('</head>','<style>.gender-art:not([src]){visibility:hidden}</style></head>').replace('</body></html>','<script id="ap-entry-artwork-loader">'+script('entry-artwork-loader.js')+'</script></body></html>');
};
exports.teacher=function(doc){
 const code="window.addEventListener('error',function(e){if(e.error)window.__agendaBootFailed=true});document.addEventListener('DOMContentLoaded',function(){requestAnimationFrame(function(){if(!window.__agendaBootFailed&&typeof openRegistrationLink==='function')window.parent.postMessage({kind:'AP_TEACHER_DOM_READY'},'*')})},{once:true});";
 // Register the error guard in the head so a later script cannot acknowledge
 // a partially initialized screen. Signal readiness after initialization.
 return doc.replace('<head>','<head><script id="ap-teacher-boot-guard">'+code+'</script>');
};
