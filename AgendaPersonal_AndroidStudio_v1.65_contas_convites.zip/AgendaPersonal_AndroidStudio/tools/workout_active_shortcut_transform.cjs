'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const anchor='onclick="showWorkoutPlanCollection(\'active\')"';
 assert.equal(doc.split(anchor).length,2,'Active workout collection button');
 doc=doc.replace(anchor,'onclick="openActiveWorkoutShortcut()" title="Ir ao treino em andamento ou aos treinos da ficha"');
 const code=fs.readFileSync(path.join(__dirname,'../web/workout-active-shortcut.js'),'utf8');
 return doc.replace('</body>','<script id="ap-workout-active-shortcut">'+code+'</script></body>');
};
