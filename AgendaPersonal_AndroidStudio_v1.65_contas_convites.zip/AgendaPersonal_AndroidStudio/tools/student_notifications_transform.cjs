'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const bell=/<button class="home-bell"[\s\S]*?<\/button>/;assert.ok(bell.test(doc));
 doc=doc.replace(bell,old=>old.replace('class="home-bell"','id="apStudentNotificationBell" class="home-bell"').replace("onclick=\"route('agenda')\"",'onclick="APnotifications.open()"').replace('<i></i>','<span id="apStudentNotificationCount" aria-hidden="true" hidden></span>'));
 const oldClear="identity=null;window.dispatchEvent(new Event('ap-account-changed'));preview=null;window.__AP_STUDENT_CONTEXT=null;";assert.ok(doc.includes(oldClear));
 doc=doc.replace(oldClear,"identity=null;preview=null;window.__AP_STUDENT_CONTEXT=null;window.dispatchEvent(new Event('ap-account-changed'));");
 const received='window.__AP_STUDENT_CONTEXT.area=area;if(area)localStorage.setItem';assert.ok(doc.includes(received));
 doc=doc.replace(received,'window.APnotifications?.receiveWorkout(area,doc.metadata?.fromCache===true);'+received);
 const back="const publisher=document.getElementById('apUpdatePublisher');";assert.ok(doc.includes(back));
 doc=doc.replace(back,"if(window.APnotifications?.close())return true;\n "+back);
 const css=fs.readFileSync(path.resolve(__dirname,'../web/student-notifications.css'),'utf8'),js=fs.readFileSync(path.resolve(__dirname,'../web/student-notifications.js'),'utf8');
 doc=doc.replace('</head>','<style id="ap-student-notifications-css">'+css+'</style></head>');
 const modal='<section id="apStudentNotifications" class="ap-notif-overlay" hidden><div class="ap-notif-sheet" role="dialog" aria-modal="true" aria-labelledby="apStudentNotificationsTitle"><header class="ap-notif-header"><div><h2 id="apStudentNotificationsTitle">Notificações</h2><p id="apStudentNotificationsSummary"></p></div><button id="apStudentNotificationsClose" class="ap-notif-close" type="button" aria-label="Fechar notificações">×</button></header><div class="ap-notif-toolbar"><button id="apStudentNotificationsRead" type="button">Marcar todas como lidas</button></div><div id="apStudentNotificationList" class="ap-notif-list"></div></div></section>';
 return doc.replace('</body></html>',modal+'<script id="ap-student-notifications">'+js+'</script></body></html>');
};
