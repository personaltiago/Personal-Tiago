'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
function assets(preview=false){
 const root=path.resolve(__dirname,'../web/mascot-homes'),manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8')),images={};
 const ids=['yard','bamboo','forest','lake','cabin','night'].map(n=>'home-'+n);
 assert.deepEqual(Object.keys(manifest),ids,'All six offline scenes are required');
 for(const id of ids){const item=manifest[id];assert.equal(item.mime,'image/webp');assert.equal(path.basename(item.file),item.file);const bytes=fs.readFileSync(path.join(root,preview?item.previewFile:item.file));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),preview?item.previewSha256:item.sha256,'Scene integrity: '+id);images[id]='data:image/webp;base64,'+bytes.toString('base64')}
 return images;
}
module.exports=function(source){
 const images=assets(true);
 const marker='/*AP_MASCOT_HOME_ASSETS*/{}';assert.equal(source.split(marker).length-1,1,'Single scenery embedding point');return source.replace(marker,JSON.stringify(images));
};
module.exports.assets=assets;
