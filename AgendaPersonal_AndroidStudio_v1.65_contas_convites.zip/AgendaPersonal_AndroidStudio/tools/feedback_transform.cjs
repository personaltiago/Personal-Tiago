'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
const read=n=>fs.readFileSync(path.resolve(__dirname,'../web',n),'utf8');
const script=n=>minify_sync(read(n),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code;
const common=()=>'<style id="ap-feedback-css">'+read('feedback.css')+'</style>';
exports.teacher=function(doc){assert.ok(doc.includes('class="student-category-tabs segmented"'),'Feedback student tabs');return doc.replace('</head>',common()+'</head>').replace('</body>','<script id="ap-feedback-model">'+script('feedback-model.js')+'</script><script id="ap-feedback-card">'+script('feedback-card.js')+'</script><script id="ap-feedback-teacher">'+script('feedback-teacher.js')+'</script></body>')};
exports.entry=function(doc){return doc.replace('</head>',common()+'</head>').replace('</body></html>','<script id="ap-feedback-model">'+script('feedback-model.js')+'</script><script id="ap-feedback-sync">'+script('feedback-sync.js')+'</script><script id="ap-feedback-student">'+script('feedback-student.js')+'</script></body></html>')};
