'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function enhanceTrainerProfile(doc){
 function replace(a,b){assert.ok(doc.includes(a),'Missing trainer profile anchor: '+a.slice(0,90));doc=doc.replace(a,b)}
 replace('<div class="field full"><button class="btn primary full" type="submit">SALVAR PERFIL</button>', '<label class="field full"><span>CREF <small>(opcional)</small></span><input id="trainerCref" maxlength="40" autocomplete="off" autocapitalize="characters" placeholder="Número e região do seu CREF"></label><div class="field full"><button class="btn primary full" type="submit">SALVAR PERFIL</button>');
 replace("onclick=\"trainerPhotoDraft='';updateTrainerPhotoPreview()\"",'onclick="resetTrainerPhoto()"');
 replace('>Usar foto do painel</button></div><input id="trainerPhotoInput"','>Usar foto do painel</button><button id="trainerPhotoAdjust" class="btn ghost" type="button" onclick="adjustTrainerPhoto()" hidden>Ajustar recorte</button></div><input id="trainerPhotoInput"');
 replace('<small id="moreTrainerSubtitle">PERSONAL TRAINER</small>','<small id="moreTrainerSubtitle">PERSONAL TRAINER</small><small id="moreTrainerCref" class="trainer-cref" hidden></small>');
 replace("photoDataUrl:typeof profile?.photoDataUrl", "cref:typeof profile?.cref==='string'?profile.cref:'',photoDataUrl:typeof profile?.photoDataUrl");
 replace("document.getElementById('moreTrainerSubtitle').textContent=profile.subtitle.toLocaleUpperCase('pt-BR');", "document.getElementById('moreTrainerSubtitle').textContent=profile.subtitle.toLocaleUpperCase('pt-BR');\n  const cref=document.getElementById('moreTrainerCref');cref.textContent=profile.cref?'CREF '+profile.cref:'';cref.hidden=!profile.cref;");
 const block=/let trainerPhotoDraft='';[\s\S]*?(?=document.addEventListener\('click',event=>\{\n  const button=event.target.closest\('\[data-home-screen\])/;
 assert.ok(block.test(doc),'Missing profile editor functions');
 doc=doc.replace(block,()=>fs.readFileSync(path.resolve(__dirname,'../web/trainer-profile.js'),'utf8')+'\n');
 const dialog='<div id="trainerPhotoCropDialog" class="dialog" role="dialog" aria-modal="true" aria-labelledby="trainerPhotoCropTitle"><div class="sheet trainer-crop-sheet"><div class="sheet-head"><h3 id="trainerPhotoCropTitle">Enquadrar foto</h3><button class="close" type="button" data-close="trainerPhotoCropDialog" aria-label="Cancelar recorte">×</button></div><p id="trainerCropHelp" class="trainer-crop-help">Arraste o círculo até a área da foto que deseja usar. Ajuste o zoom para aproximar.</p><canvas id="trainerCropCanvas" width="640" height="560" aria-label="Área de recorte circular da foto" aria-describedby="trainerCropHelp" tabindex="0"></canvas><label class="trainer-crop-zoom" for="trainerCropZoom"><span>Zoom</span><input id="trainerCropZoom" type="range" min="1" max="5" step="0.05" value="1"><output id="trainerCropZoomValue" for="trainerCropZoom">1×</output></label><p class="trainer-crop-keys">Use as setas do teclado para mover o círculo.</p><div class="trainer-crop-actions"><button class="btn ghost" type="button" data-close="trainerPhotoCropDialog">Cancelar</button><button id="trainerCropApply" class="btn primary" type="button">Usar este recorte</button></div></div></div>';
 replace('<div id="trainerProfileDialog"',dialog+'<div id="trainerProfileDialog"');
 const css=fs.readFileSync(path.resolve(__dirname,'../web/trainer-profile.css'),'utf8');
 replace('</head>','<style id="trainer-profile-crop-css">'+css+'</style></head>');
 return doc;
};
