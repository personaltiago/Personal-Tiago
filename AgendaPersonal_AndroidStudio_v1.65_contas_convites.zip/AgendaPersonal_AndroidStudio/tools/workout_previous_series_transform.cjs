'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=n=>fs.readFileSync(path.join(__dirname,'../web',n),'utf8');
function replace(s,a,b){assert.ok(s.includes(a),'Previous series anchor: '+a.slice(0,100));return s.replace(a,b)}
function script(doc,marker,patch){const start=doc.indexOf('<script '+marker),a=doc.indexOf('>',start)+1,b=doc.indexOf('</script>',a);assert.ok(start>=0&&b>a,marker);return doc.slice(0,a)+patch(doc.slice(a,b))+doc.slice(b)}
module.exports=function(doc){
  assert.ok(!doc.includes('id="ap-workout-previous-series"'),'Previous series already applied');
  doc=script(doc,'data-agenda-workout-series',s=>{
    s=replace(s,"const interactive=options.interactive===true,count=rows.filter(r=>r.done).length,title=options.title||ex.name;", "const interactive=options.interactive===true,count=rows.filter(r=>r.done).length,title=options.title||ex.name;\n    const previous=window.APWorkoutPreviousSeries?.read(state,options.plan||currentWorkoutPlan(),options.day||currentWorkoutDay(),ex);");
    s=replace(s,'<span role="columnheader">Carga (kg)</span>','<span role="columnheader" class="ws-previous-heading" aria-label="Repetições realizadas no último treino">Último<small>treino</small></span><span role="columnheader">Carga (kg)</span>');
    s=replace(s,'const attrs=rowAttributes(ex,row,options);',`const attrs=rowAttributes(ex,row,options);
        const lastReps=previous?.values[row.round],lastLabel=lastReps===undefined?'Sem repetições registradas para esta série no último treino':lastReps+' repetições no último treino'+(previous.date?' · '+workoutDateLabel(previous.date):'');`);
    s=replace(s,'<div role="cell"><input ${currentIds?\'id="workoutBisetLoad"','<span role="cell" class="ws-set-previous${lastReps===undefined?\'\':\' has-result\'}" data-series-previous="${row.round}" data-previous-date="${hesc(previous?.date||\'\')}" aria-label="${hesc(lastLabel)}" title="${hesc(lastLabel)}">${lastReps===undefined?\'—\':lastReps}</span>\n          <div role="cell"><input ${currentIds?\'id="workoutBisetLoad"');
    s=replace(s,"{interactive:active,title:'Séries de '+ex.name}","{interactive:active,title:'Séries de '+ex.name,plan,day}");
    s=replace(s,"{title:'Séries prescritas'}","{title:'Séries prescritas',plan,day:plan.days.find(d=>d.exercises.includes(ex))}");
    return s;
  });
  doc=script(doc,'data-agenda-bisets',s=>{
    s=replace(s,'function stackedTables(pair,g,status,interactive=false){','function stackedTables(pair,g,status,interactive=false,plan=currentWorkoutPlan(),day=currentWorkoutDay()){');
    s=replace(s,'step:status.step,interactive}','step:status.step,interactive,plan,day}');
    s=replace(s,'${stackedTables(pair,g,status)}','${stackedTables(pair,g,status,false,p,day)}');
    s=replace(s,'${stackedTables(pair,g,status,true)}','${stackedTables(pair,g,status,true,p,day)}');
    return s;
  });
  doc=replace(doc,'<script data-agenda-workout-series','<script id="ap-workout-previous-series">'+read('workout-previous-series.js')+'</script><script data-agenda-workout-series');
  return doc.replace('</head>','<style id="ap-workout-previous-series-css">'+read('workout-previous-series.css')+'</style></head>');
};
