"""Portable build entrypoint. Resolve tools, build this project and inspect its APK."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from zipfile import BadZipFile
from verify_apk import locate_aapt, verify

ROOT = Path(__file__).resolve().parents[1]


def run(args, **kwargs):
    return subprocess.run([str(v) for v in args], cwd=ROOT, check=True, **kwargs)


def java_home(env):
    candidates = [env.get('JAVA_HOME')]
    found = shutil.which('java', path=env.get('PATH'))
    if found:
        candidates.append(str(Path(found).resolve().parent.parent))
    candidates.extend(str(p) for p in Path('/usr/lib/jvm').glob('*'))
    for value in dict.fromkeys(v for v in candidates if v):
        executable = Path(value)/'bin/java'
        if not executable.is_file():
            continue
        result = subprocess.run([str(executable), '-version'], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        version = re.search(r'(?:openjdk|java) version "(\d+)', result.stdout)
        if result.returncode == 0 and version and int(version.group(1)) >= 17:
            return str(Path(value).resolve())
    raise RuntimeError('Java 17 ou mais recente não foi encontrado. Configure JAVA_HOME no Codespaces.')


def sdk_home(env):
    candidates = [env.get('ANDROID_HOME'), env.get('ANDROID_SDK_ROOT')]
    local = ROOT/'local.properties'
    if local.is_file():
        match = re.search(r'^sdk.dir=(.+)$', local.read_text(), re.M)
        if match:
            candidates.append(match.group(1).replace('\\:', ':').replace('\\ ', ' '))
    candidates += [str(Path.home()/'android-sdk'), str(Path.home()/'Android/Sdk'), '/home/codespace/android-sdk', '/usr/local/lib/android/sdk', '/opt/android-sdk']
    for value in dict.fromkeys(v for v in candidates if v):
        path = Path(value)
        if (path/'platforms/android-35/android.jar').is_file() and locate_aapt(path):
            return str(path.resolve())
    raise RuntimeError('Android SDK 35 com Build-Tools não encontrado. Configure ANDROID_HOME para o SDK já instalado.')


def repo_root(env):
    for parent in [ROOT, *ROOT.parents]:
        if (parent/'.git').exists():
            return parent
    for name in ['CODESPACE_VSCODE_FOLDER', 'GITHUB_WORKSPACE']:
        value = env.get(name)
        if value and Path(value).is_dir() and ROOT.is_relative_to(Path(value).resolve()):
            return Path(value).resolve()
    return ROOT


def gradle_command(env, repo):
    # Prefer a working wrapper, then installed distributions, then PATH.
    if (ROOT/'gradlew').is_file() and (ROOT/'gradle/wrapper/gradle-wrapper.jar').is_file():
        return ['bash', str(ROOT/'gradlew')]
    candidates = []
    if env.get('AGENDA_GRADLE_EXEC'):
        candidates.append(Path(env['AGENDA_GRADLE_EXEC']))
    candidates += [ROOT/'gradle-8.9/bin/gradle', repo/'app/AgendaPersonal_AndroidStudio/gradle-8.9/bin/gradle', repo/'AgendaPersonal_AndroidStudio/gradle-8.9/bin/gradle']
    found = shutil.which('gradle', path=env.get('PATH'))
    if found:
        candidates.append(Path(found))
    for candidate in candidates:
        if candidate.is_file():
            return ['bash', str(candidate)] if not os.access(candidate, os.X_OK) else [str(candidate)]
    raise RuntimeError('Gradle não encontrado. Configure AGENDA_GRADLE_EXEC com o executável já usado neste Codespaces.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-only', action='store_true', help='Conferir fontes e ferramentas sem compilar')
    args = parser.parse_args()
    env = dict(os.environ)
    if not shutil.which('node', path=env.get('PATH')):
        raise RuntimeError('Node.js não encontrado neste Codespaces.')
    release = json.loads((ROOT/'release.json').read_text())
    run(['node', 'tools/check_release.cjs'], env=env)
    raw_code = env.get('ANDROID_VERSION_CODE', str(release['versionCode']))
    if not raw_code.isdigit() or int(raw_code) < release['versionCode'] or int(raw_code) > 2100000000:
        raise RuntimeError('ANDROID_VERSION_CODE precisa ser um inteiro a partir de '+str(release['versionCode'])+'.')
    expected_code = int(raw_code)
    env['JAVA_HOME'] = java_home(env)
    env['PATH'] = str(Path(env['JAVA_HOME'])/'bin')+os.pathsep+env.get('PATH', '')
    env['ANDROID_HOME'] = env['ANDROID_SDK_ROOT'] = sdk_home(env)
    repo = repo_root(env)
    gradle = gradle_command(env, repo)
    print('Projeto: '+str(ROOT), flush=True)
    print('Compilar: Android '+release['androidVersion']+' / código '+str(expected_code), flush=True)
    if args.check_only:
        print('Fontes e ferramentas conferidas. Nenhuma compilação iniciada.')
        return
    run([*gradle, '-p', str(ROOT), 'assembleDebug'], env=env)
    run(['node', 'tools/check_release.cjs', '--assets'], env=env)
    source = ROOT/'app/build/outputs/apk/debug/app-debug.apk'
    if not source.is_file() or not source.stat().st_size:
        raise RuntimeError('A compilação não produziu o APK esperado neste projeto.')
    verify(source, env['ANDROID_HOME'], release, expected_code)
    target = repo/('AgendaPersonal-v'+release['androidVersion']+'.apk')
    temporary = target.with_name(target.name+'.partial')
    try:
        shutil.copyfile(source, temporary)
        if hashlib.sha256(source.read_bytes()).digest() != hashlib.sha256(temporary.read_bytes()).digest():
            raise RuntimeError('Falha ao copiar o APK. Nenhum arquivo incompleto foi disponibilizado.')
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    print('APK conferido por dentro: '+str(target), flush=True)
    print('Versão '+release['androidVersion']+' · '+str(target.stat().st_size)+' bytes · financeiro, semana e cronômetro presentes.', flush=True)
    print('No Explorador, escolha Baixar nesse APK e instale por cima do aplicativo atual, com a mesma assinatura.')


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, BadZipFile, subprocess.CalledProcessError) as error:
        print('COMPILAÇÃO INTERROMPIDA: '+str(error), file=sys.stderr)
        sys.exit(1)
