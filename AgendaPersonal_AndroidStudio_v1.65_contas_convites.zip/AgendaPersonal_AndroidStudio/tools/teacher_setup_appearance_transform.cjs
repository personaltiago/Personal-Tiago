'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(html){
 const script=/<script id="ap-prof-setup-script">([\s\S]*?)<\/script>/;
 assert.ok(script.test(html));
 html=html.replace(script,(_,body)=>{
  function change(a,b){assert.ok(body.includes(a),'Missing setup anchor: '+a.slice(0,70));body=body.replace(a,b)}
  change('function readConfig(){','function readBrandConfig(){');
  change('function initials(name){',fs.readFileSync(path.resolve(__dirname,'../web/teacher-setup-appearance.js'),'utf8')+'\nfunction initials(name){');
  change('function preview(){root.style','function preview(){refreshSetupAppearance();root.style');
  change("root.style.setProperty('--ap-c',currentConfig.main)","root.style.setProperty('--ap-c',setupAccent())");
  change("$('apsStatus').textContent='';updateInputs();preview();root.hidden=false;","setupBackgrounds=loadSetupBackgrounds();$('apsStatus').textContent='';updateInputs();preview();root.hidden=false;");
  change('localStorage.setItem(KEY,JSON.stringify(currentConfig))','persistSetupAppearance()');
  // Preparing a frame must never replace a saved panel theme with old branding.
  const head=/ const headScript=[\s\S]*?\n doc=doc\.replace\(/;
  assert.ok(head.test(body));body=body.replace(head," const headScript=scriptOpen+'window.__AP_TEST_BRAND='+data+';'+scriptClose;\n doc=doc.replace(");
  change('if(p){const palette={version:1,id:"custom",name:"Minha marca"','if(p&&!hasSaved()){const palette={version:1,id:"custom",name:"Minha marca"');
  change("currentConfig.design=item.id;renderOptions()","currentConfig.design=item.id;preview()");
  change('Object.assign(currentConfig,{main,support,bg});','Object.assign(currentConfig,{main,support});');
  change('const active=[main,support,bg].every((v,j)=>String(v).toLowerCase()===[currentConfig.main,currentConfig.support,currentConfig.bg][j].toLowerCase());','const active=[main,support].every((v,j)=>String(v).toLowerCase()===[currentConfig.main,currentConfig.support][j].toLowerCase());');
  return '<script id="ap-prof-setup-script">'+body+'</script>';
 });
 const anchor='  <section class="aps-block"><h3>Identidade profissional</h3>';
 assert.ok(html.includes(anchor));
 html=html.replace(anchor,'  <section class="aps-block aps-appearance" aria-labelledby="apsAppearanceTitle"><h3 id="apsAppearanceTitle">Modo de exibição</h3><p class="aps-help">Escolha como prefere usar o painel do professor.</p><div class="aps-mode-options" role="group" aria-label="Modo de exibição do professor"><button type="button" data-setup-mode="light" aria-pressed="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.4 1.4m11.2 11.2L19 19M5 19l1.4-1.4M17.6 6.4 19 5"/></svg><span><strong>Claro</strong><small>Fundo claro</small></span><span class="aps-mode-check" aria-hidden="true">✓</span></button><button type="button" data-setup-mode="dark" aria-pressed="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.8 14A9 9 0 0 1 10 3.2 9 9 0 1 0 20.8 14Z"/></svg><span><strong>Escuro</strong><small>Modo noturno</small></span><span class="aps-mode-check" aria-hidden="true">✓</span></button></div><p class="aps-help aps-mode-note">Confirme em “Salvar e abrir painel” ao terminar.</p></section>\n'+anchor);
 const css=fs.readFileSync(path.resolve(__dirname,'../web/teacher-setup-appearance.css'),'utf8');
 html=html.replace('Escolha um tema pronto ou monte sua combinação com três cores. Não há escolha masculino/feminino para o professor.','Escolha uma combinação pronta ou personalize as cores. O modo claro ou escuro escolhido é mantido.');
 const root='<div id="apTeacherSetup" hidden';assert.ok(html.includes(root));
 return html.replace(root,'<style id="ap-setup-appearance-css">'+css+'</style>\n'+root);
};
