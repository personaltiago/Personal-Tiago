'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=n=>fs.readFileSync(path.join(__dirname,'../web',n),'utf8');
const glyphs=JSON.parse(read('more-menu-icons.json'));
module.exports=function(doc){
 assert.ok(!doc.includes('id="ap-more-organization"'));
 for(const marker of ['data-agenda-metal-icons','data-agenda-deep-icons']){
  const start=doc.indexOf('<script '+marker),a=doc.indexOf('>',start)+1,b=doc.indexOf('</script>',a);assert.ok(start>=0&&b>a,marker);
  let script=doc.slice(a,b);assert.ok(script.includes(' function model(svg){'));
  script=script.replace(' function model(svg){',' Object.assign(solid,'+JSON.stringify(glyphs)+');\n function model(svg){\n  if(svg.dataset.apMenuIcon&&solid[svg.dataset.apMenuIcon])return svg.dataset.apMenuIcon;');
  doc=doc.slice(0,a)+script+doc.slice(b);
 }
 return doc.replace('</head>','<style id="ap-more-organization-css">'+read('more-menu-organization.css')+'</style></head>').replace('</body>','<script id="ap-more-menu-glyphs">window.APMoreMenuGlyphs=Object.freeze('+JSON.stringify(glyphs)+');</script><script id="ap-more-organization">'+read('more-menu-organization.js')+'</script></body>');
};
