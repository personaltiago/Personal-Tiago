'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
function replace(doc,from,to){assert.ok(doc.includes(from),'Archive anchor: '+from.slice(0,95));return doc.replace(from,to)}
function model(doc){
 return replace(doc,'enabled:!student.workoutInactive,profile:', 'enabled:student.archived!==true&&!student.workoutInactive,archived:student.archived===true,profile:');
}
function teacher(doc){
 doc=model(doc);
 doc=replace(doc,"let studentsPendingView=false;","let studentsPendingView=false;\nlet studentsArchiveView=false;");
 doc=replace(doc,"(studentsPendingView?'students-unassigned':'students-'+studentViewType)","(studentsArchiveView?'students-archived':studentsPendingView?'students-unassigned':'students-'+studentViewType)");
 doc=replace(doc,"if(['students-presencial','students-online'].includes(screen)){","if(screen==='students-archived'){studentsArchiveView=true;studentsPendingView=false;screen='students'}\n  else if(['students-presencial','students-online'].includes(screen)){studentsArchiveView=false;");
 doc=replace(doc,"}else if(screen==='students-unassigned'){studentsPendingView=true;screen='students'}\n  else if(screen==='students'){studentsPendingView=false}","}else if(screen==='students-unassigned'){studentsArchiveView=false;studentsPendingView=true;screen='students'}\n  else if(screen==='students'){studentsArchiveView=false;studentsPendingView=false}");
 // The archived branch above intentionally skips the generic students branch.
 const tabBlock=/<div class="student-category-tabs segmented"[^>]*>[\s\S]*?<\/div>/;assert.ok(tabBlock.test(doc));
 const archiveTab='<button type="button" data-student-category="archived" onclick="showScreen(\'students-archived\')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h16v13H4zM3 3h18v5H3zM9 12h6"/></svg><span>Arquivados<small id="studentsArchivedCount">0 alunos</small></span></button>';
 doc=doc.replace(tabBlock,block=>block.replace('</div>',archiveTab+'</div>'));
 doc=replace(doc,"const pending=state.students.filter(s=>!studentTypeLabel(s.studentType));","const pending=state.students.filter(s=>s.archived!==true&&!studentTypeLabel(s.studentType));");
 doc=replace(doc,"const category=studentsPendingView?pending:state.students.filter(s=>s.studentType===studentViewType),query=", "const category=studentsArchiveView?state.students.filter(s=>s.archived===true):studentsPendingView?pending:state.students.filter(s=>s.archived!==true&&s.studentType===studentViewType),query=");
 doc=replace(doc,"studentsPendingView?'Tipo a definir':'Lista de alunos'","studentsArchiveView?'Alunos arquivados':studentsPendingView?'Tipo a definir':'Lista de alunos'");
 doc=replace(doc,"const count=state.students.filter(s=>s.studentType===type).length;","const count=state.students.filter(s=>s.archived!==true&&s.studentType===type).length;");
 doc=replace(doc,"const active=!studentsPendingView&&button.dataset.studentCategory===studentViewType;","const active=!studentsPendingView&&button.dataset.studentCategory===(studentsArchiveView?'archived':studentViewType);");
 doc=replace(doc,"document.getElementById('studentsCategoryTotal').textContent=category.length;","const archivedCount=state.students.filter(s=>s.archived===true).length;document.getElementById('studentsArchivedCount').textContent=archivedCount+' '+(archivedCount===1?'aluno':'alunos');\n  document.getElementById('studentsCategoryTotal').textContent=category.length;");
 doc=replace(doc,"category.filter(s=>!s.workoutInactive&&state.workoutPlans.some", "category.filter(s=>s.archived!==true&&!s.workoutInactive&&state.workoutPlans.some");
 doc=replace(doc,"notice.hidden=!pending.length&&!studentsPendingView;","notice.hidden=studentsArchiveView||!pending.length&&!studentsPendingView;");
 doc=replace(doc,'<div class="student-subline"><span class="student-chip student-type">','<div class="student-subline">${s.archived===true?\'<span class="student-chip student-archived-chip">Arquivado</span>\':\'\'}<span class="student-chip student-type">');
 doc=replace(doc,'<button class="btn soft-danger" type="button" onclick="deleteStudent(this.closest(\'[data-student-id]\').dataset.studentId)">Excluir aluno</button>', '<button class="btn student-archive-action" type="button" onclick="toggleStudentArchive(this.closest(\'[data-student-id]\').dataset.studentId)">${s.archived===true?\'Reativar aluno\':\'Arquivar aluno\'}</button><button class="btn soft-danger" type="button" onclick="deleteStudent(this.closest(\'[data-student-id]\').dataset.studentId)">Excluir aluno</button>');
 doc=replace(doc,'</div></details><div class="student-actions">','</div></details>${s.archived===true?studentArchiveSyncHtml(s):\'\'}<div class="student-actions">');
 doc=replace(doc,"${query?'Nenhum aluno encontrado.':studentsPendingView?", "${query?'Nenhum aluno encontrado.':studentsArchiveView?'Nenhum aluno arquivado.':studentsPendingView?");
 doc=replace(doc,"${query?'Tente outro nome ou número de WhatsApp.':studentsPendingView?", "${query?'Tente outro nome ou número de WhatsApp.':studentsArchiveView?'Os alunos arquivados ficam aqui com suas fichas e históricos preservados.':studentsPendingView?");
 doc=replace(doc,"s.studentType=studentType;if(currentScreen==='students')showScreen('students-'+studentType);", "s.studentType=studentType;if(currentScreen==='students')showScreen(s.archived===true?'students-archived':'students-'+studentType);");
 // Archived records remain available from their own tab, never as active workout students.
 doc=replace(doc,"state.students.filter(s=>(!type||s.studentType===type)&&(!status", "state.students.filter(s=>s.archived!==true&&(!type||s.studentType===type)&&(!status");
 doc=replace(doc,"state.students.filter(s=>!s.workoutInactive).length} ativos", "state.students.filter(s=>s.archived!==true&&!s.workoutInactive).length} ativos");
 doc=replace(doc,"state.students.filter(s=>s.workoutInactive).length} inativos", "state.students.filter(s=>s.archived!==true&&s.workoutInactive).length} inativos");
 doc=replace(doc,"function toggleWorkoutStudentActive(){const s=studentById(workoutStudentId);", "function toggleWorkoutStudentActive(){const s=studentById(workoutStudentId);if(s?.archived===true)return toast('Reative o aluno na aba Arquivados para liberar seus treinos.');");
 const archiveJs=fs.readFileSync(path.resolve(__dirname,'../web/teacher-student-archive.js'),'utf8');
 doc=doc.replace('</body>','<script id="ap-student-archive">'+archiveJs+'</script></body>');
 doc=doc.replace('</head>','<style id="ap-student-archive-css">.student-category-tabs.segmented{grid-template-columns:repeat(3,minmax(0,1fr))}.student-category-tabs.segmented button{min-width:0;padding:12px 5px;gap:7px}.student-category-tabs.segmented button>span{min-width:0;font-size:clamp(.75rem,3.3vw,.95rem)}.student-category-tabs.segmented button>svg{flex:0 0 21px;width:21px}.student-archive-sync{grid-column:1/-1;display:flex;align-items:center;flex-wrap:wrap;gap:8px;color:var(--muted);font-size:.78rem;line-height:1.5}.student-archive-sync span{flex:1;min-width:180px}.student-archive-sync .btn{min-height:44px}.student-archived-chip{color:var(--accent,#b875fa);border-color:currentColor}@media(max-width:360px){.student-category-tabs.segmented button{flex-direction:column;gap:4px;min-height:83px;text-align:center}.student-category-tabs.segmented button>span{font-size:.78rem}.student-category-tabs.segmented button small{font-size:.68rem}}</style></head>');
 return doc;
}
function student(doc){
 doc=model(doc);
 doc=replace(doc,"if(context()?.area?.enabled===false)return [];", "if(context()?.role==='student'&&context()?.area?.enabled!==true||context()?.area?.enabled===false)return [];");
 doc=replace(doc,"window.__AP_STUDENT_CONTEXT.area=M.assertArea(cache,user.uid)","window.__AP_STUDENT_CONTEXT.area=window.APStudentAccess?APStudentAccess.accept(M.assertArea(cache,user.uid),user.uid,true):M.assertArea(cache,user.uid)");
 doc=replace(doc,"window.APnotifications?.receiveWorkout(area,doc.metadata?.fromCache===true);window.__AP_STUDENT_CONTEXT.area=area;", "if(window.APStudentAccess)area=APStudentAccess.accept(area,user.uid,doc.metadata?.fromCache===true);window.APnotifications?.receiveWorkout(area,doc.metadata?.fromCache===true);window.__AP_STUDENT_CONTEXT.area=area;window.APStudentAccess?.refresh();");
 doc=replace(doc,"message:'Treino salvo na agenda. Enviando para o aluno…'", "message:area.enabled?'Treino salvo na agenda. Enviando para o aluno…':'Bloqueio salvo na agenda. Enviando para o aluno…'");
 doc=replace(doc,"message:'Treino disponível na conta deste aluno.',at:Date.now()", "message:area.enabled?'Treino disponível na conta deste aluno.':'Acesso aos treinos bloqueado.',at:Date.now()");
 doc=replace(doc,"message:'Treino enviado. Não foi possível salvar a confirmação neste aparelho.',at:Date.now()", "message:(area.enabled?'Treino enviado.':'Acesso aos treinos bloqueado.')+' Não foi possível salvar a confirmação neste aparelho.',at:Date.now()");
 const js=fs.readFileSync(path.resolve(__dirname,'../web/student-access.js'),'utf8');
 doc=doc.replace('</body></html>','<script id="ap-student-access">'+js+'</script></body></html>');
 return doc;
}
module.exports={teacher,student};
