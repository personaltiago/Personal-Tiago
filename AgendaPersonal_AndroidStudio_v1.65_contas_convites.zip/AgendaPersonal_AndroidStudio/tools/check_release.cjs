'use strict';
// Validate the actual extracted project; do not infer its version from its folder name.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),vm=require('node:vm');
const root=path.resolve(__dirname,'..'),read=n=>fs.readFileSync(path.join(root,n),'utf8'),fail=m=>{throw Error(m)};
function check(){
 const release=JSON.parse(read('release.json')),gradle=read('app/build.gradle'),update=read('app/src/main/java/com/tiagolima/agendapersonal/UpdateManager.java');
 if(release.format!==1||release.androidVersion!=='1.148'||release.versionCode!==148||release.contentVersion!=='1.12.68'||release.sequence!==174)fail('Identificação da atualização incompatível.');
 if(!gradle.includes("versionName '"+release.androidVersion+"'")||!new RegExp('versionCode[^\\n]+: '+release.versionCode+'\\s').test(gradle))fail('O projeto Android não corresponde à versão '+release.androidVersion+'.');
 if(JSON.parse(read('package.json')).version!==release.androidVersion+'.0')fail('A versão dos arquivos web diverge do projeto.');
 if(!update.includes('BASE_VERSION = "'+release.contentVersion+'"')||!update.includes('BASE_SEQUENCE = '+release.sequence+';'))fail('A versão de conteúdo diverge do projeto.');
 if(!release.sourceHashes||Object.keys(release.sourceHashes).length<10)fail('Falta a lista de conferência do pacote.');
 for(const [file,expected]of Object.entries(release.sourceHashes)){
  if(path.isAbsolute(file)||file.split('/').includes('..')||!/^([a-f0-9]{64})$/.test(expected))fail('Lista de conferência inválida.');
  const hash=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex');if(hash!==expected)fail('Arquivo diferente do pacote revisado: '+file+'.');
 }
 const manifest=read('app/src/main/AndroidManifest.xml');for(const token of ['android.permission.SYSTEM_ALERT_WINDOW','android.permission.FOREGROUND_SERVICE_SPECIAL_USE','android:name=".LessonTimerOverlayService"'])if(!manifest.includes(token))fail('Permissão ou serviço do cronômetro ausente.');
 let scripts=0;
 if(process.argv.includes('--assets')){
  for(const page of ['index','professor','avaliacoes','cadastro']){
   const html=read('app/src/main/assets/'+page+'.html');if(!html.includes('</html>'))fail('Tela incompleta: '+page);
   for(const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){
    const type=match[1].match(/\btype\s*=\s*["']([^"']+)/i)?.[1];if(type&&!['text/javascript','application/javascript'].includes(type))continue;
    new vm.Script(match[2],{filename:page+'.html#script'+(++scripts)});
   }
  }
  const teacher=read('app/src/main/assets/professor.html');for(const token of ['id="financeResults"','ap-finance-results-model','APIconMaterial','ap-compact-week-agenda','showLessonTimerOverlay'])if(!teacher.includes(token))fail('Atualização ausente na tela gerada: '+token);
 }
 console.log('Projeto conferido: Android '+release.androidVersion+' / conteúdo '+release.contentVersion+' / sequência '+release.sequence+(scripts?' / '+scripts+' scripts analisados.':'.'));
}
try{check()}catch(error){console.error('CONFERÊNCIA INTERROMPIDA: '+error.message);process.exitCode=1}
