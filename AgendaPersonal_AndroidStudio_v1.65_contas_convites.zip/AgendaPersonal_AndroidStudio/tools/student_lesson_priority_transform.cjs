'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 for(const anchor of ['function renderStudents(','function renderWorkouts(','function occurrences(','function dashboardLessonMode('])assert.ok(doc.includes(anchor),'student priority anchor: '+anchor);
 const read=name=>fs.readFileSync(path.join(__dirname,'../web',name),'utf8');
 return doc.replace('</head>','<style id="ap-student-lesson-priority-css">'+read('student-lesson-priority.css')+'</style></head>').replace('</body>','<script id="ap-student-lesson-priority">'+read('student-lesson-priority.js')+'</script></body>');
};
