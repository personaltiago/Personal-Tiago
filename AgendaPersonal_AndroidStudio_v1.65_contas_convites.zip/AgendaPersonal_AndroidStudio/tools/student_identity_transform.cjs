'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
function trainerPacket(doc){
 const anchor='assertArea(area,linked||null);return area;';assert.ok(doc.includes(anchor));
 return doc.replace(anchor,`const trainer=state.trainerProfile||{};area.trainer={name:text(trainer.name,120),subtitle:text(trainer.subtitle,100),cref:text(trainer.cref,40),photo:/^data:image\\/(jpeg|png|webp);base64,/.test(trainer.photoDataUrl||'')&&trainer.photoDataUrl.length<200000?trainer.photoDataUrl:''};
  `+anchor);
}
function studentIdentity(doc){
 const marker='<button type="button" id="removeProfilePhoto"';assert.ok(doc.includes(marker));
 doc=doc.replace(marker,'<button type="button" id="adjustStudentPhoto" class="photo-source-option" onclick="APStudentPhoto.adjust()" hidden><span><strong>Ajustar recorte</strong><small>Mover o círculo e ajustar o zoom</small></span><span class="photo-source-arrow">›</span></button>'+marker);
 const dialog=fs.readFileSync(path.resolve(__dirname,'../web/student-photo-dialog.html'),'utf8');
 const js=fs.readFileSync(path.resolve(__dirname,'../web/student-identity.js'),'utf8');
 const css=fs.readFileSync(path.resolve(__dirname,'../web/student-identity.css'),'utf8');
 doc=doc.replace('</body></html>',dialog+'<script id="ap-student-identity-controls">'+js+'</script></body></html>');
 doc=doc.replace('</head>','<style id="ap-student-identity-css">'+css+'</style></head>');
 doc=doc.replace("for(const id of ['exFinishModal','profileEditor','profilePhotoDialog'", "if(window.APStudentPhoto?.isOpen()){window.APStudentPhoto.cancel();return true}\n for(const id of ['exFinishModal','profileEditor','profilePhotoDialog'");
 const reset="function reset(){for(const id of ['homeModal','bgDialog','profilePhotoDialog'";
 assert.ok(doc.includes(reset));doc=doc.replace(reset,"function reset(){window.APStudentPhoto?.cancel();for(const id of ['homeModal','bgDialog','profilePhotoDialog'");
 return doc;
}
module.exports={trainerPacket,studentIdentity};
