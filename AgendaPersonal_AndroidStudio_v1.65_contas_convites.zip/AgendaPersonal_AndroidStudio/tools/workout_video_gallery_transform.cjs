'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const anchor='function workoutCatalogChanges(ex){';assert.equal(doc.split(anchor).length-1,1);
 const code=fs.readFileSync(path.resolve(__dirname,'../web/workout-video-gallery.js'),'utf8');
 doc=doc.replace(anchor,code+'\n'+anchor+"\n  if(workoutExerciseMode!=='catalog'&&workoutCatalogHasVideo(ex))return workoutGalleryVideoChanges(ex);");
 const open='function openWorkoutCatalog(picking=false){';assert.ok(doc.includes(open));
 doc=doc.replace(open,open+'\n  recoverWorkoutGalleryVideos();');
 const label='<input id="workoutExerciseReusable" type="checkbox">Salvar também em Seus exercícios</label>';assert.ok(doc.includes(label));
 doc=doc.replace(label,label+'<p class="note full">O vídeo também ficará disponível na galeria de exercícios.</p>');
 const update='function updateWorkoutVideoField(){';assert.ok(doc.includes(update));
 doc=doc.replace(update,update+"\n  document.getElementById('workoutExerciseReusable').parentElement.hidden=workoutExerciseMode==='catalog'||workoutCatalogHasVideo({video:document.getElementById('workoutExerciseVideo').value});");
 const hint='Como fazer e Observação já estão preenchidos. Salvar um link válido move o exercício para Com vídeo; apagar o link devolve para Sem vídeo.';
 assert.ok(doc.includes(hint));
 return doc.replace(hint,'Vídeos salvos no treino também ficam na galeria. Exercícios já cadastrados atualizam o mesmo item; exercícios novos aparecem em Seus exercícios.');
};
