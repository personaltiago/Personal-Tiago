'use strict';
const assert=require('node:assert/strict');
const paw='<ellipse cx="5" cy="8" rx="2.5" ry="3.5" transform="rotate(-25 5 8)"/><ellipse cx="10" cy="4.5" rx="2.4" ry="3.4" transform="rotate(-8 10 4.5)"/><ellipse cx="16" cy="5" rx="2.4" ry="3.4" transform="rotate(15 16 5)"/><ellipse cx="20.5" cy="9" rx="2.4" ry="3.3" transform="rotate(30 20.5 9)"/><path d="M5 18c0-2 2-3 3.5-5.2 1.7-2.6 5.3-2.6 7 0C17 15 19 16 19 18c0 3-3 4.5-5.5 3.3a3.5 3.5 0 0 0-3 0C8 22.5 5 21 5 18Z"/>';
exports.teacher=function(doc){
 const section=/<section class="more-group" aria-labelledby="moreOptionsTitle">[\s\S]*?<\/section>/;assert.ok(section.test(doc));
 const icon='<svg viewBox="0 0 24 24" fill="currentColor" stroke="none" aria-hidden="true">'+paw+'</svg>';
 const card='<button id="morePet" class="more-function more-function-compact" type="button" data-panel-action="pet"><span class="more-function-icon">'+icon+'</span><span class="more-function-copy"><strong>Pet</strong><small>Mostrar ou ocultar seu mascote.</small></span><span class="more-chevron"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></span></button>';
 doc=doc.replace(section,s=>s.replace('</div></section>',card+'</div></section>'));
 const action="else if(action==='logout')requestAccountLogout();";assert.ok(doc.includes(action));
 doc=doc.replace(action,action+"\n  else if(action==='pet')window.parent.postMessage({kind:'AP_OPEN_TEACHER_MASCOT'},'*');");
 for(const anchor of ['const solid={\n','const solid={...{\n']){assert.ok(doc.includes(anchor));doc=doc.replace(anchor,anchor+"  pet:'"+paw+"',\n")}
 const semantic="if(p?.matches('.more-function[data-panel-action=\"logout\"]'))return 'logout';";assert.ok(doc.includes(semantic));
 doc=doc.replace(semantic,semantic+"\n  if(p?.matches('.more-function[data-panel-action=\"pet\"]'))return 'pet';");
 doc=doc.replace("logout:'logout'};","logout:'logout',pet:'pet'};");
 return doc.replace('</head>','<style id="ap-pet-card-css">.ap-teacher-mascot[hidden]{display:none!important}</style></head>');
};
exports.student=function(html){
 const anchor='<button id="apProfileUpdates"';assert.ok(html.includes(anchor));
 const option='<button id="apProfilePet" type="button" class="profile-option" onclick="APmascot.open()"><span><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">'+paw+'</svg></span><div><strong>Pet</strong><small>Mostrar ou ocultar seu mascote</small></div><span class="profile-chevron" data-profile-icon="chevron"></span></button>';
 return html.replace(anchor,option+anchor);
};
