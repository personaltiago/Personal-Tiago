'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const image=`<img class="ws-card-photo" alt="" src="'+photoForWorkout(w.id)+'" onerror="this.hidden=true">`;
 assert.equal(doc.split(image).length-1,1,'Expected one production workout card thumbnail');
 doc=doc.replace(image,`'+APWorkoutMuscles.render(w)+'`);
 const js=fs.readFileSync(path.resolve(__dirname,'../web/workout-muscle-preview.js'),'utf8'),css=fs.readFileSync(path.resolve(__dirname,'../web/workout-muscle-preview.css'),'utf8');
 const anchor='<script id="ap-student-ui">';assert.ok(doc.includes(anchor));
 doc=doc.replace(anchor,'<script id="ap-workout-muscle-preview">'+js+'</script>'+anchor);
 return doc.replace('</head>','<style id="ap-workout-muscle-preview-css">'+css+'</style></head>');
};
