'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=name=>fs.readFileSync(path.resolve(__dirname,'../web/'+name),'utf8');
function replace(doc,old,value){assert.ok(doc.includes(old),'Missing profile assessment anchor: '+old.slice(0,70));return doc.replace(old,value)}
exports.teacher=function(doc){
 doc=replace(doc,"function openEvaluations(sid=''){","function openEvaluations(sid='',view='',assessmentId=''){");
 doc=replace(doc,"if(s){params.set('agendaStudentId',s.id);params.set('name',s.name);", "if(s){if(view==='history')params.set('view','history');if(assessmentId)params.set('assessmentId',assessmentId);params.set('agendaStudentId',s.id);params.set('name',s.name);");
 doc=replace(doc,'openEvaluations(s.id)}\nfunction openCurrentProfileLesson',"openEvaluations(s.id,'history')}\nfunction openCurrentProfileLesson");
 doc=replace(doc,'<b>Avaliação corporal</b><small>Anamnese, medidas, fotos e evolução do aluno.</small>','<b>Avaliações físicas</b><small>Histórico, resultados e nova avaliação.</small>');
 const start=doc.indexOf('async function evaluationClientForStudent('),end=doc.indexOf('function profileBodyComposition(',start);assert.ok(start>=0&&end>start);
 doc=doc.slice(0,start)+read('profile-assessment-store.js')+'\n'+doc.slice(end);
 const renderStart=doc.indexOf('async function loadProfileEvaluationResults('),renderEnd=doc.indexOf('\nfunction renderFinanceAlert(',renderStart);assert.ok(renderStart>=0&&renderEnd>renderStart);
 doc=doc.slice(0,renderStart)+read('profile-assessments.js')+'\n'+doc.slice(renderEnd);
 return doc.replace('</head>','<style id="ap-profile-assessments-css">'+read('profile-assessments.css')+'</style></head>');
};
exports.assessment=function(doc){
 return replace(doc,'      selectedClientId = match.id;\n      startAssessment(null, false);',`      selectedClientId = match.id;
      if (agendaParams.get('view') === 'history') {
        showDashboard();
        const recordId = agendaParams.get('assessmentId');
        const record = recordId ? match.assessments.find(item => item.id === recordId) : null;
        if (record) openReport(record);
        else {
          if (recordId) {
            const notice = document.createElement('p');
            notice.className = 'empty-state'; notice.setAttribute('role', 'status');
            notice.textContent = 'Esta avaliação não está mais no histórico deste aluno.';
            clientDetail.prepend(notice);
          }
          clientDetail.scrollIntoView({ behavior: 'instant', block: 'start' });
        }
      } else startAssessment(null, false);`);
};
