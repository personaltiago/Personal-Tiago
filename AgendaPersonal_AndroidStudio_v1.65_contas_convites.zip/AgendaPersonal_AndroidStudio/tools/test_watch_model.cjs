'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const c={};vm.createContext(c);vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/watch-workout-model.js'),'utf8'),c);const packet=c.APWatchModel.packet;
const ex=(id,rest=60)=>({id,name:id,rows:[{reps:'12',load:20,rest},{reps:'10',load:22,rest}]});
const ordinary={id:'plan~day',label:'Treino A',exercises:[ex('e1'),ex('e2')]};
for(const role of ['student','teacher']){const p=packet(ordinary,role,'Aluno');assert.equal(p.steps.length,4);assert.deepEqual(JSON.parse(JSON.stringify(p.steps.map(s=>[s.e,s.set]))),[[0,0],[0,1],[1,0],[1,1]]);assert.equal(p.role,role);assert.equal(p.exercises[0].rows[1].load,'22');}
const pair={id:'p~d',exercises:[{...ex('B'),pair:'b1',pairOwner:false},ex('C'),{...ex('A'),pair:'b1',pairOwner:true}]};
const p=packet(pair,'teacher','Aluno');assert.deepEqual(JSON.parse(JSON.stringify(p.steps)),[{e:2,set:0,rest:0},{e:0,set:0,rest:60},{e:2,set:1,rest:0},{e:0,set:1,rest:60},{e:1,set:0,rest:60},{e:1,set:1,rest:60}]);
assert.throws(()=>packet({...pair,exercises:pair.exercises.slice(0,1)},'student','Aluno'),/bi-set/);
assert.throws(()=>packet({...ordinary,exercises:[ex('bad',-1)]},'student','Aluno'),/intervalos/);
assert.throws(()=>packet(ordinary,'preview','Aluno'),/válido/);
assert.throws(()=>packet({...ordinary,exercises:[{...ex('e'),rows:Array(31).fill({reps:'12',rest:60})}]},'student','Aluno'),/30 séries/);
console.log('Watch model: roles, series targets, bi-set order, missing partner, limits and invalid rest passed.');
