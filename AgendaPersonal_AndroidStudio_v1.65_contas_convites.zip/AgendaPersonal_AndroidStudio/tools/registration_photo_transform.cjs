'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=name=>fs.readFileSync(path.resolve(__dirname,'../web/'+name),'utf8');
const appendPhoto=doc=>doc.replace('</head>','<style id="ap-registration-photo-css">'+read('registration-photo.css')+'</style></head>').replace('</body>','<script id="ap-registration-photo-js">'+read('registration-photo.js')+'</script></body>');
exports.teacher=function(doc){
 const start=doc.indexOf('<script data-agenda-registration>'),end=doc.indexOf('</script>',start);assert.ok(start>=0&&end>start);let code=doc.slice(start,end);
 const replace=(a,b)=>{assert.equal(code.split(a).length-1,1,a.slice(0,100));code=code.replace(a,b)};
 replace('  function profileData(value){',"  function registrationPhoto(value){return typeof value==='string'&&value.length<=120000&&/^data:image\\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(value)?value:''}\n  function profileData(value){");
 replace("gender:String(value.genero||'').slice(0,60)","gender:String(value.genero||'').slice(0,60),photo:registrationPhoto(value.fotoCadastro)");
 replace("studentType:type,firebaseUid:p.uid,email:","studentType:type,photoDataUrl:existing?.photoDataUrl||p.photo,firebaseUid:p.uid,email:");
 replace("+'\"><strong>'+esc(record.nome)","+'\">'+(registrationPhoto(record.fotoCadastro)?'<img class=\"registration-contact-photo\" src=\"'+esc(registrationPhoto(record.fotoCadastro))+'\" alt=\"Foto de '+esc(record.nome)+'\" width=\"72\" height=\"72\">':'')+'<strong>'+esc(record.nome)");
 doc=doc.slice(0,start)+code+doc.slice(end);
 return doc.replace('</head>','<style id="ap-registration-contact-photo-css">.registration-contact-photo{display:block;width:72px;height:72px;border-radius:50%;object-fit:cover;border:1px solid var(--line);margin:0 0 12px}</style></head>');
};
exports.embedded=function(doc){
 const anchor='<form id="registrationForm">';assert.equal(doc.split(anchor).length-1,1);doc=doc.replace(anchor,anchor+read('registration-photo.html'));
 const old="const value=Object.fromEntries(new FormData(event.currentTarget));try{validate(value)}";assert.ok(doc.includes(old));doc=doc.replace(old,"const value=Object.fromEntries(new FormData(event.currentTarget));try{value.fotoCadastro=window.APRegistrationPhoto?.value()||'';validate(value)}");
 const declaration='const data=validate(value),f=await connect();';assert.ok(doc.includes(declaration));doc=doc.replace(declaration,"const data=validate(value),photo=String(value.fotoCadastro||'');if(photo&&(photo.length>120000||!/^data:image\\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(photo)))throw Error('Confira a foto antes de enviar.');if(photo)data.fotoCadastro=photo;const f=await connect();");
 const prior="return current.ativo===true?'approved':'pending'}";assert.ok(doc.includes(prior));doc=doc.replace(prior,"if(current.ativo!==true&&photo)await f.updateDoc(ref,{fotoCadastro:photo});return current.ativo===true?'approved':'pending'}");
 return appendPhoto(doc);
};
exports.public=function(doc){
 const anchor='<p class="intro">Você receberá acesso ao aplicativo depois da aprovação.</p>';assert.equal(doc.split(anchor).length-1,1);doc=doc.replace(anchor,anchor+read('registration-photo.html'));
 // Keep the deployed layout and Open Graph cover. Share the validated, retry-safe form flow.
 const start=doc.indexOf('  <script type="module">'),end=doc.indexOf('</script>',start);assert.ok(start>=0&&end>start);
 const code=read('registration-public-submit.js');doc=doc.slice(0,start)+'<script type="module">'+code+doc.slice(end);
 return appendPhoto(doc);
};
