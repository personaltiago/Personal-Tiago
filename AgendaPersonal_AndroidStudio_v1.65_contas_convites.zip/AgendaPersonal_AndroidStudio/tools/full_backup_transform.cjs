'use strict';
const fs=require('node:fs'),path=require('node:path');
module.exports=doc=>doc.replace('</head>','<style>'+fs.readFileSync(path.resolve(__dirname,'../web/full-backup.css'),'utf8')+'</style></head>').replace('</body>',['full-backup-core.js','full-backup.js'].map(n=>'<script>'+fs.readFileSync(path.resolve(__dirname,'../web/'+n),'utf8')+'</script>').join('')+'</body>');
