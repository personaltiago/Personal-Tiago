'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
module.exports=function(html){
 function change(a,b){assert.ok(html.includes(a),'Missing startup anchor: '+a.slice(0,70));html=html.replace(a,b)}
 // Embed the native launcher artwork so four-page updates carry the same logo
 // even when an installed APK still has an older, unrelated web icon.png.
 const logo='data:image/png;base64,'+fs.readFileSync(path.join(__dirname,'../app/src/main/res/mipmap-xxxhdpi/ic_launcher.png')).toString('base64');
 const source=fs.readFileSync(path.join(__dirname,'../web/startup.js'),'utf8');
 assert.equal(source.split('__AP_STARTUP_LOGO__').length,2);
 const js=minify_sync(source.replace('__AP_STARTUP_LOGO__',logo),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code,css=fs.readFileSync(path.join(__dirname,'../web/startup.css'),'utf8').trim();
 change('<head>','<head><style id="ap-startup-style">'+css+'</style><script id="ap-startup">'+js+'</script>');
 change("if(!user){if(identity)clear();return}","if(!user){if(identity)clear();window.APstartup.finish();return}");
 change("async function activate(user,requested=''){\n  clear();", "async function activate(user,requested=''){\n  window.APstartup.begin();clear();");
 change("activate(user).catch(e=>{clear();notice(errorText(e))})", "activate(user).catch(e=>{clear();notice(errorText(e));window.APstartup.finish()})");
 change("window.APopenTeacher();pump();return", "window.APopenTeacher();if(!document.getElementById('apTeacherSetup').hidden)window.APstartup.finish();pump();return");
 change('window.APstudentUI.activate();','window.APstudentUI.activate();window.APstartup.finish();');
 change('ensure().catch(()=>{});','ensure().catch(()=>window.APstartup.fail());');
 change("finally{loginBusy=false;", "finally{if(!identity)window.APstartup.finish();loginBusy=false;");
 change("function showError(error){status.hidden=false;", "function showError(error){window.APstartup.fail('Não foi possível abrir o painel. Tente abrir novamente.');status.hidden=false;");
 return html;
};
