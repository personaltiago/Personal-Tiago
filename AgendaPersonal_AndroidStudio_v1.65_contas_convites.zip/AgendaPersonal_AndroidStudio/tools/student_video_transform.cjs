'use strict';
const assert=require('node:assert/strict');
function model(doc){
 const own='video:https(ex.video),technique:';
 assert.ok(doc.includes(own),'student packet video field');
 doc=doc.replace(own,'video:https(helpers.video?helpers.video(ex):ex.video),technique:');
 const hosts="if(u.hostname==='youtu.be')v=u.pathname.slice(1);else if(/^(www\\.)?(youtube\\.com|youtube-nocookie\\.com)$/.test(u.hostname))";
 assert.ok(doc.includes(hosts),'student YouTube host parser');
 return doc.replace(hosts,"if(/^(www\\.)?youtu\\.be$/.test(u.hostname))v=u.pathname.slice(1);else if(/^(?:(?:www|m|music)\\.)?(youtube\\.com|youtube-nocookie\\.com)$/.test(u.hostname))");
}
function teacher(doc){
 doc=model(doc);
 const helpers='const helpers={visible:workoutPlanVisible,groups:window.workoutBisetGroups,shared:window.workoutBisetExercisePrescription,prescription:window.workoutTechniqueRoundPrescription};';
 assert.ok(doc.includes(helpers),'teacher publication helpers');
 return doc.replace(helpers,helpers.replace('visible:', 'video:workoutExerciseVideoUrl,visible:'));
}
function student(doc){
 doc=model(doc);
 const snapshots='for(const session of Object.values(sessions))if(session?.workoutSnapshot){const found=list.findIndex(w=>w.id===session.id);if(found>=0)list[found]=M.clone(session.workoutSnapshot);else list.push(M.clone(session.workoutSnapshot))}';
 assert.ok(doc.includes(snapshots),'active student workout snapshot');
 return doc.replace(snapshots,`for(const session of Object.values(sessions))if(session?.workoutSnapshot){
   const found=list.findIndex(w=>w.id===session.id),snapshot=M.clone(session.workoutSnapshot),latest=found>=0?list[found]:null;
   // Refresh demonstrations and instructions. The active prescription, order, timer,
   // completed sets and loads remain attached to the original session.
   if(latest)for(const ex of snapshot.exercises){const current=latest.exercises.find(e=>e.id===ex.id&&e.name===ex.name);if(current){ex.video=current.video||'';ex.desc=current.desc||''}}
   if(found>=0)list[found]=snapshot;else list.push(snapshot);
  }`);
}
module.exports={teacher,student};
