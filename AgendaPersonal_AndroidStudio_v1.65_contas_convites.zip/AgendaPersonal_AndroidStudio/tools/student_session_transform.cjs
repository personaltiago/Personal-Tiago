'use strict';
const assert=require('node:assert/strict');
module.exports=function(html){
 function change(from,to){assert.equal(html.split(from).length,2,'student session anchor: '+from.slice(0,75));html=html.replace(from,to)}
 // An approved account opens its home directly. Appearance remains editable
 // from the profile; a missing legacy onboarding flag must not act like logout.
 change("route(prefs().completed||preview?'home':'aluno');","route('home');");
 // Back navigation cannot expose the signed-out entry while a student context
 // is active. clear() removes that context before legitimate logout/revocation.
 change("route=function(view){if(view==='professor')", "route=function(view){if(context()?.role==='student'&&['landing','login'].includes(view))view='home';if(view==='professor')");
 // Move the existing start action, keeping the original handlers and finish gate.
 change("return tabs+progress+'<div class=\"flow-exercises\">'+rows+'</div>'+bottom+", "return tabs+progress+(!running?bottom.replace('flow-bottom-cta','flow-top-cta'):'')+'<div class=\"flow-exercises\">'+rows+'</div>'+(running?bottom:'')+");
 return html.replace('</head>','<style id="ap-student-session-layout">#exerciseScreen .flow-top-cta{margin:12px 0 16px}#exerciseScreen .flow-top-cta .flow-cta{min-height:48px;height:auto;padding:12px 16px;white-space:normal}</style></head>');
};
