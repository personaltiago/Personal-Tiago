'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const read=n=>fs.readFileSync(path.join(__dirname,'../web',n),'utf8');
 const replace=(from,to)=>{assert.equal(doc.split(from).length,2,'Retired rest notice anchor: '+from.slice(0,65));doc=doc.replace(from,to)};
 // Remove the retired view and its updates, rather than keeping a hidden timer.
 replace('<button id="workoutRestNotice" class="workout-rest-notice" type="button" onclick="resumeWorkoutRest()" hidden><span id="workoutRestNoticeName"></span><b id="workoutRestNoticeTime"></b></button>','');
 replace("notice=document.getElementById('workoutRestNotice'),",'');
 replace(';notice.hidden=!r;',';');
 replace("document.getElementById('workoutRestNoticeName').textContent=r.student+' · '+r.exercise;document.getElementById('workoutRestNoticeTime').textContent=text;",'');
 const guideStart="    const notice=document.getElementById('workoutRestNotice');",guideEnd="    if(!guide||!document.getElementById('workoutBisetDialog').classList.contains('open'))return;";
 const at=doc.indexOf(guideStart),endGuide=doc.indexOf(guideEnd,at);assert.ok(at>=0&&endGuide>at,'Retired bi-set notice positioning');doc=doc.slice(0,at)+doc.slice(endGuide);
 doc=doc.replace(/(<style\b[^>]*>)([\s\S]*?)(<\/style>)/g,(_,open,css,close)=>open+css.replace(/([^{}]+)\{([^{}]*)\}/g,(rule,selectors,body)=>{if(!/workout-rest-notice|workoutRestNotice/.test(selectors))return rule;const keep=selectors.split(',').filter(s=>!/workout-rest-notice|workoutRestNotice/.test(s));return keep.length?keep.join(',')+'{'+body+'}':''})+close);
 assert.ok(!doc.includes('workoutRestNotice'),'Retired notice has no remaining consumers');
 const anchor='<button id="workoutRestStart"';assert.equal(doc.split(anchor).length,2,'rest form');
 const end='</form>';const start=doc.indexOf(anchor),formEnd=doc.indexOf(end,start);assert.ok(formEnd>start);
 doc=doc.slice(0,formEnd)+'<button id="workoutRestFloat" class="btn ap-rest-minimize" type="button" onclick="floatWorkoutRest()" hidden>Deixar flutuante</button>'+doc.slice(formEnd);
 // Pass only a validated color to the native view, without changing the rest deadline.
 const arm='Android.startWorkoutRest(JSON.stringify({...rest,triggerAtMillis:rest.endAt}))';assert.ok(doc.includes(arm));
 doc=doc.replaceAll(arm,`Android.startWorkoutRest(JSON.stringify({...rest,triggerAtMillis:rest.endAt,accent:(getComputedStyle(document.documentElement).getPropertyValue('--ac-accent').trim().match(/^#[a-fA-F0-9]{6}$/)||['#9CC72C'])[0]}))`);
 return doc.replace('</head>','<style id="ap-rest-floating-css">'+read('rest-floating.css')+'</style></head>').replace('</body>','<script id="ap-rest-floating">'+read('rest-floating.js')+'</script></body>');
};
