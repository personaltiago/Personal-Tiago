'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=name=>fs.readFileSync(path.resolve(__dirname,'../web/'+name),'utf8');
function teacher(html){
 const pattern=/(<script\b[^>]*\bdata-agenda-registration(?:\s[^>]*)?>)([\s\S]*?)(<\/script>)/;
 assert.equal((html.match(/<script\b[^>]*\bdata-agenda-registration/g)||[]).length,1,'Registration module changed');
 assert.ok(pattern.test(html),'Registration module missing');
 return html.replace(pattern,(_,open,body,close)=>open+read('registration-contacts-session.js')+close);
}
function entry(html){
 const pattern=/(<script\b[^>]*\bid=["']ap-student-accounts["'][^>]*>)([\s\S]*?)(<\/script>)/;
 assert.ok(pattern.test(html),'Account module missing');
 return html.replace(pattern,(_,open,code,close)=>{
  if(code.includes('function registrationOwner(')){
   assert.ok(code.includes('registrations:')&&code.includes('registrationList')&&code.includes('registrationApprove'),'Incomplete registration owner service');
   return open+code+close;
  }
  for(const token of ['async function I()','const A=()=>','let S=','window.APaccounts=Object.freeze({'])assert.ok(code.includes(token),'Account session anchor changed: '+token);
  const anchor='window.APaccounts=Object.freeze({';
  assert.equal(code.split(anchor).length,2,'Account API changed');
  code=code.replace(anchor,read('contacts-session-service.js')+anchor+'registrations:Object.freeze({list:registrationList,approve:registrationApprove}),');
  return open+code+close;
 });
}
module.exports={teacher,entry};
