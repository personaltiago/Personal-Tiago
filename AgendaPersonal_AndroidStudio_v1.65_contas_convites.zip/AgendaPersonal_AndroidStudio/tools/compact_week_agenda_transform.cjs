'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 function once(before,after,label){assert.equal(doc.split(before).length,2,label);doc=doc.replace(before,after)}
 // Keep all seven dates and occurrence IDs; only the selected day's group is visible.
 once("open=sameWeek?opened.has(ds):ds===agendaSelectedDate,date=", "open=ds===agendaSelectedDate,date=", 'week selection controls visibility');
 once("first=open?defaultExpandedAgendaLesson(list):null;", "first=null;", 'start week lesson rows collapsed');
 once('data-date="${ds}" ontoggle="onAgendaDayToggle(this)"${open?\' open\':\'\'}>', 'data-date="${ds}" ontoggle="onAgendaDayToggle(this)"${open?\' open\':\' hidden\'}>', 'hide other days without deleting their lessons');
 once("document.querySelectorAll('#weekList>.day-card').forEach(card=>card.open=card===selected);", "document.querySelectorAll('#weekList>.day-card').forEach(card=>{card.hidden=card!==selected;card.open=card===selected});", 'tap a date reveals exactly one day');
 once("if(lid)openAgendaLesson(lid,date,'weekList');else selected.scrollIntoView({block:'start',behavior:'auto'});", "if(lid)openAgendaLesson(lid,date,'weekList');", 'date selection does not jump down the screen');
 // Include a small identity marker only in the week; Today's existing controls stay intact.
 const anchor='  const presentation=dashboardStatus(item,new Date());';
 once(anchor,anchor+`\n  const weekAvatar=rootId==='weekList'?\`<span class="agenda-week-avatar" aria-hidden="true">\${s?.photoDataUrl?\`<img src="\${hesc(s.photoDataUrl)}" alt="">\`:hesc(studentInitials(name))}</span>\`:'';
  const weekFinance=rootId==='weekList'&&s?.financeEnabled&&s.dueDate?financeStatus(s):null;
  const weekFinanceText=weekFinance?({overdue:'Em atraso',today:'Vence hoje',soon:'Vence em breve',ok:'Em dia'}[weekFinance.kind]||''):'';
  const weekFinanceHtml=weekFinanceText?\`<span class="agenda-week-finance finance-\${weekFinance.kind}">Financeiro: \${hesc(weekFinanceText)}</span>\`:'';`, 'week avatar and independent financial label');
 once('${hesc(l.duration)} min</small></span><span class="agenda-lesson-person">', '${hesc(l.duration)} min</small></span>${weekAvatar}<span class="agenda-lesson-person">', 'week row avatar placement');
 once('${hesc(description)}</span></span></span><span class="agenda-lesson-state">', '${hesc(description)}</span></span>${weekFinanceHtml}</span><span class="agenda-lesson-state">', 'financial status remains separate from attendance');
 const begin='  wrap.dataset.weekStart=baseDate;wrap.innerHTML=html;document.getElementById(\'weekDayStrip\').innerHTML=strip;';
 once(begin,begin+"\n  document.querySelector('#weekDayStrip .week-day-pill.is-selected')?.scrollIntoView?.({block:'nearest',inline:'nearest'});", 'keep selected day accessible in narrow screens');
 return doc.replace('</head>','<style id="ap-compact-week-agenda">'+fs.readFileSync(path.resolve(__dirname,'../web/compact-week-agenda.css'),'utf8')+'</style></head>');
};
