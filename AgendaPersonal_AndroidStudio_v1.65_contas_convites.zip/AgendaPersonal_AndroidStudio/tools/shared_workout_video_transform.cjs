'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const old="function workoutExerciseVideoUrl(ex){const own=normalizedWorkoutVideoUrl(ex?.video);if(own)return own;return ex?.catalogId?normalizedWorkoutVideoUrl(workoutCatalogItem(ex.catalogId)?.video):''}";
 assert.equal(doc.split(old).length,2,'Shared video resolver anchor');
 return doc.replace(old,fs.readFileSync(path.resolve(__dirname,'../web/shared-workout-video-resolver.js'),'utf8'));
};
