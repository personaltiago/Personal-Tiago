'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
function replace(doc,from,to){assert.ok(doc.includes(from),'Student tools anchor: '+from.slice(0,90));return doc.replace(from,to)}
module.exports=function(doc){
 const start=doc.indexOf('<div class="student-stat-grid">'),end=doc.indexOf('<div class="section-title student-list-heading">',start);
 assert.ok(start>0&&end>start,'Six student management cards');
 const cards=doc.slice(start,end);assert.equal((cards.match(/class="student-stat(?: green)?"/g)||[]).length,2);assert.equal((cards.match(/class="action-tile/g)||[]).length,4);
 doc=doc.slice(0,start)+doc.slice(end);
 const search='<label class="module-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="7.5"/><path d="m16 16 5 5"/></svg><input id="studentSearch"';
 doc=replace(doc,search,'<section id="apStudentToolsPanel" aria-labelledby="apStudentToolsTitle" hidden><div class="ap-student-tools-heading"><h3 id="apStudentToolsTitle">Gestão dos alunos</h3><p id="apStudentToolsScope"></p></div>'+cards+'</section>'+search);
 const archived='<button type="button" data-student-category="archived"';
 const icon='<svg data-ap-menu-icon="student-tools" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="11" rx="1.5"/><rect x="14" y="3" width="7" height="6" rx="1.5"/><rect x="3" y="18" width="7" height="3" rx="1"/><rect x="14" y="13" width="7" height="8" rx="1.5"/></svg>';
 doc=replace(doc,archived,'<button type="button" data-student-category="tools" onclick="showScreen(\'students-tools\')" aria-controls="apStudentToolsPanel">'+icon+'<span>Gestão<small>6 itens</small></span></button>'+archived);
 doc=replace(doc,'let studentsArchiveView=false;','let studentsArchiveView=false;\nlet studentsToolsView=false;');
 doc=replace(doc,"(studentsArchiveView?'students-archived':studentsPendingView?'students-unassigned':'students-'+studentViewType)","(studentsToolsView?'students-tools':studentsArchiveView?'students-archived':studentsPendingView?'students-unassigned':'students-'+studentViewType)");
 doc=replace(doc,"if(screen==='students-archived'){studentsArchiveView=true;studentsPendingView=false;screen='students'}","studentsToolsView=screen==='students-tools';\n  if(studentsToolsView){studentsPendingView=false;screen='students'}\n  else if(screen==='students-archived'){studentsArchiveView=true;studentsPendingView=false;screen='students'}");
 doc=replace(doc,"button.dataset.studentCategory===(studentsArchiveView?'archived':studentViewType)","button.dataset.studentCategory===(studentsToolsView?'tools':studentsArchiveView?'archived':studentViewType)");
 doc=replace(doc,"['students-presencial','students-online','students-unassigned'].includes(requestedScreen)","['students-presencial','students-online','students-unassigned','students-tools'].includes(requestedScreen)");
 doc=replace(doc,'function renderStudents(){',`function renderStudentTools(){
  const screen=document.getElementById('screen-students'),panel=document.getElementById('apStudentToolsPanel');
  panel.hidden=!studentsToolsView;screen.classList.toggle('ap-student-tools-open',studentsToolsView);
  document.getElementById('apStudentToolsScope').textContent='Resumo: '+(studentsArchiveView?'alunos arquivados':studentViewType==='online'?'alunos online':'alunos presenciais')+'.';
}
function renderStudents(){
  renderStudentTools();`);
 // Reuse the approved material renderers with a dedicated management glyph.
 const glyph='<rect x="2" y="2" width="8" height="12" rx="1.5"/><rect x="14" y="2" width="8" height="7" rx="1.5"/><rect x="2" y="18" width="8" height="4" rx="1"/><rect x="14" y="13" width="8" height="9" rx="1.5"/>';
 for(const marker of ['data-agenda-metal-icons','data-agenda-deep-icons']){
  const s=doc.indexOf('<script '+marker),a=doc.indexOf('>',s)+1,b=doc.indexOf('</script>',a);assert.ok(s>=0&&b>a,marker);
  const body=replace(doc.slice(a,b),' function model(svg){',' solid["student-tools"]='+JSON.stringify(glyph)+';\n function model(svg){');doc=doc.slice(0,a)+body+doc.slice(b);
 }
 const css=fs.readFileSync(path.join(__dirname,'../web/student-tools.css'),'utf8');
 return doc.replace('</head>','<style id="ap-student-tools-css">'+css+'</style></head>');
};
