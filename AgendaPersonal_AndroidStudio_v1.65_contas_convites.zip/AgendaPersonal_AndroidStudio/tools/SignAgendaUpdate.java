import java.io.File;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.Arrays;
import java.util.Base64;

/** Sign a reviewed update digest with the existing Android release keystore. */
class SignAgendaUpdate {
    public static void main(String[] args) throws Exception {
        byte[] digest = System.in.readNBytes(33);
        if (digest.length != 32) throw new IllegalArgumentException("Resumo inválido.");
        char[] storePassword = required("ANDROID_KEYSTORE_PASSWORD").toCharArray();
        char[] keyPassword = required("ANDROID_KEY_PASSWORD").toCharArray();
        try {
            KeyStore store = KeyStore.getInstance(new File(required("ANDROID_KEYSTORE_PATH")), storePassword);
            String alias = required("ANDROID_KEY_ALIAS");
            PrivateKey key = (PrivateKey) store.getKey(alias, keyPassword);
            if (key == null) throw new IllegalArgumentException("Chave ausente.");
            String algorithm = switch (key.getAlgorithm()) {
                case "RSA" -> "SHA256withRSA";
                case "EC" -> "SHA256withECDSA";
                default -> throw new IllegalArgumentException("Algoritmo de chave não suportado.");
            };
            Signature signer = Signature.getInstance(algorithm);
            signer.initSign(key);
            signer.update(digest);
            System.out.println(Base64.getEncoder().encodeToString(signer.sign()));
        } finally {
            Arrays.fill(storePassword, '\0');
            Arrays.fill(keyPassword, '\0');
        }
    }

    private static String required(String name) {
        String value = System.getenv(name);
        if (value == null || value.isEmpty()) throw new IllegalArgumentException("Configuração do assinador ausente.");
        return value;
    }
}
