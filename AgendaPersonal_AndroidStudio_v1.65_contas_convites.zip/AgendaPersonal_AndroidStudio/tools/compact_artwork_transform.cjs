'use strict';
// Keep the two existing sprite layouts and their exact alpha. Only the codec
// changes; no icon is removed, recolored, moved or substituted. The logo is
// lossless RGBA, and the high-quality icon atlases retain their source size.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
module.exports=function(doc){
 const root=path.resolve(__dirname,'../web/compact-artwork'),manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json'),'utf8'));
 return doc.replace(/data:image\/(?:png|webp);base64,[A-Za-z0-9+/=]+/g,uri=>{
  if(uri.length<500000)return uri;
  const original=Buffer.from(uri.slice(uri.indexOf(',')+1),'base64'),hash=crypto.createHash('sha256').update(original).digest('hex'),entry=manifest[hash];if(!entry)return uri;
  const bytes=fs.readFileSync(path.join(root,entry.file));if(crypto.createHash('sha256').update(bytes).digest('hex')!==entry.sha256)throw Error('Compact artwork integrity failed: '+entry.file);
  return 'data:image/webp;base64,'+bytes.toString('base64');
 });
};
