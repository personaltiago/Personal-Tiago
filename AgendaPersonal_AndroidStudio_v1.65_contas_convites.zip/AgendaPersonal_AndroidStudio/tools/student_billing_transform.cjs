'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
function model(doc){
 const anchor=doc.includes('<script data-ap-student-model>')?'<script data-ap-student-model>':'<script id="ap-student-model">';assert.ok(doc.includes(anchor));
 doc=doc.replace(anchor,'<script id="ap-billing-model">'+fs.readFileSync(path.resolve(__dirname,'../web/billing-model.js'),'utf8')+'</script>'+anchor);
 const done='assertArea(area,linked||null);return area;';assert.ok(doc.includes(done));
 doc=doc.replace(done,"area.billing=APBilling.make(state,student,helpers.pixKey||'');\n  "+done);
 const count='if(count>2000||new TextEncoder()';assert.ok(doc.includes(count));
 return doc.replace(count,"if(area.billing!==undefined&&!APBilling.valid(area.billing))throw Error('Cobrança recebida inválida.');\n  "+count);
}
function teacher(doc){
 doc=model(doc);const helpers='const helpers={video:workoutExerciseVideoUrl,';assert.ok(doc.includes(helpers));
 return doc.replace(helpers,'const helpers={pixKey:PIX_KEY,video:workoutExerciseVideoUrl,');
}
function student(doc){
 doc=model(doc);
 const repaint="else if(view==='agenda')agendaRender()";assert.ok(doc.includes(repaint));doc=doc.replace(repaint,"else if(view==='payments')payRender();"+repaint);
 doc=doc.replace("for(const id of ['homeModal','bgDialog','profilePhotoDialog'","for(const id of ['payDialog','homeModal','bgDialog','profilePhotoDialog'");
 doc=doc.replace("for(const id of ['exFinishModal','profileEditor'","for(const id of ['payDialog','exFinishModal','profileEditor'");
 const css=fs.readFileSync(path.resolve(__dirname,'../web/student-billing.css'),'utf8'),js=fs.readFileSync(path.resolve(__dirname,'../web/student-billing.js'),'utf8');
 doc=doc.replace('</head>','<style id="ap-student-billing-css">'+css+'</style></head>');
 return doc.replace('</body></html>','<script id="ap-student-billing">'+js+'</script></body></html>');
}
module.exports={teacher,student};
