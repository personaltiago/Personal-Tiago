'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 const section=/<section class="home-detail-panel home-evolution-panel">[\s\S]*?<\/section>/;
 assert.ok(section.test(doc),'home assessment summary');
 doc=doc.replace(section,old=>{
  assert.ok(old.includes('72,5')&&old.includes('16,3%'),'legacy sample numbers');
  const start=old.indexOf('<div class="home-stat-grid">');assert.ok(start>0);
  return old.slice(0,start).replace("onclick=\"homeAction('Minha evolução')\"","onclick=\"openAssessments('resumo')\"")+
   '<p id="apHomeAssessmentDate" class="ap-home-assessment-date" hidden></p><div id="apHomeAssessmentSummary" class="home-stat-grid" hidden></div><p id="apHomeAssessmentEmpty" class="ap-home-assessment-empty" role="status">Sem avaliações registradas</p></section>';
 });
 doc=doc.replace('</head>','<style id="ap-home-assessments-css">.home-evolution-panel [hidden]{display:none!important}.ap-home-assessment-empty{margin:0;padding:18px 10px;border:1px solid #293947;border-radius:9px;text-align:center;color:inherit;opacity:.8;font-size:calc(13px*var(--home-scale));line-height:1.5}.ap-home-assessment-date{margin:0 0 10px;font-size:calc(11px*var(--home-scale));line-height:1.5;opacity:.75;overflow-wrap:anywhere}.home-evolution-panel .home-stat-grid em{color:inherit;opacity:.75}</style></head>');
 return doc.replace('</body></html>','<script id="ap-home-assessments">'+fs.readFileSync(path.resolve(__dirname,'../web/home-assessments.js'),'utf8')+'</script></body></html>');
};
