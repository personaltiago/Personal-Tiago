'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{minify_sync}=require('terser');
const read=n=>fs.readFileSync(path.resolve(__dirname,'../web/'+n),'utf8');
module.exports=function(doc){
 const anchor='<section id="screen-today"';assert.ok(doc.includes(anchor),'Followup screen anchor');
 doc=doc.replace(anchor,read('student-followup.html')+'\n'+anchor);
 return doc.replace('</head>','<style id="ap-followup-css">'+read('student-followup.css')+'</style></head>').replace('</body>',['student-followup-model.js','student-followup.js'].map(n=>'<script>'+minify_sync(read(n),{compress:{passes:2},mangle:true,format:{comments:false,inline_script:true}}).code+'</script>').join('')+'</body>');
};
