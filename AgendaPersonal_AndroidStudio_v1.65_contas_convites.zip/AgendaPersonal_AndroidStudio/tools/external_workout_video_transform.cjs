'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const read=name=>fs.readFileSync(path.resolve(__dirname,'../web/'+name),'utf8');
function shared(doc){return doc.replace('</head>','<script id="ap-external-video-links">'+read('external-workout-video.js')+'\n'+read('tiktok-media.js')+'</script><style id="ap-external-video-css">'+read('external-workout-video.css')+'</style></head>')}
function teacher(doc){
 const placeholder='placeholder="Cole o link do YouTube"';assert.ok(doc.includes(placeholder));doc=doc.replace(placeholder,'placeholder="Cole o link do YouTube ou TikTok"');
 for(const variable of ['video','url']){
  const link='<a class="workout-exercise-preview workout-preview-external" href="${hesc('+variable+')}" target="_blank" rel="noopener"';assert.ok(doc.includes(link));
  doc=doc.replace(link,'<button type="button" class="workout-exercise-preview workout-preview-external" data-external-video="${hesc('+variable+')}" onclick="openWorkoutExternalVideo(this.dataset.externalVideo)"');
  const end='>Abrir vídeo ↗</a>';assert.ok(doc.includes(end));doc=doc.replace(end,'>${hesc(APExternalVideo.action('+variable+'))}</button>');
 }
 doc=doc.replace('Cole o link do YouTube para assistir dentro da Agenda.','Cole o link do YouTube ou TikTok.');
 doc=doc.replace('youtube?workoutVideoThumbnail({...ex,video}', '(youtube||APExternalVideo.isTikTok(video))?workoutVideoThumbnail({...ex,video}');
 doc=doc.replace('youtube?workoutVideoThumbnail({...ex,video:url}', '(youtube||APExternalVideo.isTikTok(url))?workoutVideoThumbnail({...ex,video:url}');
 const old='const youtube=workoutYouTubeVideo(workoutExerciseVideoUrl(ex));';
 // Current source combines this declaration with the exercise lookup.
 doc=doc.replace('youtube=workoutYouTubeVideo(workoutExerciseVideoUrl(ex));if(!ex||!youtube)', 'youtube=workoutYouTubeVideo(workoutExerciseVideoUrl(ex));if(ex&&APExternalVideo.isTikTok(workoutExerciseVideoUrl(ex))){openWorkoutTikTok(workoutExerciseVideoUrl(ex),ex.name,source);return}if(!ex||!youtube)');
 doc=doc.replace('if(ex)openWorkoutYouTube(workoutYouTubeVideo(ex.video),ex.name,source)', 'if(ex){if(APExternalVideo.isTikTok(ex.video))openWorkoutTikTok(ex.video,ex.name,source);else openWorkoutYouTube(workoutYouTubeVideo(ex.video),ex.name,source)}');
 doc=doc.replace('const payload={videoId:youtube.videoId,', 'const payload={provider:youtube.provider||\'youtube\',videoId:youtube.videoId,');
 doc=doc.replace("if(typeof Android.openInlineYouTubeVideo!=='function')", "if(typeof Android[youtube.provider==='tiktok'?'openInlineTikTokVideo':'openInlineYouTubeVideo']!=='function')");
 doc=doc.replace("video.native=Android.openInlineYouTubeVideo(JSON.stringify(payload))===true", "video.native=Android[youtube.provider==='tiktok'?'openInlineTikTokVideo':'openInlineYouTubeVideo'](JSON.stringify(payload))===true");
 doc=doc.replace("'Instale o APK Android 1.31 ou mais recente para assistir nesta janela. O link continua salvo.'", "youtube.provider==='tiktok'?'Instale o APK Android 1.117 para assistir ao TikTok nesta janela. O link continua salvo.':'Instale o APK Android 1.31 ou mais recente para assistir nesta janela. O link continua salvo.'");
 doc=doc.replace("frame.src='https://www.youtube.com/embed/'+youtube.videoId+", "frame.src=youtube.provider==='tiktok'?APTikTok.frameUrl(youtube.videoId):'https://www.youtube.com/embed/'+youtube.videoId+");
 doc=doc.replace("video.frame.contentWindow.postMessage(JSON.stringify({event:'command',func:'pauseVideo',args:[]}),'https://www.youtube.com')", "video.frame.contentWindow.postMessage(video.youtube.provider==='tiktok'?{type:'pause','x-tiktok-player':true}:JSON.stringify({event:'command',func:'pauseVideo',args:[]}),video.youtube.provider==='tiktok'?'https://www.tiktok.com':'https://www.youtube.com')");
 doc=doc.replace("document.getElementById('workoutVideoExternal').hidden=true;workoutVideoUrl=youtube.url;", "document.getElementById('workoutVideoExternal').hidden=true;document.getElementById('workoutVideoExternal').textContent=youtube.provider==='tiktok'?'Abrir no TikTok':'Abrir no YouTube';workoutVideoUrl=youtube.url;");
 doc=doc.replace("function openWorkoutVideoExternally(){if(workoutVideoUrl)window.open(workoutVideoUrl,'_blank','noopener')}","function openWorkoutVideoExternally(){if(workoutVideoUrl)APExternalVideo.open(workoutVideoUrl)}");

 return shared(doc).replace('</body>','<script id="ap-teacher-external-video">'+read('teacher-external-video.js')+'</script></body>');
}
module.exports={teacher,student:shared};
