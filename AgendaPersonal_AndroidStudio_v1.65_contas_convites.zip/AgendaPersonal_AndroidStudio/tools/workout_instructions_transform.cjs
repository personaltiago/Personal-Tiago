'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
module.exports=function(doc){
 assert.ok(doc.includes('function workoutExerciseCard(')&&doc.includes('function updateWorkoutExerciseCompletion('),'workout instruction anchors');
 const read=n=>fs.readFileSync(path.join(__dirname,'../web',n),'utf8');
 return doc.replace('</head>','<style id="ap-workout-instructions-css">'+read('workout-instructions.css')+'</style></head>').replace('</body>','<script id="ap-workout-instructions">'+read('workout-instructions.js')+'</script></body>');
};
