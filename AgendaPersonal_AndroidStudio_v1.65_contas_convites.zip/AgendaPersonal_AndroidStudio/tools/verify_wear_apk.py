"""Inspect the watch APK and verify both APKs share their package and signing certificate."""
from pathlib import Path
import re
import subprocess
from zipfile import ZipFile
from verify_apk import locate_aapt


def verify_wear(watch, phone, sdk, release, expected_code):
    aapt = locate_aapt(sdk)
    if not aapt:
        raise RuntimeError('aapt não encontrado.')
    output = subprocess.check_output([str(aapt), 'dump', 'badging', str(watch)], text=True)
    match = re.search(r"^package: name='([^']+)' versionCode='(\d+)' versionName='([^']+)'", output, re.M)
    if not match or match.groups() != (release['applicationId'], str(expected_code), release['androidVersion']):
        raise RuntimeError('Versão ou identidade do APK Wear OS incorreta.')
    manifest = subprocess.check_output([str(aapt), 'dump', 'xmltree', str(watch), 'AndroidManifest.xml'], text=True)
    for required in ['android.hardware.type.watch', 'WatchActivity', 'WatchDataService', 'WorkoutService', 'com.google.android.wearable.standalone']:
        if required not in manifest:
            raise RuntimeError('APK Wear OS incompleto: '+required)
    with ZipFile(watch) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('APK Wear OS corrompido.')
    signer = Path(aapt).with_name('apksigner')
    def certificate(apk):
        text = subprocess.check_output([str(signer), 'verify', '--print-certs', str(apk)], text=True)
        found = re.findall(r'Signer #\d+ certificate SHA-256 digest: (\w+)', text)
        if not found:
            raise RuntimeError('Assinatura não encontrada no APK.')
        return sorted(found)
    if certificate(watch) != certificate(phone):
        raise RuntimeError('Celular e relógio precisam da mesma assinatura. Compile ambos no mesmo Codespaces/keystore.')
    print('Wear OS: pacote, versão, manifesto, integridade e mesma assinatura do celular conferidos.')
