"""One source inventory shared by the release manifest and the browser-upload ZIP."""
from pathlib import Path
import os

PAGES = {f'app/src/main/assets/{name}.html' for name in ('index', 'professor', 'avaliacoes', 'cadastro')}
EXCLUDED_DIRS = {'.git', '.gradle', 'node_modules', '__pycache__', 'build', '.idea'}
EXCLUDED_FILES = {'.agenda-assets-build.json', '.agenda-assets-build.json.partial', 'agenda-build.json', 'agenda-build.json.partial', 'local.properties'}

def source_files(root):
    root = Path(root)
    for directory, folders, files in os.walk(root):
        folders[:] = sorted(f for f in folders if f not in EXCLUDED_DIRS)
        for name in sorted(files):
            source = Path(directory) / name
            relative = source.relative_to(root).as_posix()
            if relative.startswith('tests/reports/') or '/' not in relative and name.startswith('VERIFICACAO_'):
                continue
            if name in EXCLUDED_FILES or relative in PAGES or name.endswith(('.tmp', '.swp', '.swo', '.bak', '.orig', '.rej')):
                continue
            if relative.startswith('app/src/main/assets/') and relative not in {'app/src/main/assets/icon.png', 'app/src/main/assets/update-catalog.js'}:
                continue
            if source.is_symlink():
                raise ValueError('Arquivo com vínculo não suportado: ' + relative)
            yield relative, source
