'use strict';
// Shared screen treatment. Explicit component lists keep reports, photos, media,
// theme samples and student-owned appearance outside the teacher preference.
module.exports=function(){
 const cards=[
  '.wl-open','.wl-agenda-tools .agenda-availability-link','.wl-panel','.wl-entry','.home-quick','.home-card','.home-row','.home-upcoming-row','.home-category','.home-finance-stat','.home-tip',
  '.more-identity','.more-pending','.more-pending-link','.more-history-box','.more-history-row',
  '.summary .box','.lesson','.day-card','.student','.student-stat','.action-tile',
  '.availability-card','.availability-setup','.availability-week-day','.automatic-availability-day','.compact-availability-day',
  '#financeWallet','#financeResults','.finance-summary .box','.finance-card',
  '.workout-summary>div','.workout-student-choice','.workout-plan-card','.workout-day-card',
  '.workout-sheet-day','.workout-archived-card','.workout-catalog-card','.workout-log',
  '.workout-progress-overview','.workout-progress-summary>div','.workout-progress-chart-card',
  '.profile-action-card','.profile-section','.profile-metric','.profile-assessment-record',
  '.alarm-tools','.teacher-text-setting','.sound-choice-group','.update-tools','.notice-update','.history-row','.teacher-sync-card',
  '.dashboard .offline-backup','.dashboard .schedule-panel','.dashboard .client-index','.dashboard .client-detail',
  '.dashboard .assessment-card','.dashboard .client-button','.dashboard .profile-summary>div','.dashboard .profile-note',
  '.workspace .card','.workspace .live-card'
 ];
 const list=':is('+cards.join(',')+')',scope='html:root[data-agenda-card-style="colored"] body '+list;
 const neutral=[
  'button:not(:where('+cards.join(',')+'))','.btn:not(:where('+cards.join(',')+'))','.iconbtn','input','select','textarea',
  '.more-pending-count','.agenda-lesson-reminder','.agenda-week-avatar','.student-avatar','.student-options summary','.detail-monogram','.section-num','.field','.badge','.home-status','.student-chip','.finance-state','.meta','.lesson-timer','.agenda-timer-pill',
  '.fr-chart','.fr-cards>div','.fr-legend','.finance-wallet-warning','.ap-mascot-speech',
  '.workout-exercise','.workout-guidance','.workout-prescription>div','.workout-detail-grid>div',
  '.workout-plan-selector','.workout-plan-chooser','.workout-plan-option-actions','.workout-day-menu-items',
  '.workout-progress-table-scroll','.workout-reference-note','.workout-session',
  '.availability-row','.automatic-availability-block','.compact-availability-busy','.compact-availability-free',
  '.profile-note textarea','.goal-projection','.reference-weight-output','.sum-strip',
  '.wl-offer','.goal-auto-status','.goal-guidance','.photo-preview','.photo-picker','.error-box','.alert-box','.receipt-warning','.receipt-error'
 ];
 const inset=':where('+neutral.join(',')+')';
 const icons=':is(.wl-shortcut-icon,.home-quick-icon,.home-heading-icon,.home-info-icon,.more-pending-bell,.more-pending-icon,.dashboard-icon,.profile-action-icon,.pro-menu-icon)';
 const good=':is(.badge.good,.home-status.done,.home-status.confirmed,.student-chip.finance-ok,.student-chip.finance-soon,.finance-card.ok .finance-state,.availability-status.free,.btn.good)';
 const warn=':is(.badge.warn,.home-status.soon,.student-chip.finance-today,.finance-card.today .finance-state,.availability-status.busy,.finance-card.soon .finance-state,.btn.warn)';
 const danger=':is(.badge.danger,.home-status.cancelled,.student-chip.finance-overdue,.finance-card.overdue .finance-state,.btn.danger,.btn.soft-danger)';
 const rules=[];
 function add(selector,body){rules.push(selector+'{'+body+'}')}
 add(scope,'background:var(--ac-primary-fill,#8715bb)!important;border-color:var(--ac-on-primary,#fff)!important;color:var(--ac-on-primary,#fff)!important;box-shadow:inset 0 1px 0 #ffffff24,0 2px 7px #00000029;transition:none');
 add(scope+' :where(*)','color:var(--ac-on-primary,#fff)!important');
 // Controls and inset data keep their own surface so editing and status colors
 // remain readable. A card that is itself a button stays colored.
 add(scope+' '+inset,'color:var(--ac-text,#f5f3f7)!important;background:var(--ac-field,#131118)!important;border-color:var(--ac-line,#44364e)!important');
 add(scope+' '+inset+' :where(*)','color:var(--ac-text,#f5f3f7)!important');
 add(scope+' :is(input,select,textarea)','caret-color:var(--ac-text,#f5f3f7);accent-color:var(--ac-accent,#c596fa)');
 add(scope+' :is(input,textarea)::placeholder','color:var(--ac-muted,#b8b1bf)!important;opacity:1');
 // Matte/theme icon renderers still own the actual material and hue.
 add(scope+' '+icons,'display:inline-flex;align-items:center;justify-content:center;background:var(--ac-field,#131118)!important;color:var(--ac-accent,#c596fa)!important;border:1px solid var(--ac-line,#44364e);border-radius:12px;padding:8px;box-sizing:content-box;flex-shrink:0');
 add(scope+' '+icons+' :where(*)','color:var(--ac-accent,#c596fa)!important');
 add(scope+' button.home-section-link','background:transparent!important;color:var(--ac-on-primary,#fff)!important;border-color:transparent!important');
 add(scope+' button.home-section-link :where(*)','color:var(--ac-on-primary,#fff)!important');
 add(scope+' :is(.home-chevron,.more-stat-chevron)','background:var(--ac-field,#131118)!important;color:var(--ac-text,#f5f3f7)!important');
 add(scope+' :is(.home-chevron,.more-stat-chevron) :where(*)','color:var(--ac-text,#f5f3f7)!important');
 add(scope+' .home-section-link .home-chevron, '+scope+' .home-section-link .home-chevron :where(*)','color:var(--ac-text,#f5f3f7)!important');
 add(scope+' .ap-mascot-speech','background:#faf7ef!important;color:#302c32!important');
 add(scope+' .ap-mascot-speech :where(*)','color:#302c32!important');
 add(scope+' '+good,'color:var(--ac-good,#65d5ad)!important;background:var(--ac-field,#131118)!important;border-color:currentColor!important');
 add(scope+' '+warn,'color:var(--ac-warn,#eeb66c)!important;background:var(--ac-field,#131118)!important;border-color:currentColor!important');
 add(scope+' '+danger,'color:var(--ac-danger,#fa839c)!important;background:var(--ac-field,#131118)!important;border-color:currentColor!important');
 // Annual/monthly totals retain green/red cash-flow meaning on inset surfaces.
 add(scope+' :is(.fr-income,.fr-profit,.fr-legend span:first-child)','color:var(--green,#67d5af)!important');
 add(scope+' :is(.fr-cost,.fr-legend span:last-child)','color:var(--red,#fa839c)!important');
 add(scope+' :is(button,a,summary,input,select,textarea):focus-visible','outline:2px solid var(--ac-on-primary,#fff)!important;outline-offset:3px');
 return '@media screen{'+rules.join('\n')+'}';
};
