#!/usr/bin/env bash
set -euo pipefail
AGENDA_WATCH_PROJECT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$AGENDA_WATCH_PROJECT/COMPILAR_NO_CODESPACES.sh" --with-watch "$@"
