# Cadastro por link: sessão compartilhada

O painel de Contatos usa o serviço de consulta e aprovação da sessão principal.
Abrir essa aba não inicializa outro Firebase Auth nem modifica a persistência
escolhida no acesso do professor.

O serviço verifica a conta do professor antes e depois das consultas e aprovações.
Uma resposta recebida depois de sair ou trocar de conta é descartada. Falhas de
consulta permitem tentar novamente na mesma tela.

O formulário independente mantém suporte próprio, usando a mesma ordem de
persistência da entrada. Um painel incorporado nunca usa essa alternativa.

## Verificações

- Navegador com Firebase Auth e armazenamento reais, identidade e rede simuladas.
- Acesso salvo, reabertura e acesso sem salvar a sessão.
- Consulta, atualização da lista, abertura do aluno e aprovação única.
- Falha de rede, nova tentativa e saída enquanto uma consulta está pendente.
- Preservação do aluno existente e dos seus dados administrativos.
- Editor do link, foto de cadastro e regras de importação.

O mesmo teste cobre as telas geradas do projeto e o pacote de conteúdo entregue.
Não foram feitos acessos a contas reais, aprovações reais ou testes em celular.

O pacote de conteúdo 1.12.185, sequência 291, preserva as outras três telas e
altera somente o módulo de cadastro por link na tela do professor em relação à
1.12.184. O projeto Android mantém sua identificação nativa e a política de
preservar uma versão de conteúdo já instalada com sequência superior à base.
