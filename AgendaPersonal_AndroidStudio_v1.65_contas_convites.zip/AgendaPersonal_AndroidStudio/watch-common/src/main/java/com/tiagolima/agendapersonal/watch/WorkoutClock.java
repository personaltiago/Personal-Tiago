package com.tiagolima.agendapersonal.watch;

/** Uses elapsedRealtime, never wall time, for elapsed time and rest. */
public final class WorkoutClock {
    public int completed;
    public boolean started, paused;
    public long accumulated, anchor, restUntil, pausedRest;
    public void start(long now) { if(started)return;started=true;anchor=now; }
    public long elapsed(long now){return accumulated+(started&&!paused?Math.max(0,now-anchor):0);}
    public long rest(long now){return paused?pausedRest:Math.max(0,restUntil-now);}
    public boolean complete(long now,int seconds,int total){
        if(!started||paused||completed>=total||rest(now)>0)return false;
        completed++;restUntil=completed<total?now+Math.max(0,seconds)*1000L:0;return true;
    }
    public void pause(long now){if(!started||paused)return;accumulated=elapsed(now);pausedRest=rest(now);restUntil=0;paused=true;}
    public void resume(long now){if(!started||!paused)return;anchor=now;restUntil=pausedRest>0?now+pausedRest:0;pausedRest=0;paused=false;}
    public void skipRest(){restUntil=0;pausedRest=0;}
}
