package com.tiagolima.agendapersonal.watch;

import org.json.*;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;

/** Bounded, versioned prescription; never includes contacts, credentials or photos. */
public final class WatchContract {
    public static final String WORKOUT = "/agenda/v1/workout", RECEIPT = "/agenda/v1/receipt", RESULT = "/agenda/v1/result/";
    public static JSONObject parse(String raw) throws JSONException {
        if (raw == null || raw.getBytes(StandardCharsets.UTF_8).length > 180000) throw new JSONException("Treino muito grande para o relógio.");
        JSONObject p = new JSONObject(raw);
        if (p.getInt("v") != 1 || !p.getString("token").matches("[A-Za-z0-9-]{1,80}")) throw new JSONException("Versão inválida.");
        if (p.optBoolean("revoked")) return p;
        if (!p.optString("role").matches("teacher|student") || p.optString("owner").isEmpty()) throw new JSONException("Entre na sua conta.");
        text(p,"label",200); text(p,"person",120); text(p,"workoutId",400);
        JSONArray ex = p.getJSONArray("exercises"), steps = p.getJSONArray("steps");
        if (ex.length()<1 || ex.length()>80 || steps.length()<1 || steps.length()>2400) throw new JSONException("Divida este treino em dias menores.");
        HashSet<String> ids=new HashSet<>(), expected=new HashSet<>();
        for (int i=0;i<ex.length();i++) {
            JSONObject e=ex.getJSONObject(i); text(e,"id",200);text(e,"name",160);
            if (!ids.add(e.getString("id"))) throw new JSONException("Exercício repetido.");
            JSONArray rows=e.getJSONArray("rows");
            if(rows.length()<1 || rows.length()>30) throw new JSONException("Use de 1 a 30 séries por exercício no relógio.");
            for(int n=0;n<rows.length();n++){JSONObject row=rows.getJSONObject(n);text(row,"reps",500);if(row.optString("load").length()>80)throw new JSONException("Carga inválida.");expected.add(i+":"+n);}
        }
        for(int i=0;i<steps.length();i++) {
            JSONObject s=steps.getJSONObject(i);int e=s.getInt("e"),n=s.getInt("set"),rest=s.getInt("rest");
            if(!expected.remove(e+":"+n)||rest<0||rest>1800) throw new JSONException("Ordem de séries inválida.");
        }
        if(!expected.isEmpty())throw new JSONException("Faltam séries na sequência.");
        return p;
    }
    private static void text(JSONObject p,String k,int max)throws JSONException{String s=p.getString(k);if(s.trim().isEmpty()||s.length()>max)throw new JSONException("Campo inválido: "+k);}
    private WatchContract() {}
}
