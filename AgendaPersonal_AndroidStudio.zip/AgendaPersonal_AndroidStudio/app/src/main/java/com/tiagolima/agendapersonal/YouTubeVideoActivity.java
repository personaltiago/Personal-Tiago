package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

/** Plays YouTube separately from the local agenda and its privileged bridge. */
public final class YouTubeVideoActivity extends Activity {
    private WebView player;
    private FrameLayout root;
    private LinearLayout content;
    private View fullScreenVideo;
    private WebChromeClient.CustomViewCallback fullScreenCallback;
    private String videoId;
    private int startSeconds;

    static void open(Activity activity, String videoId, int startSeconds, String title) {
        if (!YouTubePlayerPage.validVideoId(videoId) || startSeconds < 0) throw new IllegalArgumentException("Vídeo inválido");
        activity.runOnUiThread(() -> {
            try {
                Intent intent = new Intent(activity, YouTubeVideoActivity.class);
                intent.putExtra("videoId", videoId);
                intent.putExtra("startSeconds", startSeconds);
                intent.putExtra("title", title == null ? "Vídeo do exercício" : title.substring(0, Math.min(title.length(), 180)));
                activity.startActivity(intent);
            } catch (Exception error) {
                Toast.makeText(activity, "Não foi possível abrir o vídeo.", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        videoId = getIntent().getStringExtra("videoId");
        startSeconds = getIntent().getIntExtra("startSeconds", 0);
        if (!YouTubePlayerPage.validVideoId(videoId) || startSeconds < 0) { finish(); return; }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0b0a0f"));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        AppWindowLayout.apply(this, root);

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setPadding(dp(14), dp(10), dp(14), dp(10));
        Button close = button("Fechar");
        close.setContentDescription("Fechar vídeo e voltar ao treino");
        close.setOnClickListener(view -> finish());
        heading.addView(close, new LinearLayout.LayoutParams(dp(84), dp(48)));
        TextView title = new TextView(this);
        title.setText(getIntent().getStringExtra("title"));
        title.setTextColor(Color.parseColor("#f7f4fa"));
        title.setTextSize(18);
        title.setTypeface(null, Typeface.BOLD);
        title.setMaxLines(2);
        title.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleLayout = new LinearLayout.LayoutParams(0, -2, 1);
        titleLayout.leftMargin = dp(12);
        heading.addView(title, titleLayout);
        content.addView(heading, new LinearLayout.LayoutParams(-1, -2));

        player = new WebView(this);
        player.setBackgroundColor(Color.parseColor("#0b0a0f"));
        WebSettings settings = player.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        // No JavaScript interface is attached to this remote-content WebView.
        player.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                Uri uri = request.getUrl();
                if (request.hasGesture() && isYouTubeLink(uri)) openExternal(uri);
                return true;
            }
        });
        player.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullScreenVideo != null) { callback.onCustomViewHidden(); return; }
                fullScreenVideo = view;
                fullScreenCallback = callback;
                content.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
                WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), root);
                controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                controller.hide(WindowInsetsCompat.Type.systemBars());
            }
            @Override public void onHideCustomView() { hideFullScreenVideo(); }
        });
        content.addView(player, new LinearLayout.LayoutParams(-1, 0, 1));
        Button external = button("Abrir no YouTube");
        external.setOnClickListener(view -> openExternal(Uri.parse("https://www.youtube.com/watch?v=" + videoId
                + (startSeconds > 0 ? "&t=" + startSeconds + "s" : ""))));
        LinearLayout.LayoutParams externalLayout = new LinearLayout.LayoutParams(-1, dp(48));
        externalLayout.setMargins(dp(14), dp(10), dp(14), dp(14));
        content.addView(external, externalLayout);

        String origin = YouTubePlayerPage.origin(getPackageName());
        player.loadDataWithBaseURL(origin + "/", YouTubePlayerPage.html(videoId, startSeconds, getPackageName()), "text/html", "UTF-8", null);
    }

    private Button button(String text) {
        Button result = new Button(this);
        result.setText(text);
        result.setAllCaps(false);
        result.setTextSize(15);
        result.setTextColor(Color.parseColor("#ead3fa"));
        result.setMinHeight(dp(48));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor("#23152d"));
        background.setStroke(dp(1), Color.parseColor("#633c79"));
        background.setCornerRadius(dp(11));
        result.setBackground(background);
        return result;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private boolean isYouTubeLink(Uri uri) {
        if (!"https".equals(uri.getScheme()) || uri.getHost() == null) return false;
        String host = uri.getHost();
        return host.equals("youtube.com") || host.endsWith(".youtube.com") || host.equals("youtu.be") || host.equals("www.youtu.be");
    }

    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (Exception error) { Toast.makeText(this, "Não foi possível abrir o YouTube.", Toast.LENGTH_LONG).show(); }
    }

    private void hideFullScreenVideo() {
        if (fullScreenVideo == null) return;
        root.removeView(fullScreenVideo);
        fullScreenVideo = null;
        content.setVisibility(View.VISIBLE);
        WindowCompat.getInsetsController(getWindow(), root).show(WindowInsetsCompat.Type.systemBars());
        WebChromeClient.CustomViewCallback callback = fullScreenCallback;
        fullScreenCallback = null;
        if (callback != null) callback.onCustomViewHidden();
    }

    @Override public void onBackPressed() {
        if (fullScreenVideo != null) hideFullScreenVideo();
        else finish();
    }

    @Override protected void onPause() {
        if (player != null) { player.evaluateJavascript("if(typeof pauseWorkoutVideo==='function')pauseWorkoutVideo();", null); player.onPause(); }
        super.onPause();
    }

    @Override protected void onResume() { super.onResume(); if (player != null) player.onResume(); }

    @Override protected void onDestroy() {
        hideFullScreenVideo();
        if (player != null) {
            player.stopLoading();
            player.loadUrl("about:blank");
            ((ViewGroup) player.getParent()).removeView(player);
            player.destroy();
            player = null;
        }
        super.onDestroy();
    }
}
