package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import org.json.JSONObject;

/** An isolated player placed inside the exercise card, with no privileged bridge. */
final class InlineYouTubePlayer {
    private final Activity activity;
    private final FrameLayout root;
    private final WebView agenda;
    private FrameLayout surface;
    private WebView player;
    private String key = "";
    private boolean shown;
    private View fullScreenVideo;
    private WebChromeClient.CustomViewCallback fullScreenCallback;

    InlineYouTubePlayer(Activity activity, FrameLayout root, WebView agenda) {
        this.activity = activity; this.root = root; this.agenda = agenda;
    }

    static void validate(JSONObject request) throws Exception {
        if (!YouTubePlayerPage.validVideoId(request.optString("videoId")) || request.optInt("startSeconds", -1) < 0
                || !validKey(request.optString("key"))) throw new IllegalArgumentException("Vídeo inválido");
        placement(request.getJSONObject("bounds"), 1000, 2000);
    }

    private static boolean validKey(String value) {
        return value != null && value.matches("[A-Za-z0-9_-]{1,100}");
    }

    private static InlineVideoPlacement placement(JSONObject bounds, int width, int height) throws Exception {
        return InlineVideoPlacement.calculate(bounds.getDouble("viewportWidth"), bounds.getDouble("viewportHeight"),
                bounds.getDouble("left"), bounds.getDouble("top"), bounds.getDouble("width"), bounds.getDouble("height"),
                bounds.getDouble("clipTop"), bounds.getDouble("clipBottom"), bounds.optBoolean("visible"), width, height);
    }

    void open(JSONObject request) {
        activity.runOnUiThread(() -> {
            String nextKey = request.optString("key");
            try {
                validate(request); close(); key = nextKey;
                surface = new FrameLayout(activity);
                surface.setClipChildren(true);
                surface.setBackgroundColor(Color.BLACK);
                player = new WebView(activity);
                player.setBackgroundColor(Color.BLACK);
                WebSettings settings = player.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setDomStorageEnabled(true);
                settings.setMediaPlaybackRequiresUserGesture(false);
                settings.setAllowFileAccess(false);
                settings.setAllowContentAccess(false);
                settings.setAllowFileAccessFromFileURLs(false);
                settings.setAllowUniversalAccessFromFileURLs(false);
                settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
                settings.setSafeBrowsingEnabled(true);
                // Remote scripts and the YouTube iframe receive no Android JavaScript interface.
                player.setWebViewClient(new WebViewClient() {
                    @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        if (!request.isForMainFrame()) return false;
                        Uri uri = request.getUrl();
                        String host = uri.getHost();
                        if (request.hasGesture() && "https".equals(uri.getScheme()) && host != null
                                && (host.equals("youtube.com") || host.endsWith(".youtube.com") || host.equals("youtu.be"))) {
                            try { activity.startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                            catch (Exception error) { Toast.makeText(activity, "Não foi possível abrir o YouTube.", Toast.LENGTH_SHORT).show(); }
                        }
                        return true;
                    }
                });
                player.setWebChromeClient(new WebChromeClient() {
                    @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                        if (fullScreenVideo != null || player == null) { callback.onCustomViewHidden(); return; }
                        fullScreenVideo = view; fullScreenCallback = callback;
                        surface.setVisibility(View.GONE);
                        root.addView(view, new FrameLayout.LayoutParams(-1, -1));
                        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(activity.getWindow(), root);
                        controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        controller.hide(WindowInsetsCompat.Type.systemBars());
                    }
                    @Override public void onHideCustomView() { leaveFullScreen(); }
                });
                surface.addView(player, new FrameLayout.LayoutParams(-1, -1));
                root.addView(surface, new FrameLayout.LayoutParams(1, 1));
                positionNow(request.getJSONObject("bounds"));
                String origin = YouTubePlayerPage.origin(activity.getPackageName());
                InlineVideoPlacement initial = placement(request.getJSONObject("bounds"), agenda.getWidth(), agenda.getHeight());
                String html = YouTubePlayerPage.inlineHtml(request.getString("videoId"), request.getInt("startSeconds"), activity.getPackageName());
                if (!initial.visible || initial.height * 2 <= initial.playerHeight) html = html.replace("autoplay:1", "autoplay:0");
                player.loadDataWithBaseURL(origin + "/", html, "text/html", "UTF-8", null);
            } catch (Exception error) {
                close(); agenda.evaluateJavascript("if(typeof workoutInlineVideoError==='function')workoutInlineVideoError(" + JSONObject.quote(nextKey) + ");", null);
            }
        });
    }

    void position(String requestKey, JSONObject bounds) {
        activity.runOnUiThread(() -> {
            if (!key.equals(requestKey) || player == null) return;
            try { positionNow(bounds); } catch (Exception error) { close(); }
        });
    }

    private void positionNow(JSONObject bounds) throws Exception {
        InlineVideoPlacement box = placement(bounds, agenda.getWidth(), agenda.getHeight());
        if (!box.visible) {
            if (shown) pause(); shown = false; surface.setVisibility(View.GONE); return;
        }
        FrameLayout.LayoutParams frame = new FrameLayout.LayoutParams(box.width, box.height);
        frame.leftMargin = box.left; frame.topMargin = box.top;
        surface.setLayoutParams(frame);
        FrameLayout.LayoutParams video = new FrameLayout.LayoutParams(box.width, box.playerHeight);
        video.topMargin = box.playerTop;
        player.setLayoutParams(video);
        if (fullScreenVideo == null) surface.setVisibility(View.VISIBLE);
        shown = true;
    }

    boolean isActive() { return player != null; }

    boolean leaveFullScreen() {
        if (fullScreenVideo == null) return false;
        root.removeView(fullScreenVideo); fullScreenVideo = null;
        if (surface != null) surface.setVisibility(shown ? View.VISIBLE : View.GONE);
        WindowCompat.getInsetsController(activity.getWindow(), root).show(WindowInsetsCompat.Type.systemBars());
        WebChromeClient.CustomViewCallback callback = fullScreenCallback; fullScreenCallback = null;
        if (callback != null) callback.onCustomViewHidden();
        return true;
    }

    void pause() { if (player != null) player.evaluateJavascript("if(typeof pauseWorkoutVideo==='function')pauseWorkoutVideo();", null); }
    void onPause() { pause(); if (player != null) player.onPause(); }
    void onResume() { if (player != null) player.onResume(); }
    void close(String requestKey) { activity.runOnUiThread(() -> { if (key.equals(requestKey)) close(); }); }

    void close() {
        leaveFullScreen();
        if (player != null) {
            player.stopLoading(); player.loadUrl("about:blank");
            surface.removeView(player); player.destroy(); player = null;
        }
        if (surface != null) { root.removeView(surface); surface = null; }
        shown = false; key = "";
    }
}
