package com.tiagolima.agendapersonal;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import org.json.JSONObject;
import java.io.OutputStream;
import java.security.MessageDigest;

final class AudioSettings {
    private static final String PREFS = "agenda_personal_audio_v1";
    private static final int MAX_BYTES = 8 * 1024 * 1024;

    private AudioSettings() {}

    static String lessonChannelId(Context context) {
        return channelId(context, "lesson", AlarmReceiver.CHANNEL_ID);
    }

    static String timerChannelId(Context context) {
        return channelId(context, "timer", AlarmReceiver.TIMER_CHANNEL_ID);
    }

    static Uri lessonSound(Context context) {
        return soundUri(context, "lesson");
    }

    static Uri timerSound(Context context) {
        return soundUri(context, "timer");
    }

    static JSONObject status(Context context) {
        JSONObject out = new JSONObject();
        try {
            out.put("lessonName", prefs(context).getString("lesson_name", ""));
            out.put("timerName", prefs(context).getString("timer_name", ""));
        } catch (Exception ignored) {}
        return out;
    }

    static synchronized JSONObject saveBase64(Context context, String kind, String fileName, String mimeType,
                                              String base64) throws Exception {
        if (!"lesson".equals(kind) && !"timer".equals(kind)) throw new IllegalArgumentException("Tipo de áudio inválido.");
        String clean = base64 == null ? "" : base64.replaceAll("\\s", "");
        byte[] bytes = Base64.decode(clean, Base64.DEFAULT);
        if (bytes.length == 0 || bytes.length > MAX_BYTES) throw new IllegalArgumentException("Use um áudio de até 8 MB.");
        String safeName = sanitize(fileName);
        String mime = validMime(mimeType) ? mimeType : "audio/mpeg";
        String digest = sha(bytes);
        Uri uri = saveToMediaStore(context, kind, safeName, mime, bytes);
        if (uri == null) throw new IllegalStateException("Não foi possível salvar o áudio.");
        SharedPreferences.Editor edit = prefs(context).edit()
                .putString(kind + "_uri", uri.toString())
                .putString(kind + "_name", safeName)
                .putString(kind + "_hash", digest)
                .putLong(kind + "_version", System.currentTimeMillis());
        if (!edit.commit()) throw new IllegalStateException("Não foi possível guardar o áudio.");
        return status(context);
    }

    private static String channelId(Context context, String kind, String base) {
        SharedPreferences prefs = prefs(context);
        String hash = prefs.getString(kind + "_hash", "");
        long version = prefs.getLong(kind + "_version", 0L);
        if (hash.isEmpty() || version <= 0L || prefs.getString(kind + "_uri", "").isEmpty()) return base;
        return base + "_custom_" + Math.abs((hash + version).hashCode());
    }

    private static Uri soundUri(Context context, String kind) {
        String value = prefs(context).getString(kind + "_uri", "");
        if (value.isEmpty()) return null;
        try { return Uri.parse(value); }
        catch (Exception e) { return null; }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static Uri saveToMediaStore(Context context, String kind, String fileName, String mime,
                                        byte[] bytes) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Audio.Media.DISPLAY_NAME, "agenda_personal_" + kind + "_" + System.currentTimeMillis() + "_" + fileName);
        values.put(MediaStore.Audio.Media.MIME_TYPE, mime);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_NOTIFICATIONS + "/Agenda Personal");
            values.put(MediaStore.Audio.Media.IS_PENDING, 1);
        }
        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Uri uri = context.getContentResolver().insert(collection, values);
        if (uri == null) return null;
        try (OutputStream out = context.getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("Destino indisponível");
            out.write(bytes);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
            context.getContentResolver().update(uri, done, null, null);
        }
        return uri;
    }

    private static boolean validMime(String mime) {
        return mime != null && (mime.equals("audio/mpeg") || mime.equals("audio/mp4")
                || mime.equals("audio/aac") || mime.equals("audio/ogg")
                || mime.equals("audio/wav") || mime.equals("audio/x-wav")
                || mime.startsWith("audio/"));
    }

    private static String sanitize(String name) {
        String clean = name == null ? "audio.mp3" : name.replaceAll("[^A-Za-z0-9._-]", "_");
        if (clean.length() > 80) clean = clean.substring(clean.length() - 80);
        return clean.isEmpty() ? "audio.mp3" : clean;
    }

    private static String sha(byte[] bytes) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
        StringBuilder out = new StringBuilder();
        for (byte b : digest) out.append(String.format("%02x", b));
        return out.toString();
    }
}
