package com.tiagolima.agendapersonal;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Toast;
import org.json.JSONObject;
import java.text.DateFormat;
import java.util.Date;

/** Verificação de permissões e som, sem alterar as preferências do aparelho. */
final class AlarmStatus {
    private AlarmStatus() {}

    static boolean exactAllowed(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms());
    }

    static boolean notificationsAllowed(Context context, String channelId) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || !nm.areNotificationsEnabled()) return false;
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
        NotificationChannel channel = nm.getNotificationChannel(channelId);
        return channel != null && channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
    }

    static String soundIssue(Context context) {
        String channelId = AudioSettings.lessonChannelId(context);
        if (!notificationsAllowed(context, channelId)) return "Ative as notificações das aulas.";
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = nm.getNotificationChannel(channelId);
        if (channel.getImportance() < NotificationManager.IMPORTANCE_DEFAULT) return "Ative o som em Alarmes das aulas.";
        if (channel.getSound() == null) return "Escolha um som em Alarmes das aulas.";
        if (Settings.System.DEFAULT_ALARM_ALERT_URI.equals(channel.getSound())
                && RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_ALARM) == null) {
            return "Escolha um som para o alarme nas configurações do celular.";
        }
        AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (audio == null || audio.getStreamVolume(AudioManager.STREAM_ALARM) == 0) return "Aumente o volume dos alarmes.";
        if (nm.getCurrentInterruptionFilter() == NotificationManager.INTERRUPTION_FILTER_NONE
                && !channel.canBypassDnd()) return "O modo Não perturbe está bloqueando os alarmes.";
        return "";
    }

    static String issue(Context context) {
        if (!exactAllowed(context)) return "Autorize Alarmes e lembretes para tocar no horário.";
        return soundIssue(context);
    }

    static JSONObject inspect(Context context) {
        JSONObject result = new JSONObject();
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            AlarmReceiver.createChannel(context);
            AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            int max = audio == null ? 0 : audio.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            int volume = audio == null ? 0 : audio.getStreamVolume(AudioManager.STREAM_ALARM);
            PowerManager power = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            long next = Long.MAX_VALUE;
            int lessons = 0;
            for (JSONObject plan : AlarmStore.plans(context)) {
                if (!"lesson".equals(plan.optString("kind"))) continue;
                lessons++;
                long at = plan.optLong("triggerAtMillis");
                if (at > System.currentTimeMillis() && at < next) next = at;
            }
            String issue = issue(context);
            result.put("ready", issue.isEmpty()).put("issue", issue)
                    .put("exactAllowed", exactAllowed(context))
                    .put("notificationsAllowed", notificationsAllowed(context, AudioSettings.lessonChannelId(context)))
                    .put("lessonSoundName", AudioSettings.status(context).optString("lessonName"))
                    .put("timerSoundName", AudioSettings.status(context).optString("timerName"))
                    .put("alarmVolumePercent", max > 0 ? Math.round(100f * volume / max) : 0)
                    .put("batteryOptimized", power != null && !power.isIgnoringBatteryOptimizations(context.getPackageName()))
                    .put("dndActive", nm != null && nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL)
                    .put("lessonAlarms", lessons).put("nextAlarmMillis", next == Long.MAX_VALUE ? 0 : next)
                    .put("lastDelivery", AlarmStore.lastDelivery(context));
        } catch (Exception e) {
            try { result.put("ready", false).put("issue", "Não foi possível verificar o despertador."); }
            catch (Exception ignored) {}
        }
        return result;
    }

    private static String report(Context context) {
        JSONObject s = inspect(context);
        long next = s.optLong("nextAlarmMillis");
        String nextText = next > 0 ? DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(next)) : "Nenhuma aula futura com aviso programado.";
        return "Alarmes no horário: " + (s.optBoolean("exactAllowed") ? "permitidos" : "ativar")
                + "\nNotificações das aulas: " + (s.optBoolean("notificationsAllowed") ? "permitidas" : "ativar")
                + "\nVolume dos alarmes: " + s.optInt("alarmVolumePercent") + "%"
                + "\nNão perturbe: " + (s.optBoolean("dndActive") ? "ativo; confira se permite alarmes" : "desativado")
                + "\nBateria: " + (s.optBoolean("batteryOptimized") ? "com otimização" : "sem otimização")
                + "\nSom das aulas: " + (s.optString("lessonSoundName").isEmpty() ? "padrão do celular" : s.optString("lessonSoundName"))
                + "\nSom do fim da aula: " + (s.optString("timerSoundName").isEmpty() ? "padrão do celular" : s.optString("timerSoundName"))
                + "\n\nPróximo aviso: " + nextText
                + "\n\n" + (s.optString("issue").isEmpty() ? "Permissões e som verificados. Faça o teste com a tela bloqueada." : s.optString("issue"))
                + "\n\nÚltimo disparo: " + s.optString("lastDelivery");
    }

    static void show(Activity activity) {
        AlertDialog dialog = new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Despertador").setMessage(report(activity))
                .setPositiveButton("Testar em 30 s", null)
                .setNeutralButton("Ajustes", (d, which) -> showSettings(activity))
                .setNegativeButton("Fechar", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try {
                AlarmScheduler.scheduleTest(activity);
                dialog.dismiss();
                Toast.makeText(activity, "Teste programado para daqui a 30 segundos. Bloqueie a tela e aguarde o toque.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                dialog.setMessage(report(activity));
                Toast.makeText(activity, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }));
        dialog.show();
    }

    private static void showSettings(Activity activity) {
        String[] choices = {"Alarmes e lembretes", "Notificações do aplicativo", "Som das aulas", "Volume dos alarmes", "Uso da bateria", "Cancelar teste"};
        new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Ajustes do despertador").setItems(choices, (dialog, which) -> {
                    if (which == 5) { AlarmScheduler.cancelTest(activity); show(activity); return; }
                    if (which == 1 && Build.VERSION.SDK_INT >= 33
                            && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001); return;
                    }
                    Intent intent;
                    if (which == 0 && Build.VERSION.SDK_INT >= 31) {
                        intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + activity.getPackageName()));
                    } else if (which == 2) {
                        intent = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName())
                                .putExtra(Settings.EXTRA_CHANNEL_ID, AudioSettings.lessonChannelId(activity));
                    } else if (which == 3) intent = new Intent(Settings.ACTION_SOUND_SETTINGS);
                    else if (which == 4) intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                    else intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
                    try { activity.startActivity(intent); }
                    catch (Exception e) {
                        try { activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + activity.getPackageName()))); }
                        catch (Exception ignored) { Toast.makeText(activity, "Abra as configurações da Agenda Personal no celular.", Toast.LENGTH_LONG).show(); }
                    }
                }).setNegativeButton("Fechar", null).show();
    }
}
