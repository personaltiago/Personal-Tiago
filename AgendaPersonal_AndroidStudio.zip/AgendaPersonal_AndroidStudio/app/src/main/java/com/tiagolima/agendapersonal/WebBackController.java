package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.webkit.WebView;
import java.util.function.BooleanSupplier;

/** Back belongs to the page's UI stack; URLs alone do not describe its open screens. */
final class WebBackController {
    static final String PAGE_BACK_SCRIPT = "(function(){try{"
        + "if(window.__agendaBootFailed||window.__agendaRestoreFailed)return true;"
        + "if(typeof window.handleAgendaSystemBack==='function')return window.handleAgendaSystemBack()!==false;"
        // Earlier compatible content updates still know their own UI navigation.
        + "if(typeof goBackEvaluation==='function'){goBackEvaluation();return true;}"
        + "var evaluationBack=document.getElementById('evaluationBackButton');"
        + "if(evaluationBack){evaluationBack.click();return true;}"
        + "if(typeof goBackApp==='function'){"
        + "if(typeof appNavigationReady!=='undefined'&&!appNavigationReady)return true;"
        + "if(typeof currentScreen!=='undefined'&&currentScreen==='dashboard'"
        + "&&typeof dialogStack!=='undefined'&&dialogStack.length===0"
        + "&&typeof appNavigation!=='undefined'&&appNavigation.length===0)return false;"
        + "goBackApp();return true;}"
        // During loading or an error, do not turn a Back gesture into an accidental exit.
        + "return true;}catch(error){return true;}})()";

    private final Activity activity;
    private final WebView webView;
    private final BooleanSupplier closeVideo;
    private final AppBackDispatcher dispatcher = new AppBackDispatcher();
    private boolean pending, destroyed;
    private int generation;

    WebBackController(Activity activity, WebView webView, BooleanSupplier closeVideo) {
        this.activity = activity;
        this.webView = webView;
        this.closeVideo = closeVideo;
        dispatcher.register(activity, this::handleBack);
    }

    void handleBack() {
        if (destroyed || pending || activity.isFinishing()) return;
        if (closeVideo.getAsBoolean()) return;
        pending = true;
        final int request = ++generation;
        webView.evaluateJavascript(PAGE_BACK_SCRIPT, result -> {
            if (destroyed || request != generation || activity.isFinishing()) return;
            pending = false;
            // Only an explicit root-page response can close the agenda.
            if ("false".equals(result)) activity.finish();
        });
    }

    void pageStarted() { generation++; pending = false; }

    void destroy() {
        destroyed = true;
        generation++;
        pending = false;
        dispatcher.destroy();
    }
}
