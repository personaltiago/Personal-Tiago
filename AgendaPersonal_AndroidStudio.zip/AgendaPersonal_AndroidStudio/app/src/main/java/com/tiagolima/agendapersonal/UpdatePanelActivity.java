package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

/** Separate signed-in browser: deliberately has no native JavaScript bridge. */
public final class UpdatePanelActivity extends Activity {
    private WebView browser;
    private ValueCallback<Uri[]> fileCallback;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.parseColor("#110c18"));
        Button back = new Button(this); back.setText("Voltar para a agenda"); back.setOnClickListener(v -> { CookieManager.getInstance().flush(); finish(); });
        root.addView(back, new LinearLayout.LayoutParams(-1, -2));
        browser = new WebView(this); root.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1)); setContentView(root);
        browser.getSettings().setJavaScriptEnabled(true); browser.getSettings().setDomStorageEnabled(true);
        browser.getSettings().setAllowFileAccess(false); browser.getSettings().setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(browser, true);
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), 4100); return true; }
                catch (Exception e) { fileCallback.onReceiveValue(null); fileCallback = null; return false; }
            }
        });
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme())) return true;
                if (uri.toString().startsWith(UpdateManager.SITE_URL + "/api/bundle/")) {
                    Toast.makeText(UpdatePanelActivity.this, "Volte para a agenda e toque em Verificar para aplicar essa atualização.", Toast.LENGTH_LONG).show(); return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) { CookieManager.getInstance().flush(); }
        });
        browser.loadUrl(UpdateManager.SITE_URL);
    }
    @Override public void onBackPressed() { CookieManager.getInstance().flush(); finish(); }
    @Override protected void onActivityResult(int code, int result, Intent data) {
        if (code == 4100 && fileCallback != null) { fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data)); fileCallback = null; return; }
        super.onActivityResult(code, result, data);
    }
    @Override protected void onDestroy() { if (browser != null) browser.destroy(); super.onDestroy(); }
}
