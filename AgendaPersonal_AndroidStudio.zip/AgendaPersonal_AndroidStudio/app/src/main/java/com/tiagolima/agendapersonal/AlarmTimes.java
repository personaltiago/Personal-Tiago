package com.tiagolima.agendapersonal;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Set;

/** Calendar calculations shared by scheduling, cancellation and reboot recovery. */
final class AlarmTimes {
    private AlarmTimes() {}

    static final class Occurrence {
        final String date;
        final long classAtMillis;
        final long triggerAtMillis;
        Occurrence(LocalDate date, long classAtMillis, long triggerAtMillis) {
            this.date = date.toString();
            this.classAtMillis = classAtMillis;
            this.triggerAtMillis = triggerAtMillis;
        }
    }

    static Occurrence next(String startDate, String time, int leadMinutes,
                           Integer weekday, Set<String> blocked, Set<String> delivered,
                           long now, ZoneId zone) {
        LocalDate start = LocalDate.parse(startDate);
        LocalTime lessonTime = LocalTime.parse(time);
        if (leadMinutes < 0) throw new IllegalArgumentException("Antecedência inválida");
        boolean weekly = weekday != null;
        LocalDate date = start;
        if (weekly) {
            if (weekday < 0 || weekday > 6) throw new IllegalArgumentException("Dia inválido");
            LocalDate today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
            if (date.isBefore(today)) date = today;
            int day = date.getDayOfWeek().getValue() % 7;
            date = date.plusDays((weekday - day + 7) % 7);
        }
        int attempts = blocked.size() + delivered.size() + 2;
        for (int i = 0; i < attempts; i++) {
            String key = date.toString();
            long classAt = date.atTime(lessonTime).atZone(zone).toInstant().toEpochMilli();
            if (classAt > now && !blocked.contains(key) && !delivered.contains(key)) {
                long trigger = classAt - leadMinutes * 60_000L;
                // A newly saved lesson whose lead time has passed still gets one warning.
                if (trigger <= now) trigger = Math.min(now + 5_000L, classAt);
                return new Occurrence(date, classAt, trigger);
            }
            if (!weekly) return null;
            date = date.plusWeeks(1);
        }
        throw new IllegalStateException("Não foi possível encontrar o próximo aviso");
    }
}
