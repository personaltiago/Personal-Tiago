package com.tiagolima.agendapersonal;

import java.net.URI;
import java.util.Locale;

/** Identifies shared Google Maps links without resolving them over the network. */
final class MapLinks {
    private MapLinks() {}

    static String directGoogleMapsLink(String location) {
        if (location == null) return null;
        String value = location.trim();
        try {
            URI uri = new URI(value);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (scheme == null || host == null || uri.getUserInfo() != null) return null;
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) return null;
            host = host.toLowerCase(Locale.ROOT);
            String path = uri.getPath() == null ? "" : uri.getPath();
            boolean mapsPath = "/maps".equals(path) || path.startsWith("/maps/");
            boolean directHost = "maps.app.goo.gl".equals(host)
                    || "maps.google.com".equals(host)
                    || "maps.google.com.br".equals(host);
            boolean googleHost = "google.com".equals(host) || "www.google.com".equals(host)
                    || "google.com.br".equals(host) || "www.google.com.br".equals(host);
            if (directHost || (mapsPath && (googleHost || "goo.gl".equals(host)))) {
                return value;
            }
        } catch (Exception ignored) {}
        return null;
    }
}
