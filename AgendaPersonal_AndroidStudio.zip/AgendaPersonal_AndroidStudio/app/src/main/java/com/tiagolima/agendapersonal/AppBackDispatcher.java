package com.tiagolima.agendapersonal;

import android.app.Activity;
import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

/** Connects modern Android gestures to the same action as the legacy Back button. */
final class AppBackDispatcher {
    private Runnable unregister;

    void register(Activity activity, Runnable action) {
        destroy();
        if (Build.VERSION.SDK_INT >= 33) unregister = Api33.register(activity, action);
    }

    void destroy() {
        if (unregister != null) { unregister.run(); unregister = null; }
    }

    /** Keep API 33 types away from the path used on Android 8–12. */
    private static final class Api33 {
        static Runnable register(Activity activity, Runnable action) {
            OnBackInvokedDispatcher dispatcher = activity.getOnBackInvokedDispatcher();
            OnBackInvokedCallback callback = action::run;
            // Default priority lets the keyboard handle Back before the page does.
            dispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, callback);
            return () -> dispatcher.unregisterOnBackInvokedCallback(callback);
        }
    }
}
