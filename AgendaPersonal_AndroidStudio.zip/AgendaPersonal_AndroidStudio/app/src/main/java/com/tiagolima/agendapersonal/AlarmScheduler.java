package com.tiagolima.agendapersonal;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Agenda e financeiro são as fontes únicas dos lembretes nativos deste app. */
final class AlarmScheduler {
    static final int NOTIFICATION_ID = 1;
    private AlarmScheduler() {}

    static synchronized void synchronize(Context context, JSONObject agenda) throws Exception {
        JSONArray lessons = agenda.getJSONArray("lessons");
        JSONObject statuses = agenda.getJSONObject("occurrenceStatus");
        JSONArray students = agenda.optJSONArray("students");
        long now = System.currentTimeMillis();
        Map<String, JSONObject> desired = new LinkedHashMap<>();
        // O teste usa o mesmo AlarmManager e receptor, e sobrevive a uma sincronização da agenda.
        JSONObject test = AlarmStore.plan(context, "alarm-test");
        if (test != null && test.optLong("triggerAtMillis") + 60_000L > now) desired.put("alarm-test", test);
        for (JSONObject running : AlarmStore.plans(context)) {
            if ("timer".equals(running.optString("kind")) && running.optLong("triggerAtMillis") > now) {
                desired.put(running.optString("alarmKey"), running);
            }
        }
        Set<String> lessonIds = new HashSet<>();

        for (int i = 0; i < lessons.length(); i++) {
            JSONObject lesson = lessons.getJSONObject(i);
            String lessonId = lesson.getString("id");
            if (lessonId.isEmpty() || !lessonIds.add(lessonId)) {
                throw new IllegalArgumentException("Identificador de aula inválido");
            }
            Set<String> blocked = blockedDates(statuses, lessonId);
            Set<String> delivered = AlarmStore.deliveredDatesForLesson(context, lesson);
            if ("weekly".equals(lesson.optString("repeat", "none"))) {
                JSONArray days = lesson.getJSONArray("repeatDays");
                if (days.length() == 0) throw new IllegalArgumentException("Dias da aula ausentes");
                for (int d = 0; d < days.length(); d++) {
                    addLessonPlan(context, desired, lesson, days.getInt(d), blocked, delivered, now);
                }
            } else {
                addLessonPlan(context, desired, lesson, null, blocked, delivered, now);
            }
        }

        if (students != null) {
            Set<String> studentIds = new HashSet<>();
            for (int i = 0; i < students.length(); i++) {
                JSONObject student = students.getJSONObject(i);
                String studentId = student.optString("id", "");
                if (studentId.isEmpty() || !studentIds.add(studentId)) continue;
                addPaymentPlans(context, desired, student, now);
            }
        }

        // Persistir antes de tocar nos PendingIntents permite restauração após reboot.
        if (!AlarmStore.saveSnapshot(context, agenda)) {
            throw new IllegalStateException("Não foi possível salvar os avisos");
        }
        cancelLegacyAlarms(context);
        for (JSONObject old : AlarmStore.plans(context)) {
            String key = old.getString("alarmKey");
            JSONObject replacement = desired.get(key);
            if (replacement == null
                    || old.getLong("triggerAtMillis") != replacement.getLong("triggerAtMillis")
                    || !old.optString("classDate", "").equals(replacement.optString("classDate", ""))) {
                cancelPlan(context, key);
            }
        }

        NotificationManager notifications = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Iterator<String> keys = statuses.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (isBlocked(statuses.optString(key)) && notifications != null) {
                notifications.cancel(key, NOTIFICATION_ID);
            }
        }
        if (notifications != null) {
            for (android.service.notification.StatusBarNotification notice : notifications.getActiveNotifications()) {
                String tag = notice.getTag();
                if (tag == null || tag.startsWith("payment|") || "alarm-test".equals(tag)) continue;
                int separator = tag.lastIndexOf('|');
                if (separator > 0) {
                    String id = tag.substring(0, separator), date = tag.substring(separator + 1);
                    JSONObject lesson = null;
                    for (int i = 0; i < lessons.length(); i++) if (id.equals(lessons.getJSONObject(i).optString("id"))) { lesson = lessons.getJSONObject(i); break; }
                    if (lesson == null || !AlarmStore.matchesLessonDelivery(context, lesson, date)) notifications.cancel(tag, NOTIFICATION_ID);
                }
            }
        }
        for (JSONObject plan : desired.values()) schedule(context, plan);
    }

    private static void addLessonPlan(Context context, Map<String, JSONObject> desired, JSONObject lesson,
                                      Integer weekday, Set<String> blocked, Set<String> delivered,
                                      long now) throws Exception {
        AlarmTimes.Occurrence next = AlarmTimes.next(
                lesson.getString("date"), lesson.getString("time"), lesson.optInt("lead", 15),
                weekday, blocked, delivered, now, ZoneId.systemDefault());
        if (next == null) return;
        String key = lesson.getString("id") + "|" + (weekday == null ? "once" : "week-" + weekday);
        JSONObject plan = new JSONObject();
        plan.put("kind", "lesson");
        plan.put("alarmKey", key);
        plan.put("lessonId", lesson.getString("id"));
        plan.put("classDate", next.date);
        plan.put("classAtMillis", next.classAtMillis);
        plan.put("triggerAtMillis", next.triggerAtMillis);
        plan.put("student", lesson.optString("student", "Aluno"));
        plan.put("location", lesson.optString("location", ""));
        plan.put("phone", lesson.optString("phone", ""));
        plan.put("lessonTime", lesson.getString("time"));
        plan.put("leadMinutes", lesson.optInt("lead", 15));
        plan.put("weekly", weekday != null);
        JSONObject old = AlarmStore.plan(context, key);
        // Não adiar um aviso tardio já programado a cada salvamento da agenda.
        if (old != null && next.date.equals(old.optString("classDate"))
                && next.classAtMillis == old.optLong("classAtMillis")
                && plan.getInt("leadMinutes") == old.optInt("leadMinutes")
                && old.optLong("triggerAtMillis") > now) {
            plan.put("triggerAtMillis", old.getLong("triggerAtMillis"));
        }
        desired.put(key, plan);
    }

    private static void addPaymentPlans(Context context, Map<String, JSONObject> desired,
                                        JSONObject student, long now) throws Exception {
        String studentId = student.optString("id", "");
        String dueDate = student.optString("dueDate", "");
        if (studentId.isEmpty() || dueDate.isEmpty()) return;
        LocalDate due;
        try { due = LocalDate.parse(dueDate); }
        catch (Exception e) { return; }

        int reminderDays = Math.max(0, student.optInt("paymentReminderDays", 3));
        long dueAt = atNine(due);
        if (reminderDays > 0) {
            long beforeAt = atNine(due.minusDays(reminderDays));
            if (beforeAt > now) {
                addPaymentPlan(context, desired, student, dueDate, "before", reminderDays, beforeAt, now);
            } else if (dueAt > now) {
                // Se o cadastro/edição ocorrer já dentro da janela de aviso, lembrar uma única vez imediatamente.
                addPaymentPlan(context, desired, student, dueDate, "before", reminderDays, now + 1800L, now);
            }
        }

        String deliveredToken = dueDate + "|due";
        boolean alreadyDelivered = AlarmStore.deliveredDates(context, "payment:" + studentId).contains(deliveredToken);
        if (!alreadyDelivered) {
            // Se o app abrir depois das 09:00 do vencimento (ou já vencido), avisa uma única vez imediatamente.
            long trigger = dueAt > now ? dueAt : now + 2500L;
            addPaymentPlan(context, desired, student, dueDate, "due", 0, trigger, now);
        }
    }

    private static long atNine(LocalDate date) {
        return LocalDateTime.of(date, LocalTime.of(9, 0)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    private static void addPaymentPlan(Context context, Map<String, JSONObject> desired, JSONObject student,
                                       String dueDate, String stage, int reminderDays,
                                       long triggerAt, long now) throws Exception {
        String studentId = student.getString("id");
        String token = dueDate + "|" + stage;
        Set<String> delivered = AlarmStore.deliveredDates(context, "payment:" + studentId);
        if (delivered.contains(token)) return;
        String key = "payment|" + studentId + "|" + dueDate + "|" + stage;
        JSONObject plan = new JSONObject();
        plan.put("kind", "payment");
        plan.put("alarmKey", key);
        plan.put("studentId", studentId);
        plan.put("classDate", dueDate);
        plan.put("dueDate", dueDate);
        plan.put("stage", stage);
        plan.put("reminderDays", reminderDays);
        plan.put("triggerAtMillis", triggerAt);
        plan.put("student", student.optString("name", "Aluno"));
        plan.put("phone", student.optString("phone", ""));
        plan.put("pix", student.optString("pix", ""));
        plan.put("chargeMessage", student.optString("chargeMessage", ""));
        plan.put("monthlyValue", student.optString("monthlyValue", ""));
        JSONObject old = AlarmStore.plan(context, key);
        if (old != null && old.optLong("triggerAtMillis") > now && "due".equals(stage) && triggerAt <= now + 3000L) {
            plan.put("triggerAtMillis", old.getLong("triggerAtMillis"));
        }
        desired.put(key, plan);
    }

    private static Set<String> blockedDates(JSONObject statuses, String lessonId) {
        Set<String> result = new HashSet<>();
        String prefix = lessonId + "|";
        Iterator<String> keys = statuses.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (key.startsWith(prefix) && isBlocked(statuses.optString(key))) {
                result.add(key.substring(prefix.length()));
            }
        }
        return result;
    }

    private static boolean isBlocked(String status) {
        return "cancelada".equals(status) || "realizada".equals(status);
    }

    private static Intent alarmIntent(Context context, String key) {
        return new Intent(context, AlarmReceiver.class)
                .setAction("com.tiagolima.agendapersonal.LESSON_ALARM")
                .setData(Uri.parse("agenda-personal://alarm/" + Uri.encode(key)));
    }

    private static void schedule(Context context, JSONObject plan) throws Exception {
        String key = plan.getString("alarmKey");
        long trigger = plan.getLong("triggerAtMillis");
        Intent intent = alarmIntent(context, key)
                .putExtra("alarmKey", key)
                .putExtra("classDate", plan.optString("classDate", ""))
                .putExtra("triggerAtMillis", trigger);
        PendingIntent pending = PendingIntent.getBroadcast(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) throw new IllegalStateException("Serviço de alarmes indisponível");
        try {
            boolean exactBlocked = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms();
            if (exactBlocked) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending);
            } else if ("payment".equals(plan.optString("kind"))) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending);
            } else {
                Intent open = new Intent(context, MainActivity.class)
                        .setData(Uri.parse("agenda-personal://show/" + Uri.encode(key)));
                PendingIntent show = PendingIntent.getActivity(context, 0, open,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                manager.setAlarmClock(new AlarmManager.AlarmClockInfo(trigger, show), pending);
            }
        } catch (SecurityException e) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending);
        }
        try { AlarmStore.savePlan(context, plan); }
        catch (Exception e) { manager.cancel(pending); pending.cancel(); throw e; }
    }

    private static void cancelPlan(Context context, String key) {
        PendingIntent pending = PendingIntent.getBroadcast(context, 0, alarmIntent(context, key),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pending != null) {
            AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (manager != null) manager.cancel(pending);
            pending.cancel();
        }
        AlarmStore.removePlan(context, key);
    }

    private static void cancelLegacyAlarms(Context context) {
        for (JSONObject old : AlarmStore.legacyPlans(context)) {
            int code = old.optInt("requestCode", -1);
            if (code < 0) continue;
            PendingIntent pending = PendingIntent.getBroadcast(context, code,
                    new Intent(context, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pending != null) {
                AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                if (manager != null) manager.cancel(pending);
                pending.cancel();
            }
            AlarmStore.removeLegacy(context, code);
        }
    }

    static synchronized JSONObject pending(Context context, Intent intent) {
        try {
            String key = intent.getStringExtra("alarmKey");
            if (key == null) return null;
            JSONObject plan = AlarmStore.plan(context, key);
            if (plan == null) return null;
            if (plan.getLong("triggerAtMillis") != intent.getLongExtra("triggerAtMillis", -1)
                    || !plan.optString("classDate", "").equals(intent.getStringExtra("classDate"))) return null;
            if ("test".equals(plan.optString("kind"))) return plan;
            if ("timer".equals(plan.optString("kind"))) return plan;
            JSONObject agenda = AlarmStore.snapshot(context);
            if (agenda == null) return null;

            if ("payment".equals(plan.optString("kind"))) {
                String studentId = plan.optString("studentId", "");
                String dueDate = plan.optString("dueDate", "");
                String stage = plan.optString("stage", "due");
                JSONArray students = agenda.optJSONArray("students");
                boolean stillCurrent = false;
                if (students != null) {
                    for (int i = 0; i < students.length(); i++) {
                        JSONObject s = students.optJSONObject(i);
                        if (s != null && studentId.equals(s.optString("id")) && dueDate.equals(s.optString("dueDate"))) {
                            stillCurrent = true; break;
                        }
                    }
                }
                if (!stillCurrent) { cancelPlan(context, key); return null; }
                String deliveredId = "payment:" + studentId;
                String token = dueDate + "|" + stage;
                if (AlarmStore.deliveredDates(context, deliveredId).contains(token)) return null;
                return plan;
            }

            String lessonId = plan.getString("lessonId"), date = plan.getString("classDate");
            String status = agenda.getJSONObject("occurrenceStatus").optString(lessonId + "|" + date);
            if (isBlocked(status) || (AlarmStore.deliveredDates(context, lessonId).contains(date)
                    && AlarmStore.matchesLessonDelivery(context, plan, date))) return null;
            return plan;
        } catch (Exception e) {
            return null;
        }
    }

    // Só confirma após o NotificationManager aceitar o aviso, com as notificações habilitadas.
    static synchronized boolean complete(Context context, JSONObject plan) {
        try {
            String key = plan.getString("alarmKey");
            JSONObject current = AlarmStore.plan(context, key);
            if (current == null || current.getLong("triggerAtMillis") != plan.getLong("triggerAtMillis")
                    || !current.optString("classDate").equals(plan.optString("classDate"))) return false;
            String kind = plan.optString("kind");
            if (!"test".equals(kind) && !"timer".equals(kind)) {
                String id = "payment".equals(kind) ? "payment:" + plan.getString("studentId") : plan.getString("lessonId");
                String token = "payment".equals(kind) ? plan.getString("dueDate") + "|" + plan.getString("stage") : plan.getString("classDate");
                boolean marked = "payment".equals(kind) ? AlarmStore.markDelivered(context, id, token) : AlarmStore.markLessonDelivered(context, plan);
                if (!marked) return false;
            }
            cancelPlan(context, key);
            AlarmStore.recordDelivery(context, "test".equals(kind) ? "Aviso do teste publicado." : "Aviso publicado · " + plan.optString("student", "Aluno"));
            JSONObject agenda = AlarmStore.snapshot(context);
            if (agenda != null) synchronize(context, agenda);
            return true;
        } catch (Exception e) {
            AlarmStore.recordDelivery(context, "Falha ao confirmar o disparo: " + e.getMessage());
            return false;
        }
    }

    static synchronized void scheduleTest(Context context) throws Exception {
        String issue = AlarmStatus.issue(context);
        if (!issue.isEmpty()) throw new IllegalStateException(issue);
        cancelTest(context);
        long trigger = System.currentTimeMillis() + 30_000L;
        JSONObject plan = new JSONObject().put("kind", "test").put("alarmKey", "alarm-test")
                .put("classDate", "test").put("triggerAtMillis", trigger)
                .put("student", "Teste do despertador").put("leadMinutes", 0);
        schedule(context, plan);
    }

    static synchronized void cancelTest(Context context) {
        cancelPlan(context, "alarm-test");
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel("alarm-test", NOTIFICATION_ID);
    }

    static synchronized void startLessonTimer(Context context, JSONObject timer) throws Exception {
        String lessonId = timer.getString("lessonId");
        String classDate = timer.getString("classDate");
        long trigger = timer.getLong("triggerAtMillis");
        if (lessonId.isEmpty() || classDate.isEmpty() || trigger <= System.currentTimeMillis()) {
            throw new IllegalArgumentException("Cronômetro inválido");
        }
        String key = "timer|" + lessonId + "|" + classDate;
        cancelPlan(context, key);
        JSONObject plan = new JSONObject()
                .put("kind", "timer")
                .put("alarmKey", key)
                .put("lessonId", lessonId)
                .put("classDate", classDate)
                .put("triggerAtMillis", trigger)
                .put("classAtMillis", trigger)
                .put("student", timer.optString("student", "Aluno"))
                .put("lessonTime", timer.optString("lessonTime", ""))
                .put("leadMinutes", 0)
                .put("durationMinutes", timer.optInt("durationMinutes", 60));
        schedule(context, plan);
    }

    static synchronized void cancelLessonTimer(Context context, String lessonId, String classDate) {
        if (lessonId == null || classDate == null) return;
        String key = "timer|" + lessonId + "|" + classDate;
        cancelPlan(context, key);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(lessonId + "|" + classDate, NOTIFICATION_ID);
    }

    static synchronized void restore(Context context) {
        JSONObject agenda = AlarmStore.snapshot(context);
        if (agenda == null) return;
        try { synchronize(context, agenda); }
        catch (Exception ignored) {}
    }
}
