package com.tiagolima.agendapersonal;

/** An isolated YouTube page whose HTTPS origin identifies this installed app. */
final class YouTubePlayerPage {
    private YouTubePlayerPage() {}

    static boolean validVideoId(String videoId) {
        return videoId != null && videoId.matches("[A-Za-z0-9_-]{11}");
    }

    static String origin(String packageName) {
        if (packageName == null || !packageName.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")) {
            throw new IllegalArgumentException("Identificação do app inválida");
        }
        return "https://" + packageName;
    }

    static String html(String videoId, int startSeconds, String packageName) {
        if (!validVideoId(videoId) || startSeconds < 0) throw new IllegalArgumentException("Vídeo inválido");
        String appOrigin = origin(packageName);
        return "<!doctype html><html lang=\"pt-BR\"><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<meta name=\"referrer\" content=\"strict-origin-when-cross-origin\">"
                + "<title>Vídeo do exercício</title><style>"
                + "*{box-sizing:border-box}html,body{margin:0;background:#0b0a0f;color:#f7f4fa;font-family:Arial,sans-serif}"
                + "main{padding:14px 12px}.video{width:100%;aspect-ratio:16/9;min-height:200px;background:#000}"
                + "#player{display:block;width:100%;height:100%;min-height:200px;border:0}"
                + "#status{color:#c9b8d5;font-size:14px;line-height:1.5;margin:16px 0 0}"
                + "@media(orientation:landscape){main{max-width:960px;margin:auto}.video{max-height:calc(100vh - 85px);aspect-ratio:auto;height:calc(100vh - 85px)}}"
                + "</style></head><body><main><div class=\"video\"><div id=\"player\"></div></div>"
                + "<p id=\"status\" role=\"status\">Carregando vídeo…</p></main><script>"
                + "var player=null;function videoStatus(text){document.getElementById('status').textContent=text;}"
                + "var playerTimeout=setTimeout(function(){videoStatus('O vídeo não carregou. Confira a conexão ou use Abrir no YouTube.');},15000);"
                + "function onYouTubeIframeAPIReady(){try{player=new YT.Player('player',{width:'100%',height:'100%',videoId:'" + videoId + "',"
                + "playerVars:{autoplay:1,controls:1,playsinline:1,rel:0,start:" + startSeconds + ",origin:'" + appOrigin + "'},"
                + "events:{onReady:function(){clearTimeout(playerTimeout);videoStatus('');},"
                + "onError:function(event){clearTimeout(playerTimeout);var text=event.data===100?'Este vídeo está indisponível.':"
                + "event.data===101||event.data===150?'Este vídeo não permite reprodução dentro de aplicativos.':"
                + "event.data===153?'Não foi possível iniciar o player do YouTube.':'Não foi possível reproduzir este vídeo.';"
                + "videoStatus(text+' Use Abrir no YouTube.');},"
                + "onAutoplayBlocked:function(){videoStatus('Toque no botão de reprodução para iniciar o vídeo.');}}});}"
                + "catch(error){clearTimeout(playerTimeout);videoStatus('Não foi possível iniciar o vídeo. Use Abrir no YouTube.');}}"
                + "function pauseWorkoutVideo(){if(player&&typeof player.pauseVideo==='function')player.pauseVideo();}"
                + "</script><script async src=\"https://www.youtube.com/iframe_api\" "
                + "onerror=\"videoStatus('Confira a conexão e tente novamente, ou use Abrir no YouTube.');\"></script></body></html>";
    }

    static String inlineHtml(String videoId, int startSeconds, String packageName) {
        return html(videoId, startSeconds, packageName).replace("</head>",
                "<style>html,body{height:100%;background:#000}main{padding:0!important;height:100vh;display:flex;flex-direction:column}"
                + ".video{flex:1;width:100%;height:auto!important;max-height:none!important;aspect-ratio:auto;min-height:200px}"
                + "#status{flex:0 0 auto;margin:0;padding:6px 8px;font-size:12px;line-height:1.4;max-height:40px;overflow:auto}"
                + "#status:empty{display:none}#status.error{display:flex;align-items:center;gap:8px;padding:0 8px;max-height:48px;min-height:44px}"
                + "#status.error span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}"
                + "#status a{flex:0 0 auto;display:flex;align-items:center;min-height:44px;color:#e0b7ff;font-weight:bold;text-decoration:none}"
                + "</style></head>").replace(
                "function videoStatus(text){document.getElementById('status').textContent=text;}",
                "function videoStatus(text){var status=document.getElementById('status');status.textContent='';status.className='';"
                + "if(!text)return;if(text.indexOf('Abrir no YouTube')<0){status.textContent=text;return;}"
                + "status.className='error';var message=document.createElement('span');message.textContent=text;message.title=text;status.appendChild(message);"
                + "var link=document.createElement('a');link.href='https://www.youtube.com/watch?v=" + videoId
                + (startSeconds > 0 ? "&t=" + startSeconds : "") + "';link.textContent='Abrir no YouTube';status.appendChild(link);}");
    }
}
