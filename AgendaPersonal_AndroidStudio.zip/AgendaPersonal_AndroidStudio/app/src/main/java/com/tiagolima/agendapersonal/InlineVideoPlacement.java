package com.tiagolima.agendapersonal;

/** Converts the exercise card's CSS coordinates into its visible native area. */
final class InlineVideoPlacement {
    final int left, top, width, height, playerHeight, playerTop;
    final boolean visible;

    private InlineVideoPlacement(int left, int top, int width, int height, int playerHeight, int playerTop, boolean visible) {
        this.left = left; this.top = top; this.width = width; this.height = height;
        this.playerHeight = playerHeight; this.playerTop = playerTop; this.visible = visible;
    }

    static InlineVideoPlacement calculate(double viewportWidth, double viewportHeight,
            double left, double top, double width, double height, double clipTop, double clipBottom,
            boolean visible, int nativeWidth, int nativeHeight) {
        for (double value : new double[]{viewportWidth, viewportHeight, left, top, width, height, clipTop, clipBottom}) {
            if (Double.isNaN(value) || Double.isInfinite(value)) throw new IllegalArgumentException("Área inválida");
        }
        if (viewportWidth < 200 || viewportWidth > 4096 || viewportHeight < 100 || viewportHeight > 8192
                || width < 200 || width > viewportWidth + 2 || height < 240 || height > 4096
                || left < -2 || left + width > viewportWidth + 2 || Math.abs(top) > 100000
                || nativeWidth < 1 || nativeHeight < 1) throw new IllegalArgumentException("Área inválida");
        double scale = nativeWidth / viewportWidth;
        double upper = Math.max(Math.max(top, clipTop), 0);
        double lower = Math.min(Math.min(top + height, clipBottom), Math.min(viewportHeight, nativeHeight / scale));
        int w = Math.min(nativeWidth, Math.max(1, (int) Math.round(width * scale)));
        int x = Math.max(0, Math.min(nativeWidth - w, (int) Math.round(left * scale)));
        return new InlineVideoPlacement(x, Math.max(0, (int) Math.round(upper * scale)), w,
                Math.max(0, (int) Math.round((lower - upper) * scale)), (int) Math.round(height * scale),
                (int) Math.round((top - upper) * scale), visible && lower > upper);
    }
}
