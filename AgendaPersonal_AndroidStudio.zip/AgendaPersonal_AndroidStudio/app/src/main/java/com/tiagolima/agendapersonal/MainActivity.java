package com.tiagolima.agendapersonal;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.widget.FrameLayout;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 2002;

    private WebView webView;
    private UpdateManager updateManager;
    private ValueCallback<Uri[]> pendingFileChooser;
    private Uri pendingCameraUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        AlarmReceiver.createChannel(this);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }

        webView = new WebView(this);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#09080C"));
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        AppWindowLayout.apply(this, root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        updateManager = new UpdateManager(this, webView);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (UpdateManager.isLocalPage(uri)) {
                    if (request.isForMainFrame()) updateManager.openPage(uri);
                    return true;
                }
                String scheme = uri.getScheme();
                if ("https".equals(scheme) || "http".equals(scheme) || "mailto".equals(scheme) || "tel".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) { updateManager.pageFinished(); }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = filePathCallback;
                pendingCameraUri = null;

                try {
                    Intent contentIntent = fileChooserParams.createIntent();
                    Intent cameraIntent = acceptsImage(fileChooserParams) ? createCameraIntent() : null;

                    if (fileChooserParams.isCaptureEnabled() && cameraIntent != null) {
                        startActivityForResult(cameraIntent, FILE_CHOOSER_REQUEST);
                        return true;
                    }

                    Intent chooser = Intent.createChooser(contentIntent, "Escolher arquivo");
                    if (cameraIntent != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                    pendingFileChooser = null;
                    pendingCameraUri = null;
                    Toast.makeText(MainActivity.this, "Não foi possível abrir os arquivos do celular.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new Bridge(this), "Android");
        updateManager.openPage(Uri.parse("file:///android_asset/index.html"));
    }

    private boolean acceptsImage(WebChromeClient.FileChooserParams params) {
        String[] types = params.getAcceptTypes();
        if (types == null || types.length == 0) return false;
        for (String type : types) {
            if (type != null && (type.startsWith("image/") || type.equals("image/*"))) return true;
        }
        return false;
    }

    private Intent createCameraIntent() throws Exception {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) return null;
        File folder = new File(getCacheDir(), "camera");
        if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Falha ao preparar câmera");
        File image = File.createTempFile("avaliacao_", ".jpg", folder);
        pendingCameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", image);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == UpdateManager.IMPORT_REQUEST) {
            if (resultCode == RESULT_OK && data != null) updateManager.importUri(data.getData());
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                if (data == null || data.getData() == null) {
                    if (pendingCameraUri != null) result = new Uri[]{pendingCameraUri};
                } else {
                    result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
            }
            if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(result);
            pendingFileChooser = null;
            pendingCameraUri = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (updateManager != null && updateManager.goBack()) return;
        else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.evaluateJavascript("if (typeof syncNativeAlarms === 'function') syncNativeAlarms();", null);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1001 && webView != null) {
            webView.evaluateJavascript("if (typeof syncNativeAlarms === 'function') syncNativeAlarms();", null);
        }
    }

    private static boolean needsExactAlarmPermission(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return false;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && !am.canScheduleExactAlarms();
    }

    @Override protected void onDestroy() {
        if (updateManager != null) updateManager.destroy();
        super.onDestroy();
    }

    public static class Bridge {
        private final Activity activity;
        private boolean exactAlarmPromptShown = false;

        Bridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface public void openUpdates() { ((MainActivity) activity).updateManager.showScreen(); }
        @JavascriptInterface public void updatePageReady() { ((MainActivity) activity).updateManager.pageReady(); }
        @JavascriptInterface public String getAlarmStatus() { return AlarmStatus.inspect(activity).toString(); }
        @JavascriptInterface public String getCustomSoundStatus() { return AudioSettings.status(activity).toString(); }
        @JavascriptInterface public void showAlarmSettings() { activity.runOnUiThread(() -> AlarmStatus.show(activity)); }

        @JavascriptInterface
        public String saveCustomSound(String kind, String fileName, String mimeType, String base64) {
            try {
                return AudioSettings.saveBase64(activity, kind, fileName, mimeType, base64).toString();
            } catch (Exception e) {
                try {
                    String message = e.getMessage();
                    return new JSONObject().put("error", message == null
                            ? "Não foi possível salvar o áudio." : message).toString();
                } catch (Exception ignored) {
                    return "{\"error\":\"Não foi possível salvar o áudio.\"}";
                }
            }
        }

        @JavascriptInterface
        public boolean startLessonTimer(String timerJson) {
            try {
                AlarmScheduler.startLessonTimer(activity, new JSONObject(timerJson));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void cancelLessonTimer(String lessonId, String classDate) {
            AlarmScheduler.cancelLessonTimer(activity, lessonId, classDate);
        }

        @JavascriptInterface
        public boolean syncLessonAlarms(String agendaJson) {
            try {
                JSONObject agenda = new JSONObject(agendaJson);
                if (agenda.optInt("schema", 0) != 4) return false;
                AlarmScheduler.synchronize(activity, agenda);
                if (!AlarmStore.plans(activity).isEmpty()) {
                    activity.runOnUiThread(this::requestExactAlarmAccessIfNeeded);
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        private void requestExactAlarmAccessIfNeeded() {
            if (exactAlarmPromptShown || !needsExactAlarmPermission(activity)) return;
            exactAlarmPromptShown = true;
            try {
                Toast.makeText(activity, "Para avisos no minuto exato, autorize Alarmes e lembretes.", Toast.LENGTH_LONG).show();
                Intent settings = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(settings);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void openMap(String query) {
            activity.runOnUiThread(() -> {
                String location = query == null ? "" : query.trim();
                if (location.isEmpty()) {
                    Toast.makeText(activity, "Informe o endereço ou o link do Google Maps.", Toast.LENGTH_SHORT).show();
                    return;
                }
                String directLink = MapLinks.directGoogleMapsLink(location);
                try {
                    Uri uri = Uri.parse(directLink != null
                            ? directLink : "geo:0,0?q=" + Uri.encode(location));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    activity.startActivity(intent);
                } catch (Exception e) {
                    try {
                        activity.startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse(directLink != null ? directLink
                                        : "https://www.google.com/maps/search/?api=1&query=" + Uri.encode(location))));
                    } catch (Exception ignored) {
                        Toast.makeText(activity, "Não foi possível abrir o mapa.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void openWhatsApp(String phone, String name) {
            openWhatsAppMessage(phone, "Olá, " + (name == null ? "" : name) + ".");
        }

        @JavascriptInterface
        public void openWhatsAppMessage(String phone, String message) {
            activity.runOnUiThread(() -> {
                try {
                    String digits = normalizeBrazilPhone(phone);
                    if (digits.isEmpty()) {
                        Toast.makeText(activity, "WhatsApp não cadastrado.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Uri uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(message == null ? "" : message));
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    activity.startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(activity, "Não foi possível abrir o WhatsApp.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openExternal(String url) {
            activity.runOnUiThread(() -> {
                try {
                    Uri uri = Uri.parse(url == null ? "" : url.trim());
                    String scheme = uri.getScheme();
                    if (scheme == null || !(scheme.equals("https") || scheme.equals("http") || scheme.equals("mailto") || scheme.equals("tel"))) {
                        throw new IllegalArgumentException("URL inválida");
                    }
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception e) {
                    Toast.makeText(activity, "Não foi possível abrir este link.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void shareText(String title, String text) {
            activity.runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Agenda Personal" : title);
                    send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    activity.startActivity(Intent.createChooser(send, "Compartilhar"));
                } catch (Exception e) {
                    Toast.makeText(activity, "Não foi possível compartilhar.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void saveBase64File(String filename, String mimeType, String base64) {
            new Thread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    String safeName = sanitizeFilename(filename);
                    String mime = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType;
                    saveToDownloads(safeName, mime, bytes);
                    activity.runOnUiThread(() -> Toast.makeText(activity,
                            "Arquivo salvo em Downloads/Agenda Personal.", Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    activity.runOnUiThread(() -> Toast.makeText(activity,
                            "Não foi possível salvar o arquivo.", Toast.LENGTH_LONG).show());
                }
            }).start();
        }

        @JavascriptInterface
        public void shareBase64File(String filename, String mimeType, String base64, String text) {
            new Thread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    String safeName = sanitizeFilename(filename);
                    File folder = new File(activity.getCacheDir(), "shared");
                    if (!folder.exists() && !folder.mkdirs()) throw new IllegalStateException("Falha ao preparar compartilhamento");
                    File file = new File(folder, safeName);
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", file);
                    activity.runOnUiThread(() -> {
                        try {
                            Intent send = new Intent(Intent.ACTION_SEND);
                            send.setType((mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType);
                            send.putExtra(Intent.EXTRA_STREAM, uri);
                            if (text != null && !text.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, text);
                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            activity.startActivity(Intent.createChooser(send, "Compartilhar"));
                        } catch (Exception e) {
                            Toast.makeText(activity, "Não foi possível compartilhar o arquivo.", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    activity.runOnUiThread(() -> Toast.makeText(activity,
                            "Não foi possível preparar o arquivo para compartilhar.", Toast.LENGTH_SHORT).show());
                }
            }).start();
        }

        private void saveToDownloads(String filename, String mime, byte[] bytes) throws Exception {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Agenda Personal");
                Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Falha ao criar arquivo");
                try (OutputStream out = activity.getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Falha ao abrir arquivo");
                    out.write(bytes);
                }
            } else {
                File folder = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (folder == null) throw new IllegalStateException("Downloads indisponível");
                File target = new File(folder, filename);
                try (FileOutputStream out = new FileOutputStream(target)) { out.write(bytes); }
            }
        }

        private String sanitizeFilename(String name) {
            String value = name == null ? "arquivo" : name.trim();
            value = value.replaceAll("[\\\\/:*?\"<>|\\x00-\\x1F]", "_");
            if (value.isEmpty()) value = "arquivo";
            return value.length() > 120 ? value.substring(0, 120) : value;
        }

        private String normalizeBrazilPhone(String phone) {
            String digits = phone == null ? "" : phone.replaceAll("\\D", "");
            if ((digits.length() == 10 || digits.length() == 11) && !digits.startsWith("55")) digits = "55" + digits;
            return digits;
        }
    }
}
