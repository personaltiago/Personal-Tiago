package com.tiagolima.agendapersonal;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.AtomicFile;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Keeps web releases at the original asset URLs, preserving localStorage and native alarms. */
public final class UpdateManager {
    public static final String SITE_URL = "https://agenda-personal-atualizacoes.silvanaoliveira1411.chatgpt.site";
    public static final int IMPORT_REQUEST = 3003;
    private static final String BASE_VERSION = "1.11.1";
    private static final int BASE_SEQUENCE = 2;
    private static final String HOME_URL = "file:///android_asset/index.html";
    private static final int MAX_BYTES = 12 * 1024 * 1024;
    private final MainActivity activity;
    private final WebView webView;
    private final SharedPreferences preferences;
    private final File activeFile, previousFile, snapshotFile;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile JSONObject active;
    private volatile JSONObject manifest;
    private AlertDialog dialog;
    private volatile boolean busy;
    private volatile boolean destroyed;
    private final ArrayList<Uri> pageHistory = new ArrayList<>();
    private int pageGeneration;
    private String pageToken = "";

    UpdateManager(MainActivity activity, WebView webView) {
        this.activity = activity; this.webView = webView;
        preferences = activity.getSharedPreferences("agenda_updates_v1", 0);
        File folder = new File(activity.getFilesDir(), "updates");
        if (!folder.exists()) folder.mkdirs();
        activeFile = new File(folder, "active.json"); previousFile = new File(folder, "previous.json");
        snapshotFile = new File(folder, "data-before-update.json");
        if (preferences.getBoolean("pending", false)) rollbackFiles();
        active = readActive();
    }
    private JSONObject readActive() {
        try {
            JSONObject value = validateBundle(new JSONObject(new String(new AtomicFile(activeFile).readFully(), StandardCharsets.UTF_8)));
            return value.optInt("sequence") > BASE_SEQUENCE ? value : null;
        }
        catch (Exception e) { return null; }
    }
    private JSONObject validateBundle(JSONObject value) throws Exception {
        if (value.optInt("format") != 1 || !activity.getPackageName().equals(value.optString("appId")) || value.optInt("bridgeVersion") != 2 || value.optInt("dataSchema") != 4 || value.optInt("sequence") < 1) throw new Exception("Esta atualização precisa de outra versão do APK.");
        String version = value.optString("version");
        if (!version.matches("[0-9]+\\.[0-9]+\\.[0-9]+")) throw new Exception("A versão desta atualização é inválida.");
        String[] components = version.split("\\.");
        int major = Integer.parseInt(components[0]), minor = Integer.parseInt(components[1]);
        if (major < 1 || (major == 1 && minor < 11)) throw new Exception("Esta atualização é anterior à versão incluída neste APK.");
        JSONObject files = value.getJSONObject("files");
        if (files.length() != 2 || !files.has("index.html") || !files.has("avaliacoes.html")) throw new Exception("A atualização está incompleta.");
        for (String asset : new String[]{"index.html", "avaliacoes.html"}) {
            String html = files.getString(asset);
            if (!html.contains("data-agenda-ready") || !html.toLowerCase().contains("</html>") || html.length() > MAX_BYTES) throw new Exception("O arquivo da atualização não é compatível.");
            if (asset.equals("index.html") && (!html.contains("agendaPersonalTL_v1") || !html.contains("syncNativeAlarms"))) throw new Exception("Esta atualização pertence a outra agenda.");
        }
        return value;
    }
    public static boolean isLocalPage(Uri uri) {
        if (uri == null || !"file".equals(uri.getScheme()) || (uri.getAuthority() != null && !uri.getAuthority().isEmpty())) return false;
        String path = uri.getPath();
        return "/android_asset/index.html".equals(path) || "/android_asset/avaliacoes.html".equals(path);
    }
    private String pageHtml(Uri uri, JSONObject release, String token, int releaseSequence) throws Exception {
        String path = uri.getPath();
        String asset = "/android_asset/index.html".equals(path) ? "index.html" : "/android_asset/avaliacoes.html".equals(path) ? "avaliacoes.html" : null;
        if (asset == null) throw new Exception("Página local inválida.");
        String html;
        if (release != null) html = release.getJSONObject("files").getString(asset);
        else try (InputStream input = activity.getAssets().open(asset)) { html = new String(readLimited(input, MAX_BYTES), StandardCharsets.UTF_8); }
        String script = "<script>window.__agendaNativeReleaseToken=" + JSONObject.quote(token) + ";window.__agendaNativeReleaseSequence=" + releaseSequence + ";</script>";
        if (preferences.getBoolean("restoreData", false) && snapshotFile.exists()) {
            String snapshot = Base64.encodeToString(Files.readAllBytes(snapshotFile.toPath()), Base64.NO_WRAP);
            script += "<script>(function(){try{var b=atob('" + snapshot + "');var a=Uint8Array.from(b,function(c){return c.charCodeAt(0)});var d=JSON.parse(new TextDecoder().decode(a));localStorage.clear();Object.keys(d).forEach(function(k){localStorage.setItem(k,d[k])});}catch(e){window.__agendaRestoreFailed=true}})();</script>";
        }
        Matcher head = java.util.regex.Pattern.compile("<head\\b[^>]*>", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
        if (!head.find()) throw new Exception("A página não contém o cabeçalho esperado.");
        return html.substring(0, head.end()) + script + html.substring(head.end());
    }
    public void openPage(Uri uri) { openPage(uri, false); }
    private void openHome() { openPage(Uri.parse(HOME_URL), true); }
    private void openPage(Uri uri, boolean resetHistory) {
        if (!isLocalPage(uri)) return;
        activity.runOnUiThread(() -> {
            if (destroyed || activity.isFinishing()) return;
            if (resetHistory) pageHistory.clear();
            if (pageHistory.isEmpty() || !pageHistory.get(pageHistory.size() - 1).equals(uri)) pageHistory.add(uri);
            final int generation = ++pageGeneration;
            final String token = UUID.randomUUID().toString();
            final JSONObject release = active;
            final int releaseSequence = release == null ? BASE_SEQUENCE : release.optInt("sequence", BASE_SEQUENCE);
            executor.execute(() -> {
                try {
                    String html = pageHtml(uri, release, token, releaseSequence);
                    activity.runOnUiThread(() -> {
                        if (destroyed || generation != pageGeneration || activity.isFinishing()) return;
                        pageToken = token;
                        // android_asset URLs bypass shouldInterceptRequest. Supply the HTML directly,
                        // keeping the exact original base URL and history URL for storage and links.
                        webView.loadDataWithBaseURL(uri.toString(), html, "text/html", "UTF-8", uri.toString());
                    });
                } catch (Exception e) {
                    activity.runOnUiThread(() -> {
                        if (destroyed || generation != pageGeneration || activity.isFinishing()) return;
                        if (preferences.getBoolean("pending", false)) {
                            rollbackFiles(); active = readActive(); busy = false; openHome();
                            Toast.makeText(activity, "Não foi possível abrir a atualização. A versão anterior foi recuperada.", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(activity, "Não foi possível abrir a agenda. Feche e abra o aplicativo novamente.", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            });
        });
    }
    public boolean goBack() {
        if (pageHistory.size() < 2) return false;
        pageHistory.remove(pageHistory.size() - 1);
        Uri previous = pageHistory.remove(pageHistory.size() - 1);
        openPage(previous);
        return true;
    }
    public void pageReady() {
        activity.runOnUiThread(() -> {
            if (destroyed || pageToken.isEmpty() || activity.isFinishing()) return;
            final String token = pageToken;
            final int generation = pageGeneration, releaseSequence = sequence();
            String check = "window.__agendaNativeReleaseToken===" + JSONObject.quote(token)
                + "&&window.__agendaNativeReleaseSequence===" + releaseSequence
                + "&&!window.__agendaBootFailed&&!window.__agendaRestoreFailed";
            webView.evaluateJavascript(check, result -> {
                if (destroyed || !"true".equals(result) || generation != pageGeneration || !token.equals(pageToken)) return;
                boolean applied = preferences.getBoolean("pending", false);
                if (!preferences.edit().putBoolean("pending", false).putBoolean("restoreData", false).commit()) return;
                if (applied) {
                    busy = false;
                    Toast.makeText(activity, "Atualização aplicada. Seus dados foram mantidos.", Toast.LENGTH_LONG).show();
                }
            });
        });
    }
    public void pageFinished() {
        if (!preferences.getBoolean("pending", false)) return;
        final int generation = pageGeneration;
        handler.postDelayed(() -> {
            if (!destroyed && generation == pageGeneration && preferences.getBoolean("pending", false) && !activity.isFinishing()) {
                rollbackFiles(); active = readActive(); busy = false; openHome();
                Toast.makeText(activity, "A nova versão não abriu corretamente. A versão anterior foi recuperada.", Toast.LENGTH_LONG).show();
            }
        }, 30000);
    }
    private void rollbackFiles() {
        try {
            if (previousFile.exists()) writeAtomic(activeFile, Files.readAllBytes(previousFile.toPath()));
            else new AtomicFile(activeFile).delete();
            preferences.edit().putBoolean("pending", false).putBoolean("restoreData", snapshotFile.exists()).commit();
        } catch (Exception ignored) { /* Keep pending for another recovery attempt. */ }
    }
    public void showScreen() {
        activity.runOnUiThread(() -> {
            if (activity.isFinishing()) return;
            Button importButton = new Button(activity);
            importButton.setText("Importar arquivo baixado do painel");
            importButton.setOnClickListener(v -> requestImport());
            dialog = new AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Atualizações da agenda")
                .setMessage(description("Toque em Verificar para consultar as novidades."))
                .setView(importButton)
                .setPositiveButton("Verificar", null).setNeutralButton("Painel", null).setNegativeButton("Fechar", null).create();
            dialog.setOnShowListener(ignored -> {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> { if (manifest != null && manifest.optInt("sequence") > sequence()) downloadAndApply(); else check(); });
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> activity.startActivity(new Intent(activity, UpdatePanelActivity.class)));
            });
            dialog.show();
        });
    }
    private int sequence() { return active == null ? BASE_SEQUENCE : active.optInt("sequence", BASE_SEQUENCE); }
    private String description(String message) { return "Versão instalada: " + (active == null ? BASE_VERSION : active.optString("version", BASE_VERSION)) + "\n\n" + message; }
    private void display(String message) {
        activity.runOnUiThread(() -> {
            if (dialog != null && dialog.isShowing()) {
                TextView text = dialog.findViewById(android.R.id.message); if (text != null) text.setText(description(message));
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(!busy);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText(manifest != null && manifest.optInt("sequence") > sequence() ? "Atualizar agora" : "Verificar");
            }
        });
    }
    private void check() {
        if (busy) return; busy = true; manifest = null; display("Consultando o painel…");
        executor.execute(() -> {
            String message;
            try {
                JSONObject result = new JSONObject(new String(fetch("/api/manifest", 65536), StandardCharsets.UTF_8));
                if (!result.optBoolean("available")) message = "Ainda não há uma atualização publicada.";
                else if (!activity.getPackageName().equals(result.optString("appId")) || result.optInt("bridgeVersion") != 2 || result.optInt("dataSchema") != 4) message = "Esta versão precisa de um novo APK. Abra o painel para consultar.";
                else if (result.optInt("sequence") <= sequence()) message = "Sua agenda está atualizada.";
                else { manifest = result; message = "Nova versão: " + result.optString("version") + "\n\n" + result.optString("notes") + "\n\nAo atualizar, uma cópia dos dados será salva no aparelho."; }
            } catch (Exception e) { message = readableError(e); }
            busy = false; display(message);
        });
    }
    private String readableError(Exception e) {
        if (e instanceof NeedsLogin) return "Para consultar as novidades, toque em Painel e entre na mesma conta deste painel. Depois volte e toque em Verificar.";
        return "Não foi possível consultar agora. Sua agenda continua funcionando com a versão instalada. Verifique a conexão e tente novamente.";
    }
    private byte[] fetch(String path, int limit) throws Exception {
        if (!path.matches("/api/(manifest|bundle/[a-f0-9-]{36})")) throw new Exception("Endereço de atualização inválido.");
        HttpURLConnection connection = (HttpURLConnection) new URL(SITE_URL + path).openConnection();
        connection.setConnectTimeout(15000); connection.setReadTimeout(25000); connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Accept", "application/json"); connection.setRequestProperty("Cache-Control", "no-cache");
        String cookie = CookieManager.getInstance().getCookie(SITE_URL);
        if (cookie != null) connection.setRequestProperty("Cookie", cookie);
        try {
            int status = connection.getResponseCode();
            if (status == 401 || status == 403 || (status >= 300 && status < 400)) throw new NeedsLogin();
            if (status != 200) throw new Exception("Serviço indisponível.");
            if (connection.getContentType() == null || !connection.getContentType().contains("application/json")) throw new NeedsLogin();
            if (connection.getContentLengthLong() > limit) throw new Exception("Atualização muito grande.");
            try (InputStream input = connection.getInputStream()) { return readLimited(input, limit); }
        } finally { connection.disconnect(); }
    }
    private void downloadAndApply() {
        if (busy || manifest == null) return;
        busy = true; display("Baixando e verificando a atualização…");
        JSONObject chosen = manifest;
        executor.execute(() -> {
            try {
                byte[] bytes = fetch(chosen.getString("bundlePath"), MAX_BYTES);
                String hash = hex(MessageDigest.getInstance("SHA-256").digest(bytes));
                if (!hash.equals(chosen.getString("sha256")) || bytes.length != chosen.getInt("size")) throw new Exception("O arquivo recebido está incompleto.");
                JSONObject bundle = validateBundle(new JSONObject(new String(bytes, StandardCharsets.UTF_8)));
                if (bundle.getInt("sequence") != chosen.getInt("sequence")) throw new Exception("A versão mudou durante o download.");
                activity.runOnUiThread(() -> snapshotAndApply(bundle));
            } catch (Exception e) { busy = false; display(readableError(e)); }
        });
    }
    public void importUri(Uri uri) {
        if (uri == null || busy) return;
        busy = true;
        executor.execute(() -> {
            try (InputStream input = activity.getContentResolver().openInputStream(uri)) {
                if (input == null) throw new Exception("Arquivo indisponível.");
                JSONObject bundle = validateBundle(new JSONObject(new String(readLimited(input, MAX_BYTES), StandardCharsets.UTF_8)));
                activity.runOnUiThread(() -> snapshotAndApply(bundle));
            } catch (Exception e) { busy = false; activity.runOnUiThread(() -> Toast.makeText(activity, "Não foi possível abrir esta atualização. Escolha o arquivo .agenda.json baixado do painel.", Toast.LENGTH_LONG).show()); }
        });
    }
    private void snapshotAndApply(JSONObject bundle) {
        if (bundle.optInt("sequence") <= sequence()) { busy = false; display("Essa versão já está instalada ou é anterior à atual."); return; }
        webView.evaluateJavascript("(function(){var d={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);d[k]=localStorage.getItem(k)}return JSON.stringify(d)})()", encoded -> {
            executor.execute(() -> {
                try {
                    Object decoded = new JSONTokener(encoded).nextValue();
                    if (!(decoded instanceof String)) throw new Exception("Não foi possível copiar os dados.");
                    String snapshot = (String) decoded; new JSONObject(snapshot);
                    writeAtomic(snapshotFile, snapshot.getBytes(StandardCharsets.UTF_8));
                    if (activeFile.exists()) writeAtomic(previousFile, new AtomicFile(activeFile).readFully());
                    else new AtomicFile(previousFile).delete();
                    if (!preferences.edit().putBoolean("pending", true).commit()) throw new Exception("Não foi possível preparar a atualização.");
                    writeAtomic(activeFile, bundle.toString().getBytes(StandardCharsets.UTF_8)); active = bundle;
                    activity.runOnUiThread(() -> {
                        if (dialog != null) dialog.dismiss();
                        openHome();
                        Toast.makeText(activity, "Arquivo recebido. Abrindo a nova versão…", Toast.LENGTH_SHORT).show();
                    });
                } catch (Exception e) { if (preferences.getBoolean("pending", false)) rollbackFiles(); busy = false; display("Não foi possível salvar a atualização. A versão anterior foi mantida."); }
            });
        });
    }
    public void requestImport() {
        activity.runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "application/octet-stream"});
            activity.startActivityForResult(intent, IMPORT_REQUEST);
        });
    }
    private static byte[] readLimited(InputStream input, int limit) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int count;
        while ((count = input.read(buffer)) != -1) { if (output.size() + count > limit) throw new Exception("Arquivo muito grande."); output.write(buffer, 0, count); }
        return output.toByteArray();
    }
    private static String hex(byte[] bytes) { StringBuilder result = new StringBuilder(); for (byte b : bytes) result.append(String.format("%02x", b & 255)); return result.toString(); }
    private static void writeAtomic(File file, byte[] bytes) throws Exception {
        AtomicFile target = new AtomicFile(file); FileOutputStream output = target.startWrite();
        try { output.write(bytes); target.finishWrite(output); }
        catch (Exception e) { target.failWrite(output); throw e; }
    }
    public void destroy() { destroyed = true; handler.removeCallbacksAndMessages(null); executor.shutdownNow(); }
    private static final class NeedsLogin extends Exception {}
}
