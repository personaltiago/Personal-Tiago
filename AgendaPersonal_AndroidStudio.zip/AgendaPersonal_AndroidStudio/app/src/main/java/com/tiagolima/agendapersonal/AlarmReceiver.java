package com.tiagolima.agendapersonal;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import org.json.JSONObject;
import java.time.LocalDate;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "agenda_personal_alarmes_v2";
    public static final String PAYMENT_CHANNEL_ID = "agenda_personal_financeiro_v1";

    @Override
    public void onReceive(Context context, Intent intent) {
        synchronized (AlarmScheduler.class) {
            JSONObject plan = AlarmScheduler.consume(context, intent);
            if (plan == null) return;
            if ("payment".equals(plan.optString("kind"))) showPaymentNotification(context, plan);
            else showLessonNotification(context, plan);
        }
    }

    private static void showLessonNotification(Context context, JSONObject plan) {
        String student = plan.optString("student", "Aluno");
        String location = plan.optString("location", "");
        String phone = plan.optString("phone", "");
        String lessonTime = plan.optString("lessonTime", "");
        int leadMinutes = plan.optInt("leadMinutes", 15);
        String occurrenceKey = plan.optString("lessonId") + "|" + plan.optString("classDate");
        int notificationId = occurrenceKey.hashCode() & 0x7fffffff;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel(nm);

        PendingIntent contentIntent = mainPendingIntent(context, notificationId, "lesson/" + Uri.encode(occurrenceKey));
        PendingIntent whatsAppIntent = buildWhatsAppPendingIntent(context, notificationId, phone, "Olá, " + student + ".", "wa");
        PendingIntent routeIntent = buildRoutePendingIntent(context, notificationId, location);

        String title = leadMinutes > 0
                ? "Agenda Personal · aula em " + leadMinutes + " min"
                : "Agenda Personal · hora da aula";
        String message = student + (location.isEmpty() ? "" : " — " + location)
                + (lessonTime.isEmpty() ? "" : " · " + lessonTime);

        android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new android.app.Notification.Builder(context, CHANNEL_ID)
                : new android.app.Notification.Builder(context);

        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setCategory(android.app.Notification.CATEGORY_ALARM)
                .setPriority(android.app.Notification.PRIORITY_MAX)
                .setVisibility(android.app.Notification.VISIBILITY_PUBLIC)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);

        if (whatsAppIntent != null) builder.addAction(android.R.drawable.ic_menu_send, "WhatsApp", whatsAppIntent);
        if (routeIntent != null) builder.addAction(android.R.drawable.ic_menu_mylocation, "Rota", routeIntent);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI);
            builder.setVibrate(new long[]{0, 600, 250, 600, 250, 600});
        }

        if (nm != null) {
            try { nm.notify(occurrenceKey, AlarmScheduler.NOTIFICATION_ID, builder.build()); }
            catch (SecurityException ignored) {}
        }
    }

    private static void showPaymentNotification(Context context, JSONObject plan) {
        String student = plan.optString("student", "Aluno");
        String phone = plan.optString("phone", "");
        String dueDate = plan.optString("dueDate", "");
        String stage = plan.optString("stage", "due");
        int reminderDays = plan.optInt("reminderDays", 0);
        String pix = plan.optString("pix", "");
        String key = plan.optString("alarmKey", "payment");
        int notificationId = key.hashCode() & 0x7fffffff;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel(nm);
        PendingIntent contentIntent = mainPendingIntent(context, notificationId, "finance/" + Uri.encode(plan.optString("studentId", "")));

        String title;
        if ("before".equals(stage)) title = "Financeiro · vence em " + reminderDays + (reminderDays == 1 ? " dia" : " dias");
        else {
            try {
                LocalDate due = LocalDate.parse(dueDate);
                if (due.isBefore(LocalDate.now())) title = "Financeiro · mensalidade vencida";
                else title = "Financeiro · mensalidade vence hoje";
            } catch (Exception e) {
                title = "Financeiro · vencimento de mensalidade";
            }
        }
        String chargeMessage = paymentChargeMessage(student, dueDate, pix);
        PendingIntent chargeIntent = buildWhatsAppPendingIntent(context, notificationId, phone, chargeMessage, "charge");
        String message = student + (dueDate.isEmpty() ? "" : " · vencimento " + brDate(dueDate));

        android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new android.app.Notification.Builder(context, PAYMENT_CHANNEL_ID)
                : new android.app.Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setCategory(android.app.Notification.CATEGORY_REMINDER)
                .setPriority(android.app.Notification.PRIORITY_HIGH)
                .setVisibility(android.app.Notification.VISIBILITY_PRIVATE)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (chargeIntent != null) builder.addAction(android.R.drawable.ic_menu_send, "Cobrar no WhatsApp", chargeIntent);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setSound(Settings.System.DEFAULT_NOTIFICATION_URI);
            builder.setVibrate(new long[]{0, 300, 180, 300});
        }
        if (nm != null) {
            try { nm.notify(key, AlarmScheduler.NOTIFICATION_ID, builder.build()); }
            catch (SecurityException ignored) {}
        }
    }


    private static String paymentChargeMessage(String student, String dueDate, String pix) {
        StringBuilder text = new StringBuilder("Olá, ").append(student).append(". ");
        try {
            LocalDate due = LocalDate.parse(dueDate);
            if (due.isBefore(LocalDate.now())) text.append("Sua mensalidade venceu em ").append(brDate(dueDate)).append(".");
            else if (due.isEqual(LocalDate.now())) text.append("Sua mensalidade vence hoje (").append(brDate(dueDate)).append(").");
            else text.append("Sua mensalidade vence em ").append(brDate(dueDate)).append(".");
        } catch (Exception e) {
            text.append("Sua mensalidade está com vencimento pendente.");
        }
        if (pix != null && !pix.trim().isEmpty()) text.append(" Para pagamento via PIX, chave: ").append(pix.trim()).append(".");
        text.append(" Obrigado.");
        return text.toString();
    }

    private static String brDate(String iso) {
        try {
            String[] p = iso.split("-");
            return p[2] + "/" + p[1] + "/" + p[0];
        } catch (Exception e) { return iso; }
    }

    private static PendingIntent mainPendingIntent(Context context, int notificationId, String path) {
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.setData(Uri.parse("agenda-personal://" + path));
        return PendingIntent.getActivity(context, notificationId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent buildWhatsAppPendingIntent(Context context, int notificationId, String phone,
                                                             String message, String suffix) {
        String digits = phone == null ? "" : phone.replaceAll("\\D", "");
        if (digits.isEmpty()) return null;
        if ((digits.length() == 10 || digits.length() == 11) && !digits.startsWith("55")) digits = "55" + digits;
        try {
            Uri uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(message == null ? "" : message));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            int code = (String.valueOf(notificationId) + "|" + suffix).hashCode() & 0x7fffffff;
            return PendingIntent.getActivity(context, code, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        } catch (Exception e) {
            return null;
        }
    }

    private static PendingIntent buildRoutePendingIntent(Context context, int notificationId, String location) {
        if (location == null || location.trim().isEmpty()) return null;
        try {
            String directLink = MapLinks.directGoogleMapsLink(location);
            Uri uri = Uri.parse(directLink != null
                    ? directLink : "geo:0,0?q=" + Uri.encode(location.trim()));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            int code = (String.valueOf(notificationId) + "|route").hashCode() & 0x7fffffff;
            return PendingIntent.getActivity(context, code, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        } catch (Exception e) {
            return null;
        }
    }

    public static void createChannel(NotificationManager nm) {
        if (nm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationChannel lessonChannel = new NotificationChannel(
                CHANNEL_ID,
                "Alarmes das aulas",
                NotificationManager.IMPORTANCE_HIGH
        );
        lessonChannel.setDescription("Avisos de aulas da Agenda Personal com WhatsApp e rota");
        lessonChannel.enableVibration(true);
        lessonChannel.setVibrationPattern(new long[]{0, 600, 250, 600, 250, 600});
        lessonChannel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
        Uri sound = Settings.System.DEFAULT_ALARM_ALERT_URI;
        AudioAttributes alarmAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        lessonChannel.setSound(sound, alarmAttributes);
        nm.createNotificationChannel(lessonChannel);

        NotificationChannel paymentChannel = new NotificationChannel(
                PAYMENT_CHANNEL_ID,
                "Lembretes financeiros",
                NotificationManager.IMPORTANCE_HIGH
        );
        paymentChannel.setDescription("Vencimentos de mensalidades e atalhos de cobrança");
        paymentChannel.enableVibration(true);
        paymentChannel.setVibrationPattern(new long[]{0, 300, 180, 300});
        paymentChannel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PRIVATE);
        Uri notificationSound = Settings.System.DEFAULT_NOTIFICATION_URI;
        AudioAttributes notificationAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        paymentChannel.setSound(notificationSound, notificationAttributes);
        nm.createNotificationChannel(paymentChannel);
    }
}
