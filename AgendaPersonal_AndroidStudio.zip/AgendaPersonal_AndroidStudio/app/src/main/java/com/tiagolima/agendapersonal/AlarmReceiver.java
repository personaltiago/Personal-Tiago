package com.tiagolima.agendapersonal;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import org.json.JSONObject;
import java.time.LocalDate;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "agenda_personal_alarmes_v2";
    public static final String TIMER_CHANNEL_ID = "agenda_personal_fim_aula_v1";
    public static final String PAYMENT_CHANNEL_ID = "agenda_personal_financeiro_v1";
    static final String WORKOUT_REST_CHANNEL_ID = "agenda_personal_intervalo_v1";
    static final String STOP_ACTION = "com.tiagolima.agendapersonal.STOP_ALARM";

    @Override
    public void onReceive(Context context, Intent intent) {
        synchronized (AlarmScheduler.class) {
            if (STOP_ACTION.equals(intent.getAction())) {
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                String tag = intent.getStringExtra("notificationTag");
                if (nm != null && tag != null) nm.cancel(tag, AlarmScheduler.NOTIFICATION_ID);
                return;
            }
            JSONObject plan = AlarmScheduler.pending(context, intent);
            if (plan == null) return;
            boolean accepted = "workout-rest".equals(plan.optString("kind")) ? showWorkoutRestNotification(context, plan) : "payment".equals(plan.optString("kind"))
                    ? showPaymentNotification(context, plan) : showLessonNotification(context, plan);
            if (accepted) AlarmScheduler.complete(context, plan);
        }
    }

    private static boolean showWorkoutRestNotification(Context context, JSONObject plan) {
        createChannel(context);
        if (!AlarmStatus.notificationsAllowed(context, WORKOUT_REST_CHANNEL_ID)) {
            AlarmStore.recordDelivery(context, "Intervalo não publicado: notificações bloqueadas.");
            return false;
        }
        NotificationManager notifications = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String message = plan.optString("student", "Aluno") + " · " + plan.optString("exercise", "Exercício");
        PendingIntent open = mainPendingIntent(context, 31, "workout-rest");
        try {
            android.app.Notification notification = new android.app.Notification.Builder(context, WORKOUT_REST_CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Intervalo encerrado")
                    .setContentText(message).setStyle(new android.app.Notification.BigTextStyle().bigText(message))
                    .setAutoCancel(true).setContentIntent(open).setCategory(android.app.Notification.CATEGORY_ALARM)
                    .setPriority(android.app.Notification.PRIORITY_MAX).setTimeoutAfter(30_000L).build();
            notifications.notify(AlarmScheduler.WORKOUT_REST_KEY, AlarmScheduler.NOTIFICATION_ID, notification);
            return true;
        } catch (RuntimeException error) { return false; }
    }

    private static boolean showLessonNotification(Context context, JSONObject plan) {
        String student = plan.optString("student", "Aluno");
        String location = plan.optString("location", "");
        String phone = plan.optString("phone", "");
        String lessonTime = plan.optString("lessonTime", "");
        int leadMinutes = plan.optInt("leadMinutes", 15);
        boolean test = "test".equals(plan.optString("kind"));
        boolean timer = "timer".equals(plan.optString("kind"));
        String occurrenceKey = test ? "alarm-test" : plan.optString("lessonId") + "|" + plan.optString("classDate");
        int notificationId = occurrenceKey.hashCode() & 0x7fffffff;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel(context);
        String issue = AlarmStatus.soundIssue(context);
        if (!issue.isEmpty()) {
            AlarmStore.recordDelivery(context, "Aviso não publicado: " + issue);
            return false;
        }

        PendingIntent contentIntent = mainPendingIntent(context, notificationId, "lesson/" + Uri.encode(occurrenceKey));
        PendingIntent whatsAppIntent = buildWhatsAppPendingIntent(context, notificationId, phone, "Olá, " + student + ".", "wa");
        PendingIntent routeIntent = buildRoutePendingIntent(context, notificationId, location);

        long classAt = plan.optLong("classAtMillis");
        int remaining = classAt > 0 ? (int) Math.max(0, Math.ceil((classAt - System.currentTimeMillis()) / 60_000d)) : leadMinutes;
        String title = timer ? "Agenda Personal · fim da aula" : test ? "Agenda Personal · teste do despertador" : remaining > 0
                ? "Agenda Personal · aula em " + remaining + " min"
                : "Agenda Personal · hora da aula";
        String message = timer ? "Tempo encerrado para " + student + "."
                : test ? "Toque em Parar para encerrar o teste." : student + (location.isEmpty() ? "" : " — " + location)
                + (lessonTime.isEmpty() ? "" : " · " + lessonTime);

        android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new android.app.Notification.Builder(context, timer ? AudioSettings.timerChannelId(context) : AudioSettings.lessonChannelId(context))
                : new android.app.Notification.Builder(context);

        builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setCategory(android.app.Notification.CATEGORY_ALARM)
                .setPriority(android.app.Notification.PRIORITY_MAX)
                .setVisibility(android.app.Notification.VISIBILITY_PUBLIC)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        // O som do canal usa USAGE_ALARM. O Android repete o toque sem depender do WebView.
        builder.setTimeoutAfter(120_000L);
        Intent stop = new Intent(context, AlarmReceiver.class).setAction(STOP_ACTION)
                .setData(Uri.parse("agenda-personal://stop/" + Uri.encode(occurrenceKey)))
                .putExtra("notificationTag", occurrenceKey);
        PendingIntent stopIntent = PendingIntent.getBroadcast(context, 0, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        builder.addAction(android.R.drawable.ic_media_pause, "Parar", stopIntent);

        if (!timer && whatsAppIntent != null) builder.addAction(android.R.drawable.ic_menu_send, "WhatsApp", whatsAppIntent);
        if (!timer && routeIntent != null) builder.addAction(android.R.drawable.ic_menu_mylocation, "Rota", routeIntent);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setSound(Settings.System.DEFAULT_ALARM_ALERT_URI);
            builder.setVibrate(new long[]{0, 600, 250, 600, 250, 600});
        }

        try {
            android.app.Notification notification = builder.build();
            notification.flags |= android.app.Notification.FLAG_INSISTENT;
            nm.notify(occurrenceKey, AlarmScheduler.NOTIFICATION_ID, notification);
            return true;
        } catch (RuntimeException e) {
            AlarmStore.recordDelivery(context, "Falha ao publicar o alarme: " + e.getMessage());
            return false;
        }
    }

    private static boolean showPaymentNotification(Context context, JSONObject plan) {
        String student = plan.optString("student", "Aluno");
        String phone = plan.optString("phone", "");
        String dueDate = plan.optString("dueDate", "");
        String stage = plan.optString("stage", "due");
        int reminderDays = plan.optInt("reminderDays", 0);
        String pix = plan.optString("pix", "");
        String key = plan.optString("alarmKey", "payment");
        int notificationId = key.hashCode() & 0x7fffffff;

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel(context);
        if (!AlarmStatus.notificationsAllowed(context, PAYMENT_CHANNEL_ID)) {
            AlarmStore.recordDelivery(context, "Aviso financeiro não publicado: notificações bloqueadas.");
            return false;
        }
        PendingIntent contentIntent = mainPendingIntent(context, notificationId, "finance/" + Uri.encode(plan.optString("studentId", "")));

        String title;
        if ("before".equals(stage)) title = "Financeiro · vence em " + reminderDays + (reminderDays == 1 ? " dia" : " dias");
        else {
            try {
                LocalDate due = LocalDate.parse(dueDate);
                if (due.isBefore(LocalDate.now())) title = "Financeiro · mensalidade vencida";
                else title = "Financeiro · mensalidade vence hoje";
            } catch (Exception e) {
                title = "Financeiro · vencimento de mensalidade";
            }
        }
        String chargeMessage = paymentChargeMessage(student, dueDate, pix);
        PendingIntent chargeIntent = buildWhatsAppPendingIntent(context, notificationId, phone, chargeMessage, "charge");
        String message = student + (dueDate.isEmpty() ? "" : " · vencimento " + brDate(dueDate));

        android.app.Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new android.app.Notification.Builder(context, PAYMENT_CHANNEL_ID)
                : new android.app.Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setCategory(android.app.Notification.CATEGORY_REMINDER)
                .setPriority(android.app.Notification.PRIORITY_HIGH)
                .setVisibility(android.app.Notification.VISIBILITY_PRIVATE)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (chargeIntent != null) builder.addAction(android.R.drawable.ic_menu_send, "Cobrar no WhatsApp", chargeIntent);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setSound(Settings.System.DEFAULT_NOTIFICATION_URI);
            builder.setVibrate(new long[]{0, 300, 180, 300});
        }
        try { nm.notify(key, AlarmScheduler.NOTIFICATION_ID, builder.build()); return true; }
        catch (RuntimeException e) {
            AlarmStore.recordDelivery(context, "Falha ao publicar o aviso financeiro: " + e.getMessage());
            return false;
        }
    }


    private static String paymentChargeMessage(String student, String dueDate, String pix) {
        StringBuilder text = new StringBuilder("Olá, ").append(student).append(". ");
        try {
            LocalDate due = LocalDate.parse(dueDate);
            if (due.isBefore(LocalDate.now())) text.append("Sua mensalidade venceu em ").append(brDate(dueDate)).append(".");
            else if (due.isEqual(LocalDate.now())) text.append("Sua mensalidade vence hoje (").append(brDate(dueDate)).append(").");
            else text.append("Sua mensalidade vence em ").append(brDate(dueDate)).append(".");
        } catch (Exception e) {
            text.append("Sua mensalidade está com vencimento pendente.");
        }
        if (pix != null && !pix.trim().isEmpty()) text.append(" Para pagamento via PIX, chave: ").append(pix.trim()).append(".");
        text.append(" Obrigado.");
        return text.toString();
    }

    private static String brDate(String iso) {
        try {
            String[] p = iso.split("-");
            return p[2] + "/" + p[1] + "/" + p[0];
        } catch (Exception e) { return iso; }
    }

    private static PendingIntent mainPendingIntent(Context context, int notificationId, String path) {
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.setData(Uri.parse("agenda-personal://" + path));
        return PendingIntent.getActivity(context, notificationId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent buildWhatsAppPendingIntent(Context context, int notificationId, String phone,
                                                             String message, String suffix) {
        String digits = phone == null ? "" : phone.replaceAll("\\D", "");
        if (digits.isEmpty()) return null;
        if ((digits.length() == 10 || digits.length() == 11) && !digits.startsWith("55")) digits = "55" + digits;
        try {
            Uri uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(message == null ? "" : message));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            int code = (String.valueOf(notificationId) + "|" + suffix).hashCode() & 0x7fffffff;
            return PendingIntent.getActivity(context, code, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        } catch (Exception e) {
            return null;
        }
    }

    private static PendingIntent buildRoutePendingIntent(Context context, int notificationId, String location) {
        if (location == null || location.trim().isEmpty()) return null;
        try {
            String directLink = MapLinks.directGoogleMapsLink(location);
            Uri uri = Uri.parse(directLink != null
                    ? directLink : "geo:0,0?q=" + Uri.encode(location.trim()));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            int code = (String.valueOf(notificationId) + "|route").hashCode() & 0x7fffffff;
            return PendingIntent.getActivity(context, code, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        } catch (Exception e) {
            return null;
        }
    }

    public static void createChannel(NotificationManager nm) {
        if (nm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        createChannel(nm, CHANNEL_ID, "Alarmes das aulas", "Avisos de aulas da Agenda Personal com WhatsApp e rota",
                new long[]{0, 600, 250, 600, 250, 600}, Settings.System.DEFAULT_ALARM_ALERT_URI);
        createChannel(nm, TIMER_CHANNEL_ID, "Fim da aula", "Toque específico quando o cronômetro da aula termina",
                new long[]{0, 900, 180, 900, 180, 1200}, Settings.System.DEFAULT_ALARM_ALERT_URI);
        createChannel(nm, WORKOUT_REST_CHANNEL_ID, "Intervalo do treino", "Aviso curto ao terminar o intervalo entre exercícios",
                new long[]{0, 200, 100, 200}, Settings.System.DEFAULT_ALARM_ALERT_URI);
        createPaymentChannel(nm);
    }

    public static void createChannel(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        createChannel(nm, CHANNEL_ID, "Alarmes das aulas", "Avisos de aulas da Agenda Personal com WhatsApp e rota",
                new long[]{0, 600, 250, 600, 250, 600}, Settings.System.DEFAULT_ALARM_ALERT_URI);
        createChannel(nm, TIMER_CHANNEL_ID, "Fim da aula", "Toque específico quando o cronômetro da aula termina",
                new long[]{0, 900, 180, 900, 180, 1200}, Settings.System.DEFAULT_ALARM_ALERT_URI);
        createChannel(nm, WORKOUT_REST_CHANNEL_ID, "Intervalo do treino", "Aviso curto ao terminar o intervalo entre exercícios",
                new long[]{0, 200, 100, 200}, Settings.System.DEFAULT_ALARM_ALERT_URI);
        Uri lessonSound = AudioSettings.lessonSound(context);
        if (lessonSound != null) {
            createChannel(nm, AudioSettings.lessonChannelId(context), "Alarmes das aulas · personalizado",
                    "Avisos das aulas com o áudio escolhido no aplicativo",
                    new long[]{0, 600, 250, 600, 250, 600}, lessonSound);
        }
        Uri timerSound = AudioSettings.timerSound(context);
        if (timerSound != null) {
            createChannel(nm, AudioSettings.timerChannelId(context), "Fim da aula · personalizado",
                    "Fim do cronômetro com o áudio escolhido no aplicativo",
                    new long[]{0, 900, 180, 900, 180, 1200}, timerSound);
        }
        createPaymentChannel(nm);
    }

    private static void createChannel(NotificationManager nm, String id, String name, String description,
                                      long[] vibration, Uri sound) {
        NotificationChannel lessonChannel = new NotificationChannel(
                id,
                name,
                NotificationManager.IMPORTANCE_HIGH
        );
        lessonChannel.setDescription(description);
        lessonChannel.enableVibration(true);
        lessonChannel.setVibrationPattern(vibration);
        lessonChannel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
        AudioAttributes alarmAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        lessonChannel.setSound(sound, alarmAttributes);
        nm.createNotificationChannel(lessonChannel);
    }

    private static void createPaymentChannel(NotificationManager nm) {
        NotificationChannel paymentChannel = new NotificationChannel(
                PAYMENT_CHANNEL_ID,
                "Lembretes financeiros",
                NotificationManager.IMPORTANCE_HIGH
        );
        paymentChannel.setDescription("Vencimentos de mensalidades e atalhos de cobrança");
        paymentChannel.enableVibration(true);
        paymentChannel.setVibrationPattern(new long[]{0, 300, 180, 300});
        paymentChannel.setLockscreenVisibility(android.app.Notification.VISIBILITY_PRIVATE);
        Uri notificationSound = Settings.System.DEFAULT_NOTIFICATION_URI;
        AudioAttributes notificationAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        paymentChannel.setSound(notificationSound, notificationAttributes);
        nm.createNotificationChannel(paymentChannel);
    }
}
