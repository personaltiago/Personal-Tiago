package com.tiagolima.agendapersonal;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class AlarmStore {
    private static final String PREFS = "agenda_personal_native_alarms";
    private static final String PLAN = "plan_";
    private static final String DELIVERED = "delivered_";
    private AlarmStore() {}

    static boolean saveSnapshot(Context context, JSONObject snapshot) {
        return prefs(context).edit().putString("agenda_snapshot", snapshot.toString()).commit();
    }
    static JSONObject snapshot(Context context) {
        String value = prefs(context).getString("agenda_snapshot", null);
        if (value == null) return null;
        try { return new JSONObject(value); }
        catch (Exception e) { return null; }
    }
    static void savePlan(Context context, JSONObject plan) throws Exception {
        if (!prefs(context).edit().putString(PLAN + plan.getString("alarmKey"), plan.toString()).commit()) {
            throw new IllegalStateException("Não foi possível guardar o alarme programado");
        }
    }
    static JSONObject plan(Context context, String key) {
        String value = prefs(context).getString(PLAN + key, null);
        if (value == null) return null;
        try { return new JSONObject(value); }
        catch (Exception e) { return null; }
    }
    static void removePlan(Context context, String key) {
        prefs(context).edit().remove(PLAN + key).apply();
    }
    static List<JSONObject> plans(Context context) { return entries(context, PLAN); }
    static List<JSONObject> legacyPlans(Context context) { return entries(context, "alarm_"); }
    static void removeLegacy(Context context, int requestCode) {
        prefs(context).edit().remove("alarm_" + requestCode).apply();
    }
    static boolean markDelivered(Context context, String lessonId, String date) {
        return prefs(context).edit().putBoolean(DELIVERED + lessonId + "|" + date, true).commit();
    }
    private static String lessonSignature(JSONObject lesson) {
        return lesson.optString("lessonTime", lesson.optString("time")) + "|"
                + lesson.optInt("leadMinutes", lesson.optInt("lead", 15));
    }
    static boolean markLessonDelivered(Context context, JSONObject plan) {
        String key = plan.optString("lessonId") + "|" + plan.optString("classDate");
        return prefs(context).edit().putBoolean(DELIVERED + key, true)
                .putString("delivered_signature_" + key, lessonSignature(plan)).commit();
    }
    static boolean matchesLessonDelivery(Context context, JSONObject lesson, String date) {
        String id = lesson.optString("lessonId", lesson.optString("id"));
        String signature = prefs(context).getString("delivered_signature_" + id + "|" + date, null);
        // Versões anteriores não guardavam o horário; não repetir seus avisos após atualizar.
        return signature == null || signature.equals(lessonSignature(lesson));
    }
    static Set<String> deliveredDatesForLesson(Context context, JSONObject lesson) {
        Set<String> dates = deliveredDates(context, lesson.optString("id"));
        dates.removeIf(date -> !matchesLessonDelivery(context, lesson, date));
        return dates;
    }
    static Set<String> deliveredDates(Context context, String lessonId) {
        Set<String> result = new HashSet<>();
        String prefix = DELIVERED + lessonId + "|";
        for (Map.Entry<String, ?> entry : prefs(context).getAll().entrySet()) {
            if (entry.getKey().startsWith(prefix) && Boolean.TRUE.equals(entry.getValue())) {
                result.add(entry.getKey().substring(prefix.length()));
            }
        }
        return result;
    }
    static void recordDelivery(Context context, String message) {
        prefs(context).edit().putString("last_delivery", message)
                .putLong("last_delivery_at", System.currentTimeMillis()).apply();
    }
    static String lastDelivery(Context context) {
        return prefs(context).getString("last_delivery", "Nenhum disparo registrado nesta versão.");
    }
    private static List<JSONObject> entries(Context context, String prefix) {
        List<JSONObject> result = new ArrayList<>();
        for (Map.Entry<String, ?> entry : prefs(context).getAll().entrySet()) {
            if (!entry.getKey().startsWith(prefix) || !(entry.getValue() instanceof String)) continue;
            try { result.add(new JSONObject((String) entry.getValue())); }
            catch (Exception ignored) {}
        }
        return result;
    }
    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
