const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const runtime=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/'):require;
const {chromium}=runtime('playwright');
const {fixture,init,openDay,create,start,complete,fits,server}=require('./verify_bisets.cjs');
const qa=path.resolve(__dirname,'../../qa');fs.mkdirSync(qa,{recursive:true});
const stored=page=>page.evaluate(()=>JSON.parse(localStorage.getItem('agendaPersonalTL_v1')));
const exercises=page=>page.evaluate(()=>currentWorkoutDay().exercises);
const byId=items=>items.toSorted((a,b)=>a.id.localeCompare(b.id));
async function techniques(page,id){await page.locator('#workoutDayContent [data-technique-exercise="'+id+'"] button').first().click()}
async function partners(page,id){await techniques(page,id);await page.locator('#workoutTechniquesContent [data-preset-id="bi-set"]').click()}
async function savePair(page){await page.locator('#workoutBisetForm button[type=submit]').click()}
async function picture(page,selector,name){await page.evaluate(()=>document.getElementById('toast').style.display='none');await page.locator(selector).screenshot({path:path.join(qa,name+'.png')})}
async function assemblyCount(page){return page.locator('#workoutDayContent .wt-exercise-controls,#workoutDayContent .biset-create,#workoutDayContent .biset-tools,#workoutDayContent [onclick="openWorkoutExerciseEditor()"]:visible,#workoutDayContent .exercise-edit:visible,#workoutDayContent .workout-move:visible,#workoutDayContent [onclick="toggleWorkoutExerciseOrdering()"]:visible').count()}
async function main(){
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({executablePath:process.env.AGENDA_CHROMIUM,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const checks=[],layouts=[],errors=[];
 const launch=async(data=fixture)=>{
  const c=await browser.newContext({viewport:{width:393,height:852},isMobile:true,hasTouch:true,timezoneId:'America/Cuiaba'});await init(c,data);
  const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));p.on('dialog',d=>d.accept());await p.clock.install({time:new Date('2026-10-09T12:00:00Z')});await p.goto('http://127.0.0.1:'+server.address().port+'/index.html');await p.waitForFunction(()=>__ready);await openDay(p);return {c,p};
 };
 try{
  let {c,p}=await launch();
  assert.equal(await p.locator('#workoutDayContent .wt-exercise-controls').count(),5);assert.equal(await p.locator('#workoutDayContent .biset-create').count(),0);
  assert.equal(await p.evaluate(()=>Array.from(document.querySelectorAll('#workoutDayContent .wt-exercise-controls')).every(n=>n===n.parentElement.lastElementChild)),true);
  await picture(p,'#workoutDayContent .workout-exercise[data-exercise-id="a"]','Tecnicas_abaixo_do_exercicio');
  await partners(p,'a');assert.match(await p.locator('#workoutBisetPartnerReference').innerText(),/Rosca direta/);assert.equal(await p.locator('#workoutBisetPartnerContent [data-partner-id="a"]').count(),0);assert.equal(await p.locator('#workoutBisetPartnerContent [data-partner-id="b"]').count(),1);
  await p.locator('#workoutBisetPartnerSearch').fill('TRICEPS');assert.equal(await p.locator('#workoutBisetPartnerContent .wt-preset').count(),1);assert.match(await p.locator('#workoutBisetPartnerContent').innerText(),/Tríceps na polia/);await p.locator('#workoutBisetPartnerSearch').fill('');
  await picture(p,'#workoutBisetPartnerDialog .sheet','Bi_set_lista_parceiros');
  await p.evaluate(()=>handleAgendaSystemBack());assert.equal(await p.locator('#workoutTechniquesDialog.open').count(),1);await p.evaluate(()=>handleAgendaSystemBack());assert.equal(await p.locator('#workoutDayDialog.open').count(),1);
  assert.deepEqual((await stored(p)).workoutPlans[0],fixture.workoutPlans[0]);checks.push('Botões sob cada exercício; bi-set no menu; lista vinculada, busca sem acentos e voltar sem alterar a ficha');
  await partners(p,'a');await p.locator('#workoutBisetPartnerContent [data-partner-id="b"]').click();
  assert.equal(await p.locator('#workoutBisetSelectors').isVisible(),false);assert.equal(await p.locator('#workoutBisetFixedPair').isVisible(),true);assert.equal(await p.locator('#workoutBisetExerciseA').inputValue(),'a');assert.equal(await p.locator('#workoutBisetExerciseB').inputValue(),'b');
  await p.locator('#workoutBisetRest').fill('75');await p.evaluate(()=>__failSave=true);await savePair(p);assert.equal(await p.locator('#workoutBisetEditorDialog.open').count(),1);assert.equal((await stored(p)).workoutPlans[0].days[0].bisets?.length||0,0);await p.evaluate(()=>__failSave=false);await savePair(p);
  let group=(await stored(p)).workoutPlans[0].days[0].bisets[0];assert.deepEqual(group.exerciseIds,['a','b']);assert.equal(group.restSeconds,75);assert.deepEqual(byId(await exercises(p)),byId(fixture.workoutPlans[0].days[0].exercises));assert.equal(await p.locator('#workoutDayContent .wt-exercise-controls').count(),5);checks.push('Selecionar parceiro fixa A/B; falha de gravação mantém a seleção; salvar preserva os dois exercícios');
  await create(p,'e','f',2,0);await partners(p,'b');assert.equal(await p.locator('#workoutBisetPartnerContent [data-partner-id="e"]').isDisabled(),true);assert.equal(await p.locator('#workoutBisetPartnerContent [data-partner-id="a"]').isDisabled(),false);
  await p.locator('#workoutBisetPartnerContent [data-partner-id="c"]').click();assert.equal(await p.locator('#workoutBisetExerciseA').inputValue(),'c');assert.equal(await p.locator('#workoutBisetExerciseB').inputValue(),'b');assert.equal(await p.locator('#workoutBisetRest').inputValue(),'75');
  await p.locator('#workoutBisetRest').fill('95');await p.locator('#workoutBisetChangePartner').click();assert.match(await p.locator('#workoutBisetPartnerReference').innerText(),/Rosca martelo/);await p.locator('#workoutBisetPartnerContent [data-partner-id="c"]').click();assert.equal(await p.locator('#workoutBisetRest').inputValue(),'95');
  await p.evaluate(()=>handleAgendaSystemBack());assert.deepEqual((await stored(p)).workoutPlans[0].days[0].bisets[0].exerciseIds,['a','b']);
  await partners(p,'b');await p.locator('#workoutBisetPartnerContent [data-partner-id="c"]').click();await savePair(p);group=(await stored(p)).workoutPlans[0].days[0].bisets.find(g=>g.id===group.id);assert.deepEqual(group.exerciseIds,['c','b']);assert.deepEqual(byId(await exercises(p)),byId(fixture.workoutPlans[0].days[0].exercises));
  await partners(p,'b');await p.locator('#workoutBisetPartnerContent [data-partner-id="c"]').click();await p.getByRole('button',{name:'Desfazer dupla e manter exercícios',exact:true}).click();assert.equal((await stored(p)).workoutPlans[0].days[0].bisets.length,1);assert.deepEqual(byId(await exercises(p)),byId(fixture.workoutPlans[0].days[0].exercises));checks.push('Escolher por B mantém sua posição; parceiro ocupado fica bloqueado; trocar, cancelar e desfazer preservam os exercícios');
  await c.close();

  const single=structuredClone(fixture);single.workoutPlans[0].days[0].exercises=single.workoutPlans[0].days[0].exercises.slice(0,1);
  const catalog={id:'catalog-partner',source:'mine',name:'Rosca alternada <controle>',sets:'3',reps:'12',load:'7 kg',rest:'45 s',muscle:'Bíceps',category:'Musculação',video:'https://youtu.be/aqz-KE-bpKQ',notes:'Exercício de referência.',observations:'Carga por halter.'};
  single.exerciseCatalog=[catalog,{...catalog,id:'blocked-partner',name:'Parceiro bloqueado',guidanceStatus:'blocked'}];
  ({c,p}=await launch(single));await partners(p,'a');assert.equal(await p.locator('#workoutBisetPartnerContent .wt-preset').count(),0);assert.match(await p.locator('#workoutBisetPartnerContent').innerText(),/Escolha Catálogo/);
  await p.locator('#workoutBisetPartnerCatalog').click();assert.equal(await p.locator('#workoutBisetPartnerContent [data-partner-id="blocked-partner"]').count(),0);
  const initial=await p.locator('#workoutBisetPartnerContent .wt-preset').count();assert.ok(initial>0&&initial<=48);if(await p.locator('#workoutBisetPartnerMore').isVisible()){await p.locator('#workoutBisetPartnerMore').click();assert.ok(await p.locator('#workoutBisetPartnerContent .wt-preset').count()>initial)}
  await p.locator('#workoutBisetPartnerSearch').fill('Rosca alternada <controle>');assert.equal(await p.locator('#workoutBisetPartnerContent .wt-preset').count(),1);assert.equal(await p.locator('#workoutBisetPartnerContent controle').count(),0);
  await p.locator('#workoutBisetPartnerContent [data-partner-id="catalog-partner"]').click();assert.equal(await p.locator('#workoutExerciseDialog.open').count(),1);assert.match(await p.locator('#workoutBisetCatalogHint').innerText(),/Rosca direta/);assert.equal(await p.locator('#workoutExerciseVideo').inputValue(),catalog.video);assert.equal(await p.locator('#workoutExerciseReps').inputValue(),'12');
  await p.evaluate(()=>handleAgendaSystemBack());assert.equal((await stored(p)).workoutPlans[0].days[0].exercises.length,1);assert.equal(await p.locator('#workoutDayDialog.open').count(),1);
  await partners(p,'a');await p.locator('#workoutBisetPartnerCatalog').click();await p.locator('#workoutBisetPartnerSearch').fill('Rosca alternada <controle>');await p.locator('#workoutBisetPartnerContent [data-partner-id="catalog-partner"]').click();
  await p.locator('#workoutExerciseReps').fill('10');await p.evaluate(()=>__failSave=true);await p.locator('#workoutExerciseForm button[type=submit]').click();assert.equal(await p.locator('#workoutExerciseDialog.open').count(),1);assert.equal(await p.locator('#workoutBisetEditorDialog.open').count(),0);assert.equal((await stored(p)).workoutPlans[0].days[0].exercises.length,1);
  await p.evaluate(()=>__failSave=false);await p.locator('#workoutExerciseForm button[type=submit]').click();assert.equal(await p.locator('#workoutBisetEditorDialog.open').count(),1);const added=(await exercises(p)).find(e=>e.id!=='a');assert.ok(added);assert.equal(added.video,catalog.video);assert.equal(added.catalogId,catalog.id);assert.equal(added.reps,'10');assert.equal(added.notes,catalog.notes);assert.equal((await stored(p)).workoutPlans[0].days[0].bisets?.length||0,0);
  await p.evaluate(()=>handleAgendaSystemBack());assert.equal((await exercises(p)).length,2);assert.equal((await stored(p)).workoutPlans[0].days[0].bisets?.length||0,0);
  await partners(p,'a');await p.locator('#workoutBisetPartnerContent [data-partner-id="'+added.id+'"]').click();await savePair(p);group=(await stored(p)).workoutPlans[0].days[0].bisets[0];assert.deepEqual(group.exerciseIds,['a',added.id]);assert.deepEqual((await stored(p)).customData,fixture.customData);checks.push('Catálogo funciona com um só exercício: filtra bloqueados, pagina, revisa metas e vídeo, trata falha e cancelamento sem criar dupla');
  await c.close();

  ({c,p}=await launch());await create(p);group=(await stored(p)).workoutPlans[0].days[0].bisets[0];
  await p.evaluate(()=>openWorkoutExerciseEditor('c'));await p.locator('#workoutExerciseName').fill('Alteração pendente');const before=(await stored(p)).workoutPlans[0];
  await p.evaluate(()=>{document.getElementById('workoutTimerMinutes').value='45';startWorkoutSession()});assert.equal(await p.locator('#workoutExerciseDialog.open').count(),0);assert.equal(await assemblyCount(p),0);
  await p.evaluate(g=>{openWorkoutExerciseEditor('c');saveWorkoutExercise({preventDefault(){}});openWorkoutTechniquesForExercise('c');openWorkoutBisetEditor(g);saveWorkoutBiset({preventDefault(){}});removeWorkoutBiset();toggleWorkoutExerciseOrdering();moveWorkoutExercise('c',-1);deleteWorkoutExercise()},group.id);
  assert.deepEqual((await stored(p)).workoutPlans[0],before);assert.equal(await p.locator('#workoutExerciseDialog.open,#workoutTechniquesDialog.open,#workoutBisetEditorDialog.open').count(),0);assert.equal(await assemblyCount(p),0);
  assert.equal(await p.locator('#workoutDayContent input[data-exercise-id="c"][data-field="load"]').isVisible(),true);assert.equal(await p.getByRole('button',{name:'Finalizar treino',exact:true}).isVisible(),true);
  await p.evaluate(id=>openWorkoutBiset(id),group.id);assert.equal(await p.locator('#workoutBisetContent [aria-label="Assistir vídeo de Rosca direta"]').isVisible(),true);await complete(p,'21 kg',10);await p.evaluate(()=>closeDialog('workoutBisetDialog'));
  await picture(p,'#workoutDayContent .workout-exercise[data-exercise-id="c"]','Treino_ativo_sem_montagem');
  await p.reload();await p.waitForFunction(()=>__ready);await openDay(p);assert.equal(await assemblyCount(p),0);
  await p.getByRole('button',{name:'Limpar marcações',exact:true}).click();assert.equal(await assemblyCount(p),0);await p.getByRole('button',{name:'Reiniciar treino',exact:true}).click();assert.equal(await assemblyCount(p),0);
  await p.locator('#workoutDayContent input[data-exercise-id="c"][data-field="load"]').fill('18 kg');await p.locator('#workoutDayContent input[data-exercise-id="c"][type=checkbox]').check();await p.getByRole('button',{name:'Finalizar treino',exact:true}).click();await p.locator('#workoutExecutionForm button[type=submit]').click();assert.equal(await p.locator('#workoutDayContent .wt-exercise-controls').count(),5);assert.equal(await p.locator('#workoutDayContent [onclick="openWorkoutExerciseEditor()"]:visible').count(),1);assert.equal((await stored(p)).workoutExecutions[0].exercises[0].load,'18 kg');checks.push('Início fecha montagem pendente, esconde e bloqueia edição antes da primeira série; retomada, limpar e reiniciar mantêm o bloqueio; finalizar devolve a montagem');
  await p.evaluate(()=>{closeDialog('workoutDayDialog');openWorkoutAudience()});assert.equal(await p.locator('#workoutAudienceContent .wt-exercise-controls,#workoutAudienceContent .biset-tools').count(),0);await p.locator('#workoutAudienceContent [data-biset-id]').getByRole('button',{name:'Iniciar bi-set',exact:true}).click();assert.equal(await assemblyCount(p),0);await start(p);assert.equal(await assemblyCount(p),0);await c.close();checks.push('Visualização e execução do aluno mantêm os controles de montagem ocultos');

  for(const [width,height,fontSize] of [[320,740,16],[393,852,16],[393,852,20],[852,393,16]]){
   const cx=await browser.newContext({viewport:{width,height},isMobile:width<600,hasTouch:true,timezoneId:'America/Cuiaba'});await init(cx,fixture,'deep-tl',fontSize);const page=await cx.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:'+server.address().port+'/index.html');await page.waitForFunction(()=>__ready);await openDay(page);assert.equal(await fits(page),'');await partners(page,'a');assert.equal(await fits(page),'');await page.locator('#workoutBisetPartnerContent [data-partner-id="b"]').click();assert.equal(await fits(page),'');await picture(page,'#workoutBisetEditorDialog .sheet',`layout-parceiro-${width}-${fontSize}`);layouts.push({width,height,fontSize,exercise:true,partnerList:true,fixedPair:true});await cx.close();
  }
  assert.deepEqual(errors,[]);const report={passed:true,checks,layouts,errors};fs.writeFileSync(path.join(qa,'technique-flow-review.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
 }finally{await browser.close();server.close()}
}
main().catch(e=>{console.error(e);process.exitCode=1;server.close()});
