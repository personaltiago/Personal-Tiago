/* DOM-light interaction harness: works without Chrome policy/remote dependencies. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const script=html.match(/<script id="agenda-drag-reorder-js">([\s\S]*?)<\/script>/)[1];
const css=html.match(/<style id="agenda-drag-reorder-css">([\s\S]*?)<\/style>/)[1];
assert.match(css,/touch-action:none/);
class Classes{
 constructor(...names){this.values=new Set(names)}
 add(v){this.values.add(v)}
 remove(v){this.values.delete(v)}
 contains(v){return this.values.has(v)}
}
class Row{
 constructor(id,kind,container){
  this.dataset={reorderId:id,reorderKind:kind};this.parentElement=container;
  this.classList=new Classes('workout-reorder-row');this.isConnected=true;
  this.indexEl={textContent:'',setAttribute(){}};
  this.handle={closest:s=>s==='.workout-reorder-handle'?this.handle:s==='.workout-reorder-row'?this:null,focus(){}};
 }
 getBoundingClientRect(){let i=this.parentElement.children.indexOf(this);return {top:100+i*78,height:65,bottom:165+i*78}}
 querySelector(selector){return selector==='.workout-reorder-index'?this.indexEl:selector==='.workout-reorder-handle'?this.handle:null}
}
class Container{
 constructor(){this.children=[];this.classList=new Classes();this.dataset={};this.isConnected=true;this.scrollHeight=0;this.clientHeight=0;this.parentElement=null}
 set innerHTML(markup){this._html=markup;this.children=[...markup.matchAll(/<article class="workout-reorder-row" data-reorder-id="([^"]+)" data-reorder-kind="([^"]+)"/g)].map(([,id,kind])=>new Row(id,kind,this))}
 get innerHTML(){return this._html||''}
 insertBefore(row,other){if(row===other)return;let i=this.children.indexOf(row);if(i>=0)this.children.splice(i,1);i=this.children.indexOf(other);this.children.splice(i,0,row)}
 append(row){const i=this.children.indexOf(row);if(i>=0)this.children.splice(i,1);this.children.push(row)}
}
const dayList=new Container(),exList=new Container(),listeners=new Map();
const document={
 getElementById:id=>id==='workoutDaysList'?dayList:null,
 querySelector:selector=>selector==='#workoutDayContent .workout-exercise-list'?exList:null,
 querySelectorAll:()=>[],
 addEventListener(event,listener){const curr=listeners.get(event)||[];listeners.set(event,[...curr,listener])},
 removeEventListener(event,listener){listeners.set(event,(listeners.get(event)||[]).filter(x=>x!==listener))},
 scrollingElement:{scrollHeight:0,clientHeight:0,scrollTop:0},documentElement:{scrollHeight:0,clientHeight:0,scrollTop:0}
};
const dispatch=(type,evt)=>{for(const listener of (listeners.get(type)||[]))listener(evt)};
const workouts=[
 {id:'dayA',name:'A',exercises:[{id:'a',name:'Rosca direta',sets:'3',reps:'12',load:'20 kg',technique:{name:'Rest pause'}},{id:'c',name:'Tríceps'}, {id:'b',name:'Rosca martelo'}, {id:'d',name:'Elevação lateral'}],bisets:[{id:'biset1',exerciseIds:['a','b'],rounds:3,restSeconds:60}]},
 {id:'dayB',name:'B',exercises:[]}, {id:'dayC',name:'C',exercises:[]}
];
let plan={id:'plan',name:'Plano teste',days:workouts},whichDay='dayA',daysOrdering=true,exercisesOrdering=false,running=false,failSaves=false;
let saved=0;
const window={addEventListener(){},removeEventListener(){},workoutBisetGroups(day){return day.bisets||[]}};
const context={
 window,document,innerHeight:700,
 renderWorkoutStudent(){dayList.innerHTML=''},renderWorkoutDay(){exList.innerHTML=''},
 currentWorkoutPlan(){return plan},currentWorkoutDay(){return plan.days.find(d=>d.id===whichDay)},
 workoutDayLabel(_,day){return 'Treino '+day.name},
 workoutPlanArchived(){return false},workoutRunning(){return running},
 get workoutDaysOrdering(){return daysOrdering},get workoutExercisesOrdering(){return exercisesOrdering},
 hesc:value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;'),
 replaceWorkoutPlan(next){if(failSaves)return false;plan=next;saved++;context.renderWorkoutStudent();context.renderWorkoutDay();return true},
 getComputedStyle(){return {overflowY:'visible'}},
 requestAnimationFrame(){return 1},cancelAnimationFrame(){},
};
vm.createContext(context);
vm.runInContext(script,context);
const ids=list=>list.children.map(n=>n.dataset.reorderId);
function pointerMove(list,index,y){
 const row=list.children[index],target=row.handle;
 dispatch('pointerdown',{target,isPrimary:true,button:0,pointerId:11,clientY:100+index*78+32,cancelable:true,preventDefault(){}});
 dispatch('pointermove',{pointerId:11,clientY:y,cancelable:true,preventDefault(){}});
 dispatch('pointerup',{pointerId:11,cancelable:true,preventDefault(){}});
}
context.renderWorkoutStudent();
assert.deepEqual(ids(dayList),['day:dayA','day:dayB','day:dayC']);
assert.match(dayList.innerHTML,/alça à esquerda/);
pointerMove(dayList,0,350);
assert.deepEqual(JSON.parse(JSON.stringify(plan.days.map(d=>d.id))),['dayB','dayC','dayA']);assert.equal(saved,1);
assert.deepEqual(ids(dayList),['day:dayB','day:dayC','day:dayA']);
exercisesOrdering=true;context.renderWorkoutDay();
assert.deepEqual(ids(exList),['pair:biset1','exercise:c','exercise:d']);
assert.match(exList.innerHTML,/BI-SET · A \+ B/);
pointerMove(exList,0,400);
assert.deepEqual(JSON.parse(JSON.stringify(plan.days[2].exercises.map(ex=>ex.id))),['c','d','a','b']);assert.equal(saved,2);
assert.equal(plan.days[2].exercises[2].load,'20 kg');
assert.deepEqual(JSON.parse(JSON.stringify(plan.days[2].exercises[2].technique)),{name:'Rest pause'});
assert.deepEqual(JSON.parse(JSON.stringify(plan.days[2].bisets[0].exerciseIds)),['a','b']);
// Keyboard reorder moves whole pair, never breaks A/B.
const target=exList.children.at(-1).handle;
dispatch('keydown',{key:'ArrowUp',target,preventDefault(){}});
assert.deepEqual(JSON.parse(JSON.stringify(plan.days[2].exercises.map(ex=>ex.id))),['c','a','b','d']);assert.equal(saved,3);
// Failed write rolls back the visible order when data is unchanged.
failSaves=true;pointerMove(exList,0,360);
assert.deepEqual(JSON.parse(JSON.stringify(plan.days[2].exercises.map(ex=>ex.id))),['c','a','b','d']);
assert.deepEqual(ids(exList),['exercise:c','pair:biset1','exercise:d']);
assert.equal(saved,3);failSaves=false;
// Active workout: no sortable list or mutation allowed.
running=true;context.renderWorkoutDay();
assert.deepEqual(ids(exList),[]);
assert.equal(context.currentWorkoutDay().exercises.length,4);
console.log(JSON.stringify({passed:true,checks:['ordem treinos','ordem exercícios','pares atômicos','dados preservados','teclado','rollback de armazenamento','bloqueio durante treino'],writes:saved},null,2));
