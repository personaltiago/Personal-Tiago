"""Exercise the production Back dispatcher/controller with small Android API fakes.

This verifies modern/legacy delegation and WebView callback ordering.
It does not simulate a physical swipe, predictive animations or a real keyboard.
"""
from pathlib import Path
import shutil
import subprocess
import tempfile

PROJECT=Path(__file__).resolve().parents[1]
STUBS={
 'android/os/Build.java':'''package android.os; public final class Build {public static final class VERSION {public static int SDK_INT=35;}}''',
 'android/window/OnBackInvokedCallback.java':'''package android.window; public interface OnBackInvokedCallback {void onBackInvoked();}''',
 'android/window/OnBackInvokedDispatcher.java':'''package android.window;
public final class OnBackInvokedDispatcher {
 public static final int PRIORITY_DEFAULT=0; public int registrations,removals,priority;public OnBackInvokedCallback callback;
 public void registerOnBackInvokedCallback(int p,OnBackInvokedCallback c){registrations++;priority=p;callback=c;}
 public void unregisterOnBackInvokedCallback(OnBackInvokedCallback c){removals++;if(callback==c)callback=null;}
 public void invoke(){if(callback!=null)callback.onBackInvoked();}
}''',
 'android/app/Activity.java':'''package android.app;
public class Activity {
 public final android.window.OnBackInvokedDispatcher dispatcher=new android.window.OnBackInvokedDispatcher(); public int exits;
 public android.window.OnBackInvokedDispatcher getOnBackInvokedDispatcher(){return dispatcher;}
 public boolean isFinishing(){return exits>0;}public void finish(){exits++;}
}''',
 'android/webkit/ValueCallback.java':'''package android.webkit;public interface ValueCallback<T>{void onReceiveValue(T value);}''',
 'android/webkit/WebView.java':'''package android.webkit;import java.util.*;
public class WebView {
 public final List<ValueCallback<String>> pending=new ArrayList<>(); public final List<String> scripts=new ArrayList<>();
 public void evaluateJavascript(String script,ValueCallback<String> callback){scripts.add(script);pending.add(callback);}
 public void answer(String value){pending.remove(0).onReceiveValue(value);}
}''',
 'com/tiagolima/agendapersonal/SystemBackHarness.java':'''package com.tiagolima.agendapersonal;
import android.app.Activity;import android.os.Build;import android.webkit.WebView;
public final class SystemBackHarness {
 static int cases; static void check(boolean ok,String message){cases++;if(!ok)throw new AssertionError(message);}
 static void runSdk(int sdk){
  Build.VERSION.SDK_INT=sdk;Activity activity=new Activity();WebView page=new WebView();
  boolean[] video={false};int[] videoCloses={0};
  WebBackController controller=new WebBackController(activity,page,()->{if(video[0]){video[0]=false;videoCloses[0]++;return true;}return false;});
  check(activity.dispatcher.registrations==(sdk>=33?1:0),"Registro incorreto para SDK "+sdk);
  if(sdk>=33)check(activity.dispatcher.priority==0,"Callback não deve preceder o teclado");
  controller.handleBack();controller.handleBack();check(page.scripts.size()==1,"Voltar rápido disparou duas navegações");
  page.answer("true");check(activity.exits==0,"Página interna fechou o aplicativo");
  if(sdk>=33)activity.dispatcher.invoke();else controller.handleBack();
  check(page.scripts.size()==2,"Gesto não chegou ao histórico interno");page.answer("true");
  video[0]=true;if(sdk>=33)activity.dispatcher.invoke();else controller.handleBack();
  check(videoCloses[0]==1&&page.scripts.size()==2&&activity.exits==0,"Vídeo não foi fechado antes da página");
  controller.handleBack();page.answer("null");check(activity.exits==0,"Resposta de abertura incompleta fechou o app");
  controller.handleBack();controller.pageStarted();controller.handleBack();
  page.answer("false");check(activity.exits==0,"Resposta antiga fechou a página recém-aberta");
  page.answer("true");controller.handleBack();page.answer("false");check(activity.exits==1,"Raiz sem histórico não pode encerrar normalmente");
  int before=page.scripts.size();controller.handleBack();check(page.scripts.size()==before,"Navegou após fechar a Activity");
  controller.destroy();check(activity.dispatcher.removals==(sdk>=33?1:0),"Callback não removido ao destruir");
 }
 public static void main(String[] args){
  for(int sdk:new int[]{26,32,33,35,36})runSdk(sdk);
  Build.VERSION.SDK_INT=35;Activity activity=new Activity();WebView page=new WebView();WebBackController controller=new WebBackController(activity,page,()->false);
  controller.handleBack();controller.destroy();page.answer("false");check(activity.exits==0,"Resposta tardia fechou Activity destruída");
  int before=page.scripts.size();activity.dispatcher.invoke();check(page.scripts.size()==before,"Callback continuou após destroy");
  AppBackDispatcher dispatcher=new AppBackDispatcher();int[] calls={0};dispatcher.register(activity,()->calls[0]++);dispatcher.register(activity,()->calls[0]+=10);activity.dispatcher.invoke();check(calls[0]==10,"Registro duplicado manteve callback antigo");dispatcher.destroy();
  System.out.println("Retorno nativo: "+cases+" verificações passaram nos SDKs simulados 26, 32, 33, 35 e 36; gesto, botão, vídeo, repetição e respostas atrasadas.");
 }
}'''
}

def verify_wiring():
    java=PROJECT/'app/src/main/java/com/tiagolima/agendapersonal'
    main=(java/'MainActivity.java').read_text()
    assert 'new WebBackController(this, webView, this::closeInlineVideoOnBack)' in main
    assert 'backController.handleBack()' in main and 'backController.pageStarted()' in main
    assert 'backController.destroy()' in main
    assert 'super.onBackPressed()' not in main and 'updateManager.goBack()' not in main
    for filename in ('YouTubeVideoActivity.java','UpdatePanelActivity.java'):
        text=(java/filename).read_text()
        assert 'backDispatcher.register(this, this::handleBack)' in text
        assert 'backDispatcher.destroy()' in text
    assert 'android:enableOnBackInvokedCallback="true"' in (PROJECT/'app/src/main/AndroidManifest.xml').read_text()

def main():
    verify_wiring()
    compiler=[shutil.which('javac')] if shutil.which('javac') else [shutil.which('java'),'com.sun.tools.javac.Main']
    java=PROJECT/'app/src/main/java/com/tiagolima/agendapersonal'
    with tempfile.TemporaryDirectory(prefix='agenda-system-back-') as folder:
        root=Path(folder);sources=[]
        for name,text in STUBS.items():
            p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);sources.append(str(p))
        sources+=[str(java/name)for name in ('AppBackDispatcher.java','WebBackController.java')]
        subprocess.run(compiler+['-encoding','UTF-8','-source','8','-target','8','-d',str(root/'classes')]+sources,check=True,capture_output=True)
        result=subprocess.run([shutil.which('java'),'-cp',str(root/'classes'),'com.tiagolima.agendapersonal.SystemBackHarness'],check=True,capture_output=True,text=True)
        print(result.stdout.strip())

if __name__=='__main__':main()
