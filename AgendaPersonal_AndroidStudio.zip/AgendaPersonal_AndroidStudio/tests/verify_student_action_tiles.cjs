const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const screen=html.match(/<section id="screen-students" class="screen">([\s\S]*?)<div class="section-title student-list-heading">/)?.[1];
assert.ok(screen,'Encontrada área superior da aba Alunos');
const actionArea=screen.slice(screen.indexOf('<div class="student-primary-actions">'));
const tiles=[...actionArea.matchAll(/<button\b[^>]*class="action-tile(?: [^"]+)?"[^>]*>/g)].map(x=>x[0]);
assert.equal(tiles.length,4,'Quatro cartões homogêneos na aba Alunos');
for(const tile of tiles){assert.doesNotMatch(tile,/\bprimary\b/,'Nenhuma ação aparenta estar selecionada');assert.match(tile,/type="button"/);}
assert.match(tiles[0],/onclick="openNewStudent\(\)"/,'Cadastrar aluno mantém ação');
assert.match(tiles[1],/onclick="openEvaluations\(\)"/,'Nova avaliação mantém ação');
assert.match(tiles[2],/onclick="chooseWorkoutPdfImport\(\)"/,'Importar PDF mantém ação');
assert.match(tiles[3],/onclick="openEvaluationDashboard\(\)"/,'Área de avaliações mantém ação');
assert.match(tiles[3],/student-evaluations-action/);
assert.ok(actionArea.includes('<strong>Alunos, avaliações e PDFs</strong>'));
assert.match(html,/\.student-secondary-actions\{[^}]*align-items:stretch/,'Segunda linha alinhada em altura');
assert.match(html,/\.student-secondary-actions \.student-pdf-action,\.student-secondary-actions \.student-evaluations-action\{[^}]*height:100%/);
assert.doesNotMatch(screen,/evaluation-index-link text-action/,'Link solto foi substituído pelo cartão');
console.log('OK: 4 ações neutras, cartão de avaliações completo, alturas iguais, destinos preservados.');
