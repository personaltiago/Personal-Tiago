const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');
const source = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const initial = {
  students:[{id:'s1',name:'Jéssica',phone:'69999999999',location:'Academia',notes:'',financeEnabled:true,startDate:'2026-10-03',dueDate:'2026-11-03',monthlyValue:'350,00',paymentReminderDays:3}],
  lessons:[{id:'l1',studentId:'s1',date:'2026-10-03',time:'06:45',duration:60,type:'Treino individual',location:'Academia',lead:15,repeat:'weekly',repeatDays:[1],notes:''}],
  occurrenceStatus:{'l1|2026-10-05':'cancelada'},history:[],payments:[]
};
const storage = new Map([['agendaPersonalTL_v1', JSON.stringify(initial)]]);
const elements = new Map();
function element(id){if(!elements.has(id))elements.set(id,{value:'',style:{},dataset:{},innerHTML:'',textContent:'',options:[],classList:{add(){},remove(){},toggle(){}},reset(){},querySelectorAll(){return []}});return elements.get(id)}
const calls=[];
const native={syncLessonAlarms(json){calls.push(JSON.parse(json));return true},openWhatsAppMessage(phone,msg){calls.push({phone,msg})}};
const context={URL,Date,console,confirm(){return true},setInterval(){},setTimeout(){return 1},clearTimeout(){},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},document:{getElementById:element,querySelectorAll(){return []},addEventListener(){},hidden:false},Android:native,window:{Android:native,open(){}}};
vm.createContext(context);vm.runInContext(source,context);
assert.equal(context.addMonthsSafe('2026-10-03',1),'2026-11-03');
assert.equal(context.addMonthsSafe('2027-01-31',1),'2027-02-28');
const msg=context.chargeMessage(context.studentById('s1'));
assert.match(msg,/69992913628/);assert.match(msg,/Jéssica/);assert.match(msg,/R\$\s*350,00/);
context.openChargeWhatsFor('s1');
const wa=calls.find(x=>x&&x.phone);assert.equal(wa.phone,'69999999999');assert.match(wa.msg,/PIX/);
context.markPaymentPaid('s1');
assert.equal(context.studentById('s1').dueDate,'2026-12-03');
assert.equal(JSON.parse(storage.get('agendaPersonalTL_v1')).payments.length,1);
assert.equal(calls.at(-1).schema,4);
assert.equal(calls.at(-1).students[0].dueDate,'2026-12-03');
context.deleteStudent('s1');
const afterDelete=JSON.parse(storage.get('agendaPersonalTL_v1'));assert.equal(afterDelete.students.length,0);assert.equal(afterDelete.lessons.length,0);assert.equal(Object.keys(afterDelete.occurrenceStatus).length,0);
console.log('Financeiro verificado: vencimento mensal, PIX, cobrança, baixa, próximo vencimento e exclusão do aluno.');
