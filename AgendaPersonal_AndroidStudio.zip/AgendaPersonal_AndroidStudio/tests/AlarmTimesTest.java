package com.tiagolima.agendapersonal;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class AlarmTimesTest {
    private static final ZoneId ZONE = ZoneId.of("America/Cuiaba");
    private static final Set<String> EMPTY = Collections.emptySet();
    private static int checks;

    private static long at(String value, ZoneId zone) {
        return LocalDateTime.parse(value).atZone(zone).toInstant().toEpochMilli();
    }
    private static Set<String> dates(String... values) {
        Set<String> result = new HashSet<>();
        Collections.addAll(result, values);
        return result;
    }
    private static void check(boolean condition, String label) {
        checks++;
        if (!condition) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        long now = at("2026-10-01T10:00", ZONE);
        AlarmTimes.Occurrence once = AlarmTimes.next("2026-10-01", "12:00", 15, null, EMPTY, EMPTY, now, ZONE);
        check(once.triggerAtMillis == at("2026-10-01T11:45", ZONE), "Antecedência da aula única");
        check(AlarmTimes.next("2026-10-01", "12:00", 15, null, dates("2026-10-01"), EMPTY, now, ZONE) == null,
                "Cancelar aula única desativa seu aviso");
        check(AlarmTimes.next("2026-10-01", "12:00", 15, null, EMPTY, dates("2026-10-01"), now, ZONE) == null,
                "Um aviso entregue não se repete ao sincronizar");
        check(AlarmTimes.next("2026-09-30", "12:00", 15, null, EMPTY, EMPTY, now, ZONE) == null,
                "Uma aula passada não cria aviso imediato");
        AlarmTimes.Occurrence weekly = AlarmTimes.next("2026-10-01", "12:00", 15, 4,
                dates("2026-10-01"), EMPTY, now, ZONE);
        check(weekly.date.equals("2026-10-08"), "Cancelar somente a primeira ocorrência semanal");
        AlarmTimes.Occurrence futureCancel = AlarmTimes.next("2026-10-01", "12:00", 15, 4,
                dates("2026-10-08"), EMPTY, now, ZONE);
        check(futureCancel.date.equals("2026-10-01"), "Cancelar data distante preserva a aula anterior");
        AlarmTimes.Occurrence afterFirst = AlarmTimes.next("2026-10-01", "12:00", 15, 4,
                dates("2026-10-08"), dates("2026-10-01"), now, ZONE);
        check(afterFirst.date.equals("2026-10-15"), "Pular cancelamento futuro após entregar o aviso anterior");
        check(AlarmTimes.next("2026-10-01", "12:00", 15, 4,
                dates("2026-10-01", "2026-10-08"), EMPTY, now, ZONE).date.equals("2026-10-15"),
                "Múltiplas datas canceladas preservam a série");
        check(AlarmTimes.next("2026-11-01", "12:00", 15, 4, EMPTY, EMPTY, now, ZONE).date.equals("2026-11-05"),
                "Respeitar data de início futura da série");
        long monday = at("2026-10-05T20:00", ZONE);
        AlarmTimes.Occurrence midnight = AlarmTimes.next("2026-10-06", "00:05", 15, 2, EMPTY, EMPTY, monday, ZONE);
        check(midnight.date.equals("2026-10-06") && midnight.triggerAtMillis == at("2026-10-05T23:50", ZONE),
                "Alerta no dia anterior mantém a identidade da data da aula");
        check(AlarmTimes.next("2026-10-06", "00:05", 15, 2, dates("2026-10-06"), EMPTY, monday, ZONE)
                .date.equals("2026-10-13"), "Cancelar aviso que cruza meia-noite");
        AlarmTimes.Occurrence late = AlarmTimes.next("2026-10-01", "10:05", 15, null, EMPTY, EMPTY, now, ZONE);
        check(late.triggerAtMillis == now + 5_000L, "Uma nova aula próxima recebe um aviso único");
        ZoneId newYork = ZoneId.of("America/New_York");
        long beforeDST = at("2026-10-26T05:00", newYork);
        AlarmTimes.Occurrence dst = AlarmTimes.next("2026-10-26", "07:00", 15, 1,
                EMPTY, dates("2026-10-26"), beforeDST, newYork);
        check(dst.triggerAtMillis == at("2026-11-02T06:45", newYork), "Horário local preservado ao mudar horário de verão");
        AlarmTimes.Occurrence recovered = AlarmTimes.next("2026-10-01", "12:00", 15, 4,
                dates("2026-10-08"), dates("2026-10-01"), at("2026-10-07T10:00", ZONE), ZONE);
        check(recovered.date.equals("2026-10-15"), "Recuperação após reiniciar respeita datas canceladas");
        System.out.println(checks + " verificações de datas e cancelamentos passaram.");
    }
}
