const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const runtime = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/') : require;
const { chromium } = runtime('playwright');
const assets = path.resolve(__dirname, '../app/src/main/assets');
const pdfFile = path.resolve(__dirname, 'fixtures/revisao_importacao_treino.pdf');
const fixture = {
  students: [{ id: 'j', name: 'Jéssica', phone: '69911111111', studentType: 'presencial' }, { id: 'other', name: 'Joana', phone: '69922222222' }],
  lessons: [], history: [], payments: [], occurrenceStatus: {}, lessonTimers: {},
  workoutPlans: [{ id: 'original', studentId: 'j', name: 'Ficha anterior', organization: 'sequence', days: [{ id: 'day-old', name: 'Treino anterior', exercises: [{ id: 'old', name: 'Agachamento', sets: '4', reps: '8', load: '40 kg', rest: '90 s' }] }] }],
  workoutExecutions: [], workoutDrafts: {}, customData: { preserved: true },
};
const server = http.createServer((req, res) => {
  const file = path.resolve(assets, '.' + new URL(req.url, 'http://localhost').pathname);
  if (!file.startsWith(assets + path.sep) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', file.endsWith('.html') ? 'text/html;charset=utf-8' : 'application/octet-stream');
  res.end(fs.readFileSync(file));
});
const errors = [];
async function makePage(browser, width = 414, height = 900) {
  const context = await browser.newContext({ viewport: { width, height }, isMobile: width < 768, hasTouch: true, timezoneId: 'America/Cuiaba' });
  await context.addInitScript(data => {
    if (!localStorage.getItem('agendaPersonalTL_v1')) localStorage.setItem('agendaPersonalTL_v1', JSON.stringify(data));
    const save = Storage.prototype.setItem;
    Storage.prototype.setItem = function(key, value) { if (window.__failSave && key === 'agendaPersonalTL_v1') throw new Error('quota'); return save.call(this, key, value); };
    window.Android = { syncLessonAlarms() { return true; }, getAlarmStatus() { return '{"ready":true}'; } };
  }, fixture);
  const page = await context.newPage();
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('http://127.0.0.1:' + server.address().port + '/index.html');
  return page;
}
async function readPdf(page) {
  await page.locator('.nav [data-screen="workouts"]').click();
  await page.locator('.workout-student-choice[data-student-id="j"]').click();
  const chooser = page.waitForEvent('filechooser');
  await page.getByRole('button', { name: 'Importar treino por PDF', exact: true }).click();
  await (await chooser).setFiles(pdfFile);
  await page.locator('#workoutImportFooter').waitFor({ timeout: 60000 });
}
async function fits(page) {
  assert.equal(await page.evaluate(() => {
    const scroll = document.querySelector('.workout-import-scroll').getBoundingClientRect();
    const footer = document.querySelector('.workout-import-footer').getBoundingClientRect();
    if (scroll.height < 40) return 'Área de leitura insuficiente: ' + innerWidth + 'x' + innerHeight + ', leitura=' + scroll.height + ', rodapé=' + footer.height;
    const region = document.querySelector('.workout-import-scroll');
    if (region.scrollHeight < region.clientHeight + 400) return 'Lista longa comprimida em vez de rolável';
    for (const section of region.querySelectorAll('.workout-import-section')) {
      if (section.querySelector('.workout-import-section-body').getBoundingClientRect().bottom > section.getBoundingClientRect().bottom + 1) return 'Conteúdo do bloco cortado';
    }
    if (scroll.bottom > footer.top + 1 || footer.bottom > innerHeight + 1 || footer.top < 0) return 'Rodapé sobreposto ou cortado';
    if (document.documentElement.scrollWidth > innerWidth + 1) return 'Página transbordando';
    for (const selector of ['#workoutImportReviewed', '#workoutImportFooter .btn.primary', '#workoutImportFooter .btn.ghost']) {
      const el = document.querySelector(selector); if (!el) continue;
      const b = el.getBoundingClientRect();
      if (b.x < 0 || b.right > innerWidth + 1 || b.top < 0 || b.bottom > innerHeight + 1 || el.scrollWidth > el.clientWidth + 1) return selector + ' cortado';
      const hit = document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2);
      if (!hit || (hit !== el && !el.contains(hit))) return selector + ' encoberto';
    }
    return '';
  }), '');
}
async function documentCount(page) {
  return page.evaluate(async () => {
    const db = await workoutDocumentDb();
    const count = await new Promise((resolve, reject) => { const req = db.transaction('documents').objectStore('documents').count(); req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });
    db.close(); return count;
  });
}
async function main() {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const options = { headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] };
  if (process.env.AGENDA_CHROMIUM) options.executablePath = process.env.AGENDA_CHROMIUM;
  const browser = await chromium.launch(options);
  try {
    const page = await makePage(browser); await readPdf(page);
    const comparison = await page.evaluate(() => [
      ['Glúteo coice na polia', 'Glúteos Coice na Polia'],
      ['PANTURRILHA na máquina', 'Panturrilhas Máquina'],
      ['Rosca Direta na Polia (Barra W)', 'Rosca direta na polia barra W'],
      ['Rosca Direta na Polia (Barra W)', 'Rosca W'],
      ['Rosca na Polia com Barra W', 'Rosca na Polia com Barra V'],
      ['Leg Press 45 com Pés Afastados', 'Leg Press 45'],
      ['Supino Reto com Barra Pegada Aberta', 'Supino Inclinado com Barra Pegada Aberta'],
      ['Elevação com uma perna', 'Elevação com duas pernas'],
    ].map(([a, b]) => workoutImportInstructionConflict(a, b)));
    assert.deepEqual(comparison, [false, false, false, true, true, true, true, true]);
    const recognized = await page.evaluate(() => ({ profile: workoutPdfImport.profile, exercises: workoutPdfImport.days.flatMap(d => d.exercises), count: workoutImportCounts() }));
    assert.equal(recognized.profile.name, 'Jéssica Gella de Oliveira');
    assert.equal(recognized.exercises.length, 16);
    assert.equal(recognized.exercises[0].warnings.length, 0);
    assert.equal(recognized.count.conflicts, 15);
    assert.match(await page.locator('#workoutImportReviewSection').innerText(), /Nome no PDF.*Jéssica Gella de Oliveira/);
    assert.equal(await page.locator('#workoutImportReviewSection').getByText('CONFLITO', { exact: true }).count(), 0);
    await fits(page);
    assert.ok(await page.locator('#workoutImportFooter .btn.primary').isDisabled());
    await page.evaluate(() => confirmWorkoutPdfImport());
    assert.equal(await page.evaluate(() => state.workoutPlans.length), 1);
    assert.equal(await documentCount(page), 0);
    await page.locator('#workoutImportReviewed').check();
    assert.ok(await page.locator('#workoutImportFooter .btn.primary').isEnabled());
    await page.locator('#workoutImportReviewed').uncheck();
    assert.ok(await page.locator('#workoutImportFooter .btn.primary').isDisabled());
    await page.evaluate(() => { const scroll = document.querySelector('.workout-import-scroll'); scroll.scrollTop = scroll.scrollHeight; });
    await fits(page);
    assert.ok(await page.locator('#workoutImportReviewed').isVisible());

    const parsed = await page.evaluate(() => ({ profile: workoutPdfImport.profile, days: workoutPdfImport.days }));
    const identity = await makePage(browser);
    await identity.evaluate(parsed => {
      workoutPdfImport = { ...parsed, profile: { ...parsed.profile, name: 'Jéssica' }, days: [{ ...parsed.days[0], exercises: [parsed.days[0].exercises[0]] }], file: { name: 'revisao.pdf', size: 1000 }, targetStudentId: 'j', lockedStudentId: 'j', reviewConfirmed: false };
      openDialog('workoutPdfImportDialog'); renderWorkoutPdfImport();
    }, parsed);
    assert.equal(await identity.locator('#workoutImportReviewed').count(), 0);
    assert.ok(await identity.locator('#workoutImportFooter .btn.primary').isEnabled());
    await identity.locator('#workoutImportName').fill('');
    assert.ok(await identity.locator('#workoutImportFooter .btn.primary').isDisabled());
    assert.match(await identity.locator('#workoutImportReviewSection').innerText(), /nome do aluno não foi reconhecido/);
    await identity.evaluate(() => { workoutPdfImport.lockedStudentId = ''; workoutPdfImport.targetStudentId = ''; workoutPdfImport.profile.name = 'Nova Aluna'; renderWorkoutPdfImport(); });
    assert.equal(await identity.locator('#workoutImportReviewed').count(), 0);
    assert.ok(await identity.locator('#workoutImportFooter .btn.primary').isEnabled());
    await identity.context().close();
    for (const [width, height, fontSize] of [[320, 568, 16], [360, 780, 16], [414, 900, 16], [768, 1024, 16], [1080, 800, 16], [320, 640, 20], [360, 460, 16]]) {
      const p = await makePage(browser, width, height);
      await p.evaluate(({ parsed, fontSize }) => {
        document.documentElement.style.fontSize = fontSize + 'px';
        workoutPdfImport = { ...parsed, file: { name: 'revisao_importacao_treino.pdf', size: 10000 }, fileBytes: new Uint8Array(), targetStudentId: 'j', lockedStudentId: 'j', reviewConfirmed: false };
        openDialog('workoutPdfImportDialog'); renderWorkoutPdfImport();
      }, { parsed, fontSize });
      try { await fits(p); } catch (error) { if (process.env.AGENDA_TEST_SCREENSHOTS) { fs.mkdirSync(process.env.AGENDA_TEST_SCREENSHOTS, { recursive: true }); await p.screenshot({ path: path.join(process.env.AGENDA_TEST_SCREENSHOTS, 'importacao-falha.png') }); } throw error; }
      if (process.env.AGENDA_TEST_SCREENSHOTS && (width === 414 || width === 320 && fontSize === 16)) {
        fs.mkdirSync(process.env.AGENDA_TEST_SCREENSHOTS, { recursive: true });
        await p.screenshot({ path: path.join(process.env.AGENDA_TEST_SCREENSHOTS, 'importacao-confirmacao-' + width + '.png') });
        await p.evaluate(() => { const scroll = document.querySelector('.workout-import-scroll'); scroll.scrollTop = document.getElementById('workoutImportReviewSection').offsetTop - scroll.offsetTop; });
        await p.screenshot({ path: path.join(process.env.AGENDA_TEST_SCREENSHOTS, 'importacao-avisos-' + width + '.png') });
      }
      await p.locator('#workoutImportFooter .btn.ghost').click();
      assert.ok(await p.locator('#workoutPdfImportDialog').isHidden());
      assert.equal(await p.evaluate(() => state.workoutPlans.length), 1);
      await p.context().close();
    }

    await page.locator('#workoutImportReviewed').check();
    await page.locator('#workoutImportName').fill('Outro nome');
    assert.ok(await page.locator('#workoutImportReviewed').isChecked() === false);
    assert.ok(await page.locator('#workoutImportFooter .btn.primary').isDisabled());
    await page.locator('#workoutImportName').fill('Jéssica Gella de Oliveira');
    await page.evaluate(() => { workoutPdfImport.lockedStudentId = ''; renderWorkoutPdfImport(); });
    await page.locator('#workoutImportReviewed').check();
    await page.locator('#workoutImportTarget').selectOption('other');
    assert.ok(await page.locator('#workoutImportFooter .btn.primary').isDisabled());
    assert.match(await page.locator('#workoutImportReviewSection').innerText(), /Perfil de destino: “Joana”/);
    await page.locator('#workoutImportTarget').selectOption('j');
    await page.locator('#workoutImportReviewed').check();
    await page.evaluate(() => Promise.all([confirmWorkoutPdfImport(), confirmWorkoutPdfImport()]));
    assert.equal(await page.evaluate(() => state.workoutPlans.length), 2);
    assert.equal(await documentCount(page), 1);
    const imported = await page.evaluate(() => ({ students: state.students, old: state.workoutPlans.find(p => p.id === 'original'), plan: state.workoutPlans.find(p => p.id !== 'original'), customData: state.customData }));
    assert.deepEqual(imported.students.map(s => [s.id, s.name]), [['j', 'Jéssica'], ['other', 'Joana']]);
    assert.equal(imported.old.days[0].exercises[0].load, '40 kg');
    assert.deepEqual(imported.customData, { preserved: true });
    assert.equal(imported.plan.studentId, 'j');
    const fields = ['name', 'sets', 'reps', 'load', 'rest', 'notes', 'observations', 'sourceInstructionName'];
    assert.deepEqual(imported.plan.days.flatMap(d => d.exercises).map(ex => fields.map(k => ex[k])), recognized.exercises.map(ex => fields.map(k => ex[k])));
    assert.equal(await page.evaluate(async id => workoutImportBytesToBase64(new Uint8Array(await (await workoutSourceBlob(id)).arrayBuffer())), imported.plan.sourceDocumentId), fs.readFileSync(pdfFile).toString('base64'));
    await page.reload();
    assert.equal(await page.evaluate(() => state.workoutPlans.length), 2);
    assert.equal(await documentCount(page), 1);

    const failed = await makePage(browser); await readPdf(failed);
    const savedBefore = await failed.evaluate(() => localStorage.getItem('agendaPersonalTL_v1'));
    await failed.locator('#workoutImportReviewed').check();
    await failed.evaluate(async () => { __failSave = true; await confirmWorkoutPdfImport(); __failSave = false; });
    assert.equal(await failed.evaluate(() => localStorage.getItem('agendaPersonalTL_v1')), savedBefore);
    assert.equal(await documentCount(failed), 0);
    assert.ok(await failed.locator('#workoutImportFooter .btn.primary').isEnabled());
    assert.equal(await failed.evaluate(() => workoutPdfImport.busy), false);

    const cancelled = await makePage(browser); await readPdf(cancelled);
    await cancelled.locator('#workoutImportReviewed').check();
    await cancelled.evaluate(() => {
      const save = saveWorkoutSourceDocument;
      saveWorkoutSourceDocument = async (...args) => { await new Promise(resolve => { window.__continueSave = resolve; }); return save(...args); };
      window.__pendingImport = confirmWorkoutPdfImport();
    });
    await cancelled.locator('#workoutImportFooter .btn.ghost').click();
    await cancelled.evaluate(async () => { __continueSave(); await __pendingImport; });
    assert.equal(await cancelled.evaluate(() => state.workoutPlans.length), 1);
    assert.equal(await documentCount(cancelled), 0);
    assert.deepEqual(errors, []);
    console.log('PASS: PDF real, comparação conservadora de nomes, confirmação em 7 telas, destino, preservação, clique duplo, falha de armazenamento e cancelamento.');
  } finally { await browser.close(); server.close(); }
}
main().catch(error => { console.error(error); process.exitCode = 1; server.close(); });
