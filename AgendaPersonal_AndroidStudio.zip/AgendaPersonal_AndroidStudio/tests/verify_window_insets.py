"""Exercise the actual window layout callback with Android API fakes.

Checks repeated dispatch, cutouts and keyboard opening/closing. This is not an
Android device test; the APK must still be built and checked on the phone.
"""
from pathlib import Path
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
STUBS = {
    'android/graphics/Color.java': 'package android.graphics; public class Color { public static int parseColor(String s){return 0;} }',
    'android/view/Window.java': 'package android.view; public class Window {public boolean fits=true; public void setStatusBarColor(int c){} public void setNavigationBarColor(int c){} }',
    'android/app/Activity.java': 'package android.app; public class Activity {public final android.view.Window window=new android.view.Window(); public android.view.Window getWindow(){return window;} }',
    'android/view/View.java': '''package android.view; public class View {
public int left,top,right,bottom; public int getPaddingLeft(){return left;}public int getPaddingTop(){return top;}
public int getPaddingRight(){return right;}public int getPaddingBottom(){return bottom;}
public void setPadding(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;} }''',
    'androidx/core/graphics/Insets.java': '''package androidx.core.graphics; public class Insets {
public final int left,top,right,bottom; public Insets(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;} }''',
    'androidx/core/view/WindowInsetsCompat.java': '''package androidx.core.view;
import androidx.core.graphics.Insets; public class WindowInsetsCompat {
public static final WindowInsetsCompat CONSUMED=new WindowInsetsCompat(new Insets(0,0,0,0),new Insets(0,0,0,0),new Insets(0,0,0,0));
private final Insets bars,cutout,keyboard; public WindowInsetsCompat(Insets b,Insets c,Insets k){bars=b;cutout=c;keyboard=k;}
public Insets getInsets(int mask){int l=0,t=0,r=0,b=0;Insets[] groups={bars,cutout,keyboard};for(int i=0;i<3;i++)if((mask&(1<<i))!=0){Insets v=groups[i];l=Math.max(l,v.left);t=Math.max(t,v.top);r=Math.max(r,v.right);b=Math.max(b,v.bottom);}return new Insets(l,t,r,b);}
public static class Type {public static int systemBars(){return 1;}public static int displayCutout(){return 2;}public static int ime(){return 4;}} }''',
    'androidx/core/view/WindowInsetsControllerCompat.java': '''package androidx.core.view;public class WindowInsetsControllerCompat {
public boolean lightStatus=true,lightNavigation=true;public void setAppearanceLightStatusBars(boolean v){lightStatus=v;}public void setAppearanceLightNavigationBars(boolean v){lightNavigation=v;} }''',
    'androidx/core/view/WindowCompat.java': '''package androidx.core.view;public class WindowCompat {
public static final WindowInsetsControllerCompat controller=new WindowInsetsControllerCompat();
public static void setDecorFitsSystemWindows(android.view.Window w,boolean v){w.fits=v;}
public static WindowInsetsControllerCompat getInsetsController(android.view.Window w,android.view.View v){return controller;} }''',
    'androidx/core/view/ViewCompat.java': '''package androidx.core.view;public class ViewCompat {
public interface Listener {WindowInsetsCompat apply(android.view.View v,WindowInsetsCompat i);}
public static Listener listener;public static int requests;public static void setOnApplyWindowInsetsListener(android.view.View v,Listener l){listener=l;}
public static void requestApplyInsets(android.view.View v){requests++;} }''',
    'com/tiagolima/agendapersonal/WindowInsetsHarness.java': '''package com.tiagolima.agendapersonal;
import android.view.View;import android.app.Activity;import androidx.core.graphics.Insets;import androidx.core.view.*;
public class WindowInsetsHarness {
static void check(boolean v,String message){if(!v)throw new AssertionError(message);}
static void padding(View v,int l,int t,int r,int b){check(v.left==l&&v.top==t&&v.right==r&&v.bottom==b,"Padding incorreto: "+v.left+","+v.top+","+v.right+","+v.bottom);}
static void dispatch(View v,Insets bars,Insets cutout,Insets keyboard){check(ViewCompat.listener.apply(v,new WindowInsetsCompat(bars,cutout,keyboard))==WindowInsetsCompat.CONSUMED,"Insets aplicados duas vezes aos filhos");}
public static void main(String[] args){
Activity activity=new Activity();View root=new View();root.setPadding(2,3,4,5);AppWindowLayout.apply(activity,root);
check(!activity.window.fits,"Janela não configurada");check(ViewCompat.requests==1,"Insets não solicitados");
check(!WindowCompat.controller.lightStatus&&!WindowCompat.controller.lightNavigation,"Ícones ilegíveis nas barras escuras");
Insets zero=new Insets(0,0,0,0),bars=new Insets(0,24,0,16),cutout=new Insets(34,10,18,0);
dispatch(root,bars,zero,zero);padding(root,2,27,4,21);dispatch(root,bars,zero,zero);padding(root,2,27,4,21);
dispatch(root,bars,cutout,zero);padding(root,36,27,22,21);
dispatch(root,bars,zero,new Insets(0,0,0,280));padding(root,2,27,4,285);
dispatch(root,bars,zero,zero);padding(root,2,27,4,21);dispatch(root,zero,zero,zero);padding(root,2,3,4,5);
System.out.println("Janela: barras, recorte da tela, teclado, fechamento do teclado e reaplicação sem acumular margens verificados.");
} }''',
}


def main():
    java, javac = shutil.which('java'), shutil.which('javac')
    if not java:
        raise SystemExit('Java 17 é necessário para este teste.')
    compiler = [javac] if javac else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-insets-tests-') as directory:
        root = Path(directory)
        sources = []
        for name, text in STUBS.items():
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text, encoding='utf-8')
            sources.append(str(target))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/AppWindowLayout.java'))
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(root / 'classes')] + sources, check=True)
        subprocess.run([java, '-cp', str(root / 'classes'), 'com.tiagolima.agendapersonal.WindowInsetsHarness'], check=True)


if __name__ == '__main__':
    main()
