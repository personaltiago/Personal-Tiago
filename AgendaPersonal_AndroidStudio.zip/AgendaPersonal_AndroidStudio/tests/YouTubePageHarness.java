package com.tiagolima.agendapersonal;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public final class YouTubePageHarness {
    public static void main(String[] args) throws Exception {
        String appId = "com.tiagolima.agendapersonal";
        if (!YouTubePlayerPage.validVideoId("M7lc1UVf-VE")) throw new AssertionError("Valid video rejected");
        for (String invalid : new String[]{"", "short", "M7lc1UVf-VE'", "<script>bad", "../../../a", "123456789012", "abcdefghij!"}) {
            if (YouTubePlayerPage.validVideoId(invalid)) throw new AssertionError("Invalid video accepted");
            boolean rejected = false;
            try { YouTubePlayerPage.html(invalid, 0, appId); } catch (IllegalArgumentException expected) { rejected = true; }
            if (!rejected) throw new AssertionError("Invalid video used in page");
        }
        boolean rejected = false;
        try { YouTubePlayerPage.html("M7lc1UVf-VE", -1, appId); } catch (IllegalArgumentException expected) { rejected = true; }
        if (!rejected) throw new AssertionError("Negative start accepted");
        rejected = false;
        try { YouTubePlayerPage.html("M7lc1UVf-VE", 0, "app/'bad"); } catch (IllegalArgumentException expected) { rejected = true; }
        if (!rejected) throw new AssertionError("Invalid app identity accepted");
        Files.write(Paths.get(args[0]), YouTubePlayerPage.html("M7lc1UVf-VE", 90, appId).getBytes(StandardCharsets.UTF_8));
        System.out.println("Página nativa: identificação HTTPS, vídeo e instante inicial validados.");
    }
}
