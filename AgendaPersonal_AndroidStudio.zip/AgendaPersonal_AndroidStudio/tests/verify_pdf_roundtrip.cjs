const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'avaliacoes.html'), 'utf8');

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(html.includes("format: 'agenda-personal-pdf-data', version: 1, kind: 'single'"), 'snapshot individual ausente');
assert(html.includes("kind: 'comparison', clientName: client.name, equation: client.equation, assessments: [a, b]"), 'snapshot comparativo ausente');
assert(html.includes('%AGENDA_PERSONAL_DATA:${encodedSnapshot}'), 'marcador de dados não é gravado no PDF');
assert(html.includes('const embedded = embeddedPdfRoundTrip(bytes);'), 'importação não tenta os dados embutidos');
assert(html.includes('if (embedded &&'), 'importação não prioriza os dados embutidos');
assert(html.includes('embedded || parseTiagoPdf(pages)'), 'compatibilidade com PDFs antigos de texto foi removida');

const snapshot = {
  format: 'agenda-personal-pdf-data', version: 1, kind: 'comparison',
  data: { kind: 'comparison', clientName: 'Aluno Ç', equation: 'male', assessments: [{date:'2026-01-01'}, {date:'2026-02-01'}] }
};
const encoded = Buffer.from(JSON.stringify(snapshot), 'utf8').toString('base64');
const fakePdf = Buffer.from(`%PDF-1.4\n% direct-download\n%AGENDA_PERSONAL_DATA:${encoded}\n1 0 obj\n<<>>\nendobj\n`, 'latin1');
const probe = fakePdf.subarray(0, 262144).toString('latin1');
const match = probe.match(/%AGENDA_PERSONAL_DATA:([A-Za-z0-9+/=]+)(?:\r?\n|$)/);
assert(match, 'marcador não foi recuperado');
const decoded = JSON.parse(Buffer.from(match[1], 'base64').toString('utf8'));
assert(decoded.data.clientName === 'Aluno Ç', 'UTF-8 não sobrevive ao ciclo PDF');
assert(decoded.data.assessments.length === 2, 'comparação não preservou as duas avaliações');

console.log('PDF round-trip verificado: individual, comparação, marcador interno e fallback legado.');
