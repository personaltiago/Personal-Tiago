"""Browser regression: stop an active workout without creating progress or attendance."""
import json, functools, threading, http.server, pathlib, contextlib
from playwright.sync_api import sync_playwright
base=pathlib.Path(__file__).resolve().parents[1]/'app/src/main/assets'
class Quiet(http.server.SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(base),**kwargs)
    def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Quiet)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
seed={
 'students':[{'id':'student','name':'Jéssica','studentType':'presencial','phone':'69999999999'}],
 'lessons':[], 'occurrenceStatus':{},'dismissedMakeups':{},'history':[{'id':'previous','at':'2026-10-08T14:00:00.000Z','text':'Histórico anterior'}],
 'payments':[],'lessonTimers':{},
 'workoutPlans':[{'id':'plan','studentId':'student','name':'Ficha','visibility':'always','days':[{'id':'day','name':'DIA A','exercises':[{'id':'e1','name':'Agachamento','sets':'3','reps':'12','load':'30 kg','rest':'60s'},{'id':'e2','name':'Cadeira abdutora','sets':'4','reps':'15','load':'50 kg','rest':'60s'}],'bisets':[]}]}],
 'workoutExecutions':[{'id':'prior-execution','studentId':'student','planId':'plan','dayId':'day','date':'2026-10-08','exercises':[]}],
 'workoutDrafts':{},'exerciseCatalog':[],'exerciseCatalogOverrides':{},'exerciseFavorites':[],'workoutRest':None
}
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
    context=browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='America/Manaus')
    context.add_init_script(script='const seed='+json.dumps(seed)+';'+'''(() => {if(!localStorage.getItem('agendaPersonalTL_v1'))localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(seed));window.__cancelled=[];window.__nativeRest=0;window.Android={syncLessonAlarms(){return true;},getAlarmStatus(){return '{"ready":true}';},startLessonTimer(){return true;},cancelLessonTimer(id,date){window.__cancelled.push(id+'|'+date);return true;},cancelWorkoutRest(){window.__nativeRest++;return true;},startWorkoutRest(){return true;}};})()''')
    page=context.new_page(); errors=[]
    page.on('pageerror',lambda err:errors.append(str(err)))
    page.on('dialog',lambda dlg:dlg.accept())
    page.route('https://**/*',lambda route:route.abort())
    page.goto(f'http://127.0.0.1:{server.server_port}/index.html',wait_until='domcontentloaded',timeout=70000)
    page.wait_for_function('typeof openWorkoutStudent === "function" && typeof stopWorkoutSession === "function"')
    page.evaluate('openWorkoutStudent("student");openWorkoutDay("day");')
    assert page.get_by_role('button',name='Iniciar treino presencial').is_visible()
    page.get_by_role('button',name='Iniciar treino presencial').click()
    assert page.get_by_role('button',name='Parar treino').is_visible()
    assert page.get_by_role('button',name='Finalizar treino').is_visible()
    started=page.evaluate('({draft:state.workoutDrafts["plan|day"],timer:state.lessonTimers,history:state.history,prior:state.workoutExecutions})')
    assert started['draft']['timerOwned'] is True, started
    assert len(started['timer'])==1
    page.evaluate('''() => {const d=state.workoutDrafts['plan|day'];d.values.e1={done:true,sets:'3',reps:'12',load:'99 kg'};d.bisets['some']={count:2};localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(state));renderWorkoutDay()}''')
    page.get_by_role('button',name='Parar treino').click()
    stopped=page.evaluate('''() => ({draft:state.workoutDrafts['plan|day'],timer:state.lessonTimers,history:state.history,executions:state.workoutExecutions,rest:state.workoutRest,cancelled:window.__cancelled,scroll:document.querySelector('#workoutDayDialog .sheet').scrollTop})''')
    assert stopped['draft'] is None,stopped
    assert len(stopped['timer'])==0,stopped
    assert stopped['history']==started['history'],stopped
    assert stopped['executions']==started['prior'],stopped
    assert stopped['scroll']==0,stopped
    assert len(stopped['cancelled'])==1,stopped
    assert page.get_by_role('button',name='Iniciar treino presencial').is_visible()
    assert page.get_by_role('button',name='Parar treino').count()==0
    # Start again: all temporary values are gone; the prescribed load remains.
    page.get_by_role('button',name='Iniciar treino presencial').click()
    fresh=page.evaluate('''() => ({draft:state.workoutDrafts['plan|day'],ex:workoutExerciseDraft(currentWorkoutPlan(),currentWorkoutDay(),currentWorkoutDay().exercises[0])})''')
    assert fresh['draft']['values']=={},fresh
    assert fresh['draft']['bisets']=={},fresh
    assert fresh['ex']['load']=='30 kg',fresh
    page.get_by_role('button',name='Parar treino').click()
    # A timer started for the actual lesson before this preview must keep running.
    page.evaluate('''() => {const today=iso(new Date());let lesson={id:'external',studentId:'student',date:today,repeat:'none',time:'15:00',duration:60};const extKey=timerKey('external',today);state.lessons=[lesson];state.lessonTimers[extKey]={lessonId:'external',date:today,studentId:'student',startedAt:Date.now()-10000,endAt:Date.now()+2500000,duration:60,native:true};localStorage.setItem('agendaPersonalTL_v1',JSON.stringify(state));renderWorkoutDay()}''')
    page.get_by_role('button',name='Iniciar treino presencial').click()
    shared=page.evaluate('''() => ({draft:state.workoutDrafts['plan|day'],keys:Object.keys(state.lessonTimers)})''')
    assert shared['draft']['timerOwned'] is False,shared
    extKey=shared['draft']['timerKey']
    page.get_by_role('button',name='Parar treino').click()
    external=page.evaluate('''() => ({timers:state.lessonTimers,finished:state.workoutExecutions,occ:state.occurrenceStatus,cancelled:window.__cancelled})''')
    assert extKey in external['timers'],external
    assert len(external['cancelled'])==2,external
    assert external['occ']=={},external
    assert len(external['finished'])==1,external
    # Persistence: reload the app and confirm there is no draft or fake evolution.
    page.reload(wait_until='domcontentloaded');page.wait_for_function('typeof openWorkoutDay === "function"')
    persistence=page.evaluate('''() => ({drafts:state.workoutDrafts,executions:state.workoutExecutions,history:state.history,lessonTimers:state.lessonTimers})''')
    assert persistence['drafts']=={},persistence
    assert len(persistence['executions'])==1,persistence
    assert len(persistence['history'])==1,persistence
    assert extKey in persistence['lessonTimers'],persistence
    assert not errors,errors
    print(json.dumps({'passed':True,'checks':['stop discards active workout draft and its sets, load, rounds and time','does not add history/records','stops own timer','resets UI','new start begins clean','preserves independent lesson timer','preserves history after reload','no JS errors'],'cancelledTimers':len(external['cancelled'])},ensure_ascii=False,indent=2))
    browser.close()
server.shutdown()
