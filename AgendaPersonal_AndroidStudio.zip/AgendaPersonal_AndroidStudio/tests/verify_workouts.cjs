const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const runtime = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES
  ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/') : require;
const { chromium } = runtime('playwright');
const assets = path.resolve(__dirname, '../app/src/main/assets');
const fixture = {
  students: [
    { id: 'a', name: 'Jéssica Silva', phone: '69999991111', studentType: 'presencial', photoDataUrl: '' },
    { id: 'b', name: 'Jéssica Silva', phone: '69999992222', studentType: 'online', photoDataUrl: '' },
  ],
  lessons: [{ id: 'lesson', studentId: 'a', date: '2026-10-06', time: '16:45', duration: 90, lead: 15, repeat: 'none', location: 'Local salvo', type: 'Treino individual' }],
  history: [], payments: [{ id: 'paid', studentId: 'a', dueDate: '2026-10-01', paidAt: '2026-10-01T12:00:00Z' }],
  occurrenceStatus: {}, customData: { preserve: true }, lessonTimers: {},
};
const server = http.createServer((req, res) => {
  const file = path.join(assets, new URL(req.url, 'http://localhost').pathname);
  if (!file.startsWith(assets + path.sep) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', file.endsWith('.html') ? 'text/html;charset=utf-8' : 'application/octet-stream');
  res.end(fs.readFileSync(file));
});
async function init(context, data) {
  await context.addInitScript(data => {
    if (!localStorage.getItem('agendaPersonalTL_v1')) localStorage.setItem('agendaPersonalTL_v1', JSON.stringify(data));
    const RealDate = Date, now = RealDate.parse('2026-10-06T12:00:00-04:00');
    window.Date = class extends RealDate { constructor(...args) { super(...(args.length ? args : [now])); } static now() { return now; } };
    const original = Storage.prototype.setItem;
    Storage.prototype.setItem = function(k, v) {
      if (window.__failWorkoutSave && k === 'agendaPersonalTL_v1') throw new DOMException('Quota exceeded', 'QuotaExceededError');
      return original.call(this, k, v);
    };
    window.Android = {
      syncLessonAlarms(json) { window.__alarms = JSON.parse(json); return true; },
      getAlarmStatus() { return JSON.stringify({ ready: true, issue: '' }); },
      openWhatsApp(phone) { window.__whats = phone; },
    };
  }, data);
}
async function core(page) { return page.evaluate(() => JSON.stringify({ students: state.students, lessons: state.lessons, payments: state.payments, lessonTimers: state.lessonTimers, customData: state.customData })); }
async function fits(page) {
  assert.equal(await page.evaluate(() => {
    if (document.documentElement.scrollWidth > innerWidth + 1) return 'Horizontal page overflow';
    for (const node of document.querySelectorAll('.nav button, #screen-workouts button, .workout-sheet button, .workout-exercise input, .workout-sheet summary')) {
      if (!node.getClientRects().length || node.closest('[inert]')) continue;
      const box = node.getBoundingClientRect();
      if (box.x < -1 || box.right > innerWidth + 1) return 'Outside screen: ' + node.textContent;
      if (node.tagName === 'BUTTON' && box.height < 44) return 'Small button: ' + node.textContent;
      if (node.tagName === 'BUTTON' && node.scrollWidth > node.clientWidth + 1) return 'Clipped button: ' + node.textContent;
    }
    return '';
  }), '');
}
async function close(page, dialog) { await page.locator('#' + dialog + ' .close').click(); }
async function newPlan(page, name, sequence = false) {
  await page.locator('#workoutStudentContent').getByRole('button', { name: /Criar ficha|Nova ficha/ }).click();
  await page.locator('#workoutPlanName').fill(name);
  await page.locator('#workoutPlanGoal').fill('Hipertrofia');
  await page.locator('#workoutPlanLevel').selectOption('Intermediário');
  if (sequence) await page.locator('#workoutPlanOrganization').selectOption('sequence');
  await page.locator('#workoutPlanForm').getByRole('button', { name: 'Salvar ficha', exact: true }).click();
  return page.evaluate(() => workoutPlanId);
}
async function newDay(page, name, weekday) {
  await page.locator('#workoutStudentContent').getByRole('button', { name: '+ Adicionar treino', exact: true }).click();
  await page.locator('#workoutDayName').fill(name);
  if (weekday != null) await page.locator('#workoutDayWeekday').selectOption(String(weekday));
  await page.locator('#workoutDayNotes').fill('Respeitar as orientações individuais do aluno.');
  await page.locator('#workoutDayForm').getByRole('button', { name: 'Salvar treino', exact: true }).click();
  return page.evaluate(() => currentWorkoutPlan().days.at(-1).id);
}
async function newExercise(page, name, load) {
  await page.locator('#workoutDayContent').getByRole('button', { name: '+ Exercício', exact: true }).click();
  await page.locator('#workoutExerciseName').fill(name);
  await page.locator('#workoutExerciseSets').fill('3');
  await page.locator('#workoutExerciseReps').fill('10–12');
  await page.locator('#workoutExerciseLoad').fill(load);
  await page.locator('#workoutExerciseRest').fill('60 s');
  await page.locator('#workoutExerciseNotes').fill('Orientações salvas para este exercício.');
  await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click();
  return page.evaluate(() => currentWorkoutDay().exercises.at(-1).id);
}
async function main() {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ executablePath: process.env.AGENDA_CHROMIUM || path.resolve('work/alarm_review/browser/chromium'), headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const errors = [];
  try {
    const context = await browser.newContext({ viewport: { width: 360, height: 900 }, isMobile: true, hasTouch: true, timezoneId: 'America/Cuiaba' });
    await init(context, fixture);
    const page = await context.newPage(); page.on('pageerror', error => errors.push(error.message)); page.on('dialog', dialog => dialog.accept());
    await page.goto('http://127.0.0.1:' + server.address().port + '/index.html');
    const baseline = await core(page);
    await page.locator('.nav [data-screen="workouts"]').click();
    await page.locator('#workoutTypeFilter').selectOption('online');
    assert.equal(await page.locator('.workout-student-choice').count(), 1);
    await page.locator('#workoutSearch').fill('2222');
    assert.equal(await page.locator('.workout-student-choice').getAttribute('data-student-id'), 'b');
    await page.locator('.workout-roster .iconbtn').click();
    assert.equal(await page.evaluate(() => __whats), fixture.students[1].phone);
    await page.locator('.workout-student-choice').click();
    const plan = await newPlan(page, 'Ficha Outubro <&>');
    const dayA = await newDay(page, 'DIA A · GLÚTEOS + POSTERIOR + PANTURRILHAS', 1);
    const dayB = await newDay(page, 'DIA B · PEITO + OMBROS + TRÍCEPS', 2);
    await page.locator('#workoutStudentContent').getByRole('button', { name: 'Reordenar treinos', exact: true }).click();
    await page.locator(`[data-day-id="${dayB}"]`).getByRole('button', { name: 'Mover treino para cima' }).click();
    assert.equal(await page.locator('#workoutDaysList article').first().getAttribute('data-day-id'), dayB);
    await page.locator('#workoutStudentContent').getByRole('button', { name: 'Concluir ordem', exact: true }).click();
    await page.locator(`[data-day-id="${dayA}"]`).getByRole('button', { name: 'Abrir treino', exact: true }).click();
    const hip = await newExercise(page, 'Elevação de quadril na máquina', '20 kg');
    const stiff = await newExercise(page, 'Stiff com halteres', '12 kg');
    await page.locator('#workoutDayContent').getByRole('button', { name: 'Reordenar exercícios', exact: true }).click();
    await page.locator(`article[data-exercise-id="${stiff}"]`).getByRole('button', { name: 'Mover exercício para cima' }).click();
    assert.equal(await page.locator('.workout-exercise').first().getAttribute('data-exercise-id'), stiff);
    await page.locator('#workoutDayContent').getByRole('button', { name: 'Concluir ordem', exact: true }).click();
    await page.getByRole('button', { name: 'Iniciar treino online', exact: true }).click();
    await page.locator('#workoutDayContent').getByRole('button', { name: 'Expandir todos', exact: true }).click();
    await page.getByRole('textbox', { name: 'Carga usada: Elevação de quadril na máquina', exact: true }).fill('24 kg');
    await page.getByRole('checkbox', { name: 'Concluído: Elevação de quadril na máquina', exact: true }).check();
    await fits(page);
    await page.reload();
    await page.locator('.nav [data-screen="workouts"]').click();
    await page.locator('.workout-student-choice[data-student-id="b"]').click();
    await page.locator(`[data-day-id="${dayA}"]`).getByRole('button', { name: 'Abrir treino', exact: true }).click();
    assert.ok(await page.getByRole('checkbox', { name: 'Concluído: Elevação de quadril na máquina', exact: true }).isChecked());
    await page.locator('#workoutDayContent').getByRole('button', { name: 'Expandir todos', exact: true }).click();
    assert.equal(await page.getByRole('textbox', { name: 'Carga usada: Elevação de quadril na máquina', exact: true }).inputValue(), '24 kg');
    await page.locator('#workoutDayContent').getByRole('button', { name: 'Registrar execução', exact: true }).click();
    await page.locator('#workoutExecutionEffort').fill('7');
    await page.locator('#workoutExecutionNote').fill('Aluno relatou boa execução.');
    await page.locator('#workoutExecutionForm').getByRole('button', { name: 'Salvar execução', exact: true }).click();
    assert.equal(await page.evaluate(() => state.workoutExecutions.length), 1);
    assert.equal(await page.evaluate(() => state.workoutExecutions[0].exercises[0].load), '24 kg');
    assert.equal(await page.evaluate(() => state.workoutExecutions[0].totalExercises), 2);
    assert.ok(!(await page.getByRole('checkbox', { name: 'Concluído: Elevação de quadril na máquina', exact: true }).isChecked()));
    await page.locator('#workoutDayContent').getByRole('button', { name: 'Evolução', exact: true }).click();
    assert.match(await page.locator('#workoutHistoryContent').innerText(), /24 kg/);
    await page.locator('#workoutFeedbackTab').click();
    assert.match(await page.locator('#workoutHistoryContent').innerText(), /boa execução/);
    await page.locator('#workoutHistoryContent').getByRole('button', { name: 'Editar observações', exact: true }).click();
    await page.locator('#workoutFeedbackNote').fill('Rascunho cancelado');
    await close(page, 'workoutFeedbackDialog');
    assert.equal(await page.evaluate(() => state.workoutExecutions[0].note), 'Aluno relatou boa execução.');
    await page.locator('#workoutHistoryContent').getByRole('button', { name: 'Editar observações', exact: true }).click();
    await page.locator('#workoutFeedbackNote').fill('Observação atualizada');
    await page.locator('#workoutFeedbackForm').getByRole('button', { name: 'Salvar observações', exact: true }).click();
    await close(page, 'workoutHistoryDialog');
    assert.ok(await page.locator('#workoutDayDialog').isVisible());
    await page.locator(`article[data-exercise-id="${hip}"]`).getByRole('button', { name: /Editar exercício/ }).click();
    await page.locator('#workoutExerciseLoad').fill('50 kg');
    await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click();
    assert.equal(await page.evaluate(() => state.workoutExecutions[0].exercises[0].load), '24 kg');
    await page.getByRole('button', { name: 'Iniciar treino online', exact: true }).click();
    await page.evaluate(() => window.__failWorkoutSave = true);
    await page.getByRole('checkbox', { name: 'Concluído: Stiff com halteres', exact: true }).click();
    assert.ok(!(await page.getByRole('checkbox', { name: 'Concluído: Stiff com halteres', exact: true }).isChecked()));
    await page.evaluate(() => window.__failWorkoutSave = false);
    await page.locator('#workoutDayContent').getByRole('button', { name: 'Expandir todos', exact: true }).click();
    await page.getByRole('textbox', { name: 'Carga usada: Elevação de quadril na máquina', exact: true }).fill('30 kg');
    await page.getByRole('checkbox', { name: 'Concluído: Elevação de quadril na máquina', exact: true }).check();
    await page.getByRole('checkbox', { name: 'Concluído: Stiff com halteres', exact: true }).check();
    await page.locator('#workoutDayContent').getByRole('button', { name: 'Registrar execução', exact: true }).click();
    await page.locator('#workoutExecutionForm').getByRole('button', { name: 'Salvar execução', exact: true }).click();
    assert.equal(await page.evaluate(() => state.workoutExecutions.length), 2);
    assert.equal(await page.evaluate(() => state.workoutExecutions[0].exercises.length), 2);
    assert.equal(await page.evaluate(() => state.workoutExecutions[0].exercises.find(ex => ex.exerciseId === currentWorkoutDay().exercises[1].id).load), '30 kg');
    await close(page, 'workoutDayDialog');
    await page.locator(`[data-day-id="${dayA}"]`).getByRole('button', { name: 'Editar treino', exact: true }).click();
    await page.locator('#workoutDayDelete').click();
    assert.equal(await page.evaluate(() => state.workoutExecutions.length), 2);
    await page.locator('#workoutStudentContent').getByRole('button', { name: 'Histórico da ficha', exact: true }).click();
    assert.match(await page.locator('#workoutHistoryContent').innerText(), /24 kg/);
    await close(page, 'workoutHistoryDialog');
    await page.locator('#workoutStudentContent').getByRole('button', { name: 'Arquivar ficha', exact: true }).click();
    assert.ok(await page.locator('#workoutStudentContent').getByRole('button', { name: 'Editar ficha', exact: true }).isDisabled());
    await page.locator('#workoutStudentContent').getByRole('button', { name: 'Reativar ficha', exact: true }).click();
    await page.locator('#workoutStudentContent').getByRole('button', { name: 'Editar ficha', exact: true }).click();
    await page.locator('#workoutPlanStart').fill('2026-09-01'); await page.locator('#workoutPlanEnd').fill('2026-10-05'); await page.locator('#workoutPlanAutoArchive').check();
    await page.locator('#workoutPlanForm').getByRole('button', { name: 'Salvar ficha', exact: true }).click();
    assert.equal(await page.evaluate(() => workoutPlanArchived(currentWorkoutPlan())), true);
    await page.locator('#workoutStudentContent').getByRole('button', { name: 'Reativar ficha', exact: true }).click();
    const sequencePlan = await newPlan(page, 'Ficha em sequência', true);
    const sequenceDay = await newDay(page, 'Treino C');
    await page.locator(`[data-day-id="${sequenceDay}"]`).getByRole('button', { name: 'Editar treino', exact: true }).click();
    assert.ok(await page.locator('#workoutWeekdayField').isHidden()); await close(page, 'workoutDayEditDialog');
    const beforeFailed = await page.evaluate(() => JSON.stringify(state));
    await page.evaluate(() => window.__failWorkoutSave = true);
    await newPlan(page, 'Esta ficha não deve salvar');
    assert.equal(await page.evaluate(() => JSON.stringify(state)), beforeFailed);
    await close(page, 'workoutPlanDialog'); await page.evaluate(() => window.__failWorkoutSave = false);
    await page.locator('#workoutPlanPicker').selectOption(plan);
    await close(page, 'workoutStudentDialog');
    assert.equal(await page.locator('.nav button.active').getAttribute('data-screen'), 'workouts');
    await page.locator('.workout-student-choice[data-student-id="a"]').click();
    assert.match(await page.locator('#workoutStudentContent').innerText(), /ainda não tem ficha/);
    await close(page, 'workoutStudentDialog');
    assert.equal(await core(page), baseline);
    await page.locator('.nav [data-screen="students-presencial"]').click();
    await page.locator('#studentList .profile-btn').click();
    await page.locator('#studentProfileDialog').getByRole('button', { name: /^Treinos/ }).click();
    assert.equal(await page.evaluate(() => workoutStudentId), 'a');
    await close(page, 'workoutStudentDialog');
    assert.ok(await page.locator('#studentProfileDialog').isVisible());
    await close(page, 'studentProfileDialog');
    assert.equal(await page.locator('.nav button.active').getAttribute('data-screen'), 'students-presencial');
    assert.equal(await page.evaluate(pid => state.workoutPlans.find(p => p.id === pid).studentId, sequencePlan), 'b');
    const visual = await page.evaluate(() => JSON.parse(JSON.stringify(state)));
    visual.workoutPlans.push({ id: 'visual-plan', studentId: 'a', name: 'Ficha de treino', goal: 'Hipertrofia', level: 'Intermediário', startDate: '2026-10-06', organization: 'week', days: [{ id: 'visual-day', name: 'DIA A · GLÚTEOS + POSTERIOR + PANTURRILHAS', weekday: 1, notes: 'Orientações do treino.', exercises: ['Elevação de quadril na máquina', 'Glúteo coice na polia', 'Abdução de quadril na máquina', 'Stiff com halteres'].map((name, i) => ({ id: 'visual-ex-' + i, name, sets: '3', reps: '10–12', load: '20 kg', rest: '60 s', notes: 'Orientações do exercício.' })) }] });
    await context.close();
    for (const width of [320, 360, 414, 480, 768]) {
      const ctx = await browser.newContext({ viewport: { width, height: 900 }, isMobile: width < 768, hasTouch: true, timezoneId: 'America/Cuiaba' }); await init(ctx, visual);
      const p = await ctx.newPage(); p.on('pageerror', error => errors.push(error.message)); p.on('dialog', dialog => dialog.accept());
      await p.goto('http://127.0.0.1:' + server.address().port + '/index.html'); await p.locator('.nav [data-screen="workouts"]').click(); await fits(p);
      await p.locator('.workout-student-choice[data-student-id="a"]').click(); await fits(p);
      if (process.env.AGENDA_TEST_SCREENSHOTS && width === 414) await p.locator('#workoutStudentDialog .sheet').screenshot({ path: path.join(process.env.AGENDA_TEST_SCREENSHOTS, 'ficha-treinos-414.png') });
      await p.locator('[data-day-id="visual-day"]').getByRole('button', { name: 'Abrir treino', exact: true }).click(); await fits(p);
      await p.locator('#workoutDayContent').getByRole('button', { name: 'Expandir todos', exact: true }).click(); await fits(p);
      if (process.env.AGENDA_TEST_SCREENSHOTS && width === 414) await p.locator('#workoutDayDialog .sheet').screenshot({ path: path.join(process.env.AGENDA_TEST_SCREENSHOTS, 'exercicios-treinos-414.png') });
      await close(p, 'workoutDayDialog'); assert.ok(await p.locator('#workoutStudentDialog').isVisible()); await close(p, 'workoutStudentDialog');
      assert.equal(await p.locator('.nav button.active').getAttribute('data-screen'), 'workouts'); await ctx.close();
    }
    assert.deepEqual(errors, []);
    console.log('Treinos verificados: cadastro, dias e sequência, exercícios, reordenação, cargas, execução parcial, feedback, histórico independente da ficha, arquivamento, reativação, nomes iguais, cancelamento, falha de armazenamento, reabertura, dados anteriores preservados e telas de 320 a 768 pixels.');
  } finally { await browser.close(); server.close(); }
}
main().catch(error => { console.error(error); server.close(); process.exitCode = 1; });
