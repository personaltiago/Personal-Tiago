'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
function extract(name){
  const start=html.indexOf('function '+name+'(');assert(start!==-1,'missing '+name);
  let brace=html.indexOf('{',start),depth=0,quote='',escaped=false,line=false,block=false;
  for(let i=brace;i<html.length;i++){
    const c=html[i],n=html[i+1];
    if(line){if(c==='\n')line=false;continue}if(block){if(c==='*'&&n==='/'){block=false;i++}continue}
    if(quote){if(escaped){escaped=false;continue}if(c==='\\'){escaped=true;continue}if(c===quote)quote='';continue}
    if(c==='/'&&n==='/'){line=true;i++;continue}if(c==='/'&&n==='*'){block=true;i++;continue}
    if(c==='\''||c==='"'||c==='`'){quote=c;continue}
    if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0)return html.slice(start,i+1)}
  }
  throw Error('function parse error: '+name);
}
const d1={id:'a',name:'Dia A',exercises:[{id:'ex1',name:'Flexora',load:'35 kg',sets:'3'}]};
const d2={id:'b',name:'Dia B',exercises:[{id:'ex2',name:'Agachamento',load:'60 kg',sets:'4'}]};
const plans=[
 {id:'full',name:'Ficha hipertrofia',studentId:'s1',days:[d1,d2],archived:false,autoArchive:false,visibility:'always',createdAt:'2026-08-01',organization:'sequence'},
 {id:'empty',name:'Horário',studentId:'s1',days:[],archived:false,autoArchive:false,visibility:'always',createdAt:'2026-10-08',organization:'week'},
 {id:'old',name:'Ficha de julho',studentId:'s1',days:[{id:'x',name:'Treino antigo',exercises:[{id:'oldex',name:'Rosca'}]}],archived:true,createdAt:'2026-07-01',visibility:'always',organization:'sequence'}
];
const record={id:'record',studentId:'s1',planId:'full',dayId:'a',load:'40 kg'};
const initialState={students:[{id:'s1',name:'Jéssica',phone:'',studentType:'online'}],workoutPlans:structuredClone(plans),workoutExecutions:[record],workoutDrafts:{'full|a':{values:{ex1:{load:'40 kg'}}}},history:[],workoutRest:null};
const state=structuredClone(initialState),store=new Map(),toasts=[],elements={workoutStudentContent:{innerHTML:''},workoutStudentOptions:{open:false},workoutStudentDialog:{querySelector:()=>null}};
let canPersist=true,confirms=true,checks=0;
function check(name,fn){fn();checks++;console.log('OK',name)}
const sandbox={
 state,workoutStudentId:'s1',workoutPlanId:'',workoutDayId:'',workoutDaysOrdering:false,workoutPlanCollection:'active',workoutPlanArchivedDetailId:'',
 document:{getElementById:(id)=>elements[id]||null},window:{},
 localStorage:{setItem:(k,v)=>{if(!canPersist)throw Error('quota exceeded');store.set(k,v)},getItem:k=>store.get(k)||null},DB_KEY:'agenda-test',
 toast:text=>toasts.push(text),confirm:()=>confirms,
 studentById:id=>state.students.find(s=>s.id===id),
 uiIcon:()=>'',workoutSheetIcon:()=>'',hesc:v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;'),
 studentAvatarHtml:()=>'',studentTypeLabel:()=>'',workoutStudentProgressHtml:()=>'',
 workoutPlanMetrics:()=>'',workoutGuidance:()=>'',workoutDateLabel:v=>v||'',workoutLastExecutionLabel:()=>'',workoutDayLabel:(_,d)=>d.name,
 workoutRecords:(pid,did)=>state.workoutExecutions.filter(r=>r.planId===pid&&(!did||r.dayId===did)),
 updateWorkoutSheetPosition:()=>{},renderWorkouts:()=>{},renderWorkoutHistory:()=>{},renderHistory:()=>{},renderWorkoutDay:()=>{},
 workoutRestValid:()=>true,cancelNativeWorkoutRest:()=>{},updateWorkoutSessionLabels:()=>{},
 validWorkoutDate:v=>/^\d{4}-\d\d-\d\d$/.test(v),iso:()=>new Date('2026-10-09T12:00:00Z').toISOString().slice(0,10),id:()=>`hist-${Date.now()}`,
};
vm.createContext(sandbox);
for(const name of ['workoutPlanArchived','workoutPlanById','currentWorkoutPlan','commitWorkoutChange','replaceWorkoutPlan','renderWorkoutStudent','selectWorkoutPlan','toggleWorkoutPlanArchive','showWorkoutPlanCollection','openArchivedWorkoutPlan','reactivateArchivedWorkoutPlan','deleteArchivedWorkoutPlan'])vm.runInContext(extract(name),sandbox);
const ui=()=>elements.workoutStudentContent.innerHTML;

// Archived-workout hard deletion: isolated from other students and other plans.
state.students.push({id:'s2',name:'Outra aluna'});
state.workoutPlans.push({id:'foreign',studentId:'s2',name:'Ficha da outra aluna',days:[{id:'fd',name:'Z',exercises:[{id:'fx',name:'Y'}]}],archived:true});
state.workoutPlans.push({id:'old2',studentId:'s1',name:'Ficha antiga adicional',days:[{id:'d-old2',name:'Treino extra',exercises:[{id:'ex-old2',name:'Stiff'}]}],archived:true});
state.workoutDrafts['old|x']={values:{oldex:{load:'22 kg'}}};
state.workoutDrafts['old2|d-old2']={values:{'ex-old2':{load:'33 kg'}}};
state.workoutDrafts['foreign|fd']={values:{fx:{load:'44 kg'}}};
state.workoutExecutions.push({id:'record-old',studentId:'s1',planId:'old',dayId:'x',load:'22 kg'});
state.workoutExecutions.push({id:'record-foreign',studentId:'s2',planId:'foreign',dayId:'fd',load:'44 kg'});
state.payments=[{id:'payment-1',studentId:'s1',amount:100}];
state.lessons=[{id:'lesson-1',studentId:'s1'}];
let lastConfirmation='',confirmationCount=0,restCancels=0;
sandbox.confirm=message=>{lastConfirmation=message;confirmationCount++;return confirms};
sandbox.cancelNativeWorkoutRest=()=>{restCancels++;return true};
const stateSnapshot=()=>JSON.stringify(state);
const uiContent=()=>elements.workoutStudentContent.innerHTML;
check('Botões Consultar, Reativar e Apagar renderizados no cartão arquivado',()=>{
 sandbox.showWorkoutPlanCollection('archived');
 assert.match(uiContent(),/workout-archive-consult/);
 assert.match(uiContent(),/Consultar ficha/);
 assert.match(uiContent(),/Reativar/);
 assert.match(uiContent(),/deleteArchivedWorkoutPlan\(this.dataset.planId\)/);
 assert.match(uiContent(),/>Apagar<\/button>/);
});
check('Apagar não está disponível no cartão da ficha ativa',()=>{
 sandbox.showWorkoutPlanCollection('active');
 assert.ok(!uiContent().includes('deleteArchivedWorkoutPlan(this.dataset.planId)'));
});
check('Bloqueia excluir ficha ativa sem pedir confirmação',()=>{
 const before=stateSnapshot(),n=confirmationCount;
 sandbox.deleteArchivedWorkoutPlan('full');
 assert.equal(stateSnapshot(),before);assert.equal(confirmationCount,n);
});
check('Bloqueia apagar ficha de outra aluna',()=>{
 const before=stateSnapshot(),n=confirmationCount;
 sandbox.deleteArchivedWorkoutPlan('foreign');
 assert.equal(stateSnapshot(),before);assert.equal(confirmationCount,n);
});
check('Bloqueia ID inexistente',()=>{
 const before=stateSnapshot(),n=confirmationCount;
 sandbox.deleteArchivedWorkoutPlan('nonexistent');
 assert.equal(stateSnapshot(),before);assert.equal(confirmationCount,n);
});
check('Cancelar confirmação mantém todos os registros e fichas',()=>{
 sandbox.openArchivedWorkoutPlan('old');
 const before=stateSnapshot();confirms=false;
 sandbox.deleteArchivedWorkoutPlan('old');confirms=true;
 assert.equal(stateSnapshot(),before);
 assert.equal(sandbox.workoutPlanArchivedDetailId,'old');
 assert.match(lastConfirmation,/Ficha de julho/);assert.match(lastConfirmation,/1 treino\(s\)/);
 assert.match(lastConfirmation,/1 registro\(s\) de evolução/);
 assert.match(lastConfirmation,/não pode ser desfeita/);
});
check('Falha de gravação não exclui dados nem muda a seleção',()=>{
 sandbox.openArchivedWorkoutPlan('old');
 const before=stateSnapshot();canPersist=false;
 sandbox.deleteArchivedWorkoutPlan('old');canPersist=true;
 assert.equal(stateSnapshot(),before);
 assert.equal(sandbox.workoutPlanArchivedDetailId,'old');
 assert.equal(sandbox.workoutPlanId,'old');
 assert.equal(sandbox.workoutPlanCollection,'archived');
});
check('Apaga apenas ficha selecionada, registros e rascunhos vinculados',()=>{
 sandbox.deleteArchivedWorkoutPlan('old');
 assert.equal(state.workoutPlans.some(p=>p.id==='old'),false);
 assert.equal(state.workoutExecutions.some(r=>r.id==='record-old'),false);
 assert.equal(Object.hasOwn(state.workoutDrafts,'old|x'),false);
 assert.equal(state.workoutPlans.some(p=>p.id==='full'),true);
 assert.equal(state.workoutPlans.some(p=>p.id==='old2'),true);
 assert.equal(state.workoutPlans.some(p=>p.id==='foreign'),true);
 assert.equal(state.workoutExecutions.some(r=>r.id==='record'),true);
 assert.equal(state.workoutExecutions.some(r=>r.id==='record-foreign'),true);
 assert.equal(Object.hasOwn(state.workoutDrafts,'old2|d-old2'),true);
 assert.equal(Object.hasOwn(state.workoutDrafts,'foreign|fd'),true);
 assert.equal(Object.hasOwn(state.workoutDrafts,'full|a'),true);
 assert.equal(state.students.length,2);
 assert.equal(state.payments.length,1);assert.equal(state.lessons.length,1);
 assert.equal(sandbox.workoutPlanArchivedDetailId,'');assert.match(uiContent(),/Ficha antiga adicional/);
 assert.ok(!uiContent().includes('Ficha de julho'));
 assert.match(state.history[0].text,/Ficha excluída definitivamente/);
});
check('Dados excluídos também desaparecem do estado persistido',()=>{
 const stored=JSON.parse(store.get('agenda-test'));
 assert.equal(stored.workoutPlans.some(p=>p.id==='old'),false);
 assert.equal(stored.workoutExecutions.some(r=>r.id==='record-old'),false);
 assert.equal(Object.hasOwn(stored.workoutDrafts,'old|x'),false);
 assert.equal(stored.workoutPlans.some(p=>p.id==='old2'),true);
});
check('Ação fica disponível apenas na lista de arquivadas, nunca em Ativas',()=>{
 sandbox.showWorkoutPlanCollection('active');assert.ok(!uiContent().includes('deleteArchivedWorkoutPlan(this.dataset.planId)'));
 sandbox.showWorkoutPlanCollection('archived');assert.ok(uiContent().includes('deleteArchivedWorkoutPlan(this.dataset.planId)'));
});
check('Se último arquivado for apagado, a seção mantém estado vazio',()=>{
 sandbox.deleteArchivedWorkoutPlan('old2');
 assert.match(uiContent(),/Nenhuma ficha arquivada/);
 assert.ok(!uiContent().includes('Ficha antiga adicional'));
});
check('Cronômetro de descanso vinculado a ficha removida é cancelado',()=>{
 const archived={id:'restPlan',studentId:'s1',name:'Treino descartável',days:[{id:'restDay',name:'Dia Z',exercises:[{id:'restEx',name:'Cadeira'}]}],archived:true};
 state.workoutPlans.push(archived);
 state.workoutRest={studentId:'s1',planId:'restPlan',dayId:'restDay'};
 sandbox.showWorkoutPlanCollection('archived');sandbox.openArchivedWorkoutPlan('restPlan');
 const before=restCancels;sandbox.deleteArchivedWorkoutPlan('restPlan');
 assert.equal(state.workoutRest,null);
 assert.equal(restCancels,before+1);
});
console.log('PASS',checks,'cenários de exclusão de fichas arquivadas');
