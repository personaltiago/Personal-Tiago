const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const source=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const original=JSON.stringify({students:[],lessons:[],payments:[],history:[],occurrenceStatus:{},customData:{keep:true}});
const storage=new Map([['agendaPersonalTL_v1',original]]),elements=new Map();
function element(id){if(!elements.has(id))elements.set(id,{value:'',style:{},dataset:{},innerHTML:'',textContent:'',classList:{add(){},remove(){},toggle(){}},querySelectorAll(){return []},reset(){}});return elements.get(id)}
let opened=0,issue='Autorize Alarmes e lembretes para tocar no horário.';
const native={syncLessonAlarms(){return true},getAlarmStatus(){return JSON.stringify({ready:!issue,issue})},showAlarmSettings(){opened++}};
const context={URL,Date,console,setInterval(){},setTimeout(){return 1},clearTimeout(){},
 localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},
 document:{getElementById:element,querySelectorAll(){return []},addEventListener(){},hidden:false},
 Android:native,window:{Android:native,open(){}}};
vm.createContext(context);vm.runInContext(source,context);
assert.equal(context.syncNativeAlarms(),'ok');assert.equal(element('alarmStatusText').textContent,issue);
context.alarmFeedback('ok','Aula salva; avisos atualizados.','Aula salva.');assert.ok(element('toast').textContent.includes(issue));assert.ok(!element('toast').textContent.includes('avisos atualizados'));
context.openAlarmSettings();assert.equal(opened,1);assert.equal(storage.get('agendaPersonalTL_v1'),original);
issue='';context.syncNativeAlarms();assert.equal(element('alarmStatusText').textContent,'Permissões e som verificados');
delete native.showAlarmSettings;context.openAlarmSettings();assert.ok(element('toast').textContent.includes('APK Android 1.24'));
delete native.getAlarmStatus;assert.equal(context.syncNativeAlarms(),'ok');assert.equal(context.readAlarmStatus(),null);
native.getAlarmStatus=()=>'{inválido';assert.equal(context.syncNativeAlarms(),'ok');assert.equal(context.readAlarmStatus(),null);
native.syncLessonAlarms=()=>false;assert.equal(context.syncNativeAlarms(),'error');
assert.equal(storage.get('agendaPersonalTL_v1'),original);
console.log('Acesso ao despertador verificado: diagnóstico, aviso de bloqueio, abertura, APK anterior, resposta inválida e dados preservados.');
