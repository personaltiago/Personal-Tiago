const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const dir=path.join(__dirname,'../app/src/main/assets');
for(const file of ['index.html','avaliacoes.html']){
 const html=fs.readFileSync(path.join(dir,file),'utf8');
 let count=0;
 for(const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){
  if(/\bsrc\s*=|type=["\'](?:application\/(?:octet-stream|(?:ld\+)?json)|text\/plain)["\']/i.test(m[1]))continue;
  new vm.Script(m[2],{filename:file});count++;
 }
 assert.ok(count>0);assert.ok(html.includes('data-agenda-ready'));
 const before={agendaPersonalTL_v1:JSON.stringify({students:[{name:'Pessoa de teste'}],lessons:[{time:'06:30'}]}),avaliacoes:JSON.stringify({client:'Pessoa de teste',weight:80})};
 const storage=new Map(Object.entries(before)), events={};let ready=0;
 const context={window:{__agendaBootFailed:false,Android:{updatePageReady(){ready++}},addEventListener(name,fn){events[name]=fn}},Android:{updatePageReady(){ready++}}};
 context.window.__agendaRestoreFailed=false;
 vm.runInNewContext(html.match(/<script data-agenda-ready>([\s\S]*?)<\/script>/)[1],context);
 events.load();assert.equal(ready,1);assert.deepEqual(Object.fromEntries(storage),before);
 context.window.__agendaBootFailed=true;events.load();assert.equal(ready,1);
 context.window.__agendaBootFailed=false;context.window.__agendaRestoreFailed=true;events.load();assert.equal(ready,1);
}
const java=fs.readFileSync(path.join(__dirname,'../app/src/main/java/com/tiagolima/agendapersonal/UpdateManager.java'),'utf8');
assert.match(java,/file:\/\/\/android_asset\/index\.html/);assert.match(java,/SHA-256/);assert.match(java,/snapshotFile/);
const panel=fs.readFileSync(path.join(__dirname,'../app/src/main/java/com/tiagolima/agendapersonal/UpdatePanelActivity.java'),'utf8');
assert.ok(!panel.includes('addJavascriptInterface'));
console.log('Atualizações: JavaScript das duas áreas válido, confirmação bloqueada em erro de abertura/restauração, URL local preservada e painel sem ponte nativa.');
