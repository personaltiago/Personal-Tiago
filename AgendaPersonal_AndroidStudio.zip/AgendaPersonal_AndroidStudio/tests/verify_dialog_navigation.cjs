const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const source=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const initial={students:[
 {id:'a',name:'Jéssica Silva',studentType:'presencial',phone:'69 99999-1111',location:'Local de treino',photoDataUrl:'data:image/png;base64,foto-a',financeEnabled:false},
 {id:'b',name:'Jéssica Silva',studentType:'online',phone:'69 99999-2222',location:'Local online',financeEnabled:true,startDate:'2026-09-01',dueDate:'2026-11-04',paymentOverdue:true,overdueDueDate:'2026-11-04'}
],lessons:[],payments:[],history:[],occurrenceStatus:{},customData:{keep:'preservado'}};
const storage=new Map([['agendaPersonalTL_v1',JSON.stringify(initial)]]),elements=new Map(),events={};
let document;
function element(id){
 if(!elements.has(id)){
  const classes=new Set(),attrs={};
  const node={id,value:'',style:{},dataset:{},innerHTML:'',textContent:'',options:[],isConnected:true,
   classList:{add(c){classes.add(c)},remove(c){classes.delete(c)},contains(c){return classes.has(c)},toggle(c,on){if(on)classes.add(c);else classes.delete(c)}},
   setAttribute(k,v){attrs[k]=String(v)},getAttribute(k){return attrs[k]},removeAttribute(k){delete attrs[k]},
   reset(){},querySelectorAll(){return []},focus(){document.activeElement=node},click(){},setCustomValidity(){},reportValidity(){}};
  elements.set(id,node);
 }
 return elements.get(id);
}
document={getElementById:element,querySelectorAll(){return []},addEventListener(k,fn){events[k]=fn},hidden:false,activeElement:null};
const native={syncLessonAlarms(){return true}};
const context={URL,Date,console,setInterval(){},setTimeout(){return 1},clearTimeout(){},confirm(){return true},
 localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},document,Android:native,window:{Android:native,open(){},addEventListener(){}}};
vm.createContext(context);vm.runInContext(source,context);context.loadProfileEvaluationResults=()=>{};
const value=expression=>vm.runInContext(expression,context),saved=storage.get('agendaPersonalTL_v1');
context.showScreen('students-presencial');context.prefillLesson('a');
assert.equal(value('currentScreen'),'students');assert.equal(value('studentViewType'),'presencial');assert.equal(element('lessonStudent').value,'a');
context.closeDialog('lessonDialog');assert.equal(value('currentScreen'),'students');assert.equal(value('dialogStack.length'),0);
context.showScreen('students-online');context.openStudentProfile('b');context.openCurrentProfileLesson();
assert.equal(value('currentScreen'),'students');assert.equal(value('studentViewType'),'online');assert.ok(element('studentProfileDialog').classList.contains('open'));
assert.equal(element('studentProfileDialog').inert,true);assert.equal(element('lessonDialog').inert,false);
assert.ok(Number(element('lessonDialog').style.zIndex)>Number(element('studentProfileDialog').style.zIndex));
context.openDialog('lessonDialog');assert.equal(value('dialogStack.length'),2);
context.closeDialog('lessonDialog');assert.ok(element('studentProfileDialog').classList.contains('open'));assert.equal(element('studentProfileDialog').inert,false);assert.equal(value('currentProfileStudentId'),'b');
context.editCurrentProfileStudent();assert.equal(value('dialogStack.length'),2);context.closeDialog('studentDialog');assert.ok(element('studentProfileDialog').classList.contains('open'));
for(const [opener,dialog] of [['openStudentPhoneEditor','studentPhoneDialog'],['openStudentLocationEditor','studentLocationDialog'],['openStudentTypeEditor','studentTypeDialog'],['openStudentPhotoOptions','studentPhotoDialog']]){
 context[opener]();assert.ok(element(dialog).classList.contains('open'));assert.equal(element('studentProfileDialog').inert,true);
 context.closeDialog(dialog);assert.ok(element('studentProfileDialog').classList.contains('open'));assert.equal(element('studentProfileDialog').inert,false);assert.equal(value('studentViewType'),'online');
}
context.openStudentPhotoOptions();context.chooseStudentProfilePhoto();assert.ok(element('studentProfileDialog').classList.contains('open'));assert.equal(value('currentProfileStudentId'),'b');
context.openStudentPhoneEditor();events.keydown({key:'Escape',preventDefault(){}});assert.ok(!element('studentPhoneDialog').classList.contains('open'));assert.ok(element('studentProfileDialog').classList.contains('open'));
context.openStudentTypeEditor();context.closeDialog('studentProfileDialog');assert.ok(!element('studentTypeDialog').classList.contains('open'));assert.equal(value('dialogStack.length'),0);assert.equal(value('currentProfileStudentId'),'');
assert.equal(storage.get('agendaPersonalTL_v1'),saved);
context.showScreen('finance');context.setFinanceView('overdue');context.openEditStudent('b');context.closeDialog('studentDialog');assert.equal(value('currentScreen'),'finance');assert.equal(value('financeView'),'overdue');
context.showScreen('students-presencial');context.openStudentProfile('a');context.editCurrentProfileStudent();context.deleteStudent('a');
assert.equal(value('dialogStack.length'),0);assert.equal(value('currentProfileStudentId'),'');assert.ok(!element('studentProfileDialog').classList.contains('open'));assert.ok(!element('studentDialog').classList.contains('open'));
assert.equal(JSON.parse(storage.get('agendaPersonalTL_v1')).students[0].id,'b');assert.deepEqual(JSON.parse(storage.get('agendaPersonalTL_v1')).customData,initial.customData);
console.log('Retorno das janelas verificado: aula sem mudar a aba, perfil preservado, camadas, X/Cancelar, Escape, foto, financeiro, abertura repetida, fechamento do pai e aluno removido.');
