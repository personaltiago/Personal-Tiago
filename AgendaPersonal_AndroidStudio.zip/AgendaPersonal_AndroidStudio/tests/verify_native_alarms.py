"""Compile and exercise the actual scheduler, store, receiver and diagnostics.

Android APIs are simulated; audible playback and Xiaomi restrictions require a
device test. The in-app test uses the actual AlarmManager/receiver on the phone.
"""
from pathlib import Path
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
STUBS = {
    'org/json/JSONObject.java': r'''package org.json; import java.util.*;
public class JSONObject {
final Map<String,Object> fields=new LinkedHashMap<>();static final Map<String,JSONObject> saved=new HashMap<>();
public JSONObject(){}public JSONObject(String s){JSONObject v=saved.get(s);if(v==null)throw new IllegalArgumentException(s);fields.putAll(copy(v).fields);}
static Object cloneValue(Object o){if(o instanceof JSONObject)return copy((JSONObject)o);if(o instanceof JSONArray){JSONArray n=new JSONArray();for(Object v:((JSONArray)o).values)n.put(cloneValue(v));return n;}return o;}
static JSONObject copy(JSONObject o){JSONObject n=new JSONObject();for(Map.Entry<String,Object> e:o.fields.entrySet())n.put(e.getKey(),cloneValue(e.getValue()));return n;}
public JSONObject put(String k,Object v){fields.put(k,v);return this;}public Object get(String k){if(!fields.containsKey(k))throw new IllegalArgumentException(k);return fields.get(k);}
public String getString(String k){return String.valueOf(get(k));}public String optString(String k){return optString(k,"");}public String optString(String k,String d){return fields.containsKey(k)?String.valueOf(fields.get(k)):d;}
public int getInt(String k){return ((Number)get(k)).intValue();}public int optInt(String k){return optInt(k,0);}public int optInt(String k,int d){return fields.get(k) instanceof Number?((Number)fields.get(k)).intValue():d;}
public long getLong(String k){return ((Number)get(k)).longValue();}public long optLong(String k){return optLong(k,0);}public long optLong(String k,long d){return fields.get(k) instanceof Number?((Number)fields.get(k)).longValue():d;}
public boolean optBoolean(String k){return Boolean.TRUE.equals(fields.get(k));}public JSONObject getJSONObject(String k){return (JSONObject)get(k);}public JSONArray getJSONArray(String k){return (JSONArray)get(k);}
public JSONArray optJSONArray(String k){return fields.get(k) instanceof JSONArray?(JSONArray)fields.get(k):null;}public Iterator<String> keys(){return fields.keySet().iterator();}
public String toString(){String key="json-"+UUID.randomUUID();saved.put(key,copy(this));return key;}
}''',
    'org/json/JSONArray.java': '''package org.json;import java.util.*;public class JSONArray {
final List<Object> values=new ArrayList<>();public JSONArray put(Object v){values.add(v);return this;}public int length(){return values.size();}
public int getInt(int n){return ((Number)values.get(n)).intValue();}public JSONObject getJSONObject(int n){return (JSONObject)values.get(n);}
public JSONObject optJSONObject(int n){return n<values.size()&&values.get(n) instanceof JSONObject?(JSONObject)values.get(n):null;} }''',
    'android/content/SharedPreferences.java': '''package android.content;import java.util.*;public interface SharedPreferences {
String getString(String k,String d);long getLong(String k,long d);Map<String,?> getAll();Editor edit();interface Editor{Editor putString(String k,String v);Editor putLong(String k,long v);Editor putBoolean(String k,boolean v);Editor remove(String k);boolean commit();void apply();}}''',
    'android/content/ContentValues.java': 'package android.content;import java.util.*;public class ContentValues extends java.util.HashMap<String,Object>{public void put(String k,String v){super.put(k,v);}public void put(String k,Integer v){super.put(k,v);}}',
    'android/content/ContentResolver.java': '''package android.content;import java.io.*;public class ContentResolver{
public android.net.Uri insert(android.net.Uri u,ContentValues v){return android.net.Uri.parse("content://agenda/"+System.nanoTime());}
public OutputStream openOutputStream(android.net.Uri u){return new ByteArrayOutputStream();}
public int update(android.net.Uri u,ContentValues v,String s,String[] a){return 1;}
}''',
    'android/content/Context.java': '''package android.content;import java.util.*;public class Context {
public static final int MODE_PRIVATE=0;public static final String ALARM_SERVICE="alarm",NOTIFICATION_SERVICE="notification",AUDIO_SERVICE="audio",POWER_SERVICE="power";
public final android.app.AlarmManager alarms=new android.app.AlarmManager();public final android.app.NotificationManager notifications=new android.app.NotificationManager();public final android.media.AudioManager audio=new android.media.AudioManager();public final android.os.PowerManager power=new android.os.PowerManager();public final Prefs prefs=new Prefs();public final ContentResolver resolver=new ContentResolver();public boolean granted=true;
public Object getSystemService(String n){switch(n){case ALARM_SERVICE:return alarms;case NOTIFICATION_SERVICE:return notifications;case AUDIO_SERVICE:return audio;case POWER_SERVICE:return power;}return null;}
public int checkSelfPermission(String n){return granted?0:-1;}public String getPackageName(){return "com.tiagolima.agendapersonal";}public SharedPreferences getSharedPreferences(String n,int m){return prefs;}
public ContentResolver getContentResolver(){return resolver;}
public static class Prefs implements SharedPreferences{final Map<String,Object> data=new HashMap<>();public String failPrefix="";public String getString(String k,String d){return data.containsKey(k)?String.valueOf(data.get(k)):d;}public long getLong(String k,long d){return data.get(k) instanceof Number?((Number)data.get(k)).longValue():d;}public Map<String,?> getAll(){return new HashMap<>(data);}public Editor edit(){return new E();}
class E implements Editor{final Map<String,Object> next=new HashMap<>();public Editor putString(String k,String v){next.put(k,v);return this;}public Editor putLong(String k,long v){next.put(k,v);return this;}public Editor putBoolean(String k,boolean v){next.put(k,v);return this;}public Editor remove(String k){next.put(k,null);return this;}public boolean commit(){if(!failPrefix.isEmpty()&&next.keySet().stream().anyMatch(k->k.startsWith(failPrefix)))return false;for(Map.Entry<String,Object> e:next.entrySet())if(e.getValue()==null)data.remove(e.getKey());else data.put(e.getKey(),e.getValue());return true;}public void apply(){commit();}}}
}''',
    'android/content/Intent.java': '''package android.content;import java.util.*;public class Intent {
public static final String ACTION_VIEW="view";public static final int FLAG_ACTIVITY_NEW_TASK=1,FLAG_ACTIVITY_CLEAR_TOP=2;public String action="",target="";public android.net.Uri data;public final Map<String,Object> extras=new HashMap<>();
public Intent(Context c,Class<?> t){target=t.getName();}public Intent(String a){action=a;}public Intent(String a,android.net.Uri u){action=a;data=u;}public Intent(Intent i){action=i.action;target=i.target;data=i.data;extras.putAll(i.extras);}
public Intent setAction(String s){action=s;return this;}public String getAction(){return action;}public Intent setData(android.net.Uri u){data=u;return this;}public Intent putExtra(String k,String v){extras.put(k,v);return this;}public Intent putExtra(String k,long v){extras.put(k,v);return this;}public String getStringExtra(String k){return (String)extras.get(k);}public long getLongExtra(String k,long d){return extras.containsKey(k)?((Number)extras.get(k)).longValue():d;}public Intent setFlags(int f){return this;}public Intent addFlags(int f){return this;} }
''',
    'android/content/BroadcastReceiver.java': 'package android.content;public abstract class BroadcastReceiver{public abstract void onReceive(Context c,Intent i);}',
    'android/net/Uri.java': 'package android.net;public class Uri{final String s;private Uri(String s){this.s=s;}public static Uri parse(String s){return new Uri(s);}public static String encode(String s){return java.net.URLEncoder.encode(s,java.nio.charset.StandardCharsets.UTF_8);}public String toString(){return s;}}',
    'android/os/Build.java': 'package android.os;public class Build{public static class VERSION{public static int SDK_INT=35;}public static class VERSION_CODES{public static final int O=26,Q=29,S=31;}}',
    'android/os/Environment.java': 'package android.os;public class Environment{public static final String DIRECTORY_NOTIFICATIONS="Notifications";}',
    'android/os/PowerManager.java': 'package android.os;public class PowerManager{public boolean isIgnoringBatteryOptimizations(String p){return false;}}',
    'android/media/AudioManager.java': 'package android.media;public class AudioManager{public static final int STREAM_ALARM=4;public int volume=5;public int getStreamVolume(int s){return volume;}public int getStreamMaxVolume(int s){return 10;}}',
    'android/media/RingtoneManager.java': 'package android.media;public class RingtoneManager{public static final int TYPE_ALARM=4;public static boolean silent;public static android.net.Uri getActualDefaultRingtoneUri(android.content.Context c,int type){return silent?null:android.net.Uri.parse("alarm://chosen");}}',
    'android/media/AudioAttributes.java': 'package android.media;public class AudioAttributes{public static final int USAGE_ALARM=4,USAGE_NOTIFICATION=5,CONTENT_TYPE_SONIFICATION=1;public int usage;public static class Builder{int u;public Builder setUsage(int v){u=v;return this;}public Builder setContentType(int v){return this;}public AudioAttributes build(){AudioAttributes a=new AudioAttributes();a.usage=u;return a;}}}',
    'android/app/PendingIntent.java': '''package android.app;import android.content.*;import java.util.*;public class PendingIntent {
public static final int FLAG_UPDATE_CURRENT=1,FLAG_IMMUTABLE=2,FLAG_NO_CREATE=4;static final Map<String,PendingIntent> registry=new HashMap<>();final String key;public Intent intent;public boolean cancelled;
PendingIntent(String k,Intent i){key=k;intent=new Intent(i);}static PendingIntent get(Context c,int code,Intent i,int flags,String type){String k=System.identityHashCode(c)+type+code+i.target+i.action+i.data;PendingIntent p=registry.get(k);if(p==null&&(flags&FLAG_NO_CREATE)!=0)return null;if(p==null){p=new PendingIntent(k,i);registry.put(k,p);}if((flags&FLAG_UPDATE_CURRENT)!=0)p.intent=new Intent(i);return p;}
public static PendingIntent getBroadcast(Context c,int n,Intent i,int f){return get(c,n,i,f,"b");}public static PendingIntent getActivity(Context c,int n,Intent i,int f){return get(c,n,i,f,"a");}public void cancel(){cancelled=true;registry.remove(key);}
}''',
    'android/app/AlarmManager.java': '''package android.app;import java.util.*;public class AlarmManager {
public static final int RTC_WAKEUP=0;public boolean allowed=true;public int clocks,exacts,inexacts;public final Map<PendingIntent,Long> scheduled=new HashMap<>();public boolean canScheduleExactAlarms(){return allowed;}public static class AlarmClockInfo{final long at;public AlarmClockInfo(long n,PendingIntent p){at=n;}}
public void setAlarmClock(AlarmClockInfo i,PendingIntent p){if(!allowed)throw new SecurityException("exato bloqueado");clocks++;scheduled.put(p,i.at);}public void setExactAndAllowWhileIdle(int t,long n,PendingIntent p){if(!allowed)throw new SecurityException();exacts++;scheduled.put(p,n);}public void setAndAllowWhileIdle(int t,long n,PendingIntent p){inexacts++;scheduled.put(p,n);}public void cancel(PendingIntent p){scheduled.remove(p);}
}''',
    'android/app/NotificationChannel.java': '''package android.app;public class NotificationChannel {
public final String id;public int importance;public android.net.Uri sound;public android.media.AudioAttributes attributes;public boolean bypass;
public NotificationChannel(String i,String n,int v){id=i;importance=v;}public void setDescription(String s){}public void enableVibration(boolean b){}public void setVibrationPattern(long[] p){}public void setLockscreenVisibility(int v){}public void setSound(android.net.Uri s,android.media.AudioAttributes a){sound=s;attributes=a;}public int getImportance(){return importance;}public android.net.Uri getSound(){return sound;}public boolean canBypassDnd(){return bypass;}
}''',
    'android/service/notification/StatusBarNotification.java': 'package android.service.notification;public class StatusBarNotification{final String tag;public StatusBarNotification(String s){tag=s;}public String getTag(){return tag;}}',
    'android/app/NotificationManager.java': '''package android.app;import java.util.*;public class NotificationManager{
public static final int IMPORTANCE_NONE=0,IMPORTANCE_LOW=2,IMPORTANCE_DEFAULT=3,IMPORTANCE_HIGH=4,INTERRUPTION_FILTER_ALL=1,INTERRUPTION_FILTER_NONE=3;
public boolean enabled=true,fail=false;public int filter=1,published;public final Map<String,NotificationChannel> channels=new HashMap<>();public final Map<String,Notification> active=new HashMap<>();public boolean areNotificationsEnabled(){return enabled;}public int getCurrentInterruptionFilter(){return filter;}public NotificationChannel getNotificationChannel(String id){return channels.get(id);}public void createNotificationChannel(NotificationChannel c){channels.putIfAbsent(c.id,c);}
public void notify(String tag,int id,Notification n){if(fail)throw new SecurityException("publicação recusada");if(enabled){published++;active.put(tag,n);}}public void cancel(String tag,int id){active.remove(tag);}public android.service.notification.StatusBarNotification[] getActiveNotifications(){return active.keySet().stream().map(android.service.notification.StatusBarNotification::new).toArray(android.service.notification.StatusBarNotification[]::new);}
}''',
    'android/app/Notification.java': '''package android.app;import java.util.*;public class Notification {
public static final int FLAG_INSISTENT=4,PRIORITY_MAX=2,PRIORITY_HIGH=1,VISIBILITY_PUBLIC=1,VISIBILITY_PRIVATE=0;public static final String CATEGORY_ALARM="alarm",CATEGORY_REMINDER="reminder";
public int flags;public long timeout;public String title;public final Map<String,PendingIntent> actions=new HashMap<>();public static class BigTextStyle{public BigTextStyle bigText(String s){return this;}}
public static class Builder{final Notification n=new Notification();public Builder(android.content.Context c){}public Builder(android.content.Context c,String id){}public Builder setSmallIcon(int v){return this;}public Builder setContentTitle(String s){n.title=s;return this;}public Builder setContentText(String s){return this;}public Builder setStyle(BigTextStyle s){return this;}public Builder setAutoCancel(boolean b){return this;}public Builder setContentIntent(PendingIntent p){return this;}public Builder setCategory(String c){return this;}public Builder setPriority(int p){return this;}public Builder setVisibility(int v){return this;}public Builder setWhen(long n){return this;}public Builder setShowWhen(boolean v){return this;}public Builder setSound(android.net.Uri u){return this;}public Builder setVibrate(long[] a){return this;}public Builder setTimeoutAfter(long t){n.timeout=t;return this;}public Builder addAction(int i,String s,PendingIntent p){n.actions.put(s,p);return this;}public Notification build(){return n;}}
}''',
    'android/provider/Settings.java': '''package android.provider;public class Settings {
public static final String ACTION_REQUEST_SCHEDULE_EXACT_ALARM="exact",ACTION_CHANNEL_NOTIFICATION_SETTINGS="channel",EXTRA_APP_PACKAGE="app",EXTRA_CHANNEL_ID="channelId",ACTION_SOUND_SETTINGS="sound",ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS="battery",ACTION_APP_NOTIFICATION_SETTINGS="notification",ACTION_APPLICATION_DETAILS_SETTINGS="details";
public static class System{public static final android.net.Uri DEFAULT_ALARM_ALERT_URI=android.net.Uri.parse("alarm://default"),DEFAULT_NOTIFICATION_URI=android.net.Uri.parse("notification://default");} }''',
    'android/provider/MediaStore.java': '''package android.provider;public class MediaStore{public static class Audio{public static class Media{
public static final android.net.Uri EXTERNAL_CONTENT_URI=android.net.Uri.parse("content://audio");public static final String DISPLAY_NAME="display",MIME_TYPE="mime",RELATIVE_PATH="relative",IS_PENDING="pending";
}}}''',
    'android/util/Base64.java': 'package android.util;public class Base64{public static final int DEFAULT=0;public static byte[] decode(String s,int f){return java.util.Base64.getDecoder().decode(s);}}',
    'android/Manifest.java': 'package android;public class Manifest{public static class permission{public static final String POST_NOTIFICATIONS="notifications";}}',
    'android/R.java': 'package android;public class R{public static class style{public static final int Theme_Material_Dialog_Alert=1;}public static class drawable{public static final int ic_lock_idle_alarm=1,ic_menu_send=2,ic_menu_mylocation=3,ic_dialog_info=4,ic_media_pause=5;}}',
    'android/content/pm/PackageManager.java': 'package android.content.pm;public class PackageManager{public static final int PERMISSION_GRANTED=0;}',
    'android/app/Activity.java': 'package android.app;public class Activity extends android.content.Context{public void runOnUiThread(Runnable r){r.run();}public void startActivity(android.content.Intent i){}public void requestPermissions(String[] s,int n){}}',
    'android/widget/Toast.java': 'package android.widget;public class Toast{public static final int LENGTH_LONG=1;public static Toast makeText(android.content.Context c,CharSequence s,int n){return new Toast();}public void show(){}}',
    'android/widget/Button.java': 'package android.widget;public class Button{public interface Click{void click(Object v);}public void setOnClickListener(Click l){}}',
    'android/app/AlertDialog.java': '''package android.app;public class AlertDialog{public static final int BUTTON_POSITIVE=1;public interface Click{void click(Object dialog,int which);}public interface Show{void show(Object d);}public void setOnShowListener(Show s){}public android.widget.Button getButton(int i){return new android.widget.Button();}public void dismiss(){}public void show(){}public void setMessage(String s){}
public static class Builder{public Builder(Activity a,int t){}public Builder setTitle(String s){return this;}public Builder setMessage(String s){return this;}public Builder setPositiveButton(String s,Click c){return this;}public Builder setNeutralButton(String s,Click c){return this;}public Builder setNegativeButton(String s,Click c){return this;}public Builder setItems(String[] s,Click c){return this;}public AlertDialog create(){return new AlertDialog();}public AlertDialog show(){return create();}}}''',
    'android/webkit/JavascriptInterface.java': 'package android.webkit;public @interface JavascriptInterface{}',
    'com/tiagolima/agendapersonal/NativeAlarmHarness.java': r'''package com.tiagolima.agendapersonal;
import android.app.*;import android.content.*;import org.json.*;import java.time.*;import java.util.*;
public class NativeAlarmHarness {
static int checks;static void check(boolean v,String s){checks++;if(!v)throw new AssertionError(s);}
static String tomorrow=LocalDate.now().plusDays(1).toString();
static JSONObject lesson(String id,String time){return new JSONObject().put("id",id).put("date",tomorrow).put("time",time).put("lead",15).put("student","Nomes iguais").put("phone","69999991111").put("repeat","none");}
static JSONObject agenda(JSONObject... l){JSONArray a=new JSONArray();for(JSONObject x:l)a.put(x);return new JSONObject().put("schema",4).put("lessons",a).put("students",new JSONArray()).put("occurrenceStatus",new JSONObject());}
static MainActivity context(){MainActivity c=new MainActivity();AlarmReceiver.createChannel(c.notifications);return c;}
static Intent intent(Context c,String key){for(PendingIntent p:c.alarms.scheduled.keySet())if(key.equals(p.intent.getStringExtra("alarmKey")))return new Intent(p.intent);throw new AssertionError("alarme ausente "+key);}
static void fire(Context c,Intent i){new AlarmReceiver().onReceive(c,i);}
static JSONObject stored(Context c,String key){return AlarmStore.plan(c,key);}
public static void main(String[] args)throws Exception{
 TimeZone.setDefault(TimeZone.getTimeZone("America/Cuiaba"));tomorrow=LocalDate.now().plusDays(1).toString();
 MainActivity c=context();JSONObject a=lesson("a","12:00"),b=lesson("b","14:00"),data=agenda(a,b);
 AlarmScheduler.synchronize(c,data);check(c.alarms.clocks==2,"AlarmClock para cada aula");check(AlarmStore.plans(c).size()==2,"IDs distintos com nomes iguais");
 JSONObject plan=stored(c,"a|once");check(plan.getLong("classAtMillis")-plan.getLong("triggerAtMillis")==900000,"15 minutos de antecedência");check(AlarmStatus.inspect(c).optBoolean("ready"),"Permissões e som disponíveis");
 Intent first=intent(c,"a|once");c.granted=false;fire(c,first);check(c.notifications.published==0,"Sem permissão não publica");check(AlarmStore.deliveredDates(c,"a").isEmpty(),"Bloqueio não marca entregue");check(stored(c,"a|once")!=null,"Aviso bloqueado permanece recuperável");
 c.granted=true;fire(c,first);check(AlarmStore.deliveredDates(c,"a").contains(tomorrow),"Publicação confirmada marca entregue");Notification n=c.notifications.active.get("a|"+tomorrow);check(n!=null&&(n.flags&Notification.FLAG_INSISTENT)!=0,"Toque repetido pelo Android");check(n.timeout==120000,"Limite de dois minutos");check(n.actions.containsKey("Parar"),"Controle para interromper o toque");check(stored(c,"b|once")!=null,"Outro aluno mantido");
 int count=c.notifications.published;fire(c,first);check(c.notifications.published==count,"Disparo duplicado ignorado");fire(c,n.actions.get("Parar").intent);check(c.notifications.active.isEmpty(),"Parar cancela o som/notificação");
 Intent beforeEdit=intent(c,"b|once");c.notifications.fail=true;fire(c,beforeEdit);check(AlarmStore.deliveredDates(c,"b").isEmpty(),"Falha na publicação não marca entregue");check(AlarmStore.lastDelivery(c).contains("Falha"),"Falha registrada no diagnóstico");c.notifications.fail=false;
 b.put("time","13:00");AlarmScheduler.synchronize(c,data);count=c.notifications.published;fire(c,beforeEdit);check(c.notifications.published==count,"Intent do horário antigo ignorado");fire(c,intent(c,"b|once"));check(AlarmStore.deliveredDates(c,"b").contains(tomorrow),"Horário editado entregue uma vez");
 JSONObject onlyA=agenda(a);AlarmScheduler.synchronize(c,onlyA);check(c.notifications.active.isEmpty(),"Excluir a aula interrompe o alarme publicado");
 MainActivity blocked=context();JSONObject d=agenda(lesson("cancel","12:00"));AlarmScheduler.synchronize(blocked,d);Intent old=intent(blocked,"cancel|once");d.getJSONObject("occurrenceStatus").put("cancel|"+tomorrow,"cancelada");AlarmScheduler.synchronize(blocked,d);fire(blocked,old);check(blocked.notifications.published==0&&AlarmStore.plans(blocked).isEmpty(),"Cancelar aula retira o aviso");
 d.getJSONObject("occurrenceStatus").put("cancel|"+tomorrow,"realizada");AlarmScheduler.synchronize(blocked,d);check(AlarmStore.plans(blocked).isEmpty(),"Aula realizada não toca");
 MainActivity weekly=context();int weekday=LocalDate.parse(tomorrow).getDayOfWeek().getValue()%7;JSONObject w=lesson("weekly","12:00").put("repeat","weekly").put("repeatDays",new JSONArray().put(weekday));JSONObject wd=agenda(w);AlarmScheduler.synchronize(weekly,wd);fire(weekly,intent(weekly,"weekly|week-"+weekday));check(stored(weekly,"weekly|week-"+weekday).getString("classDate").equals(LocalDate.parse(tomorrow).plusWeeks(1).toString()),"Série avança após entregar");
 wd.getJSONObject("occurrenceStatus").put("weekly|"+LocalDate.parse(tomorrow).plusWeeks(1),"cancelada");AlarmScheduler.synchronize(weekly,wd);check(stored(weekly,"weekly|week-"+weekday).getString("classDate").equals(LocalDate.parse(tomorrow).plusWeeks(2).toString()),"Cancelar uma semana mantém a série");
 MainActivity moved=context();JSONObject m=lesson("move","12:00"),md=agenda(m);AlarmScheduler.synchronize(moved,md);fire(moved,intent(moved,"move|once"));m.put("time","16:00");AlarmScheduler.synchronize(moved,md);check(stored(moved,"move|once")!=null,"Editar horário depois do primeiro aviso rearma a aula");check(moved.notifications.active.isEmpty(),"Mudança de horário interrompe o toque antigo");fire(moved,intent(moved,"move|once"));check(moved.notifications.published==2,"Novo horário recebe seu aviso uma vez");AlarmScheduler.synchronize(moved,md);check(AlarmStore.plans(moved).isEmpty(),"Sincronizar sem mudar horário não repete o aviso");
 MainActivity pay=context();JSONObject pd=agenda();pd.put("students",new JSONArray().put(new JSONObject().put("id","p").put("name","Aluno").put("dueDate",tomorrow).put("paymentReminderDays",0)));AlarmScheduler.synchronize(pay,pd);String pk="payment|p|"+tomorrow+"|due";Intent pi=intent(pay,pk);pay.notifications.enabled=false;fire(pay,pi);check(AlarmStore.deliveredDates(pay,"payment:p").isEmpty(),"Financeiro bloqueado não marca entregue");pay.notifications.enabled=true;fire(pay,pi);check(AlarmStore.deliveredDates(pay,"payment:p").contains(tomorrow+"|due"),"Financeiro confirma após publicação");check((pay.notifications.active.get(pk).flags&Notification.FLAG_INSISTENT)==0,"Financeiro mantém toque breve");
 MainActivity permissions=context();permissions.alarms.allowed=false;AlarmScheduler.synchronize(permissions,agenda(lesson("x","12:00")));check(permissions.alarms.inexacts==1,"Fallback sem permissão exata");check(AlarmStatus.issue(permissions).contains("Autorize"),"Fallback não é apresentado como pronto");boolean refused=false;try{AlarmScheduler.scheduleTest(permissions);}catch(IllegalStateException e){refused=true;}check(refused,"Teste exige alarme exato");permissions.alarms.allowed=true;AlarmScheduler.restore(permissions);check(permissions.alarms.clocks==1,"Retorno de permissão restaura horário exato");
 NotificationChannel channel=permissions.notifications.getNotificationChannel(AlarmReceiver.CHANNEL_ID);channel.importance=NotificationManager.IMPORTANCE_LOW;check(!AlarmStatus.issue(permissions).isEmpty(),"Canal silencioso identificado");AlarmReceiver.createChannel(permissions.notifications);check(channel.importance==NotificationManager.IMPORTANCE_LOW,"Preferência do canal preservada");channel.importance=4;channel.sound=null;check(AlarmStatus.issue(permissions).contains("Escolha"),"Ausência de som identificada");channel.sound=android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI;permissions.audio.volume=0;check(AlarmStatus.issue(permissions).contains("volume"),"Volume zero identificado");permissions.audio.volume=5;permissions.notifications.filter=NotificationManager.INTERRUPTION_FILTER_NONE;check(AlarmStatus.issue(permissions).contains("Não perturbe"),"Não perturbe bloqueado identificado");permissions.notifications.filter=1;
 android.media.RingtoneManager.silent=true;check(AlarmStatus.issue(permissions).contains("configurações do celular"),"Som padrão silencioso identificado");android.media.RingtoneManager.silent=false;
 MainActivity test=context();AlarmScheduler.scheduleTest(test);JSONObject tp=stored(test,"alarm-test");check(Math.abs(tp.getLong("triggerAtMillis")-System.currentTimeMillis()-30000)<1000,"Teste em trinta segundos");AlarmScheduler.synchronize(test,agenda());check(stored(test,"alarm-test").getLong("triggerAtMillis")==tp.getLong("triggerAtMillis"),"Sincronização preserva o teste");fire(test,intent(test,"alarm-test"));check(test.notifications.active.containsKey("alarm-test"),"Teste usa o mesmo receptor e toque");check(AlarmStore.plans(test).isEmpty(),"Teste não cria aula nem recorrência");AlarmScheduler.scheduleTest(test);AlarmScheduler.cancelTest(test);check(AlarmStore.plans(test).isEmpty()&&test.alarms.scheduled.isEmpty(),"Cancelar teste retira o alarme");
 MainActivity timer=context();JSONObject timerAgenda=agenda(lesson("timerLesson","16:45"));AlarmScheduler.synchronize(timer,timerAgenda);long timerAt=System.currentTimeMillis()+60000;AlarmScheduler.startLessonTimer(timer,new JSONObject().put("lessonId","timerLesson").put("classDate",tomorrow).put("triggerAtMillis",timerAt).put("student","Jéssica").put("durationMinutes",1).put("lessonTime","16:45"));check(stored(timer,"timer|timerLesson|"+tomorrow)!=null,"Cronômetro da aula salvo como plano nativo");AlarmScheduler.synchronize(timer,timerAgenda);check(stored(timer,"timer|timerLesson|"+tomorrow)!=null,"Sincronização preserva cronômetro rodando");fire(timer,intent(timer,"timer|timerLesson|"+tomorrow));Notification tn=timer.notifications.active.get("timerLesson|"+tomorrow);check(tn!=null&&(tn.flags&Notification.FLAG_INSISTENT)!=0,"Fim da aula toca com alarme insistente");check(AlarmStore.plans(timer).size()==1,"Cronômetro encerrado sem apagar o aviso normal da aula");AlarmScheduler.startLessonTimer(timer,new JSONObject().put("lessonId","timerLesson").put("classDate",tomorrow).put("triggerAtMillis",System.currentTimeMillis()+60000).put("student","Jéssica"));AlarmScheduler.cancelLessonTimer(timer,"timerLesson",tomorrow);check(stored(timer,"timer|timerLesson|"+tomorrow)==null,"Parar cronômetro retira o alarme de fim");
 MainActivity audio=context();String beforeLesson=AudioSettings.lessonChannelId(audio),beforeTimer=AudioSettings.timerChannelId(audio);JSONObject saved=AudioSettings.saveBase64(audio,"lesson","toque.mp3","audio/mpeg",java.util.Base64.getEncoder().encodeToString(new byte[]{1,2,3,4}));check("toque.mp3".equals(saved.optString("lessonName")),"Áudio do despertador salvo com nome");check(!beforeLesson.equals(AudioSettings.lessonChannelId(audio)),"Canal do despertador muda ao escolher áudio");AudioSettings.saveBase64(audio,"timer","fim.ogg","audio/ogg",java.util.Base64.getEncoder().encodeToString(new byte[]{5,6,7,8}));check(!beforeTimer.equals(AudioSettings.timerChannelId(audio)),"Canal do fim da aula muda ao escolher áudio");AlarmReceiver.createChannel(audio);check(audio.notifications.channels.containsKey(AudioSettings.lessonChannelId(audio))&&audio.notifications.channels.containsKey(AudioSettings.timerChannelId(audio)),"Canais personalizados criados");
 MainActivity quota=context();quota.prefs.failPrefix="agenda_snapshot";boolean fail=false;try{AlarmScheduler.synchronize(quota,agenda(a));}catch(Exception e){fail=true;}check(fail&&quota.alarms.scheduled.isEmpty(),"Falha de snapshot não programa aviso perdido");quota.prefs.failPrefix="plan_";fail=false;try{AlarmScheduler.synchronize(quota,agenda(a));}catch(Exception e){fail=true;}check(fail&&quota.alarms.scheduled.isEmpty(),"Falha de gravação cancela o PendingIntent sem plano");
 MainActivity.Bridge bridge=new MainActivity.Bridge(context());check(!bridge.syncLessonAlarms(new JSONObject().put("schema",3).toString()),"Ponte rejeita esquema inválido");check(bridge.syncLessonAlarms(agenda(a).toString()),"Ponte mantém esquema 4");check(new JSONObject(bridge.getAlarmStatus()).optBoolean("ready"),"Diagnóstico disponível pela ponte");
 System.out.println(checks+" verificações nativas passaram: horários, cancelamento, edição, recorrência, permissões, som, entrega, teste, financeiro e armazenamento. Android simulado; o toque deve ser conferido no aparelho.");
}}
''',
}


def main():
    source = (PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/MainActivity.java').read_text()
    bridge = source[source.index('@JavascriptInterface public String getAlarmStatus()'):source.index('        @JavascriptInterface\n        public void openMap(')]
    exact = source[source.index('    private static boolean needsExactAlarmPermission('):source.index('    @Override protected void onDestroy()')]
    STUBS['com/tiagolima/agendapersonal/MainActivity.java'] = '''package com.tiagolima.agendapersonal;
import android.app.*;import android.content.*;import android.net.Uri;import android.os.Build;import android.provider.Settings;import android.widget.Toast;import android.webkit.JavascriptInterface;import org.json.*;
public class MainActivity extends Activity {''' + exact + '''public static class Bridge {private final Activity activity;private boolean exactAlarmPromptShown;Bridge(Activity a){activity=a;}''' + bridge + '}}'
    assert 'requestCode == 1001 && webView != null' in source
    java, javac = shutil.which('java'), shutil.which('javac')
    if not java:
        raise SystemExit('Java 17 é necessário.')
    with tempfile.TemporaryDirectory(prefix='agenda-alarm-tests-') as directory:
        root = Path(directory)
        sources = []
        for name, text in STUBS.items():
            file = root / name
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_text(text, encoding='utf-8')
            sources.append(str(file))
        for name in ('AlarmTimes', 'AlarmStore', 'AlarmScheduler', 'AlarmReceiver', 'AlarmStatus', 'AudioSettings', 'MapLinks'):
            sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal' / (name + '.java')))
        sources.append(str(PROJECT / 'tests/AlarmTimesTest.java'))
        subprocess.run(([javac] if javac else [java, 'com.sun.tools.javac.Main']) + ['-encoding', 'UTF-8', '-d', str(root / 'classes')] + sources, check=True)
        for name in ('NativeAlarmHarness', 'AlarmTimesTest'):
            subprocess.run([java, '-cp', str(root / 'classes'), 'com.tiagolima.agendapersonal.' + name], check=True)


if __name__ == '__main__':
    main()
