const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const assets = path.join(__dirname, '../app/src/main/assets');
const source = fs.readFileSync(path.join(assets, 'avaliacoes.html'), 'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
const AGENDA = 'agendaPersonalTL_v1', EVAL = 'tiago-lima-avaliacoes-v1';
const phoneA = '69 99999-1111', phoneB = '69 99999-2222';
const photoA = 'data:image/jpeg;base64,AAAA', photoB = 'data:image/png;base64,BBBB';
const student = (id, name, phone = '', photoDataUrl = '') => ({ id, name, phone, photoDataUrl, location: 'Local preservado', financeEnabled: false });
const agenda = students => ({ students, lessons: [{ id: 'lesson', studentId: students[0]?.id }], occurrenceStatus: { example: 'realizada' }, history: [], payments: [{ id: 'payment' }], extra: 'preservado' });
const client = (id, name, agendaStudentId, phone = '') => ({ id, name, agendaStudentId, phone, equation: 'female', assessments: [{ id: 'record-' + id, date: '2026-10-01', data: { clientName: name, clientPhone: phone, equation: 'female', date: '2026-10-01' } }] });

function extractFunction(name) {
  const lines = source.split('\n');
  const start = lines.findIndex(line => new RegExp(`^  (?:async )?function ${name}\\(`).test(line));
  assert.ok(start >= 0, 'Function not found: ' + name);
  let end = start + 1;
  while (end < lines.length && !/^  (?:async )?function \w+\(/.test(lines[end])) end++;
  const range = lines.slice(start, end).join('\n');
  const closing = range.lastIndexOf('\n  }');
  return closing < 0 ? lines[start] : range.slice(0, closing + 4);
}

function runtime(students = [], clients = [], initialId = '', options = {}) {
  const storage = new Map([[AGENDA, JSON.stringify(agenda(students))], [EVAL, JSON.stringify({ clients })]]);
  const callbacks = {}, elements = new Map();
  const element = id => {
    if (!elements.has(id)) elements.set(id, { hidden: false, innerHTML: '', textContent: '', value: '' });
    return elements.get(id);
  };
  const context = {
    Date, console, crypto: {},
    URLSearchParams,
    sessionStorage: { getItem: key => storage.get('session:' + key) || null, setItem: (key, value) => storage.set('session:' + key, value), removeItem: key => storage.delete('session:' + key) },
    history: { replaceState: (_, __, url) => { context.formUrl = url; } },
    localStorage: { getItem: key => storage.get(key) || null, setItem: (key, value) => storage.set(key, value), removeItem: key => storage.delete(key) },
    agendaParams: new URLSearchParams(options.new ? { new: '1' } : {}),
    agendaStudentId: initialId, agendaStudentName: options.urlName || students.find(s => s.id === initialId)?.name || '',
    agendaContextApplied: false, pendingAgendaStudentId: '',
    clients: JSON.parse(JSON.stringify(clients)), selectedClientId: null, activeAssessmentId: null,
    calls: [], fields: {}, confirmations: [], data: null, autoGoals: false,
    errorsEl: {}, saveButton: {},
    form: { elements: { equation: {} }, addEventListener: (event, callback) => { callbacks[event] = callback; } },
    document: { getElementById: element },
    setField: (key, value) => { context.fields[key] = value; },
    confirm: message => { context.confirmations.push(message); return options.confirm === true; },
    updatePreview() {}, fillPrevious() {}, validate() { return []; },
    collect: () => context.data,
    savePhotoSlots: async () => {}, currentRecord: () => ({}), openReport() {},
    error: message => { throw new Error(message); }
  };
  context.startAssessment = (record, newClient) => {
    context.activeAssessmentId = record?.id || null;
    const current = context.clients.find(c => c.id === context.selectedClientId);
    if (current && !newClient) context.pendingAgendaStudentId = current.agendaStudentId || '';
    context.calls.push({ selectedClientId: context.selectedClientId, newClient });
    context.renderAssessmentStudent();
  };
  vm.createContext(context);
  vm.runInContext(`
    const STORAGE_KEY = '${EVAL}', AGENDA_DB_KEY = '${AGENDA}';
    async function ensureStorage() { return 'localstorage'; }
    async function loadWorkspace() { clients = (await readState()).clients; }
  `, context);
  for (const name of ['escapeHTML', 'pdfKey', 'uid', 'normalizeAgendaName', 'studentNameKey', 'studentPhoneKey', 'validStudentPhone', 'readAgendaState', 'agendaStudentForClient', 'phoneForClient', 'validStudentType', 'studentTypeForClient', 'ensureAgendaStudentProfile', 'emptyState', 'readState', 'writeState', 'findAssessment', 'syncClientName', 'syncClientIdentity', 'writeAssessmentState', 'evaluationClientForAgendaStudent', 'studentAvatarContent', 'selectedClient', 'renderAssessmentStudent', 'api', 'setEvaluationFormContext', 'startNewClientAssessment', 'applyAgendaStudentContext', 'pdfImportMatches', 'pdfImportNeedsChoice']) {
    vm.runInContext(extractFunction(name), context, { filename: 'avaliacoes.html:' + name });
  }
  const start = source.indexOf("  form.addEventListener('submit', async event => {");
  const end = source.indexOf("  document.getElementById('report-to-client')", start);
  vm.runInContext(source.slice(start, end), context);
  return { context, callbacks, elements, storage,
    agenda: () => JSON.parse(storage.get(AGENDA)),
    evaluations: () => JSON.parse(storage.get(EVAL)).clients };
}

async function first(rt, name, phone = '', agendaStudentId = '', studentType = '') {
  return await rt.context.api('/api/workspace', { method: 'POST', body: JSON.stringify({
    action: 'firstAssessment', name, equation: 'female', agendaStudentId,
    data: { clientName: name, clientPhone: phone, equation: 'female', date: '2026-10-03', ...(studentType ? { studentType } : {}) }
  }) });
}

async function run() {
  let checks = 0;
  const auto = runtime();
  const created = await first(auto, 'Ana Silva', phoneA);
  assert.equal(auto.agenda().students[0].name, 'Ana Silva');
  assert.equal(auto.agenda().students[0].phone, phoneA);
  assert.equal(auto.evaluations()[0].agendaStudentId, created.agendaStudentId); checks++;

  const surnames = runtime([student('a', 'Ana Silva', phoneA)]);
  await first(surnames, 'Ana Santos', phoneA);
  assert.equal(surnames.agenda().students.length, 2);
  assert.notEqual(surnames.evaluations()[0].agendaStudentId, 'a'); checks++;

  const sameName = runtime([student('a', 'Ana Silva', phoneA)]);
  await first(sameName, 'Ana Silva', phoneB);
  assert.equal(sameName.agenda().students.length, 2);
  assert.notEqual(sameName.evaluations()[0].agendaStudentId, 'a'); checks++;

  const formatted = runtime([student('a', 'Ana Silva', phoneA, photoA)]);
  await first(formatted, ' ana   silva ', '+55 (69) 99999-1111');
  assert.equal(formatted.agenda().students.length, 1);
  assert.equal(formatted.evaluations()[0].agendaStudentId, 'a');
  assert.equal(formatted.agenda().students[0].photoDataUrl, photoA);
  assert.equal(formatted.agenda().extra, 'preservado'); checks++;

  const missingPhone = runtime([student('a', 'Ana Silva', phoneA)]);
  await assert.rejects(first(missingPhone, 'Ana Silva'), /Informe o WhatsApp/);
  assert.equal(missingPhone.evaluations().length, 0);
  assert.equal(missingPhone.agenda().students.length, 1); checks++;

  const homonym = runtime([student('a', 'Ana Silva', phoneA, photoA), student('b', 'Ana Silva', phoneB, photoB)], [client('eval-a', 'Ana Silva', 'a', phoneA)], 'b');
  await homonym.context.applyAgendaStudentContext();
  assert.equal(homonym.evaluations()[0].agendaStudentId, 'a');
  assert.equal(homonym.context.selectedClientId, null);
  assert.equal(homonym.context.pendingAgendaStudentId, 'b');
  assert.equal(homonym.context.fields.clientPhone, phoneB);
  assert.ok(homonym.elements.get('assessment-student').innerHTML.includes(photoB));
  assert.ok(!homonym.elements.get('assessment-student').innerHTML.includes(photoA));
  await first(homonym, 'Ana Silva', phoneB, 'b');
  assert.deepEqual(homonym.evaluations().map(c => c.agendaStudentId), ['a', 'b']); checks++;

  const sharedPhone = runtime([student('a', 'Ana Silva', phoneA), student('b', 'Ana Silva', phoneA)], [client('eval-a', 'Ana Silva', 'a', phoneA)], 'b');
  await sharedPhone.context.applyAgendaStudentContext();
  assert.equal(sharedPhone.context.selectedClientId, null);
  await first(sharedPhone, 'Ana Silva', phoneA, 'b');
  assert.deepEqual(sharedPhone.evaluations().map(c => c.agendaStudentId), ['a', 'b']); checks++;

  const ambiguous = runtime([student('a', 'Ana Silva', phoneA), student('b', 'Ana Silva', phoneA)]);
  await assert.rejects(first(ambiguous, 'Ana Silva', phoneA), /Confira a foto|confira a foto/);
  assert.equal(ambiguous.evaluations().length, 0); checks++;

  const switched = runtime([student('a', 'Aluno A', phoneA, photoA)], [client('eval-a', 'Aluno A', 'a', phoneA)], 'a');
  await switched.context.applyAgendaStudentContext();
  switched.context.startNewClientAssessment();
  assert.equal(switched.context.pendingAgendaStudentId, '');
  assert.equal(switched.context.formUrl, 'avaliacoes.html?new=1');
  assert.equal(switched.context.sessionStorage.getItem('agendaReturnProfile'), null);
  assert.equal(switched.elements.get('assessment-student').hidden, true);
  switched.context.data = { clientName: 'Aluno B', clientPhone: phoneB, studentType: 'online', equation: 'female', date: '2026-10-03' };
  await switched.callbacks.submit({ preventDefault() {} });
  const b = switched.evaluations().find(c => c.name === 'Aluno B');
  assert.notEqual(b.agendaStudentId, 'a');
  assert.equal(switched.context.sessionStorage.getItem('agendaReturnProfile'), b.agendaStudentId);
  assert.equal(switched.agenda().students.find(s => s.id === b.agendaStudentId).name, 'Aluno B'); checks++;

  const renamed = runtime([student('a', 'Nome Antigo', phoneA, photoA)], [client('eval-a', 'Nome Antigo', 'a', phoneA)], 'a', { urlName: 'Nome Antigo' });
  await renamed.context.api('/api/workspace', { method: 'POST', body: JSON.stringify({ action: 'assessment', clientId: 'eval-a', data: { clientName: 'Nome Corrigido', clientPhone: phoneB, date: '2026-10-03' } }) });
  assert.equal(renamed.agenda().students[0].name, 'Nome Corrigido');
  assert.equal(renamed.agenda().students[0].phone, phoneB);
  assert.equal(renamed.agenda().students[0].photoDataUrl, photoA);
  assert.deepEqual(renamed.agenda().payments, [{ id: 'payment' }]);
  await renamed.context.loadWorkspace();
  await renamed.context.applyAgendaStudentContext();
  assert.equal(renamed.evaluations()[0].name, 'Nome Corrigido');
  const editId = renamed.evaluations()[0].assessments[0].id;
  await renamed.context.api('/api/workspace', { method: 'PUT', body: JSON.stringify({ id: editId, data: { clientName: 'Nome Final', clientPhone: phoneA, date: '2026-10-01' } }) });
  assert.equal(renamed.agenda().students[0].name, 'Nome Final'); checks++;

  const changedPhone = runtime([student('a', 'Ana Silva', phoneB, photoA), student('b', 'Ana Silva', phoneA, photoB)],
    [client('eval-a', 'Ana Silva', 'a', phoneA), client('eval-b', 'Ana Silva', 'b', phoneA)]);
  const originalEvaluations = changedPhone.storage.get(EVAL);
  assert.equal(changedPhone.context.phoneForClient(changedPhone.context.clients[0]), phoneB);
  assert.equal(changedPhone.context.phoneForClient(changedPhone.context.clients[1]), phoneA);
  assert.equal(changedPhone.storage.get(EVAL), originalEvaluations);
  await changedPhone.context.api('/api/workspace', { method: 'POST', body: JSON.stringify({ action: 'assessment', clientId: 'eval-a',
    data: { clientName: 'Ana Silva', date: '2026-10-03' } }) });
  assert.equal(changedPhone.agenda().students[0].phone, phoneB);
  assert.ok(changedPhone.evaluations()[0].assessments.every(record => record.data.clientPhone === phoneB));
  assert.equal(changedPhone.evaluations()[1].phone, phoneA);
  assert.equal(changedPhone.agenda().students[0].photoDataUrl, photoA);
  assert.equal(changedPhone.agenda().students[1].photoDataUrl, photoB); checks++;

  const phoneEditId = changedPhone.evaluations()[0].assessments[0].id;
  await changedPhone.context.api('/api/workspace', { method: 'PUT', body: JSON.stringify({ id: phoneEditId,
    data: { clientName: 'Ana Silva', clientPhone: phoneA, date: '2026-10-01' } }) });
  assert.equal(changedPhone.agenda().students[0].phone, phoneA);
  assert.equal(changedPhone.evaluations()[0].phone, phoneA); checks++;

  const absentPhone = runtime([student('a', 'Ana Silva')], [client('eval-a', 'Ana Silva', 'a', phoneA)]);
  assert.equal(absentPhone.context.phoneForClient(absentPhone.context.clients[0]), '');
  const detachedClient = client('detached', 'Ana Silva', undefined, phoneB);
  assert.equal(absentPhone.context.phoneForClient(detachedClient), phoneB);
  const deletedProfile = client('deleted-profile', 'Ana Silva', 'missing', phoneA);
  assert.equal(absentPhone.context.phoneForClient(deletedProfile), phoneA); checks++;

  for (const type of ['presencial', 'online']) {
    const typed = runtime();
    await first(typed, 'Aluno por avaliação', phoneA, '', type);
    assert.equal(typed.agenda().students[0].studentType, type);
    assert.equal(typed.evaluations()[0].studentType, type); checks++;
  }
  const invalidType = runtime(), beforeType = invalidType.storage.get(AGENDA);
  await assert.rejects(first(invalidType, 'Tipo inválido', phoneA, '', 'hibrido'), /Presencial ou Online/);
  assert.equal(invalidType.storage.get(AGENDA), beforeType);
  assert.equal(invalidType.evaluations().length, 0); checks++;

  const typeChanged = runtime([
    { ...student('a', 'Ana Silva', phoneA, photoA), studentType: 'online' },
    { ...student('b', 'Ana Silva', phoneB, photoB), studentType: 'presencial' }
  ], [{ ...client('eval-a', 'Ana Silva', 'a', phoneA), studentType: 'presencial' }, client('eval-b', 'Ana Silva', 'b', phoneB)]);
  assert.equal(typeChanged.context.studentTypeForClient(typeChanged.context.clients[0]), 'online');
  assert.equal(typeChanged.context.studentTypeForClient(typeChanged.context.clients[1]), 'presencial');
  const typeEditId = typeChanged.evaluations()[0].assessments[0].id;
  await typeChanged.context.api('/api/workspace', { method: 'PUT', body: JSON.stringify({ id: typeEditId,
    data: { clientName: 'Ana Silva', clientPhone: phoneA, date: '2026-10-01' } }) });
  assert.equal(typeChanged.agenda().students[0].studentType, 'online');
  assert.equal(typeChanged.evaluations()[0].studentType, 'online'); checks++;
  await typeChanged.context.api('/api/workspace', { method: 'PUT', body: JSON.stringify({ id: typeEditId,
    data: { clientName: 'Ana Silva', clientPhone: phoneA, studentType: 'presencial', date: '2026-10-01' } }) });
  assert.equal(typeChanged.agenda().students[0].studentType, 'presencial');
  assert.equal(typeChanged.agenda().students[1].studentType, 'presencial');
  assert.equal(typeChanged.agenda().students[0].photoDataUrl, photoA);
  assert.equal(typeChanged.agenda().students[1].photoDataUrl, photoB);
  assert.deepEqual(typeChanged.agenda().payments, [{ id: 'payment' }]); checks++;
  const legacyType = runtime([student('a', 'Aluno antigo', phoneA)], [client('eval-a', 'Aluno antigo', 'a', phoneA)]);
  assert.equal(legacyType.context.studentTypeForClient(legacyType.context.clients[0]), '');
  assert.equal(legacyType.agenda().students[0].studentType, undefined); checks++;

  await assert.rejects(first(renamed, 'Nome Final', phoneA, 'a'), /já tem histórico/);
  assert.equal(renamed.evaluations().length, 1); checks++;

  const stale = runtime([student('b', 'Ana Silva', phoneB)]);
  await assert.rejects(first(stale, 'Ana Silva', phoneB, 'deleted-a'), /não está mais na agenda/);
  assert.equal(stale.evaluations().length, 0); checks++;

  const legacy = runtime([student('a', 'Ana Silva', phoneA)], [client('legacy', 'Ana Silva', undefined, phoneA)], 'a');
  await legacy.context.applyAgendaStudentContext();
  assert.equal(legacy.evaluations()[0].agendaStudentId, 'a');
  assert.equal(legacy.context.confirmations.length, 0); checks++;

  const old = client('legacy', 'Ana Silva');
  delete old.phone;
  const approvedLegacy = runtime([student('a', 'Ana Silva', phoneA)], [old], 'a', { confirm: true });
  await approvedLegacy.context.applyAgendaStudentContext();
  assert.equal(approvedLegacy.evaluations()[0].agendaStudentId, 'a');
  assert.equal(approvedLegacy.context.confirmations.length, 1);
  const declinedLegacy = runtime([student('a', 'Ana Silva', phoneA)], [old], 'a');
  await declinedLegacy.context.applyAgendaStudentContext();
  assert.equal(declinedLegacy.evaluations()[0].agendaStudentId, undefined); checks++;

  const rollback = runtime();
  const previous = rollback.storage.get(AGENDA);
  rollback.context.writeState = async () => { throw new Error('Simulated storage failure'); };
  await assert.rejects(first(rollback, 'Novo aluno', phoneA), /Simulated storage failure/);
  assert.equal(rollback.storage.get(AGENDA), previous);
  assert.equal(rollback.evaluations().length, 0); checks++;

  const damaged = runtime();
  damaged.storage.set(AGENDA, 'invalid-json');
  await assert.rejects(first(damaged, 'Novo aluno', phoneA), /Restaure um backup/);
  assert.equal(damaged.storage.get(AGENDA), 'invalid-json'); checks++;

  const top = runtime([], [], '', { new: true });
  await top.context.applyAgendaStudentContext();
  assert.equal(top.context.calls.length, 1);
  assert.equal(top.context.calls[0].newClient, true); checks++;

  const imported = runtime([], [client('a', 'Ana Silva', undefined, phoneA), client('b', 'Ana Silva', undefined, phoneB)]);
  assert.equal(imported.context.pdfImportMatches('Ana Silva', '+55 69 99999-2222')[0].id, 'b');
  assert.equal(imported.context.pdfImportMatches('Ana Silva', '69 99999-3333').length, 0);
  assert.equal(imported.context.pdfImportNeedsChoice(imported.context.pdfImportMatches('Ana Silva', ''), ''), true); checks++;

  const index = fs.readFileSync(path.join(assets, 'index.html'), 'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
  const ctx = { URLSearchParams, location: {}, sessionStorage: { removeItem() {}, setItem() {} }, state: { students: homonym.agenda().students }, studentById: () => null,
    currentProfileStudentId: '', currentScreen: 'today', studentsPendingView: false, studentViewType: 'presencial', load: () => switched.agenda(), renderAll() {}, syncNativeAlarms() {} };
  vm.createContext(ctx);
  for (const name of ['studentNameKey', 'studentPhoneKey', 'linkedEvaluationClient', 'openEvaluations', 'refreshAgendaState']) {
    const start = index.indexOf('function ' + name + '(');
    const next = index.slice(start + 1).search(/^\s*(?:async )?function /m);
    vm.runInContext(name === 'refreshAgendaState' ? index.slice(start).split('\n')[0] : index.slice(start, next < 0 ? undefined : start + 1 + next), ctx);
  }
  assert.equal(ctx.linkedEvaluationClient(homonym.evaluations(), homonym.agenda().students[1]).agendaStudentId, 'b');
  assert.equal(ctx.linkedEvaluationClient([client('a', 'Ana Silva', 'a', phoneA)], student('b', 'Ana Silva', phoneB)), null);
  assert.equal(ctx.studentPhoneKey('(55) 99999-1111'), '5555999991111');
  ctx.openEvaluations();
  assert.equal(ctx.location.href, 'avaliacoes.html?new=1'); checks++;
  ctx.currentScreen = 'students';
  ctx.studentViewType = 'online';
  ctx.openEvaluations();
  assert.equal(ctx.location.href, 'avaliacoes.html?new=1&studentType=online'); checks++;
  ctx.studentsPendingView = true;
  ctx.openEvaluations();
  assert.equal(ctx.location.href, 'avaliacoes.html?new=1'); checks++;
  ctx.refreshAgendaState();
  assert.equal(ctx.state.students.some(s => s.name === 'Aluno B'), true);
  assert.equal(ctx.state.extra, 'preservado'); checks++;

  console.log(`Identificação verificada: ${checks} cenários de nome completo, telefone, vínculo, foto, edição, importação e falha de armazenamento.`);
}

run().catch(error => { console.error(error); process.exitCode = 1; });
