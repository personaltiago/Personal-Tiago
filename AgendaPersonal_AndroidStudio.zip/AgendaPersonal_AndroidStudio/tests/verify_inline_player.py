"""Exercise the production inline player against small simulated Android views."""
from pathlib import Path
import shutil
import subprocess
import tempfile
from verify_native_alarms import STUBS as ALARM_STUBS

PROJECT = Path(__file__).resolve().parents[1]
STUBS = {
    'org/json/JSONObject.java': ALARM_STUBS['org/json/JSONObject.java'].replace('public long getLong(', 'public double getDouble(String k){return ((Number)get(k)).doubleValue();}public static String quote(String s){return "\\\""+s+"\\\"";}public long getLong('),
    'org/json/JSONArray.java': ALARM_STUBS['org/json/JSONArray.java'],
    'android/content/Context.java': 'package android.content;public class Context{public String getPackageName(){return "com.tiagolima.agendapersonal";}}',
    'android/content/Intent.java': 'package android.content;public class Intent{public static final String ACTION_VIEW="view";public Intent(String a,android.net.Uri uri){}}',
    'android/app/Activity.java': 'package android.app;public class Activity extends android.content.Context{public int external;public void runOnUiThread(Runnable r){r.run();}public void startActivity(android.content.Intent i){external++;}public Object getWindow(){return this;}}',
    'android/graphics/Color.java': 'package android.graphics;public class Color{public static final int BLACK=0;}',
    'android/net/Uri.java': 'package android.net;public class Uri{private final java.net.URI uri;private Uri(String s){uri=java.net.URI.create(s);}public static Uri parse(String s){return new Uri(s);}public String getHost(){return uri.getHost();}public String getScheme(){return uri.getScheme();}}',
    'android/view/View.java': '''package android.view;public class View{public static final int VISIBLE=0,GONE=8;public int visibility=0,width=1000,height=1800;public android.view.ViewGroup.LayoutParams layout;
public int getWidth(){return width;}public int getHeight(){return height;}public void setLayoutParams(android.view.ViewGroup.LayoutParams p){layout=p;width=p.width;height=p.height;}public void setVisibility(int v){visibility=v;}public void setBackgroundColor(int c){}}''',
    'android/view/ViewGroup.java': '''package android.view;public class ViewGroup extends View{public static class LayoutParams{public int width,height;public LayoutParams(int w,int h){width=w;height=h;}}}''',
    'android/widget/FrameLayout.java': '''package android.widget;import java.util.*;public class FrameLayout extends android.view.ViewGroup{public java.util.List<android.view.View> children=new ArrayList<>();public FrameLayout(android.content.Context c){}public void setClipChildren(boolean b){}public void addView(android.view.View v,LayoutParams p){v.setLayoutParams(p);children.add(v);}public void removeView(android.view.View v){children.remove(v);}public static class LayoutParams extends android.view.ViewGroup.LayoutParams{public int leftMargin,topMargin;public LayoutParams(int w,int h){super(w,h);}}}''',
    'android/widget/Toast.java': 'package android.widget;public class Toast{public static final int LENGTH_SHORT=0;public static Toast makeText(android.content.Context c,String t,int d){return new Toast();}public void show(){}}',
    'android/webkit/WebSettings.java': '''package android.webkit;public class WebSettings{public static final int MIXED_CONTENT_NEVER_ALLOW=1;public boolean file=true,content=true,fileUrls=true,universal=true,safe;public int mixed;
public void setJavaScriptEnabled(boolean v){}public void setDomStorageEnabled(boolean v){}public void setMediaPlaybackRequiresUserGesture(boolean v){}public void setAllowFileAccess(boolean v){file=v;}public void setAllowContentAccess(boolean v){content=v;}public void setAllowFileAccessFromFileURLs(boolean v){fileUrls=v;}public void setAllowUniversalAccessFromFileURLs(boolean v){universal=v;}public void setMixedContentMode(int v){mixed=v;}public void setSafeBrowsingEnabled(boolean v){safe=v;}}''',
    'android/webkit/WebResourceRequest.java': 'package android.webkit;public interface WebResourceRequest{boolean isForMainFrame();boolean hasGesture();android.net.Uri getUrl();}',
    'android/webkit/WebViewClient.java': 'package android.webkit;public class WebViewClient{public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return false;}}',
    'android/webkit/WebChromeClient.java': 'package android.webkit;public class WebChromeClient{public interface CustomViewCallback{void onCustomViewHidden();}public void onShowCustomView(android.view.View v,CustomViewCallback c){}public void onHideCustomView(){}}',
    'android/webkit/WebView.java': '''package android.webkit;public class WebView extends android.view.View{public static WebView last;public final WebSettings settings=new WebSettings();public WebViewClient client;public WebChromeClient chrome;public String origin="",html="",script="",url="";public int loads,interfaces,pauses,resumes;public boolean destroyed;
public WebView(android.content.Context c){last=this;}public WebSettings getSettings(){return settings;}public void setWebViewClient(WebViewClient c){client=c;}public void setWebChromeClient(WebChromeClient c){chrome=c;}public void addJavascriptInterface(Object o,String n){interfaces++;}public void loadDataWithBaseURL(String base,String data,String mime,String encoding,String history){origin=base;html=data;loads++;}public void evaluateJavascript(String s,Object callback){script=s;}public void onPause(){pauses++;}public void onResume(){resumes++;}public void stopLoading(){}public void loadUrl(String s){url=s;}public void destroy(){destroyed=true;}}''',
    'androidx/core/view/WindowInsetsControllerCompat.java': 'package androidx.core.view;public class WindowInsetsControllerCompat{public static final int BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE=1;public boolean hidden;public void setSystemBarsBehavior(int b){}public void hide(int t){hidden=true;}public void show(int t){hidden=false;}}',
    'androidx/core/view/WindowInsetsCompat.java': 'package androidx.core.view;public class WindowInsetsCompat{public static class Type{public static int systemBars(){return 1;}}}',
    'androidx/core/view/WindowCompat.java': 'package androidx.core.view;public class WindowCompat{public static final WindowInsetsControllerCompat controller=new WindowInsetsControllerCompat();public static WindowInsetsControllerCompat getInsetsController(Object w,android.view.View root){return controller;}}',
    'com/tiagolima/agendapersonal/NativeInlineHarness.java': r'''package com.tiagolima.agendapersonal;import org.json.*;import android.app.*;import android.view.*;import android.webkit.*;import android.widget.*;import androidx.core.view.*;
public class NativeInlineHarness{
static int count;static void check(boolean v,String m){count++;if(!v)throw new AssertionError(m);}
static JSONObject bounds(){return new JSONObject().put("viewportWidth",500).put("viewportHeight",900).put("left",50).put("top",100).put("width",350).put("height",240).put("clipTop",0).put("clipBottom",900).put("visible",true);}
static JSONObject request(String key){return new JSONObject().put("key",key).put("videoId","M7lc1UVf-VE").put("startSeconds",30).put("bounds",bounds());}
static WebResourceRequest nav(String url,boolean main,boolean gesture){return new WebResourceRequest(){public boolean isForMainFrame(){return main;}public boolean hasGesture(){return gesture;}public android.net.Uri getUrl(){return android.net.Uri.parse(url);}};}
public static void main(String[] args)throws Exception{
InlineVideoPlacement box=InlineVideoPlacement.calculate(500,900,50,100,350,240,0,900,true,1000,1800);
check(box.visible&&box.left==100&&box.top==200&&box.width==700&&box.height==480,"Scale matches agenda viewport");
box=InlineVideoPlacement.calculate(500,900,50,-60,350,240,0,900,true,1000,1800);check(box.top==0&&box.height==360&&box.playerTop==-120&&box.playerHeight==480,"Partial scrolling clips the view, preserving player size");
box=InlineVideoPlacement.calculate(500,900,50,1200,350,240,0,900,true,1000,1800);check(!box.visible&&box.height==0,"Offscreen player hidden");
box=InlineVideoPlacement.calculate(500,900,50,100,350,240,0,900,false,1000,1800);check(!box.visible,"Covered dialog hides player");
for(double width:new double[]{0,199,501,Double.NaN,Double.POSITIVE_INFINITY}){boolean reject=false;try{InlineVideoPlacement.calculate(500,900,50,100,width,240,0,900,true,1000,1800);}catch(IllegalArgumentException e){reject=true;}check(reject,"Reject unsafe/minimum width");}
Activity activity=new Activity();FrameLayout root=new FrameLayout(activity);WebView agenda=new WebView(activity);root.addView(agenda,new FrameLayout.LayoutParams(1000,1800));InlineYouTubePlayer video=new InlineYouTubePlayer(activity,root,agenda);
InlineYouTubePlayer.validate(request("first"));video.open(request("first"));WebView first=WebView.last;check(video.isActive()&&root.children.size()==2,"Player attached to agenda, no new activity");check(activity.external==0,"Playback does not launch another screen");
check(first.interfaces==0&&!first.settings.file&&!first.settings.content&&!first.settings.fileUrls&&!first.settings.universal,"Remote video has no bridge/file permissions");check(first.settings.safe&&first.settings.mixed==WebSettings.MIXED_CONTENT_NEVER_ALLOW,"Remote security settings retained");
check(first.origin.equals("https://com.tiagolima.agendapersonal/")&&first.html.contains("start:30"),"App identity and start preserved");check(first.html.contains("padding:0!important")&&first.html.contains("min-height:200px"),"Inline player fills only the reserved area");check(first.html.contains("autoplay:1"),"Requested visible video may start playing");
FrameLayout surface=(FrameLayout)root.children.get(1);check(((FrameLayout.LayoutParams)surface.layout).leftMargin==100&&surface.height==480,"Player aligned with exercise card");
video.position("first",bounds().put("top",-60));check(((FrameLayout.LayoutParams)first.layout).topMargin==-120&&surface.height==360,"Native view follows scroll");check(first.loads==1,"Scrolling does not reload playback");
video.position("stale",bounds());check(((FrameLayout.LayoutParams)first.layout).topMargin==-120,"Old position request ignored");
video.position("first",bounds().put("visible",false));check(surface.visibility==View.GONE&&first.script.contains("pauseWorkoutVideo"),"Covered/hidden player pauses");video.position("first",bounds());check(surface.visibility==View.VISIBLE&&first.loads==1,"Reopening keeps the same player");
final int[] hidden={0};first.chrome.onShowCustomView(new View(),()->hidden[0]++);check(root.children.size()==3&&WindowCompat.controller.hidden,"Fullscreen stays in agenda activity");check(video.leaveFullScreen()&&root.children.size()==2&&hidden[0]==1&&!WindowCompat.controller.hidden,"Back exits fullscreen and restores card");check(!video.leaveFullScreen(),"Repeated fullscreen close harmless");
video.onPause();video.onResume();check(first.pauses==1&&first.resumes==1&&first.script.contains("pauseWorkoutVideo"),"Background pauses media");
check(first.client.shouldOverrideUrlLoading(first,nav("https://youtube.com/watch?v=M7lc1UVf-VE",true,true))&&activity.external==1,"YouTube opens externally only by user action");check(first.client.shouldOverrideUrlLoading(first,nav("file:///android_asset/index.html",true,true))&&activity.external==1,"Player cannot navigate to local data");check(!first.client.shouldOverrideUrlLoading(first,nav("https://www.youtube.com/embed/M7lc1UVf-VE",false,false)),"Embed subframe supported");
video.open(request("second"));WebView second=WebView.last;check(first.destroyed&&first.url.equals("about:blank")&&root.children.size()==2,"New video disposes previous media");video.close("first");check(video.isActive()&&!second.destroyed,"Old close request cannot close new video");video.close("second");check(!video.isActive()&&second.destroyed&&root.children.size()==1,"Close disposes view and returns to exercise");
video.open(request("partial").put("bounds",bounds().put("top",780)));check(WebView.last.html.contains("autoplay:0"),"Half-hidden player does not start automatically");video.close();
for(JSONObject invalid:new JSONObject[]{request("bad").put("videoId","short"),request("bad").put("startSeconds",-1),request("bad!")}){boolean reject=false;try{InlineYouTubePlayer.validate(invalid);}catch(Exception e){reject=true;}check(reject,"Invalid payload rejected");}
System.out.println(count+" verificações do player no cartão passaram. Views Android simuladas.");}}
''',
}


def main():
    java, javac = shutil.which('java'), shutil.which('javac')
    with tempfile.TemporaryDirectory(prefix='agenda-inline-player-') as directory:
        root = Path(directory)
        files = []
        for name, content in STUBS.items():
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding='utf-8')
            files.append(str(target))
        for name in ('YouTubePlayerPage', 'InlineVideoPlacement', 'InlineYouTubePlayer'):
            files.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal' / (name + '.java')))
        subprocess.run(([javac] if javac else [java, 'com.sun.tools.javac.Main']) + ['-encoding', 'UTF-8', '-d', str(root / 'classes')] + files, check=True)
        subprocess.run([java, '-cp', str(root / 'classes'), 'com.tiagolima.agendapersonal.NativeInlineHarness'], check=True)


if __name__ == '__main__':
    main()
