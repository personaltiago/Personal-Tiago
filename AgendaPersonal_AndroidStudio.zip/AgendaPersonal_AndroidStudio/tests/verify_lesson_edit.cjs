const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const source=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const initial={students:[
 {id:'a',name:'Jéssica Silva',studentType:'presencial',phone:'69 99999-1111',photoDataUrl:'foto-a',location:'Local padrão A'},
 {id:'b',name:'Jéssica Silva',studentType:'online',phone:'69 99999-2222',photoDataUrl:'foto-b',location:'Local padrão B'},
 {id:'c',name:'Aluno novo',studentType:'presencial',location:'Local C'}
],lessons:[
 {id:'aula-a',studentId:'a',date:'2026-10-08',time:'16:45',duration:90,type:'Treino individual',location:'Local desta aula',lead:30,repeat:'none',repeatDays:[],notes:'Nota original',customLesson:{keep:true}},
 {id:'serie-b',studentId:'b',date:'2026-10-06',time:'09:20',duration:50,type:'Treino online',location:'Local online',lead:0,repeat:'weekly',repeatDays:[2,4],notes:'Série original'},
 {id:'avulsa-b',studentId:'b',date:'2026-10-10',time:'18:10',duration:60,type:'Avaliação',location:'Local B',lead:20,repeat:'none',repeatDays:[],notes:'Avulsa'}
],payments:[{id:'payment',studentId:'a',studentName:'Jéssica Silva',amount:'500,00',paidAt:'2026-10-01T10:00:00Z',dueDate:'2026-10-01',nextDueDate:'2026-11-01'}],history:[],occurrenceStatus:{'avulsa-b|2026-10-10':'cancelada'},customData:{keep:true}};
const storage=new Map([['agendaPersonalTL_v1',JSON.stringify(initial)]]),elements=new Map(),events={};
let document,alarmPayload;
const checks=Array.from({length:7},(_,day)=>({value:String(day),checked:false}));
function element(id){
 if(!elements.has(id)){
  const classes=new Set(),attrs={};
  const options=id==='lessonDuration'?[30,45,60,90,120]:id==='lessonLead'?[0,10,15,30,60,90]:[];
  const node={id,value:'',hidden:false,style:{},dataset:{},innerHTML:'',textContent:'',options:options.map(value=>({value:String(value)})),isConnected:true,
   classList:{add(c){classes.add(c)},remove(c){classes.delete(c)},contains(c){return classes.has(c)},toggle(c,on){if(on)classes.add(c);else classes.delete(c)}},
   setAttribute(k,v){attrs[k]=String(v)},getAttribute(k){return attrs[k]},removeAttribute(k){delete attrs[k]},appendChild(option){node.options.push(option)},
   reset(){if(id==='lessonForm'){for(const key of ['lessonEditId','lessonStudent','lessonDate','lessonTime','lessonLocation','lessonNotes'])element(key).value='';element('lessonDuration').value='60';element('lessonLead').value='15';element('lessonRepeat').value='none';checks.forEach(input=>input.checked=false)}},
   querySelectorAll(selector){return id==='repeatDays'?(selector==='input:checked'?checks.filter(input=>input.checked):checks):[]},
   focus(){document.activeElement=node},click(){},setCustomValidity(){},reportValidity(){}};
  elements.set(id,node);
 }
 return elements.get(id);
}
document={getElementById:element,createElement(){return {value:'',textContent:''}},querySelectorAll(){return []},addEventListener(k,fn){events[k]=fn},hidden:false,activeElement:null};
const native={syncLessonAlarms(json){alarmPayload=JSON.parse(json);return true}};
const context={URL,Date,console,setInterval(){},setTimeout(){return 1},clearTimeout(){},confirm(){return true},
 localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},document,Android:native,window:{Android:native,open(){}}};
vm.createContext(context);vm.runInContext(source,context);context.loadProfileEvaluationResults=()=>{};
const value=expression=>vm.runInContext(expression,context),copy=expression=>JSON.parse(value(`JSON.stringify(${expression})`));
const before=copy('state'),originalStored=storage.get('agendaPersonalTL_v1');

// The pupil's shortcut loads its existing lesson, even when another pupil has the same full name.
context.showScreen('students-presencial');context.prefillLesson('a');
assert.equal(element('lessonDialogTitle').textContent,'Editar aula');assert.equal(element('lessonEditId').value,'aula-a');
for(const [field,expected] of Object.entries({lessonStudent:'a',lessonDate:'2026-10-08',lessonTime:'16:45',lessonDuration:'90',lessonLead:'30',lessonType:'Treino individual',lessonLocation:'Local desta aula',lessonNotes:'Nota original',lessonRepeat:'none'}))assert.equal(element(field).value,expected,field);
assert.match(element('lessonSavedReference').textContent,/16:45.*30 min antes/);assert.equal(element('lessonSavedReference').hidden,false);
element('lessonTime').value='07:00';context.closeDialog('lessonDialog');context.prefillLesson('a');assert.equal(element('lessonTime').value,'16:45');
assert.equal(storage.get('agendaPersonalTL_v1'),originalStored);

// Saving a note keeps the lesson ID, its saved time/lead, extra metadata, and all other records.
element('lessonNotes').value='Nota atualizada';element('lessonForm').onsubmit({preventDefault(){}});
let saved=JSON.parse(storage.get('agendaPersonalTL_v1'));
assert.equal(saved.lessons.length,3);assert.deepEqual(saved.lessons[0],{...before.lessons[0],notes:'Nota atualizada'});
assert.deepEqual(saved.lessons.slice(1),before.lessons.slice(1));assert.deepEqual(saved.students,before.students);
assert.deepEqual(saved.payments,before.payments);assert.deepEqual(saved.occurrenceStatus,before.occurrenceStatus);assert.deepEqual(saved.customData,before.customData);
assert.equal(alarmPayload.lessons.find(l=>l.id==='aula-a').time,'16:45');assert.equal(alarmPayload.lessons.find(l=>l.id==='aula-a').lead,30);
assert.equal(value('currentScreen'),'students');assert.equal(value('studentViewType'),'presencial');

// Multiple lessons require an explicit choice; canceled entries and advance reminders remain visible.
context.showScreen('students-online');context.openStudentProfile('b');context.openCurrentProfileLesson();
assert.ok(element('studentLessonsDialog').classList.contains('open'));assert.ok(!element('lessonDialog').classList.contains('open'));
assert.ok(element('studentLessonsList').innerHTML.includes('09:20'));assert.ok(element('studentLessonsList').innerHTML.includes('18:10'));
assert.ok(!element('studentLessonsList').innerHTML.includes('16:45'));assert.match(element('studentLessonsList').innerHTML,/Cancelada/);
assert.match(element('studentLessonsList').innerHTML,/Aviso no horário/);assert.match(element('studentLessonsList').innerHTML,/20 min antes/);
context.editStudentLesson('aula-a');assert.ok(!element('lessonDialog').classList.contains('open'));
context.editStudentLesson('serie-b');assert.equal(element('lessonEditId').value,'serie-b');assert.equal(element('lessonTime').value,'09:20');
assert.equal(element('lessonDuration').value,'50');assert.equal(element('lessonLead').value,'0');
assert.ok(element('lessonDuration').options.some(option=>option.value==='50'));assert.deepEqual(checks.filter(input=>input.checked).map(input=>Number(input.value)),[2,4]);
assert.equal(element('studentLessonsDialog').inert,true);assert.match(element('lessonSavedReference').textContent,/no horário.*série semanal/);
element('lessonTime').value='10:10';setInput('lessonLead','20');element('lessonForm').onsubmit({preventDefault(){}});
saved=JSON.parse(storage.get('agendaPersonalTL_v1'));assert.equal(saved.lessons.length,3);
const series=saved.lessons.find(l=>l.id==='serie-b');assert.equal(series.time,'10:10');assert.equal(series.lead,20);assert.deepEqual(series.repeatDays,[2,4]);assert.equal(series.duration,50);
assert.deepEqual(saved.lessons.find(l=>l.id==='avulsa-b'),before.lessons[2]);assert.deepEqual(saved.occurrenceStatus,before.occurrenceStatus);
assert.equal(alarmPayload.lessons.find(l=>l.id==='serie-b').time,'10:10');assert.equal(alarmPayload.lessons.find(l=>l.id==='serie-b').lead,20);
assert.ok(element('studentLessonsDialog').classList.contains('open'));assert.equal(element('studentLessonsDialog').inert,false);assert.ok(element('studentLessonsList').innerHTML.includes('10:10'));
context.editStudentLesson('serie-b');assert.equal(element('lessonTime').value,'10:10');assert.equal(element('lessonLead').value,'20');
context.closeDialog('lessonDialog');context.editStudentLesson('avulsa-b');assert.equal(element('lessonLead').value,'20');assert.ok(element('lessonLead').options.some(option=>option.value==='20'));
context.closeDialog('lessonDialog');context.newStudentLesson();assert.equal(element('lessonDialogTitle').textContent,'Nova aula');assert.equal(element('lessonEditId').value,'');assert.equal(element('lessonStudent').value,'b');
context.closeDialog('lessonDialog');context.closeDialog('studentLessonsDialog');assert.ok(element('studentProfileDialog').classList.contains('open'));assert.equal(element('studentProfileDialog').inert,false);
assert.equal(value('currentScreen'),'students');assert.equal(value('studentViewType'),'online');context.closeDialog('studentProfileDialog');

// A pupil with no lesson still has the normal new-lesson flow; creation stays available after a direct edit.
context.prefillLesson('c');assert.equal(element('lessonDialogTitle').textContent,'Nova aula');assert.equal(element('lessonStudent').value,'c');assert.equal(element('lessonEditId').value,'');assert.equal(element('lessonSavedReference').hidden,true);
context.closeDialog('lessonDialog');context.prefillLesson('a');context.newLessonFromEditor();assert.equal(element('lessonDialogTitle').textContent,'Nova aula');assert.equal(element('lessonEditId').value,'');assert.equal(element('lessonStudent').value,'a');assert.equal(element('lessonNewZone').hidden,true);
context.closeDialog('lessonDialog');assert.equal(value('dialogStack.length'),0);assert.equal(value('studentLessonsStudentId'),'');
assert.deepEqual(JSON.parse(storage.get('agendaPersonalTL_v1')),saved);
function setInput(field,text){context.setLessonSelectValue(field,text,`${text} min`)}
console.log('Edição verificada: horário e aviso salvos, aluno por ID, seleção entre aulas, zero/customização do aviso, série semanal, mesma aula ao salvar, referência atualizada, nova aula explícita, retorno e dados preservados.');
