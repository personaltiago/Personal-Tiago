const fs=require('fs'), vm=require('vm'),assert=require('assert');
const path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const start=html.indexOf('  function partners(){',html.indexOf('  function pairContext('));
const end=html.indexOf('  function configurePair(',start);
const actual=html.slice(start,end);
const categories=[...html.match(/const WORKOUT_MUSCLES=(\[[^;]+\]);/)[1].matchAll(/'([^']+)'/g)].map(m=>m[1]);
assert.strictEqual(categories.length,22);
const ids=['workoutBisetPartnerReference','workoutBisetPartnerDay','workoutBisetPartnerCatalog','workoutBisetPartnerSearchField','workoutBisetPartnerGroupHeader','workoutBisetPartnerCount','workoutBisetPartnerCurrentMuscle','workoutBisetPartnerMore','workoutBisetPartnerContent','workoutBisetPartnerHint','workoutBisetPartnerSearch'];
const els={}; for (const id of ids) els[id]={id,hidden:false,textContent:'',innerHTML:'',value:'',classList:{primary:false,toggle(k,v){this[k]=v}},setAttribute(k,v){this[k]=v}};
const doc={getElementById(id){if(!els[id]) throw Error('missing '+id);return els[id]}};
const data={p:{id:'p1'},day:{id:'d1',exercises:[{id:'a',name:'Flexora Unilateral',muscle:'Posterior de coxa'},{id:'b',name:'Agachamento',muscle:'Quadríceps'},{id:'c',name:'Mesa flexora',muscle:'Posterior de coxa'}]}};
const catalog=[{id:'x1',name:'Cadeira flexora',muscle:'Posterior de coxa',category:'Musculação',aliases:['Flexora sentada']}, {id:'x2',name:'Supino reto',muscle:'Peito',category:'Musculação'}, {id:'x3',name:'Glúteos na polia',muscle:'Glúteos',category:'Musculação'}, {id:'x4',name:'Agachamento frontal',muscle:'Quadríceps',category:'Musculação'}, {id:'x5',name:'Desenvolvimento',muscle:'Ombros',category:'Musculação'}, {id:'x6',name:'Curl femoral',muscle:'Quadríceps',muscles:['Posterior de coxa'],category:'Musculação'}, {id:'xx',name:'Exercício proibido',muscle:'Peito',blocked:true}];
const env={document:doc, window:{}, pairSource:'day',pairMuscle:null,pairLimit:48,pairTarget:{planId:'p1',dayId:'d1',anchorId:'a'},target:{mode:'card',exerciseId:'a'},WORKOUT_MUSCLES:categories,WORKOUT_LOWER_MUSCLES:['Inferiores','Quadríceps','Posterior de coxa','Glúteos','Adutores','Flexores do quadril','Panturrilhas','Quadril','Tornozelo'],
 pairContext(){return {...data,anchor:data.day.exercises[0],group:null}},context(){return data},assemblyAllowed(){return true},openDialog(id){this.opened=id},
 workoutCatalogItems(){return catalog},workoutCatalogBlocked(ex){return !!ex.blocked},searchText(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR')},
 workoutCatalogMatchesMuscle(ex,muscle){let list=[ex.muscle,...(ex.muscles||[])];return !muscle||list.includes(muscle)||muscle==='Inferiores'&&list.some(v=>env.WORKOUT_LOWER_MUSCLES.includes(v))},groupFor(){return null},hesc(s){return String(s).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;')},console};
vm.createContext(env);
vm.runInContext(actual,env);
let runs=0;function check(name,fn){fn();runs++;console.log('OK',name)}
check('Neste treino continua mostrando parceiros da ficha',()=>{env.renderPartners();assert(els.workoutBisetPartnerContent.innerHTML.includes('Mesa flexora'));assert(!els.workoutBisetPartnerContent.innerHTML.includes('Supino reto'))});
check('Catálogo abre seleção de grupos, não exercícios',()=>{env.window.setWorkoutBisetPartnerSource('catalog');assert(els.workoutBisetPartnerContent.innerHTML.includes('Escolha o grupo muscular'));assert(els.workoutBisetPartnerContent.innerHTML.includes('Posterior de coxa'));assert(!els.workoutBisetPartnerContent.innerHTML.includes('Supino reto'));assert(els.workoutBisetPartnerSearchField.hidden)});
check('Todos os grupos originais aparecem',()=>{for(const item of categories)assert(els.workoutBisetPartnerContent.innerHTML.includes(item),item)});
check('Selecionar Posterior filtra exercícios e músculos secundários',()=>{env.window.pickWorkoutBisetPartnerMuscle('Posterior de coxa');let txt=els.workoutBisetPartnerContent.innerHTML;assert(txt.includes('Cadeira flexora'));assert(txt.includes('Curl femoral'));assert(!txt.includes('Supino reto'));assert(!els.workoutBisetPartnerSearchField.hidden);assert(els.workoutBisetPartnerCurrentMuscle.textContent==='Posterior de coxa')});
check('Busca textual funciona dentro do grupo',()=>{els.workoutBisetPartnerSearch.value='curl';env.window.searchWorkoutBisetPartner();assert(els.workoutBisetPartnerContent.innerHTML.includes('Curl femoral'));assert(!els.workoutBisetPartnerContent.innerHTML.includes('Cadeira flexora'))});
check('Placeholder pede somente o nome do exercício',()=>{assert(html.includes('placeholder="Pesquisar pelo nome do exercício"'));assert(!html.includes('placeholder="Nome ou grupo muscular"'))});
check('Grupo muscular não é tratado como termo de busca',()=>{
 els.workoutBisetPartnerSearch.value='posterior de coxa';
 env.window.searchWorkoutBisetPartner();
 assert(!els.workoutBisetPartnerContent.innerHTML.includes('Cadeira flexora'));
 assert(els.workoutBisetPartnerContent.innerHTML.includes('Nenhum exercício encontrado'));
});
check('Pesquisa por nome encontra exercício dentro do grupo selecionado',()=>{
 els.workoutBisetPartnerSearch.value='cadeira';env.window.searchWorkoutBisetPartner();
 assert(els.workoutBisetPartnerContent.innerHTML.includes('Cadeira flexora'));
 assert(!els.workoutBisetPartnerContent.innerHTML.includes('Supino reto'));
});
check('Modalidade não é usada como palavra-chave da busca',()=>{
 els.workoutBisetPartnerSearch.value='musculacao';env.window.searchWorkoutBisetPartner();
 assert(els.workoutBisetPartnerContent.innerHTML.includes('Nenhum exercício encontrado'));
});
check('Sinônimos do exercício continuam pesquisáveis',()=>{els.workoutBisetPartnerSearch.value='sentada';env.window.searchWorkoutBisetPartner();assert(els.workoutBisetPartnerContent.innerHTML.includes('Cadeira flexora'))});
check('Voltar à seleção de grupos limpa pesquisa',()=>{env.window.showWorkoutBisetPartnerMuscles();assert(els.workoutBisetPartnerSearch.value==='');assert(els.workoutBisetPartnerContent.innerHTML.includes('Escolha o grupo muscular'))});
check('Inferiores inclui subgrupos',()=>{env.window.pickWorkoutBisetPartnerMuscle('Inferiores');let txt=els.workoutBisetPartnerContent.innerHTML;assert(txt.includes('Cadeira flexora')&&txt.includes('Glúteos na polia')&&txt.includes('Agachamento frontal'));assert(!txt.includes('Supino reto'))});
check('Todos os exercícios mostra diferentes regiões',()=>{env.window.showWorkoutBisetPartnerMuscles();env.window.pickWorkoutBisetPartnerMuscle('');let txt=els.workoutBisetPartnerContent.innerHTML;assert(txt.includes('Supino reto')&&txt.includes('Cadeira flexora'));assert(!txt.includes('Exercício proibido'))});
check('Região inválida não altera seleção',()=>{env.window.pickWorkoutBisetPartnerMuscle('invasão');assert(els.workoutBisetPartnerCurrentMuscle.textContent==='Todos os exercícios')});
check('Voltar a Neste treino mantém comportamento original',()=>{env.window.setWorkoutBisetPartnerSource('day');assert(els.workoutBisetPartnerContent.innerHTML.includes('Mesa flexora'));assert(!els.workoutBisetPartnerContent.innerHTML.includes('Cadeira flexora'));assert(!els.workoutBisetPartnerSearchField.hidden)});
check('Retornar ao Catálogo volta aos grupos musculares',()=>{env.window.setWorkoutBisetPartnerSource('catalog');assert(els.workoutBisetPartnerContent.innerHTML.includes('Escolha o grupo muscular'));assert(!els.workoutBisetPartnerContent.innerHTML.includes('Supino reto'))});
check('Mostrar mais oculto na seleção de grupos',()=>{assert(els.workoutBisetPartnerMore.hidden);env.window.moreWorkoutBisetPartners();assert(els.workoutBisetPartnerContent.innerHTML.includes('Escolha o grupo muscular'))});
check('Escolher grupo e trocar mantendo estado sem mutar prescrição',()=>{env.window.pickWorkoutBisetPartnerMuscle('Peito');assert(els.workoutBisetPartnerContent.innerHTML.includes('Supino reto'));assert.strictEqual(data.day.exercises.length,3);assert.strictEqual(catalog.length,7)});
console.log('PASSOU:',runs,'cenários de fluxo do catálogo e bi-set');
