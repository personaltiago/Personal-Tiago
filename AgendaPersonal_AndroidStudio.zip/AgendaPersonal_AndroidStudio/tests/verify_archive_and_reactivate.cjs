'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
function extract(name){
  const start=html.indexOf('function '+name+'(');assert(start!==-1,'missing '+name);
  let brace=html.indexOf('{',start),depth=0,quote='',escaped=false,line=false,block=false;
  for(let i=brace;i<html.length;i++){
    const c=html[i],n=html[i+1];
    if(line){if(c==='\n')line=false;continue}if(block){if(c==='*'&&n==='/'){block=false;i++}continue}
    if(quote){if(escaped){escaped=false;continue}if(c==='\\'){escaped=true;continue}if(c===quote)quote='';continue}
    if(c==='/'&&n==='/'){line=true;i++;continue}if(c==='/'&&n==='*'){block=true;i++;continue}
    if(c==='\''||c==='"'||c==='`'){quote=c;continue}
    if(c==='{')depth++;else if(c==='}'){depth--;if(depth===0)return html.slice(start,i+1)}
  }
  throw Error('function parse error: '+name);
}
const d1={id:'a',name:'Dia A',exercises:[{id:'ex1',name:'Flexora',load:'35 kg',sets:'3'}]};
const d2={id:'b',name:'Dia B',exercises:[{id:'ex2',name:'Agachamento',load:'60 kg',sets:'4'}]};
const plans=[
 {id:'full',name:'Ficha hipertrofia',studentId:'s1',days:[d1,d2],archived:false,autoArchive:false,visibility:'always',createdAt:'2026-08-01',organization:'sequence'},
 {id:'empty',name:'Horário',studentId:'s1',days:[],archived:false,autoArchive:false,visibility:'always',createdAt:'2026-10-08',organization:'week'},
 {id:'old',name:'Ficha de julho',studentId:'s1',days:[{id:'x',name:'Treino antigo',exercises:[{id:'oldex',name:'Rosca'}]}],archived:true,createdAt:'2026-07-01',visibility:'always',organization:'sequence'}
];
const record={id:'record',studentId:'s1',planId:'full',dayId:'a',load:'40 kg'};
const initialState={students:[{id:'s1',name:'Jéssica',phone:'',studentType:'online'}],workoutPlans:structuredClone(plans),workoutExecutions:[record],workoutDrafts:{'full|a':{values:{ex1:{load:'40 kg'}}}},history:[],workoutRest:null};
const state=structuredClone(initialState),store=new Map(),toasts=[],elements={workoutStudentContent:{innerHTML:''},workoutStudentOptions:{open:false},workoutStudentDialog:{querySelector:()=>null}};
let canPersist=true,confirms=true,checks=0;
function check(name,fn){fn();checks++;console.log('OK',name)}
const sandbox={
 state,workoutStudentId:'s1',workoutPlanId:'',workoutDayId:'',workoutDaysOrdering:false,workoutPlanCollection:'active',workoutPlanArchivedDetailId:'',
 document:{getElementById:(id)=>elements[id]||null},window:{},
 localStorage:{setItem:(k,v)=>{if(!canPersist)throw Error('quota exceeded');store.set(k,v)},getItem:k=>store.get(k)||null},DB_KEY:'agenda-test',
 toast:text=>toasts.push(text),confirm:()=>confirms,
 studentById:id=>state.students.find(s=>s.id===id),
 uiIcon:()=>'',workoutSheetIcon:()=>'',hesc:v=>String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;'),
 studentAvatarHtml:()=>'',studentTypeLabel:()=>'',workoutStudentProgressHtml:()=>'',
 workoutPlanMetrics:()=>'',workoutGuidance:()=>'',workoutDateLabel:v=>v||'',workoutLastExecutionLabel:()=>'',workoutDayLabel:(_,d)=>d.name,
 workoutRecords:(pid,did)=>state.workoutExecutions.filter(r=>r.planId===pid&&(!did||r.dayId===did)),
 updateWorkoutSheetPosition:()=>{},renderWorkouts:()=>{},renderWorkoutHistory:()=>{},renderHistory:()=>{},renderWorkoutDay:()=>{},
 workoutRestValid:()=>true,cancelNativeWorkoutRest:()=>{},updateWorkoutSessionLabels:()=>{},
 validWorkoutDate:v=>/^\d{4}-\d\d-\d\d$/.test(v),iso:()=>new Date('2026-10-09T12:00:00Z').toISOString().slice(0,10),id:()=>`hist-${Date.now()}`,
};
vm.createContext(sandbox);
for(const name of ['workoutPlanArchived','workoutPlanById','currentWorkoutPlan','commitWorkoutChange','replaceWorkoutPlan','renderWorkoutStudent','selectWorkoutPlan','toggleWorkoutPlanArchive','showWorkoutPlanCollection','openArchivedWorkoutPlan','reactivateArchivedWorkoutPlan'])vm.runInContext(extract(name),sandbox);
const ui=()=>elements.workoutStudentContent.innerHTML;
check('Inicia na aba Ativas e seleciona ficha ativa com treinos',()=>{
 sandbox.renderWorkoutStudent();assert.equal(sandbox.workoutPlanId,'full');assert.match(ui(),/Ativas <span>2<\/span>/);assert.match(ui(),/Arquivadas <span>1<\/span>/);assert.match(ui(),/Dia A/);
});
check('Ficha arquivada fica separada do seletor de ativas',()=>{
 assert.match(ui(),/Trocar ficha ativa/);assert.ok(!ui().includes('Ficha de julho · 1 treino · Arquivada'));
});
check('A aba Arquivadas mostra fichas anteriores, com treinos e botões',()=>{
 sandbox.showWorkoutPlanCollection('archived');assert.match(ui(),/Fichas arquivadas/);assert.match(ui(),/Ficha de julho/);assert.match(ui(),/1 treino · 1 exercício/);assert.match(ui(),/Consultar ficha/);assert.match(ui(),/Reativar/);assert.ok(!ui().includes('Ficha hipertrofia'));
});
check('Consulta da ficha arquivada mostra exercícios sem permitir edição',()=>{
 sandbox.openArchivedWorkoutPlan('old');assert.match(ui(),/Treino antigo/);assert.match(ui(),/Voltar às arquivadas/);assert.match(ui(),/disabled/);assert.equal(sandbox.workoutPlanId,'old');
});
check('Voltar retorna à listagem Arquivadas',()=>{
 sandbox.showWorkoutPlanCollection('archived');assert.equal(sandbox.workoutPlanArchivedDetailId,'');assert.match(ui(),/Ficha de julho/);
});
check('Arquivar ficha ativa mantém dados e a move para Arquivadas',()=>{
 sandbox.showWorkoutPlanCollection('active');sandbox.selectWorkoutPlan('full');
 const exercises=JSON.stringify(state.workoutPlans.find(p=>p.id==='full').days),history=JSON.stringify(state.workoutExecutions),draft=JSON.stringify(state.workoutDrafts);
 sandbox.toggleWorkoutPlanArchive();assert.equal(state.workoutPlans.find(p=>p.id==='full').archived,true);assert.equal(sandbox.workoutPlanCollection,'archived');
 assert.match(ui(),/Ficha hipertrofia/);assert.equal(JSON.stringify(state.workoutPlans.find(p=>p.id==='full').days),exercises);
 assert.equal(JSON.stringify(state.workoutExecutions),history);assert.equal(JSON.stringify(state.workoutDrafts),draft);
 assert.equal(JSON.stringify(JSON.parse(store.get('agenda-test')).workoutPlans.find(p=>p.id==='full').days),exercises);
});
check('Arquivada recém-movida mantém todos os exercícios na consulta',()=>{
 sandbox.openArchivedWorkoutPlan('full');assert.match(ui(),/Dia A/);assert.match(ui(),/Dia B/);assert.match(ui(),/Reativar ficha/);
});
check('Reativar devolve ficha à aba Ativas sem duplicar',()=>{
 const length=state.workoutPlans.length;
 sandbox.reactivateArchivedWorkoutPlan('full');assert.equal(sandbox.workoutPlanCollection,'active');assert.equal(state.workoutPlans.length,length);
 assert.equal(state.workoutPlans.find(p=>p.id==='full').archived,false);assert.match(ui(),/Dia A/);
});
check('Outra ficha arquivada permanece arquivada após reativação',()=>{
 assert.equal(state.workoutPlans.find(p=>p.id==='old').archived,true);
 sandbox.showWorkoutPlanCollection('archived');assert.match(ui(),/Ficha de julho/);assert.ok(!ui().includes('Ficha hipertrofia'));
});
check('Abre Ativas mostrando ficha com exercícios após trocar a aba',()=>{
 sandbox.showWorkoutPlanCollection('active');assert.match(ui(),/Ficha hipertrofia/);assert.match(ui(),/Dia A/);
});
check('Tentativa de zerar os treinos existentes é bloqueada',()=>{
 let p=state.workoutPlans.find(p=>p.id==='full');assert.equal(sandbox.replaceWorkoutPlan({...p,days:[]},'invalid'),false);assert.equal(p.days.length,2);
});
check('Falha de persistência não altera status nem disposição da aba',()=>{
 sandbox.selectWorkoutPlan('full');const before=state.workoutPlans.find(p=>p.id==='full');canPersist=false;sandbox.toggleWorkoutPlanArchive();canPersist=true;
 assert.equal(state.workoutPlans.find(p=>p.id==='full'),before);assert.equal(sandbox.workoutPlanCollection,'active');
});
check('Cancelamento preserva status da ficha',()=>{
 const before=JSON.stringify(state.workoutPlans);confirms=false;sandbox.toggleWorkoutPlanArchive();confirms=true;assert.equal(JSON.stringify(state.workoutPlans),before);
});
check('Reativação de arquivada automática impede reaquivamento imediato',()=>{
 const plan=state.workoutPlans.find(p=>p.id==='old');plan.archived=false;plan.autoArchive=true;plan.endDate='2026-01-01';
 sandbox.showWorkoutPlanCollection('archived');sandbox.reactivateArchivedWorkoutPlan('old');
 assert.equal(state.workoutPlans.find(p=>p.id==='old').autoArchive,false);assert.equal(sandbox.workoutPlanArchived(state.workoutPlans.find(p=>p.id==='old')),false);
});
check('Arquivadas vazias mostra estado vazio, mesmo que ativas existam',()=>{
 for(const p of state.workoutPlans){p.archived=false;p.autoArchive=false}
 sandbox.showWorkoutPlanCollection('archived');assert.match(ui(),/Nenhuma ficha arquivada/);
});
check('Sem fichas ativas a aba Ativas orienta reativação, sem inventar treinos',()=>{
 for(const p of state.workoutPlans)p.archived=true;
 sandbox.showWorkoutPlanCollection('active');assert.match(ui(),/Nenhuma ficha ativa/);assert.match(ui(),/Acesse Arquivadas/);assert.ok(!ui().includes('Dia A'));
});
check('Todo treino e histórico continuam associados a IDs originais',()=>{
 assert.deepEqual(state.workoutPlans.find(p=>p.id==='full').days,initialState.workoutPlans.find(p=>p.id==='full').days);
 assert.deepEqual(state.workoutExecutions,initialState.workoutExecutions);
 assert.deepEqual(state.workoutDrafts,initialState.workoutDrafts);
});
console.log('PASS',checks,'cenários de abas e fichas arquivadas');
