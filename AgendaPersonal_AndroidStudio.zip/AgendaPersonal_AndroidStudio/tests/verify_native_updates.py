"""Compile and exercise the real UpdateManager with small Android API fakes.

This verifies loading, version acknowledgement, navigation and rollback logic.
It does not replace installation/storage checks in an Android WebView.
"""
from pathlib import Path
import shutil
import subprocess
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
STUBS = {
    'android/content/Context.java': '''package android.content; public class Context {}''',
    'android/content/Intent.java': '''package android.content;
public class Intent { public static final String ACTION_OPEN_DOCUMENT="open", CATEGORY_OPENABLE="openable", EXTRA_MIME_TYPES="types";
public Intent(String s){} public Intent(Context c,Class<?> t){} public Intent addCategory(String s){return this;}
public Intent setType(String s){return this;} public Intent putExtra(String k,String[] v){return this;} }''',
    'android/content/SharedPreferences.java': '''package android.content;
public interface SharedPreferences { boolean getBoolean(String k,boolean d); Editor edit();
interface Editor { Editor putBoolean(String k,boolean v); boolean commit(); } }''',
    'android/net/Uri.java': '''package android.net;
public final class Uri { private final java.net.URI u; private Uri(String s){u=java.net.URI.create(s);}
public static Uri parse(String s){return new Uri(s);} public String getScheme(){return u.getScheme();}
public String getAuthority(){return u.getRawAuthority();} public String getPath(){return u.getPath();}
public String toString(){return u.toString();} public boolean equals(Object o){return o instanceof Uri&&u.equals(((Uri)o).u);}
public int hashCode(){return u.hashCode();} }''',
    'android/os/Looper.java': '''package android.os; public class Looper {public static Looper getMainLooper(){return new Looper();}}''',
    'android/os/Handler.java': '''package android.os;
public class Handler {public static final java.util.List<Runnable> tasks=new java.util.ArrayList<>(); public Handler(Looper l){}
public boolean postDelayed(Runnable r,long t){synchronized(tasks){tasks.add(r);}return true;}
public void removeCallbacksAndMessages(Object o){synchronized(tasks){tasks.clear();}}
public static void fire(){java.util.List<Runnable> copy; synchronized(tasks){copy=new java.util.ArrayList<>(tasks);tasks.clear();}for(Runnable r:copy)r.run();} }''',
    'android/util/Base64.java': '''package android.util; public class Base64 {public static final int NO_WRAP=2;
public static String encodeToString(byte[] a,int f){return java.util.Base64.getEncoder().encodeToString(a);} }''',
    'android/util/AtomicFile.java': '''package android.util; import java.io.*; import java.nio.file.*;
public class AtomicFile {private final File f; public AtomicFile(File f){this.f=f;}
public byte[] readFully()throws IOException{return Files.readAllBytes(f.toPath());}
public FileOutputStream startWrite()throws IOException{return new FileOutputStream(f);}
public void finishWrite(FileOutputStream s)throws IOException{s.close();} public void failWrite(FileOutputStream s)throws IOException{s.close();}
public void delete(){f.delete();} }''',
    'android/webkit/CookieManager.java': '''package android.webkit; public class CookieManager {
public static CookieManager getInstance(){return new CookieManager();} public String getCookie(String s){return null;} }''',
    'android/webkit/ValueCallback.java': '''package android.webkit; public interface ValueCallback<T>{void onReceiveValue(T value);}''',
    'android/webkit/WebView.java': '''package android.webkit;
public class WebView {public volatile String base,html,history,check; public volatile int loads; public volatile boolean ready;
public String snapshot="{\\\"agendaPersonalTL_v1\\\":\\\"foto-á-segurada\\\"}";
public synchronized void loadDataWithBaseURL(String b,String d,String m,String e,String h){base=b;html=d;history=h;loads++;notifyAll();}
public void evaluateJavascript(String s,ValueCallback<String> c){check=s;c.onReceiveValue(s.contains("localStorage.length")?org.json.JSONObject.quote(snapshot):(ready?"true":"false"));}
public synchronized void awaitLoads(int n)throws Exception{long until=System.currentTimeMillis()+5000;while(loads<n&&System.currentTimeMillis()<until)wait(50);if(loads<n)throw new AssertionError("Página não carregada");} }''',
    'android/widget/Button.java': '''package android.widget; public class Button {
public Button(android.content.Context c){} public void setText(String s){} public void setEnabled(boolean b){}
public interface Click{void click(Object v);} public void setOnClickListener(Click c){} }''',
    'android/widget/TextView.java': '''package android.widget; public class TextView {public void setText(String s){}}''',
    'android/widget/Toast.java': '''package android.widget;
public class Toast {public static final int LENGTH_LONG=1,LENGTH_SHORT=0; public static final java.util.List<String> shown=new java.util.concurrent.CopyOnWriteArrayList<>();
private final String message;private Toast(String s){message=s;} public static Toast makeText(android.content.Context c,String s,int n){return new Toast(s);}public void show(){shown.add(message);} }''',
    'android/app/AlertDialog.java': '''package android.app;
public class AlertDialog {public static final int BUTTON_POSITIVE=1,BUTTON_NEUTRAL=2,BUTTON_NEGATIVE=3;
public boolean isShowing(){return true;} public <T>T findViewById(int i){return null;}public android.widget.Button getButton(int i){return new android.widget.Button(null);}
public interface Show{void show(Object d);} public void setOnShowListener(Show s){} public void show(){}public void dismiss(){}
public static class Builder {public Builder(android.content.Context c,int style){}public Builder setTitle(String s){return this;}
public Builder setMessage(String s){return this;}public Builder setView(Object v){return this;}public Builder setPositiveButton(String s,Object o){return this;}
public Builder setNeutralButton(String s,Object o){return this;}public Builder setNegativeButton(String s,Object o){return this;}public AlertDialog create(){return new AlertDialog();}} }''',
    'android/R.java': '''package android; public class R {public static class style{public static final int Theme_Material_Dialog_Alert=1;}public static class id{public static final int message=1;}}''',
    'org/json/JSONObject.java': r'''package org.json; import java.util.*;
public class JSONObject {
private final Map<String,Object> fields=new LinkedHashMap<>(); private String original;
private static final Map<String,Map<String,Object>> saved=new java.util.concurrent.ConcurrentHashMap<>();
public JSONObject(){} public JSONObject(String s){if(saved.containsKey(s))fields.putAll(saved.get(s));else if(s.startsWith("{")&&s.endsWith("}"))original=s;else throw new IllegalArgumentException("JSON inválido");}
public JSONObject put(String k,Object v){fields.put(k,v);return this;}public int optInt(String k){return optInt(k,0);}
public int optInt(String k,int d){Object o=fields.get(k);return o instanceof Number?((Number)o).intValue():d;}
public String optString(String k){return optString(k,"");}public String optString(String k,String d){Object o=fields.get(k);return o==null?d:String.valueOf(o);}
public boolean optBoolean(String k){return Boolean.TRUE.equals(fields.get(k));}public JSONObject getJSONObject(String k){Object o=fields.get(k);if(!(o instanceof JSONObject))throw new IllegalArgumentException(k);return (JSONObject)o;}
public String getString(String k){if(!fields.containsKey(k))throw new IllegalArgumentException(k);return String.valueOf(fields.get(k));}
public int getInt(String k){if(!fields.containsKey(k))throw new IllegalArgumentException(k);return ((Number)fields.get(k)).intValue();}
public int length(){return fields.size();}public boolean has(String k){return fields.containsKey(k);}
public String toString(){if(original!=null)return original;String s="{\"native-test\":\""+UUID.randomUUID()+"\"}";saved.put(s,new LinkedHashMap<>(fields));return s;}
public static String quote(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")+"\"";}
}''',
    'org/json/JSONTokener.java': r'''package org.json;
public class JSONTokener {private final String s;public JSONTokener(String s){this.s=s;}
public Object nextValue(){if(s==null||s.length()<2||s.charAt(0)!='"')return null;
StringBuilder out=new StringBuilder();for(int i=1;i<s.length()-1;i++){char c=s.charAt(i);if(c=='\\'){c=s.charAt(++i);if(c=='n')c='\n';else if(c=='r')c='\r';}out.append(c);}return out.toString();} }''',
    'com/tiagolima/agendapersonal/UpdatePanelActivity.java': '''package com.tiagolima.agendapersonal; public class UpdatePanelActivity {}''',
    'com/tiagolima/agendapersonal/MainActivity.java': '''package com.tiagolima.agendapersonal;
import java.io.*;import java.nio.file.*;import java.util.*;
public class MainActivity extends android.content.Context {
public final File folder;public final Path assets;public final Prefs prefs=new Prefs();public MainActivity(File f,Path a){folder=f;assets=a;}
public android.content.SharedPreferences getSharedPreferences(String n,int m){return prefs;}public File getFilesDir(){return folder;}
public String getPackageName(){return "com.tiagolima.agendapersonal";}public boolean isFinishing(){return false;}
public void runOnUiThread(Runnable r){r.run();}public void startActivity(android.content.Intent i){}public void startActivityForResult(android.content.Intent i,int n){}
public Assets getAssets(){return new Assets();}public class Assets{public InputStream open(String n)throws IOException{return Files.newInputStream(assets.resolve(n));}}
public Resolver getContentResolver(){return new Resolver();}public class Resolver{public InputStream openInputStream(android.net.Uri u)throws IOException{return Files.newInputStream(Path.of(java.net.URI.create(u.toString())));}}
public static class Prefs implements android.content.SharedPreferences {private final Map<String,Boolean> data=new java.util.concurrent.ConcurrentHashMap<>();
public boolean getBoolean(String k,boolean d){return data.getOrDefault(k,d);}public Editor edit(){return new E();}
private class E implements Editor{private final Map<String,Boolean> next=new HashMap<>();public Editor putBoolean(String k,boolean v){next.put(k,v);return this;}public boolean commit(){data.putAll(next);return true;}}}
}''',
    'com/tiagolima/agendapersonal/NativeUpdateHarness.java': r'''package com.tiagolima.agendapersonal;
import android.net.Uri;import android.webkit.WebView;import android.os.Handler;import android.widget.Toast;
import java.nio.file.*;import java.lang.reflect.*;import org.json.JSONObject;
public final class NativeUpdateHarness {
static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
static JSONObject bundle(int n,String label){String html="<!doctype html><html><head></head><body>"+label+" agendaPersonalTL_v1 syncNativeAlarms<script data-agenda-ready></script></body></html>";
return new JSONObject().put("format",1).put("appId","com.tiagolima.agendapersonal").put("bridgeVersion",2).put("dataSchema",4).put("sequence",n).put("version","1.11."+(n-1)).put("files",new JSONObject().put("index.html",html).put("avaliacoes.html",html));}
static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
static void apply(UpdateManager m,JSONObject b)throws Exception{Method v=UpdateManager.class.getDeclaredMethod("validateBundle",JSONObject.class);v.setAccessible(true);v.invoke(m,b);Method a=UpdateManager.class.getDeclaredMethod("snapshotAndApply",JSONObject.class);a.setAccessible(true);a.invoke(m,b);}
public static void main(String[] args)throws Exception{
Path root=Path.of(args[0]),folder=Files.createTempDirectory("agenda-native-fixture-");
MainActivity activity=new MainActivity(folder.toFile(),root.resolve("app/src/main/assets"));WebView view=new WebView();
Files.createDirectories(folder.resolve("updates"));Files.writeString(folder.resolve("updates/active.json"),bundle(2,"pacote anterior").toString());
UpdateManager manager=new UpdateManager(activity,view);
final int updateSequence=((Integer)field(manager,"BASE_SEQUENCE"))+1;
try {
String home="file:///android_asset/index.html",eval="file:///android_asset/avaliacoes.html?agendaStudentId=aluno-2&name=Ana%20Silva";
check(UpdateManager.isLocalPage(Uri.parse(home)),"Rota local recusada");check(!UpdateManager.isLocalPage(Uri.parse("file://outro/android_asset/index.html")),"Autoridade externa aceita");
check(!UpdateManager.isLocalPage(Uri.parse("https://example.com/index.html")),"URL externa aceita");check(!UpdateManager.isLocalPage(Uri.parse("file:///android_asset/segredos.txt")),"Arquivo não previsto aceito");
manager.openPage(Uri.parse(home));view.awaitLoads(1);check(home.equals(view.base)&&home.equals(view.history),"Endereço de armazenamento alterado");
check(view.html.contains("FAZER AVALIAÇÃO")&&view.html.contains("WHATSAPP_ICON"),"Base nova substituída por pacote antigo");
manager.openPage(Uri.parse(eval));view.awaitLoads(2);check(eval.equals(view.base)&&eval.equals(view.history),"Parâmetros de avaliação perdidos");check(view.html.contains("Tiago Lima · Avaliações"),"Página errada");
check(manager.goBack(),"Voltar não funcionou");view.awaitLoads(3);check(home.equals(view.base)&&view.html.contains("FAZER AVALIAÇÃO"),"Voltar abriu conteúdo antigo");check(!manager.goBack(),"Histórico não terminou");
Toast.shown.clear();int before=view.loads;apply(manager,bundle(updateSequence,"nova-versão-A"));view.awaitLoads(before+1);
check(view.html.contains("nova-versão-A"),"Conteúdo publicado não abriu");check(activity.prefs.getBoolean("pending",false),"Atualização confirmada antes de abrir");
check(Toast.shown.stream().noneMatch(s->s.startsWith("Atualização aplicada")),"Sucesso antecipado");
check(Files.readString(folder.resolve("updates/data-before-update.json")).equals(view.snapshot),"Snapshot alterado");
view.ready=false;manager.pageReady();check(activity.prefs.getBoolean("pending",false),"Página antiga confirmou atualização");
check(view.check.contains("__agendaNativeReleaseToken")&&view.check.contains("__agendaNativeReleaseSequence==="+updateSequence),"Versão não verificada");
Files.writeString(Path.of(args[1]),view.html.substring(view.html.indexOf("<script>window.__agendaNativeReleaseToken="),view.html.indexOf("</script>")+9)+"\n"+view.check);
manager.pageFinished();view.ready=true;manager.pageReady();check(!activity.prefs.getBoolean("pending",true),"Abertura confirmada não registrada");
check(Toast.shown.stream().filter(s->s.startsWith("Atualização aplicada")).count()==1,"Sucesso não ligado à confirmação");
int accepted=view.loads;Handler.fire();check(view.loads==accepted,"Timer antigo desfez versão confirmada");
before=view.loads;view.ready=false;apply(manager,bundle(updateSequence+1,"nova-versão-B"));view.awaitLoads(before+1);manager.pageFinished();Handler.fire();view.awaitLoads(before+2);
check(view.html.contains("nova-versão-A")&&!view.html.contains("nova-versão-B"),"Falha não voltou à versão anterior");
check(view.html.contains("__agendaNativeReleaseSequence="+updateSequence),"Identificação da recuperação incorreta");
check(view.html.contains("localStorage.clear()"),"Restauração não incorporada");
String marker="var b=atob('",encoded=view.html.substring(view.html.indexOf(marker)+marker.length());encoded=encoded.substring(0,encoded.indexOf("'"));
check(new String(java.util.Base64.getDecoder().decode(encoded),java.nio.charset.StandardCharsets.UTF_8).equals(view.snapshot),"Snapshot UTF-8 não restaurado integralmente");
check(activity.prefs.getBoolean("restoreData",false),"Restauração confirmada prematuramente");
view.ready=true;manager.pageReady();check(!activity.prefs.getBoolean("restoreData",true),"Restauração não confirmada");
int after=view.loads;apply(manager,bundle(2,"antigo"));Thread.yield();check(view.loads==after,"Downgrade aceito");
apply(manager,bundle(updateSequence+1,"interrompida"));view.awaitLoads(after+1);check(activity.prefs.getBoolean("pending",false),"Interrupção sem marcador");
manager.destroy();UpdateManager reopened=new UpdateManager(activity,view);
try{reopened.openPage(Uri.parse(home));view.awaitLoads(after+2);check(view.html.contains("nova-versão-A"),"Reabertura não recuperou a última versão confirmada");check(home.equals(view.base),"Origem alterada após recuperação");}finally{reopened.destroy();}
System.out.println("Atualizações nativas: carregamento direto, URLs e parâmetros, base instalada, voltar, snapshot, rejeição de confirmação antiga, sucesso após abertura, rollback, downgrade e recuperação após interrupção verificados.");
}finally{manager.destroy();}
} }
''',
}


def main():
    java = shutil.which('java')
    javac = shutil.which('javac')
    if not java:
        raise SystemExit('Java 17 é necessário para estes testes.')
    compiler = [javac] if javac else [java, 'com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='agenda-native-tests-') as temporary:
        work = Path(temporary)
        sources = []
        for name, content in STUBS.items():
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding='utf-8')
            sources.append(str(target))
        sources.append(str(PROJECT / 'app/src/main/java/com/tiagolima/agendapersonal/UpdateManager.java'))
        subprocess.run(compiler + ['-encoding', 'UTF-8', '-d', str(work / 'classes')] + sources, check=True)
        probe = work / 'readiness.txt'
        subprocess.run([java, '-cp', str(work / 'classes'), 'com.tiagolima.agendapersonal.NativeUpdateHarness', str(PROJECT), str(probe)], check=True)
        subprocess.run(['node', '-e', r'''const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const text=fs.readFileSync(process.argv[1],'utf8'),html=text.slice(0,text.indexOf('</script>')+9),check=text.slice(text.indexOf('</script>')+9).trim();
const window={};vm.runInNewContext(html.slice(8,-9),{window});assert.equal(vm.runInNewContext(check,{window}),true);
window.__agendaNativeReleaseToken='outra-página';assert.equal(vm.runInNewContext(check,{window}),false);
vm.runInNewContext(html.slice(8,-9),{window});window.__agendaNativeReleaseSequence=2;assert.equal(vm.runInNewContext(check,{window}),false);
vm.runInNewContext(html.slice(8,-9),{window});window.__agendaBootFailed=true;assert.equal(vm.runInNewContext(check,{window}),false);
window.__agendaBootFailed=false;window.__agendaRestoreFailed=true;assert.equal(vm.runInNewContext(check,{window}),false);
console.log('Expressão real de confirmação: token, sequência, erro de abertura e erro de restauração verificados.');''', str(probe)], check=True)


if __name__ == '__main__':
    main()
