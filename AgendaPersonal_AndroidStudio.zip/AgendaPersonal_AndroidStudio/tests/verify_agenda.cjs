const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/index.html'), 'utf8');
const source = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const maps = 'https://maps.app.goo.gl/F5XfXkBAnBs91hhHA';
const initial = {
  students: [{id:'pessoa', name:'Aluno teste', phone:'', location:maps}],
  lessons: ['aula-a', 'aula-b'].map(id => ({
    id, studentId:'pessoa', date:'2026-10-01', time:'12:00', duration:60,
    type:'Treino individual', location:maps, lead:15, repeat:'weekly', repeatDays:[4], notes:''
  })),
  occurrenceStatus:{}, history:[]
};
const storage = new Map([['agendaPersonalTL_v1', JSON.stringify(initial)]]);
const calls = [];
function createRuntime(nativeResult = true) {
  const elements = new Map();
  const element = id => {
    if (!elements.has(id)) elements.set(id, {
      value:'', style:{}, dataset:{}, innerHTML:'', textContent:'',
      classList:{add(){},remove(){},toggle(){}}, reset(){}, querySelectorAll(){return [];}
    });
    return elements.get(id);
  };
  const native = {syncLessonAlarms(json){calls.push(JSON.parse(json));return nativeResult;}};
  const context = {
    URL, Date, console, setInterval(){}, setTimeout(){return 1;}, clearTimeout(){},
    localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,value)=>storage.set(key,value)},
    document:{getElementById:element,querySelectorAll(){return [];},addEventListener(){},hidden:false},
    Android:native, window:{Android:native,open(url){context.opened = url;},addEventListener(){}}
  };
  vm.createContext(context);
  vm.runInContext(source, context);
  return {context, element};
}
const first = createRuntime();
first.context.cancelAndMakeup('aula-a', '2026-10-01');
assert.equal(calls.at(-1).occurrenceStatus['aula-a|2026-10-01'], 'cancelada');
assert.equal(calls.at(-1).occurrenceStatus['aula-b|2026-10-01'], undefined);
assert.equal(calls.at(-1).lessons.length, 2);
assert.deepEqual(calls.at(-1).lessons[0].repeatDays, [4]);
assert.equal(first.element('rescheduleOriginalDate').value, '2026-10-01');
first.element('rescheduleDate').value = '2026-10-02';
first.element('rescheduleTime').value = '12:00';
first.element('rescheduleLocation').value = maps;
first.element('rescheduleForm').onsubmit({preventDefault(){}});
const replacement = calls.at(-1).lessons.find(l => l.id !== 'aula-a' && l.id !== 'aula-b');
assert.ok(replacement);
assert.equal(replacement.repeat, 'none');
assert.equal(replacement.location, maps);
assert.equal(calls.at(-1).occurrenceStatus['aula-a|2026-10-01'], 'cancelada');
assert.equal(calls.at(-1).occurrenceStatus[replacement.id+'|2026-10-02'], 'reposicao');
const reopened = createRuntime();
assert.equal(calls.at(-1).occurrenceStatus['aula-a|2026-10-01'], 'cancelada');
reopened.context.cancelAndMakeup('aula-a', '2026-10-08');
assert.equal(calls.at(-1).occurrenceStatus['aula-a|2026-10-08'], 'cancelada');
reopened.context.setStatusBy('aula-b', '2026-10-01', 'realizada');
assert.equal(calls.at(-1).occurrenceStatus['aula-b|2026-10-01'], 'realizada');
reopened.context.openMapFor('aula-a');
assert.equal(reopened.context.opened, maps);
const failed = createRuntime(false);
failed.context.cancelAndMakeup('aula-b', '2026-10-08');
assert.match(failed.element('toast').textContent, /Falha ao atualizar/);
assert.equal(JSON.parse(storage.get('agendaPersonalTL_v1')).occurrenceStatus['aula-b|2026-10-08'], 'cancelada');
console.log('Agenda verificada: IDs independentes, cancelamento, reposição, persistência, Maps e erro da ponte Android.');
