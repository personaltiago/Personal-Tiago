const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const { createRequire } = require('node:module');
const runtime = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/') : require;
const { chromium } = runtime('playwright');
const project = path.resolve(__dirname, '..'), assets = path.join(project, 'app/src/main/assets');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'agenda-youtube-'));
const nativePage = path.join(temp, 'player.html');
execFileSync('java', ['com.sun.tools.javac.Main', '-encoding', 'UTF-8', '-d', temp,
  path.join(project, 'app/src/main/java/com/tiagolima/agendapersonal/YouTubePlayerPage.java'), path.join(__dirname, 'YouTubePageHarness.java')]);
execFileSync('java', ['-cp', temp, 'com.tiagolima.agendapersonal.YouTubePageHarness', nativePage], { stdio: 'inherit' });
const fixture = {
  students: [{ id: 'a', name: 'Aluno do vídeo', studentType: 'presencial', phone: '69999990000' }],
  lessons: [], occurrenceStatus: {}, history: [], payments: [], customData: { preserved: true },
  workoutPlans: [{ id: 'p', studentId: 'a', name: 'Ficha de treino', organization: 'week', startDate: '2026-10-06', days: [
    { id: 'd', name: 'Treino A', weekday: 1, exercises: [{ id: 'ex', name: 'Elevação de quadril', sets: '3', reps: '10–12', load: '20 kg', rest: '60 s', video: 'https://youtu.be/M7lc1UVf-VE?t=30s' }] },
  ] }], workoutExecutions: [], workoutDrafts: {},
};
const server = http.createServer((req, res) => {
  if (req.url === '/native-player') { res.setHeader('Content-Type', 'text/html;charset=utf-8'); res.end(fs.readFileSync(nativePage)); return; }
  const file = path.join(assets, new URL(req.url, 'http://localhost').pathname);
  if (!file.startsWith(assets + path.sep) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', file.endsWith('.html') ? 'text/html;charset=utf-8' : 'application/octet-stream'); res.end(fs.readFileSync(file));
});
async function fits(page) {
  assert.equal(await page.evaluate(() => {
    if (document.documentElement.scrollWidth > innerWidth + 1) return 'Page overflow';
    for (const button of document.querySelectorAll('.workout-sheet button')) {
      if (!button.getClientRects().length || button.closest('[inert]')) continue;
      const box = button.getBoundingClientRect();
      if (box.x < 0 || box.right > innerWidth + 1 || box.height < 44 || button.scrollWidth > button.clientWidth + 1) return button.textContent;
    }
    return '';
  }), '');
}
async function main() {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ executablePath: process.env.AGENDA_CHROMIUM || path.resolve('work/alarm_review/browser/chromium'), headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const errors = [];
  try {
    for (const width of [320, 414, 768]) {
      const context = await browser.newContext({ viewport: { width, height: 900 }, isMobile: width < 768, hasTouch: true, timezoneId: 'America/Cuiaba' });
      await context.addInitScript(data => {
        if (!localStorage.getItem('agendaPersonalTL_v1')) localStorage.setItem('agendaPersonalTL_v1', JSON.stringify(data));
        window.Android = { syncLessonAlarms() { return true; }, getAlarmStatus() { return '{"ready":true}'; }, openYouTubeVideo(json) { window.__video = JSON.parse(json); return true; } };
      }, fixture);
      let embedReferer = '';
      await context.route('https://www.youtube.com/embed/**', route => { embedReferer = route.request().headers().referer || ''; return route.fulfill({ status: 200, contentType: 'text/html', body: '<html><body>Player de teste</body></html>' }); });
      const page = await context.newPage(); page.on('pageerror', error => errors.push(error.message));
      await page.goto('http://127.0.0.1:' + server.address().port + '/index.html');
      const cases = [
        ['https://www.youtube.com/watch?v=M7lc1UVf-VE', 0], ['https://youtu.be/M7lc1UVf-VE?si=share&t=90', 90],
        ['https://m.youtube.com/watch?v=M7lc1UVf-VE&t=1m30s', 90], ['https://www.youtube.com/shorts/M7lc1UVf-VE?si=share', 0],
        ['https://www.youtube.com/live/M7lc1UVf-VE?t=2m', 120], ['https://www.youtube.com/embed/M7lc1UVf-VE?start=45', 45],
        ['https://www.youtube-nocookie.com/embed/M7lc1UVf-VE', 0], ['youtu.be/M7lc1UVf-VE', 0],
        ['www.youtube.com/watch?v=M7lc1UVf-VE#t=1h2m3s', 3723], ['https://youtube.com/watch?v=M7lc1UVf-VE&t=-1', 0],
      ];
      for (const [url, start] of cases) {
        const parsed = await page.evaluate(url => workoutYouTubeVideo(url), url);
        assert.equal(parsed.videoId, 'M7lc1UVf-VE'); assert.equal(parsed.startSeconds, start);
      }
      for (const invalid of ['javascript:alert(1)', 'file:///video.mp4', 'https://youtube.com.evil.example/watch?v=M7lc1UVf-VE', 'https://evil.example/?youtube.com/watch?v=M7lc1UVf-VE', 'https://user:pass@youtube.com/watch?v=M7lc1UVf-VE', 'https://youtube.com:8443/watch?v=M7lc1UVf-VE', 'https://youtube.com/playlist?list=anything', 'https://youtube.com/@channel', 'https://youtu.be/short', 'https://youtu.be/M7lc1UVf-VE/extra', 'https://youtu.be/M7lc1UVf-V!', 'https://youtube.com/watch?v=%22%3E%3Cscript%3E']) {
        assert.equal(await page.evaluate(url => workoutYouTubeVideo(url), invalid), null);
      }
      await page.locator('.nav [data-screen="workouts"]').click(); await page.locator('.workout-student-choice').click();
      await page.locator('#workoutDaysList').getByRole('button', { name: 'Abrir treino', exact: true }).click();
      await page.locator('#workoutDayContent').getByRole('button', { name: 'Expandir todos', exact: true }).click();
      const initial = await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1'));
      await page.getByRole('button', { name: 'Assistir vídeo de Elevação de quadril', exact: true }).click();
      assert.deepEqual(await page.evaluate(() => __video), { videoId: 'M7lc1UVf-VE', startSeconds: 30, title: 'Elevação de quadril' });
      assert.equal(await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1')), initial);
      await page.getByRole('button', { name: 'Editar exercício Elevação de quadril', exact: true }).click();
      await page.locator('#workoutExerciseVideo').fill('youtube.com/shorts/M7lc1UVf-VE?t=1m');
      await page.locator('#workoutVideoPreview').click();
      assert.equal(await page.evaluate(() => __video.startSeconds), 60);
      assert.equal(await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1')), initial);
      await fits(page);
      await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click();
      assert.equal(await page.evaluate(() => currentWorkoutDay().exercises[0].video), 'https://youtube.com/shorts/M7lc1UVf-VE?t=1m');
      assert.equal(await page.evaluate(() => currentWorkoutDay().exercises[0].sets), '3');
      await page.evaluate(() => { delete Android.openYouTubeVideo; });
      await page.getByRole('button', { name: 'Assistir vídeo de Elevação de quadril', exact: true }).click();
      assert.match(await page.locator('#workoutVideoStatus').innerText(), /Android 1.29/);
      assert.equal(await page.locator('#workoutVideoPlayer iframe').count(), 0);
      await page.locator('#workoutVideoDialog .close').click(); assert.ok(await page.locator('#workoutDayDialog').isVisible());
      await page.evaluate(() => { delete window.Android; });
      await page.getByRole('button', { name: 'Assistir vídeo de Elevação de quadril', exact: true }).click();
      const frame = page.locator('#workoutVideoPlayer iframe');
      assert.match(await frame.getAttribute('src'), /youtube\.com\/embed\/M7lc1UVf-VE.*start=60/);
      await page.locator('#workoutVideoPlayer').waitFor({ state: 'visible' });
      assert.match(embedReferer, /^http:\/\/127\.0\.0\.1/);
      assert.ok((await frame.boundingBox()).height >= 200); await fits(page);
      await page.locator('#workoutVideoDialog .close').click(); assert.equal(await frame.count(), 0); assert.ok(await page.locator('#workoutDayDialog').isVisible());
      if (process.env.AGENDA_TEST_SCREENSHOTS && width === 414) {
        await page.getByRole('button', { name: 'Editar exercício Elevação de quadril', exact: true }).click();
        await page.waitForFunction(() => Number(getComputedStyle(document.getElementById('toast')).opacity) === 0);
        await page.locator('#workoutExerciseDialog .sheet').screenshot({ path: path.join(process.env.AGENDA_TEST_SCREENSHOTS, 'youtube-no-exercicio-414.png') });
      }
      await context.close();
    }
    const context = await browser.newContext({ viewport: { width: 360, height: 800 } });
    await context.route('https://www.youtube.com/iframe_api', route => route.fulfill({ contentType: 'text/javascript', body: "window.YT={Player:function(id,config){window.__playerConfig=config;this.pauseVideo=function(){window.__paused=true};var frame=document.createElement('iframe');frame.id=id;frame.title='YouTube de teste';frame.src='about:blank';document.getElementById(id).replaceWith(frame);queueMicrotask(function(){config.events.onReady({});});}};onYouTubeIframeAPIReady();" }));
    const page = await context.newPage(); page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:' + server.address().port + '/native-player');
    await page.waitForFunction(() => !!window.__playerConfig);
    assert.deepEqual(await page.evaluate(() => ({ id: __playerConfig.videoId, start: __playerConfig.playerVars.start, origin: __playerConfig.playerVars.origin })), { id: 'M7lc1UVf-VE', start: 90, origin: 'https://com.tiagolima.agendapersonal' });
    assert.ok((await page.locator('#player').boundingBox()).height >= 200);
    for (const [code, message] of [[100, /indisponível/], [101, /não permite/], [150, /não permite/], [153, /iniciar o player/]]) {
      await page.evaluate(code => __playerConfig.events.onError({ data: code }), code); assert.match(await page.locator('#status').innerText(), message);
    }
    await page.evaluate(() => __playerConfig.events.onAutoplayBlocked()); assert.match(await page.locator('#status').innerText(), /Toque/);
    await page.evaluate(() => pauseWorkoutVideo()); assert.equal(await page.evaluate(() => __paused), true);
    await context.close(); assert.deepEqual(errors, []);
    console.log('YouTube verificado: links normais, curtos e Shorts, instante inicial, URLs inválidas, prévia sem salvar, vídeo ligado ao exercício, ponte nativa, APK anterior, retorno e remoção do iframe, identificação do app, erros do player e pausa. Player remoto simulado; reprodução real requer conferência no aparelho.');
  } finally { await browser.close(); server.close(); fs.rmSync(temp, { recursive: true, force: true }); }
}
main().catch(error => { console.error(error); server.close(); process.exitCode = 1; });
