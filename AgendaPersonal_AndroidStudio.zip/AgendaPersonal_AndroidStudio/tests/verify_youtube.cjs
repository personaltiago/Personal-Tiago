const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const { createRequire } = require('node:module');
const runtime = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/') : require;
const { chromium } = runtime('playwright');
const project = path.resolve(__dirname, '..'), assets = path.join(project, 'app/src/main/assets');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'agenda-youtube-'));
const nativePage = path.join(temp, 'player.html');
const inlinePage = path.join(temp, 'inline-player.html');
execFileSync('java', ['com.sun.tools.javac.Main', '-encoding', 'UTF-8', '-d', temp,
  path.join(project, 'app/src/main/java/com/tiagolima/agendapersonal/YouTubePlayerPage.java'), path.join(__dirname, 'YouTubePageHarness.java')]);
execFileSync('java', ['-cp', temp, 'com.tiagolima.agendapersonal.YouTubePageHarness', nativePage, inlinePage], { stdio: 'inherit' });
const fixture = {
  students: [{ id: 'a', name: 'Aluno do vídeo', studentType: 'presencial', phone: '69999990000' }],
  lessons: [], occurrenceStatus: {}, history: [], payments: [], customData: { preserved: true },
  workoutPlans: [{ id: 'p', studentId: 'a', name: 'Ficha de treino', organization: 'week', startDate: '2026-10-06', days: [
    { id: 'd', name: 'Treino A', weekday: 1, exercises: [{ id: 'ex', name: 'Elevação de quadril', sets: '3', reps: '10–12', load: '20 kg', rest: '60 s', video: 'https://youtu.be/M7lc1UVf-VE?t=30s' }] },
  ] }], workoutExecutions: [], workoutDrafts: {},
};
const server = http.createServer((req, res) => {
  if (req.url === '/native-player') { res.setHeader('Content-Type', 'text/html;charset=utf-8'); res.end(fs.readFileSync(nativePage)); return; }
  if (req.url === '/inline-player') { res.setHeader('Content-Type', 'text/html;charset=utf-8'); res.end(fs.readFileSync(inlinePage)); return; }
  const file = path.join(assets, new URL(req.url, 'http://localhost').pathname);
  if (!file.startsWith(assets + path.sep) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', file.endsWith('.html') ? 'text/html;charset=utf-8' : 'application/octet-stream'); res.end(fs.readFileSync(file));
});
async function fits(page) {
  assert.equal(await page.evaluate(() => {
    if (document.documentElement.scrollWidth > innerWidth + 1) return 'Page overflow';
    for (const button of document.querySelectorAll('.workout-sheet button,.workout-video-sheet button')) {
      if (!button.getClientRects().length || button.closest('[inert]')) continue;
      const box = button.getBoundingClientRect();
      if (box.x < 0 || box.right > innerWidth + 1 || box.height < 44 || button.scrollWidth > button.clientWidth + 1) return button.textContent;
    }
    return '';
  }), '');
}
async function overlayFits(page, portrait = true) {
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const box = await page.evaluate(() => {
    const video = workoutInlineVideo, area = video.surface.getBoundingClientRect(), panel = document.querySelector('.workout-video-sheet').getBoundingClientRect(), close = document.querySelector('#workoutVideoDialog .close').getBoundingClientRect();
    return { x: area.x, top: area.top, right: area.right, bottom: area.bottom, width: area.width, height: area.height, panelTop: panel.top, panelBottom: panel.bottom, closeBottom: close.bottom, closeSize: close.width, viewportWidth: innerWidth, viewportHeight: innerHeight, portrait: video.wrapper.classList.contains('vertical'), bounds: workoutInlineBounds(video), sourceHidden: video.source.hidden, ownerInert: video.ownerSheet.closest('.dialog').inert };
  });
  assert.ok(box.width >= 200 && box.height >= 248); assert.ok(box.x >= 11 && box.right <= box.viewportWidth - 11);
  assert.ok(box.panelTop >= (box.viewportHeight<360?4:12) && box.panelBottom <= box.viewportHeight - (box.viewportHeight<360?4:12),JSON.stringify(box)); assert.ok(box.closeBottom <= box.top && box.closeSize >= 44);
  assert.equal(box.portrait, portrait); assert.equal(box.bounds.visible, true); assert.equal(box.sourceHidden, false); assert.equal(box.ownerInert, true);
  if (portrait) assert.ok(Math.abs(box.height / box.width - 16 / 9) < .01);
  await fits(page);
}
async function main() {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ executablePath: process.env.AGENDA_CHROMIUM || path.resolve('work/alarm_review/browser/chromium'), headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const errors = [];
  try {
    for (const width of [320, 414, 768]) {
      const context = await browser.newContext({ viewport: { width, height: 900 }, isMobile: width < 768, hasTouch: true, timezoneId: 'America/Cuiaba' });
      await context.addInitScript(data => {
        if (!localStorage.getItem('agendaPersonalTL_v1')) localStorage.setItem('agendaPersonalTL_v1', JSON.stringify(data));
        window.__positions=[];window.__closed=[];window.__separateCalls=0;
        window.Android = { syncLessonAlarms() { return true; }, getAlarmStatus() { return '{"ready":true}'; }, openYouTubeVideo(){ __separateCalls++;return true; },openInlineYouTubeVideo(json){ window.__video=JSON.parse(json); return !window.__rejectVideo; },positionInlineYouTubeVideo(key,json){__positions.push({key,...JSON.parse(json)});},closeInlineYouTubeVideo(key){__closed.push(key);} };
      }, fixture);
      let embedReferer = '';
      await context.route('https://www.youtube.com/embed/**', route => { embedReferer = route.request().headers().referer || ''; return route.fulfill({ status: 200, contentType: 'text/html', body: '<html><body>Player de teste</body></html>' }); });
      const page = await context.newPage(); page.on('pageerror', error => errors.push(error.message));
      await page.goto('http://127.0.0.1:' + server.address().port + '/index.html');
      const cases = [
        ['https://www.youtube.com/watch?v=M7lc1UVf-VE', 0], ['https://youtu.be/M7lc1UVf-VE?si=share&t=90', 90],
        ['https://m.youtube.com/watch?v=M7lc1UVf-VE&t=1m30s', 90], ['https://www.youtube.com/shorts/M7lc1UVf-VE?si=share', 0],
        ['https://www.youtube.com/live/M7lc1UVf-VE?t=2m', 120], ['https://www.youtube.com/embed/M7lc1UVf-VE?start=45', 45],
        ['https://www.youtube-nocookie.com/embed/M7lc1UVf-VE', 0], ['youtu.be/M7lc1UVf-VE', 0],
        ['www.youtube.com/watch?v=M7lc1UVf-VE#t=1h2m3s', 3723], ['https://youtube.com/watch?v=M7lc1UVf-VE&t=-1', 0],
      ];
      for (const [url, start] of cases) {
        const parsed = await page.evaluate(url => workoutYouTubeVideo(url), url);
        assert.equal(parsed.videoId, 'M7lc1UVf-VE'); assert.equal(parsed.startSeconds, start);
      }
      for (const invalid of ['javascript:alert(1)', 'file:///video.mp4', 'https://youtube.com.evil.example/watch?v=M7lc1UVf-VE', 'https://evil.example/?youtube.com/watch?v=M7lc1UVf-VE', 'https://user:pass@youtube.com/watch?v=M7lc1UVf-VE', 'https://youtube.com:8443/watch?v=M7lc1UVf-VE', 'https://youtube.com/playlist?list=anything', 'https://youtube.com/@channel', 'https://youtu.be/short', 'https://youtu.be/M7lc1UVf-VE/extra', 'https://youtu.be/M7lc1UVf-V!', 'https://youtube.com/watch?v=%22%3E%3Cscript%3E']) {
        assert.equal(await page.evaluate(url => workoutYouTubeVideo(url), invalid), null);
      }
      await page.locator('.nav [data-screen="workouts"]').click(); await page.locator('.workout-student-choice').click();
      await page.locator('#workoutDaysList').getByRole('button', { name: 'Abrir treino', exact: true }).click();
      await page.locator('#workoutDayContent').getByRole('button', { name: 'Expandir todos', exact: true }).click();
      const initial = await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1'));
      await page.getByRole('button', { name: 'Assistir vídeo de Elevação de quadril', exact: true }).scrollIntoViewIfNeeded();
      const originalScroll = await page.locator('#workoutDayDialog .sheet').evaluate(sheet => sheet.scrollTop);
      await page.getByRole('button', { name: 'Assistir vídeo de Elevação de quadril', exact: true }).click();
      assert.deepEqual(await page.evaluate(() => ({videoId:__video.videoId,startSeconds:__video.startSeconds,title:__video.title})), { videoId: 'M7lc1UVf-VE', startSeconds: 30, title: 'Elevação de quadril' });
      assert.equal(await page.evaluate(() => __separateCalls),0);assert.equal(await page.locator('#workoutDayContent .workout-inline-video').count(),0);assert.equal(await page.locator('#workoutVideoDialog').isVisible(),true);
      await overlayFits(page); assert.equal(await page.locator('#workoutVideoExternal').isVisible(),false);
      assert.ok(await page.evaluate(() => __video.bounds.width>=200&&__video.bounds.height>=240));const firstKey=await page.evaluate(()=>__video.key);
      assert.equal(await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1')), initial);
      await page.evaluate(() => openDialog('workoutExerciseDialog'));
      assert.equal(await page.evaluate(()=>__positions.at(-1).visible),false);
      await page.locator('#workoutExerciseDialog .close').click(); assert.equal(await page.evaluate(()=>__positions.at(-1).visible),true);
      await page.locator('#workoutVideoDialog .close').click(); assert.equal(await page.locator('#workoutDayDialog .sheet').evaluate(sheet=>sheet.scrollTop),originalScroll);
      assert.equal(await page.evaluate(()=>document.activeElement.getAttribute('aria-label')),'Assistir vídeo de Elevação de quadril');
      assert.ok(await page.evaluate(key=>__closed.includes(key),firstKey));assert.equal(await page.evaluate(()=>document.body.classList.contains('workout-video-open')),false);
      await page.getByRole('button', { name: 'Editar exercício Elevação de quadril', exact: true }).click();
      await page.locator('#workoutExerciseVideo').fill('youtube.com/shorts/M7lc1UVf-VE?t=1m');
      await page.locator('#workoutVideoPreview').click();
      assert.equal(await page.evaluate(() => __video.startSeconds), 60);
      assert.equal(await page.locator('#workoutVideoDialog .workout-inline-video.vertical').count(),1); await overlayFits(page);
      assert.equal(await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1')), initial);
      await page.locator('#workoutVideoDialog .close').click(); assert.equal(await page.locator('#workoutExerciseVideo').inputValue(),'https://youtube.com/shorts/M7lc1UVf-VE?t=1m');
      await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click();
      assert.equal(await page.evaluate(() => currentWorkoutDay().exercises[0].video), 'https://youtube.com/shorts/M7lc1UVf-VE?t=1m');
      assert.equal(await page.evaluate(() => currentWorkoutDay().exercises[0].sets), '3');
      await page.evaluate(() => { delete Android.openInlineYouTubeVideo; });
      await page.getByRole('button', { name: 'Assistir vídeo de Elevação de quadril', exact: true }).click();
      assert.match(await page.locator('.workout-inline-status').innerText(), /Android 1.31/);
      assert.equal(await page.locator('.workout-inline-surface iframe').count(), 0);assert.equal(await page.evaluate(()=>__separateCalls),0);
      assert.ok(await page.locator('#workoutVideoExternal').isVisible());
      await page.getByRole('button',{name:'Fechar vídeo e voltar ao treino',exact:true}).click(); assert.ok(await page.locator('#workoutDayDialog').isVisible());
      await page.evaluate(() => { delete window.Android; });
      await page.getByRole('button', { name: 'Assistir vídeo de Elevação de quadril', exact: true }).click();
      const frame = page.locator('.workout-inline-surface iframe');
      assert.match(await frame.getAttribute('src'), /youtube\.com\/embed\/M7lc1UVf-VE.*start=60/);
      await page.locator('.workout-inline-surface').waitFor({ state: 'visible' });
      assert.match(embedReferer, /^http:\/\/127\.0\.0\.1/);
      assert.ok((await frame.boundingBox()).height >= 200); await overlayFits(page);
      const frameSource=await frame.getAttribute('src'); await page.getByRole('button',{name:'Alternar vídeo para horizontal',exact:true}).click(); await overlayFits(page,false); assert.equal(await frame.getAttribute('src'),frameSource);
      await page.getByRole('button',{name:'Alternar vídeo para vertical',exact:true}).click(); await overlayFits(page);
      if(process.env.AGENDA_TEST_SCREENSHOTS&&width===414){await page.screenshot({path:path.join(process.env.AGENDA_TEST_SCREENSHOTS,'janela-video-vertical-414.png')});}
      await page.setViewportSize({width:568,height:320});await overlayFits(page,false);assert.equal(await frame.getAttribute('src'),frameSource);
      await page.setViewportSize({width:900,height:414});await overlayFits(page,false);assert.equal(await frame.getAttribute('src'),frameSource);
      await page.setViewportSize({width,height:900});await overlayFits(page);
      await page.keyboard.press('Escape'); assert.equal(await frame.count(), 0); assert.ok(await page.locator('#workoutDayDialog').isVisible());
      await page.getByRole('button',{name:'Assistir vídeo de Elevação de quadril',exact:true}).click();await page.evaluate(()=>clearWorkoutInlineVideo());assert.equal(await page.locator('#workoutVideoDialog').isVisible(),false);assert.ok(await page.locator('#workoutDayDialog').isVisible());
      await page.getByRole('button',{name:'Assistir vídeo de Elevação de quadril',exact:true}).click();await page.evaluate(()=>closeDialog('workoutDayDialog'));assert.equal(await page.locator('.workout-inline-video').count(),0);assert.ok(await page.locator('#workoutStudentDialog').isVisible());await page.locator('#workoutDaysList').getByRole('button',{name:'Abrir treino',exact:true}).click();
      if (process.env.AGENDA_TEST_SCREENSHOTS && width === 414) {
        await page.getByRole('button', { name: 'Editar exercício Elevação de quadril', exact: true }).click();
        await page.waitForFunction(() => Number(getComputedStyle(document.getElementById('toast')).opacity) === 0);
        await page.locator('#workoutExerciseDialog .sheet').screenshot({ path: path.join(process.env.AGENDA_TEST_SCREENSHOTS, 'youtube-no-exercicio-414.png') });
      }
      await context.close();
    }
    const context = await browser.newContext({ viewport: { width: 360, height: 800 } });
    await context.route('https://www.youtube.com/iframe_api', route => route.fulfill({ contentType: 'text/javascript', body: "window.YT={Player:function(id,config){window.__playerConfig=config;this.pauseVideo=function(){window.__paused=true};var frame=document.createElement('iframe');frame.id=id;frame.title='YouTube de teste';frame.src='about:blank';document.getElementById(id).replaceWith(frame);queueMicrotask(function(){config.events.onReady({});});}};onYouTubeIframeAPIReady();" }));
    const page = await context.newPage(); page.on('pageerror', error => errors.push(error.message));
    await page.goto('http://127.0.0.1:' + server.address().port + '/native-player');
    await page.waitForFunction(() => !!window.__playerConfig);
    assert.deepEqual(await page.evaluate(() => ({ id: __playerConfig.videoId, start: __playerConfig.playerVars.start, origin: __playerConfig.playerVars.origin })), { id: 'M7lc1UVf-VE', start: 90, origin: 'https://com.tiagolima.agendapersonal' });
    assert.ok((await page.locator('#player').boundingBox()).height >= 200);
    for (const [code, message] of [[100, /indisponível/], [101, /não permite/], [150, /não permite/], [153, /iniciar o player/]]) {
      await page.evaluate(code => __playerConfig.events.onError({ data: code }), code); assert.match(await page.locator('#status').innerText(), message);
    }
    await page.evaluate(() => __playerConfig.events.onAutoplayBlocked()); assert.match(await page.locator('#status').innerText(), /Toque/);
    await page.evaluate(() => pauseWorkoutVideo()); assert.equal(await page.evaluate(() => __paused), true);
    await page.setViewportSize({width:320,height:240});await page.goto('http://127.0.0.1:'+server.address().port+'/inline-player');await page.waitForFunction(()=>!!window.__playerConfig);assert.ok((await page.locator('#player').boundingBox()).height>=200);assert.equal(await page.locator('main').evaluate(m=>getComputedStyle(m).padding),'0px');
    await page.setViewportSize({width:320,height:248});await page.evaluate(()=>__playerConfig.events.onError({data:150}));assert.ok((await page.locator('#player').boundingBox()).height>=200);assert.equal(await page.locator('#status a').getAttribute('href'),'https://www.youtube.com/watch?v=M7lc1UVf-VE&t=90');assert.ok((await page.locator('#status a').boundingBox()).height>=44);assert.ok((await page.locator('#status a').boundingBox()).y>=200);
    await context.close(); assert.deepEqual(errors, []);
    console.log('Janela grande sobre o treino verificada: vertical inicial, horizontal, rotação, X/Escape/Voltar, foco e rolagem preservados, prévia e rascunho, ponte sem Activity separada, janela sobreposta, limpeza, APK anterior, dados preservados, 320/414/768 px e 568×320/900×414, identidade HTTPS, tamanho mínimo e abertura alternativa em erro. Mídia remota simulada.');
  } finally { await browser.close(); server.close(); fs.rmSync(temp, { recursive: true, force: true }); }
}
main().catch(error => { console.error(error); server.close(); process.exitCode = 1; });
