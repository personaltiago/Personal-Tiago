const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const runtime = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES ? createRequire(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES + '/') : require;
const { chromium } = runtime('playwright');
const assets = path.resolve(__dirname, '../app/src/main/assets');
const source = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures/catalogo_07.json'), 'utf8'));
const oldVideo = 'https://youtu.be/M7lc1UVf-VE?t=10';
const fixture = {
  students: [{ id: 'a', name: 'Aluna existente', studentType: 'presencial', phone: '69911111111', photoDataUrl: '' }],
  lessons: [{ id: 'lesson', studentId: 'a', date: '2026-10-07', time: '16:45', duration: 90, type: 'Treino individual', lead: 15, repeat: 'none', repeatDays: [], location: '', notes: '' }],
  payments: [{ id: 'payment', studentId: 'a', amount: 500, paidAt: '2026-10-05T12:00:00Z', dueDate: '2026-10-05' }], occurrenceStatus: {}, history: [], lessonTimers: {},
  exerciseCatalog: [{ id: 'mine-existing', name: 'Bíceps Spider', muscle: 'Bíceps', category: 'Musculação', video: oldVideo, notes: 'Instrução própria', customFlag: 'preservar' }],
  exerciseFavorites: ['app-ex-022', 'mine-existing'], workoutDrafts: {},
  workoutPlans: [{ id: 'p', studentId: 'a', name: 'Ficha atual', organization: 'week', days: [{ id: 'd', name: 'Dia A', weekday: 1, exercises: [
    { id: 'ex', catalogId: 'app-ex-022', name: 'Agachamento Hack', muscle: 'Inferiores', category: 'Musculação', sets: '3', reps: '10', load: '50 kg', rest: '75 s', video: oldVideo, observations: 'Individual' }
  ] }] }],
  workoutExecutions: [{ id: 'execution', planId: 'p', studentId: 'a', dayId: 'd', dayName: 'Dia A', date: '2026-10-05', exercises: [{ exerciseId: 'ex', name: 'Agachamento Hack', load: '45 kg', reps: '10' }], note: 'Histórico preservado' }],
  customData: { keep: true }
};
const server = http.createServer((req, res) => {
  const file = path.join(assets, new URL(req.url, 'http://localhost').pathname);
  if (!file.startsWith(assets + path.sep) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
  res.setHeader('Content-Type', file.endsWith('.html') ? 'text/html;charset=utf-8' : 'application/octet-stream');
  res.end(fs.readFileSync(file));
});
async function init(context) {
  await context.addInitScript(data => {
    if (!localStorage.getItem('agendaPersonalTL_v1')) localStorage.setItem('agendaPersonalTL_v1', JSON.stringify(data));
    const set = Storage.prototype.setItem;
    Storage.prototype.setItem = function(key, value) { if (key === 'agendaPersonalTL_v1' && window.__failSave) throw new Error('quota'); return set.call(this, key, value); };
    window.Android = { syncLessonAlarms() { return true; }, getAlarmStatus() { return '{"ready":true}'; }, openInlineYouTubeVideo(json) { window.__video = JSON.parse(json); return true; }, positionInlineYouTubeVideo() {}, closeInlineYouTubeVideo() {} };
  }, fixture);
  await context.route('https://i.ytimg.com/**', route => route.fulfill({ status: 200, contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="480" height="270"><rect width="480" height="270" fill="#2c1938"/></svg>' }));
}
async function open(page) {
  await page.locator('.nav [data-screen="workouts"]').click();
  await page.getByRole('button', { name: 'Catálogo de exercícios', exact: true }).click();
}
async function close(page, id) { await page.locator('#' + id + ' .close').click(); }
async function save(page) { await page.locator('#workoutExerciseForm').getByRole('button', { name: 'Salvar exercício', exact: true }).click(); }
async function fits(page) {
  assert.equal(await page.evaluate(() => {
    if (document.documentElement.scrollWidth > innerWidth + 1) return 'page overflow';
    for (const button of document.querySelectorAll('#workoutCatalogDialog button, #workoutExerciseDialog button')) {
      if (!button.getClientRects().length || button.closest('[inert]')) continue;
      const box = button.getBoundingClientRect();
      if (box.x < 0 || box.right > innerWidth + 1 || box.height < 44 || button.scrollWidth > button.clientWidth + 1) return button.textContent;
    }
    return '';
  }), '');
}
async function main() {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch({ executablePath: process.env.AGENDA_CHROMIUM || path.resolve('work/alarm_review/browser/chromium'), headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const errors = [];
  const url = 'http://127.0.0.1:' + server.address().port + '/index.html';
  try {
    const ctx = await browser.newContext({ viewport: { width: 414, height: 900 }, isMobile: true, hasTouch: true, timezoneId: 'America/Cuiaba' });
    await init(ctx); const page = await ctx.newPage(); page.on('pageerror', e => errors.push(e.message)); page.on('dialog', d => d.accept());
    await page.goto(url); await open(page);
    const before = await page.evaluate(() => structuredClone(state));
    const catalog = await page.evaluate(() => WORKOUT_STARTER_EXERCISES);
    assert.equal(source.sourceRows, 681); assert.equal(source.existingMatches, 18); assert.equal(catalog.length, 714);
    assert.equal(new Set(catalog.map(ex => ex.id)).size, 714);
    assert.equal(new Set(catalog.map(ex => ex.name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase())).size, 714);
    const byId = new Map(catalog.map(ex => [ex.id, ex]));
    for (const row of source.exercises) {
      const ex = byId.get(row.id); assert.ok(ex, row.name); assert.equal(ex.name, row.name); assert.equal(ex.muscle, row.muscle); assert.equal(ex.category, row.category); assert.equal(ex.video, '');
    }
    for (let i = 1; i <= 51; i++) assert.ok(byId.has('app-ex-' + String(i).padStart(3, '0')), 'stable old id ' + i);
    assert.equal(catalog.filter(ex => ex.reference?.page === 20).length, 4); assert.equal(catalog.filter(ex => ex.reference?.page === 21).length, 8);
    assert.equal(await page.locator('.workout-catalog-card').count(), 48); assert.match(await page.locator('#workoutCatalogCount').innerText(), /^714 exercícios · 48 exibidos$/);
    await page.locator('#workoutCatalogMore').click(); assert.equal(await page.locator('.workout-catalog-card').count(), 96);
    for (const row of source.exercises.filter(ex => ex.reference.page >= 20)) {
      await page.locator('#workoutCatalogSearch').fill(row.name); assert.equal(await page.locator(`[data-catalog-id="${row.id}"] h4`).innerText(), row.name);
    }
    await page.locator('#workoutCatalogSearch').fill('biceps spider'); assert.equal(await page.locator('.workout-catalog-card').count(), 1);
    await page.locator('#workoutCatalogSearch').fill('nordica inversa'); assert.equal(await page.locator('.workout-catalog-card').count(), 2);
    assert.ok((await page.evaluate(() => filteredWorkoutCatalog())).every(ex => ex.muscle === 'Quadríceps'));
    await page.locator('#workoutCatalogSearch').fill('aducao'); assert.ok((await page.evaluate(() => filteredWorkoutCatalog())).every(ex => ex.muscle === 'Adutores'));
    await page.locator('#workoutCatalogSearch').fill(''); await page.locator('#workoutCatalogMuscle').selectOption('Inferiores');
    assert.ok(await page.evaluate(() => ['Quadríceps','Posterior de coxa','Glúteos','Panturrilhas','Adutores'].every(muscle => filteredWorkoutCatalog().some(ex => ex.muscle === muscle))));
    await page.locator('#workoutCatalogCategory').selectOption('Alongamento'); assert.ok((await page.evaluate(() => filteredWorkoutCatalog())).every(ex => ex.category === 'Alongamento'));
    await page.getByRole('button', { name: 'Limpar filtros', exact: true }).click();
    await page.locator('#workoutCatalogSearch').fill('Supino halteres inclinado'); assert.equal(await page.locator('.workout-catalog-card').count(), 1);
    await page.locator('#workoutCatalogSearch').fill('dead bug'); assert.equal(await page.locator('.workout-catalog-card').count(), 2);
    await page.locator('#workoutCatalogSearch').fill('Agachamento Hack');
    const card = page.locator('[data-catalog-id="app-ex-022"]');
    await card.getByRole('button', { name: 'Adicionar vídeo', exact: true }).click();
    assert.equal(await page.locator('#workoutExerciseName').inputValue(), 'Agachamento Hack');
    assert.equal(await page.locator('#workoutExerciseMuscle').inputValue(), 'Quadríceps');
    assert.equal(await page.locator('#workoutExerciseVideo').inputValue(), '');
    await page.locator('#workoutExerciseVideo').fill('javascript:alert(1)'); await save(page); assert.ok(await page.locator('#workoutExerciseDialog').isVisible());
    await page.locator('#workoutExerciseVideo').fill('youtu.be/M7lc1UVf-VE?t=1m');
    const storedBeforeFailure = await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1'));
    await page.evaluate(() => __failSave = true); await save(page);
    assert.equal(await page.evaluate(() => localStorage.getItem('agendaPersonalTL_v1')), storedBeforeFailure);
    assert.deepEqual(await page.evaluate(() => state.exerciseCatalogOverrides), {});
    await page.evaluate(() => __failSave = false); await save(page);
    assert.equal(await page.evaluate(() => workoutCatalogItems().filter(ex => ex.source === 'app').length), 714);
    assert.equal(await page.evaluate(() => state.exerciseCatalog.length), 1);
    assert.equal(await page.evaluate(() => workoutCatalogItem('app-ex-022').video), 'https://youtu.be/M7lc1UVf-VE?t=1m');
    const preserved = await page.evaluate(() => structuredClone(state));
    for (const field of ['students','lessons','payments','workoutPlans','workoutExecutions','exerciseCatalog','customData']) assert.deepEqual(preserved[field], before[field], field);
    assert.deepEqual(preserved.exerciseFavorites, before.exerciseFavorites);
    await card.getByRole('button', { name: 'Assistir vídeo de Agachamento Hack', exact: true }).click();
    assert.equal(await page.evaluate(() => __video.videoId), 'M7lc1UVf-VE'); assert.equal(await page.evaluate(() => __video.startSeconds), 60);
    await close(page, 'workoutVideoDialog');
    await page.locator('#workoutCatalogVideo').selectOption('missing'); assert.equal(await page.locator('[data-catalog-id="app-ex-022"]').count(), 0);
    await page.locator('#workoutCatalogVideo').selectOption('ready'); assert.equal(await page.locator('.workout-catalog-card').count(), 1);
    await page.reload(); await open(page); await page.locator('#workoutCatalogSearch').fill('Agachamento Hack');
    assert.equal(await page.evaluate(() => workoutCatalogItem('app-ex-022').video), 'https://youtu.be/M7lc1UVf-VE?t=1m');
    await card.getByRole('button', { name: 'Editar vídeo', exact: true }).click();
    assert.equal(await page.locator('#workoutExerciseVideo').inputValue(), 'https://youtu.be/M7lc1UVf-VE?t=1m');
    await page.locator('#workoutExerciseVideo').fill('https://youtu.be/M7lc1UVf-VE?t=30'); await save(page);
    assert.equal(await page.evaluate(() => state.exerciseCatalog.length), 1); assert.equal(await page.evaluate(() => WORKOUT_STARTER_EXERCISES.length), 714);
    await page.getByRole('button', { name: 'Limpar filtros', exact: true }).click(); await page.locator('#workoutCatalogFavorites').click();
    assert.equal(await page.locator('.workout-catalog-card').count(), 2);
    await page.locator('#workoutCatalogMine').click();
    assert.equal(await page.locator('[data-catalog-id="mine-existing"] h4').innerText(), 'Bíceps Spider');
    assert.equal(await page.evaluate(() => workoutCatalogItem('mine-existing').video), oldVideo);
    await close(page, 'workoutCatalogDialog'); await page.locator('.workout-student-choice[data-student-id="a"]').click();
    await page.locator('[data-day-id="d"]').getByRole('button', { name: 'Abrir treino', exact: true }).click();
    await page.getByRole('button', { name: '+ Exercício', exact: true }).click();
    await page.locator('#workoutExerciseSets').fill('4'); await page.locator('#workoutExerciseReps').fill('12');
    await page.getByRole('button', { name: 'Escolher no catálogo de exercícios', exact: true }).click();
    await page.locator('#workoutCatalogSearch').fill('Agachamento Hack');
    await card.getByRole('button', { name: 'Usar no exercício', exact: true }).click();
    assert.equal(await page.locator('#workoutExerciseSets').inputValue(), '4'); assert.equal(await page.locator('#workoutExerciseReps').inputValue(), '12');
    assert.equal(await page.locator('#workoutExerciseVideo').inputValue(), 'https://youtu.be/M7lc1UVf-VE?t=30'); await save(page);
    const exercises = await page.evaluate(() => state.workoutPlans[0].days[0].exercises);
    assert.deepEqual(exercises[0], before.workoutPlans[0].days[0].exercises[0]);
    assert.equal(exercises[1].catalogId, 'app-ex-022'); assert.equal(exercises[1].sets, '4'); assert.equal(exercises[1].video, 'https://youtu.be/M7lc1UVf-VE?t=30');
    assert.equal(await page.evaluate(() => state.exerciseCatalog.length), 1);
    assert.deepEqual(await page.evaluate(() => state.workoutExecutions), before.workoutExecutions);
    await ctx.close();
    for (const width of [320, 360, 414, 768]) {
      const context = await browser.newContext({ viewport: { width, height: 900 }, isMobile: true }); await init(context);
      const p = await context.newPage(); p.on('pageerror', e => errors.push(e.message)); await p.goto(url); await open(p); await fits(p);
      await p.locator('#workoutCatalogSearch').fill('Abdução de Quadril na Máquina Articulada com Anilhas'); await fits(p);
      if (process.env.AGENDA_TEST_SCREENSHOTS && width === 414) await p.locator('#workoutCatalogDialog .sheet').screenshot({ path: path.join(process.env.AGENDA_TEST_SCREENSHOTS, 'catalogo-pdf-414.png') });
      await p.getByRole('button', { name: 'Adicionar vídeo', exact: true }).click(); await fits(p);
      await context.close();
    }
    assert.deepEqual(errors, []);
    console.log('Catálogo conferido: 681 nomes do PDF, 18 reaproveitados, 663 novos, total 714; 51 IDs anteriores; 12 inclusões finais; grupos, categorias, variações e aliases; paginação/busca sem acentos; vídeo direto sem duplicar, recarga, favoritos, falha/URL inválida; preservação de vídeos, fichas, cargas e histórico; reutilização e 320–768 px. Android e mídia simulados.');
  } finally { await browser.close(); await new Promise(resolve => server.close(resolve)); }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
