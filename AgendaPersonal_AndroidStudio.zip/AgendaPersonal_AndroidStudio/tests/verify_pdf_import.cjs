const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/avaliacoes.html'),'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
function extract(name){
 const lines=source.split('\n'),start=lines.findIndex(line=>new RegExp(`^  (?:async )?function ${name}\\(`).test(line));
 assert.ok(start>=0,name);let end=start+1;while(end<lines.length&&!/^  (?:async )?function \w+\(/.test(lines[end]))end++;
 const range=lines.slice(start,end).join('\n'),closing=range.lastIndexOf('\n  }');return closing<0?lines[start]:range.slice(0,closing+4);
}
const AGENDA='agendaPersonalTL_v1',EVAL='tiago-lima-avaliacoes-v1';
const photoA='data:image/jpeg;base64,AAAA',photoB='data:image/png;base64,BBBB',photoC='data:image/webp;base64,CCCC';
function runtime(){
 const initialAgenda={students:[],lessons:[{id:'old-lesson'}],payments:[{id:'old-payment'}],history:[],extra:'keep'};
 const storage=new Map([[AGENDA,JSON.stringify(initialAgenda)],[EVAL,JSON.stringify({clients:[]})]]),fields=new Map();
 const ctx={console,Date,TextEncoder,TextDecoder,crypto:require('node:crypto').webcrypto,fields,fail:false,
  document:{getElementById:id=>fields.get(id)},
  localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,value)=>{if(ctx.fail&&key===EVAL)throw new Error('disk full');storage.set(key,value);},removeItem:key=>storage.delete(key)}};
 vm.createContext(ctx);
 vm.runInContext(source.slice(source.indexOf('  const circumferences = ['),source.indexOf('  const objectiveLabels = {')),ctx);
 vm.runInContext(`const STORAGE_KEY='${EVAL}',AGENDA_DB_KEY='${AGENDA}',objectiveLabels={}; const PHOTO_SLOTS=[{key:'front'},{key:'back'},{key:'left'},{key:'right'}]; async function ensureStorage(){return 'localstorage';}`,ctx);
 for(const name of ['uid','pdfKey','normalizeAgendaName','studentNameKey','studentPhoneKey','validStudentPhone','readAgendaState','agendaStudentForClient','phoneForClient','validStudentType','studentTypeForClient','ensureAgendaStudentProfile','emptyState','readState','writeState','syncClientName','syncClientIdentity','writeAssessmentState','allFolds','skinfoldResult','validate','dateLabel','pdfPhotoSlots','resolvedPdfPhotoSlots','importedDataFromPdf','recordPhotoSlots','pdfAssessmentMatches','setRecordPhotoSlots','importPdfAssessments','api'])vm.runInContext(extract(name),ctx);
 function data(date,weight,photos){return ctx.importedDataFromPdf({date,age:31,equation:'male',height:179,weight,photos,
  circumference:{neck:36,shoulder:119,chest:97,waist:85.5,abdomen:95,hip:102,armLeft:34.5,armRight:35.5,thighLeft:64,thighRight:62,calfLeft:40,calfRight:39.5},
  folds:{triceps:14,subscapular:18,suprailiac:17,pectoral:13,midaxillary:17,abdominal:27,thigh:27},
  peakFat:null,fitnessFat:null,healthyFat:null,stageFat:null,longFat:null},'Luís Silva','69 99999-1111');}
 const read=()=>JSON.parse(storage.get(EVAL));
 const call=body=>ctx.api('/api/import-assessments',{method:'POST',body:JSON.stringify(body)});
 return{ctx,fields,storage,data,read,call};
}
(async()=>{
 const rt=runtime(),before=rt.data('2026-07-20',87.3,[photoA]),after=rt.data('2026-09-17',80,['',photoB,'',photoC]);
 const result=await rt.call({records:[before,after]});
 assert.equal(result.imported,2);
 assert.equal(result.importedPhotos,3);
 let client=rt.read().clients[0];assert.equal(client.assessments.length,2);
 assert.deepEqual(client.assessments[1].data.photoSlots,['back','right']);
 assert.deepEqual(client.assessments[1].photos,[photoB,photoC]);
 assert.equal(client.assessments[1].data.photos.length,0,'photo bytes stored once');
 const agenda=JSON.parse(rt.storage.get(AGENDA));assert.equal(agenda.students.length,1);assert.equal(agenda.lessons[0].id,'old-lesson');assert.equal(agenda.payments[0].id,'old-payment');
 const ids=client.assessments.map(record=>record.id),initialId=client.id;
 const recovery=await rt.call({clientId:initialId,records:[{...before,photos:[photoC,photoB]},after]});
 assert.equal(recovery.imported,0);assert.equal(recovery.restoredPhotos,1);
 client=rt.read().clients[0];assert.deepEqual(client.assessments.map(record=>record.id),ids);
 assert.equal(client.assessments[0].photos[0],photoA,'existing photo preserved');
 assert.equal(client.assessments[0].photos[1],photoB);
 await rt.call({clientId:initialId,records:[{...before,clientName:'Luis Silva'}]});
 assert.equal(rt.read().clients[0].name,'Luís Silva','stored full name preserved when an old PDF loses an accent');
 const saved=rt.storage.get(EVAL);
 await assert.rejects(rt.call({clientId:initialId,records:[{...before,photos:[photoA,photoB,photoC]},{...after,weight:79}]}),/medidas diferentes/);
 assert.equal(rt.storage.get(EVAL),saved,'no partial photo recovery');
 await assert.rejects(rt.call({clientId:initialId,records:[{...after,clientPhone:'69 99999-2222'}]}),/telefone/);
 await assert.rejects(rt.call({clientId:initialId,records:[{...after,clientName:'Luís Souza'}]}),/cadastro escolhido/);
 await assert.rejects(rt.call({records:[before,before]}),/datas diferentes/);
 const invalid=runtime(),invalidAgenda=invalid.storage.get(AGENDA);
 await assert.rejects(invalid.call({records:[{...before,photos:['javascript:alert(1)']}]}),/inválida/);
 assert.equal(invalid.storage.get(AGENDA),invalidAgenda);assert.equal(invalid.read().clients.length,0);
 const failing=runtime(),rollback=failing.storage.get(AGENDA);failing.ctx.fail=true;
 await assert.rejects(failing.call({records:[before,after]}),/espaço local/);
 assert.equal(failing.storage.get(AGENDA),rollback);assert.equal(failing.read().clients.length,0);
 const ambiguous={date:'2026-07-20',photos:[photoA],unassignedPhotos:[{src:photoB,label:'Lado'}]};
 assert.throws(()=>rt.ctx.resolvedPdfPhotoSlots(ambiguous),/Selecione a posição/);
 rt.fields.set('pdf-import-photo-0-0',{value:'3'});
 assert.equal(rt.ctx.resolvedPdfPhotoSlots(ambiguous)[3],photoB);
 rt.fields.set('pdf-import-photo-0-0',{value:'0'});
 assert.throws(()=>rt.ctx.resolvedPdfPhotoSlots(ambiguous),/duas fotos/);
 const typed=runtime();
 const typedResult=await typed.call({records:[{...before,studentType:'online'},{...after,studentType:'online'}]});
 const typedAgenda=JSON.parse(typed.storage.get(AGENDA));
 assert.equal(typedAgenda.students[0].studentType,'online');
 assert.equal(typed.read().clients[0].studentType,'online');
 typedAgenda.students[0].studentType='presencial';typed.storage.set(AGENDA,JSON.stringify(typedAgenda));
 await typed.call({clientId:typedResult.clientId,records:[{...before,studentType:'online'}]});
 assert.equal(JSON.parse(typed.storage.get(AGENDA)).students[0].studentType,'presencial','old PDF must preserve the current student type');
 assert.equal(typed.read().clients[0].studentType,'presencial');
 assert.equal(typed.read().clients[0].assessments[0].photos[0],photoA);
 const manualType=runtime(),manualAgenda=JSON.parse(manualType.storage.get(AGENDA));
 manualAgenda.students.push({id:'manual-student',name:'Luís Silva',phone:'69 99999-1111',studentType:'presencial',photoDataUrl:photoC,location:'Local atual'});
 manualType.storage.set(AGENDA,JSON.stringify(manualAgenda));
 await manualType.call({records:[{...before,studentType:'online'}]});
 const manualStudent=JSON.parse(manualType.storage.get(AGENDA)).students[0];
 assert.equal(manualStudent.id,'manual-student');assert.equal(manualStudent.studentType,'presencial');
 assert.equal(manualStudent.photoDataUrl,photoC);assert.equal(manualStudent.location,'Local atual');
 assert.equal(manualType.read().clients[0].studentType,'presencial');
 console.log('Importação: duas avaliações e fotos juntas, recuperação sem duplicação, dados existentes preservados, posição lateral conferida, identidade e gravação atômica.');
})().catch(error=>{console.error(error);process.exitCode=1;});
