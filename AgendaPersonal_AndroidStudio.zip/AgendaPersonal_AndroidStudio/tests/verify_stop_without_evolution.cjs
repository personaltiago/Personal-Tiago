const fs=require('node:fs'),assert=require('node:assert/strict'),vm=require('node:vm'),path=require('node:path');
const html=fs.readFileSync(path.resolve(__dirname,'../app/src/main/assets/index.html'),'utf8');
function excerpt(first,last){const a=html.indexOf(first),b=html.indexOf(last,a+first.length);if(a<0||b<0)throw Error('Missing function: '+first);return html.slice(a,b)}
const code=[
 excerpt('function workoutDraftKey(planId,dayId){','function workoutExerciseDraft('),
 excerpt('function workoutSessionHtml(plan,day,running){','function openWorkoutForLesson('),
 excerpt('function workoutRunning(plan,day){','function workoutDurationText('),
].join('\n');
const baselineExecutions=[{id:'execution-previous',load:'45 kg',studentId:'student',planId:'plan',dayId:'day'}];
const baselineHistory=[{id:'history-previous',text:'Aula já realizada'}];
const exercises=[{id:'ex1',name:'Agachamento',load:'30 kg',sets:'3',reps:'12',technique:{name:'Rest-pause'}},{id:'ex2',name:'Cadeira flexora',load:'50 kg',sets:'3',reps:'10'}];
const plan={id:'plan',studentId:'student',days:[{id:'day',name:'DIA A',exercises}]};const day=plan.days[0];
let persisted,fail=false,approve=true,borrowed=null,events=[],step=0;
const sheet={scrollTop:50};
const state={workoutPlans:[plan],students:[{id:'student',name:'Jéssica',studentType:'presencial'}],workoutExecutions:baselineExecutions.slice(),history:baselineHistory.slice(),workoutDrafts:{},lessonTimers:{},workoutRest:null};
function clone(x){return JSON.parse(JSON.stringify(x))}
const context={
 state,Date,console,window:{},studentById:id=>state.students.find(x=>x.id===id),
 currentWorkoutPlan:()=>plan,currentWorkoutDay:()=>day,workoutPlanArchived:()=>false,
 confirm:message=>{events.push('confirm');assert.match(message,/sem salvar/i);return approve},
 workoutTimerSetupHtml:()=>'<div>Configuração do cronômetro</div>',
 lessonCountdownHtml:()=>'<div>Contagem</div>',
 hesc:String,
 workoutTimerConfiguration:()=>borrowed?{key:borrowed.key,timer:borrowed.timer,reusedExisting:true}:(()=>{const start=Date.now(),key='workout:plan:day|today';return{key,timer:{lessonId:'workout:plan:day',date:'today',planId:'plan',dayId:'day',standalone:true,startedAt:start,endAt:start+3600000,duration:60},reusedExisting:false}})(),
 commitWorkoutChange:(changes,text,renderDay=true)=>{events.push('persist');if(fail)return false;assert.equal(text||'','');Object.assign(state,changes);persisted=clone(state);if(renderDay)context.renderWorkoutDay();return true},
 armLessonTimer:()=>({native:true,warning:''}),syncNativeAlarms:()=>events.push('sync'),renderToday:()=>events.push('today'),renderWeek:()=>events.push('week'),renderWorkoutDay:()=>{events.push('render');step++;},
 updateWorkoutSessionLabels:()=>events.push('labels'),updateTimerLabels:()=>events.push('timerlabels'),cancelNativeWorkoutRest:()=>events.push('rest-cancel'),cancelNativeLessonTimer:()=>{events.push('timer-cancel');return true},
 toast:()=>events.push('toast'),id:()=>String(++step),
 document:{getElementById:()=>({classList:{contains:()=>false}}),querySelector:()=>sheet},closeDialog:()=>{throw Error('No modal open')},
};
vm.createContext(context);vm.runInContext(code,context);
function restartData(){state.workoutDrafts={};state.lessonTimers={};state.workoutRest=null;events=[];persisted=clone(state);fail=false;approve=true;borrowed=null;sheet.scrollTop=50;}
assert.match(context.workoutSessionHtml(plan,day,false),/Iniciar treino presencial/);
function start(){context.startWorkoutSession();assert.equal(context.workoutRunning(plan,day),true);assert.match(context.workoutSessionHtml(plan,day,true),/Parar treino/);}
start();
assert.equal(state.workoutDrafts['plan|day'].timerOwned,true);
const startedTimerKey=state.workoutDrafts['plan|day'].timerKey;
assert.ok(state.lessonTimers[startedTimerKey]);
state.workoutDrafts['plan|day'].values.ex1={done:true,load:'90 kg'};
state.workoutDrafts['plan|day'].bisets.some={rounds:2};
state.workoutRest={planId:'plan',dayId:'day',seconds:45};
const savedBefore=clone(state);
approve=false;context.stopWorkoutSession();
assert.deepEqual(clone(state),savedBefore);assert.equal(events.includes('timer-cancel'),false);
approve=true;fail=true;context.stopWorkoutSession();
assert.deepEqual(clone(state),savedBefore);assert.equal(events.includes('timer-cancel'),false);
fail=false;context.stopWorkoutSession();
assert.equal(context.workoutRunning(plan,day),false);
assert.equal(state.workoutDrafts['plan|day'],undefined);assert.deepEqual(Object.keys(state.lessonTimers),[]);
assert.equal(state.workoutRest,null);assert.equal(sheet.scrollTop,0);
assert.deepEqual(clone(state.workoutExecutions),baselineExecutions);
assert.deepEqual(clone(state.history),baselineHistory);
assert.equal(events.filter(x=>x==='timer-cancel').length,1);assert.equal(events.filter(x=>x==='rest-cancel').length,1);
assert.deepEqual(clone(persisted),clone(state));
assert.doesNotMatch(context.workoutSessionHtml(plan,day,false),/Parar treino/);
restartData();start();assert.deepEqual(clone(state.workoutDrafts['plan|day'].values),{});assert.deepEqual(clone(state.workoutDrafts['plan|day'].bisets),{});context.stopWorkoutSession();
// Standalone timer from an active draft created before the new ownership flag was introduced.
restartData();start();delete state.workoutDrafts['plan|day'].timerOwned;context.stopWorkoutSession();assert.deepEqual(Object.keys(state.lessonTimers),[]);
// Do not cancel a timer started independently for an actual booked lesson.
restartData();const lessonTimer={lessonId:'lesson',date:'today',studentId:'student',standalone:false,endAt:Date.now()+3600000,duration:60};borrowed={key:'lesson|today',timer:lessonTimer};state.lessonTimers[borrowed.key]=lessonTimer;
start();assert.equal(state.workoutDrafts['plan|day'].timerOwned,false);context.stopWorkoutSession();
assert.deepEqual(Object.keys(state.lessonTimers),['lesson|today']);assert.equal(events.includes('timer-cancel'),false);assert.deepEqual(clone(state.workoutExecutions),baselineExecutions);
// A different running workout can share a timer; it must not be cancelled.
restartData();start();state.workoutDrafts['other|day']={active:true,sessionId:'other',timerKey:state.workoutDrafts['plan|day'].timerKey,values:{}};context.stopWorkoutSession();
assert.equal(events.includes('timer-cancel'),false);assert.equal(Object.keys(state.lessonTimers).length,1);
assert.ok(state.workoutDrafts['other|day']);
console.log(JSON.stringify({passed:true,checks:['UI has stop button only while running','standalone timer owned','declined confirmation preserves data','failed persistence preserves draft and timers','no evolution/history/attendance writes','reset all marks, rounds, rest and time','persisted clean state','start from scratch','legacy draft supported','preserve external lesson timer','preserve timer shared with other running workout']},null,2));
