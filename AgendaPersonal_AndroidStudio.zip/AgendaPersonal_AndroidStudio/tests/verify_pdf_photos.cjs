const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname,'../app/src/main/assets/avaliacoes.html'),'utf8');
const script = source.match(/<script>([\s\S]*?)<\/script>/)[1];
function extract(name) {
  const lines = script.split('\n');
  const start = lines.findIndex(line=>new RegExp(`^  (?:async )?function ${name}\\(`).test(line));
  assert.ok(start>=0,name);
  let end=start+1;
  while(end<lines.length && !/^  (?:async )?function \w+\(/.test(lines[end]))end++;
  const chunk=lines.slice(start,end).join('\n'), close=chunk.lastIndexOf('\n  }');
  return close<0 ? lines[start] : chunk.slice(0,close+4);
}
const context = {console,TextEncoder,TextDecoder,Uint8Array,atob,btoa,
  phoneForClient: client=>client.phone,
  studentTypeForClient: client=>client.studentType || '',
  skinfoldResult: ()=>({sum:133,bodyFat:19.2})};
vm.createContext(context);
vm.runInContext("const PHOTO_SLOTS=[{key:'front'},{key:'back'},{key:'left'},{key:'right'}];",context);
for(const name of ['bytesToBase64','utf8ToBase64','base64ToUtf8','recordPhotoSlots','photoSourcesForRecord','hasPhotos','pdfPhotoSlots','pdfRoundTripAssessment','embeddedPdfRoundTrip','createRasterPdfDoc'])vm.runInContext(extract(name),context);
for(const name of ['pdfKey','pdfISO','pdfPhotoCandidates','rasterPhotoRegions'])vm.runInContext(extract(name),context);

(async()=>{
  // Payload bigger than 256 KB verifies the former truncation boundary.
  const photo='data:image/jpeg;base64,'+Buffer.from('photo-before'.repeat(30000)).toString('base64');
  const after='data:image/png;base64,'+Buffer.from('photo-after').toString('base64');
  const client={name:'Luís Ç',phone:'69 99999-1111',studentType:'online',equation:'male'};
  const record={date:'2026-07-20',photos:[photo],data:{age:31,height:179,weight:87.3,folds:{triceps:14},photoSlots:['front']}};
  const first=context.pdfRoundTripAssessment(record,client);
  const second=context.pdfRoundTripAssessment({...record,date:'2026-09-17',photos:[after],data:{...record.data,photoSlots:['right']}},client);
  assert.equal(first.photos[0],photo);
  assert.equal(second.photos[3],after);
  assert.equal(second.photos[0],'');
  assert.equal(first.clientPhone,client.phone);
  assert.equal(first.studentType,'online');
  const snapshot={format:'agenda-personal-pdf-data',version:1,kind:'comparison',data:{kind:'comparison',clientName:client.name,equation:client.equation,assessments:[first,second]}};
  const bytes=await context.createRasterPdfDoc([{width:1,height:1,bytes:new Uint8Array([255,216,255,217])}],snapshot).save();
  assert.ok(bytes.length>262144);
  const restored=context.embeddedPdfRoundTrip(bytes);
  assert.equal(restored.clientName,client.name);
  assert.equal(restored.assessments[0].photos[0],photo);
  assert.equal(restored.assessments[1].photos[3],after);
  assert.equal(restored.assessments[1].date,'2026-09-17');
  assert.equal(restored.assessments[0].studentType,'online');
  const single={format:'agenda-personal-pdf-data',version:1,kind:'single',data:{kind:'single',...first}};
  assert.equal(context.embeddedPdfRoundTrip(await context.createRasterPdfDoc([],single).save()).photos[0],photo);
  const old={...single,data:{...single.data,photos:undefined}};
  assert.equal(context.embeddedPdfRoundTrip(await context.createRasterPdfDoc([],old).save()).photos.filter(Boolean).length,0);
  assert.throws(()=>context.pdfPhotoSlots({photos:['javascript:alert(1)']}),/inválida/);
  assert.throws(()=>context.embeddedPdfRoundTrip(new TextEncoder().encode('%PDF-1.4\n%AGENDA_PERSONAL_DATA:not-base64!\n')),/incompletos/);
  assert.ok(!extract('evolutionPosterPage').includes('sharePhotos('),'photo strips absent from metrics page');
  assert.ok(extract('comparisonPhotosPage').includes('comparison-photo-stack'),'final photo comparison preserved');
  const records=[{date:'2026-07-20'},{date:'2026-09-17'}];
  const items=[{text:'20/07/2026 · 31 anos',x:20,y:730,width:130},{text:'17/09/2026 · 31 anos',x:400,y:730,width:130},{text:'Frente',x:30,y:545,width:25},{text:'Lateral',x:420,y:545,width:38},{text:'direita',x:460,y:545,width:29}];
  const found=context.pdfPhotoCandidates(items,[{rect:[20,550,100,700]},{rect:[400,550,500,700]}],records);
  assert.equal(found[0].index,0);assert.equal(found[0].slot,0);
  assert.equal(found[1].index,1);assert.equal(found[1].slot,3,'split caption keeps the right side');
  const width=400,height=600,pixels=new Uint8Array(width*height*4);
  const pixel=(x,y)=>{const p=(y*width+x)*4;pixels[p]=216;pixels[p+1]=201;pixels[p+2]=226;pixels[p+3]=255;};
  const outline=(x0,y0,x1,y1)=>{for(let x=x0;x<=x1;x++){pixel(x,y0);pixel(x,y1);}for(let y=y0;y<=y1;y++){pixel(x0,y);pixel(x1,y);}};
  for(const y of [120,340]){outline(6,y-10,393,y+173);for(const x of [12,142,272])outline(x,y,x+116,y+160);}
  assert.equal(context.rasterPhotoRegions(pixels,width,height).length,6,'both assessment rows recovered, outer groups excluded');
  pixels.fill(0);for(let y=120;y<500;y++)for(let x=80;x<320;x++)pixel(x,y);
  assert.equal(context.rasterPhotoRegions(pixels,width,height).length,0,'a coloured area is not a photo frame');
  console.log('PDF: fotos e posições preservadas, duas datas e UTF-8, marcador maior que 256 KB, compatibilidade antiga e dados inválidos.');
})().catch(error=>{console.error(error);process.exitCode=1;});
